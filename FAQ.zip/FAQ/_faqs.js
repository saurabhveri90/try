$(document).ready(function() {
  if ($('.accordion-container').hasClass('open-all')) {
    $('.accordion-content').slideDown().addClass('open');
    $('.arrow').addClass('open');
  }

  $('.accordion-header').click(function() {
    const content = $(this).next('.accordion-content');
    const arrow = $(this).find('.arrow');
    if ($('.accordion-container').hasClass('open-all')) {
      content.stop(true, true).slideToggle();
      arrow.toggleClass('open');
    } else {
      if (!content.is(':visible')) {
        $('.accordion-content').slideUp().removeClass('open');
        $('.arrow').removeClass('open');
      }
      content.stop(true, true).slideToggle().toggleClass('open');
      arrow.toggleClass('open');
    }
  });
});