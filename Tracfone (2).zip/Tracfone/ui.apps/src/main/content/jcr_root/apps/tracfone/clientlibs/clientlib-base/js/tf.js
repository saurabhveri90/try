(function tfCustom() {
    /*Tracfone JS can be included here*/
}());