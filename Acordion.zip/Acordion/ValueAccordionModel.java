package com.verizon.value.aem.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.models.Accordion;
import com.adobe.cq.wcm.core.components.models.PanelContainerItem;
import com.adobe.cq.wcm.core.components.models.datalayer.ComponentData;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.via.ResourceSuperType;

import java.util.List;

@Model(adaptables = SlingHttpServletRequest.class, adapters = { Accordion.class,
        ValueAccordionModel.class }, resourceType = ValueAccordionModel.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, extensions = ExporterConstants.SLING_MODEL_EXTENSION)
public class ValueAccordionModel implements Accordion {


    @Self
    @Via(type = ResourceSuperType.class)
    Accordion accordion;

    public static final String RESOURCE_TYPE = "value-aem/components/core/accordion";

    @ValueMapValue
    private String arrowIcon;

    public String getArrowIcon(){
        return arrowIcon;
    }

    @Override
    public boolean isSingleExpansion() {
        return accordion.isSingleExpansion();
    }

    @Override
    public String getHeadingElement() {
        return accordion.getHeadingElement();
    }

    @Override
    public List<? extends PanelContainerItem> getChildren() {
        return accordion.getChildren();
    }


    @Override
    public String getAppliedCssClasses() {
        return accordion.getAppliedCssClasses();
    }

    @Override
    public String[] getExpandedItems() {
        return accordion.getExpandedItems();
    }

    @Override
    public ComponentData getData() {
        return accordion.getData();
    }

    @Override
    public String getId() {
        return accordion.getId();
    }

}
