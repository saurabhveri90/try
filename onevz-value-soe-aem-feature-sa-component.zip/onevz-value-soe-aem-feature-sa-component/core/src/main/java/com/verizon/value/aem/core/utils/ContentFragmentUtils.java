package com.verizon.value.aem.core.utils;

import com.adobe.cq.dam.cfm.ContentElement;
import com.adobe.cq.dam.cfm.ContentFragment;
import com.adobe.cq.dam.cfm.FragmentTemplate;
import com.adobe.cq.export.json.ComponentExporter;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.policies.ContentPolicy;
import com.day.cq.wcm.api.policies.ContentPolicyManager;
import com.day.text.Text;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Session;
import java.util.*;

import static com.day.cq.commons.jcr.JcrConstants.JCR_CONTENT;

/**
 * Utilities to ease the work with {@link ContentFragment content fragments}.
 */
public class ContentFragmentUtils {

    private static final Logger LOG = LoggerFactory.getLogger(ContentFragmentUtils.class);

    /**
     * The default grid type.
     */
    private static final String DEFAULT_GRID_TYPE = "dam/cfm/components/grid";

    /**
     * Name of the property of an optional {@link ContentPolicy content policy} holding the name of the grid type.
     */
    private static final String PN_CFM_GRID_TYPE = "cfm-grid-type";

    /* Hide the constructor of utility classes */
    private ContentFragmentUtils() {
    }

    /**
     * Returns the type of {@link ContentFragment content fragment}. The type is a string that uniquely identifies the
     * model or template of the content fragment (CF) (e.g. <code>my-project/models/my-model</code> for a structured CF
     * or <code>/content/dam/my-cf/jcr:content/model</code> for a text-only CF).
     *
     * @param contentFragment the content fragment
     * @return the type of the content fragment
     */
    public static String getType(ContentFragment contentFragment) {
        String type = "";
        if (contentFragment == null) {
            return type;
        }

        Resource fragmentResource = contentFragment.adaptTo(Resource.class);
        FragmentTemplate fragmentTemplate = contentFragment.getTemplate();
        if (fragmentTemplate == null) {
            return type;
        }
        Resource templateResource = fragmentTemplate.adaptTo(Resource.class);
        if (fragmentResource == null || templateResource == null) {
            LOG.warn("Unable to return type: fragment or template resource is null");
            type = contentFragment.getName();
        } else {
            // use the parent if the template resource is the jcr:content child
            Resource parent = templateResource.getParent();
            if (JCR_CONTENT.equals(templateResource.getName()) && parent != null) {
                templateResource = parent;
            }
            // get data node to check if this is a text-only or structured content fragment
            Resource data = fragmentResource.getChild(JCR_CONTENT + "/data");
            if (data == null || data.getValueMap().get("cq:model") == null) {
                // this is a text-only content fragment, for which we use the model path as the type
                type = templateResource.getPath();
            } else {
                // this is a structured content fragment, assemble type string (e.g. "my-project/models/my-model" or
                // "my-project/nested/models/my-model")
                StringBuilder prefix = new StringBuilder();
                String[] segments = Text.explode(templateResource.getPath(), '/', false);
                // get the configuration names (e.g. for "my-project/" or "my-project/nested/")
                for (int i = 1; i < segments.length - 5; i++) {
                    prefix.append(segments[i]);
                    prefix.append("/");
                }
                type = prefix + "models/" + templateResource.getName();
            }
        }

        return type;
    }

    public static String getModelPath(Resource fragmentResource) {
        String modelPath = null;
        Resource data = fragmentResource.getChild(JCR_CONTENT + "/data");
        if (data != null) {
            modelPath = data.getValueMap().get("cq:model", String.class);
        }
        return modelPath;
    }

    public static String getContentRenditionPath(String path) {
        return path + "/" + JCR_CONTENT + "/data/master";
    }


    /**
     * Filters {@link ContentElement content elements} by their name.
     *
     * <p><b>Note:</b> The natural order of the elements in the content fragment will not be maintained. Instead
     * elements will be order as provided in the filter.</p>
     *
     * @param contentFragment the content fragment
     * @param elementNames    the names of the elements to filter
     * @return all content elements found matching the filter
     */
    public static Iterator<ContentElement> filterElements(final ContentFragment contentFragment,
                                                          final String[] elementNames) {

        if (ArrayUtils.isNotEmpty(elementNames)) {
            List<ContentElement> elements = new LinkedList<>();
            for (String name : elementNames) {
                if (!contentFragment.hasElement(name)) {
                    // skip non-existing element
                    LOG.warn("Skipping non-existing element '{}'", name);
                    continue;
                }
                elements.add(contentFragment.getElement(name));
            }
            return elements.iterator();
        }
        return contentFragment.getElements();
    }

    /**
     * Returns an optional grid type configured via {@link ContentPolicy content policy} property
     * ({@value #PN_CFM_GRID_TYPE}) or {@value #DEFAULT_GRID_TYPE} as default.
     *
     * @param fragmentResource the content fragment resource to be checked
     * @return the configured grid type of default
     */
    public static String getGridResourceType(Resource fragmentResource) {
        String gridResourceType = DEFAULT_GRID_TYPE;
        if (fragmentResource == null) {
            return gridResourceType;
        }
        ResourceResolver resourceResolver = fragmentResource.getResourceResolver();
        ContentPolicyManager contentPolicyManager = resourceResolver.adaptTo(ContentPolicyManager.class);
        ContentPolicy fragmentContentPolicy = contentPolicyManager != null ? contentPolicyManager.getPolicy(fragmentResource) : null;
        if (fragmentContentPolicy != null) {
            ValueMap contentPolicyProperties = fragmentContentPolicy.getProperties();
            gridResourceType = contentPolicyProperties.get(PN_CFM_GRID_TYPE, DEFAULT_GRID_TYPE);
        }
        return gridResourceType;
    }

    /**
     * Returns an array with all item keys in order of given map.
     *
     * @param itemsMap a map of items
     * @return an array with all keys in order of given map
     */
    public static String[] getItemsOrder(Map<String, ?> itemsMap) {
        if (itemsMap == null || itemsMap.isEmpty()) {
            return ArrayUtils.EMPTY_STRING_ARRAY;
        }

        return itemsMap.keySet().toArray(ArrayUtils.EMPTY_STRING_ARRAY);
    }


    /**
     * Returns a map of all given resources mapping their name to their {@link ComponentExporter component exporter}
     * model.
     */
    public static Map<String, ComponentExporter> getComponentExporters(Iterator<Resource> resourceIterator,
                                                                       ModelFactory modelFactory,
                                                                       SlingHttpServletRequest slingHttpServletRequest) {
        final Map<String, ComponentExporter> componentExporterMap = new LinkedHashMap<>();

        while (resourceIterator.hasNext()) {
            Resource resource = resourceIterator.next();
            ComponentExporter exporter =
                    modelFactory.getModelFromWrappedRequest(slingHttpServletRequest, resource, ComponentExporter.class);

            if (exporter != null) {
                String name = resource.getName();
                if (componentExporterMap.put(name, exporter) != null) {
                    throw new IllegalStateException(String.format("Duplicate key '%s'", name));
                }
            }
        }

        return componentExporterMap;
    }

    public static Map<String, String> parseSelectors(String[] selectorArray) {
        Map<String, String> selectorList = new HashMap<>();
        for (String selector : selectorArray) {
            if (selector.contains(":")) {
                String[] splits = selector.split(":");
                selectorList.put(splits[0], splits[1]);
            }
        }
        return selectorList;
    }

    public static Iterator<Resource> runQueryBuilder(String folderPath, QueryBuilder builder, Session session, Map<String, String> selectorList) {
        Map<String, Object> predicateMap = new LinkedHashMap<>();
        //predicate preparation to search pages
        predicateMap.put("type", "dam:Asset");
        predicateMap.put("path", folderPath);
        final int[] i = {1};
        selectorList.entrySet().stream().forEach(e -> {
            if (e.getValue().contains(",")) {
                int j = 1;
                String[] values = e.getValue().split(",");
                predicateMap.put(i[0] + "_property", "jcr:content/data/master/".concat(e.getKey()));
                for (String val : values) {
                    predicateMap.put(i[0] + "_property." + j + "_value", val);
                    j++;
                }
            } else {
                predicateMap.put(i[0] + "_property", "jcr:content/data/master/".concat(e.getKey()));
                predicateMap.put(i[0] + "_property.value", e.getValue());
            }
            i[0]++;
        });

        predicateMap.put("p.limit", "-1");
        //Query preparation
        Query query = builder.createQuery(PredicateGroup.create(predicateMap), session);
        SearchResult searchResult = query.getResult();
        return searchResult.getResources();
    }

    public static <T> Iterable<T> convertToIterableFromIterator(Iterator<T> iterator) {
        return () -> iterator;
    }
}
