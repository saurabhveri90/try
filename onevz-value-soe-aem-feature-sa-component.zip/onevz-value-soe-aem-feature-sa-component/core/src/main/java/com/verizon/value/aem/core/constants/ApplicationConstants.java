/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.verizon.value.aem.core.constants;

import com.adobe.aemds.guide.utils.JcrResourceConstants;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.wcm.api.NameConstants;
import com.adobe.aemds.guide.utils.GuideConstants;

/**
 * Constants used across the application.
 */
public final class ApplicationConstants {

	 public static final String HTML_EXTENSION = ".html";

	 public static final Float INTEGER_ONE = 1.0f;

	public static final Integer INTEGER_SIX = 6;
	
	public static final Integer INTEGER_THREE = 3;

	public static final Integer INTEGER_TEN = 10;

      public static final int INTEGER_TWO = 2;
	 
	 public static final String INTERNAL_LINK_PATH = "/content/";
     
     public static final String SLASH = "/";
     
     public static final String DOUBLE_SLASH = "//";
     
     public static final String DOUBLE_SLASH_DOT = " \\.";
     
     public static final String COLON = ":";
     
	 public static final String SEMICOLON = ";";
	  
     public static final String COMMA = ",";
	 
	 public static final String FALSE = "false";
	 
	 public static final String TARGET_BLANK = "_blank";
		
	 public static final String TARGET_SELF = "_self";
	 
	 public static final String YES = "yes";
	 
	 public static final String NO = "no";
	 
	 public static final String NO_INDEX = "noindex";
	 
	 public static final String INDEX = "index";
	 
	 public static final String NO_FOLLOW = "nofollow";
	 
	 public static final String FOLLOW = "follow";
	 
	 public static final String NO_IMAGE_INDEX = "noimageindex";
	 
	 public static final String NO_ARCHIVE = "noarchive";
	 
	public static final String NO_CACHE = "nocache";
			 
	public static final String NO_SNIPPET = "nosnippet";
	
	public static final String SEO_TITLE = "seoTitle";
	
	public static final String SEO_DESCRIPTION = "seoDescription";
	
	public static final String PIPE_WITH_SPACES = " | ";
	
	public static final String COMMA_AND_SPACE = ", ";
	
	public static final String JCR_CONTENT_IMAGE = "/jcr:content/image";
	
	public static final String  FILEREFERENCE = "fileReference";
	public static final String  CATEGORYTYPE = "categorytype";
	
	 public static final String UNDERSCORE = "_";
	 
	 public static final String SPACE = " ";

	public static final String SPACE_REGEX = "\\s{1,}";
	
	public static final String ALL_SPECIAL_CHAR_REGEX = "[^A-Za-z0-9]+";
	 
	 public static final String LANGUAGE_MASTERS= "language-masters";
	 
	 public static final String COUNTRY_US= "us";
	 public static final String OPTIONS = "options";
	 public static final String TILDA = "~";
	 public static final String HASH = "#";
	 public static final String EQUAL = "=";
	 
	 //SEO
	 public static final String HYPHEN = "-";
	 public static final String BLANK_SPACE = " ";
	 public static final String DOT = ".";
	 public static final int TWITTER_TITLE_LIMIT = 70;
	 public static final int TWITTER_DESC_LIMIT = 200;
	 public static final int META_TITLE_LIMIT = 70;
	 public static final int META_DESC_LIMIT = 158;
	 public static final String JCRCONTENT =  JcrConstants.JCR_CONTENT;
	 public static final String DO_NOT_FOLLOW_LINK =  "donotfollowlink";
	 public static final String TRUE =  "true";
	 public static final String JCR_CONTENT_SOCIAL_ACCOUNT = "/jcr:content/socialAccount";
	 public static final String RESOURCE_TYPE = JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY;
	 public static final String SEO_BRAND_NAME = "seoBrandName";
	 	 
	 public static final int TOTAL_COL = 12;
	 public static final String COLUMN_XL = "col-xl-";
	 public static final String COLUMN_L = "col-lg-";
	 public static final String COLUMN_M = "col-md-";
	 public static final String COLUMN_S = "col-sm-";
	 public static final String COLUMN = "col-";
	 
	public static final String URL_PROTOCOL_HTTP = GuideConstants.PROTOCOL_HTTP;
	public static final String URL_PROTOCOL_HTTPS = GuideConstants.PROTOCOL_HTTPS;
	public static final String PATH_DAM = "/content/dam";
	public static final String ERROR_CODE_404 = "404";
	public static final String URL_PROTOCOL_POST = "POST";
	public static final String URL_PROTOCOL_PUT = "PUT";
	
	public static final String QUESTION_MARK = "?";
	public static final String COLON_SLASHES = "://";
	
	// Multilink constants
	public static final String MULTI_LINKS = "multilinks";
	public static final String LINK_TEXT = "linktext";
	public static final String LINK_DESCRIPTION = "linkdescription";
	public static final String LINK_ALT_TEXT = "linkalttext";
	public static final String LINK_URL = "linkurl";
	public static final String ICON = "icon";
	public static final String LINK_URL_TARGET = "linkurltarget";
	public static final String SHOW_LINK_TEXT = "showLinkText";
	public static final String SHOW_LINK_TEXT_ICON_SAME_LINE = "showLinkTextAndIconSameLine";
	public static final String EVENT_NAME = "eventName";
	public static final String CTA_TYPE = "ctaType";
	//Multiline plan list constants
	public static final String FEATURES = "features";	
	public static final String FEATURE_TITLE = "featureTitle";
	public static final String FEATURE_DESCRIPTION = "featureDescription";
	public static final String FEATURE_LOGO = "featureLogo";
	//Hero Carousel
	public static final String backgroundImageAlign ="backgroundImageAlign";
	public static final String slideHeading = "slideHeading";
	public static final String slideCtaAlignment = "slideCtaAlignment";
	public static final String slideSubHeading = "slideSubHeading";
	public static final String backgroundImageForSlide = "backgroundImageForSlide";
	public static final String backgroundImageAlt = "backgroundImageAlt";
	public static final String tooltipLogo = "tooltipLogo";
	public static final String tooltipMsg = "tooltipMsg";

	// Column control constants
	public static final String COLUMNS = "columns";		
	public static final String WIDTH = "columnwidth";

	//carousel
	public static final int TOTAL_DEFAULT_ITEMS_CAROUSEL = 2;
	
	// Video data type
	public static final String VIDEO_DATA_TYPE = "video/mp4";
	public static final String IMAGE = "image";
	public static final String MOBILE_IMAGE = "mobileimage";
	public static final String VIDEO = "video";
	public static final String BG_SMART_CROP = "bgsmartcrop";
	public static final String MOBILE_VERSION ="mobileVersion";
	public static final String TRAILING_ZERO ="0.#";
	
	//Animation
	public static final String POINT_SIX = ".6s";
	public static final String POINT_THREE = ".3s";

	//Breadcrumb 
	public static final String BREADCRUMB_TITLE = "breadcrumbTitle";
	public static final String PAGE_NO_FOLLOW = "noFollow";
	public static final String HIDE_IN_BREADCRUMB = "hideInBreadcrumb";

	public static final String WEBER_ID = "weberId";
	public static final String JCR_CONTENT_METADATA = "/jcr:content/metadata";
	//detail-features
	public static final String HEADING = "heading";
	
	public static final String SVG_EXTENSION = ".svg";
	
	public static final String MODAL = "modal";
	
	/*Checkout Detail constants*/
	public static final String SHIPPING_METHODS = "shippingMethods";
	public static final String CHECKOUT_STEPS = "checkoutSteps";
	public static final String PAYMENT_OPTIONS = "paymentOptions";
	public static final String CREDIT_CARD_VENDORS = "creditCardVendors";
	public static final String TRADE_IN_OPTIONS = "tradeInOptions";
	public static final String COMMUNICATION_ITEMS="communicationItems";
	public static final String APPS_CARDS="appsCards";
	public static final String COMMUNICATION_PREFERENCES="communicationPreferences";
	public static final String ACCOUNT_NAVIGATION_ITEMS="accountNavigationItems";
	public static final String SOCIAL_MEDIA_ACCOUNTS="socialMediaAccounts";
	public static final String DEAL_CARDS="dealCards";
	public static final String PROMO_CARDS="promoCards";
	public static final String EARN_MORE_WAYS_CARD_DETAILS="earnMoreWaysCardDetails";
	public static final String SPECS_OPTIONS = "specsoptions";
	public static final String TRANSACTION_FLOW_CHECKOUT_MAPPING = "transactionFlowCheckoutMapping";
	public static final String ACTIVATION_SUPPORT_KIT_OPTIONS = "activationSupportKitOptions";
	public static final String ACTIVATION_SUPPORT_KIT_OPTION = "activationSupportKitOption";
	
	
	public static final String ADD_MERGE_LINE_OPTIONS="addMergeLineOptions";
	public static final String ADD_NEW_LINE_OPTIONS="addNewLineOptions";
	public static final String ADD_NEW_DEVICE_OPTIONS="addNewDeviceOptions";
	public static final String PLAN_AUTO_REFILL_MESSAGE_MAPPING="planAutoRefillMessageMapping";
	public static final String NOTIFICATION_CARDS="notificationCards";
	public static final String STATUS_PENDING_TRANSACTION_LIST="statusPendingTransactionList";
	public static final String BENEFIT_CHANGE_OPTIONS_PLAN="benefitChangeOptionsForPlan";
	public static final String BENEFIT_CHANGE_OPTIONS_ILD="benefitChangeOptionsForILD";
	public static final String BENEFIT_CHANGE_OPTIONS_RESERVE_PLANS="benefitChangeOptionsForReservePlans";
	public static final String WELCOME_CENTER_PART_CLASSESS="welcomeCenterPartClasses";
	public static final String DEENROLLMENT_REASONS="deEnrollmentReasons";
	
	
	public static final String CHECKOUT_STEP = "checkoutStep";
	public static final String DEENROLLMENT_REASON = "deEnrollmentReason";
	public static final String DEENROLLMENT_REASON_TEXT = "deEnrollmentReasonText";
	public static final String TRADE_IN_OPTION = "tradeInOption";
	
	public static final String SHIPPING_METHOD_ID = "shippingMethodId";
	public static final String SHIPPING_METHOD_NAME = "shippingMethodName";
	public static final String SHIPPING_CHARGE = "shippingCharge";
	public static final String DELIVERY_RANGE = "deliveryRange";
	public static final String DELIVERY_MIN_DAYS = "deliveryMinDays";
	public static final String DELIVERY_MAX_DAYS = "deliveryMaxDays"; 
	public static final String SHIPPING_VENDOR_LOGO = "shippingVendorLogo";
	public static final String SHIPPING_VENDOR_LOGO_ALT_TEXT = "shippingVendorLogoAltText";
	
	public static final String PAYMENT_OPTION_ID = "paymentOptionId";
	public static final String PAYMENT_OPTION_NAME = "paymentOptionName";
	public static final String PAYMENT_OPTION_LOGO = "paymentOptionLogo";
	public static final String PAYMENT_OPTION_LOGO_ALT_TEXT = "paymentOptionLogoAltText";
	
	public static final String CREDIT_CARD_VENDOR_NAME = "creditCardVendorName";
	public static final String CREDIT_CARD_VENDOR_LOGO = "creditCardVendorLogo";
	public static final String CREDIT_CARD_VENDOR_LOGO_ALT_TEXT = "creditCardVendorLogoAltText";
	
	
	public static final String PURCHASE_SCENARIOS = "purchaseScenarios";

	public static final String ST_PURCHASE_SCENARIOS = "stpurchaseScenarios";
	
	public static final String CATEGORY_ID="categoryId";

	public static final String  ACCESSORY_EDIT_URL = "accessoryEditUrl";

	public static final String  WATCH_EDIT_URL = "watchEditUrl";
	public static final String  FALLBACK_THUMBNAIL_IMAGE = "defaultFallbackThumbnailImage";
		
	public static final String AGENCY_ID_DEFAULT_SCRIPTING_KEY = "_LBL_DEFAULT_AGENCY_ID";
	public static final String  CQ_TEMPLATE = NameConstants.NN_TEMPLATE;	
	
	public static final String  FETCH_SELECTOR ="fetch";
	public static final String  CREATE_SELECTOR ="create";
	public static final String  DELETE_SELECTOR ="delete";
	public static final String  UPDATE_SELECTOR ="update";
	
	public static final String ANDROID = "android";
	public static final String IOS = "ios";
	public static final String OPERATING_SYSTEM = "os";
	public static final String APPLE = "apple";
	public static final String PAGE_CONTENT = "cq:PageContent";
	
	public static final String LEARN_MORE = "Learn More";
	public static final String BUY_NOW_SCRIPTING_KEY = "_LBL_BUY_NOW";
	public static final String REDEEM_REWARDS_POINTS = "#redeemRewardPoints";
	public static final String MY_ACCOUNT_PATH_LOGIN_REDIRECTION ="myAccountPageForLoginRedirection";
	public static final String LOGIN_PATH_REDIRECTION ="loginEmailXfPath";
	public static final String MY_ACCOUNT_DASHBOARD_PATH ="myAccountDashboardPagePath";
	public static final String MY_ACCOUNT_LOGOUT_REDIRECT_PATH ="pageForMyAccountLogoutRedirection";
	
	public static final String DEFAULT_DYNAMIC_MEDIA_QUERY_STRING = "?wid=400&hei=400&fmt=png-alpha&qlt=80,0&resMode=sharp2&op_usm=1.75,0.3,2,0";

	public static final String DYNAMIC_VAS_LIST="dynamicVasList";
	
	public static final String ZERO ="0";
	public static final String DECIMAL_ZERO ="0.00";
	public static final String POINT_ZERO =".00";

	public static final int ONE_GB = 1024;
	public static final String UNIT_GB = "GB";
	public static final String UNIT_MB = "MB";
	public static final String ROW_COLS = "row-cols-";
	public static final String ROW_COLS_LG = "row-cols-lg-";
	
	//Constant for EXTENSIONS
	public static final String EXTENSION_JSON ="json";
	public static final String EXTENSION_HTML = "html";
	
	public static final String EX_PRICE_DURATION_DEFAULT_SCRIPTING_KEY = "_LBL_PER_MONTH";
	public static final String WEB_CORE_NODE = "web-core";
	public static final String STATUS = "status";
	public static final String SUCCESS = "success";
	public static final String MESSAGE = "message";
	
	public static final String PLAN_CARD_MAX_QUANTITY= "planCardMaxQuantity";
	public static final String CREATE_JSON = "createjson";
	
	public static final String SLASH_JCR_CONTENT= "/jcr:content";

	public static final String VAS_PRODUCTS_LIST="vasProducts";

	public static final String CARD_TITLE="cardtitle";

	public static final String COMPATIBILITYCARDS="compatibilitycards";

	public static final String SHOWCARD="showcard";

	public static final String CARDCONTENT="cardcontent";

	public static final String CARDBUTTONLABEL="cardbuttonlabel";

	public static final String CARDBUTTONLINK="cardbuttonlink";

	public static final String CARDIMAGE="cardimage";

	public static final String CARDEVENT="cardevent";

	public static final String SIMNOTCOMPATIBILITYBUTTONS="simnotcompatibilitybuttons";

	public static final String DEVICENOTCOMPATIBILITYBUTTONS="devicenotcompatibilitybuttons";
	
	public static final String SHOWBUTTON="showbutton";

	public static final String BUTTONLABEL="buttonlabel";

	public static final String BUTTONLINK="buttonlink";

	public static final String CHECKEVENT="checkevent";

	public static final String ACTIVEBUTTONS="activebuttons";

    public static String sliderBgType="sliderBgType";

	public static String sliderBackgroundImage="sliderBackgroundImage";
	public static String sliderBackgroundColor="sliderBackgroundColor";

	public static String PLAN_DISCLAIMER_CTA_LINK = "disclaimerCTALink";
 	public static String PLAN_DISCLAIMER_CTA_TEXT = "disclaimerCTALabel";
	public static String PLAN_DISCLAIMER_CTA_ARIA_TEXT = "disclaimerAccessibilityText";

	public static String READMORE_DISCLAIMER_CTA_LINK = "readmoreCTALink";
	public static String READMORE_DISCLAIMER_CTA_TEXT = "readmoreCTALabel";
	public static String READMORE_DISCLAIMER_CTA_ARIA_TEXT = "readmoreAccessibilityText";
	
	


	/**
     * The Private Constructor.
     */
    private ApplicationConstants() {
    }

}
