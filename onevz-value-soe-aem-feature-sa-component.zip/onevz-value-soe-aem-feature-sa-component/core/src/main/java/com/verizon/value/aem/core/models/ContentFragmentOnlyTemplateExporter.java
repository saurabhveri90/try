package com.verizon.value.aem.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ContainerExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.adobe.cq.xf.ExperienceFragmentsConstants;
import com.day.cq.wcm.api.Page;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.*;

@Model(adaptables = SlingHttpServletRequest.class,
        adapters = {ContentFragmentOnlyTemplateExporter.class, ContainerExporter.class},
        resourceType = ContentFragmentOnlyTemplateExporter.RESOURCE_TYPE)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION)
public class ContentFragmentOnlyTemplateExporter implements ContainerExporter {

    protected static final String RESOURCE_TYPE = "visible-aem/components/structure/cf-page";
    private static final Logger log = LoggerFactory.getLogger(ContentFragmentOnlyTemplateExporter.class);
    @ScriptVariable
    protected Page currentPage;
    @Self
    private SlingHttpServletRequest slingRequest;

    @Inject
    private Resource resource;

    @Inject
    private SlingModelFilter slingModelFilter;

    @Inject
    private ModelFactory modelFactory;

    private Map<String, Object> childModels = null;

    @Nonnull
    @Override
    @JsonIgnore
    public Map<String, ? extends ComponentExporter> getExportedItems() {
        return new HashMap<>();
    }

    @JsonAnyGetter
    public Map<String, Object> getCustomExportedItems() {
        return childModels;
    }

    @Nonnull
    @Override
    @JsonIgnore
    public String[] getExportedItemsOrder() {
        return new String[0];
    }

    @Nonnull
    @Override
    @JsonIgnore
    public String getExportedType() {
        return resource.getResourceType();
    }

    @PostConstruct
    private void initModel() {
        if (childModels == null) {
            childModels = getChildComponents();
        }
    }

    private Map<String, Object> getChildComponents() {
        Map<String, Object> itemWrappers = new LinkedHashMap<>();
        List<Object> cfmList = new LinkedList<>();
        List<String> itemNames = new LinkedList<>();

        Resource compParentRes = resource.getChild("root/responsivegrid");
        if (compParentRes == null) {
            return itemWrappers;
        }

        Iterable<Resource> iterable = slingModelFilter.filterChildResources(compParentRes.getChildren());

        if (iterable == null) {
            return itemWrappers;
        }

        iterable.forEach(child -> {
            String itemName = getCompName(child, itemNames);
            Object childCompExporter = modelFactory
                    .getModelFromWrappedRequest(slingRequest, child, ComponentExporter.class);

            if (childCompExporter instanceof ContentFragmentListExporter) {
                try {
                    String childAttVale = ((ContentFragmentListExporter) childCompExporter).childAttVale;
                    updateWrapperItems(childCompExporter, childAttVale, itemWrappers, itemName);
                } catch (Exception e) {
                    log.error("Exception while setting the child Object Name {}", e.getMessage());
                }
            } else if (childCompExporter instanceof ContentFragmentExporter) {
                cfmList.add(childCompExporter);
            } else if (childCompExporter instanceof ContentFragmentMultiExporter) {
                itemWrappers.put(itemName, childCompExporter);
            } else {
                log.error("Unknown component used in page {}", currentPage.getPath());
            }
        });
        if (CollectionUtils.isNotEmpty(cfmList)) {
            itemWrappers.put("itemsList", cfmList);
        }

        return itemWrappers;
    }

    private void updateWrapperItems(Object childCompExporter, String childAttVale, Map<String, Object> itemWrappers, String itemName) {
        if (((ContentFragmentListExporter) childCompExporter).requireChildObjName && ((ContentFragmentListExporter) childCompExporter).getListItems().get(0).containsKey(childAttVale) ) {
            Map<String, Object> nestedWrapper = new LinkedHashMap<>();
            for (int i = 0; i < ((ContentFragmentListExporter) childCompExporter).getListItems().size(); i++) {
                if (((ContentFragmentListExporter) childCompExporter).getListItems().get(i).get(childAttVale) != "nothing" &&
                        ((ContentFragmentListExporter) childCompExporter).getListItems().get(i).get(childAttVale) != "") {
                    nestedWrapper.put(((ContentFragmentListExporter) childCompExporter).getListItems().get(i).get(childAttVale).toString()
                            , ((ContentFragmentListExporter) childCompExporter).getListItems().get(i));
                }
            }
            itemWrappers.put(itemName, nestedWrapper);
        } else {
            itemWrappers.put(itemName, childCompExporter);
        }
    }

    private String getCompName(final Resource compRes, List<String> itemNames) {
        String compName = null;
        try {
            ValueMap properties = compRes.getValueMap();
            String cfmAttributeName = properties.get("cfmAttributeName", String.class);
            String fragmentPath = properties.get(ExperienceFragmentsConstants.PN_FRAGMENT_PATH, String.class);

            if (StringUtils.isNotBlank(cfmAttributeName)) {
                compName = StringUtils.trim(cfmAttributeName);
            }
            if (StringUtils.isBlank(compName) && StringUtils.isNotBlank(fragmentPath)) {
                String cfmName = StringUtils.substringAfterLast(fragmentPath, "/");
                if (StringUtils.isNoneBlank(cfmName)) {
                    compName = cfmName;
                }
            }
        } catch (Exception ex) {
            log.error("Error while fetching component name", ex);
        }
        if (StringUtils.isBlank(compName)) {
            compName = compRes.getName();
        }
        if (itemNames.contains(compName)) {
            compName = compName + "-r-" + itemNames.size();
        }
        itemNames.add(compName);
        return compName;
    }
}
