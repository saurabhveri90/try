package com.verizon.value.aem.core.services;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@Component(service = PreConnectOSGIConfigService.class, immediate = true)
@Designate(ocd = PreConnectOSGIConfigServiceImpl.Config.class)
public class PreConnectOSGIConfigServiceImpl implements PreConnectOSGIConfigService{

    private String[] preConnectPaths;
    private String[] dnsPrefetchPaths;

    @ObjectClassDefinition(name = "Pre-Connect Paths Config", description = "Pre-Connect Paths Config")
    public @interface Config {

        @AttributeDefinition(name = "Pre-Connect Paths", description = "Provide Pre-Connect Paths")
        String[] getPreConnectPaths() default {"https://fonts.googleapis.com/","https://www.lightboxcdn.com/","https://www.gstatic.com/","https://s.pinimg.com/","https://sc-static.net/"};

        @AttributeDefinition(name = "DNS Pre-Fetch Paths", description = "Provide DNS Pre-Fetch Paths")
        String[] getDNSPrefetchPaths() default {"https://fonts.googleapis.com/","https://www.lightboxcdn.com/","https://www.gstatic.com/","https://s.pinimg.com/","https://sc-static.net/"};
    }

    @Activate
    @Modified
    protected void activate(final Config configuration){
        preConnectPaths = configuration.getPreConnectPaths();
        dnsPrefetchPaths = configuration.getDNSPrefetchPaths();
    }

    @Override
    public String[] getPreConnectPaths() {
        return preConnectPaths;
    }
    @Override
    public String[] getDNSPrefetchPaths() {
        return dnsPrefetchPaths;
    }

}
