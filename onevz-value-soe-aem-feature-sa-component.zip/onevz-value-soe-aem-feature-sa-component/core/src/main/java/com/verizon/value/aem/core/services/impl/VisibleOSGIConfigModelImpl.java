package com.verizon.value.aem.core.services.impl;

import com.verizon.value.aem.core.models.VisibleOSGIConfigModel;
import com.verizon.value.aem.core.services.VisibleOSGIService;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = {SlingHttpServletRequest.class, Resource.class}, adapters = VisibleOSGIConfigModel.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class VisibleOSGIConfigModelImpl implements VisibleOSGIConfigModel {

    protected  final Logger Log = LoggerFactory.getLogger(this.getClass());

    @OSGiService
    private VisibleOSGIService visibleConfigService;

    @Override
    public String getDomain() {
        return visibleConfigService.getDomain();
    }

    public String getUtag() {
        return visibleConfigService.getUtag();
    }

    @Override
    public String getAffirmScriptUrl() { return visibleConfigService.getAffirmScriptUrl(); }

    @Override
    public String getAffirmApiKey() { return visibleConfigService.getAffirmApiKey();}
    @Override
    public String getChatUrl() { return visibleConfigService.getChatUrl(); }

    @Override
    public String getApiUrl() { return visibleConfigService.getApiUrl(); }

    @Override
    public String getProductsUrl() { return visibleConfigService.getProductsUrl(); }

    @Override
    public String getSaveSignal() { return visibleConfigService.getSaveSignal(); }

    @Override
    public String getSearchTa() { return visibleConfigService.getSearchTa(); }

    @Override
    public String getAppConfig() { return visibleConfigService.getAppConfig(); }

    @Override
    public String getEnablePrechatForm() { return visibleConfigService.getEnablePrechatForm(); }

    @Override
    public String getClearCartUrl() { return visibleConfigService.getClearCartUrl(); }

    @Override
    public String getIsProd() { return visibleConfigService.getIsProd(); }

    @Override
    public String getAirgapJsUrl() { return visibleConfigService.getAirgapJsUrl(); }

    @Override
    public String getQmNwInterceptOrUrl() {return visibleConfigService.getQmNwInterceptOrUrl();}

    @Override
    public String getPortabilityApiUrl() {
        return visibleConfigService.getPortabilityApiUrl();
    }
}
