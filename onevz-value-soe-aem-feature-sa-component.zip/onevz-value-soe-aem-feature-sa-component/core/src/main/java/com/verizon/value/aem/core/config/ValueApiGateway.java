package com.verizon.value.aem.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Value API Gateway Service", description = "Paths for Value Api Gateway are added here")
public @interface ValueApiGateway {

	@AttributeDefinition(name = "Value API Gateway", description = "Configuration for Value API Gateway", type = AttributeType.STRING)
	String getApiUrl() default "https://dit-apigateway.tracfone.com/api/dit";

	@AttributeDefinition(name = "Value API Domain", description = "Configuration for Value API Domain", type = AttributeType.STRING)
	String getApiDomain() default "https://sit-apigateway.tracfone.com/api/sitf";

	@AttributeDefinition(name = "Value Aoi Environment", description = "Configuration for Value API Environment", type = AttributeType.STRING)
	String getApiEnvironment() default "";

	@AttributeDefinition(name = "API ClientId", description = "Configuration for API ClientId", type = AttributeType.STRING)
	String[] getApiClientId() default { "STRAIGHT_TALK:15a86354-7c65-46f0-ac3a-f0cc63b5219c",
			"TRACFONE:7db825bf-58e5-4338-b01c-731755272735" };

	@AttributeDefinition(name = "Gridwall Endpoint", description = "Configuration for Gridwall Endpoint", type = AttributeType.STRING)
	String getGridwallEndpoint() default "";

}
