package com.verizon.value.aem.core.models;

public interface VisibleOSGIConfigModel {

    public String getDomain();

    public String getUtag();

    public String getAffirmScriptUrl();

    public String getAffirmApiKey();

    public String getChatUrl();

    public String getApiUrl();

    public String getProductsUrl();

    public String getSaveSignal();

    public String getSearchTa();

    public String getAppConfig();

    public String getEnablePrechatForm();

    public String getClearCartUrl();

    public String getIsProd();

    public String getAirgapJsUrl();

    public String getQmNwInterceptOrUrl();

    public String getPortabilityApiUrl();
};
