package com.verizon.value.aem.core.services;

public interface ValueApiGatewayService {

	String getApiUrl();

	String getApiDomain();

	String getApiEnvironment();

	String[] getApiClientId();

	String getGridwallEndpoint();

}
