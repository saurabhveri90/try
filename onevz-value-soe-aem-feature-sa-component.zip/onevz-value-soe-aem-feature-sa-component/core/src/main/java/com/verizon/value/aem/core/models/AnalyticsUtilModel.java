/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.verizon.value.aem.core.models;

public interface  AnalyticsUtilModel {


	/**
	 * <p>
	 * Fetches ctaAnalyticText
	 * </p>
	 *
	 * @return String - ctaAnalyticText
	 */
	public String getCtaAnalyticText();
	/**
	 * <p>
	 * Fetches placementText
	 * </p>
	 *
	 * @return String - placementText
	 */
	public String getPlacementText();
	
}