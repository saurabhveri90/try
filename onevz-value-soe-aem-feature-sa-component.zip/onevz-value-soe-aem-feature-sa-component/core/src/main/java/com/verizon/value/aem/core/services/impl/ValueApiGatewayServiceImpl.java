package com.verizon.value.aem.core.services.impl;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.metatype.annotations.Designate;

import com.verizon.value.aem.core.config.ValueApiGateway;
import com.verizon.value.aem.core.services.ValueApiGatewayService;

@Component(service = ValueApiGatewayService.class, immediate = true)
@Designate(ocd = ValueApiGateway.class)
public class ValueApiGatewayServiceImpl implements ValueApiGatewayService {

	private ValueApiGateway config;

	@Activate

	public void activate(ValueApiGateway config) {
		this.config = config;
	}

	@Override
	public String getApiUrl() {
		return this.config.getApiUrl();
	}

	@Override
	public String getApiDomain() {
		return this.config.getApiDomain();
	}

	@Override
	public String getApiEnvironment() {
		return this.config.getApiEnvironment();
	}

	@Override
	public String[] getApiClientId() {
		return this.config.getApiClientId();
	}

	@Override
	public String getGridwallEndpoint() {
		return this.config.getGridwallEndpoint();
	}

}
