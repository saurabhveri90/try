package com.verizon.value.aem.core.models;

import com.adobe.cq.dam.cfm.converter.ContentTypeConverter;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonValue;
import com.verizon.value.aem.core.utils.BaseExporter;
import com.verizon.value.aem.core.utils.ContentFragmentExporterUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.List;
import java.util.Map;

@Component
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = {ComponentExporter.class},
        resourceType = ContentFragmentExporter.RESOURCE_TYPE,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class ContentFragmentExporter extends BaseExporter implements ComponentExporter {

    public static final String RESOURCE_TYPE = "onevz-value-aem/components/content/contentfragment";
    private static final Logger log = LoggerFactory.getLogger(ContentFragmentExporter.class);
    protected boolean requireChildObjName = false;
    protected String childAttValue = "";

    @SlingObject
    protected SlingHttpServletRequest cfExporterRequest;

    @Inject
    ContentTypeConverter contentTypeConverter;

    @Inject
    private Resource cfExporterResource;

    @SlingObject
    ResourceResolver resourceResolver;

    @ValueMapValue
    String fragmentPath;

    @ValueMapValue
    private String nestedJson;

    @ValueMapValue
    private String childObjectName;

    @ValueMapValue
    private String[] elementNames;

    @ValueMapValue
    private String variationName;

    @ValueMapValue
    private String displayMode;

    private Map<String, Object> content = null;
    private List<DAMContentFragment.DAMContentElement> elements;

    @PostConstruct
    void initModel() {
        if (nestedJson == null) {
            nestedJson = "false";
        }
        if (StringUtils.isNotEmpty(fragmentPath)) {
            try {
                Resource fragmentResource = resourceResolver.getResource(fragmentPath);
                getContentFragmentResources(fragmentResource);
            } catch (Exception ex) {
                log.error("Error while fetching Fragment Path Info for {}", fragmentPath, ex);
            }
        }
    }

    private void getContentFragmentResources(Resource fragmentResource) {
        Map<String, DAMContentFragment.DAMContentElement> exportedElements;
        if (fragmentResource != null) {
            exportedElements = ContentFragmentExporterUtils.getExportedElements(fragmentResource, elementNames, variationName, contentTypeConverter);
            if (childObjectName != null) {
                try {
                    if (exportedElements.containsKey(childObjectName) &&
                            (exportedElements.get(childObjectName) != null)) {
                        requireChildObjName = true;
                        childAttValue = exportedElements.get(childObjectName).getValue().toString();

                    }
                } catch (Exception e) {
                    log.error("Exception at getting the child object attr name {}", e.getMessage());
                }
            }
            content = ContentFragmentExporterUtils.generateContent(exportedElements, nestedJson, resourceResolver);
        } else {
            log.error("Fragment path {} not resolved", fragmentPath);
        }
    }

    @Override
    @JsonIgnore
    @Nonnull
    public String getExportedType() {
        return "";
    }

    @JsonValue
    public Map<String, Object> getContent() {
        return content;
    }

    @JsonIgnore
    public List<DAMContentFragment.DAMContentElement> getElements() {
        return elements;
    }

    @JsonIgnore
    public String getFragmentPath() {
        return fragmentPath;
    }
}
