/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.verizon.value.aem.core.models.impl;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.via.ResourceSuperType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.wcm.core.components.models.Button;
import com.verizon.value.aem.core.constants.ApplicationConstants;
import com.verizon.value.aem.core.models.ButtonModel;
import com.verizon.value.aem.core.utils.ApplicationUtil;

@Model(adaptables = SlingHttpServletRequest.class, 
	adapters = {ButtonModel.class,ComponentExporter.class},
    resourceType = "value-aem/components/core/content/button", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ButtonModelImpl implements ButtonModel {

    @Self @Via(type = ResourceSuperType.class)
    private Button button;

    @Self
    private SlingHttpServletRequest request;
    
    @ValueMapValue
    private String ctaType;
    
    @ValueMapValue
    private String modalID;
    
    @ValueMapValue
    private String eventName;
    
    @ValueMapValue
    private String modalName;

    @ValueMapValue @Default(booleanValues = false)
    private Boolean target;

    @ValueMapValue
    private String donotfollowlink;
    
    @ValueMapValue
    private String placementText;
    
    @ValueMapValue
    private String btnPlacementText;
    
    @ValueMapValue
    private String eventLink;
    
    @ValueMapValue @Default(booleanValues = false)
    private Boolean useAsHyperlink;

    @ValueMapValue
    private String chatnowContainerId;

    @ValueMapValue
    private String multiPlanSelection;

	private static final Logger LOGGER = LoggerFactory.getLogger(ButtonModelImpl.class);
	private static final String ENTER_MODAL_NAME = "enterModalName";

    @PostConstruct
    private void initModel() {
        LOGGER.debug("Entering initModel method");
            if (donotfollowlink != null) {
                donotfollowlink = ApplicationUtil.getNoFollow(donotfollowlink);
            } else
                donotfollowlink = ApplicationUtil.getNoFollow(null);
        LOGGER.debug("Exiting initModel method");
    }

    /**
     * <p>Fetches text of the button</p>
     *
     * @return String - text of the button
     */
    @Override
    public String getText() {
        return button.getText();
    }

    /**
     * <p>Fetches link of the button</p>
     *
     * @return String - link of the button
     */
    @Override
    public String getLink() {
        return button.getLink();
    }

    /**
     * <p>Fetches accessibility label of the button</p>
     *
     * @return String - accessibility label of the button
     */
    @Override
    public String getAccessibilityLabel() {
        return button.getAccessibilityLabel();
    }

    /**
     * <p>Fetches target value of the button</p>
     *
     * @return String - target value of the button
     */
    @Override
    public String getTarget() {
        String tragetValue;
        if(target != null && target){
            tragetValue = ApplicationConstants.TARGET_BLANK;
        }else{
            tragetValue = ApplicationConstants.TARGET_SELF;
        }
        //return (!target ? ApplicationConstants.TARGET_SELF : ApplicationConstants.TARGET_BLANK);
    return tragetValue;
    }

    /**
     * <p>Fetches do not follow value of the button</p>
     *
     * @return String - do not follow value of the button
     */
    @Override
    public String getDonotfollowlink() {
        return donotfollowlink;
    }
    
    @Override
    public String getPlacementText() {
		return placementText;
	}
    
    @Override
    public String getBtnPlacementText() {
    	return btnPlacementText;
    }

	@Override
	public String getCtaType() {	
		return this.ctaType;
	}

	@Override
	public String getModalID() {
		return StringUtils.equalsIgnoreCase(this.modalID, ENTER_MODAL_NAME) ? (ApplicationConstants.HASH +
			ApplicationUtil.getLowerCaseWithHyphen(this.modalName) + ApplicationConstants.HYPHEN 
			+ ApplicationConstants.MODAL) : this.modalID;
	}
	
	 /**
	 * @return the eventName
	 */
	@Override
	public String getEventName() {
		return eventName;
	}

	/**
     * @return exportedType
     */
    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

	/**
	 *<p>Fetches eventLink</p>
	 *
	 * @return the eventLink
	 */
    @Override
	public String getEventLink() {
		return ApplicationUtil.getShortUrl(request.getResourceResolver(),eventLink);
	}

	/**
	 * @return the useAsHyperlink
	 */
    @Override
	public Boolean getUseAsHyperlink() {
		return useAsHyperlink;
	}

    @Override
    public String getChatnowContainerId() {
		return chatnowContainerId;
	}

    /**
	 * @return the multiPlanSelection
	 */
	@Override
	public String getMultiPlanSelection() {
		return multiPlanSelection;
	}
    
}