package com.verizon.value.aem.core.models;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Model(adaptables = {Resource.class, SlingHttpServletRequest.class}, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class Container {

    protected  final Logger Log = LoggerFactory.getLogger(this.getClass());
    @ValueMapValue
    private String desktopFileReference;

    @ValueMapValue
    private String tabletFileReference;

    @ValueMapValue
    private String mobileFileReference;

    @SlingObject
    private ResourceResolver resolver;


    public String getDesktopFileReference() {
        return desktopFileReference;
    }

    public String getTabletFileReference() {
        return tabletFileReference;
    }

    public String getMobileFileReference() {
        return mobileFileReference;
    }

}
