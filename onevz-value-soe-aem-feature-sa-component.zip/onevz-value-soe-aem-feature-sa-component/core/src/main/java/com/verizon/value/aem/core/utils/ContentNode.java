package com.verizon.value.aem.core.utils;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;

/**
 * Encapsulate data associated with Jcr content node.
 */
public class ContentNode {

	/**
	 * The Resource associated with the current jcr node.
	 */
	private final Resource resource;

	/**
	 * The resource resolver is available to the current request processing servlet
	 */
	private final ResourceResolver resolver;

	/**
	 * Jcr Properties of the resource associated with {@link ContentNode#resource}
	 */
	private final ValueMap valueMap;

	private ContentNode(Builder builder) {
		resource = builder.resource;
		resolver = builder.resolver;
		valueMap = builder.valueMap;
	}

	public static Builder newBuilder() {
		return new Builder();
	}

	public Resource getResource() {
		return resource;
	}

	public ResourceResolver getResolver() {
		return resolver;
	}

	public ValueMap getValueMap() {
		if (valueMap == null) {
			return ResourceUtil.getValueMap(getResource());
		}
		return valueMap;
	}

	/**
	 * {@code ContentNode} builder static inner class.
	 */
	public static final class Builder {
		private Resource resource;
		private ResourceResolver resolver;
		private ValueMap valueMap;

		private Builder() {
		}

		/**
		 * Sets the {@code resource} and returns a reference to this Builder so that the methods can be chained
		 * together.
		 *
		 * @param resource
		 *            the {@code resource} to set
		 * @return a reference to this Builder
		 */
		public Builder withResource(Resource resource) {
			this.resource = resource;
			return this;
		}

		/**
		 * Sets the {@code resolver} and returns a reference to this Builder so that the methods can be chained
		 * together.
		 *
		 * @param resolver
		 *            the {@code resolver} to set
		 * @return a reference to this Builder
		 */
		public Builder withResolver(ResourceResolver resolver) {
			this.resolver = resolver;
			return this;
		}

		/**
		 * Sets the {@code valueMap} and returns a reference to this Builder so that the methods can be chained
		 * together.
		 *
		 * @param valueMap
		 *            the {@code valueMap} to set
		 * @return a reference to this Builder
		 */
		public Builder withValueMap(ValueMap valueMap) {
			this.valueMap = valueMap;
			return this;
		}

		/**
		 * Returns a {@code ContentNode} built from the parameters previously set.
		 *
		 * @return a {@code ContentNode} built with parameters of this {@code ContentNode.Builder}
		 */
		public ContentNode build() {
			return new ContentNode(this);
		}
	}
}
