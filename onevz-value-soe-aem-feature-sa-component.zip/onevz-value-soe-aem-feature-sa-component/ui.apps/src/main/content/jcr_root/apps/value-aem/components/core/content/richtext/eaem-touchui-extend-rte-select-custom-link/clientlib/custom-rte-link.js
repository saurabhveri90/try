(function ($) {
    "use strict";
 
    var Class = window.Class,
        CUI = window.CUI,
        REL_FIELD = "rel",
        RTE_LINK_DIALOG = "rtelinkdialog";
 
    if(CUI.rte.ui.cui.CuiDialogHelper.eaemExtended){
        return;
    }

    var EAEMLinkBaseDialog = new Class({
        extend: CUI.rte.ui.cui.CQLinkBaseDialog,
 
        toString: "EAEMLinkBaseDialog",
 
        initialize: function(config) {
            this.superClass.initialize.call(this, config);
 
            this.$rteDialog = this.$container.find("[data-rte-dialog=link]");
 
            this.$rteDialog.find(".rte-dialog-columnContainer:last").before(getLinkRelOptionsHtml());

            this.$rteDialog.find(".rte-dialog-columnContainer:last").before(getLinkAccesibilityLabel());
        },
 
        dlgToModel: function() {
            this.superClass.dlgToModel.call(this);
            if(!(_.isEmpty(this.getFieldByType("acclbl").val()))){
                this.objToEdit.attributes["data-setacccessibility"] = "true";
                this.objToEdit.attributes["data-setacclabel"] = this.getFieldByType("acclbl").val();              
            }
 
            var relField = this.getFieldByType(REL_FIELD);
 
            if(_.isEmpty(relField)){
                return;
            }

            var relVal = relField.val();

            if (_.isEmpty(relVal) || this.getFieldByType("rel").val() == "link") {
                return;
            }

            if(this.getFieldByType("rel").val() == "modal or toast" || this.getFieldByType("rel").val() == "modal" || this.getFieldByType("rel").val() == "toast"){
                this.objToEdit.attributes["rel"] = relVal;
                this.objToEdit.attributes["class"] = "modal-tab add-role-btn";
                this.objToEdit.attributes["data-keyboard"] = "true";
                this.objToEdit.attributes["data-target"] =  this.objToEdit.href;
                this.objToEdit.attributes["data-toggle"] =  "modal";
                this.objToEdit.attributes["tabindex"] = "0";
                this.objToEdit.href="#";
                
                this.objToEdit.attributes["data-setctaanalytic"] = "true";
            }
        },
 
        dlgFromModel: function() {
            this.superClass.dlgFromModel.call(this);

            if(_.isEmpty(this.objToEdit.attributes)){
                return;
            }
 
            var relValue = this.objToEdit.attributes['rel'];

            if(_.isEmpty(relValue)){
                return;
            }
 
            var relSelect = this.$rteDialog.find("[data-type='rel']")[0];
 
            relSelect.items.getAll().forEach(function(elem) {
                elem.selected = (elem.value === relValue);
            });

        }
    });
 
    CUI.rte.ui.cui.CuiDialogHelper = new Class({
        extend: CUI.rte.ui.cui.CuiDialogHelper,
 
        toString: "EAEMCuiDialogHelper",
 
        instantiateDialog: function(dialogConfig) {
            var type = dialogConfig.type;
 
            if(type !== RTE_LINK_DIALOG){
                this.superClass.instantiateDialog.call(this, dialogConfig);
                return;
            }
 
            var $editable = $(this.editorKernel.getEditContext().root),
                $container = CUI.rte.UIUtils.getUIContainer($editable),
                dialog = new EAEMLinkBaseDialog();
 
            dialog.attach(dialogConfig, $container, this.editorKernel);
 
            return dialog;
        }
    });

    function getLinkRelOptionsHtml(){
        var html =  "<div class='rte-dialog-columnContainer'>" +
                    "<div class='rte-dialog-column'>" +
                    "<coral-select data-type='rel' placeholder='Type of \"<a> Tag\" '>";

        var options = ["link", "modal or toast"];
 
        _.each(options, function(option){
            html = html + getOptionHtml(option);
        });

        html = html + "</coral-select></div></div>";

        return html;
 
        function getOptionHtml(option){
            return "<coral-select-item>" + option + "</coral-select-item>"
        }
    }

    function getLinkAccesibilityLabel(){
        var html =  "<div class='rte-dialog-columnContainer'>" +
                  "<div class='rte-dialog-column'>" +
                  " <label> <input is='coral-textfield' class='coral3-Textfield' data-type='acclbl' placeholder='Accessibility Text' aria-invalid='false'> </label>";
         return html;
  }
 
    CUI.rte.ui.cui.CuiDialogHelper.eaemExtended = true;
})(jQuery);