function alignTiles(tilename) {
	const tiles = document.querySelectorAll(tilename);
	let maxHeight = 0;

	tiles.forEach(tile => {
		tile.style.height = 'auto';
		maxHeight = Math.max(maxHeight, tile.offsetHeight);
	});

	tiles.forEach(tile => {
		tile.style.height = `${maxHeight}px`;
	});
}