package com.verizon.value.aem.core.services;

public interface PreConnectOSGIConfigService {

    public String[] getPreConnectPaths();

    public String[] getDNSPrefetchPaths();

}
