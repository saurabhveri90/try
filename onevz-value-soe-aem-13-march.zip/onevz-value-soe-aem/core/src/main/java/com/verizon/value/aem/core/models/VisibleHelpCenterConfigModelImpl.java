package com.verizon.value.aem.core.models;


import com.verizon.value.aem.core.services.VisibleHelpCenterApiService;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import javax.inject.Inject;


@Model(adaptables = {SlingHttpServletRequest.class, Resource.class}, adapters = VisibleHelpCenterConfigModel.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class VisibleHelpCenterConfigModelImpl implements VisibleHelpCenterConfigModel{

  @Inject
    private VisibleHelpCenterApiService visibleHelpCenterApiService;
    @Override
    public String getCategoryApiUrl() {
        return visibleHelpCenterApiService.getCategoryApiUrl();
    }

    @Override
    public String getTrendingApiUrl() {
        return visibleHelpCenterApiService.getTrendingApiUrl();
    }

    @Override
    public String getArticleApiUrl() {
        return visibleHelpCenterApiService.getArticleApiUrl();
    }

    @Override
    public String getPrefixPath() {return visibleHelpCenterApiService.getPrefixPath();}
}
