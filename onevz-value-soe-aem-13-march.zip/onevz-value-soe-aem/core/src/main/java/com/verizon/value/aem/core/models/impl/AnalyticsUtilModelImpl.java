/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.verizon.value.aem.core.models.impl;


import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.verizon.value.aem.core.models.AnalyticsUtilModel;
import com.verizon.value.aem.core.utils.ApplicationUtil;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.injectorspecific.RequestAttribute;
import org.apache.sling.models.annotations.injectorspecific.Self;

@Model(adaptables = { Resource.class,
		SlingHttpServletRequest.class }, adapters = {
				AnalyticsUtilModel.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class AnalyticsUtilModelImpl implements AnalyticsUtilModel{

	private static final Logger LOGGER = LoggerFactory.getLogger(AnalyticsUtilModelImpl.class);

	@RequestAttribute
	private String ctaText;

	@RequestAttribute
	private String componentTitle;

	private String ctaAnalyticText;

	private String placementText;



	@SlingObject
	private ResourceResolver resourceResolver;
	

	@PostConstruct
	private void initModel() {
		LOGGER.debug("Entering initModel method");
			this.setCtaAnalyticText(ApplicationUtil.getLowerCaseWithUnderScore(ctaText));
			this.setPlacementText(ApplicationUtil.getLowerCaseWithUnderScore(componentTitle));
		LOGGER.debug("Exiting initModel method");
	}

	

	/**
	 * <p>
	 * Fetches ctaAnalyticText
	 * </p>
	 *
	 * @return String - ctaAnalyticText
	 */
	@Override
	public String getCtaAnalyticText() {
		return ctaAnalyticText;
	}

	/**
	 * <p>
	 * Sets ctaAnalyticText
	 * </p>
	 *
	 * @param ctaAnalyticText - the ctaAnalyticText to set
	 */
	public void setCtaAnalyticText(String ctaAnalyticText) {
		this.ctaAnalyticText = ctaAnalyticText;
	}

	/**
	 * <p>
	 * Fetches placementText
	 * </p>
	 *
	 * @return String - placementText
	 */
	@Override
	public String getPlacementText() {
		return placementText;
	}

	/**
	 * <p>
	 * Sets placementText
	 * </p>
	 *
	 * @param placementText - the placementText to set
	 */
	public void setPlacementText(String placementText) {
		this.placementText = placementText;
	}

	
}