package com.verizon.value.aem.core.services;

public interface VisibleOSGIService {

    public String getDomain();

    public String getUtag();

    public String getAffirmScriptUrl();

    public String getAffirmApiKey();

    public String getChatUrl();

    public String getApiUrl();

    public String getProductsUrl();

    public String getSaveSignal();

    public String getSearchTa();

    public String getAppConfig();

    public String getEnablePrechatForm();

    public String getClearCartUrl();

    public String getIsProd();

    public String getAirgapJsUrl();

    public String getQmNwInterceptOrUrl();

    public String[] getDispatcherUrl();

    public String[] getReplicationAgent();

    public String[] getAlphaDispatcherUrl();

    public String getPortabilityApiUrl();
}
