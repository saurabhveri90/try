package com.verizon.value.aem.core.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.StringWriter;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.apache.commons.lang3.Validate.isTrue;

public final class NestedJsonUnflattener {

    public static final String ROOT = "root";

    public static String unflatten(JsonNode json) {
        return new NestedJsonUnflattener(json).unflatten();
    }
    private final ObjectMapper mapper = new ObjectMapper();
    private final JsonNode root;

    private String separator = "__";
    private final Character leftBracket = '[';
    private final Character rightBracket = ']';

    private NestedJsonUnflattener newJsonUnflattener(JsonNode jsonNode) {
        NestedJsonUnflattener ju = new NestedJsonUnflattener(jsonNode);
        ju.withSeparator(separator);
        return ju;
    }

    private JsonNode parseJson(String json) {
        try {
            return mapper.readTree(json);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }



    private NestedJsonUnflattener(JsonNode jsonNode) {
        root = jsonNode;
    }

    private String arrayIndex() {
        return Pattern.quote(leftBracket.toString()) + "\\s*\\d+\\s*"
                + Pattern.quote(rightBracket.toString());
    }

    private String objectComplexKey() {
        return Pattern.quote(leftBracket.toString()) + "\\s*\".+?\"\\s*"
                + Pattern.quote(rightBracket.toString());
    }

    private String objectKey() {
        return "[^" + Pattern.quote(separator)
                + Pattern.quote(leftBracket.toString())
                + Pattern.quote(rightBracket.toString()) + "]+";
    }

    private Pattern keyPartPattern() {

            return Pattern
                    .compile(arrayIndex() + "|" + objectComplexKey() + "|" + objectKey());
    }


    public NestedJsonUnflattener withSeparator(String separator) {
        String separatorStr = String.valueOf(separator);
        isTrue(!separatorStr.matches("[\"\\s]"),
                "Separator contains illegal character(%s)", separatorStr);
        isTrue(!leftBracket.equals(separator) && !rightBracket.equals(separator),
                "Separator(%s) is already used in brackets", separatorStr);

        this.separator = separator;
        return this;
    }

    private String illegalBracketsRegex() {
        return "[\"\\s" + Pattern.quote(separator.toString()) + "]";
    }

    private String writeByConfig(JsonNode jsonNode) {
        return jsonNode.toString();
    }


    public String unflatten() {
        StringWriter sw = new StringWriter();
        if (!root.isObject()) {
            return root.toString();
        }

        ObjectNode flattened = (ObjectNode) root;
        JsonNode unflattened =
                flattened.size()<1 ? mapper.createObjectNode() : null;

        Iterator<String> names = flattened.fieldNames();
        while (names.hasNext()) {
            String key = names.next();
            JsonNode currentVal = unflattened;
            String objKey = null;
            Integer aryIdx = null;

            Matcher matcher = keyPartPattern().matcher(key);
            while (matcher.find()) {
                String keyPart = matcher.group();

                if (objKey != null ^ aryIdx != null) {

                        currentVal = findOrCreateJsonObject(currentVal, objKey, aryIdx);
                        objKey = extractKey(keyPart);
                        aryIdx = null;

                }

                if (objKey == null && aryIdx == null) {
                    if (isJsonArray(keyPart)) {
                        aryIdx = extractIndex(keyPart);
                        if (currentVal == null) currentVal = mapper.createArrayNode();
                    } else { // JSON object
                        objKey = extractKey(keyPart);
                        if (currentVal == null) currentVal = mapper.createObjectNode();
                    }
                }

                if (unflattened == null) unflattened = currentVal;
            }

            setUnflattenedValue(flattened, key, currentVal, objKey, aryIdx);
        }

        sw.append(writeByConfig(unflattened));
        return sw.toString();
    }

    private String extractKey(String keyPart) {
        if (keyPart.matches(objectComplexKey())) {
            keyPart = keyPart.replaceAll(
                    "^" + Pattern.quote(leftBracket.toString()) + "\\s*\"", "");
            keyPart = keyPart.replaceAll(
                    "\"\\s*" + Pattern.quote(rightBracket.toString()) + "$", "");
        }
        return keyPart;
    }

    private Integer extractIndex(String keyPart) {

            return Integer.valueOf(
                    keyPart.replaceAll("[" + Pattern.quote(leftBracket.toString())
                            + Pattern.quote(rightBracket.toString()) + "\\s]", ""));
    }

    private boolean isJsonArray(String keyPart) {
        return keyPart.matches(arrayIndex())
                || ( keyPart.matches("\\d+"));
    }



    private JsonNode findOrCreateJsonObject(JsonNode currentVal, String objKey,
                                            Integer aryIdx) {
        if (objKey != null) {
            ObjectNode jsonObj = (ObjectNode) currentVal;

            if (jsonObj.get(objKey) == null) {
                ObjectNode obj = mapper.createObjectNode();
                jsonObj.set(objKey, obj);

                return obj;
            }

            return jsonObj.get(objKey);
        } else { // aryIdx != null
            ArrayNode jsonAry = (ArrayNode) currentVal;

            if (jsonAry.size() <= aryIdx
                    ) {
                ObjectNode obj = mapper.createObjectNode();
                assureJsonArraySize(jsonAry, aryIdx);
                jsonAry.set(aryIdx, obj);

                return obj;
            }

            return jsonAry.get(aryIdx);
        }
    }

    private void setUnflattenedValue(ObjectNode flattened, String key,
                                     JsonNode currentVal, String objKey, Integer aryIdx) {
        JsonNode val = flattened.get(key);
        if (objKey != null) {
            if (val.isArray()) {
                ArrayNode jsonArray = mapper.createArrayNode();
                for (JsonNode arrayVal : (ArrayNode) val) {
                    jsonArray.add(parseJson(newJsonUnflattener(arrayVal).unflatten()));
                }
                ((ObjectNode) currentVal).set(objKey, jsonArray);
            }else if(val.toString().startsWith("\"[") && val.toString().endsWith("]\"")){
                ArrayNode jsonArray = mapper.createArrayNode();
                String[] items = val.toString().replaceAll("\\[", "").replaceAll("\"", "").replaceAll("\\]", "").split(",");
                for (String arrayVal : (String[]) items) {
                    jsonArray.add(arrayVal.trim());
                }
                ((ObjectNode) currentVal).set(objKey, jsonArray);
            }
            else {
                ((ObjectNode) currentVal).set(objKey.replace("=","_"), val);
            }
        } else { // aryIdx != null
            assureJsonArraySize((ArrayNode) currentVal, aryIdx);
            ((ArrayNode) currentVal).set(aryIdx, val);
        }
    }

    private void assureJsonArraySize(ArrayNode jsonArray, Integer index) {
        while (index >= jsonArray.size()) {

        }
    }

}
