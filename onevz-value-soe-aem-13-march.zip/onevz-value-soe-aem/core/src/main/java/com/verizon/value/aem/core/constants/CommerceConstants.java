/*
/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.verizon.value.aem.core.constants;

import com.adobe.aemds.guide.utils.JcrResourceConstants;

/**
 * Constants used across the application.
 */
public final class CommerceConstants {

	public static final String COLOR = "color";
	public static final String PRICE = "price";
	public static final String BRAND = "brand";
	public static final String NAME = "name";
	public static final String VALUE = "value";
	public static final String DESCRIPTION = "description";
	public static final String RATINGS = "ratings";
	public static final String REVIEWS = "reviews";
	public static final String ID = "id";
	public static final String MAKE = "make";
	public static final String SKUS = "SKUs";
	public static final String HEXA_COLOR = "hexaColor";
	public static final String PLAN_DATA = "PLANDATA";
	public static final String PLAN_TALK_MINUTES = "PlanTalkMinutes";
	public static final String DATA = "dataUnits";
	public static final String TALK_MINUTES = "voiceUnits";
	public static final String PRODUCT_CHARACTERISTICS = "productCharacteristics";
	public static final String PART_NUMBER = "partNumber";
	public static final String PRODUCT_ID = "product-id";
	public static final String LANGUAGE = "language";
	public static final String EQUALS_TO = "=";
	public static final String AMPERSAND = "&";
	public static final String QUESTION_MARK = "?";
	public static final String CATENTRY_ID = "skipPlanCatentryId";
	public static final String AUTO_REFILL_ID = "autoRefillCatentryId";
	public static final String AUTO_REFILL_PRICE = "autoRefillCatentryPrice";
	public static final String SERVICE_DAYS = "ServiceDays";
	public static final String UTF_8 = "UTF-8";
	public static final String APPLICATION_JSON = "application/json";
	public static final String SEARCH_KEY_WORD = "searchKeyword=*";
	public static final String PRODUCT_SPECIFICATIONS = "productSpecification";
	public static final String PART_CLASS = "partClass";

	// Dynamic SEO Title Constants
	public static final String PIM_OEM = "PIM_OEM";
	public static final String PIM_MARKET_NAME = "PIM_Market_Name";
	public static final String PIM_STORAGE_CAPACITY = "PIM_Storage_Capacity";
	public static final String PIM_STOCK_TYPE = "PIM_Stock_Type";
	public static final String PIM_BRAND = "PIM_Brand";
	public static final String PIM_MODEL = "PIM_Model";
	public static final String PIM_AMX_TECHNOLOGY = "PIM_AMX_Technology";
	public static final String PIM_DESCRIPTION = "PIM_Description";
	public static final String PIM_COLOR = "PIM_Color";
	public static final String PREPAID = "Prepaid";
	public static final String RECONDITIONED = "Reconditioned";
	public static final String NEW = "NEW";
	public static final String REFURBISHED = "REFURBISHED";

	// Phone card constants
	public static final String PHONE_LIST = "phonelist";
	public static final String MEDIA_PATH = "mediaPath";
	public static final String SKUS_SELECTION = "skusSelection";

	public static final String PHONE1 = "phone1";

	public static final String PLAN1 = "plan1";

	// Plan Detail
	public static final String PATH = "path";
	public static final String FULL = "full";
	public static final String QUERY_HITS = "p.hits";
	public static final String QUERY_LIMIT = "p.limit";
	public static final String QUERY_LIMIT_VALUE = "-1";
	public static final String PART_NO = "partNo";
	public static final String PROPERTY = "1_property";
	public static final String PROPERTY_VALUE = "1_property.value";
	public static final String STRING_PROPERTY = "property";
	public static final String STRING_PROPERTY_VALUE = "property.value";
	public static final String PLAN = "plan";
	public static final String PHONES = "phones";
	public static final String JCR_CONTENT = "/jcr:content";
	public static final String ACCESSORY = "accessory";
	public static final String DEVICE = "device";
	public static final String FILTER_SUMMARY = "filterSummary";
	public static final String SUB_FILTER = "subfilter";
	public static final String FILTER = "filter";
	public static final String SUB_FILTER_ATTRIBUTE = "subfilterattribute";
	public static final String SUB_FILTER_VALUE = "subfiltervalue";
	public static final String COUNT = "count";
	public static final String CATEGORY_ID = "categoryId";
	public static final String ATTRIBUTE = "attribute";
	public static final String ALL = "ALL";
	public static final String IDENTIFIER = "identifier";
	public static final String CUSTOMER_RANKING = "customerRanking";
	public static final String ALL_PLAN_TYPE = "AllPlanType";
	public static final String DEVICES_TYPE = "DevicesType";
	public static final String EXTENTDED_PLAN_ELIGIBLE = "ExtendedPlanEligible";
	public static final String OFFER_SMART_PAY = "offerSmartPay";
	public static final String OFFER_HPP_PLAN = "offerHPPPlan";
	public static final String PLAN_CATEGORY = "PlanCategory";
	public static final String PLAN_PURCHASE_TYPE = "PlanPurchaseType";
	public static final String ALLOW_GUEST_CHECKOUT = "allowGuestCheckout";
	public static final String PLAN_TEXT = "textUnits";
	public static final String PLAN_SERVICE_DAYS = "planServiceDays";
	public static final String PLAN_PURCHASE_POINTS = "PLANVALUE_TO_LRPOINTS";
	public static final String PLAN_EARN_POINTS = "planEarnPoints";
	public static final String PLAN_DEVICE_TYPE = "planDeviceType";
	public static final String INBUILT_PROTECTION_PLAN = "inBuiltProtectionPlan";
	public static final String MIGRATION_GROUP_UPGRADE = "migrationGroupUpg";
	public static final String EOL = "EOL";
	public static final String TYPE = "TYPE";
	public static final String EXCEPTION_OCCURRED = "Exception Occurred";
	public static final String _1001 = "1001";
	public static final String ACTIVATION_REDEEM_BY = "activationRedeemBy";
	public static final String ACTIVATION_PLAN_INSTRUCTIONS_MULTI_LINE = "activationPlanInstructionsMultiLine";
	public static final String ACTIVATION_PLAN_INSTRUCTIONS_NORMAL = "activationPlanInstructionsNormal";
	public static final String ACTIVATION_PLAN_TITLE = "activationPlanTitle";
	public static final String ACTIVATION_PLAN_DESCRIPTION = "activationPlanDescription";
	public static final String PLAN_DATA_DESCRIPTION_CAMEL = "planDataDescription";
	public static final String DATA_QUOTA = "dataQuota";
	public static final String PLAN_TALK_MINUTES_CAMEL = "planTalkMinutes";
	public static final String ROOT_RESPONSIVEGRID_PRODUCT_PLANCARD = "root/responsivegrid/product/plancard";
	public static final String ROOT_RESPONSIVEGRID_PLANCARD = "root/responsivegrid/product/plandetail/plancard";
	public static final String ROOT_RESPONSIVEGRID_PLAN_DETAIL = "root/responsivegrid/product/plandetail";
	public static final String ROOT_RESPONSIVEGRID_MLD_PLANCARD = "root/responsivegrid/product/multilineplandetail/plancard";
	public static final String ROOT_RESPONSIVEGRID_MLD_DETAIL = "root/responsivegrid/product/multilineplandetail";
	public static final String ROOT_RESPONSIVEGRID_PRODUCT_MULTILINE_PLANCARD = "root/responsivegrid/product/multilineplandetail/plancard";
	public static final String ROOT_RESPONSIVEGRID_PRODUCT_MULTILINE = "root/responsivegrid/product/multilineplandetail";
	public static final String EMPTY_STRING = "";
	public static final String FIRST_IMAGE_PATH = "firstImagePath";
	public static final String IMAGE_PATH = "imagePath";
	public static final String SKUS_SELECTION_CAMEL = "skusSelection";
	public static final String ROOT_RESPONSIVEGRID_PRODUCT_PHONEDETAIL_COLOR_VARIANTS = "root/responsivegrid/product/phonedetail/colorVariants";
	public static final String TUTORIAL_LINK = "tutorialLink";
	public static final String PLAN_PART_NO = "planPartNo";
	public static final String PLAN_TITLE = "planTitle";
	public static final String PLAN_SUBTITLE = "planSubtitle";
	public static final String PLAN_TITLE_MAPPING = "planTitleMapping";
	public static final String DEVICES_PAGE_PATH = "devicesPagePath";
	public static final String ROOT_RESPONSIVEGRID_PRODUCT_ACCESSORYDEVICE_MULTILINKS = "root/responsivegrid/product/accessorydevice/multilinks";
	public static final String PLAN_TYPE = "planType";
	public static final String DOLLAR = "$";
	public static final String GLOBAL_CALLING_CARD_QUANTITY = "gccQuantity";
	public static final String PRODUCT_CARD_IMAGE = "productCardImage";
	public static final String PRODUCT_CARD_HEADING = "productCardHeading";
	public static final String PRODUCT_CARD_DESCRIPTION = "productCardDescription";
	public static final String REWARDS_PURCHASE_LABEL = "rewardsPurchaseLabel";
	public static final String REWARDS_EARN_LABEL = "rewardsEarnLabel";
	public static final String ADD_MORE_SAVE_MORE = "addMoreSaveMore";
	public static final String PLAN_DETAIL_NODE_PATH = "/jcr:content/root/responsivegrid/product/plandetail/plancard";
	public static final String PLAN_DETAIL_NODE_PATH_V1 = "/jcr:content/root/responsivegrid/product/plancard";
	public static final String SIM_DETAIL_NODE_PATH_V1 = "/jcr:content/root/responsivegrid/product/simcard";
	public static final String PLAN_DETAIL_ROOT_PATH = "/jcr:content/root/responsivegrid/product/plandetail";
	public static final String USE_BAZAAR_VOICE_RATINGS = "useBazaarVoiceRatings";
	public static final String USE_FULL_WIDTH_EARN_REWARDS = "useFullWidthEarnRewards";
	public static final String ALTERNATE_DATA_UNIT_FOR_PLAN_CARD = "alternateDataUnitForPlanCard";
	public static final String ACCESS_TEXT = "accessText";
	// Add to Cart Constants
	public static final String CATEGORY_TYPE = "categorytype";
	public static final String SUB_CATEGORY_TYPE = "subcategorytype";
	public static final String CTA_TEXT = "ctaText";
	public static final String CTA_LINK = "ctaLink";
	public static final String CTA_ALTTEXT = "ctaAltText";
	public static final String HEADING = "heading";
	public static final String HEADING_HELPTEXT = "headingHelpText";
	public static final String HEADING_HELPTEXT_ACCESSIBILITY_LBL = "headingHelpTextAccessibilityLabel";
	public static final String FOOT_NOTE = "footNote";
	public static final String SUMMARY = "summary";
	public static final String LABEL = "label";
	public static final String CUSTOMER_TYPE = "customerType";
	public static final String OPTIONS = "options";
	public static final String LOGO_LINK = "logoLink";
	public static final String LOGO_ALT_TEXT = "logoAltText";
	public static final String LOGO_SUBTEXT = "logoSubtext";
	public static final String PRE_ORDER_CTA_TEXT = "preOrderCtaText";
	public static final String PHONES_PAGE_PATH = "phonesPagePath";

	public static final String WATCHES_PAGE_PATH = "watchesPagePath";
	public static final String TABLETS_PAGE_PATH = "tabletsPagePath";
	public static final String PLANS_PAGE_PATH = "plansPagePath";
	public static final String TERMS_AND_CONDITION_MODAL_ID = "termsConditionModalId";
	public static final String TERMS_AND_CONDITION_MODAL_ID_LINK_LABEL = "termsConditionLinkLabel";
	public static final String TERMS_AND_CONDITION_LINK = "termsConditionLink";
	public static final String TERMS_AND_CONDITION_TYPE = "termsConditiontype";
	public static final String PLAN_FLOW_TYPE = "flowType";
	public static final String RETAIL_PRICE_LABEL = "retailPriceLabel";
	public static final String EXPERIENCE_PRICE_PREFIX = "expriceprefix";
	public static final String EXPERIENCE_PRICE_SUFFIX = "expricesuffix";
	public static final String SMART_PAY_MESSAGE_LOGO = "smartPayLogo";
	public static final String SHOW_PRICE_DETAILS_ABOVE_IMAGE = "showPriceDetailsAboveImg";
	public static final String SHOW_STEPS_NUMBER = "showStepsNumber";
	public static final String CTA_DISABLE_TEXT = "ctaDisableText";
	public static final String NO_REFILL_DISCLAIMER = "noRefillDisclaimer";
	// recommended products constants
	public static final String PRODUCT_NODE_PATH = "/root/responsivegrid/product";
	public static final String PLAN_NAME = "planname";
	public static final String PRICE_DESCRIPTION = "pricedescription";
	public static final String AUTO_REFILL_DISCOUNT_LABEL = "autoRefillDiscountLabel";
	public static final String PLAN_DATA_DESCRIPTION = "plandatadescription";
	public static final String PRICE_SUPER_SCRIPT = "pricesuperscript";
	public static final String PLAN_PROMO_TEXT = "promotext";
	public static final String PLAN_PROMO_ADDITIONAL_TEXT = "promoadditionaltext";
	public static final String PLAN_DATA_LABEL = "plandatalabel";
	public static final String PRICE_ACCESSIBILITY_LABEL = "priceAccessibilityLabel";
	public static final String HASH = "hash";
	public static final String DOT = "dot";

	// Payment Options Constants
	public static final String PAYMENT_CTA_TEXT = "paymentCtaText";
	public static final String PAYMENT_CTA_LINK = "paymentCtaLink";
	public static final String PAYMENT_CTA_ALTTEXT = "paymentCtaAltText";
	public static final String PAYMENT_OPTION_LABEL = "paymentOptionsLabel";
	public static final String PAYMENT_LABEL = "paymentLabel";
	public static final String PAYMENT_TYPE = "paymentType";
	public static final String PROMO_PAYMENT_LABEL = "promoPaymentLabel";
	public static final String PAYMENT_OPTIONS = "paymentOptions";
	public static final String PAYMENT_PRICE_PREFIX_LABEL = "pricePrefixLabel";
	public static final String PROMO_PAYMENT_PRICE_PREFIX_LABEL = "promoPricePrefixLabel";
	public static final String PAYMENT_PRICE_SUFFIX_LABEL = "priceSuffixLabel";
	public static final String PROMO_PAYMENT_PRICE_SUFFIX_LABEL = "promoPriceSuffixLabel";
	public static final String PROMO_OFFER_TYPE = "promo-offer";
	public static final String DO_NOT_FOLLOW_LINK = "donotfollowlink";
	public static final String EMI = "emi";
	public static final String PRICE_SUFFIX_LABEL = "priceSuffixLabel";
	public static final String MARKETPLACE_ICON_IMG = "marketPlaceIconImage";
	public static final String MARKETPLACE_TITLE_TEXT = "marketPlaceTitleText";
	public static final String MARKETPLACE_SUBTITLE_TEXT = "marketPlaceSubTitleText";
	public static final String MARKETPLACE_CTA_TEXT = "marketPlaceCtaText";
	public static final String MARKETPLACE_CTA_LINK = "marketPlaceCtaLink";
	public static final String MARKETPLACE_CTA_ALTTEXT = "marketPlaceCtaAltText";

	// Zipcode functionality
	public static final String BRANDNAME = "brandName";
	public static final String SOURCE_SYSTEM = "sourceSystem";
	public static final String WEB = "WEB";
	public static final String ZIP_CODE = "zipCode";
	public static final String MARKET = "market";
	public static final String CLIENT_ID = "client_id";

	// Notify Stock Constants
	public static final String NOTIFY_TITLE = "notifyTitle";
	public static final String NOTIFY_TEXT = "notifyText";
	public static final String SUCCESS_TEXT = "successText";
	public static final String NOTIFY_BUTTON = "notifyBtn";
	public static final String EMAIL_LABEL = "emailLabel";

	public static final String STOCK_POPOVER_TITLE = "stockPopoverTitle";
	public static final String NOTIFY_ME_BUTTON = "notifyMeBtn";
	public static final String PRE_TEXT_NOTIFY_ME_BUTTON = "preTextnotifyMeBtn";

	// Exceed Cart Limit
	public static final String ITEM_TYPE_FOR_DEVICE = "deviceItem";
	public static final String ITEM_TYPE_FOR_PLAN = "planItem";
	public static final String ITEM_TYPE_FOR_ACCESSORIES = "standaloneItem";
	public static final String PROJECTION = "projection";
	public static final String CART_DETAILS = "cartDetails";

	// Get Account Profile
	public static final String VIEW = "view";
	public static final String VIEW_TYPE_FULL = "FULL";

	// HPP ELigibility
	public static final String RESOURCE_CATEGORY = "resourceCategory";
	public static final String LINE = "LINE";
	public static final String RESOURCE_IDENTIFIER = "resourceIdentifier";
	public static final String BASIC_INFO = "basic-info";
	public static final String PROJECTION_ACCOUNT = "account";

	// mixed cart notification
	public static final String PRE_ORDER_DETAILS = "preOrderDetail";
	public static final String PRE_ORDER_CONFIRMATION_TEXT = "preOrderConfirmationText";
	public static final String SMART_PAY_DETAILS = "smartPayDetail";
	public static final String SMART_PAY_CONFIRMATION_TEXT = "smartConfirmationText";
	public static final String NORMAL_CART_DETAILS = "normalCartDetail";
	public static final String NORMAL_CART_CONFIRMATION_TEXT = "normalCartConfirmationText";

	// adobe i/o query properties
	public static final String EXTRA_CHARACTERISTICS = "extraCharacteristics";
	public static final String IS_PRE_SALES = "ISPRESALE";
	public static final String PS_DELIVERY_DATE = "PSDELIVERYDATE";
	public static final String MIGRATION_GROUP_UPG = "MIGRATION_GROUP_UPG";

	// Smartpay App
	public static final String FULL_PRICE_QUERY = "actionCode=SP_DECLINE_URL";

	public static final String QUEUED_FLOW_TYPE = "r";
	public static final String PIN_FLOW_TYPE = "p";

	// Constants for Payment Detail
	public static final String RESOURCE_TYPE = JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY;
	public static final String HPP_PLAN_DATA_DESCRIPTION = "hppPlandatadescription";
	public static final String HPP_PLAN_SERVICE_DAYS = "hppPlanservicedays";
	public static final String PLAN_THUMBNAIL_IMAGE = "planthumbnailimage";
	public static final String HPP_PLAN_THUMBNAIL_IMAGE = "hppPlanthumbnailimage";
	public static final String HPP_PLAN_NAME = "hppPlanname";
	public static final String HPP_PLAN_DATA_LABEL = "hppPlandatalabel";

	public static final String PLAN_PAGE_PATH_FOR_PAYMENT_DETAIL = "planPagePathForPaymentDetail";
	public static final String ROOT_RESPONSIVEGRID_PRODUCT_HPP_PLANCARD = "root/responsivegrid/product/protectionplancard";
	public static final String ROOT_RESPONSIVEGRID_HPP_PLANCARD = "root/responsivegrid/product/protectionplancard";
	public static final String PAYMENT_DETAIL = "paymentDetail";
	public static final String PAYMENT_PLAN_NAME = "planName";
	public static final String PAYMENT_PLAN_NAME_DETAIL = "planNameDetail";
	public static final String PAYMENT_PLAN_IMAGE = "planImage";
	public static final String PAYMENT_PLAN_IMAGE_ASSET_ID = "planImageAssetId";
	public static final String PAYMENT_PLAN_IMAGE_ASSET_AGENCY_ID = "planImageAssetAgencyId";
	public static final String PAYMENT_PLAN_RESOURCE_TYPE = "planResourceType";
	public static final String ITEM_TYPE = "itemType";
	public static final String ALL_PLANS = "ALL_PLANS";

	// Constants for Phone card
	public static final String PHONE_DETAIL_NODE_PATH = "/jcr:content/root/responsivegrid/product/phonedetail";
	public static final String COLOR_VARIANTS = "/colorVariants/item0";
	public static final String PHONE_EXPRICE_PREFIX = "expriceprefix";
	public static final String PHONE_EXPRICE_SUFFIX = "expricesuffix";
	public static final String PHONE_EXPRICE_DURATION = "expriceduration";
	public static final String PHONE_PRICE_CAPTION_PLP = "pricecaptionplp";
	public static final String PHONE_ALT_TEXT = "altText";
	public static final String PHONE_SMART_PAY_LOGO = "smartPayLogo";
	public static final String UNIT = "unit";
	public static final String SPECS_OPTIONS = "specsoptions";
	public static final String MULTIPLIER = "multiplier";
	public static final String IDENTIFIER_MULTIPLIER = "Multiplier";
	public static final String SINGLE_BUCKET_TEXT = "sbtext";
	public static final String SINGLE_BUCKET_UNIT = "sbunit";
	public static final String SINGLE_BUCKET_IDENTIFIERS = "sbidentifiers";
	public static final String CONVERT_VALUE = "convertValue";
	public static final String CARRYOVER_OPTIONS = "carryoveroptions";
	public static final String SERVICE_PLAN_GROUP = "servicePlanGroup";
	public static final String SERVICE_PLAN_GROUP_IDENTIFIER = "ServicePlanGroups";
	public static final String DATA_CONVERSION = "dataConversion";
	public static final String THRESHOLD_VALUE = "thresholdValue";
	public static final String THRESHOLD_UNIT = "thresholdUnit";
	public static final String THRESHOLD_LABEL = "thresholdLabel";
	public static final String BENEFIT_CARRY_FORWARD_DESC = "bcfDescription";
	public static final String BENEFIT_CARRY_FORWARD_ADD_ON_DESC = "bcfAddOnDescription";
	public static final String BENEFIT_NON_CARRY_FORWARD_ADD_ON_DESC = "bncfAddOnDescription";
	public static final String BENEFITS_CARRY_FORWARD_FLAG = "benefitsCarryForward";
	public static final String BUY_NOW_REWARDS_HELP_TEXT = "buyNowRewardsHelpText";
	public static final String PHONE_PLAN_CAROUSEL_BUTTON_LABEL = "phonePlanCardButtonLabel";
	public static final String ENABLE_BUTTON_FOR_CAROUSEL_PRODUCT_CARD = "enableButtonForProductCards";
	public static final String ADDON_GLOBAL_CARD_DETAILS = "planAddonGlobalCardDetails";
	public static final String PLAN_ELIGIBLE_FOR_AUTOREFILL = "PlanEligibleForAutoRefill";
	public static final String BILLING_PLAN_TYPE = "billingPlanType";
	public static final String TAX_INCLUSIVE = "taxInclusive";
	public static final String HOTSPOT_CAPABILITY = "HOTSPOT_CAPABILITY";
	public static final String HOTSPOT_CAPABLE_EN = "Hotspot Capable";
	public static final String HOTSPOT_CAPABLE_ES = "Hotspot habilitado";
	public static final String HOTSPOT_TEXT = "Hotspot";
	public static final String CAPABLE_TEXT_EN = "Capable";
	public static final String CAPABLE_TEXT_ES = "habilitado";
	// Constants for CUSG
	public static final String LABEL_PLAN_CUSG_DISCOUNT_TYPE = "cusgPlanDiscountTypeLabel";
	public static final String LOGO_CUSG = "cusgLogo";
	public static final String ENABLE_CUSG = "enableCusg";
	public static final String LOGO_ALT_TEXT_CUSG = "cusgLogoAltText";
	public static final String CUSG_DISCLAIMER_TEXT = "cusgDisclaimerText";


	public static final String SKU = "sku";
	public static final String BY_PART_NUMBER_OPTIMIZED = "bypartnumberoptimized";
	public static final String CATEGORY = "category";
	public static final String PRODUCT_OFFERINGS = "productOfferings";
	public static final String BY_SEARCH_TERM_OPTIMIZED = "bysearchtermoptimized";

	// Constants for Multiline Plan
	public static final String NUMBER_OF_LINES = "numberOfLines";
	public static final String MULTILINE_HEADING = "multilineHeading";
	public static final String MULTILINE_SUBHEADING = "multilineSubheading";
	public static final String PRICE_BREAKDOWN_LABEL = "priceBreakdownLabel";
	public static final String NEW_CUSTOMER_CTA_TEXT = "newCustomerCtaText";
	public static final String NEW_CUSTOMER_ACCESSIBILITY = "newCustomerAccessibility";
	public static final String RETURN_CUSTOMER_CTA_TEXT = "returnCustomerCtaText";
	public static final String RETURN_CUSTOMER_ACCESSIBILITY = "returnCustomerAccessibility";
	public static final String RETURN_CUSTOMER_CTA_LINK = "returnCustomerCtaLink";
	public static final String MULTILINE_DISCLAIMER_TEXT = "multilineDisclaimerText";
	public static final String SPEC_PREFIX = "spec-";
	public static final String ADDITIONAL_SPECS = "additionalSpecs";
	public static final String PER_TIME_PERIOD = "pertimeperiod";

	public static final String UPSELL = "UPSELL";

	public static final String PLAN_NAME_DETAIL = "planNameDetail";
	public static final String MULTILINE_PLAN_NAME_TYPE = "planNameType";
	public static final String MULTILINE_PLAN_NAME = "planName";
	public static final String MULTILINE_PLAN_DETAIL_ROOT_PATH = "/jcr:content/root/responsivegrid/product/multilineplandetail";
	public static final String MULTILINE_PLAN_DETAIL_NODE_PATH = "/jcr:content/root/responsivegrid/product/multilineplandetail/plancard";
	public static final String PRICE_SAVE_ACCESSIBILITY = "priceSaveAccessibility";

	// Constants for Multiline Plan Refill
	public static final String MULTILINE_REFILL_HEADING = "multilineplanrefillHeading";
	public static final String MULTILINE_REFILL_SUBHEADING = "multilinerefillSubheading";
	public static final String MULTILINE_REFILL_INPUT_LABEL = "planrefillInputLabel";
	public static final String MULTILINE_REFILL_OTP_LABEL = "planrefillOTPLabel";
	public static final String MULTILINE_REFILL_EDIT_BUTTON = "planrefillEditButtonText";

	// Constants for PhoneSpecs
	public static final String WITHOUT_LOGO = "withoutlogo";
	public static final String A = "a";
	public static final String N = "n";
	public static final String Y = "y";
	public static final String ANDROID_IMAGE_NAME = "androidImageName";
	public static final String APPLE_IMAGE_NAME = "appleImageName";
	public static final String PRODUCT_SPEC_IMAGE_PATH = "productSpecImagePath";
	public static final String COMPARE_IMAGE_PATH = "compareProductSpecImagePath";
	public static final String LAYOUT = "layout";
	public static final String PLAN_PERK_DESCRIPTION = "PlanPerkDescription";

	public static final String USE_BAZAAR_VOICE_RATINGS_SIM_PDP = "useBazaarVoiceinSimDetails";

	// Bundle Plan Constants
	public static final String IS_VAS_BUNDLE_PLAN = "isVasBundlePlan";
	public static final String VAS_BUNDLED_SP_PROD_IMG = "vasProductThumbnailImage";
	public static final String VAS_BUNDLED_SP_PROD_IMG_ACC_TEXT = "vasProdImgAccessibleText";
	public static final String VAS_BUNDLED_SP_PROD_IMG_SUBSCRIPT = "vasProdImgSubscript";
	public static final String VAS_BUNDLED_SP_PROD_TERMS_CONTENT = "vasTermsContent";
	public static final String VAS_TOOLTIP_CONTENT = "vasTooltipContent";
	public static final String VAS_TERMS = "vasTerms";
	public static final String PLAN_CAMPAIGN_NAME = "PLAN_CAMPAIGN_NAME";

	// Payment Options For Free Option
	public static final String PAYMENT_SUMMARY = "paymentSummary";
	public static final String PROMO_PAYMENT_SUMMARY = "promoPaymentSummary";
	public static final String PROMO_CTA_TEXT = "promoCtaText";
	public static final String PROMO_ACTIVATION_CTA_LINK = "promoActivationCtaLink";
	public static final String PROMO_PORT_IN_CTA_LINK = "promoPortInCtaLink";
	public static final String PROMO_CTA_ALTTEXT = "promoCtaAltText";
	public static final String PROMO_DO_NOT_FOLLOW_LINK = "promoDoNotFollowLink";
	public static final String OTHER_PAYMENT_OPTIONS_CTA_TEXT = "otherPayOptionsCtaText";
	public static final String OTHER_PAYMENT_OPTIONS_CTA_ALT_TEXT = "otherPayOptionsCtaAltText";
	public static final String HIDE_OTHER_PAYMENT_OPTIONS_CTA = "hideOtherOptionDropDown";
	public static final String PROMO_DCOT_CTA_LINK = "promoDcotCtaLink";
	public static final String PROMO_DCOT_CHURN_CTA_LINK = "promoDcotChrunCtaLink";

	// promotional offer constants
	public static final String PORT_IN_HEADING_TEXT = "portInHeadingText";
	public static final String PORT_IN_ELIGIBILITY_STEPS = "portEligibilitySteps";
	public static final String PORT_IN_VERIFY_PHONE_TEXT = "verifyPhoneNumberText";
	public static final String PORT_IN_VERIFY_PHONE_LABEL = "verifyPhoneNumberLabel";
	public static final String PORT_IN_CHECK_CTA_TEXT = "checkMyNumberCtaText";
	public static final String PRIVACY_POLICY_DISCLAIMER = "privacyPolicyDisclaimer";
	public static final String PORT_IN_VERIFY_CODE_HEADING_TEXT = "verifyCodeHeadingText";
	public static final String PORT_IN_VERIFY_CODE_SUB_HEADING_TEXT = "verifyCodeSubHeadingText";
	public static final String PORT_IN_VERIFY_CODE_SUB_HEADING_2_TEXT = "verifyCodeSubHeading2Text";
	public static final String PORT_IN_VERIFY_CODE_INPUT_LABEL = "verifyCodeInputLabelText";
	public static final String PORT_IN_VERIFY_CODE_CTA_TEXT = "verifyCodeCtaText";
	public static final String PORT_IN_VERIFY_CODE_RESEND_TEXT_ONE = "verifyCodeResendTextOne";
	public static final String PORT_IN_VERIFY_CODE_RESEND_TEXT_TWO = "verifyCodeResendTextTwo";
	public static final String PORT_IN_ANOTHER_PHONE_NUM_LABEL = "portInAnotherPhoneNumberText";
	public static final String PORT_IN_SUCCESS_HEADING_TEXT = "portInSuccessHeadingText";
	public static final String PORT_IN_SUCCESS_DESCRIPTION_TEXT = "portInSuccessDescriptionText";
	public static final String PORT_IN_FAILURE_HEADING_TEXT_ONE = "portInFailureHeadingTextOne";
	public static final String PORT_IN_FAILURE_HEADING_TEXT_TWO = "portInFailureHeadingTextTwo";
	public static final String PORT_IN_FAILURE_DESCRIPTION_TEXT = "portInFailureDescriptionText";
	public static final String PORT_IN_FAILURE_OPTIONS_LINK = "portInFailureOtherOptionsLink";
	public static final String PORT_IN_FAILURE_OPTIONS_ARIA_LINK = "portInFailureOtherOptionsAriaLabel";
	public static final String PORT_IN_FAILURE_OPTIONS_URL_LINK = "portInFailureOtherOptionsUrlLink";
	public static final String PORT_IN_FOOT_NOTE = "portInFootnote";
	public static final String PORT_IN_LOADER_HEADING_TEXT = "portInLoaderHeadingText";
	public static final String PORT_IN_LOADER_STEP_ONE_TEXT = "portInLoaderStepOne";
	public static final String PORT_IN_LOADER_STEP_TWO_TEXT = "portInLoaderStepTwo";
	public static final String PORT_IN_LOADER_STEP_THREE_TEXT = "portInLoaderStepThree";
	public static final String PORT_IN_LOADER_STEP_ERROR_ONE_TEXT = "portInApiErrorMsgOne";
	public static final String PORT_IN_LOADER_STEP_ERROR_TWO_TEXT = "portInApiErrorMsgTwo";
	public static final String PORT_IN_ELIGIBILITY_API_TIMER = "portInEligibilityApiTimer";
	public static final String PORT_IN_RESEND_CODE_TIMER = "portInResendCodeTimer";
	public static final String ENABLE_PROMOTIONAL_PHONE_OFFER_MODAL = "enablePromotionalOfferModal";
	public static final String ENABLE_PROMOTIONAL_OFFER = "enablePromotionalOffers";
	public static final String ENABLE_DCOT_PROMOTIONAL_OFFER = "enableDcotPromoOffers";
	// constant for Promotional Offer on Plan PDP
	public static final String MULTILINE_PLAN_OFFER_DISCLAIMER = "offerDisclaimer";
	public static final String MULTILINE_PLAN_OFFER_DISCLAIMER_LABEL = "offerDisclaimerLabel";
	public static final String MULTILINE_PLAN_OFFER_DISCLAIMER_LINK_LABEL = "offerDisclaimerLinklabel";
	public static final String MULTILINE_SPECIAL_PLAN_OFFER_LABEL = "specialPromoSummary";
	public static final String VERIFF_SUCCESS_HEADING_TEXT = "veriffSuccessHeadingText";
	public static final String VERIFF_SUCCESS_DESCRIPTION_TEXT = "veriffSuccessDescriptionText";
	public static final String PROMO_VERIFF_CTA_LINK = "promoVeriffCtaLink";
	public static final String VERIFF_FOOT_NOTE = "veriffFootnote";
	public static final String VERIFF_LV_FOOT_NOTE = "veriffLVFootnote";
	public static final String VERIFF_NL_FOOT_NOTE = "veriffNLFootnote";
	public static final String VERIFF_LOGGED_IN_FOOT_NOTE = "veriffLFootnote";
	public static final String VERIFF_SUCCESS_LV_DESCRIPTION_TEXT = "veriffSuccessLVDescText";
	public static final String VERIFF_SUCCESS_NL_DESCRIPTION_TEXT = "veriffSuccessNLDescText";
	public static final String PORT_IN_VERIFY_CODE_RESEND_ACC_TEXT_TWO = "verifyCodeResendAccTextTwo";
	public static final String PORT_IN_ANOTHER_PHONE_NUM_ACC_LABEL = "portInAnotherPhoneNumberAccText";
	public static final String SHOW_PORT_IN_SCREEN_IN_FLOW = "showPortinInFlow";

	public static final String SHOW_RECOMMENDED_PLAN = "showRecommendedPlan";
	public static final String INVENTORY_AVAILABLE = "inventoryAvailable";
	public static final String SERVICE_PLANS = "servicePlans";
	public static final String PLANS = "plans";
	public static final String BASE_PLAN_ID = "basePlanId";
	public static final String CLIENT_CREDENTIALS = "client_credentials";
	public static final String CLIENT_SECRET = "client_secret";
	public static final String GRANT_TYPE = "grant_type";
	public static final String SCOPE = "scope";
	public static final String GET_SECURITY_QUESTIONS = "getSecurityQuestions";
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String SCOPE_CATALOG_MANAGEMENT = "catalog-mgmt";
	public static final String SCOPE_SERIVICE_PLAN_SELECTOR = "servicePlanSelector";
	public static final String RESPONSE = "response";
	public static final String START_DATE = "startDate";
	public static final String END_DATE = "endDate";
	public static final String INELIGIBLE_PLAN_MESSAGE = "inEligiblePlanMsg";
	public static final String ELIGIBLE_PLAN_PLP_LINK = "eligiblePlanPLPLink";
	public static final String SHOW_ELIGIBLE_PLAN_LINK = "showEligiblePlanLink";

	public static final String DCOT_PROMO = "DCOTPromo";

	public static final String DCOT_MODEL_NAME = "DCOTModelName";

	public static final String DCOT_MIN_MONTHLY = "DCOTMinMonthly";

	public static final String DCOT_MODEL_DISCOUNT = "DCOTMonthlyDisc";

	public static final String DCOT_OFFER_END_DATE = "DCOTOfferEndDt";

	public static final String DCOT_PAID_AMOUNT = "DCOTPaidAmt";

	public static final String DCOT_SAVING = "DCOTSaving";
	public static final String DCOT_AUTOREFILL = "DCOTAutoRefill";
	public static final String DCOT_NEWLINEUPG = "DCOTNewLineUpg";
	public static final String DCOT_TOTAL_MONTH = "DCOTTotalMonth";
	public static final String DCOT_UPGRADE = "DCOTActUpg";
	public static final String DCOT_NEWLINE_ACTIVATION = "DCOTActNewLine";

	public static final String DISABLE_PROMO_ELIGIBILITY_CALL = "disablePromoEligibility";

	public static final String DCOT_PROMO_TEXT_POPUP_DESC_PDP = "dcotPromoTextPopupPDP";
	public static final String DCOT_PROMO_TEXT_POPUP_HEADING_PDP = "dcotPromoTextPopupHeadingPDP";
	public static final String DCOT_PROMO_PLAN_TEXT_ON_PDP = "dcotPromoPlantextonPDP";
	public static final String DCOT_FULL_PRICE_PROMO_PLAN_TEXT_ON_PDP = "dcotFullpricePromoTextPDP";
	public static final String DCOT_PAYMENT_LABEL = "dcotPaymentLabel";
	public static final String DCOT_PRICE_PREFIX_LABEL = "dcotPricePrefixLabel";
	public static final String DCOT_PRICE_SUFFIX_LABEL = "dcotPriceSuffixLabel";
	public static final String DCOT_PAYMENT_SUMMARY = "dcotPaymentSummary";


	public static final String VERIFF_PROMO_TEXT_POPUP_DESC_PDP = "veriffPromoTextPopupPDP";
	public static final String VERIFF_PROMO_TEXT_POPUP_HEADING_PDP = "veriffPromoTextPopupHeadingPDP";
	public static final String VERIFF_PROMO_PLAN_TEXT_ON_PDP = "veriffPromoPlantextonPDP";
	public static final String VERIFF_PAYMENT_LABEL = "veriffPaymentLabel";
	public static final String VERIFF_PRICE_PREFIX_LABEL = "veriffPricePrefixLabel";
	public static final String VERIFF_PRICE_SUFFIX_LABEL = "veriffPriceSuffixLabel";
	public static final String VERIFF_PAYMENT_SUMMARY = "veriffPaymentSummary";

	public static final String PORTIN_PROMO_TEXT_POPUP_DESC_PDP = "portInPromoTextPopupPDP";
	public static final String PORTIN_PROMO_TEXT_POPUP_HEADING_PDP = "portInPromoTextPopupHeadingPDP";
	public static final String PORTIN_PROMO_PLAN_TEXT_ON_PDP = "portInPromoPlantextonPDP";
	public static final String PORTIN_PAYMENT_LABEL = "portInPaymentLabel";
	public static final String PORTIN_PRICE_PREFIX_LABEL = "portInPricePrefixLabel";
	public static final String PORTIN_PRICE_SUFFIX_LABEL = "portInPriceSuffixLabel";
	public static final String PORTIN_PAYMENT_SUMMARY = "portInPaymentSummary";

	public static final String ACTIVATION_PROMO_TEXT_POPUP_DESC_PDP = "activationPromoPopupPDP";
	public static final String ACTIVATION_PROMO_TEXT_POPUP_HEADING_PDP = "activationPromoPopupHeadingPDP";
	public static final String ACTIVATION_PROMO_PLAN_TEXT_ON_PDP = "activationPromoPlantextonPDP";
	public static final String ACTIVATION_PAYMENT_LABEL = "activPaymentLabel";
	public static final String ACTIVATION_PRICE_PREFIX_LABEL = "activPricePrefixLabel";
	public static final String ACTIVATION_PRICE_SUFFIX_LABEL = "activPriceSuffixLabel";
	public static final String ACTIVATION_PAYMENT_SUMMARY = "activPaymentSummary";
	public static final String DCOT_PROMO_HEADING_PLP = "dcotPromoTextPLP";
	public static final String DCOT_PROMO_TEXT_PLP = "dcotPromoDescPLP";

	public static final String VERIFF_PROMO_HEADING_PLP = "veriffPromoTextPLP";
	public static final String VERIFF_PROMO_TEXT_PLP = "veriffPromoDescPLP";

	public static final String PORTIN_PROMO_HEADING_PLP = "portInPromoTextPLP";
	public static final String PORTIN_PROMO_TEXT_PLP = "portInPromoDescPLP";

	public static final String ACTIVATION_PROMO_HEADING_PLP = "activationPromoTextPLP";
	public static final String ACTIVATION_PROMO_TEXT_PLP = "activationPromoDescPLP";
	public static final String DCOT_PROMO_TEXT_PDP = "dcotPromoTextPDP";
	public static final String VERIFF_PROMO_TEXT_PDP = "veriffPromoTextPDP";
	public static final String PORTIN_PROMO_TEXT_PDP = "portInPromoTextPDP";
	public static final String ACTIVATION_PROMO_TEXT_PDP = "activationPromoTextPDP";

	public static final String STORAGE = "storage";


	/**
	 * The Private Constructor.
	 */
	private CommerceConstants() {
	}

}
