package com.verizon.value.aem.core.models;


import com.adobe.cq.dam.cfm.converter.ContentTypeConverter;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.search.QueryBuilder;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonValue;
import com.verizon.value.aem.core.utils.BaseExporter;
import com.verizon.value.aem.core.utils.ContentFragmentExporterUtils;
import com.verizon.value.aem.core.utils.ContentFragmentUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Session;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = {ComponentExporter.class},
        resourceType = ContentFragmentListExporter.RESOURCE_TYPE,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class ContentFragmentListExporter extends BaseExporter implements ComponentExporter {

    static final String RESOURCE_TYPE = "onevz-value-soe-aem/components/content/contentfragmentlist";
    private static final Logger log = LoggerFactory.getLogger(ContentFragmentListExporter.class);
    protected boolean requireChildObjName = false;
    protected String childAttVale = "";

    private List<Map<String, Object>> content;

    @Inject
    private ContentTypeConverter contentTypeConverter;

    @SlingObject
    private ResourceResolver resourceResolver;

    @ValueMapValue
    private String modelPath;

    @ValueMapValue
    private String parentPath;

    @ValueMapValue
    private String nestedJson;

    @ValueMapValue
    private String childObjectName;

    @ValueMapValue
    private String[] elementNames;

    @ValueMapValue
    private String variationName;

    @Inject
    private QueryBuilder queryBuilder;

    @PostConstruct
    private void initModel() {
        content = new ArrayList<>();
        if (nestedJson == null) {
            nestedJson = "false";
        }
        if (StringUtils.isNotEmpty(parentPath)) {
            try {
                String[] selectorArray = request.getRequestPathInfo().getSelectors();
                Resource parentResource = resourceResolver.getResource(parentPath);
                getContentFragmentList(parentResource, selectorArray);
            } catch (Exception ex) {
                log.error("Error while fetching Fragment Path List Info for {}", parentPath, ex);
            }
        }
    }

    private void getContentFragmentList(Resource parentResource, String[] selectorArray) {
        if (parentResource != null) {
            Iterable<Resource> contentFragmentsList = parentResource.getChildren();

            if (childObjectName != null) {
                requireChildObjName = true;
                childAttVale = childObjectName;
            }

            if (selectorArray.length > 1) {
                Session session = resolver.adaptTo(Session.class);
                Iterator<Resource> queryResult = ContentFragmentUtils.runQueryBuilder(parentPath, queryBuilder, session, ContentFragmentUtils.parseSelectors(selectorArray));
                contentFragmentsList = ContentFragmentUtils.convertToIterableFromIterator(queryResult);
            }

            Resource fragmentResource;
            Iterator<Resource> iterator = contentFragmentsList.iterator();
            Map<String, Object> tempContent;
            while (iterator.hasNext()) {
                fragmentResource = iterator.next();
                tempContent = ContentFragmentExporterUtils.generateContent(
                        ContentFragmentExporterUtils.getExportedElements(fragmentResource, elementNames, variationName, contentTypeConverter),
                        nestedJson, resourceResolver);
                if (!tempContent.isEmpty()) {
                    content.add(tempContent);
                }
            }
        } else {
            log.error("Parent path {} not resolved", parentPath);
        }
    }

    @Override
    @JsonIgnore
    @Nonnull
    public String getExportedType() {
        return "";
    }

    @JsonValue
    public List<Map<String, Object>> getListItems() {
        return content;
    }
}
