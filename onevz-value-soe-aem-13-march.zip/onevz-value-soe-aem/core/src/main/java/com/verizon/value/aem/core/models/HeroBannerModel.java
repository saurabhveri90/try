package com.verizon.value.aem.core.models;

import com.adobe.cq.export.json.ComponentExporter;

public interface HeroBannerModel extends ComponentExporter {

	String getColumn2width();

	String getHeading();

	String getEyebrowtextHeading();

	String getDescription();

	String getColumn1width();

	String getImgPath();

	String getTabimgPath();

	String getMobimgPath();

	String getTooltipMsg();

}
