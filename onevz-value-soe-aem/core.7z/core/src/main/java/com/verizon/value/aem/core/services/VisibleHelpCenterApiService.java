package com.verizon.value.aem.core.services;

public interface VisibleHelpCenterApiService {

    public String getCategoryApiUrl();

    public String getTrendingApiUrl();

    public String getArticleApiUrl();

    String getPrefixPath();
}
