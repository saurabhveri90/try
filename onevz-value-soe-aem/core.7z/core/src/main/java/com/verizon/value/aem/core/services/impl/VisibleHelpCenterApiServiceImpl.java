package com.verizon.value.aem.core.services.impl;

import com.verizon.value.aem.core.services.VisibleHelpCenterApiService;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@Component(service = VisibleHelpCenterApiService.class, immediate = true)
@Designate(ocd = VisibleHelpCenterApiServiceImpl.Config.class)
public class VisibleHelpCenterApiServiceImpl implements VisibleHelpCenterApiService {

    private String categoryApiUrl;
    private String trendingApiUrl;
    private String articleApiUrl;

    private String prefixPath;

    @ObjectClassDefinition(name="OneVZ Help Center Api Url OSGI Config Service")
    @interface Config {
        @AttributeDefinition(name = "Trending Api Url", description = "Trending Api Url", type = AttributeType.STRING)
        String trendingApiUrl() default "/v2/helpcenter/articles/trending";

        @AttributeDefinition(name = "Article Api Url", description = "Article Api Url", type = AttributeType.STRING)
        String articleApiUrl() default "/v2/helpcenter/articles";

        @AttributeDefinition(name = "Category Api Url", description = "Category Api Url", type = AttributeType.STRING)
        String categoryApiUrl() default "/v2/helpcenter/categoryhelp";

        @AttributeDefinition(name= "Prefix Path", description = "Content Prefix Path")
        String prefixPath() default "/content/visible-aem";
    }

    @Activate
    protected void activate(Config config) {
        this.trendingApiUrl = config.trendingApiUrl();
        this.articleApiUrl = config.articleApiUrl();
        this.categoryApiUrl = config.categoryApiUrl();
        this.prefixPath = config.prefixPath();
    }
    @Override
    public String getCategoryApiUrl() {
        return categoryApiUrl;
    }

    @Override
    public String getTrendingApiUrl() {
        return trendingApiUrl;
    }

    @Override
    public String getArticleApiUrl() {
        return articleApiUrl;
    }

    @Override
    public String getPrefixPath() {return prefixPath; }
}
