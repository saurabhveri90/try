package com.verizon.value.aem.core.models;

public interface VisibleHelpCenterConfigModel {

    public String getCategoryApiUrl();

    public String getTrendingApiUrl();

    public String getArticleApiUrl();

    public String getPrefixPath();

}
