package com.verizon.value.aem.core.models;

import com.adobe.cq.dam.cfm.converter.ContentTypeConverter;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonValue;
import com.verizon.value.aem.core.utils.BaseExporter;
import com.verizon.value.aem.core.utils.ContentFragmentExporterUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Created by esthara on 9/3/2020.
 */
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = {ComponentExporter.class},
        resourceType = ContentFragmentMultiExporter.RESOURCE_TYPE,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class ContentFragmentMultiExporter extends BaseExporter implements ComponentExporter {
    static final String RESOURCE_TYPE = "onevz-value-soe-aem/components/content/contentfragmentmulti";
    private static final Logger log = LoggerFactory.getLogger(ContentFragmentMultiExporter.class);
    protected List<Map<String, Object>> content = new ArrayList<>();

    @Inject
    private ContentTypeConverter contentTypeConverter;

    @SlingObject
    private ResourceResolver resourceResolver;

    @ValueMapValue
    private String cfmAttributeName;

    @ValueMapValue
    private String nestedJson;

    @ValueMapValue
    private String childObjectName;

    @ValueMapValue
    private String[] elementNames;

    @ValueMapValue
    private String variationName;

    @PostConstruct
    private void initModel() {
        if (nestedJson == null) {
            nestedJson = "false";
        }
        try {
            final String requestPath = resource.getPath();
            final Resource multiresource = resolver.getResource(requestPath + "/multicfs");
            if (multiresource != null && multiresource.hasChildren()) {
                    Iterator<Resource> iterator = multiresource.getChildren().iterator();
                    Resource fragmentResource;
                    while (iterator.hasNext()) {
                        String cfpath = iterator.next().getValueMap().get("cfpath", null);
                        fragmentResource = resolver.getResource(cfpath);
                        content.add(ContentFragmentExporterUtils.generateContent(ContentFragmentExporterUtils.getExportedElements(fragmentResource, elementNames, variationName, contentTypeConverter), nestedJson, resourceResolver));
                    }

            }

        } catch (Exception ex) {
            log.error("Error while fetching CFs path from multiField. {}", ex.getMessage());
        }
    }

    @Override
    @JsonIgnore
    @Nonnull
    public String getExportedType() {
        return "";
    }

    @JsonValue
    public List<Map<String, Object>> getListItems() {
        return content;
    }
}
