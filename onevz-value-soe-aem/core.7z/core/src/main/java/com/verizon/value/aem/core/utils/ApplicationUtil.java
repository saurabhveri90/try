package com.verizon.value.aem.core.utils;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.verizon.value.aem.core.constants.ApplicationConstants;

/**
 * <p>
 * Utility file to get values for OSGI Configurations
 * </p>
 * 
 */
public final class ApplicationUtil {

	private static final Logger logger = LoggerFactory.getLogger(ApplicationUtil.class);

	/**
	 * Private Constructor.
	 */
	private ApplicationUtil() {
	}

	/**
	 * <p>
	 * This method will check if the link is an internal link or not. If it starts
	 * with /content/, it is an internal link
	 * </p>
	 * 
	 * @param linkStr - link string
	 * @return boolean - true if it is an internal link
	 */
	public static Boolean isInternalLink(final String linkStr) {
		Boolean isInternal = false;
		isInternal = StringUtils.startsWith(linkStr, ApplicationConstants.INTERNAL_LINK_PATH);
		return isInternal;
	}
	
	/**
	 * Returns the Link No follow value.
	 *
	 * @param link         - The authored link.
	 * @param ignoreValues - The links to ignore.
	 * @return processed no-follow value.
	 */
	public static String getNoFollow(final String noFollowLink) {

		if (noFollowLink != null && noFollowLink.equalsIgnoreCase(ApplicationConstants.TRUE))
			return ApplicationConstants.NO_FOLLOW;
		else
			return ApplicationConstants.FOLLOW;

	}
	
	/**
	 * <p>
	 * Returns the lower case value and replace blank space with hyphen.
	 * </p>
	 *
	 * @param ctaText - cta text which needs to convert
	 ** @return String - processed ctaText value.
	 */
	public static String getLowerCaseWithHyphen(final String ctaText) {
		String ctaTextValue = ctaText;
		if (StringUtils.isNotBlank(ctaText))
			ctaTextValue = ctaText.replaceAll(ApplicationConstants.SPACE_REGEX, ApplicationConstants.HYPHEN)
					.toLowerCase();
		return ctaTextValue;
	}
	
	public static String getShortUrl(ResourceResolver resolver, String url) {
		String ctaPath = "";
		if (StringUtils.isNotEmpty(url)) {
			if (ApplicationUtil.isInternalLink(url) && url.indexOf(ApplicationConstants.HTML_EXTENSION) == -1 && url.lastIndexOf(".csv") == -1) {
				url = url + ApplicationConstants.HTML_EXTENSION;
			}
			ctaPath = StringUtils.startsWith(url, "#") ? url : resolver.map(url);
			if (StringUtils.isEmpty(ctaPath)) {
				ctaPath = url;
			}
		}
		return ctaPath;
	}
	
	/**
	 * <p>
	 * Returns the lower case value and replace blank space with underscore.
	 * </p>
	 *
	 * @param ctaText - cta text which needs to convert
	 ** @return String - processed ctaText value.
	 */
	public static String getLowerCaseWithUnderScore(final String ctaText) {
		String ctaTextValue = ctaText;
		if (StringUtils.isNotBlank(ctaText))
			ctaTextValue = ctaText
					.replaceAll(ApplicationConstants.ALL_SPECIAL_CHAR_REGEX, ApplicationConstants.UNDERSCORE)
					.toLowerCase();
		return ctaTextValue;
	}
}
