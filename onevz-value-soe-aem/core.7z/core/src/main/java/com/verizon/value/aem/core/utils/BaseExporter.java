package com.verizon.value.aem.core.utils;


import aQute.bnd.annotation.ConsumerType;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ContainerExporter;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.scripting.SlingScriptHelper;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;

import java.util.Collections;
import java.util.Map;

/**
 * Refer:
 * https://helpx.adobe.com/experience-manager/6-3/release-notes/json-exporter-dev-fp.html
 */
@ConsumerType
public abstract class BaseExporter implements ContainerExporter {

	@SlingObject
    public SlingHttpServletRequest request;

	@SlingObject
	protected ResourceResolver resolver;

	@SlingObject
    public Resource resource;
	
	@SlingObject
	protected SlingScriptHelper scriptHelper;

	@Override
	public Map<String, ? extends ComponentExporter> getExportedItems() {
		return Collections.emptyMap();
	}

	@Override
	public String[] getExportedItemsOrder() {
		Map<String, ? extends ComponentExporter> models = getExportedItems();

		if (models.isEmpty()) {
			return ArrayUtils.EMPTY_STRING_ARRAY;
		}

		return models.keySet().toArray(ArrayUtils.EMPTY_STRING_ARRAY);
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	protected ContentNode toContentNode(Resource aResource) {
		return ContentNode.newBuilder().withResolver(resolver).withResource(aResource).build();
	}
}
