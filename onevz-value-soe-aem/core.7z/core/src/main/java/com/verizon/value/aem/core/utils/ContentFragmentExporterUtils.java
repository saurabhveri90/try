package com.verizon.value.aem.core.utils;

import com.adobe.cq.dam.cfm.ContentElement;
import com.adobe.cq.dam.cfm.ContentFragment;
import com.adobe.cq.dam.cfm.ContentVariation;
import com.adobe.cq.dam.cfm.converter.ContentTypeConverter;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.verizon.value.aem.core.models.DAMContentFragment;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class ContentFragmentExporterUtils {
    static final String PIPE_REGEX = "\\|\\|";
    private static final Logger log = LoggerFactory.getLogger(ContentFragmentExporterUtils.class);
    private static final String MASTER_VARIATION = "master";

    public static String[] processMultiFieldType(String[] mapEntry) {
        ArrayList<String> parsedMultiValue = new ArrayList<>();
        try {
            if (mapEntry.length > 0) {
                parsedMultiValue = new ArrayList<>();
                for (String values : mapEntry) {
                    if (values.contains("||")) {
                        for (String temp : values.split(PIPE_REGEX)) {
                            Arrays.asList(parsedMultiValue.add(temp));
                        }
                    } else {
                        parsedMultiValue.add(values);
                    }
                }
            }
        } catch (Exception e) {
            log.error("Exception at extracting the values of - {}",  mapEntry[0] + " w/ error-" + e.getMessage());
        }
        return parsedMultiValue.toArray(new String[parsedMultiValue.size()]);
    }


    public static List<Map<String, Object>> processContentFragmentReference(Map.Entry<String,
            DAMContentFragment.DAMContentElement> mapEntry, ResourceResolver resourceResolver) {
        List<Map<String, Object>> nestedCFs = new ArrayList<>();
        String[] multiValue = (String[]) mapEntry.getValue().getValue();
        Resource fragmentResource;
        try {
            if (multiValue.length > 0) {
                for (String values : multiValue) {
                    fragmentResource = resourceResolver.getResource(values);
                    Map<String, DAMContentFragment.DAMContentElement> exportedElements =
                            ContentFragmentExporterUtils.getExportedElements(fragmentResource,
                                    null, MASTER_VARIATION, null);
                    nestedCFs.add(generateContent(exportedElements, "false", resourceResolver));
                }
            }
        } catch (Exception e) {
            log.error("Exception at extracting the values of- {}", mapEntry.getKey() + "and value-" +
                    Arrays.toString(multiValue) + " w/ error-" + e.getMessage());
        }
        return nestedCFs;
    }

    public static Map<String, Object> generateContent(Map<String,
            DAMContentFragment.DAMContentElement> exportedElements, String nestedjson,
                                                      ResourceResolver resourceResolver) {
        Map<String, Object> content = new HashMap<>();
        if (MapUtils.isNotEmpty(exportedElements)) {
            try {
                if (nestedjson.equalsIgnoreCase("true")) {
                    content = getNestedJson(exportedElements, resourceResolver);
                } else {
                    Iterator<?> iterator = exportedElements.entrySet().iterator();
                    getGeneratedContent(resourceResolver, iterator, content);
                }
            } catch (Exception e) {
                log.error("Exception at extracting the values for of CFs w/ error -{}", e.getMessage());
            }
        }
        return content;
    }

    private static void getGeneratedContent(ResourceResolver resourceResolver, Iterator<?> iterator, Map<String, Object> content) {
        while (iterator.hasNext()) {
            Map.Entry<String, DAMContentFragment.DAMContentElement> mapEntry = (Map.Entry<String, DAMContentFragment.DAMContentElement>) iterator.next();

            /** Process nested content fragment references */
            if (mapEntry.getValue().getDataType().contains("content-fragment")) {
                content.put(mapEntry.getKey(), processContentFragmentReference(mapEntry, resourceResolver));
            }

            /** Process multi-field data type*/
            else if (mapEntry.getValue().isMultiValue() && mapEntry.getValue().getValue() != null) {
                updateMapWithMultiValue(mapEntry, content);
            }

            /** Process Json object data type*/
            else if (mapEntry.getValue().getDataType().equalsIgnoreCase("json")) {
                processExtractedJson(content, mapEntry);
            }

            /** Process all other data types*/
            else {
                if (mapEntry.getValue().getValue() != null) {
                    content.put(mapEntry.getKey(), mapEntry.getValue().getValue());
                }
            }
        }
    }

    private static void processExtractedJson(Map<String, Object> content, Map.Entry<String, DAMContentFragment.DAMContentElement> mapEntry) {
        ObjectMapper objectMapper;
        if (mapEntry.getValue().getValue().toString().trim().startsWith("{") && mapEntry.getValue().getValue().toString().trim().endsWith("}")) {
            objectMapper = new ObjectMapper();
            objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
            try {
                content.put(mapEntry.getKey(), (objectMapper.readValue(mapEntry.getValue().getValue().toString().trim(),
                        new TypeReference<Map<String, Object>>() {
                        })));
            } catch (JsonProcessingException e) {
                log.error("Json Processing error:::{}", e.getMessage());
            }
        } else if (mapEntry.getValue().toString().trim().startsWith("[") && mapEntry.getValue().toString().trim().endsWith("]")) {
            try {
                objectMapper = new ObjectMapper();
                objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
                content.put(mapEntry.getKey(), (objectMapper.readValue(mapEntry.getValue().toString().trim(),
                        new TypeReference<List<Object>>() {
                        })));
            } catch (Exception e) {
                log.error("Exception for extracting the values {}", e.getMessage());
            }
        } else {
            content.put(mapEntry.getKey(), mapEntry.getValue().getValue());
        }
    }

    public static Map<String, Object> getNestedJson(Map<String, DAMContentFragment.DAMContentElement> exportedElements, ResourceResolver resourceResolver) {
        Map<String, Object> content = new HashMap<>();
        String propName;

        Iterator<?> iterator = exportedElements.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, DAMContentFragment.DAMContentElement> mapEntry = (Map.Entry<String, DAMContentFragment.DAMContentElement>) iterator.next();
            propName = mapEntry.getKey();
            try {
                /** Process nested content fragment references */
                if (mapEntry.getValue().getDataType().contains("content-fragment")) {
                    content.put(mapEntry.getKey(), processContentFragmentReference(mapEntry, resourceResolver));
                }

                /** Process multi-field data type*/
                else if (mapEntry.getValue().isMultiValue()) {
                    updateMapWithMultiValue(mapEntry, content);
                }

                /** Process all other data types*/
                else {
                    if (mapEntry.getValue().getValue() != null) {
                        propName = propName.replaceAll("(?<!_)_(?!_)", "=").replace("-", ".");

                        updatePropName(propName, content, mapEntry);
                    }
                }
            } catch (Exception e) {
                log.error("Exception at parsing the CF props.{}", e.getMessage());
            }
        }

        /** Un-flatten the flattened json objects. */
        try {
            JsonNode json = new ObjectMapper().valueToTree(content);
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
            return objectMapper.readValue(NestedJsonUnflattener.unflatten(json),
                    new TypeReference<Map<String, Object>>() {
                    });
        } catch (Exception e) {
            log.error("Exception while un-flattening Json w/ error-{}", e.getMessage());
        }
        return Collections.emptyMap();
    }

    private static void updatePropName(String propName, Map<String, Object> content, Map.Entry<String, DAMContentFragment.DAMContentElement> mapEntry) {
        if (StringUtils.countMatches(propName, "..") > 0) {
            content.put(propName.replace("..", "-"), mapEntry.getValue().getValue());
        } else {
            content.put(propName, mapEntry.getValue().getValue());
        }
    }

    private static void updateMapWithMultiValue(Map.Entry<String, DAMContentFragment.DAMContentElement> mapEntry, Map<String, Object> content) {
        if (Boolean.TRUE.equals(isStringJson((String[]) mapEntry.getValue().getValue()))) {
            content.put(mapEntry.getKey(), stringToJson(processMultiFieldType((String[]) mapEntry.getValue().getValue())));
        } else {
            content.put(mapEntry.getKey(), processMultiFieldType((String[]) mapEntry.getValue().getValue()));
        }
    }

    public static Map<String, DAMContentFragment.DAMContentElement> getExportedElements(Resource fragmentResource, String[] elementNames, String variationName, ContentTypeConverter contentTypeConverter) {
        ContentFragment contentFragment = fragmentResource.adaptTo(ContentFragment.class);
        Map<String, DAMContentFragment.DAMContentElement> exportedElements = new LinkedHashMap<>();
        if (contentFragment == null) {
            log.error("Content Fragment can not be initialized because '{}' is not a content fragment.",
                    fragmentResource.getPath());
        } else {
            final Iterator<ContentElement> contentElementIterator =
                    ContentFragmentUtils.filterElements(contentFragment, elementNames);

            // Wrap elements and get their configured variation (if any)

            while (contentElementIterator.hasNext()) {
                final ContentElement contentElement = contentElementIterator.next();
                ContentVariation variation = null;
                if (StringUtils.isNotEmpty(variationName) && !MASTER_VARIATION.equals(variationName)) {
                    variation = contentElement.getVariation(variationName);
                    if (variation == null) {
                        log.warn("Non-existing variation '{}' of element '{}'", variationName, contentElement.getName());
                    }
                }
                exportedElements.put(contentElement.getName(),
                        new DAMContentFragment.DAMContentElement(contentTypeConverter, contentElement, variation));
            }
        }
        return exportedElements;
    }

    public static Boolean isStringJson(String[] props) {
        return props[0].trim().startsWith("{") && props[0].trim().endsWith("}");
    }

    public static Object stringToJson(String[] stringJson) {
        List<Object> finalJson = new ArrayList<>();
        Map<String, Object> jsonMap = new HashedMap();
        ObjectMapper objectMapper;
        try {
            for (String val : stringJson) {
                objectMapper = new ObjectMapper();
                objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
                jsonMap = (objectMapper.readValue(val,
                        new TypeReference<Map<String, Object>>() {
                        }));
                finalJson.add(jsonMap);
            }

        } catch (Exception e) {
            jsonMap.put("error", e.getMessage());
            log.error("Exception at converting StringToJson w/ error- {}", e.getMessage());
        }
        return finalJson;
    }
    
}
