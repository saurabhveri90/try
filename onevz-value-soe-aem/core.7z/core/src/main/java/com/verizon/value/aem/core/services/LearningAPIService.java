package com.verizon.value.aem.core.services;

public interface LearningAPIService {

    public String getBaseEndpointUrl();

    public String getToken();
}
