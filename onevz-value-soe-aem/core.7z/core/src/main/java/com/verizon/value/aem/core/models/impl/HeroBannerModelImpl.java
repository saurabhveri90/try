package com.verizon.value.aem.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.verizon.value.aem.core.models.HeroBannerModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { HeroBannerModel.class,
		ComponentExporter.class }, resourceType = "value-aem/components/core/content/herobanner", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class HeroBannerModelImpl implements HeroBannerModel {

	
	@Self
	private SlingHttpServletRequest request;
	
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
	@ValueMapValue
	private String eyebrowtextHeading;
	
	@ValueMapValue
	private String heading;
	
	@ValueMapValue
	private String description;
	
	@ValueMapValue
	private String column1width;
	
	@ValueMapValue
	private String column2width;
	
	@ValueMapValue
	private String imgPath;
	
	@ValueMapValue
	private String tabimgPath;
	
	@ValueMapValue
	private String mobimgPath;
	
	@ValueMapValue
	private String tooltipid;
	
	@ValueMapValue
	private String tooltipMsg;

	@Override
	public String getEyebrowtextHeading() {
		return eyebrowtextHeading;
	}

	@Override
	public String getHeading() {
		return heading;
	}

	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public String getColumn1width() {
		return column1width;
	}

	@Override
	public String getColumn2width() {
		return column2width;
	}

	@Override
	public String getImgPath() {
		return imgPath;
	}

	@Override
	public String getTabimgPath() {
		return tabimgPath;
	}

	@Override
	public String getMobimgPath() {
		return mobimgPath;
	}

	public String getTooltipid() {
		return tooltipid;
	}

	@Override
	public String getTooltipMsg() {
		return tooltipMsg;
	}
}
