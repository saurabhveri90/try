package com.verizon.value.aem.core.services;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@Component(service = LearningAPIService.class, immediate = true)
@Designate(ocd= LearningAPIServiceImpl.Configuration.class)
public class LearningAPIServiceImpl implements LearningAPIService{


    private volatile String baseEndpointUrl;
    private volatile String tokenKey;



    @ObjectClassDefinition(name = "Verizon Learning API Config", description = "Endpoint Details of Verizon Learning API")
    public @interface Configuration {

        @AttributeDefinition(name = "Base Endpoint URL", description = "Provide the Base endpoint url for Learning API")
        String baseEndpointUrl() default "";

        @AttributeDefinition(name = "Token Key", description = "Provide the Token Key for Learning API")
        String tokenKey() default "";
    }

    @Activate
    protected void activate(final Configuration configuration){
        baseEndpointUrl = configuration.baseEndpointUrl();
        tokenKey = configuration.tokenKey();
    }

    @Override
    public String getBaseEndpointUrl() {
        return baseEndpointUrl;
    }

    @Override
    public String getToken() {
        return tokenKey;
    }


}
