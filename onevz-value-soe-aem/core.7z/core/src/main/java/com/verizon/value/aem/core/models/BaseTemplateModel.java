package com.verizon.value.aem.core.models;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.verizon.value.aem.core.services.PreConnectOSGIConfigService;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.*;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.Arrays;
import java.util.Objects;
import java.util.stream.Stream;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class BaseTemplateModel {

    private static final Logger log = LoggerFactory.getLogger(BaseTemplateModel.class);

    @Self
    private Resource resource;

    @Inject
    @OSGiService
    private PreConnectOSGIConfigService preConnectOSGIConfigService;

    private String[] preconnectPath;

    private String[] dnsprefetchPath;

    private String[] preconnectCombinedPath;

    private String[] dnsprefetchPathCombined;

    @PostConstruct
    protected void init() throws PersistenceException {
        PageManager pm = resource.getResourceResolver().adaptTo(PageManager.class);
        Page page = pm.getContainingPage(resource);
        log.info("Page Path :::"+page.getPath());
        log.info("Resource:::"+resource.getPath()+resource.getParent().getPath());
        ValueMap vm = page.getProperties();
        preconnectPath = vm.get("preconnectPath", String[].class);
        dnsprefetchPath = vm.get("dnsprefetchPath", String[].class);
        preconnectCombinedPath = updateValuesforProperties(vm, page, preconnectPath, preconnectCombinedPath,"preconnectPath");
        dnsprefetchPathCombined = updateValuesforProperties(vm, page, dnsprefetchPath, dnsprefetchPathCombined, "dnsprefetchPath");
    }

    private String[] updateValuesforProperties(ValueMap vm, Page page, String[] preconnectPath, String[] preconnectCombinedPath, String property) throws PersistenceException {
        if(Objects.isNull(preconnectPath)) {
                preconnectPath = preConnectOSGIConfigService.getPreConnectPaths();
                log.info("preconnect Path::"+preconnectPath);
                if(page.getContentResource()!=null){
                    log.info("Page Resource::"+ page.getContentResource());
                    page.getContentResource().adaptTo(ModifiableValueMap.class).put(property, preconnectPath);
                    resource.getResourceResolver().commit();
                }
            preconnectCombinedPath = preconnectPath;
            } else {
                preconnectCombinedPath = vm.get(property, String[].class);
                if(preconnectCombinedPath.length!=0){
                    if(page.getContentResource()!=null){
                        log.info("inside null check");
                        page.getContentResource().adaptTo(ModifiableValueMap.class).put(property, preconnectCombinedPath);
                        resource.getResourceResolver().commit();
                    }
                }
            }
        return preconnectCombinedPath;
    }

    public String[] getPreconnectPath() {
        return preconnectCombinedPath;
    }
    public String[] getDnsprefetchPath() {
        return dnsprefetchPath;
    }

}
