/**
 * 
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;

/**
 * Defines the {@code DisclaimerModel} Sling Model used for the {@code /apps/tracfone-core/components/content/disclaimercf} component.
 */
public interface DisclaimerModel extends ComponentExporter {
	
	/**
	 * Get the exportedType
	 * 
	 * @return String - exportedType
	 */
	public String getExportedType();

	/**
	 * Get the cfPath
	 * 
	 * @return String - cfPath
	 */
	public String getCfPath();
	
	/**
	 * Get the disclaimerType
	 * 
	 * @return String - disclaimerType
	 */
	public String getDisclaimerType();
	
	/**
	 * Get the disclaimerName
	 * 
	 * @return String - disclaimer Name
	 */
	public String getDisclaimerName();
	
	/**
	 * Get the disclaimerId
	 * 
	 * @return String - disclaimerId
	 */
	public String getDisclaimerId();
	
	/**
	 * Get the ariaLabel
	 * 
	 * @return String - ariaLabel
	 */
	public String getAriaLabel();
	
	/**
	 * Get the disclaimerText
	 * 
	 * @return String - disclaimerText
	 */
	public String getDisclaimerText();
	
}
