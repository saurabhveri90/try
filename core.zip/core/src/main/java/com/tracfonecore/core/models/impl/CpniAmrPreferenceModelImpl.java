package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.List;
import com.tracfonecore.core.beans.LinkBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.CpniAmrPreferenceModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;
import com.day.cq.wcm.api.Page;


import javax.inject.Inject;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CpniAmrPreferenceModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/cpniamr", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CpniAmrPreferenceModelImpl implements CpniAmrPreferenceModel {
	
	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue
	private String heading;

	@ValueMapValue
	private String summary;

	@ValueMapValue
	private String subHeading;

	@ValueMapValue
	private String textFieldHeading;

	@ValueMapValue
	private String inputFieldPlaceholder;

	@ValueMapValue
	private String dontShareLabel;

	@ValueMapValue
	private String shareLabel;

	@Inject
	private Resource resource;

	@ValueMapValue
	private String buttonLabel;

	@Inject
	private Page currentPage;

	@Inject
	private ApplicationConfigService applicationConfigService;

	/**
	 * Inject disableEnterpriseCaptcha
	 */
	@Inject
	@Via("resource")
	private String disableEnterpriseCaptcha;

	/**
     * @return String - heading
     */
	@Override
	public String getHeading() {
		return heading;
	}

	/**
     * @return String - getSummary
     */
	@Override
	public String getSummary() {
		return summary;
	}

	/**
     * @return String - exported Type
     */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
     * @return String - subHeading
     */
	@Override
	public String getSubHeading() {
		return subHeading;
	}

	/**
     * @return String - getTextFieldHeading
     */
	@Override
	public String getTextFieldHeading() {
		return textFieldHeading;
	}

	/**
     * @return String - getInputFieldPlaceholder
     */
	@Override
	public String getInputFieldPlaceholder() {
		return inputFieldPlaceholder;
	}

	/**
     * @return String - getDontShareLabel
     */
	@Override
	public String getDontShareLabel() {
		return dontShareLabel;
	}

	/**
     * @return String - getShareLabel
     */
	@Override
	public String getShareLabel() {
		return shareLabel;
	}

	/**
	 * @return String - getButtonLabel
	 */
	@Override
	public String getButtonLabel() {
		return buttonLabel;
	}

	/**
	 * <p>
	 * Returns disableEnterpriseCaptcha from properties
	 * </p>
	 * @return the disableEnterpriseCaptcha
	 */
	@Override
	public String getDisableEnterpriseCaptcha() {
		return disableEnterpriseCaptcha;
	}

	/**
	 * <p>
	 * Fetches ReCaptcha SiteKey property from config
	 * </p>
	 *
	 * @return String[] - reCaptchaSiteKey
	 */
	@Override
	public String getReCaptchaEnterpriseSiteKey() {
		return ConfigurationUtil.getConfigValue(applicationConfigService.getReCaptchaEnterpriseSiteKey(), CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}

	/**
	 * <p>
	 * Fetches ReCaptcha SiteKey property from config
	 * </p>
	 *
	 * @return String[] - reCaptchaSiteKey
	 */
	@Override
	public String getReCaptchaSiteKey() {
		return ConfigurationUtil.getConfigValue(applicationConfigService.getReCaptchaSiteKey(), CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}

}
