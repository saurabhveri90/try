package com.tracfonecore.core.models.impl;
import com.tracfonecore.core.models.UnsubscribeEmailModel;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.ComponentExporter;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import javax.inject.Inject;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.utils.ApplicationUtil;

@Model(adaptables = {SlingHttpServletRequest.class, Resource.class }, adapters = {UnsubscribeEmailModel.class,ComponentExporter.class}, 
      resourceType = "tracfone-core/components/spa/commerce/unsubscribe", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class UnsubscribeEmailModelImpl implements UnsubscribeEmailModel{
    
    	private static final Logger LOGGER = LoggerFactory.getLogger(UnsubscribeEmailModelImpl.class);

	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue
	private String heading;

    @ValueMapValue
    private String unsubtext;

    @ValueMapValue
    private String unsubremindertext;

    @ValueMapValue
    private String additionalinfotext;

    @ValueMapValue
    private String enteremailtext;

    @ValueMapValue
    private String emailinputtext;

    @ValueMapValue
    private String unsubscribesuccessmessageheading;

    @ValueMapValue
    private String unsubscribesuccessmessagedescription;

	@ValueMapValue
	private String unsubscribeImageFileReference;

	@ValueMapValue
	private String unsubscribeImageAltText;

	@ValueMapValue
	private String unsubscribeSampleEmailId;

	@ValueMapValue
	private String emailIdLabelText;
	@Override
	public String getExportedType() {

		return request.getResource().getResourceType();
	}

    /**
	 * @return the heading
	 */
	@Override
	public String getHeading() {
		return heading;
	}

    /** 
	 * @return String - unsubtext
	 */
    @Override
    public String getUnsubText() {
        return unsubtext;
    }

    /** 
	 * @return String - unsubremindertext
	 */
    @Override
    public String getUnsubReminderText() {
        return unsubremindertext;
    }

    /** 
	 * @return String - additionalinfotext
	 */
    @Override
    public String getAdditionalInfoText() {
        return additionalinfotext;
    }

    /** 
	 * @return String - enteremailtext
	 */
    @Override
    public String getEnterEmailText() {
        return enteremailtext;
    }

    /** 
	 * @return String - emailinputtext
	 */
    @Override
    public String getEmailInputText() {
        return emailinputtext;
    }

    /** 
	 * @return String - unsubscribesuccessmessageheading
	 */
    @Override
    public String getUnsubscribeSuccessMessageHeading() {
        return unsubscribesuccessmessageheading;
    }

    /** 
	 * @return String - unsubscribesuccessmessagedescription
	 */
    @Override
    public String getUnsubscribeSuccessMessageDescription() {
        return unsubscribesuccessmessagedescription;
    }

    /** 
	 * @return String - unsubscribeImageFileReference
	 */
	@Override
	public String getUnsubscribeImageFileReference() {
		return unsubscribeImageFileReference;
	}

    /** 
	 * @return String - unsubscribeImageAltText
	 */
	@Override
	public String getUnsubscribeImageAltText() {
		return unsubscribeImageAltText;
	}

    /** 
	 * @return String 
	 */
	@Override
	public String getUnsubscribeImageAssetId() {
		return ApplicationUtil.getAssetId(unsubscribeImageFileReference,
				request.getResourceResolver(), ApplicationConstants.IMAGE);
	}
	
    /** 
	 * @return String
	 */
	@Override
	public String getUnsubscribeImageAgencyId() {
		return ApplicationUtil.getAssetMetaDataValue(unsubscribeImageFileReference,
				request.getResourceResolver(), ApplicationConstants.WEBER_ID);
	}

    /** 
	 * @return String - unsubscribeSampleEmailId
	 */
    @Override
    public String getUnsubscribeSampleEmailId() {
        return unsubscribeSampleEmailId;
    }

    /**
	 * @return the emailIdLabelText
	 */
	@Override
	public String getEmailIdLabelText() {
		return emailIdLabelText;
	}

}