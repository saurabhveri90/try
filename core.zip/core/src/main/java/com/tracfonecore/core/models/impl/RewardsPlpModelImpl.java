/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.RewardsPlpModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { RewardsPlpModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/rewardsplp", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class RewardsPlpModelImpl implements RewardsPlpModel {

	@Self
	private SlingHttpServletRequest request;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String categoryIdPlans;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String selectPlanDatePagePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String firstCtaLink;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String firstCtaLabel;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String firstCtaNewWindow;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String secondCtaLink;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String secondCtaLabel;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String secondCtaNewWindow;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String pageHeading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String pageSubHeading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planInfoModalContent;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String errorMessageForInactiveDevices;
	
	@Inject
	private ApplicationConfigService applicationConfigService;
	
    @Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getCategoryIdPlans() {
		return categoryIdPlans;
	}
	
	@Override
	public String getSelectPlanDatePagePath() {
		return ApplicationUtil.getShortUrl(request.getResourceResolver(), selectPlanDatePagePath);
	}

	@Override
	public String getFirstCtaLink() {
		return firstCtaLink;
	}

	@Override
	public String getfirstCtaLabel() {
		return firstCtaLabel;
	}

	@Override
	public String getFirstCtaNewWindow() {
		return firstCtaNewWindow;
	}

	@Override
	public String getSecondCtaLink() {
		return secondCtaLink;
	}

	@Override
	public String getSecondCtaLabel() {
		return secondCtaLabel;
	}

	@Override
	public String getSecondCtaNewWindow() {
		return secondCtaNewWindow;
	}

	public String getPageHeading() {
		return pageHeading;
	}

	public String getPageSubHeading() {
		return pageSubHeading;
	}

	@Override
	public String getPlanInfoModalContent() {
		return planInfoModalContent;
	}

	@Override
	public String getErrorMessageForInactiveDevices() {
		return errorMessageForInactiveDevices;
	}

	@Override
	public String[] getRewardsPLPFacets() {
		return applicationConfigService.getRewardsPLPFacets();
	}
}
