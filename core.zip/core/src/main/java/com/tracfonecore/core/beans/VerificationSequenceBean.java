/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class VerificationSequenceBean {

	
	@Self
	private Resource resource;
	
	/**
	 * Inject imageUrl
	 */
	@ValueMapValue
	private String imageUrl;

	/**
	 * Inject imageAltText
	 */
	@ValueMapValue
	private String imageAltText;
	
	/**
	 * Inject actionImage
	 */
	@ValueMapValue
	private String heading;
	
	/**
	 * Inject subtext
	 */
	@ValueMapValue
	private String subtext;

	/**
	 * helpText
	 */
	@ValueMapValue
	private String helpText;

	/**
	 * @return the imageUrl
	 */
	public String getImageUrl() {
		
		return DynamicMediaUtils.changeMediaPathToDMPath(imageUrl, resource.getResourceResolver());
	}

	/**
	 * @return the imageAltText
	 */
	public String getImageAltText() {
		return imageAltText;
	}

	/**
	 * @return the heading
	 */
	public String getHeading() {
		return heading;
	}

	/**
	 * @return the subtext
	 */
	public String getSubtext() {
		return subtext;
	}

	/**
	 * @return the helpText
	 */
	public String getHelpText() {
		return helpText;
	}

	/**
	 * @return the unchanged imageUrl
	 */
	public String getImagePath() {
		return imageUrl;
	}
}
