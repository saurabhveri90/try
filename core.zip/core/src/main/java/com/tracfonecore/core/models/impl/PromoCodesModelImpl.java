/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.settings.SlingSettingsService;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.PromoCodesModel;
import com.tracfonecore.core.utils.ApplicationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { PromoCodesModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/promocodes", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class PromoCodesModelImpl implements PromoCodesModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headlinePromoCodes;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subheadlinePromoCodes;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String carouselSpeedPromoCodes;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String dotNavigationLengthPromoCodes;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String seeAllPromoCodesLink;

	@Inject
	private SlingSettingsService settingService;

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	private String getShortURL(String serverDomain, String url) {
		if (StringUtils.isNotBlank(url) && StringUtils.isNotBlank(serverDomain) && url.contains(serverDomain)) {
			url = url.split(serverDomain)[1];
		}
		return url;
	}

	@Override
	public String getHeadlinePromoCodes() {
		return headlinePromoCodes;
	}

	@Override
	public String getSubheadlinePromoCodes() {
		return subheadlinePromoCodes;
	}

	@Override
	public String getCarouselSpeedPromoCodes() {
		return carouselSpeedPromoCodes;
	}

	@Override
	public String getDotNavigationLengthPromoCodes() {
		return dotNavigationLengthPromoCodes;
	}

	@Override
	public String getSeeAllPromoCodesLink() {
		String finalSeeAllPromoCodesLink = seeAllPromoCodesLink;
		if (StringUtils.isNotBlank(finalSeeAllPromoCodesLink) && Boolean.TRUE.equals(ApplicationUtil.isInternalLink(finalSeeAllPromoCodesLink))) {
			if (finalSeeAllPromoCodesLink.indexOf(ApplicationConstants.HTML_EXTENSION) == -1) {
				finalSeeAllPromoCodesLink = finalSeeAllPromoCodesLink + ApplicationConstants.HTML_EXTENSION;
			}
			if (StringUtils.isNotBlank(finalSeeAllPromoCodesLink)) {
				String ctaPath = request.getResourceResolver().map(finalSeeAllPromoCodesLink);
				if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
					finalSeeAllPromoCodesLink = ApplicationUtil.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
				}
			}
		}
		return finalSeeAllPromoCodesLink;
	}
}
