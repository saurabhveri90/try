
package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.inject.Inject;
import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.DynamicVasBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.ManageDynamicVasModal;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ManageDynamicVasModal.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/managedynamicvas", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ManageDynamicVasModalImpl implements ManageDynamicVasModal {

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private Resource resource;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String dynamicVasHeading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String dynamicVasSubHeading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String noDynamicVasFoundMsg;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String dynamicVasCategoryId;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String categoryIdHPP;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppPlanImage;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String manageClaimsUrl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String resumeSubCheckoutUrl;

	private List<DynamicVasBean> dynamicVasList = Collections.emptyList();

	@PostConstruct
	private void initModel() {
		dynamicVasList = new ArrayList<>();				
		if (resource != null) {
			getMultifieldResource();
		}
	}

	private void getMultifieldResource() {
		for (Resource child : resource.getChildren()) {
			Iterator<Resource> it = child.listChildren();
			if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.DYNAMIC_VAS_LIST.equals(child.getName())) {
				setDynamicVas(it, dynamicVasList);
			} 
		}
	}

	private void setDynamicVas(Iterator<Resource> it, List<DynamicVasBean> dynamicVasList) {
		while (it.hasNext()) {
			DynamicVasBean dynamicVasBean = new DynamicVasBean();
			Resource grandChild = it.next();
			dynamicVasBean.setDynamicVasPartNumber(
					grandChild.getValueMap().get("dynamicVasPartNumber", String.class));			
			dynamicVasBean.setDynamicVasPlanName(
					grandChild.getValueMap().get("dynamicVasPlanName", String.class));	
			dynamicVasBean.setDynamicVasVendorUrl(
					grandChild.getValueMap().get("dynamicVasVendorUrl", String.class));
			dynamicVasBean.setOpenVendorUrlNewTab(
					grandChild.getValueMap().get("openVendorUrlNewTab", String.class));	
			dynamicVasBean.setDynamicVasIcon(
					grandChild.getValueMap().get("dynamicVasIcon", String.class));
			dynamicVasBean.setDynamicVasIconAltText(
					grandChild.getValueMap().get("dynamicVasIconAltText", String.class));
			dynamicVasBean.setChangePartNumber(
					grandChild.getValueMap().get("changePartNumber", String.class));
			dynamicVasBean.setChangePlanName(
						grandChild.getValueMap().get("changePlanName", String.class));
			dynamicVasBean.setAutoEnrollBtnLabel(
					grandChild.getValueMap().get("autoEnrollBtnLabel", String.class));
			dynamicVasBean.setAutoEnrollBtnAccessibleText(
					grandChild.getValueMap().get("autoEnrollBtnAccessibleText", String.class));	
			dynamicVasBean.setCancelEnrollBtnLabel(
					grandChild.getValueMap().get("cancelEnrollBtnLabel", String.class));
			dynamicVasBean.setCancelEnrollBtnAccessibleText(
					grandChild.getValueMap().get("cancelEnrollBtnAccessibleText", String.class));	
			dynamicVasBean.setVendorUrlAccessibleText(
					grandChild.getValueMap().get("vendorUrlAccessibleText", String.class));
			dynamicVasBean.setSuspendedResumeBtnLabel(
					grandChild.getValueMap().get("suspendedResumeBtnLabel", String.class));
			dynamicVasBean.setSuspendedResumeBtnAccessibleText(
					grandChild.getValueMap().get("suspendedResumeBtnAccessibleText", String.class));
			dynamicVasBean.setCancelledResumeBtnLabel(
					grandChild.getValueMap().get("cancelledResumeBtnLabel", String.class));
			dynamicVasBean.setCancelledResumeBtnAccessibleText(
					grandChild.getValueMap().get("cancelledResumeBtnAccessibleText", String.class));
			dynamicVasBean.setVendorActionMsg(
					grandChild.getValueMap().get("vendorActionMsg", String.class));
			dynamicVasBean.setExpandBtnAccLabel(
					grandChild.getValueMap().get("expandBtnAccLabel", String.class));
			dynamicVasBean.setResumeCancelledMsg(
					grandChild.getValueMap().get("resumeCancelledMsg", String.class));
			dynamicVasBean.setResumeSuspendMsg(
					grandChild.getValueMap().get("resumeSuspendMsg", String.class));
			dynamicVasList.add(dynamicVasBean);
		}
	}

	
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getDynamicVasHeading(){
		return dynamicVasHeading;
	}

	@Override
	public String getDynamicVasSubHeading() {
		return dynamicVasSubHeading;
	}

	@Override
	public String getNoDynamicVasFoundMsg(){
		return noDynamicVasFoundMsg;
	}

	@Override
	public String getDynamicVasCategoryId(){
		return dynamicVasCategoryId;
	}

	@Override
    public String getHppPlanImage() {
         return DynamicMediaUtils.changeMediaPathToDMPath(hppPlanImage, request.getResourceResolver());
    }

	@Override
    public String getManageClaimsUrl() {
         return manageClaimsUrl;
    }

	@Override
	public String getCategoryIdHPP(){
		return categoryIdHPP;
	}

	@Override
	public String getResumeSubCheckoutUrl(){
		return resumeSubCheckoutUrl;
	}

	

	public List<DynamicVasBean> getDynamicVasList() {
		return new ArrayList<>(dynamicVasList);
	}

	
}
