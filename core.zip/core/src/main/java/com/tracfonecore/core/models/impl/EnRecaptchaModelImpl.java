package com.tracfonecore.core.models.impl;
import com.tracfonecore.core.models.EnRecaptchaModel;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;


@Model(adaptables = {SlingHttpServletRequest.class, Resource.class }, adapters = {EnRecaptchaModel.class}, 
      resourceType = "tracfone-core/components/spa/commerce/enRecaptcha", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

public class EnRecaptchaModelImpl implements EnRecaptchaModel{

        private static final Logger LOGGER = LoggerFactory.getLogger(EnRecaptchaModelImpl.class);

    @ValueMapValue
    private String enCaptchaSiteProjectId;

     @ValueMapValue
    private String enCaptchaSiteAPIKey;

      @ValueMapValue
    private String enCaptchaSiteKey;

    @ValueMapValue
    private String enCaptchaSubmitUrl;

    /**
     * @return the heading
     */
    @Override
    public String getEnCaptchaSiteProjectId() {
        return enCaptchaSiteProjectId;
    }

    @Override
    public String getEnCaptchaSiteAPIKey() {
        return enCaptchaSiteAPIKey;
    }

    @Override
    public String getEnCaptchaSiteKey() {
        return enCaptchaSiteKey;
    }

     @Override
    public String getEnCaptchaSubmitUrl() {
        return enCaptchaSubmitUrl;
    }
}