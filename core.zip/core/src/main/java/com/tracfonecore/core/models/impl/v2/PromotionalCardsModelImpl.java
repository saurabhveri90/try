package com.tracfonecore.core.models.impl.v2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.PromotionalCardBean;
import com.tracfonecore.core.beans.ScenarioBasedPromotionalCardBean;
import com.tracfonecore.core.models.PromotionalCardsModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { PromotionalCardsModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/content/promotionalcards/v2/promotionalcards", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class PromotionalCardsModelImpl extends com.tracfonecore.core.models.impl.v1.PromotionalCardsModelImpl implements PromotionalCardsModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;

	@Inject
	private Resource resource;

	private List<PromotionalCardBean> promotionalCardsList = Collections.emptyList();
	private List<ScenarioBasedPromotionalCardBean> scenarioBasedPromotionalCardsList = Collections.emptyList();

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String componentVersion;

	@PostConstruct
	private void initModel() {

		promotionalCardsList = new ArrayList<PromotionalCardBean>();
		scenarioBasedPromotionalCardsList = new ArrayList<ScenarioBasedPromotionalCardBean>();
		if (resource != null) {
			getMultifieldResource();
		}
	}

	private void getMultifieldResource() {
		for (Resource child : resource.getChildren()) {
			Iterator<Resource> it = child.listChildren();
			if (StringUtils.isNotBlank(child.getName()) && "promotionalCards".equals(child.getName())) {
				setPromotionalCardsList(it, promotionalCardsList);
			} else if (StringUtils.isNotBlank(child.getName())
					&& "scenarioBasedPromotionalCards".equals(child.getName())) {
				setScenarioBasedPromotionalCardsList(it, scenarioBasedPromotionalCardsList);
			}
		}
	}

	private void setScenarioBasedPromotionalCardsList(Iterator<Resource> it,
			List<ScenarioBasedPromotionalCardBean> multiFieldData) {
		ScenarioBasedPromotionalCardBean scenarioBasedPromotionalCardBean = null;
		while (it.hasNext()) {
			scenarioBasedPromotionalCardBean = new ScenarioBasedPromotionalCardBean();
			Resource grandChild = it.next();
			scenarioBasedPromotionalCardBean
					.setPurchaseScenario(grandChild.getValueMap().get("purchaseScenario", String.class));
			for (Resource child : grandChild.getChildren()) {
				if ("promotionalCards".equals(child.getName())) {
					Iterator<Resource> childIt = child.listChildren();
					List<PromotionalCardBean> promotionalCardsList = new ArrayList<PromotionalCardBean>();
					scenarioBasedPromotionalCardBean.setPromotionalCardsList(setPromotionalCardsList(childIt,promotionalCardsList));
				}
			}
			multiFieldData.add(scenarioBasedPromotionalCardBean);
		}

	}

	private List<PromotionalCardBean> setPromotionalCardsList(Iterator<Resource> it, List<PromotionalCardBean> multiFieldData) {
		while (it.hasNext()) {
			PromotionalCardBean promotionalCardBean = new PromotionalCardBean();
			Resource grandChild = it.next();

			promotionalCardBean.setCardType(grandChild.getValueMap().get("cardType", String.class));
			promotionalCardBean.setEnableCard(grandChild.getValueMap().get("enableCard", String.class));
			promotionalCardBean.setApplyFallback(grandChild.getValueMap().get("applyFallback", String.class));
			promotionalCardBean.setCardHeadlineText(grandChild.getValueMap().get("cardHeadlineText", String.class));
			promotionalCardBean.setCardSubHeadlineText(grandChild.getValueMap().get("cardSubHeadlineText", String.class));
			promotionalCardBean.setCardTextColor(grandChild.getValueMap().get("cardTextColor", String.class));
			promotionalCardBean.setCardBgColor(grandChild.getValueMap().get("cardBgColor", String.class));
			promotionalCardBean.setCardImage(DynamicMediaUtils.changeMediaPathToDMPath(grandChild.getValueMap().get("cardImage", String.class),request.getResourceResolver()));
			promotionalCardBean.setCardImageAltText(grandChild.getValueMap().get("cardImageAltText", String.class));
			promotionalCardBean.setCardImageAlignment(grandChild.getValueMap().get("cardImageAlignment", String.class));
			promotionalCardBean.setCardCtaType(grandChild.getValueMap().get("cardCtaType", String.class));
			promotionalCardBean.setCardCtaLabel(grandChild.getValueMap().get("cardCtaLabel", String.class));
			promotionalCardBean.setCardCtaLink(grandChild.getValueMap().get("cardCtaLink", String.class));
			promotionalCardBean.setCardCtaLinkTarget(grandChild.getValueMap().get("cardCtaLinkTarget", String.class));
			promotionalCardBean.setCardCtaDoNotFollowLink(ApplicationUtil.getNoFollow(grandChild.getValueMap().get("cardCtaDoNotFollowLink", String.class)));
			promotionalCardBean.setPlayStoreFileReference(grandChild.getValueMap().get("playStoreFileReference", String.class));
			promotionalCardBean.setPlayStoreLink(grandChild.getValueMap().get("playStoreLink", String.class));
			promotionalCardBean.setPlayStoreAltText(grandChild.getValueMap().get("playStoreAltText", String.class));
			promotionalCardBean.setAppStoreFileReference(grandChild.getValueMap().get("appStoreFileReference", String.class));
			promotionalCardBean.setAppStoreLink(grandChild.getValueMap().get("appStoreLink", String.class));
			promotionalCardBean.setAppStoreAltText(grandChild.getValueMap().get("appStoreAltText", String.class));
			multiFieldData.add(promotionalCardBean);
		}
		return multiFieldData;
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getComponentVersion() {
		return StringUtils.isNotBlank(componentVersion) ? componentVersion : "v2";
	}

	@Override
	public List<PromotionalCardBean> getPromotionalCards() {
		return new ArrayList<>(promotionalCardsList);
	}

	@Override
	public List<ScenarioBasedPromotionalCardBean> getScenarioBasedPromotionalCards() {
		return new ArrayList<>(scenarioBasedPromotionalCardsList);
	}
}
