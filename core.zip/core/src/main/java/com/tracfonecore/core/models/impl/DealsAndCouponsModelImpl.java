package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.settings.SlingSettingsService;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.DealCardBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.DealsAndCouponsModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { DealsAndCouponsModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/dealsandcoupons", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class DealsAndCouponsModelImpl implements DealsAndCouponsModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;

	@Inject
	private Resource resource;

	@Inject
	private SlingSettingsService settingService;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String positionDealsAndCoupons;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String positionAccountNavigation;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subHeadlineDealsAndCoupons;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headlineDeals;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subHeadlineDeals;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String carouselSpeedDeals;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String dotNavigationLengthDeals;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String seeMoreDealsCtaLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String legalCopyTextForDealsAndCoupons;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headlineCoupons;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subHeadlineCoupons;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String seeMoreCouponButtonLink;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String carouselSpeedCoupons;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String dotNavigationLengthCoupons;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String seeMoreDealsCtaText;
	
	private List<DealCardBean> dealCards = Collections.emptyList();

	@PostConstruct
	private void initModel() {
		dealCards = new ArrayList<>();
		if (resource != null) {
			getMultifieldResource();
		}
	}
	
	private void getMultifieldResource() {
		for (Resource child : resource.getChildren()) {
			Iterator<Resource> it = child.listChildren();
			if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.DEAL_CARDS.equals(child.getName())) {
				setDealCards(it);
			} 
		}
	}

	private void setDealCards(Iterator<Resource> it) {
		while (it.hasNext()) {
			DealCardBean dealCardBean = new DealCardBean();
			Resource child = it.next();
			dealCardBean.setCardType(
					child.getValueMap().get("cardType", String.class));
			dealCardBean.setCardHeadline(
					child.getValueMap().get("cardHeadline", String.class));
			dealCardBean.setCardSubheadline(
					child.getValueMap().get("cardSubheadline", String.class));
			dealCardBean.setCardImage(
					DynamicMediaUtils.changeMediaPathToDMPath(child.getValueMap().get("cardImageFileReference", String.class), request.getResourceResolver()));
			dealCardBean.setCardImageAltText(
					child.getValueMap().get("cardImageAltText", String.class));
			/*Get Card Plp Page Link*/
			String finalPlpPagePath = child.getValueMap().get("cardPlpPagePath", String.class);
			if (StringUtils.isNotBlank(finalPlpPagePath)
					&& Boolean.TRUE.equals(ApplicationUtil.isInternalLink(finalPlpPagePath))) {
				if (finalPlpPagePath.indexOf(ApplicationConstants.HTML_EXTENSION) == -1) {
					finalPlpPagePath = finalPlpPagePath + ApplicationConstants.HTML_EXTENSION;
				}
				String ctaPath = request.getResourceResolver().map(finalPlpPagePath);
				if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
					finalPlpPagePath = ApplicationUtil.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
				}
			}
			/*Set Card Plp Page Link*/
			dealCardBean.setCardPlpPagePath(finalPlpPagePath);
			dealCardBean.setOpenNewTabCardPlpPagePath(
					child.getValueMap().get("openNewTabCardPlpPagePath", String.class));
			
			dealCardBean.setCardBgColor(
					child.getValueMap().get("cardBgColor", String.class));
			
			dealCardBean.setCardTextColor(
					child.getValueMap().get("cardTextColor", String.class));
			
			dealCardBean.setCardButtonClassName(
					child.getValueMap().get("cardButtonClassName", String.class));

			dealCardBean.setCardTextHeadingColor(
					child.getValueMap().get("cardTextHeadingColor", String.class));

			dealCardBean.setCardTextSubHeadingColor(
					child.getValueMap().get("cardTextSubHeadingColor", String.class));

			dealCardBean.setCardImageAssetId(ApplicationUtil.getAssetId(child.getValueMap().get("cardImageFileReference",String.class),
					request.getResourceResolver(), ApplicationConstants.IMAGE));
			dealCardBean.setCardImageAssetAgencyId(ApplicationUtil.getAssetMetaDataValue(child.getValueMap().get("cardImageFileReference",String.class),
					request.getResourceResolver(), ApplicationConstants.IMAGE));
			
			dealCards.add(dealCardBean);
		}
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getPositionDealsAndCoupons() {
		return positionDealsAndCoupons;
	}

	@Override
	public String getPositionAccountNavigation() {
		return positionAccountNavigation;
	}

	@Override
	public String getHeadlineDeals() {
		return headlineDeals;
	}

	@Override
	public String getSubHeadlineDeals() {
		return subHeadlineDeals;
	}

	@Override
	public String getHeadlineCoupons() {
		return headlineCoupons;
	}

	@Override
	public String getSubHeadlineCoupons() {
		return subHeadlineCoupons;
	}

	@Override
	public String getSeeMoreCouponButtonLink() {
		String finalCouponsLink = seeMoreCouponButtonLink;
		if (StringUtils.isNotBlank(finalCouponsLink) &&  Boolean.TRUE.equals(ApplicationUtil.isInternalLink(finalCouponsLink))) {
			if (finalCouponsLink.indexOf(ApplicationConstants.HTML_EXTENSION) == -1) {
				finalCouponsLink = finalCouponsLink + ApplicationConstants.HTML_EXTENSION;
			}
			if (StringUtils.isNotBlank(finalCouponsLink)) {
				String ctaPath = request.getResourceResolver().map(finalCouponsLink);
				if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
					finalCouponsLink = ApplicationUtil
							.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
				}
			}
		}
		return finalCouponsLink;
	}

	@Override
	public String getSubHeadlineDealsAndCoupons() {
		return subHeadlineDealsAndCoupons;
	}

	@Override
	public String getLegalCopyTextForDealsAndCoupons() {
		return legalCopyTextForDealsAndCoupons;
	}

	@Override
	public List<DealCardBean> getDealCards() {
		return new ArrayList<>(dealCards);
	}

	private String getShortURL(String serverDomain, String url) {
		if (StringUtils.isNotBlank(url) && StringUtils.isNotBlank(serverDomain) && url.contains(serverDomain)) {
			url = url.split(serverDomain)[1];
		}
		return url;
	}

	@Override
	public String getCarouselSpeedDeals() {
		return carouselSpeedDeals;
	}

	@Override
	public String getDotNavigationLengthDeals() {
		return dotNavigationLengthDeals;
	}

	@Override
	public String getSeeMoreDealsCtaLink() {
		String finalCouponsLink = seeMoreDealsCtaLink;
		if (StringUtils.isNotBlank(finalCouponsLink) &&  Boolean.TRUE.equals(ApplicationUtil.isInternalLink(finalCouponsLink))) {
			if (finalCouponsLink.indexOf(ApplicationConstants.HTML_EXTENSION) == -1) {
				finalCouponsLink = finalCouponsLink + ApplicationConstants.HTML_EXTENSION;
			}
			if (StringUtils.isNotBlank(finalCouponsLink)) {
				String ctaPath = request.getResourceResolver().map(finalCouponsLink);
				if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
					finalCouponsLink = ApplicationUtil
							.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
				}
			}
		}
		return finalCouponsLink;
	}

	@Override
	public String getCarouselSpeedCoupons() {
		return carouselSpeedCoupons;
	}

	@Override
	public String getDotNavigationLengthCoupons() {
		return dotNavigationLengthCoupons;
	}

	@Override
	public String getSeeMoreDealsCtaText() {
		return seeMoreDealsCtaText;
	}
}
