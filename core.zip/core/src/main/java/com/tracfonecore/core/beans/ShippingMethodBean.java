/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;

/**
 * <p>Defines bean to hold shipping methods</p>
 */
/**
 * @author saurabh_kumar1
 *
 */
public class ShippingMethodBean {

    private String shippingMethodId;
	private String shippingMethodName;
	private String shippingCharge;
	private String deliveryRange;
	private String deliveryMinDays;
	private String deliveryMaxDays;
	private String shippingVendorLogo;
	private String shippingVendorLogoAltText;

    
	/**
	 * <p>Fetches id of shipping method</p>
	 * 
	 * @return String - shipping method Id
	 */
	public String getShippingMethodId() {
		return shippingMethodId;
	}

	/**
	 * <p>Sets name of the shipping method</p>
	 * 
	 * @param shippingMethodId - name of shipping method
	 */
	public void setShippingMethodId(String shippingMethodId) {
		this.shippingMethodId = shippingMethodId;
	}
	
	/**
	 * <p>Fetches name of shipping method</p>
	 * 
	 * @return String - shipping method name
	 */
	public String getShippingMethodName() {
		return shippingMethodName;
	}

	/**
	 * <p>Sets name of the shipping method</p>
	 * 
	 * @param shippingMethodName - name of shipping method
	 */
	public void setShippingMethodName(String shippingMethodName) {
		this.shippingMethodName = shippingMethodName;
	}
	
	/**
	 * <p>Fetches shipping charge</p>
	 * 
	 * @return String - shipping charge
	 */
	public String getShippingCharge() {
		return shippingCharge;
	}

	/**
	 * <p>Sets shipping charge</p>
	 * 
	 * @param shippingCharge - shipping charge 
	 */
	public void setShippingCharge(String shippingCharge) {
		this.shippingCharge = shippingCharge;
	}
	
	/**
	 * <p>Fetches delivery range</p>
	 * 
	 * @return String - deliveryRange
	 */
	public String getDeliveryRange() {
		return deliveryRange;
	}
	
	/**
	 * <p>Sets delivery  range</p>
	 * 
	 * @param delivery rang - delivery range 
	 */
	public void setDeliveryRange(String deliveryRange) {
		this.deliveryRange = deliveryRange;
	}
	/**
	 * <p>Fetches vendor logo </p>
	 * 
	 * @return String - vendor logo
	 */
	public String getShippingVendorLogo() {
		return shippingVendorLogo;
	}
	
	/**
	 * <p>Sets shipping vendor logo</p>
	 * 
	 * @param shippingVendorLogo - shipping vendor logo 
	 */
	public void setShippingVendorLogo(String shippingVendorLogo) {
		this.shippingVendorLogo = shippingVendorLogo;
	}
     /**
	 * <p>Fetches shippingVendorLogoAltText </p>
	 * 
	 * @return String - shippingVendorLogoAltText
	 */
	public String getShippingVendorLogoAltText() {
		return shippingVendorLogoAltText;
	}
	
	/**
	 * <p>Sets shippingVendorLogoAltText</p>
	 * 
	 * @param shippingVendorLogoAltText - shipping vendor logo 
	 */
	public void setShippingVendorLogoAltText(String shippingVendorLogoAltText) {
		this.shippingVendorLogoAltText = shippingVendorLogoAltText;
	}

	/**
	 * <p>Fetches delivery Min Days</p>
	 * 
	 * @return String - deliveryMinDays
	 */
	public String getDeliveryMinDays() {
		return deliveryMinDays;
	}

	/**
	 * <p>Sets delivery  Min Days</p>
	 * 
	 * @param delivery Min Days - deliveryMinDays 
	 */
	public void setDeliveryMinDays(String deliveryMinDays) {
		this.deliveryMinDays = deliveryMinDays;
	}
	
	/**
	 * <p>Fetches delivery Max Days</p>
	 * 
	 * @return String - deliveryMaxDays
	 */

	public String getDeliveryMaxDays() {
		return deliveryMaxDays;
	}

	/**
	 * <p>Sets delivery  Max days</p>
	 * 
	 * @param delivery Max days - deliveryMaxDays 
	 */
	public void setDeliveryMaxDays(String deliveryMaxDays) {
		this.deliveryMaxDays = deliveryMaxDays;
	}
}
