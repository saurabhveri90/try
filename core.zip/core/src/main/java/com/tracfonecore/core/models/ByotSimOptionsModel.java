package com.tracfonecore.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ExporterConstants;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true")})
public interface ByotSimOptionsModel {
	
	/**
     * <p>Fetches option</p>
     *
     * @return String - option
     */
	@ValueMapValue(name="option")
	public String getOption();

     /**
     * <p>Fetches option</p>
     *
     * @return String - option
     */
	@ValueMapValue(name="cardimage")
	public String getCardImage();
	
	/**
     * <p>Fetches description</p>
     *
     * @return String - description
     */
	@ValueMapValue(name="description")
	public String getDescription();
	
	/**
     * <p>Fetches label</p>
     *
     * @return String - label
     */
	@ValueMapValue(name="label")
	public String getLabel();
     
     /**
     * <p>Fetches buttonlabel</p>
     *
     * @return String - buttonlabel
     */
	@ValueMapValue(name="buttonlabel")
	public String getButtonLabel();

     /**
     * <p>Fetches buttonlink</p>
     *
     * @return String - buttonlink
     */
	@ValueMapValue(name="buttonlink")
	public String getButtonLink();

     /**
     * <p>Fetches checkevent</p>
     *
     * @return String - checkevent
     */
	@ValueMapValue(name="checkevent")
	public String getCheckEvent();
	
}
