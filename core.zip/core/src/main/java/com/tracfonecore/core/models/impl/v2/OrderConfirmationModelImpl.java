/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl.v2;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.OrderConfirmationModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { OrderConfirmationModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/orderconfirmation/v2/orderconfirmation", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class OrderConfirmationModelImpl extends com.tracfonecore.core.models.impl.v1.OrderConfirmationModelImpl implements OrderConfirmationModel {

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String componentVersion;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String positionCartSummary;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String positionOrderSummary;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String cartDetailComponentVersion;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String enableEstimateOrder;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String smartPaySummaryText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String smartPayLeasedFrom;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean useResourceManagementValues;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planCategoryId;

    @Override
    public String getComponentVersion() {
        return StringUtils.isNotBlank(componentVersion) ?  componentVersion: "v2";
    }
    
    @Override
	public String getPositionCartSummary() {
		return positionCartSummary;
	}

	@Override
	public String getPositionOrderSummary() {
		return positionOrderSummary;
	}

	@Override
	public String getCartDetailComponentVersion() {
		return cartDetailComponentVersion;
	}

	@Override
	public String getEnableEstimateOrder() {
		return enableEstimateOrder;
	}

	@Override
	public String getSmartPaySummaryText() {
		return smartPaySummaryText;
	}

	@Override
	public String getSmartPayLeasedFrom() {
		return smartPayLeasedFrom;
	}
	
	@Override
	public Boolean getUseResourceManagementValues() {
		return useResourceManagementValues;
	}

	@Override
	public String getPlanCategoryId() {
		return planCategoryId;
	}
    
}
