/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.PurchaseFlowWrapperModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.BrandSpecificConfigService;
import com.tracfonecore.core.services.PurchaseFlowConfigService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.services.TracfoneValueMappingConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;


@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { PurchaseFlowWrapperModel.class,ComponentExporter.class },
		resourceType = "tracfone-core/components/commerce/purchaseflowwrapper", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR,
		extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class PurchaseFlowWrapperModelImpl implements PurchaseFlowWrapperModel {

	@ScriptVariable
	private ValueMap properties;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String cartPath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String editPlanPath;
	
	@ValueMapValue
	private String loginPagePath;

	@Inject
	@Via("resource")
	private Resource extendedPlanXfsPlan;
    
    @Inject
    private Page currentPage;
    
    @Inject
    private TracfoneApiGatewayService tracfoneApiService;

	@Inject
	private ApplicationConfigService applicationConfigService;
	
	@Inject
	private BrandSpecificConfigService brandSpecificConfigService;
	
	@Inject
	private PurchaseFlowConfigService purchaseFlowConfigService;

    @Inject
    private TracfoneValueMappingConfigService tracfoneValueMappingConfigService;

	private static final Logger LOGGER = LoggerFactory.getLogger(PurchaseFlowWrapperModelImpl.class);
	
	@Self
	private SlingHttpServletRequest request;

	@Inject
	private Resource resource;
	
	private String selectors;
	
	private static final String MANAGE_AUTO_REFILL_PAGE_PATH = "manageAutoRefillPagePath";

	@PostConstruct
	private void initModel() {
		selectors = String.join(".", request.getRequestPathInfo().getSelectors());
		LOGGER.debug("Inside Purchase Flow Wrapper");
	}
	
	@Override
	public String getPurchaseFlowSteps() {
		return purchaseFlowConfigService.getPurchaseSteps(selectors);	
	}
	
	/**
	 * <p>get Cart Sticky Steps</p>
	 *
	 * @return String - xf path
	 */
	@Override
	public String getCartStickySteps() {
		return purchaseFlowConfigService.getCartStickySteps(selectors);	
	}
	
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
	private String getXfPath(Resource multiResource) {
		String xfPaths = "";
		for (Resource resource : multiResource.getChildren()) {
			xfPaths = xfPaths + "," + resource.getValueMap().get("xfPath", "").toString();
		}
		if(xfPaths.startsWith(",")) {
			xfPaths = xfPaths.replaceFirst(",", "");
		}
		return xfPaths;
	}
	
	/**
	 * <p>get purchase flow</p>
	 *
	 * @return String - xf path
	 */
	@Override
	public String getCurrentPurchaseFlowSteps() {
		return purchaseFlowConfigService.getCurrentPurchaseSteps(selectors);	
	}
	
	@Override
	public String getAllXfPaths() {
		String value = "";
		for (Resource childResource : resource.getChildren()) {
			if(childResource.getName().equals("propdevicecustomplan")) {
				value = value + ";" + getCustomXfPath(childResource);
			}else if(childResource.getName().startsWith("prop")) {
				value = value + ";" + childResource.getName().replace("prop", "") + ":"+getXfPath(childResource);
			}
		}
		value = value.replaceFirst(";", "");
		return value;
		
	}
	
	private String getCustomXfPath(Resource multiResource) {
		String xfPaths = "";
		for (Resource resource : multiResource.getChildren()) {
			String type = resource.getValueMap().get("xfType", "").toString();
			if(type.startsWith("plan")) {
				type = type.replace("plan", "");
			}
			if(StringUtils.isNoneEmpty(type)) {
				xfPaths = xfPaths + ";" + multiResource.getName().replace("prop", "").replace("custom",type) + ":"+ resource.getValueMap().get("xfPath", "").toString();
			}
		}
		if(xfPaths.startsWith(";")) {
			xfPaths = xfPaths.replaceFirst(";", "");
		}
		return xfPaths;
	}
	/**
     * <p>get Protection plan category ID</p>
     *
     * @return String - category ID
     */
     private String getCategoryID() {
        return ApplicationUtil.getPropertiesFromRootPage(currentPage.getPath(),resource.getResourceResolver(),ApplicationConstants.CATEGORY_ID);                    
     }
     
     /**
     * <p> Returns apiDomain from configuration</p>
     * 
      * @return String - apiDomain
     */
     @Override
     public String getApiDomain() {
    	 return tracfoneApiService.getApiDomain();
     }

	/**
	 * <p> Returns smartPay Plan Facet </p>
	 *
	 * @return String - smartPayPlanFacet
	 */
	@Override
	public String getSmartPayPlanFacet() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getSmartPayPlanFacet(),CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
		
	}
     
     /**
     * String is used for category API call
     * 
      * @return String - queryString
     */
     @Override
     public String getQueryString() {
         StringBuilder query = new StringBuilder("projection=bysearchtermoptimized&searchKeyword=*").append(CommerceConstants.AMPERSAND)
                                     .append(CommerceConstants.CATEGORY_ID).append(CommerceConstants.EQUALS_TO).append(this.getCategoryID());
         return query.toString();
     }
     
     /**
     *  <p>Returns categoryApiPath from configuration</p>
     *  
      * @return String - categoryApiPath
     */
     @Override
     public String getCategoryApiPath() {
    	 return tracfoneApiService.getCategoryApiPath();
     }

     /**
      *  <p>Returns emiOrderType from configuration</p>
      *  
       * @return String - emiOrderType
      */
      @Override
     public String getEmiOrderType(){
    	   return purchaseFlowConfigService.getEmiOrderItemType();
    	}
     /**
      *  <p>Returns checkoutPath from properties</p>
      *  
       * @return String - checkoutPath
      */
      @Override
      public String getCartPath() {
    	if(ApplicationUtil.isInternalLink(this.cartPath)&& this.cartPath.indexOf(ApplicationConstants.HTML_EXTENSION)==-1) {
      		this.cartPath = this.cartPath+ApplicationConstants.HTML_EXTENSION;
      	}
    	String ctaPath = resource.getResourceResolver().map(this.cartPath);
  		if(StringUtils.isEmpty(ctaPath)) {
  			ctaPath = this.cartPath;
  		}
  		return ctaPath;
		//return this.cartPath;
      }

      /**
       *  <p>Returns editPlanPath from properties</p>
       *  
        * @return String - editPlanPath
       */
       @Override
       public String getEditPlanPath() {
    	if(ApplicationUtil.isInternalLink(this.editPlanPath)&& this.editPlanPath.indexOf(ApplicationConstants.HTML_EXTENSION)==-1) {
    		this.editPlanPath = this.editPlanPath+ApplicationConstants.HTML_EXTENSION;
    	}
     	String ctaPath = resource.getResourceResolver().map(this.editPlanPath);
   		if(StringUtils.isEmpty(ctaPath)) {
   			ctaPath = this.editPlanPath;
   		}
   		return ctaPath;
 		//return this.editPlanPath;
       }
       
    /**
	 * @return String -  UpgradeEligibilityApiPath
	 */
	@Override 
	public String getUpgradeApiPath() {

		return tracfoneApiService.getUpgradeEligibilityApiPath();
	}
	
	/**
	 * <p> This method is used to generate query string for marketing id call
	 * @return -String : Query String
	 */
	@Override
	public String getUpgradeElgQueryString(){
		StringBuilder query = new StringBuilder(CommerceConstants.IDENTIFIER).append(CommerceConstants.EQUALS_TO);		
		return query.toString();
	}

	/**
	 *
	 * @return String - Default fallback thumbnail Image.
	 * */
	public String getDefaultFallbackThumbnailImage(){
		String image =  ApplicationUtil.getPropertiesFromRootPage(currentPage.getPath(),resource.getResourceResolver(),ApplicationConstants.FALLBACK_THUMBNAIL_IMAGE);
		return DynamicMediaUtils.changeMediaPathToDMPath(image, resource.getResourceResolver());
	}

	/**
	 * @return String  - Login page path
	 */
	@Override
	public String getLoginPath() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), this.loginPagePath);
	}

	/**
	 * @return String  - Hide Sticky Cart Config
	 */
	@Override
	public String getHideStickyCart() {
		return String.join(ApplicationConstants.COMMA, purchaseFlowConfigService.getHideStickyCart());
	}

	/**
	 * @return String  - Hide Sticky Cart Config
	 */
	@Override
	public String getPreorderHPPDefaultValue() {
		return ConfigurationUtil.getConfigValue(purchaseFlowConfigService.getPreorderHPPDefaultValue(),
				CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel())).toLowerCase();
	}
	
	/**
	 * Get the cusg enabling check
	 *
	 * @return String - cusg enabling check
	 */
	@Override
	public String getCusgEnable() {
        String cusgCheck = (CommerceUtil.getPagePropertyValue(currentPage, applicationConfigService.getHomePageLevel(),
                CommerceConstants.ENABLE_CUSG) != null) ? CommerceUtil
                        .getPagePropertyValue(currentPage, applicationConfigService.getHomePageLevel(), CommerceConstants.ENABLE_CUSG).toString()
                        : "";
        return cusgCheck;
    }

	/**
	 * <p>Fetches disableHpp value from config</p>
	 *
	 * @return String - disableHpp
	 */
	@Override
	public String getDisableHpp() {
		return ConfigurationUtil.getConfigValue(brandSpecificConfigService.disableHpp(), CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}

    /**
     * <p>
     * get device type mapping
     * </p>
     *
     * @return String[] - device type mapping
     */
    @Override
    public String[] getPurchaseDevicesType() {
        return purchaseFlowConfigService.getDevicesType();
    }

    /**
     * <p>
     * Returns Purchase Devices Type
     * </p>
     *
     * @return String - purchaseDevicesType
     */
    @Override
    public String[] getLanguageValueMapping() {
        return tracfoneValueMappingConfigService.getLanguageValueMapping();
    }

    /**
	 * Get the manage Auto Refill Page Path
	 *
	 * @return String - manage Auto Refill Page Path
	 */
	@Override
	public String getManageAutoRefillPagePath() {
	    String manageAutoRefillPagePath =(CommerceUtil.getPagePropertyValue(currentPage, applicationConfigService.getHomePageLevel(),
	    		MANAGE_AUTO_REFILL_PAGE_PATH) != null) ? CommerceUtil
                .getPagePropertyValue(currentPage, applicationConfigService.getHomePageLevel(), MANAGE_AUTO_REFILL_PAGE_PATH).toString()
                : "";
		return ApplicationUtil.getShortUrl(request.getResourceResolver(), manageAutoRefillPagePath);
	}
}
