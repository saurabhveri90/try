package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;

import com.tracfonecore.core.models.TwoColumnLayoutModel;
import com.tracfonecore.core.utils.DynamicMediaUtils;

import javax.annotation.PostConstruct;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { TwoColumnLayoutModel.class,
      ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/twocolumn", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
      @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
      @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class TwoColumnLayoutModelImpl implements TwoColumnLayoutModel {


   @Self
   private SlingHttpServletRequest request;
   @ValueMapValue
   private String textColumnHeading;

   @ValueMapValue
   private String useHeadingOne;

   @ValueMapValue
   private String textColumnDesc;

   @ValueMapValue
   private String textColumnCTA;

   @ValueMapValue
   private String alignType;

   @ValueMapValue
   private String imgPath;

   @ValueMapValue
   private String headingColumnTwo;

   @ValueMapValue
   private String descColumnTwo;

   @ValueMapValue
   private String imgPathColTwo;

   @ValueMapValue
   @Default(values = "")
   private String tooltipLogo;

   @ValueMapValue
   @Default(values = "")
   private String tooltipMsg;

   @ValueMapValue
	private String eyebrowtextHeading;

	@ValueMapValue
	private String mobimgPath;
	
	@ValueMapValue
	private String tabimgPath;

   private static final Logger LOGGER = LoggerFactory.getLogger(TwoColumnLayoutModelImpl.class);


   public String getTextColumnHeading(){ return textColumnHeading;}
   public String getUseHeadingOne(){ return useHeadingOne;}
   public String getTextColumnDesc(){ return  textColumnDesc;}
   public String getTextColumnCTA(){ return textColumnCTA;}
   public String getAlignType(){return  alignType;}   
   public String getImgPath() {
         return DynamicMediaUtils.changeMediaPathToDMPath(imgPath, request.getResourceResolver());
   }
   public String getHeadingColumnTwo(){ return headingColumnTwo;}
   public String getDescColumnTwo(){return  descColumnTwo;}   
   public String getImgPathColTwo() {
         return DynamicMediaUtils.changeMediaPathToDMPath(imgPathColTwo, request.getResourceResolver());
   }
   public String getTooltipMessage(){return tooltipMsg;}
   public String getTooltipLogo(){return tooltipLogo;}
   public String getEyebrowtextHeading(){ return eyebrowtextHeading;}
   public String getMobimgPath(){ return DynamicMediaUtils.changeMediaPathToDMPath(mobimgPath, request.getResourceResolver());}
   public String getTabimgPath(){ return DynamicMediaUtils.changeMediaPathToDMPath(tabimgPath, request.getResourceResolver());}


   @Override
   public String getExportedType() {
      return request.getResource().getResourceType();
   }

   @PostConstruct
	protected void initModel() {

            if(null != textColumnDesc)
            {
                  textColumnDesc = textColumnDesc.replace("TooltipIdentifier", tooltipMsg);
                  textColumnDesc = textColumnDesc.replace("tooltipLogoIdentifier", tooltipLogo);                  
            }	
		
	}
}
