/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code PaypalBannerModel} Sling Model used for the {@code tracfone-core/components/commerce/paypalbanner} component.
 */
public interface PaypalBannerModel extends ComponentExporter{
	
	/**
	 * <p>get Show Paypal Banner flag</p>
	 *
	 * @return String - ShowPaypalBanner flag
	 */
	@JsonProperty("showPaypalBanner")
    public String getShowPaypalBanner();
    
	/**
	 * <p>get Braintree API path</p>
	 *
	 * @return String - BraintreePath
	 */
    public String getPaypalBraintreePath();

	/**
	 * <p>get Message Layout Style</p>
	 *
	 * @return String - MessageLayoutStyle
	 */
	@JsonProperty("messageLayoutStyle")
    public String getMessageLayoutStyle();

	/**
	 * <p>get Logo Type</p>
	 *
	 * @return String - LogoType
	 */
	@JsonProperty("logoType")
    public String getLogoType();

	/**
	 * <p>get Logo Position</p>
	 *
	 * @return String - LogoPosition
	 */
	@JsonProperty("logoPosition")
    public String getLogoPosition();

	/**
	 * <p>get Text Color</p>
	 *
	 * @return String - TextColor
	 */
	@JsonProperty("textColor")
    public String getTextColor();

	/**
	 * <p>get BgColor</p>
	 *
	 * @return String - BgColor
	 */
	@JsonProperty("bgColor")
    public String getBgColor();

	/**
	 * <p>get Text Alignment</p>
	 *
	 * @return String - TextAlign
	 */
	@JsonProperty("textAlign")
    public String getTextAlign();

	/**
	 * <p>get StyleRatio</p>
	 *
	 * @return String - StyleRatio
	 */
	@JsonProperty("styleRatio")
    public String getStyleRatio();
	 
	public int getHomePageLevel();

	public String getExportedType();
}