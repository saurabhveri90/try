package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;


public interface ButterBarModel extends ComponentExporter {



    @JsonProperty("timervalue")
    public String getTimervalue();

    @JsonProperty("butterbarText")
    public String getButterbarText();

    @JsonProperty("mediaPath")
    public String getMediaPath();

    @JsonProperty("btnlistcheck")
    public String getBtnlistcheck();

    /**
     * <p>Fetches the image data mode</p>
     *
     * @return String - data mode
     */
    @JsonProperty("dataMode")
    public String getDataMode();

    /**
     * <p>Fetches image profile breakpoint</p>
     *
     * @return String - image profile breakpoint
     */
    @JsonProperty("imageProfileBreakpoints")
    public String getImageProfileBreakpoints();

    /**
     * <p>Fetches path for mobile image</p>
     *
     * @return String - mobile media image path
     */
    @JsonProperty("mobileMediaImagePath")
    public String getMobileMediaImagePath();

    String getTheme();
}
