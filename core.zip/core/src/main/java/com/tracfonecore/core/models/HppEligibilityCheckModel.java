/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the Sling Model used for the {@code /apps/tracfone-core/components/commerce/hppeligibilitychecker} component.
 */
public interface HppEligibilityCheckModel extends ComponentExporter {

	/**
	 * <p>Fetches heading for the HPP Eligibility checker</p>
	 * 
	 * @return String - heading for the HPP Eligibility checker
	 */
	@JsonProperty("heading")
	public String getHeading();
	
	/**
	 * <p>Fetches dropdown label for the HPP Eligibility checker</p>
	 * 
	 * @return String - dropdown label for the HPP Eligibility checker
	 */
	@JsonProperty("dropdownLabel")
	public String getDropdownLabel();
	
	
	/**
	 * <p>Fetches textbox label for the HPP Eligibility checker</p>
	 * 
	 * @return String - textbox label for the HPP Eligibility checker
	 */
	@JsonProperty("textboxLabel")
	public String getTextboxLabel();

	/**
	 * <p>Fetches Privacy Policy Info label for the HPP Eligibility checker</p>
	 * 
	 * @return privacyPolicy
	 */
	@JsonProperty("privacyPolicy")
	public String getPrivacyPolicy();
}
