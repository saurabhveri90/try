/*
 *  Copyright 2022 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl.v1;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Collections;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import com.tracfonecore.core.beans.ColumnBean;
import com.tracfonecore.core.beans.FeatureBean;

import com.tracfonecore.core.services.PurchaseFlowConfigService;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.day.cq.wcm.api.Page;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.tracfonecore.core.beans.SpecsBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.MultilinePlanListModel;
import com.tracfonecore.core.models.impl.BaseComponentModelImpl;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import com.tracfonecore.core.utils.ItemsExporterUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { MultilinePlanListModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/multilineplanlist", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class MultilinePlanListModelImpl extends BaseComponentModelImpl implements com.tracfonecore.core.models.MultilinePlanListModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(MultilinePlanListModelImpl.class);

	private Map<String, Object> brandPropertyValueMap;

	@Self
	private SlingHttpServletRequest request;

	private ResourceResolver resourceResolver;

	@Inject
	private SlingModelFilter slingModelFilter;

	@Inject
	private ModelFactory modelFactory;
	@Inject
	private Resource resource;

	@Inject
	private TracfoneApiGatewayService tracfoneApiService;

	@Inject
	private ApplicationConfigService applicationConfigService;

	@Inject
	private PurchaseFlowConfigService purchaseFlowConfigService;

	@Inject
	private Page currentPage;

	@ValueMapValue
	@Default(values = "plp")
	private String pagetype;

	@ValueMapValue
	private String plpHeader;

	@ValueMapValue
	@Default(booleanValues = false)
	private boolean h1tagheader;

	@ValueMapValue
	private String fourthLineDiscountLabel;

	@ValueMapValue
	private String pdpJsonPath;
	@ValueMapValue
	private String pdpJsonPathForLanding;

	@ValueMapValue
	private String plpSubHeader;

	@ValueMapValue
	private String disclaimer;

	@ValueMapValue
	private String byopPlanHeaderText;

	@ValueMapValue
	private Boolean showMultiLineSelector;

	@ValueMapValue
	private String showTimer;

	@ValueMapValue
	private String selectButtonLabel;

	@ValueMapValue
	private String seeDetailLinkLabel;

	@ValueMapValue
	private String backToSummaryLabel;

	@ValueMapValue
	@Default(values="false")
	private String disableCompare;
	@ValueMapValue
	@Default(values="false")
	private String fccLabelOnCard;

	@ValueMapValue
	@Default(values="false")
	private String disableFeatures;

	@ValueMapValue
	private String compareTabDescription;

	@ValueMapValue
	private String compareButtonLabel;

	@ValueMapValue
	private String compareButtonLink;

	@ValueMapValue
	private String compareLinkLabel;

	@ValueMapValue
	private String applyPurchasePlanFacet;

	@ValueMapValue
	private String applyActivationPlanFacet;

	@ValueMapValue
	private String isAddOn;

	@ValueMapValue
	private String applyHotspotPlanFacet;

	@ValueMapValue
	private String showRewardsText;

	@ValueMapValue
	private String addButton;

	@ValueMapValue
	private String disableBazaarVoiceRatings;

	@ValueMapValue
	private String discountText;

	@ValueMapValue
	private String activationPlansHeading;

	@ValueMapValue
	private String currentPlanLabel;

	@ValueMapValue
	private String fccLabelLink;

	@ValueMapValue
	private String phoneNumberLabel;

	@ValueMapValue
	private String serviceEndLabel;

	@ValueMapValue
	private String differentNumberLabel;

	@ValueMapValue
	private String addonSectionHeading;

	@ValueMapValue
	private String refillPagePath;

	@ValueMapValue
	private String applyHomeInternetPlanFacet;

	@ValueMapValue
	private String applyTabletPlanFacet;

	@ValueMapValue
	private String viewFccLabelText;
	private List<FeatureBean> featureList = Collections.emptyList();

	private String jsonPagePath;
	private String categoryId;
	private String categoryType;
	private Page homePage;
	private ObjectMapper mapper;
	private String brand;
	private String specsOptions;
	private String multilineSelectorText;
	private String priceBreakdownLabel;
	private String planServiceDaysLabel;

	//Constants
	private static final String DEFAULT_PLAN_THUMBNAIL_IMAGE = "defaultFallbackThumbnailImage";

	@PostConstruct
	protected void initModel() {
		super.initModel();

		String[] properties = { CommerceConstants.BRANDNAME, CommerceConstants.NUMBER_OF_LINES, DEFAULT_PLAN_THUMBNAIL_IMAGE };
		this.brandPropertyValueMap = CommerceUtil.getMultiplePagePropertyValue(currentPage, getBrandPageLevel(),properties);

		this.homePage = CommerceUtil.getHomePage(currentPage, getHomePageLevel());
		this.brand = CommerceUtil.getPropertyValue(this.brandPropertyValueMap, CommerceConstants.BRANDNAME);
		resourceResolver = request.getResourceResolver();
		mapper = new ObjectMapper();

		Page commonPage = getPage();
		if(commonPage != null) {
			setUnitValues(commonPage);
			ValueMap commonVm = commonPage.getContentResource().getValueMap();
			categoryType = commonVm.get("categorytype", String.class);
			categoryId = commonVm.get("categoryId", String.class);
			jsonPagePath = StringUtils.equalsIgnoreCase(commonVm.get("createjson", String.class), ApplicationConstants.YES) ? commonPage.getPath() : "";
			multilineSelectorText = commonVm.get("multilineSubheading", String.class);
			priceBreakdownLabel = commonVm.get("priceBreakdownLabel", String.class);
		}
		//for adding features
		try {
			featureList = new ArrayList<FeatureBean>();
			Node currentNode = resource.adaptTo(Node.class);
			if (currentNode != null && currentNode.hasNode(ApplicationConstants.FEATURES)) {
				Node child = currentNode.getNode(ApplicationConstants.FEATURES);
				// get the grandchild node of the currentNode - which represents where the
				// Column control values are stored
				NodeIterator ni = child.getNodes();
				setMultiFieldItems(ni, featureList);
			}
		} catch (RepositoryException re) {
			LOGGER.error("Repository Exception occurred while fetching column control details {}", re);
		}

	}
	private void setMultiFieldItems(NodeIterator ni, List<FeatureBean> multiFieldData) {
		LOGGER.debug("Entering setMultiFieldItems method.");
		try {
			while (ni.hasNext()) {
				FeatureBean featureBean = new FeatureBean();
				Node grandChild = (Node) ni.nextNode();

				if ((grandChild.hasProperty(ApplicationConstants.FEATURE_TITLE))) {
					featureBean.setFeatureTitle(grandChild.getProperty(ApplicationConstants.FEATURE_TITLE).getString());
				}
				if ((grandChild.hasProperty(ApplicationConstants.FEATURE_DESCRIPTION))) {
					featureBean.setFeatureDescription(grandChild.getProperty(ApplicationConstants.FEATURE_DESCRIPTION).getString());
				}
				if ((grandChild.hasProperty(ApplicationConstants.FEATURE_LOGO))) {
					featureBean.setFeatureLogo(grandChild.getProperty(ApplicationConstants.FEATURE_LOGO).getString());
				}

				multiFieldData.add(featureBean);

			}
			//getColWidthRatioClass(multiFieldData);
		} catch (RepositoryException re) {
			LOGGER.error("Repository Exception occurred while setting column control multifield values {}", re);
		}
		LOGGER.debug("Exiting setMultiFieldItems method.");
	}

	/**
	 * Allows authoring each specification at the page properties level
	 */
	private void setUnitValues(Page resourcePage) {
		ObjectNode objNode = mapper.createObjectNode();
		SpecsBean specsBean = CommerceUtil.getProductSpecificationUnit(resourcePage, getHomePageLevel());
		if(specsBean.getOtherSpecs() != null) {
			objNode.putPOJO(CommerceConstants.SPECS_OPTIONS, specsBean.getOtherSpecs());
			specsBean.getOtherSpecs().forEach(entry -> {
				if(StringUtils.equalsIgnoreCase(entry.getIdentifier(), CommerceConstants.PLAN_SERVICE_DAYS)) {
					planServiceDaysLabel = entry.getUnit();
				}
			});
		}
		try {
			specsOptions = mapper.writeValueAsString(objNode);
		} catch (JsonProcessingException e) {
			LOGGER.error("ProductListModelImpl :: JsonProcessingException in setUnitValues"+e);
		}
	}

	/**
	 * Returns page based on page type
	 * @return
	 */
	private Page getPage() {
		if ((pagetype.equals("purchaseflow") || pagetype.equals("activation") || pagetype.equals("refill") || pdpJsonPath != null)
				&& resourceResolver.getResource(pdpJsonPath) != null
				&& resourceResolver.getResource(pdpJsonPath).adaptTo(Page.class) != null)
		{
			Resource plpPageResource = resourceResolver.getResource(pdpJsonPath);
			return plpPageResource.adaptTo(Page.class);
		} else {
			LOGGER.debug("template is {}",currentPage.getTemplate()!=null?currentPage.getTemplate().getName():"");
			if(currentPage.getTemplate()!=null&&currentPage.getTemplate().getName().equals("landing-page") && StringUtils.isNotBlank(pdpJsonPathForLanding)){
				Page allPlansPage = resourceResolver.getResource(pdpJsonPathForLanding).adaptTo(Page.class);
				return allPlansPage;

			}else if (!StringUtils.isBlank(currentPage.getContentResource().getValueMap().get("categoryId", String.class))) {
				return currentPage;
			}else{
				return currentPage.getParent();
			}
		}
	}

	/**
	 * <p>
	 * Fetches home page level property from config
	 * </p>
	 *
	 * @return int - homePageLevel
	 */
	@Override
	public int getHomePageLevel() {
		return applicationConfigService.getHomePageLevel();
	}

	/**
	 * <p>
	 * Fetches categoryId Param
	 * </p>
	 *
	 * @return String - categoryId Param
	 */
	@Override
	public String getCategoryId() {
		return categoryId;
	}

	/**
	 * <p>
	 * Fetches categoryType Param
	 * </p>
	 *
	 * @return String - categoryType Param
	 */
	@Override
	public String getCategoryType() {
		return categoryType;
	}

	/**
	 * <p>
	 * Returns exporter type
	 * </p>
	 *
	 * @return String - getexportertype
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Fetches pagetype Param
	 * </p>
	 *
	 * @return String - pagetype Param
	 */
	@Override
	public String getPageType() {
		return pagetype;
	}

	/**
	 * <p>
	 * Fetches fourthLineDiscountLabel Param
	 * </p>
	 *
	 * @return String - fourthLineDiscountLabel Param
	 */
	@Override
	public String getFourthLineDiscountLabel() {
		return fourthLineDiscountLabel;
	}

	/**
	 * <p>
	 * Fetches getFccLabelLink Param
	 * </p>
	 *
	 * @return String - getFccLabelLink Param
	 */
	@Override
	public String getFccLabelLink() {
		return fccLabelLink;
	}

	/**
	 * <p>
	 * Fetches plpHeader Param
	 * </p>
	 *
	 * @return String - plpHeader Param
	 */
	@Override
	public String getPlpHeader() {
		return plpHeader;
	}
	/**
	 * <p>
	 * Fetches h1tagheader
	 * </p>
	 *
	 * @return String - h1tagheader Param
	 */
	@Override
	public boolean getH1TagHeader(){
		return h1tagheader;
	}

	/**
	 * <p>
	 * Fetches pdpJsonPath Param
	 * </p>
	 *
	 * @return String - pdpJsonPath Param
	 */
	@Override
	public String getPdpJsonPath() {
		return pdpJsonPath;
	}

	/**
	 * <p>
	 * Fetches plpSubHeader Param
	 * </p>
	 *
	 * @return String - plpSubHeader Param
	 */
	@Override
	public String getPlpSubHeader() {
		return plpSubHeader;
	}

	/**
	 * <p>
	 * Fetches disclaimer Param
	 * </p>
	 *
	 * @return String - disclaimer Param
	 */
	@Override
	public String getDisclaimer() {
		return disclaimer;
	}

	/**
	 * <p>
	 * Fetches byopPlanHeaderText Param
	 * </p>
	 *
	 * @return String - byopPlanHeaderText Param
	 */
	@Override
	public String getByopPlanHeaderText() {
		return byopPlanHeaderText;
	}

	/**
	 * <p>
	 * Fetches showMultiLineSelector Param
	 * </p>
	 *
	 * @return String - showMultiLineSelector Param
	 */
	@Override
	public Boolean getShowMultiLineSelector() {
		return showMultiLineSelector;
	}

	/**
	 * <p>
	 * Fetches multilineSelectorText Param
	 * </p>
	 *
	 * @return String - multilineSelectorText Param
	 */
	@Override
	public String getMultilineSelectorText() {
		return multilineSelectorText;
	}

	/**
	 * <p>
	 * Fetches priceBreakdownLabel Param
	 * </p>
	 *
	 * @return String - priceBreakdownLabel Param
	 */
	@Override
	public String getPriceBreakdownLabel() {
		return priceBreakdownLabel;
	}

	/**
	 * <p>
	 * Fetches showTimer Param
	 * </p>
	 *
	 * @return String - showTimer Param
	 */
	@Override
	public String getShowTimer() {
		return showTimer;
	}

	/**
	 * <p>
	 * Fetches selectButtonLabel Param
	 * </p>
	 *
	 * @return String - selectButtonLabel Param
	 */
	@Override
	public String getSelectButtonLabel() {
		return selectButtonLabel;
	}

	/**
	 * <p>
	 * Fetches seeDetailLinkLabel Param
	 * </p>
	 *
	 * @return String - seeDetailLinkLabel Param
	 */
	@Override
	public String getSeeDetailLinkLabel() {
		return seeDetailLinkLabel;
	}

	/**
	 * <p>
	 * Fetches backToSummaryLabel Param
	 * </p>
	 *
	 * @return String - backToSummaryLabel Param
	 */
	@Override
	public String getBackToSummaryLabel() {
		return backToSummaryLabel;
	}

	/**
	 * <p>
	 * Fetches disableCompare Param
	 * </p>
	 *
	 * @return String - disableCompare Param
	 */
	@Override
	public String getFccLabelOnCard() {
		return fccLabelOnCard;
	}

	/**
	 * <p>
	 * Fetches disableCompare Param
	 * </p>
	 *
	 * @return String - disableCompare Param
	 */
	@Override
	public String getDisableCompare() {
		return disableCompare;
	}

	/**
	 * <p>
	 * Fetches disableFeatures Param
	 * </p>
	 *
	 * @return String - disableFeatures Param
	 */
	@Override
	public String getDisableFeatures() {
		return disableFeatures;
	}

	/**
	 * <p>
	 * Fetches compareTabDescription Param
	 * </p>
	 *
	 * @return String - compareTabDescription Param
	 */
	@Override
	public String getCompareTabDescription() {
		return compareTabDescription;
	}

	/**
	 * <p>
	 * Fetches compareButtonLabel Param
	 * </p>
	 *
	 * @return String - compareButtonLabel Param
	 */
	@Override
	public String getCompareButtonLabel() {
		return compareButtonLabel;
	}

	/**
	 * <p>
	 * Fetches compareButtonLink Param
	 * </p>
	 *
	 * @return String - compareButtonLink Param
	 */
	@Override
	public String getCompareButtonLink() {
		return ApplicationUtil.getShortUrl(request.getResourceResolver(), compareButtonLink);
	}

	/**
	 * @return the jsonPagePath
	 */
	public String getJsonPagePath() {
		return jsonPagePath;
	}

	/**
	 * String is used for category API call
	 *
	 * @return String - queryString
	 */
	public String getQueryString() {
		StringBuilder query = new StringBuilder("searchKeyword=*").append(CommerceConstants.AMPERSAND)
				.append(CommerceConstants.CATEGORY_ID).append(CommerceConstants.EQUALS_TO).append(this.getCategoryId());
		return query.toString();
	}

	/**
	 * <p>
	 * Method to return numberOfLinesList
	 *
	 * @return List numberOfLinesList
	 */
	@Override
	public List<Object> getNumberOfLinesList() {
		int numOfLines = Integer.parseInt(CommerceUtil.getPropertyValue(this.brandPropertyValueMap, CommerceConstants.NUMBER_OF_LINES));
		List<Object> list = new ArrayList<>(numOfLines);
		for (int i = 0; i < numOfLines; i++) {
			list.add("");
		}
		return list;
	}

	/**
	 * <p>
	 * Fetches brand page level property from config
	 * </p>
	 *
	 * @return int - brand page level
	 */
	private int getBrandPageLevel() {
		return applicationConfigService.getBrandPageLevel();
	}

	/**
	 * <p>
	 * Returns categoryApiPath from configuration
	 * </p>
	 *
	 * @return String - categoryApiPath
	 */
	public String getCategoryApiPath() {
		return tracfoneApiService.getCategoryApiPath();
	}

	/**
	 * <p>
	 * Fetches property to show purchase plans
	 * </p>
	 *
	 * @return String - the applyPurchasePlanFacet
	 */
	@Override
	public String getApplyPurchasePlanFacet() {
		return StringUtils.isNotBlank(applyPurchasePlanFacet) ? applyPurchasePlanFacet : "false" ;
	}

	/**
	 * <p>
	 * Fetches property to show tablet plans
	 * </p>
	 *
	 * @return String - the applyTabletPlanFacet
	 */
	@Override
	public String getApplyTabletPlanFacet() {
		return StringUtils.isNotBlank(applyTabletPlanFacet) ? applyTabletPlanFacet : "false" ;
	}

	/**
	 * <p>
	 * Fetches TabletPlanTypeFacet
	 * </p>
	 *
	 * @return the tabletPlanTypeFacet
	 */
	@Override
	public String getTabletPlanTypeFacet() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getTabletPlanTypeFacet(), this.brand);
	}

	/**
	 * <p>
	 * Fetches purchasePlanTypeFacet
	 * </p>
	 *
	 * @return the purchasePlanTypeFacet
	 */
	@Override
	public String getPurchasePlanTypeFacet() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getPurchasePlanTypeFacet(), this.brand);
	}
	/**
	 * <p>
	 * Fetches property to show hotspot plans
	 * </p>
	 *
	 * @return String - the applyHotspotPlanFacet
	 */
	@Override
	public String getApplyHotspotPlanFacet() {
		return StringUtils.isNotBlank(applyHotspotPlanFacet) ? applyHotspotPlanFacet : "false";
	}


	/**
	 * <p>
	 * Fetches hotspotPlanTypeFacet
	 * </p>
	 *
	 * @return the hotspotPlanTypeFacet
	 */
	@Override
	public String getHotspotPlanTypeFacet() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getHotspotPlanTypeFacet(), this.brand);
	}


	/**
	 * <p>
	 * Fetches servicePlanFacet
	 * </p>
	 *
	 * @return the servicePlanFacet
	 */
	@Override
	public String getServicePlanFacet() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getServicePlanFacet(), this.brand);
	}

	/**
	 * @return the activationPlanTypeFacet
	 */
	@Override
	public String getActivationPlanTypeFacet() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getActivationPlanTypeFacet(), this.brand);
	}

	/**
	 * <p>
	 * Fetches property to show activation plans
	 * </p>
	 *
	 * @return String - the applyActivationPlanFacet
	 */
	@Override
	public String getApplyActivationPlanFacet() {
		return StringUtils.isNotBlank(applyActivationPlanFacet) ? applyActivationPlanFacet : "false" ;
	}

	/**
	 * <p>
	 * Fetches label for compare link
	 * </p>
	 *
	 * @return String - the compareLinkLabel
	 */
	@Override
	public String getCompareLinkLabel() {
		return compareLinkLabel;
	}

	/**
	 * <p>
	 * Fetches specsOptions
	 * </p>
	 *
	 * @return the specsOptions
	 */
	@Override
	public String getSpecsOptions() {
		return specsOptions;
	}

	/**
	 * <p>
	 * Returns json from items
	 * </p>
	 *
	 * @return Map - items
	 */
	@Override
	public Map<String, ? extends ComponentExporter> getItems() {
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}

	/**
	 * @return the defaultPlanThumbnailImage
	 */
	@Override
	public String getDefaultPlanThumbnailImage() {
		return DynamicMediaUtils.changeMediaPathToDMPath(CommerceUtil
				.getPropertyValue(this.brandPropertyValueMap, DEFAULT_PLAN_THUMBNAIL_IMAGE), resourceResolver);
	}

	/**
	 * <p>
	 * Fetches skipPlanType property from config
	 * </p>
	 *
	 * @return String[] - skipPlanType
	 */
	@Override
	public String getSkipPlanType() {
		return applicationConfigService.noPlanCheck();
	}

	/**
	 * @return the planThumbnailImageWeberId
	 */
	@Override
	public String getPlanThumbnailImageWeberId() {
		return ApplicationUtil.getAssetMetaDataValue(getDefaultPlanThumbnailImage(),
				resourceResolver, ApplicationConstants.WEBER_ID);
	}

	/**
	 * @return the planThumbnailImageAssestId
	 */
	@Override
	public String getPlanThumbnailImageAssestId() {
		return ApplicationUtil.getAssetId(getDefaultPlanThumbnailImage(),
				resourceResolver, ApplicationConstants.IMAGE);
	}

	/**
	 * <p>
	 * Fetches isAddOn
	 * </p>
	 *
	 * @return the isAddOn
	 */
	@Override
	public String getIsAddOn() {
		return isAddOn;
	}

	/**
	 * <p>
	 * Fetches addOnPlanFacet 
	 * </p>
	 *
	 * @return the addOnPlanFacet
	 */

	@Override
	public String getAddOnPlanFacet() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getAddOnPlanFacet(), this.brand);
	}

	/**
	 * <p>
	 * Fetches showRewardsText
	 * </p>
	 *
	 * @return the showRewardsText
	 */
	@Override
	public String getShowRewardsText() {
		return showRewardsText;
	}

	/**
	 * <p>
	 * Fetches discountText
	 * </p>
	 *
	 * @return the discountText
	 */
	@Override
	public String getDiscountText() {
		return discountText;
	}

	/**
	 * <p>
	 * Fetches addButton
	 * </p>
	 *
	 * @return the addButton
	 */
	@Override
	public String getAddButton() {
		return addButton;
	}
	/**
	 * <p>
	 * Fetches disableBazaarVoiceRatings
	 * </p>
	 *
	 * @return the disableBazaarVoiceRatings
	 */
	@Override
	public String getDisableBazaarVoiceRatings() {
		return disableBazaarVoiceRatings;
	}
	/**
	 * <p>
	 * Fetches activation plans heading
	 * </p>
	 *
	 * @return String - the activationPlansHeading
	 */
	@Override
	public String getActivationPlansHeading() {
		return activationPlansHeading;
	}

	/**
	 * <p>
	 * Fetches label for current plan
	 * </p>
	 *
	 * @return String - the currentPlanLabel
	 */
	@Override
	public String getCurrentPlanLabel() {
		return currentPlanLabel;
	}

	/**
	 * @return the reactivationPlanTypeFacet
	 */
	@Override
	public String getReactivationPlanTypeFacet() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getReactivationPlanTypeFacet(), this.brand);
	}

	/**
	 * <p>
	 * Fetches label for phone number
	 * </p>
	 *
	 * @return String - the phoneNumberLabel
	 */
	@Override
	public String getPhoneNumberLabel() {
		return phoneNumberLabel;
	}

	/**
	 * <p>
	 * Fetches label for service end date
	 * </p>
	 *
	 * @return String - the serviceEndLabel
	 */
	@Override
	public String getServiceEndLabel() {
		return serviceEndLabel;
	}

	/**
	 * <p>
	 * Fetches label for different number
	 * </p>
	 *
	 * @return String - the differentNumberLabel
	 */
	@Override
	public String getDifferentNumberLabel() {
		return differentNumberLabel;
	}

	/**
	 * <p>
	 * Fetches heading for addon section
	 * </p>
	 *
	 * @return String - the addonSectionHeading
	 */
	@Override
	public String getAddonSectionHeading() {
		return addonSectionHeading;
	}
	/**
	 * @return the refillPlanTypeFacet
	 */
	@Override
	public String getRefillPlanTypeFacet() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getRefillPlanTypeFacet(), this.brand);
	}

	/**
	 * <p>
	 * Fetches refill page path
	 * </p>
	 *
	 * @return String - the refill page path
	 */
	@Override
	public String getRefillPagePath() {
		return ApplicationUtil.getShortUrl(resourceResolver, refillPagePath);
	}

	/**
	 * <p>
	 * Fetches plan Service Days Label
	 * </p>
	 *
	 * @return String - the plan Service Days Label
	 */
	@Override
	public String getPlanServiceDaysLabel() {
		return planServiceDaysLabel;
	}

	/**
	 * <p>
	 * Fetches property to show home internet plans
	 * </p>
	 *
	 * @return String - the applyHomeInternetPlanFacet
	 */
	@Override
	public String getApplyHomeInternetPlanFacet() {
		return StringUtils.isNotBlank(applyHomeInternetPlanFacet) ? applyHomeInternetPlanFacet : "false" ;
	}

	/**
	 * <p>
	 * Fetches homeInternetPlanFacet 
	 * </p>
	 *
	 * @return the homeInternetPlanFacet
	 */

	@Override
	public String getHomeInternetPlanFacet() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getHomeInternetPlanFacet(), this.brand);
	}

	/** Fetches plan Service Days Label
	 * </p>
	 *
	 * @return String - the plan Service Days Label
	 */

	@Override
	public String getViewFccLabelText() {
		return viewFccLabelText;
	}

	/**
	 * String is used for marketing API call
	 *
	 * @return String - queryString
	 */
	@Override
	public String getMarketingQueryString() {
		StringBuilder query = new StringBuilder("brandName").append(CommerceConstants.EQUALS_TO).append(brand)
				.append(CommerceConstants.AMPERSAND).append("sourceSystem").append(CommerceConstants.EQUALS_TO)
				.append(tracfoneApiService.getApiSourceSystem()).append(CommerceConstants.AMPERSAND).append("zipCode")
				.append(CommerceConstants.EQUALS_TO);
		return query.toString();
	}
	/**
	 * <p>
	 * Returns MarketingApiPath from configuration
	 * </p>
	 *
	 * @return String - MarketingApiPath
	 */
	@Override
	public String getMarketingApiPath() {
		return tracfoneApiService.getMarketingApiPath();
	}
	@Override
	public List<FeatureBean> getFeatureList() {
		return new ArrayList<>(featureList);
	}
	@Override
	public String getPdpJsonForLanding() {

		return pdpJsonPathForLanding;
	}
	@Override
	public String getHotspotPartClass() {
		return purchaseFlowConfigService.getHotspotPartClass();
	}
}

