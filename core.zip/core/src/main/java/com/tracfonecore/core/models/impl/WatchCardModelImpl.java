/*
 *  Copyright 2020 HCL Technologies Ltd.
 *
 */
package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.tracfonecore.core.beans.WatchCardBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.WatchCardModel;
import com.tracfonecore.core.models.ScriptingModel;
import com.tracfonecore.core.services.*;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import com.tracfonecore.core.utils.ItemsExporterUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.*;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.RepositoryException;
import java.text.DecimalFormat;
import java.util.Optional;
import java.util.*;

/**
 * @author vijaykumar.tripathi
 *
 */
@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { WatchCardModel.class,
		ComponentExporter.class }, resourceType = WatchCardModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class WatchCardModelImpl extends BaseComponentModelImpl implements WatchCardModel {
	private static final Logger LOGGER = LoggerFactory.getLogger(WatchCardModelImpl.class);
	protected static final String RESOURCE_TYPE = "tracfone-core/components/commerce/watchcard/v1/watchcard";

	

	@Inject
	@Via("resource")
	private Resource watchlist;

	@Inject
	private Page currentPage;

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private SlingModelFilter slingModelFilter;
	@Inject
	private DynamicMediaConfigService dynamicMediaConfig;
	@Inject
	private ModelFactory modelFactory;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String selection;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ctaLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean disableBazaarVoiceRatings;

	private JsonArray skusArray;

	private WatchCardBean watchcardBean;

	@ScriptVariable
	private ValueMap properties;

	private String thumbnailPath;

	private int productID;

	private String partNumber;

	private String categoryType;

	private String productType;

	private JsonObject product;

	private Map<String, String> skuMap;

	private List<WatchCardBean> colorList = Collections.emptyList();
	private String skuId;

	@Inject
	private TracfoneApiGatewayService tracfoneApiService;

	@Inject
	private ApplicationConfigService applicationConfigService;

	@Inject
	private ProductOfferingApiService productOfferingApiService;

	@Inject
	private Resource resource;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promotext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String rrcheck;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String smartpayIcon;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String logoalt;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String expriceprefix;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String expriceduration;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String expricesuffix;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String pricecaption;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String type;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String pdpPagePath;
	
	@ValueMapValue
	private String orderIndex;

	@OSGiService
	private TracfoneValueMappingConfigService tracfoneValueMappingConfigService;

	@ScriptVariable
	private ValueMap pdpProperties;
	
	@Inject
	@Self
	private ScriptingModel scriptingModel;

	/**
	 * <p>
	 * This method calls Magento graphql API using CIF framework- setQuery() method
	 * of OOB AbstractProductRetriever class to be used to execute custom query
	 * </p>
	 * 
	 */
	@PostConstruct
	protected void initModel() {
		try {
			LOGGER.debug("Entering: initModel method of WatchCardModelImpl");
			super.initModel();
			if (StringUtils.isNotEmpty(type) && StringUtils.equalsIgnoreCase("dynamic", type)
					&& StringUtils.isNotEmpty(pdpPagePath)) {
				LOGGER.debug("PDP path for dynamic inclusion of watch card {} ", pdpPagePath);
				Resource watchResource = request.getResourceResolver().resolve(pdpPagePath);
				if(null != watchResource){
					Page productPage = watchResource.adaptTo(Page.class);
					if (ApplicationUtil.isPdpPage(productPage, tracfoneValueMappingConfigService.pdpTemplateValues())
							&& !ApplicationUtil.isPageDeleted(productPage)) {
						ctaLink = pdpPagePath;
						ValueMap vm = request.getResourceResolver().resolve(pdpPagePath + CommerceConstants.JCR_CONTENT)
								.getValueMap();
						selection = vm.get(CommerceConstants.PART_NO, String.class);
						Resource phoneRes = getWatchResource();
						if (phoneRes != null) {
							pdpProperties = phoneRes.getValueMap();
							if (pdpProperties != null) {
								promotext = StringUtils.defaultString(
										pdpProperties.get(CommerceConstants.PLAN_PROMO_TEXT, String.class));
								expriceprefix = StringUtils.defaultString(
										pdpProperties.get(CommerceConstants.PHONE_EXPRICE_PREFIX, String.class));
								expricesuffix = StringUtils.defaultString(
										pdpProperties.get(CommerceConstants.PHONE_EXPRICE_SUFFIX, String.class));
								smartpayIcon = StringUtils.defaultString(
										pdpProperties.get(CommerceConstants.PHONE_SMART_PAY_LOGO, String.class));
								logoalt = StringUtils.defaultString(
										pdpProperties.get(CommerceConstants.PHONE_ALT_TEXT, String.class));
								pricecaption = StringUtils.defaultString(
										pdpProperties.get(CommerceConstants.PHONE_PRICE_CAPTION_PLP, String.class));
								expriceduration = StringUtils.defaultString(
										pdpProperties.get(CommerceConstants.PHONE_EXPRICE_DURATION, String.class));
								if(null==expriceduration || StringUtils.isEmpty(expriceduration))
									expriceduration = CommerceUtil.fetchDefaultExpPriceDuration(expriceduration, scriptingModel);
								Resource skuRes = request.getResourceResolver()
										.resolve(phoneRes.getPath() + CommerceConstants.COLOR_VARIANTS);
								if (null != skuRes) {
									thumbnailPath = skuRes.getValueMap().get(CommerceConstants.FIRST_IMAGE_PATH,
											String.class);
								}

							}
						}
					}
				}
			}
			if (selection != null && !selection.equals("")) {
				product = productOfferingApiService.getProductDetailObject(selection, currentPage);
				LOGGER.debug("Product Bean "+product);
				if(null!=product) {
						if(product.get(CommerceConstants.ID)!=null) 
							productID = product.get(CommerceConstants.ID).getAsInt();
						setWatchCardItems();
				}
				LOGGER.debug("Exiting: initModel method of PhoneCardModelImpl");
			}
		} catch (RuntimeException re) {
			LOGGER.error("API Exception occurred while fetching phone card details {}", re);
		}
	}

	/**
	 * Method to get exprice duration property from page
	 * 
	 * @param page
	 * @return String - exprice duration property from page
	 */
	private String getExpriceTerm(Page page) {
		String expricePriceTerm = "";

		Page parentPage = page.getParent();
		Page ancestorPage = parentPage.getParent();
		ValueMap properties = parentPage.getProperties();
		if (!(properties != null && properties.containsKey(CommerceConstants.CATEGORY_TYPE))) {
			parentPage = ancestorPage;
		}
		expricePriceTerm = CommerceUtil.getExpriceTerm(parentPage);		
		return expricePriceTerm;
	}
	/**
	 * Method to get Phone resource duration property from page
	 *
	 *  @return Resource - request property from page
	 */
	private Resource getWatchResource() {
		Resource watchResource = request.getResourceResolver()
				.resolve(pdpPagePath + CommerceConstants.PHONE_DETAIL_NODE_PATH);
				PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
               Page parentPage = Optional.ofNullable(pageManager).map(pm -> pm.getContainingPage(pdpPagePath))
			.filter(Objects::nonNull).map(Page::getParent).orElse(null);
               if (parentPage != null) {
				this.categoryType = parentPage.getName();
				productType = parentPage.getContentResource().getValueMap().get(CommerceConstants.CATEGORY_TYPE,String.class);
				if (StringUtils.isBlank(productType)) {
					productType = parentPage.getParent().getContentResource().getValueMap().get(CommerceConstants.CATEGORY_TYPE,String.class);	
				}
			}
		return watchResource;
	}
	/**
	 * Method to save phone card details
	 * 
	 * @return void
	 * @throws RepositoryException
	 */
	private void setWatchCardItems() {
			LOGGER.debug("Entering: setWatchCardItems method of WatchCardModelImpl");
			if (!(StringUtils.isNotEmpty(type) && StringUtils.equalsIgnoreCase("dynamic", type))) {
				Iterator<Resource> phonelistIterator = watchlist.listChildren();
				skuMap = new HashMap<String, String>();
				while (phonelistIterator.hasNext()) {
					watchcardBean = new WatchCardBean();
					Resource grandChild = phonelistIterator.next();
					String thumbnail = "";
					String skuPartNO = "";
					if (grandChild.getValueMap().get(CommerceConstants.MEDIA_PATH) != null) {
						thumbnail = grandChild.getValueMap().get(CommerceConstants.MEDIA_PATH).toString();
					}
					if (grandChild.getValueMap().get(CommerceConstants.SKUS_SELECTION) != null) {
						skuPartNO = grandChild.getValueMap().get(CommerceConstants.SKUS_SELECTION).toString();
					}
					skuMap.put(skuPartNO, thumbnail);
				}
			}
			colorList = new ArrayList<WatchCardBean>();
			if(null != product && product.get(CommerceConstants.SKUS) != null && product.get(CommerceConstants.SKUS).isJsonArray())
				skusArray = product.get(CommerceConstants.SKUS).getAsJsonArray();
			LOGGER.info("skusArray size {}", skusArray.size());
			if (skusArray.size() > 0) {
				for (int i = 0; i < skusArray.size(); i++) {
					JsonObject element = skusArray.get(i).getAsJsonObject();
					String color = element.get("color").getAsString();
					partNumber = skusArray.get(0).getAsJsonObject().get("partNumber").getAsString();
					skuId = skusArray.get(0).getAsJsonObject().get("id").getAsString();
					watchcardBean = new WatchCardBean();
					watchcardBean.setColor(color);
					colorList.add(watchcardBean);
				}
			}
			LOGGER.info("colorList size {}", colorList.size());
			if (!(StringUtils.isNotEmpty(type) && StringUtils.equalsIgnoreCase("dynamic", type))) {
				if (skuMap.size() > 0) {
					LOGGER.info("SKU map size {}", skuMap.size());
					thumbnailPath = skuMap.get(partNumber);
				}
			}
			LOGGER.debug("Exiting: setWatchCardItems method of WatchCardModelImpl");
	}

	/**
	 * <p>
	 * Method to return skuid
	 * </p>
	 * 
	 * @return String skuid
	 */
	public String getSkuId() {
		return skuId;
	}

	/**
	 * <p>
	 * Method to return ratings
	 * </p>
	 * 
	 * @return String ratings
	 */
	@Override
	public String getRating() {
		String rating = "0.0";
		if (product != null && product.get(CommerceConstants.RATINGS)!=null && StringUtils.isNotBlank(product.get(CommerceConstants.RATINGS).getAsString())) {
				rating = product.get(CommerceConstants.RATINGS).getAsString();
		}
		return rating;
	}

	/**
	 * <p>
	 * Method to return reviews
	 * </p>
	 * 
	 * @return String reviews
	 */
	@Override
	public String getReviews() {
		String reviews = "0";
		if (product != null && product.get(CommerceConstants.REVIEWS)!=null && StringUtils.isNotBlank(product.get(CommerceConstants.REVIEWS).getAsString())) {
				reviews = product.get(CommerceConstants.REVIEWS).getAsString();
		}
		return reviews;
	}

	/**
	* <p>
	* Returns  Bazaar Voice Ratings
	* </p>
	* 
	* @return Boolean - disableBazaarVoiceRatings
	*/
	@Override
	public Boolean getDisableBazaarVoiceRatings() {
	return disableBazaarVoiceRatings;
	}

	/**
	 * <p>
	 * Method to return list of color variants
	 * </p>
	 * 
	 * @return List<PhoneCardBean> colorList
	 */
	@Override
	public List<WatchCardBean> getSKUs() {

		return new ArrayList<>(colorList);
	}

	/**
	 * <p>
	 * Method to return path of phone image related to first SKU only
	 * </p>
	 * 
	 * @return String thumbnailPath
	 */
	@Override
	public String getThumbnail() {

		return DynamicMediaUtils.changeMediaPathToDMPath(thumbnailPath, request.getResourceResolver());
	}

	/**
	 * <p>
	 * Method to return path of phone image related to first SKU only
	 * </p>
	 * 
	 * @return String thumbnailPath
	 */
	@Override
	public String getImagePath() {
		return thumbnailPath;
	}

	public String getBreakPoints() {
		return dynamicMediaConfig.getBreakPoint();
	}

	/**
	 * <p>
	 * Method to return Price Api domain
	 * </p>
	 * 
	 * @return String
	 */
	public String getApiDomain() {

		return tracfoneApiService.getApiDomain();
	}

	/**
	 * <p>
	 * Method to return Price Api Path
	 * </p>
	 * 
	 * @return String
	 */
	public String getPriceApiPath() {

		return tracfoneApiService.getPriceApiPath();
	}

	/**
	 * <p>
	 * Method to return Home Page Level
	 * </p>
	 * 
	 * @return integer
	 */
	private int getHomePageLevel() {
		return applicationConfigService.getHomePageLevel();

	}

	/**
	 * <p>
	 * Method to return exporter type
	 * </p>
	 * 
	 * @return String
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	public Map<String, ? extends ComponentExporter> getItems() {
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}

	/**
	 * <p>
	 * Method to return current page language
	 * </p>
	 * 
	 * @return String language
	 */
	public String getLanguage() {
		String language = CommerceUtil.getLanguage(currentPage, getHomePageLevel());
		LOGGER.info("Phone card Language {}", language);
		return language;
	}

	/**
	 * <p>
	 * Method to return queryString to be used for price API call
	 * </p>
	 * 
	 * @return String queryString
	 */
	@Override
	public String getQueryString() {
		StringBuilder query = new StringBuilder(CommerceConstants.BRAND).append(CommerceConstants.EQUALS_TO)
				.append(CommerceUtil.getBrandValue(currentPage, getHomePageLevel())).append(CommerceConstants.AMPERSAND)
				.append(CommerceConstants.PRODUCT_ID).append(CommerceConstants.EQUALS_TO).append(this.productID)
				.append(CommerceConstants.AMPERSAND).append(CommerceConstants.LANGUAGE)
				.append(CommerceConstants.EQUALS_TO).append(getLanguage());
		return query.toString();
	}

	/**
	 * <p>
	 * Method to return product name like iphone
	 * </p>
	 * 
	 * @return String - name of phone
	 */
	@Override
	public String getName() {
		String name = StringUtils.EMPTY;
		if (product != null && product.get(CommerceConstants.NAME) != null) {
			name = product.get(CommerceConstants.NAME).getAsString();
		}
		return name;
	}

	/**
	 * <p>
	 * Format rating and remove trailing zeros
	 * </p>
	 * 
	 * @return String - rating without trailing zero
	 * 
	 */
	@Override
	public String getAccessibilityRating() {
		DecimalFormat format = new DecimalFormat(ApplicationConstants.TRAILING_ZERO);
		String accessibilityRating = getRating();
		LOGGER.info("accessibilityRating {}", accessibilityRating);
		if (StringUtils.isNotBlank(accessibilityRating)) {
			double ratingval = Double.parseDouble(getRating());
			accessibilityRating = format.format(ratingval);
		}
		LOGGER.info("accessibilityRating after trailing {}", accessibilityRating);
		return accessibilityRating;
	}

	/**
	 * Checks if the phone card is first in carousel then return animation timing.
	 * 
	 * @return String - animation value
	 */
	public String getAnimationValue() {
		String val = ApplicationConstants.POINT_SIX;

		Resource currentRes = request.getResource();
		if (currentRes != null) {
			String curentResName = currentRes.getName();
			if (curentResName.equals(CommerceConstants.PHONE1)) {
				val = ApplicationConstants.POINT_THREE;
			}
		}
		return val;

	}

	/**
	 * <p>
	 * Returns ctaLink
	 * </p>
	 * 
	 * @return String - ctaLink
	 */
	@Override
	public String getCtaLink() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), this.ctaLink);
	}

	/**
	 * <p>
	 * Fetches promotext
	 * </p>
	 *
	 * @return the promotext
	 */
	@Override
	public String getPromotext() {
		return promotext;
	}

	/**
	 * <p>
	 * Fetches rrcheck
	 * </p>
	 *
	 * @return the rrcheck
	 */
	@Override
	public String getRrcheck() {
		return rrcheck;
	}

	/**
	 * <p>
	 * Fetches smartpayIcon
	 * </p>
	 *
	 * @return the smartpayIcon
	 */
	@Override
	public String getSmartpayIcon() {
		return smartpayIcon;
	}

	/**
	 * <p>
	 * Fetches logoalt
	 * </p>
	 *
	 * @return the logoalt
	 */
	@Override
	public String getLogoalt() {
		return logoalt;
	}

	/**
	 * <p>
	 * Fetches expriceprefix
	 * </p>
	 *
	 * @return the expriceprefix
	 */
	@Override
	public String getExpriceprefix() {
		return expriceprefix;
	}

	/**
	 * <p>
	 * Fetches expriceduration
	 * </p>
	 *
	 * @return the expriceduration
	 */
	@Override
	public String getExpriceduration() {
		return expriceduration;
	}

	/**
	 * <p>
	 * Fetches expricesuffix
	 * </p>
	 *
	 * @return the expricesuffix
	 */
	@Override
	public String getExpricesuffix() {
		return expricesuffix;
	}

	/**
	 * <p>
	 * Fetches pricecaption
	 * </p>
	 *
	 * @return the pricecaption
	 */
	@Override
	public String getPricecaption() {
		return pricecaption;
	}

	/**
	 * <p>
	 * Fetches type
	 * </p>
	 *
	 * @return the type
	 */
	@Override
	public String getType() {
		return type;
	}

	/**
	 * <p>
	 * Fetches pdpPagePath
	 * </p>
	 *
	 * @return the pdpPagePath
	 */
	@Override
	public String getPdpPagePath() {
		return pdpPagePath;
	}

	/**
	 * @return the productID
	 */
	@Override
	public int getProductID() {
		return productID;
	}

	/**
	 * @return the partNumber
	 */
	@Override
	public String getPartNumber() {
		return partNumber;
	}

	/**
	 * @return the categoryType
	 */
	@Override
	public String getCategoryType() {
		return categoryType;
	}

	/**
	 * @return the productType
	 */
	@Override
	public String getProductType() {
		return productType;
	}
	
	/**
	 * @return the phoneCardButtonLabel
	 */
	@Override
	public String getWatchCardButtonLabel() {
		return (String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
				CommerceConstants.PHONE_PLAN_CAROUSEL_BUTTON_LABEL);
	}

	/**
	 * @return the selection
	 */
	public String getSelection() {
		return selection;
	}
	
	/**
	 * @return the enableButtonForProductCards
	 */
	@Override
	public String getEnableButtonForProductCards() {
		return (String) CommerceUtil.getPropertiesFromRootPage(currentPage,CommerceConstants.ENABLE_BUTTON_FOR_CAROUSEL_PRODUCT_CARD);
	}
	
	/**
	 * Method to return orderIndex
	 * 
	 * @return String orderIndex
	 */
	@Override
	public String getOrderIndex() {
		return orderIndex;
	}

}
