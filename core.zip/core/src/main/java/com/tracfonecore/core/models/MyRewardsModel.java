/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * Defines the {@code Multi-Links} Sling Model used for the {@code /apps/tracfone-core/components/spa/commerce/myrewards} component.
 */
public interface MyRewardsModel extends ComponentExporter {

	@JsonProperty("positionMyRewards")
	public String getPositionMyRewards();

	@JsonProperty("positionAccountNavigation")
	public String getPositionAccountNavigation();
	
	@JsonProperty("joinRewardsImageFileReference")
	public String getJoinRewardsImageFileReference();
	
	@JsonProperty("joinRewardsImageAltText")
	public String getJoinRewardsImageAltText();
	
	@JsonProperty("termsConditionsPagePath")
	public String getTermsConditionsPagePath();

	@JsonProperty("privacyPolicyPagePath")
	public String getPrivacyPolicyPagePath();
	
	@JsonProperty("categoryIdPlans")
	public String getCategoryIdPlans();
	
	@JsonProperty("joinMyRewardsSuccessModalHeading")
	public String getJoinMyRewardsSuccessModalHeading();
	
	@JsonProperty("joinMyRewardsSuccessModalSubHeading")
	public String getJoinMyRewardsSuccessModalSubHeading();
	
	@JsonProperty("joinMyRewardsSuccessModalSummary")
	public String getJoinMyRewardsSuccessModalSummary();
	
	@JsonProperty("alreadyEnrolledModalHeading")
	public String getAlreadyEnrolledModalHeading();
	
	@JsonProperty("alreadyEnrolledModalSubHeading")
	public String getAlreadyEnrolledModalSubHeading();
	
	@JsonProperty("alreadyEnrolledModalSummary")
	public String getAlreadyEnrolledModalSummary();

	@JsonProperty("planInfoModalContent")
	public String getPlanInfoModalContent();

	@JsonProperty("joinRewardsImageAssetId")
	public String getJoinRewardsImageAssetId();

	@JsonProperty("joinRewardsImageAssetAgencyId")
	public String getJoinRewardsImageAssetAgencyId();

	@JsonProperty("disableCaptcha")
	public String getDisableCaptcha();

	@JsonProperty("recaptchaSiteKeyValue")
	public String getReCaptchaSiteKey();

	@JsonProperty("enableMyRewardsForNonLoggedIn")
	public Boolean getEnableMyRewardsForNonLoggedIn();

	  /**
     * Get the homePageLevel
     * @return String - homePageLevel
     */
    public int getHomePageLevel();

	@JsonProperty("errorMessageForInactiveDevices")
	public String getErrorMessageForInactiveDevices();
	
	@JsonProperty("selectPlanDatePagePath")
	public String getSelectPlanDatePagePath();

	@JsonProperty("refillLandingPagePath")
	public String getRefillLandingPagePath();
}
