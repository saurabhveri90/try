/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl.v1;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;

import com.tracfonecore.core.models.ButterBarModel;

import com.tracfonecore.core.utils.DynamicMediaUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.*;

import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ButterBarModel.class,
		ComponentExporter.class }, resourceType = ButterBarModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ButterBarModelImpl extends com.tracfonecore.core.models.impl.BaseComponentModelImpl implements ButterBarModel {
	private static final Logger LOGGER = LoggerFactory.getLogger(ButterBarModelImpl.class);

	public static final String RESOURCE_TYPE = "tracfone-core/components/content/butterbar/v1/butterbar";

	@ValueMapValue
	private String timervalue;

	@ValueMapValue
	private String butterbarText;

	@ValueMapValue
	private String btnlistcheck;

	@ValueMapValue
	@Default(values = "dark-theme")
	private String theme;

	@ValueMapValue
	private String  mediaPath;
	@ValueMapValue
	private String mobileVersion;
	@Self
	private SlingHttpServletRequest request;


	@Override
	public String getExportedType() {
		return RESOURCE_TYPE;
	}


	@Override
	public String getTimervalue(){
		return timervalue;
	}

	@Override
	public String getButterbarText(){
		return butterbarText;
	}

	@Override
	public String getMediaPath(){
		return mediaPath;
	}

	@Override
	public String getBtnlistcheck(){
		return btnlistcheck;
	}

	/**
	 * <p>Returns the data mode</p>
	 *
	 * @return String - dataMode
	 */
	@Override
	public String getDataMode() {
		return this.mobileVersion;
	}
	/**
	 * <p>Returns the breakpoint for website from Dynamic media config</p>
	 *
	 * @return String - breakpoints
	 */
	@Override
	public String getImageProfileBreakpoints() {
		String path = this.mediaPath;
		String breakPoints = "";
		if("bgsmartcrop".equals(this.getDataMode())) {
			breakPoints = DynamicMediaUtils.getImageProfileBreakpoints(path, request.getResourceResolver());
		}
		return breakPoints;
	}

	@Override
	public String getMobileMediaImagePath() {
		String path = DynamicMediaUtils.getMobileDMPath(this.mediaPath, request.getResourceResolver());
		if(!"mobileimage".equals(this.mobileVersion)) {
			path = "";
		}
		return path;
	}

	/**
	 * <p>Returns the theme</p>
	 *
	 * @return String - theme
	 */
	@Override
	public String getTheme() {
		return this.theme;
	}
}