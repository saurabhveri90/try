/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.tracfonecore.core.beans.SpecsBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.AllPlpPagePathModel;
import com.tracfonecore.core.models.SearchResultModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.SearchConfigService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.utils.CommerceUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { SearchResultModel.class, ComponentExporter.class },
		resourceType = {"tracfone-core/components/content/searchresult/v1/searchresult","tracfone-core/components/content/searchresult/v2/searchresult"},
		defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class SearchResultModelImpl implements SearchResultModel {
	
	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue
	private String seeAllPhonesCtaLabel;
	
	@ValueMapValue
	private String seeAllPlansCtaLabel;
	
	@ValueMapValue
	private String seeAllAccessoriesCtaLabel;
	
	@ValueMapValue
	private String seeAllDevicesCtaLabel;
	
	@ValueMapValue
	private String seeAllPhoneSimCtaLabel;
	
	@ValueMapValue
	private String seeAllTabletSimCtaLabel;
	
	@ValueMapValue
	private String searchResultsPerPage;
	
	@ValueMapValue
	private String numberOfPagesInPagination;
	
	@ValueMapValue @Default(values="All Categories")
	private String titleAllCategoriesFacet;
	
	@ValueMapValue
	private String lblResultsFor;
	
	@ValueMapValue
	private String lblResults;
	
	@ValueMapValue @Default(values="Out of Stock")
	private String outOfStockLabel;
	
	@ValueMapValue @Default(values="false")
	private String enableFilterByLanguage;
	
    @Inject
    private ApplicationConfigService applicationConfigService;
    
    @Inject
    private TracfoneApiGatewayService tracfoneApiService;

    @Inject
    private SearchConfigService searchConfigService;
    
    @Inject
    private Page currentPage;
        
    private String searchAuthoring;
    private String specsOptions;
	private String planServiceDaysLabel;
	private String allPlpPathsWithCategories;
	private ObjectMapper mapper;
	
    private static final Logger LOGGER = LoggerFactory.getLogger(SearchResultModelImpl.class);

    @PostConstruct
    private void initModel() throws JsonProcessingException {
        LOGGER.debug("Entering initModel method");
        mapper = new ObjectMapper();    
        allPlpPathsWithCategories = retrieveAllPlpPagePaths();
        ObjectNode objNode = mapper.createObjectNode();
        SpecsBean specsBean = CommerceUtil.getProductSpecificationUnit(currentPage, getHomePageLevel());
        if(specsBean.getOtherSpecs() != null) {
	        specsBean.getOtherSpecs().forEach(entry -> {
		    	if(StringUtils.equalsIgnoreCase(entry.getIdentifier(), CommerceConstants.PLAN_SERVICE_DAYS)) {
		    		planServiceDaysLabel = entry.getUnit();
		    	}
	        });
        }
        if(specsBean.getSpecsOptions() != null) {
	        objNode.putPOJO(CommerceConstants.SPECS_OPTIONS, specsBean.getSpecsOptions());	        
        }
        specsOptions = mapper.writeValueAsString(objNode);
        searchAuthoring = setSearchAuthoring();   
  		LOGGER.debug("Exiting initModel method");	
    }

	private int getHomePageLevel() {
        return applicationConfigService.getHomePageLevel();
    }

    @Override
    public String getLanguage() {
        return CommerceUtil.getLanguage(currentPage, getHomePageLevel());
    }
	
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getSearchResultsPerPage() {
		return searchResultsPerPage;
	}

	@Override
	public String getNumberOfPagesInPagination() {
		return numberOfPagesInPagination;
	}

	@Override
	public String getEnableFilterByLanguage() {
		return enableFilterByLanguage;
	}
    
    @Override
    public String getApiDomain() {
        return tracfoneApiService.getApiDomain();
    }
    
    @Override
    public String getCategoryApiPath() {
        return tracfoneApiService.getCategoryApiPath();
    }
    
    @Override
    public String getSearchApiDomain() {
        return searchConfigService.searchApiDomain();
    }

    @Override
    public String getSearchApiPath() {
        return searchConfigService.searchApiPath();
    }

    @Override
    public String getSearchApiEngineKey() {
        return getValueByBrandAndLanguage(searchConfigService.searchApiEngineKey());
    }

    @Override
    public String getSearchApiFetchFields() {
        return getValueByBrandAndLanguage(searchConfigService.searchApiFetchFields());
    }

    @Override
    public String getSearchApiSearchFields() {
        return getValueByBrandAndLanguage(searchConfigService.searchApiSearchFields());
    }

    @Override
    public String getSearchApiFacetFields() {
        return getValueByBrandAndLanguage(searchConfigService.searchApiFacetFields());
    }
    
    private String getValueByBrandAndLanguage(String[] valueArray) {
        String retValue="";
        Map<String, String> retMap = new HashMap<>();
        String brandName = CommerceUtil.getBrandValue(currentPage, getHomePageLevel());
        String language = CommerceUtil.getLanguage(currentPage, getHomePageLevel());
        if (StringUtils.isNotBlank(brandName) && valueArray != null) {
            for (String configValue : valueArray) {
                if (StringUtils.isNotBlank(configValue)&& configValue.indexOf(ApplicationConstants.COLON)!=-1) {
                    String[] valuesArray = configValue.split(ApplicationConstants.COLON);
                    if(null != valuesArray && valuesArray.length == 3 && StringUtils.equalsIgnoreCase(brandName,valuesArray[0]) && StringUtils.isNotBlank(valuesArray[1])&&StringUtils.isNotBlank(valuesArray[2])) {
                        retMap.put(valuesArray[1].trim(), valuesArray[2].trim());
                        if(StringUtils.isNotBlank(language)){
                            retValue = retMap.get(language);
                        }
                    }else if(null != valuesArray && valuesArray.length == 2 && StringUtils.equalsIgnoreCase(brandName,valuesArray[0]) && StringUtils.isNotBlank(valuesArray[1])){
                        retValue = valuesArray[1].trim();
                    }
                }
            }   
        }
        return retValue;
    }
    
    

	@Override
	public String getAllPlpPathsWithCategories() {
        return allPlpPathsWithCategories;
	}

	/**
	 * @return the specsOptions
	 */
	@Override
	public String getSpecsOptions() {
		return specsOptions;
	}
	
	private String retrieveAllPlpPagePaths() throws JsonProcessingException {
		String allPlpPathsWithCategories = "";
		Page homePage = currentPage.getAbsoluteParent(applicationConfigService.getHomePageLevel());
        if(homePage != null) {
            AllPlpPagePathModel allPlpPagePath = homePage.getContentResource().adaptTo(AllPlpPagePathModel.class);
            allPlpPathsWithCategories = mapper.writeValueAsString(allPlpPagePath);
        }
        return allPlpPathsWithCategories;
	}
	
	/**
	 * @return the searchAuthoring
	 * @throws JsonProcessingException 
	 */
    @Override
	public String getSearchAuthoring() {		
		return searchAuthoring;
	}
    
    private String setSearchAuthoring() throws JsonProcessingException {
	    String[] properties = {CommerceConstants.BUY_NOW_REWARDS_HELP_TEXT, CommerceConstants.THRESHOLD_LABEL, CommerceConstants.SINGLE_BUCKET_TEXT, 
	    		CommerceConstants.SINGLE_BUCKET_UNIT, CommerceConstants.THRESHOLD_VALUE, CommerceConstants.THRESHOLD_UNIT};
	    Map<String, Object> propertyValueMap = CommerceUtil.getMultiplePagePropertyValue(currentPage, getHomePageLevel(), properties);
	    
	  //Authoring text Object
	    ObjectNode searchAuthoringObj = mapper.createObjectNode();
		searchAuthoringObj.put("thresholdLabel", CommerceUtil.getPropertyValue(propertyValueMap, CommerceConstants.THRESHOLD_LABEL));
		searchAuthoringObj.put("singleBucketText", CommerceUtil.getPropertyValue(propertyValueMap, CommerceConstants.SINGLE_BUCKET_TEXT));
		searchAuthoringObj.put("singleBucketUnit", CommerceUtil.getPropertyValue(propertyValueMap, CommerceConstants.SINGLE_BUCKET_UNIT));
		searchAuthoringObj.put("sbThresholdValue", CommerceUtil.getPropertyValue(propertyValueMap, CommerceConstants.THRESHOLD_VALUE));
		searchAuthoringObj.put("sbThresholdUnit", CommerceUtil.getPropertyValue(propertyValueMap, CommerceConstants.THRESHOLD_UNIT));
		searchAuthoringObj.put("buyNowRewardsHelpText", CommerceUtil.getPropertyValue(propertyValueMap, CommerceConstants.BUY_NOW_REWARDS_HELP_TEXT));
		searchAuthoringObj.put("phoneCtaLabel", seeAllPhonesCtaLabel);
		searchAuthoringObj.put("planCtaLabel", seeAllPlansCtaLabel);
		searchAuthoringObj.put("accessoryCtaLabel", seeAllAccessoriesCtaLabel);
		searchAuthoringObj.put("deviceCtaLabel", seeAllDevicesCtaLabel);
		searchAuthoringObj.put("phonesimCtaLabel", seeAllPhoneSimCtaLabel);
		searchAuthoringObj.put("tabletsimCtaLabel", seeAllTabletSimCtaLabel);
		searchAuthoringObj.put("lblResultsFor", lblResultsFor);
		searchAuthoringObj.put("lblResults", lblResults);
		searchAuthoringObj.put("titleAllCategoriesFacet", titleAllCategoriesFacet);	
		searchAuthoringObj.put("planServiceDaysLabel", planServiceDaysLabel);
		searchAuthoringObj.put("outOfStockLabel", outOfStockLabel);
		return mapper.writeValueAsString(searchAuthoringObj);
    }
	
}
