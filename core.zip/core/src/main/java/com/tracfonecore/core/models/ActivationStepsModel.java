/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Multi-Links} Sling Model used for the {@code /apps/tracfone-core/components/spa/commerce/activationsteps} component.
 */
public interface ActivationStepsModel extends ComponentExporter {
	/**
	 * <p>Fetches CTA button alt-text for the activation steps component</p>
	 * 
	 * @return String - ctaAltText for the activation steps component
	 */
	@JsonProperty("ctaAltText")
	public String getCtaAltText();

	/**
	 * <p>Fetches CTA button label for the activation steps component</p>
	 * 
	 * @return String - ctaLabel for the activation steps component
	 */
	@JsonProperty("ctaLabel")
	public String getCtaLabel();
	
	/**
	 * <p>Fetches title for the activation steps component</p>
	 * 
	 * @return String - title for the activation steps component
	 */
	@JsonProperty("title")
	public String getTitle();

	/**
	 * <p>Fetches heading summary for the activation steps component</p>
	 * 
	 * @return String - headingSummary for the activation steps component
	 */
	@JsonProperty("headingSummary")
	public String getHeadingSummary();

	/**
	 * <p>Fetches footer text for the activation steps component</p>
	 * 
	 * @return String - footerText for the activation steps component
	 */
	@JsonProperty("footerText")
	public String getFooterText();

	/**
	 * <p>Fetches rafcode page info text for the activation steps component</p>
	 * 
	 * @return String - rafcode page info text for the activation steps component
	 */
	@JsonProperty("rafCodePageInfo")
	public String getRafCodePageInfo();

	/**
	 * <p>Fetches showActivatedEsn flag for activation steps</p>
	 *
	 * @return Boolean - showActivatedEsn flag for activation steps
	 */
	@JsonProperty("showActivatedEsn")
	public String getShowActivatedEsn();

	/**
	 * <p>Fetches esnTitle for activation steps</p>
	 *
	 * @return Boolean - esnTitle for activation steps
	 */
	@JsonProperty("esnTitle")
	public String getEsnTitle();

	/**
	 * <p>Fetches home internet heading summary for the activation steps component</p>
	 * 
	 * @return String - headingSummary for the activation steps component
	 */
	@JsonProperty("homeInternetHeadingSummary")
	public String getHomeInternetHeadingSummary();

	/**
	 * <p>Fetches showRafCodePage flag for activation steps</p>
	 *
	 * @return Boolean - showRafCodePage flag for activation steps
	 */
	@JsonProperty("showRafCodePage")
	public Boolean getShowRafCodePage();

	/**
	 * <p>Fetches error codes for the activation steps component</p>
	 * 
	 * @return String - error codes for the activation steps component
	 */
	@JsonProperty("errorCodes")
	public String getErrorCodes();
	
}
