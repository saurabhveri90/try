package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.sling.api.resource.Resource;

/**
 * Defines the {@code accessibilityfeatures} Sling Model used for the {@code /apps/tracfone-core/components/content/accessibilityfeatures} component.
 */
public interface PromoNotificationBeanModel extends ComponentExporter {

    /**
     * <p>Fetches planType.</p>
     *
     * @return String - planType.
     */
    @JsonProperty("planType")
    public String getPlanType();

    /**
     * <p>Fetches promoText</p>
     *
     * @return String - promoText
     */
    @JsonProperty("promoText")
    public String getPromoText();

    /**
     * <p>Fetches promonotificationIcon</p>
     *
     * @return String - promonotificationIcon
     */
    @JsonProperty("promonotificationIcon")
    public String getPromonotificationIcon();

}
