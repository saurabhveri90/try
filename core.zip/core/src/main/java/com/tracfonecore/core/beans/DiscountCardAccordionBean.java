package com.tracfonecore.core.beans;

public class DiscountCardAccordionBean {

    private String accordionTitle;
	private String accordionText;
    public String getAccordionTitle() {
		return accordionTitle;
	}
	public void setAccordionTitle(String accordionTitle) {
		this.accordionTitle = accordionTitle;
	}
	public String getAccordionText() {
		return accordionText;
	}
	public void setAccordionText(String accordionText) {
		this.accordionText = accordionText;
	}

}