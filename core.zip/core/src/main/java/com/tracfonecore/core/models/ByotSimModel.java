package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public interface ByotSimModel extends ComponentExporter{

    /**
     * <p>Fetches heading</p>
     *
     * @return String - heading
     */
    @JsonProperty("heading")
    public String getHeading();

    /**
     * <p>Fetches summary</p>
     *
     * @return String - summary
     */
    @JsonProperty("summary")
    public String getSummary();

    /**
     * <p>Fetches all the multi-options</p>
     *
     * @return List - all the multi-options
     */
    @JsonProperty("options")
    public List<ByotSimOptionsModel> getOptions();
    
    /**
     * <p>Fetches scanText</p>
     *
     * @return String - scanText
     */
    @JsonProperty("scanText")
    public String getScanText();

    /**
     * <p>Fetches scanPlacement</p>
     *
     * @return String - scanPlacement
     */
    @JsonProperty("scanPlacement")
    public String getScanPlacement();
}
