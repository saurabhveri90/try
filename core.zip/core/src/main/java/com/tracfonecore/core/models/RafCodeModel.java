package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

public interface RafCodeModel extends ComponentExporter {

	/**
     * <p>Fetches heading </p>
     *
     * @return String - heading
     */
    @JsonProperty("heading")
    public String getHeading();

    /**
     * <p>Fetches sub heading </p>
     *
     * @return String - sub heading
     */
    @JsonProperty("subHeading")
    public String getSubHeading();

    /**
     * <p>Fetches minheading </p>
     *
     * @return String - minheading
     */
    @JsonProperty("minHeading")
    public String getMinHeading();

    /**
     * <p>Fetches min placeholder </p>
     *
     * @return String - min placeholder
     */
    @JsonProperty("minPlaceHolder")
    public String getMinPlaceHolder();

    /**
     * <p>Fetches rafcode heading </p>
     *
     * @return String - rafcode heading
     */
    @JsonProperty("rafCodeheading")
    public String getRafCodeheading();

    /**
     * <p>Fetches raf code placehoder </p>
     *
     * @return String - raf code placeholder
     */
    @JsonProperty("rafCodePlaceHolder")
    public String getRafCodePlaceHolder();

    /**
	 * <p>Fetches image path for the section</p>
	 * 
	 * @return String - image path for the section
	 */
	@JsonProperty("rafCodePageImagePath")
	public String getRafCodePageImagePath();

    /**
	 * <p>Fetches  path for the section</p>
	 * 
	 * @return String -  path for the section
	 */
	@JsonProperty("termsConditionsPagePath")
	public String getTermsConditionsPagePath();

    /**
	 * <p>Fetches  path for the section</p>
	 * 
	 * @return String -  path for the section
	 */
	@JsonProperty("privacyPolicyPagePath")
	public String getPrivacyPolicyPagePath();

    /**
	 * <p>Fetches  text for the section</p>
	 * 
	 * @return String -  text for the section
	 */
	@JsonProperty("termsConditionsAriaLabel")
	public String getTermsConditionsAriaLabel();

    /**
	 * <p>Fetches  text for the section</p>
	 * 
	 * @return String -  text for the section
	 */
	@JsonProperty("continueBtnAriaLabel")
	public String getContinueBtnAriaLabel();


    /**
	 * <p>Fetches  text for the section</p>
	 * 
	 * @return String -  text for the section
	 */
	@JsonProperty("learnMoreAriaLabel")
	public String getLearnMoreAriaLabel();

    /**
	 * <p>Fetches  text for the section</p>
	 * 
	 * @return String -  text for the section
	 */
	@JsonProperty("oneTimeErrorCodes")
	public String getOneTimeErrorCodes();

    /**
	 * <p>Fetches  text for the section</p>
	 * 
	 * @return String -  text for the section
	 */
	@JsonProperty("threeTimesErrorCodes")
	public String getThreeTimesErrorCodes();

}
