/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.PlanStartDateModel;
/**
 * Defines the model for Retrieve Order Number component
 */
@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { PlanStartDateModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/planstartdate", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class PlanStartDateModelImpl implements PlanStartDateModel {

	@Self
	private SlingHttpServletRequest request;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String screenTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String screenHeading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String screenDescription;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String reservePlanText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planExpiresText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String startToday;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String startTodayWarning;
	
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>Title for Plan Start Date screen</p>
	 * 
	 * @return String - screenTitle
	 */
	@Override
	public String getScreenTitle() {
		return screenTitle;
	}
	
	/**
	 * <p>startTodayWarning for Plan Start Date screen</p>
	 * 
	 * @return String - startTodayWarning
	 */
	@Override
	public String getStartTodayWarning() {
		return startTodayWarning;
	}

	/**
	 * <p>Heading for Plan Start Date screen.</p>
	 *
	 * @return String - screenHeading.
	 */
	@Override
	public String getScreenHeading() {
		return screenHeading;
	}

	/**
	 * <p>Description for Plan Start Date screen.</p>
	 *
	 * @return String - screenDescription.
	 */
	@Override
	public String getScreenDescription() {
		return screenDescription;
	}

	/**
	 * <p>Reserve Plan Text.</p>
	 *
	 * @return String - reservePlanText.
	 */
	@Override
	public String getReservePlanText() {
		return reservePlanText;
	}

	/**
	 * <p>Plan Expires Text.</p>
	 *
	 * @return String - planExpiresText.
	 */
	@Override
	public String getPlanExpiresText() {
		return planExpiresText;
	}

	/**
	 * <p>Start Today Text.</p>
	 *
	 * @return String - startToday.
	 */
	@Override
	public String getStartToday() {
		return startToday;
	}
	
}