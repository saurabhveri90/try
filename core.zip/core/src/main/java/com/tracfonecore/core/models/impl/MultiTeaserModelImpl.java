/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.MultiTeaserModel;
import com.tracfonecore.core.utils.ItemsExporterUtil;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { MultiTeaserModel.class,ComponentExporter.class },
		resourceType = "tracfone-core/components/content/multiteaser", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR,
		extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class MultiTeaserModelImpl extends BaseComponentModelImpl implements MultiTeaserModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(MultiTeaserModelImpl.class);

	@ScriptVariable
	private ValueMap properties;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String teaserType;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Integer count;

	private List<Integer> countarray = Collections.emptyList();

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private SlingModelFilter slingModelFilter;
	@Inject
	private ModelFactory modelFactory;

	@Override
	public String getTeaserType() {
		return teaserType;
	}

	@Override
	public Integer getCount() {
		if(count== null)
			count= 0;
		return count;
	}

	@Override
	public Integer getColumn() {
		int col;
		if (count==null || 0 == count)
			col = ApplicationConstants.TOTAL_COL;
		else 
			col = ApplicationConstants.TOTAL_COL/count;
		return col;
	}

	@Override
	public List<Integer> getCountArray() {
		countarray = new ArrayList<Integer>();
		if(count!=null)
		{
			for (int i = 1;i<=count;i++){
				countarray.add(i);
			}
		}
		
		return new ArrayList<>(countarray);
	}


	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public Map<String, ? extends ComponentExporter> getItems(){
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}
	
	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering initModel method");
			super.initModel();			
		LOGGER.debug("Exiting initModel method");
	}

}