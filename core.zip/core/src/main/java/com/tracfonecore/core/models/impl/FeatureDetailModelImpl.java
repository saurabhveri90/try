/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl;


import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.tracfonecore.core.beans.LinkBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.FeatureDetailModel;
import com.tracfonecore.core.utils.ItemsExporterUtil;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.*;


@Model(adaptables = {SlingHttpServletRequest.class, Resource.class}, adapters = {FeatureDetailModel.class, ComponentExporter.class},
        resourceType = "tracfone-core/components/content/featureDetails", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true"),
        @ExporterOption(name = "SerializationFeature.FAIL_ON_EMPTY_BEANS", value = "false") })
public class FeatureDetailModelImpl implements FeatureDetailModel {

    private static final Logger LOGGER = LoggerFactory.getLogger(FeatureDetailModelImpl.class);
    protected static final String RESOURCE_TYPE = "tracfone-core/components/content/featureDetails";

    @Self
    private SlingHttpServletRequest request;

    @Inject
    private Resource resource;
    @Inject
    private SlingModelFilter slingModelFilter;
    @Inject
    private ModelFactory modelFactory;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String displayType;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String title;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    @Default(values = "Show More")
	private String ctaTextShowMore;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Default(values = "Show Less")
	private String ctaTextShowLess;

    private List<LinkBean> multilinks = Collections.emptyList();
    LinkBean linkBean;

    @PostConstruct
    protected void initModel() {

        LOGGER.info("Executing FeatureDetailModelImpl initModel method");
        multilinks = new ArrayList<LinkBean>();

        for (Resource child : resource.getChildren()) {
            if (ApplicationConstants.MULTI_LINKS.equals(child.getName())) {
                Iterator<Resource> it = child.listChildren();
                setMultiFieldItems(it, multilinks);
            }
        }
    }

    /**
     * <p>Populates a list with all the multi-links</p>
     *
     * @param it             - iterator of the parent node
     * @param multiFieldData - list in which the multi links data needs to be set
     */
    private void setMultiFieldItems(Iterator<Resource> it, List<LinkBean> multiFieldData) {
        LOGGER.info("Entering FeatureDetailModelImpl setMultiFieldItems method ");

            while (it.hasNext()) {
                linkBean = new LinkBean();
                Resource grandChild = it.next();

                linkBean.setHeading(grandChild.getValueMap().get(ApplicationConstants.HEADING, String.class));
                linkBean.setLinkText(grandChild.getValueMap().get(ApplicationConstants.LINK_TEXT, String.class));
                linkBean.setLinkAltText(grandChild.getValueMap().get(ApplicationConstants.LINK_ALT_TEXT, String.class));
                linkBean.setLinkIcon(grandChild.getValueMap().get(ApplicationConstants.ICON, String.class));

                multiFieldData.add(linkBean);
            }

        LOGGER.info("Exiting FeatureDetailModelImpl setMultiFieldItems method ");
    }

    @Override
    public String getDisplayType() {
        return displayType;
    }

    @Override
    public String getTitle() {
        return title;
    }

    @Override
    public List<LinkBean> getMultilinks() { return new ArrayList<>(multilinks); }

    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }


	/**
	 *<p>Fetches ctaTextShowMore</p>
	 *
	 * @return the ctaTextShowMore
	 */
	public String getCtaTextShowMore() {
		return ctaTextShowMore;
	}

	/**
	 *<p>Fetches ctaTextShowLess</p>
	 *
	 * @return the ctaTextShowLess
	 */
	public String getCtaTextShowLess() {
		return ctaTextShowLess;
	}
    
    /**
     * @return getexportertype
     */
	@Override
    public Map<String, ? extends ComponentExporter> getItems() {
        return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
    }
}

