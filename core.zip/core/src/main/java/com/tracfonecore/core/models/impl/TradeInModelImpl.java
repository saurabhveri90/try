/**
 * Copyright 2020 HCL Technologies Ltd.
 */
package com.tracfonecore.core.models.impl;

import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import com.tracfonecore.core.utils.ApplicationUtil;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.TradeInModel;
import com.tracfonecore.core.services.TradeInConfigService;

/**
 * Trade-In Model Implementation
 *
 */
@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { TradeInModel.class,
		ComponentExporter.class }, resourceType = TradeInModelImpl.RESOURCE_TYPE)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class TradeInModelImpl implements TradeInModel {

	protected static final String RESOURCE_TYPE = "tracfone-core/components/content/tradein";
	
	@Inject
	@Optional
	private TradeInConfigService tradeInConfigService;

	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue
	@Optional
	private String stepZeroTitle;

	@ValueMapValue
	@Optional
	private String stepZeroDesc;

	@Inject
	@Via("resource")
	@Optional
	private Resource tradeInSteps;

	@ValueMapValue
	@Optional
	private String stepZeroButtonNext;

	@ValueMapValue
	@Optional
	private String stepZeroCancelText;

	@ValueMapValue
	@Optional
	private String stepZeroContinueCartText;

	@ValueMapValue
	@Optional
	private String continueToCartLink;

	@ValueMapValue
	@Optional
	private String stepZeroDonotfollowlink;

	@ValueMapValue
	@Optional
	private String stepOneTitle;

	@ValueMapValue
	@Optional
	private String stepOneButtonNext;

	@ValueMapValue
	@Optional
	private String stepOneButtonBack;

	@ValueMapValue
	@Optional
	private String stepTwoTitle;

	@ValueMapValue
	@Optional
	private String stepTwoDropdownLabel;

	@ValueMapValue
	@Optional
	private String stepTwoPlaceholderText;

	@ValueMapValue
	@Optional
	private String stepTwoButtonNext;

	@ValueMapValue
	@Optional
	private String stepTwoButtonBack;

	@ValueMapValue
	@Optional
	private String stepTwoPopPhonesLabel;

	@ValueMapValue
	@Optional
	private String stepThreeTitle;

	@ValueMapValue
	@Optional
	private String stepThreeDesc;

	@ValueMapValue
	@Optional
	private String stepThreeStorage;

	@ValueMapValue
	@Optional
	private String stepThreeCarrier;

	@ValueMapValue
	@Optional
	private String stepThreePlaceholderText;

	@ValueMapValue
	@Optional
	private String stepThreeButtonNext;

	@ValueMapValue
	@Optional
	private String stepThreeButtonBack;

	@ValueMapValue
	@Optional
	private String stepFourTitle;

	@ValueMapValue
	@Optional
	private String stepFourButtonNext;

	@ValueMapValue
	@Optional
	private String stepFourButtonBack;

	@ValueMapValue
	@Optional
	private String stepFiveTitle;

	@ValueMapValue
	@Optional
	private String stepFiveDesc;

	@ValueMapValue
	@Optional
	private String stepFiveButtonNext;

	@ValueMapValue
	@Optional
	private String stepFiveButtonBack;

	@ValueMapValue
	@Optional
	private String stepSixTitle;

	@ValueMapValue
	@Optional
	private String stepSixDesc;

	@ValueMapValue
	@Optional
	private String stepSixAcknowledge;

	@ValueMapValue
	@Optional
	private String stepSixResetTitle;

	@ValueMapValue
	@Optional
	private String stepSixResetDesc;

	@ValueMapValue
	@Optional
	private String stepSixResetStepsIOS;

	@ValueMapValue
	@Optional
	private String stepSixResetStepsAnd;

	@ValueMapValue
	@Optional
	private String stepSixButtonNext;

	@ValueMapValue
	@Optional
	private String stepSixButtonBack;

	@ValueMapValue
	@Optional
	private String stepSixTermsText;

	@ValueMapValue
	@Optional
	private String stepSixTermsLink;

	@ValueMapValue
	@Optional
	private String stepSixDonotfollowlink;
	
	@ValueMapValue
	@Optional
	private String stepSixShopPhonesButton;

	@ValueMapValue
	@Optional
	private String stepSixShopPhonesLink;

	@ValueMapValue
	@Optional
	private String stepSixDonotfollowlinkSP;

	@ValueMapValue
	@Optional
	private String errorMessageTitle;

	@ValueMapValue
	@Optional
	private String errorMessageDesc;

	@ValueMapValue
	@Optional
	private String errorContinueCartText;

	@ValueMapValue
	@Optional
	private String errorContinueToCartLink;

	@ValueMapValue
	@Optional
	private String errorDonotfollowlink;
	
	@ValueMapValue
	@Optional
	private String placementText;
	
	
	public String getTradeInCartUri() {
		
		return tradeInConfigService.getApiHylaCartUri();
	}
	
	@Override
	public String getTradeInBaseAPI() {
		
		return tradeInConfigService.getApiBaseEndPoint();
	}

	@Override
	public String getStepZeroTitle() {

		return this.stepZeroTitle;
	}

	@Override
	public String getStepZeroDesc() {

		return this.stepZeroDesc;
	}

	@Override
	public Resource getTradeInSteps() {

		return this.tradeInSteps;
	}

	@Override
	public String getStepZeroButtonNext() {

		return this.stepZeroButtonNext;
	}

	@Override
	public String getStepZeroCancelText() {

		return this.stepZeroCancelText;
	}

	@Override
	public String getStepZeroContinueCartText() {

		return this.stepZeroContinueCartText;
	}

	@Override
	public String getContinueToCartLink() {

  	return ApplicationUtil.getShortUrl(request.getResourceResolver(), this.continueToCartLink);
	}

	@Override
	public String getStepZeroDonotfollowlink() {

		return this.stepZeroDonotfollowlink;
	}

	@Override
	public String getStepOneTitle() {

		return this.stepOneTitle;
	}

	@Override
	public String getStepOneButtonNext() {

		return this.stepOneButtonNext;
	}

	@Override
	public String getStepOneButtonBack() {

		return this.stepOneButtonBack;
	}

	@Override
	public String getStepTwoTitle() {

		return this.stepTwoTitle;
	}

	@Override
	public String getStepTwoDropdownLabel() {

		return this.stepTwoDropdownLabel;
	}

	@Override
	public String getStepTwoPlaceholderText() {

		return this.stepTwoPlaceholderText;
	}

	@Override
	public String getStepTwoButtonNext() {

		return this.stepTwoButtonNext;
	}

	@Override
	public String getStepTwoButtonBack() {

		return this.stepTwoButtonBack;
	}

	@Override
	public String getStepTwoPopPhonesLabel() {

		return this.stepTwoPopPhonesLabel;
	}

	@Override
	public String getStepThreeTitle() {

		return this.stepThreeTitle;
	}

	@Override
	public String getStepThreeDesc() {

		return this.stepThreeDesc;
	}

	@Override
	public String getStepThreeStorage() {

		return this.stepThreeStorage;
	}

	@Override
	public String getStepThreeCarrier() {

		return this.stepThreeCarrier;
	}

	@Override
	public String getStepThreePlaceholderText() {

		return this.stepThreePlaceholderText;
	}

	@Override
	public String getStepThreeButtonNext() {

		return this.stepThreeButtonNext;
	}

	@Override
	public String getStepThreeButtonBack() {

		return this.stepThreeButtonBack;
	}

	@Override
	public String getStepFourTitle() {

		return this.stepFourTitle;
	}

	@Override
	public String getStepFourButtonNext() {

		return this.stepFourButtonNext;
	}

	@Override
	public String getStepFourButtonBack() {

		return this.stepFourButtonBack;
	}

	@Override
	public String getStepFiveTitle() {

		return this.stepFiveTitle;
	}

	@Override
	public String getStepFiveDesc() {

		return this.stepFiveDesc;
	}

	@Override
	public String getStepFiveButtonNext() {

		return this.stepFiveButtonNext;
	}

	@Override
	public String getStepFiveButtonBack() {

		return this.stepFiveButtonBack;
	}

	@Override
	public String getStepSixTitle() {

		return this.stepSixTitle;
	}

	@Override
	public String getStepSixDesc() {

		return this.stepSixDesc;
	}

	@Override
	public String getStepSixAcknowledge() {

		return this.stepSixAcknowledge;
	}

	@Override
	public String getStepSixResetTitle() {

		return this.stepSixResetTitle;
	}

	@Override
	public String getStepSixResetDesc() {

		return this.stepSixResetDesc;
	}

	@Override
	public String getStepSixResetStepsIOS() {

		return this.stepSixResetStepsIOS;
	}

	@Override
	public String getStepSixResetStepsAnd() {

		return this.stepSixResetStepsAnd;
	}

	@Override
	public String getStepSixButtonNext() {

		return this.stepSixButtonNext;
	}

	@Override
	public String getStepSixButtonBack() {

		return this.stepSixButtonBack;
	}

	@Override
	public String getStepSixTermsText() {

		return this.stepSixTermsText;
	}

	@Override
	public String getStepSixTermsLink() {

		return this.stepSixTermsLink;
	}

	@Override
	public String getStepSixDonotfollowlink() {

		return this.stepSixDonotfollowlink;
	}
	
	@Override
	public String getStepSixShopPhonesButton() {

		return this.stepSixShopPhonesButton;
	}

	@Override
	public String getStepSixShopPhonesLink() {
		
		return ApplicationUtil.getShortUrl(request.getResourceResolver(), this.stepSixShopPhonesLink);
	}

	@Override
	public String getStepSixDonotfollowlinkSP() {
		
		return this.stepSixDonotfollowlinkSP;
	}

	@Override
	public String getErrorMessageTitle() {

		return this.errorMessageTitle;
	}

	@Override
	public String getErrorMessageDesc() {

		return this.errorMessageDesc;
	}

	@Override
	public String getErrorContinueCartText() {

		return this.errorContinueCartText;
	}

	@Override
	public String getErrorContinueToCartLink() {

		return this.errorContinueToCartLink;
	}

	@Override
	public String getErrorDonotfollowlink() {

		return this.errorDonotfollowlink;
	}

	@Override
	public String getExportedType() {

		return request.getResource().getResourceType();
	}

	@Override
	public String getPlacementText() {
		return this.placementText;
	}

}
