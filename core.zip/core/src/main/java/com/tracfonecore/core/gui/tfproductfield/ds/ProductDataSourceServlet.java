package com.tracfonecore.core.gui.tfproductfield.ds;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Iterator;
import java.util.regex.Pattern;

import javax.servlet.Servlet;
import javax.servlet.ServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.collections.Transformer;
import org.apache.commons.collections.iterators.TransformIterator;
import org.apache.jackrabbit.JcrConstants;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceWrapper;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.ServletResolverConstants;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.ui.components.Config;
import com.adobe.granite.ui.components.ExpressionHelper;
import com.adobe.granite.ui.components.ExpressionResolver;
import com.adobe.granite.ui.components.PagingIterator;
import com.adobe.granite.ui.components.ds.AbstractDataSource;
import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.EmptyDataSource;
import com.adobe.granite.ui.components.ds.ValueMapResource;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.services.ProductOfferingApiService;
import com.tracfonecore.core.utils.ApplicationUtil;

@Component(service = Servlet.class, property = {
		Constants.SERVICE_DESCRIPTION + "=" + ProductDataSourceServlet.SERVICE_DESCRIPTION,
		ServletResolverConstants.SLING_SERVLET_RESOURCE_TYPES + "=" + ProductDataSourceServlet.RESOURCE_TYPE })
public class ProductDataSourceServlet extends SlingSafeMethodsServlet {

    protected static final String SERVICE_DESCRIPTION = "Data Source to get Products from Product Offering API";
	protected static final String RESOURCE_TYPE = "tracfone-core/gui/components/tfproductfield/datasources/products";

	private static Logger LOGGER = LoggerFactory.getLogger(ProductDataSourceServlet.class);
	private static final String CATEGORY_FILTER = "category";
	private static final String PRODUCT_FILTER = "product";
	private static final String VARIANT_FILTER = "variant";
    private static final String PROPERTY_NAME = "name";
	private static final String PROPERTY_ID = "id";
	private static final String PROPERTY_PARTNO = "partNo";
    private static final String PROPERTY_HAS_CHILDREN = "hasChildren";
	private static final String PROPERTY_PATH = "path";

    @Reference
    private transient ExpressionResolver expressionResolver;
    @Reference
    private transient ProductOfferingApiService prodOfferingService;

    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) {

        final ExpressionHelper ex = new ExpressionHelper(expressionResolver, request);
        final Config dsCfg = new Config(request.getResource().getChild(Config.DATASOURCE));
        
        final String parentPath;
        final String searchName;
        final String pagePath = ex.getString(dsCfg.get("pagePath", ""));
		final String rootPath = ex.getString(dsCfg.get("rootPath", "/var/commerce/products"));
		LOGGER.debug("TFProductField children datasource pagePath : {}, rootPath : {}", pagePath, rootPath);

        final DataSource ds;
        if (StringUtils.isBlank(pagePath)) {
            ds = EmptyDataSource.instance();
        } else {
            final Integer offset = ex.get(dsCfg.get("offset", String.class), Integer.class);
            final Integer limit = ex.get(dsCfg.get("limit", String.class), Integer.class);
            final String itemRT = dsCfg.get("itemResourceType", String.class);
            final String filter = ex.getString(dsCfg.get("filter", PRODUCT_FILTER));
            String selection = ex.getString(dsCfg.get("path", String.class));

			if(rootPath.equals(selection)) selection=""; //make selection blank for category load more
			final PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
			final Page page = pageManager.getPage(pagePath);

			List<Resource> resourceList = getResourceList(selection, filter, page, request);
			// Get data source from resource list
			if(null != resourceList && resourceList.size()>0) {
				LOGGER.debug("TFProductField children datasource resourceList :: {}", resourceList.size());
				// Create a DataSource that is used to populate the picker column view
				final Transformer transformer = createTransformer(itemRT, rootPath + ApplicationConstants.SLASH
						 + filter, request.getResourceResolver());
				@SuppressWarnings("unchecked")
				DataSource datasource = new AbstractDataSource() {
					public Iterator<Resource> iterator() {
						final Iterator<Resource> iterator = resourceList.iterator();
						return new TransformIterator(new PagingIterator<>(iterator, offset, limit), transformer);
					}
				};

				ds = datasource;
			} else {
				LOGGER.debug("TFProductField children datasource categories not present");
				ds = EmptyDataSource.instance();
			}
        }

        request.setAttribute(DataSource.class.getName(), ds);
    }
	
	/**
	 * Get resource list as per user selection
	 * @param String selection - User selection
	 * @param String filter - Filter specified for the field
	 * @param Page page - Page object of current page
	 * @param SlingHttpServletRequest request - SlingHttpServletRequest object
	 * @return resource list
	 */
	private List<Resource> getResourceList(String selection, String filter, Page page, SlingHttpServletRequest request) {
		LOGGER.debug("TFProductField children datasource resource list selection : {}, filter:{}", selection, filter);
		List<Resource> resourceList = null;
		// For initial load (current selection will be blank), load list of categories
		if(StringUtils.isNotBlank(selection)) {
			// If variant needs to be displayed and product is already selected, get list of variants 
			// for selected product else display products for selected category
			if((VARIANT_FILTER).equals(filter) && selection.split(ApplicationConstants.SLASH).length>3) {
				resourceList = getVariantsList(selection, page, request);
			} else {
				resourceList = getProductsList(selection, filter, page, request);
			}
		} else {
			resourceList = getCategoriesList(filter, page, request);
		}
		return resourceList;
	}
	
	/**
	 * Get list of categories
	 * @param String filter - Filter specified for the field
	 * @param Page page - Page object of current page
	 * @param SlingHttpServletRequest request - SlingHttpServletRequest object
	 * @return category resource list
	 */
	private List<Resource> getCategoriesList(String filter, Page page, SlingHttpServletRequest request) {
		LOGGER.debug("TFProductField children datasource inside get category list");
		List<Resource> categoryResourceList = new ArrayList<>();
		// Get categories array from product offering service
		JsonArray categoriesArray = prodOfferingService.getCategories(page);
		if(null != categoriesArray && categoriesArray.size()>0) {
			LOGGER.debug("TFProductField children datasource getcategories :: {}", categoriesArray.size());
			// Iterate though category array to create resource list
			for(int i=0; i<categoriesArray.size(); i++) {
				JsonObject categoryObject = categoriesArray.get(i).getAsJsonObject();
                String id = categoryObject.get(CommerceConstants.ID).getAsString();
				ValueMap valueMap = new ValueMapDecorator(new HashMap<String, Object>());
				valueMap.put(PROPERTY_NAME, categoryObject.get(CommerceConstants.NAME).getAsString());
				valueMap.put(PROPERTY_ID, id);
				valueMap.put(PROPERTY_PARTNO, id);
				valueMap.put(PROPERTY_HAS_CHILDREN, ((CATEGORY_FILTER).equals(filter)? false : true));
				valueMap.put(PROPERTY_PATH, (new StringBuilder(ApplicationConstants.SLASH)
						.append(CATEGORY_FILTER).append(ApplicationConstants.SLASH).append(id)).toString());
				categoryResourceList.add(new ValueMapResource(request.getResourceResolver(), new ResourceMetadata(),
						JcrConstants.NT_UNSTRUCTURED, valueMap));
			}
		}
		return categoryResourceList;
	}

	/**
	 * Get list of products for selected category
	 * @param String categoryPath - Path of selected category
	 * @param String filter - Filter specified for the field
	 * @param Page page - Page object of current page
	 * @param SlingHttpServletRequest request - SlingHttpServletRequest object
	 * @return products resource list
	 */
	private List<Resource> getProductsList(String categoryPath, String filter, Page page, SlingHttpServletRequest request) {
		LOGGER.debug("TFProductField children datasource inside get product list");
		List<Resource> productResourceList = new ArrayList<>();
		// Get category object from product offering service
		String query = (new StringBuilder("searchKeyword=*&categoryId=").append(categoryPath.split("/")[2])).toString();
		JsonObject categoryData = prodOfferingService.getCategoryDetailObject(query, page, true);
		if(null != categoryData && null != categoryData.get(CommerceConstants.PRODUCT_OFFERINGS)) {
			JsonArray productArray = categoryData.get(CommerceConstants.PRODUCT_OFFERINGS).getAsJsonArray();
			LOGGER.debug("TFProductField children datasource number of products for category {} are :: {}", categoryPath, productArray.size());
			// Iterate though products array to create list of resource items
			for(int i=0; i<productArray.size(); i++) {
				JsonObject productObject = productArray.get(i).getAsJsonObject();
				String partNumber = productObject.get("productSpecification").getAsJsonObject()
                        .get(CommerceConstants.PART_NUMBER).getAsString();
				ValueMap valueMap = new ValueMapDecorator(new HashMap<String, Object>());
				valueMap.put(PROPERTY_NAME, productObject.get(CommerceConstants.NAME).getAsString());
				valueMap.put(PROPERTY_ID, productObject.get(CommerceConstants.ID).getAsString());
				valueMap.put(PROPERTY_PARTNO, partNumber);
				valueMap.put(PROPERTY_HAS_CHILDREN, ((PRODUCT_FILTER).equals(filter)? false : true));
				valueMap.put(PROPERTY_PATH, (new StringBuilder(categoryPath).append(ApplicationConstants.SLASH)
						.append(partNumber)).toString());
				productResourceList.add(new ValueMapResource(request.getResourceResolver(), new ResourceMetadata(),
						JcrConstants.NT_UNSTRUCTURED, valueMap));
			}
		}
		return productResourceList;
	}
	
	/**
	 * Get list of variants for selected product
	 * @param String productPath - Path of selected product
	 * @param String filter - Filter specified for the field
	 * @param Page page - Page object of current page
	 * @param SlingHttpServletRequest request - SlingHttpServletRequest object
	 * @return variant resource list
	 */
	private List<Resource> getVariantsList(String productPath, Page page, SlingHttpServletRequest request) {
		LOGGER.debug("TFProductField children datasource inside get variant list");
		List<Resource> variantResourceList = new ArrayList<>();
		// Get product object from product offering service
		JsonObject productData = prodOfferingService.getProductDetailObject(productPath.split("/")[3], page);
        if(null != productData && null != productData.get(CommerceConstants.SKUS)) {
			JsonArray variantArray = productData.get(CommerceConstants.SKUS).getAsJsonArray();
			LOGGER.debug("TFProductField children datasource getvariants :: {}", variantArray.size());
			// Iterate though category list to create dropdown items
			for(int i=0; i<variantArray.size(); i++) {
				JsonObject variantObject = variantArray.get(i).getAsJsonObject();
                String partNumber = variantObject.get(CommerceConstants.PART_NUMBER).getAsString();
				ValueMap valueMap = new ValueMapDecorator(new HashMap<String, Object>());
				valueMap.put(PROPERTY_NAME, (new StringBuilder(variantObject.get(CommerceConstants.NAME)
                        .getAsString()).append(" (").append(variantObject.get(CommerceConstants.COLOR)
                        .getAsString()).append(")")).toString());
				valueMap.put(PROPERTY_ID, variantObject.get(CommerceConstants.ID).getAsString());
				valueMap.put(PROPERTY_PARTNO, partNumber);
				valueMap.put(PROPERTY_HAS_CHILDREN, false);
				valueMap.put(PROPERTY_PATH, (new StringBuilder(productPath).append(ApplicationConstants.SLASH)
						.append(partNumber)).toString());
				variantResourceList.add(new ValueMapResource(request.getResourceResolver(), new ResourceMetadata(),
						JcrConstants.NT_UNSTRUCTURED, valueMap));
			}
		}
		return variantResourceList;
	}

	/**
	 * Create transformer to add missing properties to resource object
	 * @param String itemRT - Column Item resource type
	 * @return transformer
	 */	
    private static Transformer createTransformer(final String itemRT, final String parentPath, final ResourceResolver resolver) {
        return new Transformer() {
            public Object transform(Object o) {
                Resource r = ((Resource) o);

                return new ProductResourceWrapper(r) {
                    @Override
                    public String getResourceType() {
                        return itemRT;
                    }
					
					@Override
                    public String getPath() {
                        return r.adaptTo(ValueMap.class).get(PROPERTY_PATH,"");
                    }
					
					@Override
                    public String getName() {
                        return r.adaptTo(ValueMap.class).get(PROPERTY_ID,"");
                    }

					@Override
                    public Resource getParent() {
                        return resolver.getResource(parentPath);
                    }
                };
            }
        };
    }

	/**
	 * Product resource wrapper class
	 */	
    private static class ProductResourceWrapper extends ResourceWrapper {

        ProductResourceWrapper(Resource resource) {
            super(resource);
        }

        @Override
        public Resource getChild(String relPath) {
            Resource child = super.getChild(relPath);
            return new ProductResourceWrapper(child);
        }

        @SuppressWarnings("unchecked")
        @Override
        public Iterator<Resource> listChildren() {
            return new TransformIterator(super.listChildren(), o -> new ProductResourceWrapper((Resource) o));
        }

        @Override
        public boolean hasChildren() {
            return super.hasChildren() && listChildren().hasNext();
        }
    }
}