package com.tracfonecore.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class KeyValuePairModel {
    @ValueMapValue(name="key")
    private String key;
    @ValueMapValue(name="content")
    private String content;
    public String getKey(){
        return key;
    }
    public String getContent(){
        return content;
    }
}
