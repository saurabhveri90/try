package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;


public interface BannerItemModel  extends ComponentExporter {

	String getMediaPath();

	String getTitle();

	String getUseFullWidth();

	String getSummary();

	String getMobileMediaPath();

	String getTabletMediaPath();
	
	String getShowTitleAsH1();
	
	String getImgHeight();
	
	String getCarouselBannerNarrow();
}
