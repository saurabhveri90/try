/**
 * 
 */
package com.tracfonecore.core.beans;

/**
 * @author vamsikrishna.jetty
 *
 */
public class LocatorStoreImagesBean {
	
	private String uniqueStoreName;
	
	private String storeLogo;
	
	private String storeImage;

	/**
	 * @return the uniqueStoreName
	 */
	public String getUniqueStoreName() {
		return uniqueStoreName;
	}

	/**
	 * @param uniqueStoreName the uniqueStoreName to set
	 */
	public void setUniqueStoreName(String uniqueStoreName) {
		this.uniqueStoreName = uniqueStoreName;
	}

	/**
	 * @return the storeLogo
	 */
	public String getStoreLogo() {
		return storeLogo;
	}

	/**
	 * @param storeLogo the storeLogo to set
	 */
	public void setStoreLogo(String storeLogo) {
		this.storeLogo = storeLogo;
	}

	/**
	 * @return the storeImage
	 */
	public String getStoreImage() {
		return storeImage;
	}

	/**
	 * @param storeImage the storeImage to set
	 */
	public void setStoreImage(String storeImage) {
		this.storeImage = storeImage;
	}

}
