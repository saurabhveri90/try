/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;


import java.util.Map;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Product} Sling Model used for the {@code /apps/tracfone-core/components/commerce/product} component.
 */
public interface ProductModel extends ComponentExporter {
		
	/**
	 * <p>Fetches detail for all the columns</p>
	 * 
	 * @return String - detail for all the columns
	 */
	@JsonProperty("categoryType")
	public String getCategoryType();
	/**
	  * <p>
	 * Fetches the export child items
	 * </p>
	 *
	 * 
	 * @return Map<String, ? extends ComponentExporter> - the export child items
	 */
	public Map<String, ? extends ComponentExporter> getItems();
	/**
	 * <p>Fetches number of columns for product specification</p>
	 *
	 * @return String - number of columns for product specification
	 */
	@JsonProperty("layoutSize")
	public String getLayoutSize();
	/**
	 * <p>Fetches number of columns for product specification for mobile</p>
	 *
	 * @return String - number of columns for product specification for Mobile
	 */
	@JsonProperty("mobileLayoutSize")
	public String getMobileLayoutSize();

	
	/**
	 * @return the useBazaarVoiceRatings
	 */
	public String getUseBazaarVoiceRatings();

	
	/**
	 * <p>Fetches style class for product specification</p>
	 *
	 * @return String - style class for product specification
	 */
	@JsonProperty("styleClass")
	public String getStyleClass();
	
	/**
	 * <p>Fetches mobile style class for product specification</p>
	 *
	 * @return String - mobile style class for product specification
	 */
	@JsonProperty("mobileStyleClass")
	public String getMobileStyleClass();
		
	
	/**
	 * <p>Fetches planType from pdp page properties</p>
	 *
	 * @return String - planType
	 */
	@JsonProperty("planType")
	public String getPlanType();

/**
 * <p>Fetches home Page Level</p>
 *
 * @return String - notify btn title
 */
public String getNotifyBtn();
	
/**
* <p>Fetches home Page Level</p>
*
* @return String - pre text notify btn
*/
public String getPreTextNotifyMeBtn();

public String getStockTitle();

	/**
	 * <p>Fetches enableMultilinePlan value from config</p>
	 *
	 * @return String - enableMultilinePlan
	 */
	@JsonProperty("enableMultilinePlan")
	public String getEnableMultilinePlan();

	/**
	 * @return the selection
	 */
	public String getSelection();
	
	/**
	  * <p>
	  * Fetches the disclaimerText
	  * </p>
	  *
	  * @return String - disclaimerText
	  */
	 @JsonProperty("disclaimerText")
	 public String getDisclaimerText();
	  
	 /**
	   * <p>
	   * Fetches the priceBreakDownLabel
	   * </p>
	   *
	   * @return String - priceBreakDownLabel
	   */
	 @JsonProperty("priceBreakDownLabel")
	 public String getPriceBreakDownLabel();

	 /**
	   * <p>
	   * Fetches hideRatings
	   * </p>
	   *
	   * @return String - hideRatings
	   */
	  @JsonProperty("hideRatings")
	  public String getHideRatings();
	  
	  /**
		 * <p>
		 * Checks if it is a Plan PDP
		 * </p>
		 *
		 * @return boolean - isPlanPDPPage
		 */
		public String getPlanPDPPage();
}
