/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.settings.SlingSettingsService;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.ManageCommunicationSubscriptionsModel;
import com.tracfonecore.core.models.ManageCommunicationCategoryModel;
import com.tracfonecore.core.utils.ApplicationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ManageCommunicationSubscriptionsModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/managecommunicationsubscriptions", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ManageCommunicationSubscriptionsModelImpl implements ManageCommunicationSubscriptionsModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;
	
	@Inject
	private SlingSettingsService settingService;
	
	@Inject
	private Resource resource;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String emailLabel;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String mailLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String directmailLabel;
	
	@ChildResource
    private List<ManageCommunicationCategoryModel> communicationCategories;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String communicationsLabel;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String privacyLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headerTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headerSubTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String smsLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String unsubscribeallLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String updatepreferencesctaText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String unsubscribeallhelpLabel;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String unsubscribedisclaimerText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String successText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ccpaTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ccpasubmitreqTxt;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ccpasubmitctaLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ccpastatusreqTxt;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ccpacheckstatusctaLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String successheaderText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String unsuballsuccessText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String errorTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String errorText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String submitRequestLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String checkStatusLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String yourPrivacyChoicesLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String openNewTabYourPrivacyChoicesLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String openNewTabSubmitRequestLink;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String openNewTabCheckStatusLink;

		
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getSubTitle() {
		return subTitle;
	}

	@Override
	public String getEmailLabel() {
		return emailLabel;
	}

	@Override
	public String getMailLabel() {
		return mailLabel;
	}

	@Override
	public String getDirectmailLabel() {
		return directmailLabel;
	}

  	@Override
    public List<ManageCommunicationCategoryModel> getCommunicationCategories() {
        List<ManageCommunicationCategoryModel> list = Optional.ofNullable(communicationCategories).map(List::stream).orElseGet(Stream::empty)
                .collect(Collectors.toList());
        return new ArrayList<>(list);
    }

	@Override
	public String getCommunicationsLabel() {
		return communicationsLabel;
	}

	@Override
	public String getPrivacyLabel() {
		return privacyLabel;
	}

	@Override
	public String getHeaderTitle() {
		return headerTitle;
	}

	@Override
	public String getHeaderSubTitle(){
		return headerSubTitle;
	}

	@Override
	public String getSmsLabel() {
		return smsLabel;
	}

	@Override
	public String getUnsubscribeallLabel() {
		return unsubscribeallLabel;
	}

	@Override
	public String getUpdatepreferencesctaText() {
		return updatepreferencesctaText;
	}

	@Override
	public String getUnsubscribeallhelpLabel() {
		return unsubscribeallhelpLabel;
	}

	@Override
	public String getUnsubscribedisclaimerText() {
		return unsubscribedisclaimerText;
	}
    
	@Override
	public String getSuccessText() {
		return successText;
	}
	
	@Override
	public String getCcpaTitle() {
		return ccpaTitle;
	}

	@Override
	public String getCcpasubmitreqTxt() {
		return ccpasubmitreqTxt;
	}

	@Override
	public String getCcpasubmitctaLbl() {
		return ccpasubmitctaLbl;
	}

	@Override
	public String getCcpastatusreqTxt() {
		return ccpastatusreqTxt;
	}

	@Override
	public String getCcpacheckstatusctaLbl() {
		return ccpacheckstatusctaLbl;
	}

	@Override
	public String getSuccessheaderText() {
		return successheaderText;
	}

	@Override
	public String getUnsuballsuccessText() {
		return unsuballsuccessText;
	}

	@Override
	public String getErrorTitle() {
		return errorTitle;
	}

	@Override
	public String getErrorText() {
		return errorText;
	}

	@Override
	public String getOpenNewTabSubmitRequestLink() {
		return openNewTabSubmitRequestLink;
	}

	@Override
	public String getOpenNewTabYourPrivacyChoicesLink() {
		return openNewTabYourPrivacyChoicesLink;
	}

	@Override
	public String getOpenNewTabCheckStatusLink() {
		return openNewTabCheckStatusLink;
	}

	private String getShortURL(String serverDomain, String url) {
		if (StringUtils.isNotBlank(url) && StringUtils.isNotBlank(serverDomain) && url.contains(serverDomain)) {
			url = url.split(serverDomain)[1];
		}
		return url;
	}

	@Override
	public String getSubmitRequestLink() {
		String finalSubmitRequestLink = submitRequestLink;
		if (StringUtils.isNotBlank(finalSubmitRequestLink) &&  Boolean.TRUE.equals(ApplicationUtil.isInternalLink(finalSubmitRequestLink))) {
			if (finalSubmitRequestLink.indexOf(ApplicationConstants.HTML_EXTENSION) == -1) {
				finalSubmitRequestLink = finalSubmitRequestLink + ApplicationConstants.HTML_EXTENSION;
			}
			if (StringUtils.isNotBlank(finalSubmitRequestLink)) {
				String ctaPath = request.getResourceResolver().map(finalSubmitRequestLink);
				if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
					finalSubmitRequestLink = ApplicationUtil
							.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
				}
			}
		}
		return finalSubmitRequestLink;
	}

	@Override
	public String getYourPrivacyChoicesLink() {
		String finalYourPrivacyChoicesLink = yourPrivacyChoicesLink;
		if (StringUtils.isNotBlank(finalYourPrivacyChoicesLink) &&  Boolean.TRUE.equals(ApplicationUtil.isInternalLink(finalYourPrivacyChoicesLink))) {
			if (finalYourPrivacyChoicesLink.indexOf(ApplicationConstants.HTML_EXTENSION) == -1) {
				finalYourPrivacyChoicesLink = finalYourPrivacyChoicesLink + ApplicationConstants.HTML_EXTENSION;
			}
			if (StringUtils.isNotBlank(finalYourPrivacyChoicesLink)) {
				String ctaPath = request.getResourceResolver().map(finalYourPrivacyChoicesLink);
				if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
					finalYourPrivacyChoicesLink = ApplicationUtil
							.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
				}
			}
		}
		return finalYourPrivacyChoicesLink;
	}

	@Override
	public String getCheckStatusLink() {
		String finalCheckStatusLink = checkStatusLink;
		if (StringUtils.isNotBlank(finalCheckStatusLink) &&  Boolean.TRUE.equals(ApplicationUtil.isInternalLink(finalCheckStatusLink))) {
			if (finalCheckStatusLink.indexOf(ApplicationConstants.HTML_EXTENSION) == -1) {
				finalCheckStatusLink = finalCheckStatusLink + ApplicationConstants.HTML_EXTENSION;
			}
			if (StringUtils.isNotBlank(finalCheckStatusLink)) {
				String ctaPath = request.getResourceResolver().map(finalCheckStatusLink);
				if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
					finalCheckStatusLink = ApplicationUtil
							.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
				}
			}
		}
		return finalCheckStatusLink;
	}
}
