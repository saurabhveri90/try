package com.tracfonecore.core.models;

import java.util.List;
import java.util.Map;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Fcc Container} Sling Model used for the {@code tracfone-core/components/content/fccContainer} component.
 */
public interface FccContainerModel  extends ComponentExporter {
	

	/**
	 * <p>Fetches Content Fragment Path</p>
	 * 
	 * @return String - content fragment path
	 */
	@JsonProperty("cfPath")
	public String getHeading();
	
	/**
	 * <p>Fetches Content Fragment Path</p>
	 * 
	 * @return String - content fragment path
	 */
	@JsonProperty("subheading")
	public String getSubheading();
	
	/**
	  * <p>
	 * Fetches the export child items
	 * </p>
	 *
	 * 
	 * @return Map<String, ? extends ComponentExporter> - the export child items
	 */
	public Map<String, ? extends ComponentExporter> getItems();

	/**
	 * <p>Fetches Page Type</p>
	 * 
	 * @return String - pagetype
	 */
	@JsonProperty("pagetype")
	public String getPagetype();

	/**
	 * <p>Fetches FCC button value</p>
	 * 
	 * @return String - FCC button value
	 */
	@JsonProperty("showFccButton")
	public String getShowFccButton();
}
