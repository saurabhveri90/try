package com.tracfonecore.core.event;

import java.util.HashMap;
import java.util.Map;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.ValueFormatException;
import javax.jcr.lock.LockException;
import javax.jcr.nodetype.ConstraintViolationException;
import javax.jcr.observation.Event;
import javax.jcr.observation.EventIterator;
import javax.jcr.observation.EventListener;
import javax.jcr.observation.ObservationManager;
import javax.jcr.version.VersionException;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aemds.guide.utils.JcrResourceConstants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.tracfonecore.core.constants.FccMapConstants;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.BroadbandFactsConfigService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.utils.ConfigurationUtil;

@Component(service = EventListener.class, immediate = true)
public class FccPlanTemplateLevelChangeEvent implements EventListener {
	private static final Logger LOG = LoggerFactory.getLogger(FccPlanTemplateLevelChangeEvent.class);

	private static final String TF_CREATE_MODIFY_SERVICE = "tf-create-modify-service-user";

	@Reference
	private ResourceResolverFactory resolverFactory;
	
	@Reference
	private SlingRepository repository;
	
	@Reference
	private BroadbandFactsConfigService broadbandFactsConfigService;

	@Reference
	private ApplicationConfigService applicationConfigService;

	@Reference
	private TracfoneApiGatewayService tracfoneApiGatewayService;

	
	private ObservationManager observationManager;
	
	@SuppressWarnings("AEM Rules:AEM-3")
	private Session session;

	@Activate
	protected void activate(ComponentContext componentContext) throws RepositoryException {
		LOG.info("inside Activate  in FccPlanTemplateLevelChangeEvent" );
		session = repository.loginService(TF_CREATE_MODIFY_SERVICE, null);
		//Get the observationManager from the workspace of session 
		observationManager = session.getWorkspace().getObservationManager();
		//Add a eventListener inside the observation manager, listen changed/added/removed properties from Template Level Path
		observationManager.addEventListener(
				this, 
				Event.PROPERTY_CHANGED | Event.PROPERTY_ADDED |Event.PROPERTY_REMOVED, 
				broadbandFactsConfigService.getTemplateLevelPath(), 
				true, 
				null, 
				null, 
				false);
	}
	
	
	@Deactivate
	protected void deactivate() throws RepositoryException {
		LOG.debug("inside deactivate  in FccPlanTemplateLevelChangeEvent" );
		//Remove the listener to not duplicate 
		if(observationManager != null) {
			observationManager.removeEventListener(this);
		}
		if(session != null) {
			session.logout();
		}
	}
	
	@Override
	public void onEvent(EventIterator events) {
		LOG.info("inside onEvent  in FccPlanTemplateLevelChangeEvent" );
		while(events.hasNext()) {
			Event event = events.nextEvent();
			try {			
				String eventPath = event.getPath();
				//The eventNameWithPrefix is a String in format XXYYYYYZZ XX-Brand short name YYYYY-Property ZZ-Language
				String eventNameWithPrefix =  eventPath.substring(eventPath.lastIndexOf("/") + 1);	
				//Get the property name removing two letters from the start and end.
				String property = eventNameWithPrefix.substring(2,(eventNameWithPrefix.length() - 2));
				for(String properties : FccMapConstants.getPropertiesTemplateLevel()) {
					if(properties.equals(property)) {	
						//Get the first two letters from property (ST/TF/TW/SM/WF/NT/GS/SL/PP) refer to brandShortName in OSGi Config
						String project = eventNameWithPrefix.substring(0,2);
						//Get the last two letters En/Es
						String language = eventNameWithPrefix.substring(eventNameWithPrefix.length() - 2).toLowerCase();
						Map<String, String> map = createQuery(getBrandName(project), language);	
						setProperty(map, event, property);
						}
				}
				
			} catch(RepositoryException e) {
				LOG.error("RepositoryException at onEvent caused by : ", e);
			}
		}
		
	}
	
	/**
	 * <p>
	 * Method send search result from Query Builder
	 * </p>
	 * 
	 * @param Map<String,      String>
	 * @param ResourceResolver
	 * @return SearchResult
	 */
	private SearchResult getSearchResult(Map<String, String> map, ResourceResolver resourceResolver) {
		QueryBuilder queryBuilder = resourceResolver.adaptTo(QueryBuilder.class);
		Query query = queryBuilder.createQuery(PredicateGroup.create(map), resourceResolver.adaptTo(Session.class));
		return query.getResult();
	}
	
	/**
	 * Create query to search CF
	 * 
	 * @param path path of the CF
	 * @return Map<String, String> Query
	 */
	private Map<String, String> createQuery(String brand, String language) {
		String path = ConfigurationUtil.getConfigValue(broadbandFactsConfigService.getFactsContentBasePath(), brand);
		path = path.replace("{language}", language);
		
		Map<String, String> map = new HashMap<>();
		map.put("path", path);
		map.put("type", "dam:asset");
		map.put("p.hits", "full");
		map.put("p.limit", "-1");
		map.put("nodename", "master");	
		return map;
	}
	
	/**
	 * Transform the brandShorName to normal brand
	 * @param brandShorName path of the event
	 * @return rootPath
	 */
	private String getBrandName(String brandShorName){

		for(String brandConfig : broadbandFactsConfigService.getBrandShortName() ) {		
			String[] partsConfig = brandConfig.split(":");
			if(brandShorName.matches(partsConfig[1])) {	
				return partsConfig[0];			
			}
		}
		
		return null;

	}
	
	/**
	 * Transform the path of the event to get the root page of the brand
	 * @param map Map where have the properties
	 * @param event event
	 * @param property property to set
	 * @throws RepositoryException 
	 * @throws ConstraintViolationException 
	 * @throws LockException 
	 * @throws VersionException 
	 * @throws ValueFormatException 
	 */
	private void setProperty(Map<String, String> map, Event event, String property) throws RepositoryException{
		String propertyValue = "";
		if(event.getInfo().containsKey("afterValue")) {
			propertyValue = event.getInfo().get("afterValue").toString();
		}
		
		Map<String, Object> loginParams = new HashMap<>();
		loginParams.put(JcrResourceConstants.AUTHENTICATION_INFO_SESSION, session);
		//Get the ResourceResolver from the active session
		try (ResourceResolver leakingResourceResolver = resolverFactory.getResourceResolver(loginParams))  {
			Session sessionResolver = leakingResourceResolver.adaptTo(Session.class);		
			SearchResult result = getSearchResult(map, leakingResourceResolver);
			if (result.getHits().isEmpty()) {
				LOG.info("No CF updated");
			} else {
				for (final Hit hit : result.getHits()) {
					//Only use node master from Content Fragments
					if(hit.getPath().contains("data/master")) {
						Node masterNode = hit.getNode();
						masterNode.setProperty(property, propertyValue);
						session.save();
					}
					
				}
			}
			sessionResolver.save();
			LOG.info("total {} found", (result.getTotalMatches()/2));
		}
		catch (LoginException e) {
			LOG.error("LoginException at onEvent caused by : ", e);
		}
		finally {
			session.logout();
		}

	}


	
}
