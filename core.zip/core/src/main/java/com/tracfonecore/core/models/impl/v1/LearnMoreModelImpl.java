/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl.v1;

import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.LearnMoreModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.ItemsExporterUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { LearnMoreModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/learnmoremodal/v1/learnmoremodal", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class LearnMoreModelImpl extends com.tracfonecore.core.models.impl.BaseComponentModelImpl implements LearnMoreModel {
	private static final Logger LOGGER = LoggerFactory.getLogger(LearnMoreModelImpl.class);

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private SlingModelFilter slingModelFilter;

	@Inject
	private ModelFactory modelFactory;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String displayType;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String title;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String description;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String errorDescription;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Default(values = "Learn More")
	private String modalName;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String doNotUseReference;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addImage;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String placementText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accessibilityText;
	
	@ValueMapValue()
	@Default(values = "tertiary-btn")
	private String buttonType;	

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private boolean hideClose;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private boolean displayCTAsInNewLine;

	private String modalId;
	private String accessibilityLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String doNotUseBaseStructureClass;
	private String accessibilityHeading;

	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering initModel method");
			super.initModel();
			String modal_Name=ApplicationUtil.getLowerCaseWithHyphen(modalName);
			this.setModalId(modal_Name+ ApplicationConstants.HYPHEN + ApplicationConstants.MODAL);
			if(StringUtils.isNotBlank(accessibilityText))
				this.setAccessibilityLabel(accessibilityText);
			else
				this.setAccessibilityLabel(modalName);
		LOGGER.debug("Exiting initModel method");
	}

	/**
	 *<p>Fetches title</p>
	 *
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 *<p>Fetches displayType</p>
	 *
	 * @return the displayType
	 */
	public String getDisplayType() {
		return displayType;
	}

	/**
	 *<p>Fetches description</p>
	 *
	 * @return the description
	 */
	public String getDescription() {
		if(null != description)
		{
			description = description.replaceAll("replaceOnClick\"","\" onclick='iconClick(this)'");
		}
		return description;
	}

	/**
	 *<p>Fetches errorDescription</p>
	 *
	 * @return the errorDescription
	 */
	public String getErrorDescription() {
		return errorDescription;
	}

	/**
	 *<p>Fetches modalName</p>
	 *
	 * @return the modalName
	 */
	public String getModalName() {
		return modalName;
	}

	/**
	 *<p>Fetches modalId</p>
	 *
	 * @return the modalId
	 */
	public String getModalId() {
		return modalId;
	}

	/**
	 * <p>Sets modalId</p>
	 *
	 *@param modalId - the modalId to set
	 */
	public void setModalId(String modalId) {
		this.modalId = modalId;
	}	

	/**
	 *<p>Fetches accessibilityLabel</p>
	 *
	 * @return the accessibilityLabel
	 */
	public String getAccessibilityLabel() {
		return accessibilityLabel;
	}

	/**
	 * <p>Sets accessibilityLabel</p>
	 *
	 *@param accessibilityLabel - the accessibilityLabel to set
	 */
	public void setAccessibilityLabel(String accessibilityLabel) {
		this.accessibilityLabel = accessibilityLabel;
	}
	
	/**
	 *<p>Fetches doNotUseReference</p>
	 *
	 * @return the doNotUseReference
	 */
	public String getDoNotUseReference() {
		return doNotUseReference;
	}

	/**
	 *<p>Fetches addImage</p>
	 *
	 * @return the addImage
	 */
	public String getAddImage() {
		return addImage;
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Fetches the export child items
	 * </p>
	 *
	 * 
	 * @return Map<String, ? extends ComponentExporter> - the export child items
	 */
	@Override
	public Map<String, ? extends ComponentExporter> getItems() {
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}
	
	/**
	 *<p>Fetches placementText</p>
	 *
	 * @return the gtm placement text
	 */
    @Override
	public String getPlacementText() {
		return placementText;
	}
    /**
	 * <p>Fetches button type for suggested shipping address</p>
	 * 
	 * @return String - buttonType
	 */
    @Override
	public String getButtonType() {
    	return buttonType;
    }

		
	/**
	 *<p>Fetches hideClose</p>
	 *
	 * @return hideClose
	 */
	@Override
	public boolean getHideClose() {
		return hideClose;
	}
	/**
	 *<p>Fetches accessibility Text</p>
	 *
	 * @return the accessibility text
	 */
	@Override
	public String getAccessibilityText(){
    	return accessibilityText;
    }

	/**
	 *<p>Fetches isCTAsDisplayedInNewLine</p>
	 *
	 * @return the isCTAsDisplayedInNewLine boolean
	 */
	@Override
	public boolean getDisplayCTAsInNewLine(){
    	return displayCTAsInNewLine;
    }

	/**
	 * <p>
	 * Fetches doNotUseBaseStructureClass
	 * </p>
	 *
	 * @return boolean - doNotUseBaseStructureClass
	 */
	@Override
	public boolean isDoNotUseBaseStructureClass() {
		return StringUtils.isNotBlank(doNotUseBaseStructureClass) &&
				doNotUseBaseStructureClass.equalsIgnoreCase(ApplicationConstants.TRUE) ? true : false;
	}
	
	/**
	 *<p>Fetches accessibilityHeading</p>
	 *
	 * @return the accessibilityHeading
	 */
	public String getHeading() {
		return accessibilityHeading;
	}
}