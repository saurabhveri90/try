/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.tracfonecore.core.utils.ApplicationUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.AppsCardsBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.AppsCardsModel;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { AppsCardsModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/content/appscards", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class AppsCardsModelImpl implements AppsCardsModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;

	@Inject
	private Resource resource;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String positionAppsCards;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String positionAccountNavigation;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String appsSummaryText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String appsLegalCopy;
	
	private List<AppsCardsBean> appsCards = Collections.emptyList();

	@PostConstruct
	private void initModel() {
		appsCards = new ArrayList<>();
		if (resource != null) {
			getMultifieldResource();
		}
	}

	private void getMultifieldResource() {
		for (Resource child : resource.getChildren()) {
			Iterator<Resource> it = child.listChildren();
			if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.APPS_CARDS.equals(child.getName())) {
				setAppsCards(it);
			} 
		}
	}

	private void setAppsCards(Iterator<Resource> it) {
		while (it.hasNext()) {
			AppsCardsBean appsCardsBean = new AppsCardsBean();
			Resource child = it.next();
			appsCardsBean.setAppName(
					child.getValueMap().get("appName", String.class));
			appsCardsBean.setAppDetails(
					child.getValueMap().get("appDetails", String.class));
			appsCardsBean.setAppLogoFileReference(
					DynamicMediaUtils.changeMediaPathToDMPath(child.getValueMap().get("appLogoFileReference", String.class), request.getResourceResolver()));
			appsCardsBean.setAppLogoAltText(
					child.getValueMap().get("appLogoAltText", String.class));
			appsCardsBean.setAppLogoAssetId(ApplicationUtil.getAssetId(child.getValueMap().get("appLogoFileReference",String.class),
					request.getResourceResolver(), ApplicationConstants.IMAGE));
			appsCardsBean.setAppLogoAssetAgencyId(ApplicationUtil.getAssetMetaDataValue(child.getValueMap().get("appLogoFileReference",String.class),
					request.getResourceResolver(), ApplicationConstants.IMAGE));
			
			appsCardsBean.setAppStoreLogoFileReference(
					DynamicMediaUtils.changeMediaPathToDMPath(child.getValueMap().get("appStoreLogoFileReference", String.class), request.getResourceResolver()));
			appsCardsBean.setAppStoreLogoAltText(
					child.getValueMap().get("appStoreLogoAltText", String.class));
			appsCardsBean.setAppStoreLogoLink(
					child.getValueMap().get("appStoreLogoLink", String.class));
			appsCardsBean.setOpenNewTabAppStoreLink(
					child.getValueMap().get("openNewTabAppStoreLink", String.class));
			appsCardsBean.setDoNotFollowAppStore(
					child.getValueMap().get("doNotFollowAppStore", String.class));
			appsCardsBean.setAppStoreLogoAssetId(ApplicationUtil.getAssetId(child.getValueMap().get("appStoreLogoFileReference",String.class),
					request.getResourceResolver(), ApplicationConstants.IMAGE));
			appsCardsBean.setAppStoreLogoAssetAgencyId(ApplicationUtil.getAssetMetaDataValue(child.getValueMap().get("appStoreLogoFileReference",String.class),
					request.getResourceResolver(), ApplicationConstants.IMAGE));
			
			appsCardsBean.setPlayStoreLogoFileReference(
			DynamicMediaUtils.changeMediaPathToDMPath(child.getValueMap().get("playStoreLogoFileReference", String.class), request.getResourceResolver()));
			appsCardsBean.setPlayStoreLogoAltText(
					child.getValueMap().get("playStoreLogoAltText", String.class));
			appsCardsBean.setPlayStoreLogoLink(
					child.getValueMap().get("playStoreLogoLink", String.class));
			appsCardsBean.setOpenNewTabPlayStoreLink(
					child.getValueMap().get("openNewTabPlayStoreLink", String.class));
			appsCardsBean.setDoNotFollowPlayStore(
					child.getValueMap().get("doNotFollowPlayStore", String.class));
			appsCardsBean.setPlayStoreLogoAssetId(ApplicationUtil.getAssetId(child.getValueMap().get("playStoreLogoFileReference",String.class),
					request.getResourceResolver(), ApplicationConstants.IMAGE));
			appsCardsBean.setPlayStoreLogoAssetAgencyId(ApplicationUtil.getAssetMetaDataValue(child.getValueMap().get("playStoreLogoFileReference",String.class),
					request.getResourceResolver(), ApplicationConstants.IMAGE));
			
			appsCards.add(appsCardsBean);
		}
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
	@Override
	public List<AppsCardsBean> getAppsCards() {
		return new ArrayList<>(appsCards);
	}

	@Override
	public String getAppsSummaryText() {
		return appsSummaryText;
	}

	@Override
	public String getAppsLegalCopy() {
		return appsLegalCopy;
	}

	@Override
	public String getPositionAppsCards() {
		return positionAppsCards;
	}

	@Override
	public String getPositionAccountNavigation() {
		return positionAccountNavigation;
	}
}
