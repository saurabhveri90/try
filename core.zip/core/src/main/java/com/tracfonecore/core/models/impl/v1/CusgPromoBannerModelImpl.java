package com.tracfonecore.core.models.impl.v1;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.CusgPromoBannerModel;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CusgPromoBannerModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/content/cusgpromobanner/v1/cusgpromobanner", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CusgPromoBannerModelImpl  implements CusgPromoBannerModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String componentVersion;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headlineText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subHeadlineText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String exclusiveOfferLabel;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String firstImageForBanner;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String firstImageAltTextForBanner;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String secondImageForBanner;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String secondImageAltTextForBanner;

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
	@Override
	public String getComponentVersion() {
		return StringUtils.isNotBlank(componentVersion) ? componentVersion : "v1";
	}

	@Override
	public String getHeadlineText() {
		return headlineText;
	}

	@Override
	public String getSubHeadlineText() {
		return subHeadlineText;
	}

	@Override
	public String getExclusiveOfferLabel() {
		return exclusiveOfferLabel;
	}

	@Override
	public String getFirstImageForBanner() {
		return DynamicMediaUtils.changeMediaPathToDMPath(firstImageForBanner,request.getResourceResolver());
	}

	@Override
	public String getFirstImageAltTextForBanner() {
		return firstImageAltTextForBanner;
	}

	@Override
	public String getSecondImageForBanner() {
		return DynamicMediaUtils.changeMediaPathToDMPath(secondImageForBanner,request.getResourceResolver());
	}

	@Override
	public String getSecondImageAltTextForBanner() {
		return secondImageAltTextForBanner;
	}

}

