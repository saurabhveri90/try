package com.tracfonecore.core.models.impl;

import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.E911AddressRegistrationModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { E911AddressRegistrationModel.class,
		ComponentExporter.class }, resourceType = E911AddressRegistrationModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class E911AddressRegistrationModelImpl implements E911AddressRegistrationModel {

	protected static final String RESOURCE_TYPE = "tracfone-core/components/commerce/e911addressregistration";
	@Self
	private SlingHttpServletRequest request;

	/**
	 * Inject e911Title
	 */
	@Inject
	@Via("resource")
	private String e911Title;

	/**
	 * Inject e911Description
	 */
	@Inject
	@Via("resource")
	private String e911Description;

	/**
	 * Inject e911AddressLabel
	 */
	@Inject
	@Via("resource")
	private String e911AddressLabel;

	/**
	 * Inject e911AddressAccessibleText
	 */
	@Inject
	@Via("resource")
	private String e911AddressAccessibleText;
	
	/**
	 * Inject aptUnitSuitAccessibleText
	 */
	@Inject
	@Via("resource")
	private String aptUnitSuitAccessibleText;

	/**
	 * Inject aptUnitSuitlabel
	 */
	@Inject
	@Via("resource")
	private String aptUnitSuitlabel;

	/**
	 * Inject buttonlabel
	 */
	@Inject
	@Via("resource")
	private String buttonlabel;

	/**
	 * Inject buttonAccessibleText
	 */
	@Inject
	@Via("resource")
	private String buttonAccessibleText;

	

	/**
	 * <p>
	 * Returns buttonAccessibleText from properties
	 * </p>
	 * 
	 * @return String - buttonAccessibleText
	 */
	@Override
	public String getButtonAccessibleText() {
		return buttonAccessibleText;
	}

	/**
	 * <p>
	 * Returns buttonlabel
	 * </p>
	 *
	 * @return String - buttonlabel
	 */
	@Override
	public String getButtonlabel() {
		return buttonlabel;
	}

	/**
	 * <p>
	 * Returns aptUnitSuitlabel from properties
	 * </p>
	 * 
	 * @return String - aptUnitSuitlabel
	 */
	@Override
	public String getAptUnitSuitlabel() {
		return aptUnitSuitlabel;
	}

	/**
	 * <p>
	 * Returns aptUnitSuitAccessibleText from properties
	 * </p>
	 * 
	 * @return String - aptUnitSuitAccessibleText
	 */
	@Override
	public String getAptUnitSuitAccessibleText() {
		return aptUnitSuitAccessibleText;
	}

	/**
	 * <p>
	 * Returns e911AddressAccessibleText from resource
	 * </p>
	 * 
	 * @return String - e911AddressAccessibleText
	 */
	@Override
	public String getE911AddressAccessibleText() {

		return e911AddressAccessibleText;
	}
	
	/**
	 * <p>
	 * Returns e911AddressLabel from properties
	 * </p>
	 * 
	 * @return the e911AddressLabel
	 */
	@Override
	public String getE911AddressLabel() {
		return e911AddressLabel;
	}

	/**
	 * <p>
	 * Returns e911Description from properties
	 * </p>
	 * 
	 * @return the e911Description
	 */
	@Override
	public String getE911Description() {
		return e911Description;
	}

	/**
	 * <p>
	 * Returns e911Title from properties
	 * </p>
	 * 
	 * @return the e911Title
	 */
	@Override
	public String getE911Title() {
		return e911Title;
	}

	/**
	 * <p>
	 * Returns getexportertype from resource
	 * </p>
	 * 
	 * @return String - getexportertype
	 */
	@Override
	public String getExportedType() {

		return request.getResource().getResourceType();
	}
	

}
