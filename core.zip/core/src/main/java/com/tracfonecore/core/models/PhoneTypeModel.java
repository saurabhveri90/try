/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.PhoneTypeBean;

import java.util.List;

/**
 * Defines the {@code New Line} Sling Model used for the
 * {@code /apps/tracfone-core/components/commerce/phonetype} component.
 */
public interface PhoneTypeModel extends ComponentExporter {

	/**
	 * <p>
	 * Fetches all the multi-options
	 * </p>
	 *
	 * @return List - all the multi-options
	 */
	@JsonProperty("options")
	public List<PhoneTypeBean> getOptions();

	/**
	 * <p>
	 * Fetches modal name
	 * </p>
	 * 
	 * @return String - modalName
	 */
	@JsonProperty("modalName")
	public String getModalName();

}
