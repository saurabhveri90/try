/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import javax.annotation.PostConstruct;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.BentoModel;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { BentoModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/bento", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class BentoModelImpl extends BaseComponentModelImpl
		implements com.tracfonecore.core.models.BentoModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(BentoModelImpl.class);
	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue
	private String card1heading;

	@ValueMapValue
	private String card3BgImage;

	@ValueMapValue
	private String card1SubHeading;

	@ValueMapValue
	private String card1Image;

	@ValueMapValue
	private String card1ImageAlt;

	@ValueMapValue
	@Default(values = "")
	private String card1TooltipMsg;

	@ValueMapValue
	@Default(values = "")
	private String card1tooltipLogo;

	@ValueMapValue
	private String card2heading;

	@ValueMapValue
	private String card2SubHeading;

	@ValueMapValue
	private String card2Image;

	@ValueMapValue
	private String card2ImageAlt;

	@ValueMapValue
	@Default(values = "")
	private String card2TooltipMsg;

	@ValueMapValue
	@Default(values = "")
	private String card2tooltipLogo;

	@ValueMapValue
	private String card3heading;

	@ValueMapValue
	private String card3SubHeading;

	@ValueMapValue
	private String card3Image;

	@ValueMapValue
	private String card3ImageAlt;

	@ValueMapValue
	@Default(values = "")
	private String card3TooltipMsg;

	@ValueMapValue
	@Default(values = "")
	private String card3tooltipLogo;

	@ValueMapValue
	private String card4heading;

	@ValueMapValue
	private String card4SubHeading;

	@ValueMapValue
	private String card4Image;

	@ValueMapValue
	private String card4ImageAlt;

	@ValueMapValue
	@Default(values = "")
	private String card4TooltipMsg;

	@ValueMapValue
	@Default(values = "")
	private String card4tooltipLogo;

	@ValueMapValue
	private String card5heading;

	@ValueMapValue
	private String card5SubHeading;

	@ValueMapValue
	@Default(values = "")
	private String card5TooltipMsg;

	@ValueMapValue
	@Default(values = "")
	private String card5tooltipLogo;

	@ValueMapValue
	private String card6heading;

	@ValueMapValue
	private String card6SubHeading;

	@ValueMapValue
	@Default(values = "")
	private String card6TooltipMsg;

	@ValueMapValue
	@Default(values = "")
	private String card6tooltipLogo;

	@ValueMapValue
	private String card1background;

	@ValueMapValue
	private String card2background;

	@ValueMapValue
	private String card3background;

	@ValueMapValue
	private String card4background;

	@ValueMapValue
	private String card5background;

	@ValueMapValue
	private String card6background;

	@ValueMapValue
	private String card6font;

	@ValueMapValue
	private String card5font;

	@ValueMapValue
	private String card4font;

	@ValueMapValue
	private String card3font;

	@ValueMapValue
	private String card2font;

	@ValueMapValue
	private String card1font;

	@ValueMapValue
	private String bentoHeader;

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getCard1heading() {

		//card1heading = card1heading.replace("card1TooltipIdentifier", card1TooltipMsg);

		return card1heading;
	}

	@Override
	public String getBentoHeader() {

		return bentoHeader;
	}

	@Override
	public String getCard1SubHeading() {
		return card1SubHeading;
	}

	@Override
	public String getCard1Image() {
		return DynamicMediaUtils.changeMediaPathToDMPath(card1Image, request.getResourceResolver());
	}

	@Override
	public String getCard1ImageAlt() {
		return card1ImageAlt;
	}

	@Override
	public String getCard2heading() {
		return card2heading;
	}

	@Override
	public String getCard2SubHeading() {
		return card2SubHeading;
	}

	@Override
	public String getCard2Image() {
		return DynamicMediaUtils.changeMediaPathToDMPath(card2Image, request.getResourceResolver());
	}

	@Override
	public String getCard2ImageAlt() {
		return card2ImageAlt;
	}

	@Override
	public String getCard3heading() {

		return card3heading;
	}

	@Override
	public String getCard3SubHeading() {

		return card3SubHeading;
	}

	@Override
	public String getCard3Image() {

		return DynamicMediaUtils.changeMediaPathToDMPath(card3Image, request.getResourceResolver());
	}

	@Override
	public String getCard3ImageAlt() {

		return card3ImageAlt;
	}

	@Override
	public String getCard4heading() {

		return card4heading;
	}

	@Override
	public String getCard4SubHeading() {

		return card4SubHeading;
	}

	@Override
	public String getCard4Image() {

		return DynamicMediaUtils.changeMediaPathToDMPath(card4Image, request.getResourceResolver());
	}

	@Override
	public String getCard4ImageAlt() {

		return card4ImageAlt;
	}

	@Override
	public String getCard5heading() {

		return card5heading;
	}

	@Override
	public String getCard6SubHeading() {

		return card6SubHeading;
	}

	@Override
	public String getCard6heading() {

		return card6heading;
	}

	@Override
	public String getCard5SubHeading() {

		return card5SubHeading;
	}

	@Override
	public String getCard1TooltipMsg() {
		return card1TooltipMsg;
	}

	@Override
	public String getCard1tooltipLogo() {
		return card1tooltipLogo;
	}

	@Override
	public String getCard2TooltipMsg() {
		return card2TooltipMsg;
	}

	@Override
	public String getCard2tooltipLogo() {
		return card2tooltipLogo;
	}

	@Override
	public String getCard3TooltipMsg() {
		return card3TooltipMsg;
	}

	@Override
	public String getCard3tooltipLogo() {
		return card3tooltipLogo;
	}

	@Override
	public String getCard4TooltipMsg() {
		return card4TooltipMsg;
	}

	@Override
	public String getCard4tooltipLogo() {
		return card4tooltipLogo;
	}

	@Override
	public String getCard5TooltipMsg() {
		return card5TooltipMsg;
	}

	@Override
	public String getCard5tooltipLogo() {
		return card5tooltipLogo;
	}

	@Override
	public String getCard6TooltipMsg() {
		return card6TooltipMsg;
	}

	@Override
	public String getCard6tooltipLogo() {
		return card6tooltipLogo;
	}

	@Override
	public String getCard1background() {
		return card1background;
	}

	@Override
	public String getCard2background() {
		return card2background;
	}

	@Override
	public String getCard3background() {
		return card3background;
	}

	@Override
	public String getCard4background() {
		return card4background;
	}

	@Override
	public String getCard5background() {
		return card5background;
	}

	@Override
	public String getCard6background() {
		return card6background;
	}

	@Override
	public String getCard1font() {
		return card1font;
	}

	@Override
	public String getCard2font() {
		return card2font;
	}

	@Override
	public String getCard3font() {
		return card3font;
	}

	@Override
	public String getCard4font() {
		return card4font;
	}

	@Override
	public String getCard5font() {
		return card5font;
	}

	@Override
	public String getCard6font() {
		return card6font;
	}

	@Override
	public String getCard3BgImage() {
		return card3BgImage;
	}

	
	@PostConstruct
	protected void initModel() {
		
		card1heading = card1heading.replace("card1TooltipIdentifier", card1TooltipMsg);
		
		card1heading = card1heading.replace("tooltipLogoIdentifier", card1tooltipLogo);
		card2heading = card2heading.replace("card2TooltipIdentifier", card2TooltipMsg);
		card3heading = card3heading.replace("card3TooltipIdentifier", card3TooltipMsg);
		card4heading = card4heading.replace("card4TooltipIdentifier", card4TooltipMsg);
		card5heading = card5heading.replace("card5TooltipIdentifier", card5TooltipMsg);
		card6heading = card6heading.replace("card6TooltipIdentifier", card6TooltipMsg);

		card2heading = card2heading.replace("tooltipLogoIdentifier", card2tooltipLogo);
		card3heading = card3heading.replace("tooltipLogoIdentifier", card3tooltipLogo);
		card4heading = card4heading.replace("tooltipLogoIdentifier", card4tooltipLogo);
		card5heading = card5heading.replace("tooltipLogoIdentifier", card5tooltipLogo);
		card6heading = card6heading.replace("tooltipLogoIdentifier", card6tooltipLogo);
		
	}

}
