package com.tracfonecore.core.models.impl.v2;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.ContactUsModel;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ContactUsModel.class,
        ComponentExporter.class }, resourceType = "tracfone-core/components/content/contactus/v2/contactus", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ContactUsModelImpl extends com.tracfonecore.core.models.impl.v1.ContactUsModelImpl implements ContactUsModel {
    
    
    @ValueMapValue
    private String onlineChatArea;
    
    @ValueMapValue
    private String callUsArea;

    @ValueMapValue
    private Boolean includeImageandText;

    @ValueMapValue
    private Boolean includeBtnCol1;

    @ValueMapValue
    private Boolean includeBtnCol2;

    @ValueMapValue
    private Boolean includeBtnCol3;

	@Override
	public String getOnlineChatArea() {
		return onlineChatArea;
	}
	
    @Override
	public String getCallUsArea() {
		return callUsArea;
	}

    @Override
    public Boolean getIncludeImageandText() {
        return includeImageandText;
    }

    @Override
    public Boolean getIncludeBtnCol1() {
        return includeBtnCol1;
    }

    @Override
    public Boolean getIncludeBtnCol2() {
        return includeBtnCol2;
    }

    @Override
    public Boolean getIncludeBtnCol3() {
        return includeBtnCol3;
    }
}
