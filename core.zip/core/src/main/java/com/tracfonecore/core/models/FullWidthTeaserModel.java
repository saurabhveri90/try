/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
 package com.tracfonecore.core.models;


import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface FullWidthTeaserModel extends ComponentExporter {

	/**
	 * <p>Fetches title of teaser</p>
	 * 
	 * @return String - title of teaser
	 */
	@JsonProperty("title")
	public String getTitle();

	/**
	 * <p>Fetches summary of teaser</p>
	 *
	 * @return String - summary of teaser
	 */
	@JsonProperty("summary")
	public String getSummary();

	/**
	 * <p>Fetches media type of teaser</p>
	 *
	 * @return String - media type of teaser
	 */
	@JsonProperty("mediaType")
	public String getMediaType();

	/**
	 * <p>Fetches media of teaser</p>
	 *
	 * @return String - media of teaser
	 */
	@JsonProperty("imageAndVideo")
	public String getImageAndVideo();

	/**
	 * <p>Fetches image alternate text</p>
	 *
	 * @return String - image alternate text
	 */
	@JsonProperty("imageAltText")
	public String getImageAltText();

	/**
	 * <p>Fetches video thumbnail of teaser</p>
	 *
	 * @return String - video thumbnail of teaser
	 */
	@JsonProperty("videoThumbnailImage")
	public String getVideoThumbnailImage();
	
	/**
	 * <p>Fetches no-follow value for video link</p>
	 *
	 * @return String - video no-follow value
	 */
	@JsonProperty("doNotFollow")
	public String getDoNotFollow();
	

	/**
	 * <p>Fetches child items json</p>
	 *
	 * @return Map<String, ? extends ComponentExporter> - items
	 */
	@JsonProperty("items")
	public Map<String, ? extends ComponentExporter> getItems();
	
	/**
	 * <p>Fetches data mode</p>
	 *
	 * @return String - data mode
	 */
	@JsonProperty("dataMode")
	public String getDataMode();
	
	/**
	 * <p>Fetches image profile breakpoint</p>
	 *
	 * @return String - image profile breakpoint
	 */
	@JsonProperty("imageProfileBreakpoints")
	public String getImageProfileBreakpoints();
	
	
	/**
	 * <p>Fetches path for mobile thumbnail image</p>
	 *
	 * @return String - mobile thumbnail image path
	 */
	@JsonProperty("mobileThumbnailImagePath")
	public String getMobileThumbnailImagePath();
	
	/**
	 * <p>Fetches path for mobile image</p>
	 *
	 * @return String - mobile media image path
	 */
	@JsonProperty("mobileMediaImagePath")
	public String getMobileMediaImagePath();

	/**
	 * <p>Fetches useTwoColumnLayout</p>
	 * 
	 * @return boolean - useTwoColumnLayout
	 */
	@JsonProperty("useTwoColumnLayout")
	public boolean isUseTwoColumnLayout();

	/**
	 * <p>Fetches include inline disclaimer</p>
	 *
	 * @return Boolean - includeInlineDisclaimer
	 */
	@JsonProperty("includeInlineDisclaimer")
	public default Boolean getIncludeInlineDisclaimer() {
		return false;
	}
	
}