package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

public interface HearingAidCompatibilityModel extends ComponentExporter{
	
	/**
	 * @return brand
	 */
	@JsonProperty("brand")
	public String getBrand();
	
	/**
	 * @return model
	 */
	@JsonProperty("model")
	public String getModel();
	
	/**
	 * @return hacRating
	 */
	@JsonProperty("hacRating")
	public String getHacRating();

	/**
	 * @return fccId
	 */
	@JsonProperty("fccId")
	public String getFccId();
	
	/**
	 * @return availability
	 */
	@JsonProperty("availability")
	public String getAvailability();

	/**
	 * @return the lastUpdatedLabel
	 */
	@JsonProperty("lastUpdatedLabel")
	public String getLastUpdatedLabel();

	/**
	 * @return the categoryId
	 */
	@JsonProperty("categoryId")
	public String getCategoryId();
	
}
