package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonGetter;

public interface ButtonListModel extends ComponentExporter {

    @JsonGetter("buttonList")
    public List<ButtonListOptionsModel> getButtonList();
    
    @JsonGetter("heading")
    public String getHeading();
    
    @JsonGetter("placementText")
    public String getPlacementText();
    
}
