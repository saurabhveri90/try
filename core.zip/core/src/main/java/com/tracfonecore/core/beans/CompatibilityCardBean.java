/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;

/**
 * <p>Defines bean to hold link detail</p>
 */
public class CompatibilityCardBean {

	private String cardtitle;

	private String cardcontent;

	private String cardbuttonlabel;

	private String cardbuttonlink;

	private String cardimage;

	private String cardevent;



	
	/**
	 * @return the cardtitle
	 */
	public String getCardtitle() {
		return cardtitle;
	}
	/**
	 * @param cardtitle the cardtitle to set
	 */
	public void setCardtitle(String cardtitle) {
		this.cardtitle = cardtitle;
	}

	
	/**
	 * @return the cardcontent
	 */
	public String getCardcontent() {
		return cardcontent;
	}
	/**
	 * @param cardcontent the cardcontent to set
	 */
	public void setCardcontent(String cardcontent) {
		this.cardcontent = cardcontent;
	}
	

	/**
	 * @return the cardbuttonlabel
	 */
	public String getCardbuttonlabel() {
		return cardbuttonlabel;
	}
	/**
	 * @param cardbuttonlabel the cardbuttonlabel to set
	 */
	public void setCardbuttonlabel(String cardbuttonlabel) {
		this.cardbuttonlabel = cardbuttonlabel;
	}


	/**
	 * @return the cardbuttonlink
	 */
	public String getCardbuttonlink() {
		return cardbuttonlink;
	}
	/**
	 * @param cardbuttonlink the cardbuttonlink to set
	 */
	public void setCardbuttonlink(String cardbuttonlink) {
		this.cardbuttonlink = cardbuttonlink;
	}


	/**
	 * @return the cardimage
	 */
	public String getCardimage() {
		return cardimage;
	}
	/**
	 * @param cardimage the cardimage to set
	 */
	public void setCardimage(String cardimage) {
		this.cardimage = cardimage;
	}


	
	/**
	 * @return the cardevent
	 */
	public String getCardevent() {
		return cardevent;
	}
	/**
	 * @param cardevent the cardevent to set
	 */
	public void setCardevent(String cardevent) {
		this.cardevent = cardevent;
	}
	
}
