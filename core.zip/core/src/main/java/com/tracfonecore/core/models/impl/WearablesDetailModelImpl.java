
package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.utils.*;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.factory.ModelFactory;
import org.apache.sling.settings.SlingSettingsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.tracfonecore.core.beans.WearablesSkuDetailBean;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.WearablesDetailModel;
import com.tracfonecore.core.models.ScriptingModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.ProductOfferingApiService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;

import com.tracfonecore.core.utils.ApplicationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { WearablesDetailModel.class,
		ComponentExporter.class }, resourceType = WearablesDetailModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class WearablesDetailModelImpl extends BaseComponentModelImpl implements WearablesDetailModel {
	private static final Logger LOGGER = LoggerFactory.getLogger(WearablesDetailModelImpl.class);
	protected static final String RESOURCE_TYPE = "tracfone-core/components/commerce/wearablesdetail";

	@Inject
	private Page currentPage;

	@Inject
	private SlingSettingsService slingSettingsService;

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private SlingModelFilter slingModelFilter;

	@Inject
	private ModelFactory modelFactory;

	@Inject
	private Resource resource;

	private ResourceResolver resolver;

	@Inject
	@Via("resource")
	private String expriceprefix;

	@Inject
	@Via("resource")
	private String expricesuffix;

	@Inject
	@Via("resource")
	private String smartPayLogo;

	@Inject
	@Via("resource")
	private String altText;

	@Inject
	@Via("resource")
	private String colorsheading;

	@Inject
	@Via("resource")
	private Resource tablinks;

	@Inject
	@Via("resource")
	private Resource colorVariants;

	@Inject
	@Via("resource")
	private String expriceduration;

	@Inject
	@Via("resource")
	private String pricecaptionplp;

	@Inject
	@Via("resource")
	private String compareimage;

	@Inject
	@Via("resource")
	private String freePhoneText;

	@Inject
	@Via("resource")
	private String showTimer;

	@Inject
	@Via("resource")
	private String marketPlaceIconImage;

	@Inject
	@Via("resource")
	private String marketPlaceTitleText;

	@Inject
	@Via("resource")
	private String marketPlaceSubTitleText;

	@Inject
	@Via("resource")
	private String marketPlace;

	@Inject
	@Via("resource")
	private String marketPlaceCtaText;

	@Inject
	@Via("resource")
	private String marketPlaceCtaAltText;

	@Inject
	@Via("resource")
	private String marketPlaceCtaLink;

	@Inject
	private TracfoneApiGatewayService tracfoneApiService;

	@Inject
	private ApplicationConfigService applicationConfigService;

	@Inject
	private ProductOfferingApiService productOfferingApiService;

	private JsonArray skusArray;

	private Map<String, List<String>> skuMap;

	private List<String> resultList = new ArrayList<>();

	private Map<String, List<String>> characteristicsMap = new HashMap<>();

	private List<WearablesSkuDetailBean> colorDataList;

	private List<String> videoSchemaList = new ArrayList<>();

	private String selection;

	private String firstImagePath;
	private String firstImagePathAssetId;
	private String firstImagePathAgencyId;

	@ScriptVariable
	private ValueMap properties;
	private String stockTitle;
	private String notifyBtn;
	private String preTextNotifyMeBtn;

	// constants
	private static final String FIRST_IMAGE_PATH = "firstImagePath";
	private static final String SECOND_IMAGE_PATH = "secondImagePath";
	private static final String THIRD_IMAGE_PATH = "thirdImagePath";
	private static final String FIRST_ASSET_TYPE = "firstAssetType";
	private static final String SECOND_ASSET_TYPE = "secondAssetType";
	private static final String THIRD_ASSET_TYPE = "thirdAssetType";
	private static final String FIRST_VIDEO_THUMB = "firstThumbImagePath";
	private static final String SECOND_VIDEO_THUMB = "secondThumbImagePath";
	private static final String THIRD_VIDEO_THUMB = "thirdThumbImagePath";
	private static final String FIRST_IMAGE_ALT_TEXT = "firstImageAltText";
	private static final String SECOND_IMAGE_ALT_TEXT = "secondImageAltText";
	private static final String THIRD_IMAGE_ALT_TEXT = "thirdImageAltText";

	private static final String SKUS_SELECTION = "skusSelection";
	private static final String IMAGE_RENDITION_PATH = "/jcr:content/renditions/cq5dam.thumbnail.48.48.png";
	private static final String VIDEO = "video";

	private String thumbnailImageAssetId;
	private String thumbnailImageAssetAgencyId;
	private String defaultPlanThumbnailImage;
	private String planThumbnailImageAssestId;
	private String planThumbnailImageWeberId;

	private String firstImageAssetId;
	private String firstImageWeberId;
	private String secondImageAssetId;
	private String secondImageWeberId;
	private String thirdImageAssetId;
	private String thirdImageWeberId;
	private String smartpayImageAssetId;
	private String smartpayImageWeberId;

	private String seoDynamicTitle;

	private String termsCondModalId;
	private String termsCondModalLabel;

	private String retailPriceLabel;
	private String showPriceDetailsAboveImg;
	private String showStepsNumber;
	private String enablePromotionalOffers;

	@Inject
	@Self
	private ScriptingModel scriptingModel;

	private String productSchemaObj = StringUtils.EMPTY;

	private JsonObject product = null;

	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Enter init method of PhoneDetailModelImpl");

		super.initModel();
		/*
		 * This method is used to get data from Listing page properties for Terms and
		 * Condition link
		 */
		fetchPagePropertiesData();
		selection = currentPage.getContentResource().getValueMap().get("partNo", String.class);
		if (!selection.equals(StringUtils.EMPTY)) {
			String[] apiLanguageArray = tracfoneApiService.getApiLanguage();
			String languageCode = getLanguage();
			if (StringUtils.isNotBlank(languageCode) && apiLanguageArray != null) {
				languageCode = ApplicationUtil.getAPILanguageValue(languageCode, apiLanguageArray);
			}
			String brand = CommerceUtil.getBrandValue(currentPage, getHomePageLevel());
			String clientId = ConfigurationUtil.getConfigValue(tracfoneApiService.getApiClientId(), brand) != null?
					ConfigurationUtil.getConfigValue(tracfoneApiService.getApiClientId(), brand): "";

			product = productOfferingApiService.getProductDetailObject(selection, currentPage);
			if(product != null)
				LOGGER.debug("Product Bean "+product.toString());
			setSkuList();
			setStockProperties();
			if(!disableProductSchemaObj()) {
				getPhonePriceForSEO(languageCode, clientId);
				getProductCharacterisitics(languageCode, clientId);

			} else {
				setProductSchemaObj(
						SeoSchemaOrgUtil.createPdpSchemaData(null, resource, request, currentPage, resolver, false));
			}
			if (!ApplicationUtil.isPublish(slingSettingsService)) {
				setDynamicSEOTitle(currentPage);
			}
			this.setThumbnailImageAssetId(ApplicationUtil.getAssetId(getImage(), request.getResourceResolver(),
					ApplicationConstants.IMAGE));
			this.setThumbnailImageAssetAgencyId(ApplicationUtil.getAssetMetaDataValue(getImage(),
					request.getResourceResolver(), ApplicationConstants.WEBER_ID));
			if (null == expriceduration || StringUtils.isEmpty(expriceduration))
				expriceduration = CommerceUtil.fetchDefaultExpPriceDuration(expriceduration, scriptingModel);

		}

		LOGGER.debug("after get list from skup map");
	}

	/**
	 * Method to values from page properties
	 */
	private void fetchPagePropertiesData() {
		if(null!=resource) {
			resolver = resource.getResourceResolver();
			if(null!=resolver) {
				PageManager pm = resolver.adaptTo(PageManager.class);
				Page currentPage = pm.getContainingPage(resource);
				Page parentPage = currentPage.getParent();
				Page ancestorPage = parentPage.getParent();
				properties = parentPage.getProperties();
				if (!(properties != null && properties.containsKey(CommerceConstants.CATEGORY_TYPE))) {
					properties = ancestorPage.getProperties();
				}
				setEnablePromotionalOffers(ApplicationUtil.getPropertiesFromRootPage(ancestorPage.getPath(), resolver,
						"enablePromotionalOffers"));
				if (properties != null) {
					if (properties.get(CommerceConstants.CATEGORY_TYPE, String.class) != null) {
						if(null != properties.get(CommerceConstants.TERMS_AND_CONDITION_MODAL_ID))
							setTermsCondModalId(properties.get(CommerceConstants.TERMS_AND_CONDITION_MODAL_ID, String.class));
						if(null != properties.get(CommerceConstants.TERMS_AND_CONDITION_MODAL_ID_LINK_LABEL))
							setTermsCondModalLabel(properties.get(CommerceConstants.TERMS_AND_CONDITION_MODAL_ID_LINK_LABEL, String.class));
						/* code added for show list price on page  */
						if( null != properties.get(CommerceConstants.RETAIL_PRICE_LABEL))
							setRetailPriceLabel(properties.get(CommerceConstants.RETAIL_PRICE_LABEL, String.class));
						/* code added for show price and other details above image in mobile view  */
						if(null != properties.get(CommerceConstants.SHOW_PRICE_DETAILS_ABOVE_IMAGE))
							setShowPriceDetailsAboveImg(properties.get(CommerceConstants.SHOW_PRICE_DETAILS_ABOVE_IMAGE, String.class));
						if(null != properties.get(CommerceConstants.MARKETPLACE_ICON_IMG))
							setMarketPlaceIconImage(properties.get(CommerceConstants.MARKETPLACE_ICON_IMG, String.class));
						if(null != properties.get(CommerceConstants.MARKETPLACE_TITLE_TEXT))
							setMarketPlaceTitleText(properties.get(CommerceConstants.MARKETPLACE_TITLE_TEXT, String.class));
						if(null != properties.get(CommerceConstants.MARKETPLACE_SUBTITLE_TEXT))
							setMarketPlaceSubTitleText(properties.get(CommerceConstants.MARKETPLACE_SUBTITLE_TEXT, String.class));
						if(null != properties.get(CommerceConstants.MARKETPLACE_CTA_TEXT))
							setMarketPlaceCtaText(properties.get(CommerceConstants.MARKETPLACE_CTA_TEXT, String.class));
						if(null != properties.get(CommerceConstants.MARKETPLACE_CTA_ALTTEXT))
							setMarketPlaceCtaAltText(properties.get(CommerceConstants.MARKETPLACE_CTA_ALTTEXT, String.class));
						if(null != properties.get(CommerceConstants.MARKETPLACE_CTA_LINK))
							setMarketPlaceCtaLink(properties.get(CommerceConstants.MARKETPLACE_CTA_LINK, String.class));
						if(null != properties.get(CommerceConstants.SHOW_STEPS_NUMBER))
							setShowStepsNumber(properties.get(CommerceConstants.SHOW_STEPS_NUMBER, String.class));
					}
				}
			}
		}
	}

	/**
	 * <p>
	 * Sets termsCondModalId
	 * </p>
	 *
	 * @param termsCondModalId - the termsCondModalId to set
	 */
	public void setTermsCondModalId(String termsCondModalId) {
		this.termsCondModalId = termsCondModalId;
	}
	/**
	 * <p>
	 * Fetches Terms and Condition Modal Id/p>
	 *
	 * @return String - Terms and Condition Modal Id
	 */
	@Override
	public String getTermsCondModalLabel() {
		return termsCondModalLabel;
	}
	/**
	 * <p>
	 * Fetches CTA text of Terms and Condition link/p>
	 *
	 * @return String - CTA text of Terms and Condition
	 */
	@Override
	public String getTermsCondModalId() {
		String modalId= StringUtils.EMPTY;
		if(StringUtils.isNotBlank(termsCondModalId)) {
			modalId = ApplicationUtil.getLowerCaseWithHyphen(termsCondModalId) + ApplicationConstants.HYPHEN
					+ ApplicationConstants.MODAL;
		}
		return modalId;
	}

	/**
	 * <p>
	 * Sets termsCondModalLabel
	 * </p>
	 *
	 * @param termsCondModalLabel - the termsCondModalLabel to set
	 */
	public void setTermsCondModalLabel(String termsCondModalLabel) {
		this.termsCondModalLabel = termsCondModalLabel;
	}

	/**
	 * Set seoTitle property for the currentPage (Author Server only)
	 * @return void
	 */
	private void setDynamicSEOTitle(Page currentPage) {
		String seoTitle = StringUtils.EMPTY;
		String breadcrumbTitle = StringUtils.EMPTY;
		String useDynamicTitle = ApplicationUtil.getPropertiesFromRootPage(currentPage.getPath(), resource.getResourceResolver(), "useDynamicSeoTitles");

		try {
			String seoBrandName = getPimBrand();
			if (StringUtils.isBlank(seoBrandName)) {
				seoBrandName = ApplicationUtil.getPropertiesFromRootPage(currentPage.getPath(),
						resource.getResourceResolver(), ApplicationConstants.SEO_BRAND_NAME);
			}
			if (StringUtils.isNotBlank(getPimOEM()) && StringUtils.isNotBlank(getPimMarketName())
					&& StringUtils.isNotBlank(seoBrandName)) {
				if (getPimOEM().equalsIgnoreCase("APPLE")) {
					seoTitle = getPimOEM() + ApplicationConstants.SPACE + getPimMarketName()
							+ (StringUtils.isNotBlank(getPimStorageCapacity())
							? (ApplicationConstants.SPACE + getPimStorageCapacity())
							: StringUtils.EMPTY)
							+ (StringUtils.isNotBlank(getPimStockType())
							? (ApplicationConstants.SPACE + getPimStockType())
							: StringUtils.EMPTY)
							+ ApplicationConstants.PIPE_WITH_SPACES + seoBrandName;
				} else {
					seoTitle = getPimMarketName()
							+ (StringUtils.isNotBlank(getPimStorageCapacity())
							? (ApplicationConstants.SPACE + getPimStorageCapacity())
							: StringUtils.EMPTY)
							+ (StringUtils.isNotBlank(getPimStockType())
							? (ApplicationConstants.SPACE + getPimStockType())
							: StringUtils.EMPTY)
							+ ApplicationConstants.PIPE_WITH_SPACES + seoBrandName;
				}
			}
			this.setSeoDynamicTitle(seoTitle);
			if(this.getSeoDynamicTitle().lastIndexOf('|') > -1) {
				breadcrumbTitle = this.getSeoDynamicTitle().substring(0, this.getSeoDynamicTitle().lastIndexOf('|'));
			}
			if (StringUtils.isNotBlank(seoTitle) && StringUtils.isNotBlank(breadcrumbTitle)) {
				Resource currentResource = currentPage.getContentResource();
				ModifiableValueMap map = currentResource.adaptTo(ModifiableValueMap.class);
				if (map.get(ApplicationConstants.SEO_TITLE) == null
						|| map.get(ApplicationConstants.SEO_TITLE).toString().isEmpty()) {
					map.put(ApplicationConstants.SEO_TITLE, this.getSeoDynamicTitle());
				}
				if ((map.get(ApplicationConstants.BREADCRUMB_TITLE) == null
						|| map.get(ApplicationConstants.BREADCRUMB_TITLE).toString().isEmpty()) && (useDynamicTitle != null && Boolean.parseBoolean(useDynamicTitle))) {
					map.put(ApplicationConstants.BREADCRUMB_TITLE, breadcrumbTitle.trim());
				}
				currentResource.getResourceResolver().commit();
				LOGGER.debug("SEO title of the page {} is {}", currentPage.getPath(), this.getSeoDynamicTitle());
			} else {
				LOGGER.debug(
						"SEO title: Issue while retrieving Mandatory attributes from API. PIM_OEM:{}, PIM_MARKET_NAME:{}, PIM_BRAND:{}",
						getPimOEM(), getPimMarketName(), getPimBrand());
			}

		} catch (PersistenceException e) {
			LOGGER.error("Exception {} while saving seoTitle property on page {}", e.getMessage(),
					currentPage.getPath());
		}
	}

	/**
	 * Creates a map of authored skuno and images
	 * @return void
	 */
	private void getSkuMap() {

		String skuPartNO = StringUtils.EMPTY;
		List<String> images;
		skuMap = new HashMap<String, List<String>>();
		Iterator<Resource> colorVariantsIterator = colorVariants.listChildren();

		while (colorVariantsIterator.hasNext()) {

			Resource multifieldItems = colorVariantsIterator.next();

			images = new ArrayList<>();

			if ((multifieldItems.getValueMap().get(SKUS_SELECTION)) != null) {
				skuPartNO = multifieldItems.getValueMap().get(SKUS_SELECTION).toString();
				String firstAssetType = multifieldItems.getValueMap().get(FIRST_ASSET_TYPE, StringUtils.EMPTY);
				String secondAssetType = multifieldItems.getValueMap().get(SECOND_ASSET_TYPE, StringUtils.EMPTY);
				String thirdAssetType = multifieldItems.getValueMap().get(THIRD_ASSET_TYPE, StringUtils.EMPTY);
				String firstThumb = DynamicMediaUtils.changeMediaPathToDMPath(multifieldItems.getValueMap().get(FIRST_VIDEO_THUMB, StringUtils.EMPTY), request.getResourceResolver());
				String secondThumb = DynamicMediaUtils.changeMediaPathToDMPath(multifieldItems.getValueMap().get(SECOND_VIDEO_THUMB, StringUtils.EMPTY), request.getResourceResolver());
				String thirdThumb = DynamicMediaUtils.changeMediaPathToDMPath(multifieldItems.getValueMap().get(THIRD_VIDEO_THUMB, StringUtils.EMPTY), request.getResourceResolver());
				String imageAssetId;
				String imageWeberId;
				String imagethumbnail;
				if(multifieldItems.getValueMap().containsKey(FIRST_IMAGE_PATH)) {
					this.setFirstImageAssetId(ApplicationUtil.getAssetId(multifieldItems.getValueMap().get(FIRST_IMAGE_PATH).toString(),
							request.getResourceResolver(), ApplicationConstants.IMAGE));
					this.setFirstImageWeberId(ApplicationUtil.getAssetMetaDataValue(multifieldItems.getValueMap().get(FIRST_IMAGE_PATH).toString(),
							request.getResourceResolver(), ApplicationConstants.WEBER_ID));
					imagethumbnail = StringUtils.isNotBlank(firstThumb) ? ("@@" + firstThumb) : StringUtils.EMPTY;
					imageAssetId = ";" + getFirstImageAssetId();
					imageWeberId = ";" + getFirstImageWeberId();
					String altTextString = ";" + multifieldItems.getValueMap().get(FIRST_IMAGE_ALT_TEXT, StringUtils.EMPTY);
					images.add(firstAssetType + "=" + (DynamicMediaUtils.changeMediaPathToDMPath(multifieldItems.getValueMap().get(FIRST_IMAGE_PATH).toString(), request.getResourceResolver()))
							+ imagethumbnail + imageAssetId  + imageWeberId + altTextString);
					if(firstAssetType.equalsIgnoreCase(VIDEO)){
						this.videoSchemaList.add(SeoSchemaOrgUtil.getVideoObjSchemaData(multifieldItems.getValueMap().get(FIRST_IMAGE_PATH).toString(),
								multifieldItems.getValueMap().get(FIRST_VIDEO_THUMB, StringUtils.EMPTY), request.getResourceResolver()));
					}
				}
				if(multifieldItems.getValueMap().containsKey(SECOND_IMAGE_PATH)) {
					this.setSecondImageAssetId(ApplicationUtil.getAssetId(multifieldItems.getValueMap().get(SECOND_IMAGE_PATH).toString(),
							request.getResourceResolver(), ApplicationConstants.IMAGE));
					this.setSecondImageWeberId(ApplicationUtil.getAssetMetaDataValue(multifieldItems.getValueMap().get(SECOND_IMAGE_PATH).toString(),
							request.getResourceResolver(), ApplicationConstants.WEBER_ID));
					imagethumbnail = StringUtils.isNotBlank(secondThumb) ? ("@@" + secondThumb) : StringUtils.EMPTY;
					imageAssetId = ";" + getSecondImageAssetId();
					imageWeberId = ";" + getSecondImageWeberId();
					String altTextString = ";" + multifieldItems.getValueMap().get(SECOND_IMAGE_ALT_TEXT, StringUtils.EMPTY);
					images.add(secondAssetType + "=" + (DynamicMediaUtils.changeMediaPathToDMPath(multifieldItems.getValueMap().get(SECOND_IMAGE_PATH).toString(), request.getResourceResolver()))
							+ imagethumbnail + imageAssetId  + imageWeberId + altTextString);
					if(secondAssetType.equalsIgnoreCase(VIDEO)) {
						this.videoSchemaList.add(SeoSchemaOrgUtil.getVideoObjSchemaData(multifieldItems.getValueMap().get(SECOND_IMAGE_PATH).toString(),
								multifieldItems.getValueMap().get(SECOND_VIDEO_THUMB, StringUtils.EMPTY), request.getResourceResolver()));
					}
				}
				if(multifieldItems.getValueMap().containsKey(THIRD_IMAGE_PATH)) {
					this.setThirdImageAssetId(ApplicationUtil.getAssetId(multifieldItems.getValueMap().get(THIRD_IMAGE_PATH).toString(),
							request.getResourceResolver(), ApplicationConstants.IMAGE));
					this.setThirdImageWeberId(ApplicationUtil.getAssetMetaDataValue(multifieldItems.getValueMap().get(THIRD_IMAGE_PATH).toString(),
							request.getResourceResolver(), ApplicationConstants.WEBER_ID));
					imagethumbnail = StringUtils.isNotBlank(thirdThumb) ? ("@@" + thirdThumb) : StringUtils.EMPTY;
					imageAssetId = ";" + getThirdImageAssetId();
					imageWeberId = ";" + getThirdImageWeberId();
					String altTextString = ";" + multifieldItems.getValueMap().get(THIRD_IMAGE_ALT_TEXT, StringUtils.EMPTY);
					images.add(thirdAssetType + "=" + (DynamicMediaUtils.changeMediaPathToDMPath(multifieldItems.getValueMap().get(THIRD_IMAGE_PATH).toString(), request.getResourceResolver()))
							+ imagethumbnail + imageAssetId  + imageWeberId + altTextString);
					if(thirdAssetType.equalsIgnoreCase(VIDEO)) {
						this.videoSchemaList.add(SeoSchemaOrgUtil.getVideoObjSchemaData(multifieldItems.getValueMap().get(THIRD_IMAGE_PATH).toString(),
								multifieldItems.getValueMap().get(THIRD_VIDEO_THUMB, StringUtils.EMPTY), request.getResourceResolver()));
					}
				}
				if((firstImagePath== null ||(StringUtils.EMPTY).equals(firstImagePath))&& multifieldItems.getValueMap().get(FIRST_IMAGE_PATH) != null)
				{
					firstImagePath = DynamicMediaUtils.changeMediaPathToDMPath(multifieldItems.getValueMap().get(FIRST_IMAGE_PATH).toString(), request.getResourceResolver());
				}
			}
			skuMap.put(skuPartNO, images);
		}
		LOGGER.debug("PhoneDetailModelImpl getVideoSchemaList() Size: {}", this.videoSchemaList.size());

	}

	public List<String> getListFromuSkuMap(){

		LOGGER.debug("skuMaps list from getListFromMap" + skuMap);
		for(Map.Entry<String, List<String>> entry: skuMap.entrySet()){
			String key = entry.getKey();
			List<String> values = entry.getValue();
			if("charSetValue".equals(key)) {
				resultList.addAll(entry.getValue());
			}

		}
		LOGGER.debug("skuMap resultList from return" + resultList);
		return resultList;

	}

	/**
	 * Method to create list of api data and their corrensponding images authored
	 *
	 * @return void
	 */
	private void setSkuList() {

		LOGGER.debug("Enterng setSkuList method of PhoneDetailModelImpl");
		getSkuMap();

		WearablesSkuDetailBean wearablesSkuDetailBean;
		colorDataList = new ArrayList<WearablesSkuDetailBean>();

		if(null != product && product.get(CommerceConstants.SKUS) != null && product.get(CommerceConstants.SKUS).isJsonArray()){
			skusArray = product.get(CommerceConstants.SKUS).getAsJsonArray();
			String partNumber;
			if (skusArray != null && skusArray.size() > 0) {
				for (int i = 0; i < skusArray.size(); i++) {
					wearablesSkuDetailBean = new WearablesSkuDetailBean();
					JsonObject element = skusArray.get(i).getAsJsonObject();
					partNumber = skusArray.get(i).getAsJsonObject().get(CommerceConstants.PART_NUMBER).getAsString();
					if(skuMap.size() > 0 && skuMap.containsKey(partNumber)) {
						wearablesSkuDetailBean.setSkusSelection(partNumber);
						wearablesSkuDetailBean.setMediaPaths(skuMap.get(partNumber));
						String color = element.get(CommerceConstants.COLOR).getAsString();
						String hexaColor = element.get(CommerceConstants.HEXA_COLOR).getAsString();
						String id = element.get(CommerceConstants.ID).getAsString();
						wearablesSkuDetailBean.setColor(color);
						wearablesSkuDetailBean.setHexaColor(hexaColor);
						wearablesSkuDetailBean.setId(id);
						colorDataList.add(wearablesSkuDetailBean);
					}
				}
			}
		}
	}

	private void setStockProperties(){
		Page parentPage = currentPage.getParent();
		Page ancestorPage = parentPage.getParent();

		properties = parentPage.getProperties();
		if (properties != null && properties.containsKey(CommerceConstants.NOTIFY_ME_BUTTON) && !properties.get(CommerceConstants.NOTIFY_ME_BUTTON, String.class).isEmpty()) {
			LOGGER.debug("Entering setStockProperties method - Phone Detail Model: parent Page");
		} else {
			properties = ancestorPage.getProperties();
			if (properties != null && properties.containsKey(CommerceConstants.NOTIFY_ME_BUTTON) && !properties.get(CommerceConstants.NOTIFY_ME_BUTTON, String.class).isEmpty()) {
				LOGGER.debug("Entering setStockProperties method - Phone detail Model: Ancestor Page");
			}
		}

		if (properties != null && ((properties.containsKey(CommerceConstants.NOTIFY_ME_BUTTON) && !properties.get(CommerceConstants.NOTIFY_ME_BUTTON, String.class).isEmpty())
				|| ((properties.containsKey(CommerceConstants.STOCK_POPOVER_TITLE) && !properties.get(CommerceConstants.STOCK_POPOVER_TITLE, String.class).isEmpty()))
				|| ((properties.containsKey(CommerceConstants.PRE_TEXT_NOTIFY_ME_BUTTON) && !properties.get(CommerceConstants.PRE_TEXT_NOTIFY_ME_BUTTON, String.class).isEmpty()))
		)){
			setStockTitle(properties.get(CommerceConstants.STOCK_POPOVER_TITLE, String.class));
			setNotifyBtn(properties.get(CommerceConstants.NOTIFY_ME_BUTTON, String.class));
			setPreTextNotifyMeBtn(properties.get(CommerceConstants.PRE_TEXT_NOTIFY_ME_BUTTON, String.class));
		}
	}

	/**
	 * Method to check if generating productSchemaObject is disabled.
	 *
	 */
	private boolean disableProductSchemaObj(){

		boolean isDisabledProductSchemaOrg = false;

		Page parentPage = currentPage.getParent();
		Page ancestorPage = parentPage.getParent();

		if(parentPage.getContentResource().getValueMap().containsKey("disableProductSchemaObj") ) {
			isDisabledProductSchemaOrg = Boolean.valueOf(parentPage.getContentResource().getValueMap().get("disableProductSchemaObj").toString());
			return isDisabledProductSchemaOrg;
		} else if(ancestorPage.getContentResource().getValueMap().containsKey("disableProductSchemaObj")) {
			isDisabledProductSchemaOrg = Boolean.valueOf(ancestorPage.getContentResource().getValueMap().get("disableProductSchemaObj").toString());
			return isDisabledProductSchemaOrg;
		}

		return isDisabledProductSchemaOrg;
	}

	/**
	 *
	 * @return Integer - id
	 */
	public Integer getId() {
		if (product != null && product.get(CommerceConstants.ID)!=null) {
			return product.get(CommerceConstants.ID).getAsInt();
		}
		return null;
	}

	/**
	 *
	 * @return String - Make
	 */
	@Override
	public String getMake() {
		if (product != null && product.get(CommerceConstants.MAKE)!=null) {
			return product.get(CommerceConstants.MAKE).getAsString();
		}
		return null;
	}

	/**
	 * @return String - name
	 */
	@Override
	public String getName() {
		if (product != null && product.get(CommerceConstants.NAME)!=null) {
			return  StringEscapeUtils.unescapeHtml(product.get(CommerceConstants.NAME).getAsString());
		}
		return null;
	}

	/**
	 * @return String - expriceprefix
	 */
	@Override
	public String getExperiencePricePrefix() {
		return expriceprefix;
	}

	/**
	 * @return String - the expricesuffix
	 */
	@Override
	public String getExperiencePriceSufix() {
		return expricesuffix;
	}

	/**
	 * @return String - the smartPayLogo
	 */
	@Override
	public String getSmartPayLogo() { return smartPayLogo; }

	/**
	 * @return String - the altText
	 */
	@Override
	public String getAltText() { return altText; }

	/**
	 * @return String - colorsheading
	 */
	@Override
	public String getColorsheading() {
		return colorsheading;
	}

	/**
	 * @return String - selection
	 */
	@Override
	public String getSelection() {
		return selection;
	}



	/**
	 * @return Resource - tablinks
	 */
	@Override
	public Resource getTablinks() {
		return tablinks;
	}

	/**
	 * @return String - image rendition path
	 */
	@Override
	public String getImageRenditionThumbnailPath() {
		return IMAGE_RENDITION_PATH;
	}

	/**
	 * @return String - ratings
	 */
	@Override
	public String getRating() {

		String rating = "0";

		if (product != null && product.get(CommerceConstants.RATINGS)!=null) {
			if (StringUtils.isNotBlank(product.get(CommerceConstants.RATINGS).getAsString())) {
				rating = product.get(CommerceConstants.RATINGS).getAsString();
			}
		}
		return rating;
	}

	/**
	 * @return String - reviews
	 */
	@Override
	public String getReviews() {
		String reviews = "0";
		if (product != null && product.get(CommerceConstants.REVIEWS)!=null) {
			if (StringUtils.isNotBlank(product.get(CommerceConstants.REVIEWS).getAsString())) {
				reviews = product.get(CommerceConstants.REVIEWS).getAsString();
			}
		}
		return reviews;
	}

	/**
	 * Customization for variants.
	 */
	@Override
	public List<WearablesSkuDetailBean> getSKUs() {
		List<WearablesSkuDetailBean> colorList = colorDataList;
		LOGGER.debug("Color data list" + colorList);
		return colorList;
	}

	@Override
	public List<String> getCaseMaterialList() {
		Map<String, List<String>> characMaps = characteristicsMap;
		if(characMaps.containsKey("CaseMaterial")) {
			LOGGER.debug("map list"+characMaps.get("CaseMaterial"));
			return characMaps.get("CaseMaterial");
		}
		LOGGER.debug("map list is null");
		return null;
	}

	@Override
	public List<String> getCaseSizeList() {
		Map<String, List<String>> characMaps = characteristicsMap;
		if(characMaps.containsKey("CaseSize")) {
			LOGGER.debug("map list"+characMaps.get("CaseSize"));
			return characMaps.get("CaseSize");
		}
		LOGGER.debug("map list is null");
		return null;
	}

	@Override
	public List<String> getCaseColorList() {
		Map<String, List<String>> characMaps = characteristicsMap;
		if(characMaps.containsKey("CaseColor")) {
			LOGGER.debug("map list"+characMaps.get("CaseColor"));
			return characMaps.get("CaseColor");
		}
		LOGGER.debug("map list is null");
		return null;
	}

	@Override
	public List<String> getBandTypeList() {
		Map<String, List<String>> characMaps = characteristicsMap;
		if(characMaps.containsKey("BandType")) {
			LOGGER.debug("map list"+characMaps.get("BandType"));
			return characMaps.get("BandType");
		}
		LOGGER.debug("map list is null");
		return null;
	}

	@Override
	public List<String> getBandColorList() {
		Map<String, List<String>> characMaps = characteristicsMap;
		if(characMaps.containsKey("BandColor")) {
			LOGGER.debug("map list"+characMaps.get("BandColor"));
			return characMaps.get("BandColor");
		}
		LOGGER.debug("map list is null");
		return null;
	}

	@Override
	public List<String> getBandSizeList() {
		Map<String, List<String>> characMaps = characteristicsMap;
		if(characMaps.containsKey("BandSize")) {
			LOGGER.debug("map list"+characMaps.get("BandSize"));
			return characMaps.get("BandSize");
		}
		LOGGER.debug("map list is null");
		return null;
	}


	/**
	 * Customization for Skus map .
	 */
	@Override
	public Map<String, List<String>> getSKUsMap() {
		Map<String, List<String>> skusMap = skuMap;
		return skusMap;
	}

	/**
	 * Schema.org for Product Videos.
	 */
	@Override
	public List<String> getVideoSchemaList()  {
		List<String> videoSchema = this.videoSchemaList;
		return videoSchema;
	}

	/**
	 * @return String - apiDomain
	 */
	@Override
	public String getApiDomain() {

		return tracfoneApiService.getApiDomain();
	}

	/**
	 * @return String -  priceApiPath
	 */
	@Override
	public String getPriceApiPath() {

		return tracfoneApiService.getPriceApiPath();
	}

	/**
	 * @return int - homePageLevel
	 */
	@Override
	public int getHomePageLevel() {

		return applicationConfigService.getHomePageLevel();
	}

	/**
	 * @return String - getexportertype
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Fetches marketplace Icon Image/p>
	 *
	 * @return String - marketplace Icon Image
	 */
	@Override
	public String getMarketPlaceIconImage() {
		return marketPlaceIconImage;
	}

	/**
	 * <p>
	 * Fetches marketplace title text/p>
	 *
	 * @return String - marketplace title text
	 */
	@Override
	public String getMarketPlaceTitleText() {
		return marketPlaceTitleText;
	}

	/**
	 * <p>
	 * Fetches marketplace subtitle text/p>
	 *
	 * @return String - marketplace subtitle text
	 */
	@Override
	public String getMarketPlaceSubTitleText() {
		return marketPlaceSubTitleText;
	}

	/**
	 * <p>
	 * Fetches CTA text of marketplace/p>
	 *
	 * @return String - CTA text of marketplace
	 */
	@Override
	public String getMarketPlaceCtaText() {
		return marketPlaceCtaText;
	}

	/**
	 * <p>
	 * Fetches CTA Alt-text of marketplace link
	 * </p>
	 *
	 * @return String - CTA Alt-text of marketplace link
	 */
	@Override
	public String getMarketPlaceCtaAltText() {
		return marketPlaceCtaAltText;
	}

	/**
	 * <p>
	 * Fetches CTA link of marketplace
	 * </p>
	 *
	 * @return String - CTA link of marketplace
	 */
	@Override
	public String getMarketPlaceCtaLink() {
		return marketPlaceCtaLink;
	}

	/**
	 * <p>
	 * Sets marketPlaceIconImage
	 * </p>
	 *
	 * @param marketPlaceIconImage - the marketPlaceIconImage to set
	 */
	public void setMarketPlaceIconImage(String marketPlaceIconImage) {
		this.marketPlaceIconImage = marketPlaceIconImage;
	}

	/**
	 * <p>
	 * Sets marketPlaceTitleText
	 * </p>
	 *
	 * @param marketPlaceTitleText - the marketPlaceCtaText to set
	 */
	public void setMarketPlaceTitleText(String marketPlaceTitleText) {
		this.marketPlaceTitleText = marketPlaceTitleText;
	}

	/**
	 * <p>
	 * Sets marketPlaceSubTitleText
	 * </p>
	 *
	 * @param marketPlaceSubTitleText - the marketPlaceSubTitleText to set
	 */
	public void setMarketPlaceSubTitleText(String marketPlaceSubTitleText) {
		this.marketPlaceSubTitleText = marketPlaceSubTitleText;
	}

	/**
	 * <p>
	 * Sets marketPlaceCtaText
	 * </p>
	 *
	 * @param marketPlaceCtaText - the marketPlaceCtaText to set
	 */
	public void setMarketPlaceCtaText(String marketPlaceCtaText) {
		this.marketPlaceCtaText = marketPlaceCtaText;
	}

	/**
	 * <p>
	 * Sets marketPlaceCtaAltText
	 * </p>
	 *
	 * @param marketPlaceCtaAltText - the marketPlaceCtaAltText to set
	 */
	public void setMarketPlaceCtaAltText(String marketPlaceCtaAltText) {
		this.marketPlaceCtaAltText = marketPlaceCtaAltText;
	}

	/**
	 * <p>
	 * Sets marketPlaceCtaLink
	 * </p>
	 *
	 * @param marketPlaceCtaLink - the marketPlaceCtaLink to set
	 */
	public void setMarketPlaceCtaLink(String marketPlaceCtaLink) {
		this.marketPlaceCtaLink = marketPlaceCtaLink;
	}

	/**
	 *
	 * @return
	 */
	@Override
	public Map<String, ? extends ComponentExporter> getItems() {
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}

	/**
	 * @return String - language
	 */
	@Override
	public String getLanguage() {

		return CommerceUtil.getLanguage(currentPage, getHomePageLevel());
	}

	/**
	 * @return String - language
	 */
	@Override
	public String getBrand() {

		return CommerceUtil.getBrandValue(currentPage, getHomePageLevel());
	}
	/**
	 * String is used for price API call
	 * @return String - queryString
	 */
	@Override
	public String getQueryString() {
		StringBuilder query = new StringBuilder(CommerceConstants.BRAND).append(CommerceConstants.EQUALS_TO)
				.append(getBrand()).append(CommerceConstants.AMPERSAND)
				.append(CommerceConstants.PRODUCT_ID).append(CommerceConstants.EQUALS_TO).append(this.getId());
		return query.toString();
	}

	/**
	 * @return String -  inventoryApiPath
	 */
	@Override
	public String getInventoryApiPath() {
		return tracfoneApiService.getInventoryApiPath();
	}

	@Override
	public String getInventoryQueryString() {
		String skuParameter = getSkuId();
		StringBuilder query = new StringBuilder(CommerceConstants.BRAND).append(CommerceConstants.EQUALS_TO)
				.append(getBrand()).append(CommerceConstants.AMPERSAND)
				.append(CommerceConstants.IDENTIFIER).append(CommerceConstants.EQUALS_TO).append(skuParameter);
		return query.toString();
	}

	private String getSkuId() {
		List<WearablesSkuDetailBean> skuId = getSKUs();
		String skuParameter = StringUtils.EMPTY;
		if(CollectionUtils.isNotEmpty(skuId)) {
			Iterator<WearablesSkuDetailBean> skuIterator = skuId.iterator();
			while (skuIterator.hasNext()){
				skuParameter = skuParameter + skuIterator.next().getId() +",";
			}
			skuParameter = skuParameter.substring(0, skuParameter.length()-1);
		}
		return skuParameter;
	}

	@Override
	public String getExpriceduration() {
		return expriceduration;
	}

	@Override
	public String getPricecaptionplp() {
		return pricecaptionplp;
	}

	@Override
	public String getFirstImagePath() {
		return firstImagePath;
	}

	public void setFirstImagePath(String firstImagePath) {
		this.firstImagePath = firstImagePath;
	}


	/**
	 * @return String - the stockPopoverTitle
	 */
	@Override
	public String getStockTitle() {
		return stockTitle;
	}

	public void setStockTitle(String stockTitle) {
		this.stockTitle = stockTitle;
	}


	/**
	 * @return String - the notifyMeBtn
	 */
	@Override
	public String getNotifyBtn() {
		return notifyBtn;
	}

	public void setNotifyBtn(String notifyBtn) {
		this.notifyBtn = notifyBtn;
	}

	/**
	 * @return String - the preTextNotifyMeBtn preTextNotifyMeBtn
	 */
	@Override
	public String getPreTextNotifyMeBtn() {
		return preTextNotifyMeBtn;
	}

	public void setPreTextNotifyMeBtn(String preTextNotifyMeBtn) {
		this.preTextNotifyMeBtn = preTextNotifyMeBtn;
	}

	public String getImage() { return DynamicMediaUtils.changeMediaPathToDMPath(compareimage,request.getResourceResolver()); }

	/**
	 *
	 * @return String - Cantentry id
	 */
	@Override
	public String getCantentryId() {
		if (product != null && product.get(CommerceConstants.CATENTRY_ID) != null) {
			return product.get(CommerceConstants.CATENTRY_ID).getAsString();
		}
		return null;
	}

	@Override
	public String getThumbnailImageAssetId() {
		return thumbnailImageAssetId;
	}

	public void setThumbnailImageAssetId(String thumbnailImageAssetId) {
		this.thumbnailImageAssetId = thumbnailImageAssetId;
	}

	@Override
	public String getThumbnailImageAssetAgencyId() {
		return thumbnailImageAssetAgencyId;
	}

	public void setThumbnailImageAssetAgencyId(String thumbnailImageAssetAgencyId) {
		this.thumbnailImageAssetAgencyId = thumbnailImageAssetAgencyId;
	}


	/**
	 * @return the defaultPlanThumbnailImage
	 */
	@Override
	public String getDefaultPlanThumbnailImage() {
		defaultPlanThumbnailImage = CommerceUtil
				.getPagePropertyValue(currentPage, applicationConfigService.getBrandPageLevel(), "defaultPlanThumbnailImage").toString();
		return  DynamicMediaUtils.changeMediaPathToDMPath(defaultPlanThumbnailImage, request.getResourceResolver());
	}

	/**
	 * @return the planThumbnailImageAssestId
	 */
	@Override
	public String getPlanThumbnailImageAssestId() {
		planThumbnailImageAssestId = ApplicationUtil.getAssetId(getDefaultPlanThumbnailImage(),
				request.getResourceResolver(), ApplicationConstants.IMAGE);
		return planThumbnailImageAssestId;
	}

	/**
	 * @return the planThumbnailImageWeberId
	 */
	@Override
	public String getPlanThumbnailImageWeberId() {
		planThumbnailImageWeberId = ApplicationUtil.getAssetMetaDataValue(getDefaultPlanThumbnailImage(),
				request.getResourceResolver(), ApplicationConstants.WEBER_ID);
		return planThumbnailImageWeberId;
	}

	/**
	 * @return the Phone Migration Group eligible
	 */
	@Override
	public String getPhoneMigrationGroupUpg() {
		return getCharactersticValue(CommerceConstants.EXTRA_CHARACTERISTICS,CommerceConstants.MIGRATION_GROUP_UPG);
	}

	public String getWatchEditUrl(){
		return ApplicationUtil.getPropertiesFromRootPage(currentPage.getPath(),resource.getResourceResolver(),ApplicationConstants.WATCH_EDIT_URL);
	}

	/**
	 * @return the EOL variable
	 */
	@Override
	public String getEOL() {
		return getCharactersticValue(CommerceConstants.EXTRA_CHARACTERISTICS,CommerceConstants.EOL);
	}

	private String getCharactersticValue(String charactersticsArrayName, String propertyName){
		String charactersticValue = StringUtils.EMPTY;
		if (product != null && product.get(charactersticsArrayName)!=null && product.get(charactersticsArrayName).isJsonArray()) {
			JsonArray prodSpecsArray;
			prodSpecsArray = product.get(charactersticsArrayName).getAsJsonArray();
			if (prodSpecsArray != null && prodSpecsArray.size() > 0) {
				for (int i = 0; i < prodSpecsArray.size(); i++) {
					JsonObject element = prodSpecsArray.get(i).getAsJsonObject();
					if(!element.get("identifier").getAsString().isEmpty() && propertyName.equalsIgnoreCase(element.get("identifier").getAsString().trim().toLowerCase())){
						charactersticValue = element.get("value").getAsString();
					}
				}
			}
		}
		return charactersticValue;
	}

	/**
	 * Method to get price for SEO Schema Only
	 *
	 */
	private void getPhonePriceForSEO(String languageCode, String clientId) {

		Map<String, String> priceMap = new HashMap<>();

		try {
			if (product!=null && product.get("SKUs")!=null && product.get("SKUs").isJsonArray() && product.get("SKUs").getAsJsonArray().size()>0
					&& product.get("SKUs").getAsJsonArray().get(0).isJsonObject() && product.get("SKUs").getAsJsonArray().get(0).getAsJsonObject().get("productOfferingPrice")!=null
					&& product.get("SKUs").getAsJsonArray().get(0).getAsJsonObject().get("productOfferingPrice").isJsonArray()) {

				JsonArray priceOfferingArray = product
						.get("SKUs").getAsJsonArray().get(0).getAsJsonObject().get("productOfferingPrice")
						.getAsJsonArray();

				for (JsonElement poa : priceOfferingArray) {
					JsonObject priceObj = poa.getAsJsonObject();

					if (priceObj.get("priceType").getAsString().equalsIgnoreCase("ltoPriceTier")) {
						priceMap.put("lowPrice",
								priceObj.get("price").getAsJsonObject().get("amount").getAsString());
					} else if(priceObj.get("priceType").getAsString().equalsIgnoreCase("offer price")) {
						priceMap.put("lowPrice",
								priceObj.get("price").getAsJsonObject().get("amount").getAsString());
					}
					if (priceObj.get("priceType").getAsString().equalsIgnoreCase("offer price")) {
						priceMap.put("offerPrice",
								priceObj.get("price").getAsJsonObject().get("amount").getAsString());
					}
				}
				LOGGER.debug("Price to be used for SEO Schema purposes. lowPrice: {}, offerPrice: {}",
						priceMap.get("lowPrice"), priceMap.get("offerPrice"));
				setProductSchemaObj(
						SeoSchemaOrgUtil.createPdpSchemaData(priceMap, resource, request, currentPage, resolver, getInventoryForSEO(languageCode, clientId)));
			}
		} catch (JsonParseException ex) {
			LOGGER.error("Exception occured while fetching and parsing JSON", ex);
		}
	}

	private void getProductCharacterisitics(String languageCode, String clientId) {

		Map<String, String> rawData = new HashMap<>();

		try {
			if (product!=null && product.get("SKUs")!=null && product.get("SKUs").isJsonArray()) {

				skusArray = product.get(CommerceConstants.SKUS).getAsJsonArray();
				for(int i=0; i < skusArray.size(); i++){
					JsonArray charArray = product
							.get("SKUs").getAsJsonArray().get(i).getAsJsonObject().get("productCharacteristics")
							.getAsJsonArray();

					for (JsonElement poa : charArray) {
						JsonObject charObj = poa.getAsJsonObject();
						if(charObj.has("name") && charObj.has("value")) {
							String charName = charObj.get("name").getAsString();
							String charValue = charObj.get("value").getAsString();
							if (charName != null && charValue != null){
								rawData.merge(charName, charValue, (oldValue, newValue) -> oldValue + "," + newValue);
							}
							else{
								LOGGER.debug("Missing 'name' or 'value' in the characterisitic  JSON Object");
							}
						}
					}
					LOGGER.debug("Price to be used for SEO Schema purposes. lowPrice: {}, offerPrice: {}",
							rawData.get("name"), rawData.get("value"));
					characteristicsMap = processCharMap(rawData);
					setProductSchemaObj(
							SeoSchemaOrgUtil.createPdpSchemaData(rawData, resource, request, currentPage, resolver, getInventoryForSEO(languageCode, clientId)));

				}
			}
		} catch (JsonParseException ex) {
			LOGGER.error("Exception occured while fetching and parsing JSON", ex);
		}
	}

	private Map<String, List<String>> processCharMap(Map<String, String> characteristicsMap){
		Map<String, List<String>> consolidateCharMap = new HashMap<>();
		if(characteristicsMap != null || !characteristicsMap.isEmpty()){
			for( Map.Entry<String, String> entry : characteristicsMap.entrySet()){
				String characteristicName = entry.getKey();
				String characteristicValue = entry.getValue();
				String[] valuesArray = characteristicValue.split(",");
				Set<String> uniqueValueSet = new HashSet<>(Arrays.asList(valuesArray));
				consolidateCharMap.put(characteristicName, new ArrayList<>(uniqueValueSet));
			}
		}
		LOGGER.debug("Consolidate CharMap List is " + consolidateCharMap);
		return consolidateCharMap;
	}

	/**
	 * Method to get Inventory for SEO Schema Only
	 *
	 */
	private boolean getInventoryForSEO(String languageCode, String clientId) {

		boolean isAvailable = false;
		String inventoryRequest = getApiDomain() + getInventoryApiPath() + "?" + getInventoryQueryString() + "&language="
				+ languageCode + "&client_id=" + clientId;

		JsonObject jsonInventoryApiObject = CommerceUtil.getApiResponseData(inventoryRequest);
		if (jsonInventoryApiObject != null && (jsonInventoryApiObject.get("status").getAsJsonObject().get("message")
				.getAsString().equalsIgnoreCase("success"))) {

			for (JsonElement poa : jsonInventoryApiObject.get("productOfferings").getAsJsonArray()) {
				JsonObject inventoryObj = poa.getAsJsonObject();
				if (inventoryObj.get("inventory").getAsJsonObject().get("status").getAsString()
						.equalsIgnoreCase("Available")) {
					isAvailable = true;
				}
			}
		}
		return isAvailable;
	}

	/**
	 * @return the Pre order sales flag for a device
	 */
	@Override
	public String getPreOrderFlag(){
		return !getCharactersticValue(CommerceConstants.PRODUCT_CHARACTERISTICS,CommerceConstants.IS_PRE_SALES).equals(StringUtils.EMPTY) ? getCharactersticValue(CommerceConstants.PRODUCT_CHARACTERISTICS,CommerceConstants.IS_PRE_SALES) : "N";
	}

	/**
	 * @return the Pre order sales flag for a device
	 */
	@Override
	public String getPreorderShippingDate(){
		return getCharactersticValue(CommerceConstants.PRODUCT_CHARACTERISTICS,CommerceConstants.PS_DELIVERY_DATE);
	}

	@Override
	public String getMarketingIds() {
		return getCharactersticValue(CommerceConstants.PRODUCT_CHARACTERISTICS,CommerceConstants.MARKET);
	}


	/**
	 * @return the firstImagePathAgencyId
	 */
	@Override
	public String getFirstImagePathAgencyId(){
		firstImagePathAgencyId = ApplicationUtil.getAssetMetaDataValue(getFirstImagePath(),
				request.getResourceResolver(), ApplicationConstants.WEBER_ID);
		return firstImagePathAgencyId;
	}

	/**
	 * @return the firstImagePathAssetId
	 */
	@Override
	public String getFirstImagePathAssetId(){
		firstImagePathAssetId = ApplicationUtil.getAssetId(getFirstImagePath(),
				request.getResourceResolver(), ApplicationConstants.IMAGE);
		return firstImagePathAssetId;
	}


	public void setFirstImageAssetId(String firstImageAssetId) {
		this.firstImageAssetId = firstImageAssetId;
	}

	public void setFirstImageWeberId(String firstImageWeberId) {
		this.firstImageWeberId = firstImageWeberId;
	}

	/**
	 * @return the firstImageAgencyId
	 */
	public String getFirstImageWeberId(){
		return firstImageWeberId;
	}

	/**
	 * @return the firstImageAssetId
	 */
	public String getFirstImageAssetId(){
		return firstImageAssetId;
	}

	public String getSecondImageAssetId() {
		return secondImageAssetId;
	}

	public void setSecondImageAssetId(String secondImageAssetId) {
		this.secondImageAssetId = secondImageAssetId;
	}

	public String getSecondImageWeberId() {
		return secondImageWeberId;
	}

	public void setSecondImageWeberId(String secondImageWeberId) {
		this.secondImageWeberId = secondImageWeberId;
	}

	public String getThirdImageAssetId() {
		return thirdImageAssetId;
	}

	public void setThirdImageAssetId(String thirdImageAssetId) {
		this.thirdImageAssetId = thirdImageAssetId;
	}

	public String getThirdImageWeberId() {
		return thirdImageWeberId;
	}

	public void setThirdImageWeberId(String thirdImageWeberId) {
		this.thirdImageWeberId = thirdImageWeberId;
	}

	@Override
	public String getSmartpayImageAssetId() {
		smartpayImageAssetId = ApplicationUtil.getAssetId(getSmartPayLogo(),
				request.getResourceResolver(), ApplicationConstants.IMAGE);
		return smartpayImageAssetId;
	}

	@Override
	public String getSmartpayImageWeberId() {
		smartpayImageWeberId = ApplicationUtil.getAssetMetaDataValue(getSmartPayLogo(),
				request.getResourceResolver(), ApplicationConstants.WEBER_ID);
		return smartpayImageWeberId;
	}
	@Override
	public String getProductNameForAnalytics() {

		if (product != null && product.get(CommerceConstants.NAME) != null) {
			return ApplicationUtil.getLowerCaseWithUnderScore(product.get(CommerceConstants.NAME).getAsString());
		}
		return StringUtils.EMPTY;

	}

	@Override
	public String getSkipPlanType() { return applicationConfigService.skipPlanCheck().trim(); }

	/**
	 *<p>Fetches retailPriceLabel</p>
	 *
	 * @return the retailPriceLabel
	 */
	@Override
	public String getRetailPriceLabel() {
		return retailPriceLabel;
	}

	/**
	 * <p>Sets retailPriceLabel</p>
	 *
	 *@param retailPriceLabel - the retailPriceLabel to set
	 */
	@Override
	public void setRetailPriceLabel(String retailPriceLabel) {
		this.retailPriceLabel = retailPriceLabel;
	}

	/**
	 *<p>Fetches showPriceDetailsAboveImg</p>
	 *
	 * @return the showPriceDetailsAboveImg
	 */
	@Override
	public String getShowPriceDetailsAboveImg() {
		return showPriceDetailsAboveImg;
	}

	/**
	 * <p>Sets showPriceDetailsAboveImg</p>
	 *
	 *@param showPriceDetailsAboveImg - the showPriceDetailsAboveImg to set
	 */
	@Override
	public void setShowPriceDetailsAboveImg(String showPriceDetailsAboveImg) {
		this.showPriceDetailsAboveImg = showPriceDetailsAboveImg;
	}

	/**
	 *<p>Fetches showStepsNumber</p>
	 *
	 * @return the showStepsNumber
	 */
	@Override
	public String getShowStepsNumber() {
		return showStepsNumber;
	}

	/**
	 * <p>Sets setShowStepsNumber</p>
	 *
	 *@param showStepsNumber - the showStepsNumber to set
	 */
	public void setShowStepsNumber(String showStepsNumber) {
		this.showStepsNumber = showStepsNumber;
	}

	/**
	 *
	 * @return String - PIM_OEM
	 */
	public String getPimOEM() {
		return getCharactersticValue(CommerceConstants.PRODUCT_CHARACTERISTICS,CommerceConstants.PIM_OEM);
	}

	/**
	 *
	 * @return String - PIM_Market_Name
	 */
	public String getPimMarketName() {
		return getCharactersticValue(CommerceConstants.PRODUCT_CHARACTERISTICS,CommerceConstants.PIM_MARKET_NAME);
	}

	/**
	 *
	 * @return String - PIM_Storage_Capacity
	 */
	public String getPimStorageCapacity() {
		return getCharactersticValue(CommerceConstants.PRODUCT_CHARACTERISTICS,CommerceConstants.PIM_STORAGE_CAPACITY);
	}

	/**
	 *
	 * @return String - PIM_Stock_Type
	 */
	public String getPimStockType() {
		String stockType = getCharactersticValue(CommerceConstants.PRODUCT_CHARACTERISTICS,CommerceConstants.PIM_STOCK_TYPE);
		if(StringUtils.isNotBlank(stockType)) {
			if(stockType.equalsIgnoreCase(CommerceConstants.NEW)) {
				return CommerceConstants.PREPAID;
			} else if(stockType.equalsIgnoreCase(CommerceConstants.REFURBISHED)) {
				return CommerceConstants.RECONDITIONED;
			}
		}
		return stockType;
	}

	/**
	 *
	 * @return String - PIM_Brand
	 */
	public String getPimBrand() {
		return getCharactersticValue(CommerceConstants.PRODUCT_CHARACTERISTICS,CommerceConstants.PIM_BRAND);
	}

	/**
	 * @return String - seoDynamicTitle
	 */
	public String getSeoDynamicTitle() {
		return seoDynamicTitle;
	}

	/**
	 * Sets seoDynamicTitle
	 * @param String - seoDynamicTitle
	 */
	public void setSeoDynamicTitle(String seoDynamicTitle) {
		this.seoDynamicTitle = seoDynamicTitle;
	}

	/**
	 * <p>
	 * Method to return showTimer
	 *
	 * @return String showTimer
	 */
	@Override
	public String getShowTimer() {
		return showTimer;
	}

	/**
	 * <p>
	 * Method to return freePhoneText
	 *
	 * @return String freePhoneText
	 */
	@Override
	public String getFreePhoneText() {
		return freePhoneText;
	}

	/**
	 * <p>
	 * Returns categoryApiPath from configuration
	 * </p>
	 *
	 * @return String - categoryApiPath
	 */
	@Override
	public String getCategoryApiPath() {
		return tracfoneApiService.getCategoryApiPath();
	}

	/*
	 * String is used for part number API call
	 * @return String - fall back queryString
	 */
	@Override
	public String getFallBackQueryString() {
		return CommerceUtil.getFallBackQueryString(getBrand(),selection);
	}

	/**
	 * <p>
	 *
	 * @return String marketPlace
	 */
	@Override
	public String getMarketPlace() {
		return marketPlace;
	}

	@Override
	public String getProductSchemaObj() {
		return productSchemaObj;
	}

	public void setProductSchemaObj(String productSchemaObj) {
		this.productSchemaObj = productSchemaObj;
	}

	/**
	 * <p>
	 * Fetches enablePromotionalOffers
	 * </p>
	 *
	 * @return the enablePromotionalOffers
	 */
	public String getEnablePromotionalOffers() {
		return enablePromotionalOffers;
	}

	/**
	 * <p>
	 * Sets enablePromotionalOffers
	 * </p>
	 *
	 * @param enablePromotionalOffers - the enablePromotionalOffers to set
	 */
	public void setEnablePromotionalOffers(String enablePromotionalOffers) {
		this.enablePromotionalOffers = enablePromotionalOffers;
	}
}