/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;

import com.tracfonecore.core.constants.ApplicationConstants;

import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Defines bean to hold link detail
 * </p>
 */
public class LinkBean {

	private String linkText;
	private String linkDescription;
	private String linkAltText;
	private String linkUrl;
	private String newWindow;
	private String linkIcon;
	private String ctaType;
	private String eventName;
	private String doNotFollowLink;
	private String heading;
	private boolean showLinkText;
	private boolean showLinkTextAndIconSameLine;
	private String linkName;
	private String iconName;
	private String pagePath;

	/**
	 * <p>Fetches text of the link</p>
	 * 
	 * @return String - text of the link
	 */
	public String getLinkText() {
		return linkText;
	}

	/**
	 * <p>Sets text of the link</p>
	 * 
	 * @param linkText - text of the link
	 */
	public void setLinkText(String linkText) {
		this.linkText = linkText;
	}

	/**
	 * <p>Fetches alt text of the link</p>
	 * 
	 * @return String - alt text of the link
	 */
	public String getLinkAltText() {
		return linkAltText;
	}

	/**
	 * <p>Sets alt text of the link</p>
	 * 
	 * @param linkAltText - alt text of the link
	 */
	public void setLinkAltText(String linkAltText) {
		this.linkAltText = linkAltText;
	}	
	
	/**
	 * <p>Fetches url of the link</p>
	 * 
	 * @return String - url of the link
	 */
	public String getLinkUrl() {
		return linkUrl;
	}

	/**
	 * <p>Sets url of the link</p>
	 * 
	 * @param linkUrl - url of the link
	 */
	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}

	/**
	 * <p>Fetches whether to open the link in new window or not</p>
	 * 
	 * @return String - specifies whether to open the link in new window or not
	 */
	public String getNewWindow() {
		return newWindow;
	}

	/**
	 * <p>Sets whether to open the link in new window or not</p>
	 * 
	 * @param newWindow - specifies whether to open the link in new window or not
	 */
	public void setNewWindow(String newWindow) {
		this.newWindow = newWindow;
	}

	/**
	 * <p>Fetches icon for the link</p>
	 * 
	 * @return String - icon for the link
	 */
	public String getLinkIcon() {
		return linkIcon;
	}

	/**
	 * <p>Sets icon for the link</p>
	 * 
	 * @param linkIcon - icon for the link
	 */
	public void setLinkIcon(String linkIcon) {
		this.linkIcon = linkIcon;
	}

	/**
	 * <p>Fetches whether to set link as no-follow</p>
	 * 
	 * @return String - specifies whether to set the link as no-follow 
	 */
	public String getDoNotFollowLink() {
		return doNotFollowLink;
	}

	/**
	 * <p>Sets whether to set link as no-follow</p>
	 * 
	 * @param donotfollowlink - specifies whether to set the link as no-follow 
	 */
	public void setDoNotFollowLink(String doNotFollowLink) {
		this.doNotFollowLink = doNotFollowLink;
	}

	/**
	 * <p>Fetches heading of the detail section</p>
	 *
	 * @return String - heading of the detail section
	 */
	public String getHeading() {
		return heading;
	}

	/**
	 * <p>Sets heading of the detail section</p>
	 *
	 * @return heading - heading of the detail section
	 */
	public void setHeading(String heading) {
		this.heading = heading;
	}

	/**
	 * <p>Sets showLinkText of the detail section</p>
	 *
	 * @return showLinkText - to show the title with icon
	 */
	public boolean getShowLinkText() {
		return showLinkText;
	}

	/**
	 * <p>Sets showLinkText of the detail section</p>
	 *
	 * @return showLinkText - to show the title with icon
	 */
	public void setShowLinkText(String showLinkText) {
		this.showLinkText = StringUtils.isNotBlank(showLinkText) && 
				showLinkText.equalsIgnoreCase(ApplicationConstants.TRUE)? true : false;		
	}

	/**
	 * <p>Sets showLinkTextAndIconSameLine of the detail section</p>
	 *
	 * @return showLinkTextAndIconSameLine - to show the title with icon
	 */
	public boolean getShowLinkTextAndIconSameLine() {
		return showLinkTextAndIconSameLine;
	}

	/**
	 * <p>Sets showLinkTextAndIconSameLine of the detail section</p>
	 *
	 * @return showLinkTextAndIconSameLine - to show the title with icon
	 */
	public void setShowLinkTextAndIconSameLine(String showLinkTextAndIconSameLine) {
		this.showLinkTextAndIconSameLine = StringUtils.isNotBlank(showLinkTextAndIconSameLine) && 
				showLinkTextAndIconSameLine.equalsIgnoreCase(ApplicationConstants.TRUE)? true : false;		
	}

	/**
	 * @return the linkDescription
	 */
	public String getLinkDescription() {
		return linkDescription;
	}

	/**
	 * @param linkDescription the linkDescription to set
	 */
	public void setLinkDescription(String linkDescription) {
		this.linkDescription = linkDescription;
	}

	/**
	 * @return the ctaType
	 */
	public String getCtaType() {
		return ctaType;
	}

	/**
	 * @param ctaType the ctaType to set
	 */
	public void setCtaType(String ctaType) {
		this.ctaType = ctaType;
	}

	/**
	 * @return the eventName
	 */
	public String getEventName() {
		return eventName;
	}

	/**
	 * @param eventName the eventName to set
	 */
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	/**
	 * @return the linkName
	 */
	public String getLinkName(){	
		return linkName;
	}

	/**
	 * @param linkName the linkName to set
	 */
	public void setLinkName(String linkName) {
		this.linkName = linkName;
	}

	/**
	 * @return the iconName
	 */
	public String getIconName() {
		return iconName;
	}

	/**
	 * @param iconName the iconName to set
	 */
	public void setIconName(String iconName) {
		this.iconName = iconName;
	}

	/**
	 * @return the pagePath
	 */
	public String getPagePath() {
		return pagePath;
	}

	/**
	 * @param pagePath the pagePath to set
	 */
	public void setPagePath(String pagePath) {
		this.pagePath = pagePath;
	}


}
