/**
 * 
 */
package com.tracfonecore.core.models.impl;

import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.KyopPopupModel;

/**
 * @author HCL
 *
 */
@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { KyopPopupModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/kyopModal", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class KyopPopupModelImpl implements KyopPopupModel{
	
	@Self
	private SlingHttpServletRequest request;
	/**
	 * Inject headerText - textbox
	 */
	@Inject
	@Via("resource")
	private String headerText;
	
	/**
	 * Inject summary - textbox
	 */
	@Inject
	@Via("resource")
	private String summary;
	
	/**
	 * <p>
	 * Returns headerText from properties
	 * </p>
	 * @return the headerText
	 */
	@Override
	public String getHeaderText() {
		return headerText;
	}

	/**
	 * <p>
	 * Returns summary from properties
	 * </p>
	 * @return the summary
	 */
	@Override
	public String getSummary() {
		return summary;
	}

	/**
	 * <p>
	 * Returns exportertype from resource
	 * </p>
	 * 
	 * @return String - exportertype
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
}
