/*
 *  Copyright 2022 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models;

import java.util.List;
import java.util.Map;

import org.apache.sling.models.annotations.Default;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.utils.ConfigurationUtil;
import com.tracfonecore.core.beans.FeatureBean;

public interface MultilinePlanListModel extends ComponentExporter {

	/**
	 * <p>
	 * Fetches pageType label
	 * </p>
	 *
	 * @return String - pageType label
	 */
	@JsonProperty("pageType")
	public String getPageType();

	/**
	 * <p>
	 * Fetches plpHeader label
	 * </p>
	 *
	 * @return String - plpHeader label
	 */
	@JsonProperty("plpHeader")
	public String getPlpHeader();

	/**
	 * <p>
	 * Checkbox for H1 tag
	 * </p>
	 *
	 * @return Boolean - h1tag header
	 */
	@JsonProperty("h1tagheader")
	@Default(booleanValues = false)
	public boolean getH1TagHeader();

	/**
	 * <p>
	 * Fetches fccLabelLink label
	 * </p>
	 *
	 * @return String - fccLabelLink label
	 */
	@JsonProperty("fccLabelLink")
	public String getFccLabelLink();

	/**
	 * <p>
	 * Fetches pdpJsonPath label
	 * </p>
	 *
	 * @return String - pdpJsonPath label
	 */
	@JsonProperty("pdpJsonPath")
	public String getPdpJsonPath();

	/**
	 * <p>
	 * Fetches plpSubHeader label
	 * </p>
	 *
	 * @return String - plpSubHeader label
	 */
	@JsonProperty("plpSubHeader")
	public String getPlpSubHeader();

	/**
	 * <p>
	 * Fetches disclaimer label
	 * </p>
	 *
	 * @return String - disclaimer label
	 */
	@JsonProperty("disclaimer")
	public String getDisclaimer();

	/**
	 * <p>Fetches detail for all the features</p>
	 *
	 * @return String - detail for all the features
	 */
	@JsonProperty("featureList")
	public List<FeatureBean> getFeatureList();

	/**
	 * <p>
	 * Fetches byopPlanHeaderText
	 * </p>
	 *
	 * @return String - byopPlanHeaderText
	 */
	@JsonProperty("byopPlanHeaderText")
	public String getByopPlanHeaderText();

	/**
	 * <p>
	 * Fetches showMultiLineSelector label
	 * </p>
	 *
	 * @return String - showMultiLineSelector label
	 */
	@JsonProperty("showMultiLineSelector")
	public Boolean getShowMultiLineSelector();

	/**
	 * <p>
	 * Fetches multilineSelectorText label
	 * </p>
	 *
	 * @return String - multilineSelectorText label
	 */
	@JsonProperty("multilineSelectorText")
	public String getMultilineSelectorText();

	/**
	 * <p>
	 * Fetches priceBreakdownLabel label
	 * </p>
	 *
	 * @return String - priceBreakdownLabel label
	 */
	@JsonProperty("priceBreakdownLabel")
	public String getPriceBreakdownLabel();

	/**
	 * <p>
	 * Fetches showTimer label
	 * </p>
	 *
	 * @return String - showTimer label
	 */
	@JsonProperty("showTimer")
	public String getShowTimer();

	/**
	 * <p>
	 * Fetches selectButtonLabel label
	 * </p>
	 *
	 * @return String - selectButtonLabel label
	 */
	@JsonProperty("selectButtonLabel")
	public String getSelectButtonLabel();


	/**
	 * <p>
	 * Fetches seeDetailLinkLabel label
	 * </p>
	 *
	 * @return String - seeDetailLinkLabel label
	 */
	@JsonProperty("seeDetailLinkLabel")
	public String getSeeDetailLinkLabel();

	/**
	 * <p>
	 * Fetches backToSummaryLabel label
	 * </p>
	 *
	 * @return String - backToSummaryLabel label
	 */
	@JsonProperty("backToSummaryLabel")
	public String getBackToSummaryLabel();

	/**
	 * <p>
	 * Fetches property to hide compare
	 * </p>
	 *
	 * @return String - the disableCompare
	 */
	@JsonProperty("disableCompare")
	public String getDisableCompare();
	/**
	 * <p>
	 * Fetches property to hide Features
	 * </p>
	 *
	 * @return String - the disableFeatures
	 */
	@JsonProperty("disableFeatures")
	public String getDisableFeatures();
	/**
	 * <p>
	 * Fetches property to hide Features
	 * </p>
	 *
	 * @return String - the disableFeatures
	 */
	@JsonProperty("fccLabelOnCard")
	public String getFccLabelOnCard();

	/**
	 * <p>
	 * Fetches compare Tab Description
	 * </p>
	 *
	 * @return String - compare Tab Description
	 */
	@JsonProperty("compare Tab Description")
	public String getCompareTabDescription();

	/**
	 * <p>
	 * Fetches compare Button Label
	 * </p>
	 *
	 * @return String - compare Button Label
	 */
	@JsonProperty("compareButtonLabel")
	public String getCompareButtonLabel();

	/**
	 * <p>
	 * Fetches compare Button Link
	 * </p>
	 *
	 * @return String - compare Button Link
	 */
	@JsonProperty("compareButtonLink")
	public String getCompareButtonLink();

	/**
	 * <p>
	 * Fetches home page level property from config
	 * </p>
	 *
	 * @return int - homePageLevel
	 */
	int getHomePageLevel();

	/**
	 * <p>
	 * Fetches device Type Param
	 * </p>
	 *
	 * @return String - device Type Param
	 */
	public String getCategoryId();

	public String getCategoryType();

	/**
	 * <p>
	 * Fetches applyPurchasePlanFacet flag
	 * </p>
	 *
	 * @return String - applyPurchasePlanFacet flag
	 */
	@JsonProperty("applyPurchasePlanFacet")
	public String getApplyPurchasePlanFacet();

	/**
	 * <p>
	 * Fetches applyTabletPlanFacet flag
	 * </p>
	 *
	 * @return String - applyTabletPlanFacet flag
	 */
	@JsonProperty("applyTabletPlanFacet")
	public String getApplyTabletPlanFacet();

	/**
	 * <p>
	 * Fetches applyActivationPlanFacet flag
	 * </p>
	 *
	 * @return String - applyActivationPlanFacet flag
	 */
	@JsonProperty("applyActivationPlanFacet")
	public String getApplyActivationPlanFacet();

	/**
	 * <p>
	 * Fetches purchasePlanTypeFacet
	 * </p>
	 *
	 * @return String - purchasePlanTypeFacet
	 */
	@JsonProperty("purchasePlanTypeFacet")
	public String getPurchasePlanTypeFacet();

	/**
	 * <p>
	 * Fetches tabletPlanTypeFacet
	 * </p>
	 *
	 * @return String - tabletPlanTypeFacet
	 */
	@JsonProperty("tabletPlanTypeFacet")
	public String getTabletPlanTypeFacet();

	/**
	 * <p>
	 * Fetches servicePlanFacet
	 * </p>
	 *
	 * @return String - servicePlanFacet
	 */
	@JsonProperty("servicePlanFacet")
	public String getServicePlanFacet();

	/**
	 * <p>
	 * Fetches activationPlanTypeFacet
	 * </p>
	 *
	 * @return String - activation Plan Type Facet
	 */
	@JsonProperty("activationPlanTypeFacet")
	public String getActivationPlanTypeFacet();

	/**
	 * <p>
	 * Fetches compareLinkLabel
	 * </p>
	 *
	 * @return String - compareLinkLabel
	 */
	@JsonProperty("compareLinkLabel")
	public String getCompareLinkLabel();

	/**
	 * <p>
	 * Fetches specsOptions
	 * </p>
	 *
	 * @return the specsOptions
	 */
	@JsonProperty("specsOptions")
	public String getSpecsOptions();

	/**
	 * <p>
	 * Fetches the export child items
	 * </p>
	 *
	 * @return Map<String, ? extends ComponentExporter> - the export child items
	 */
	public Map<String, ? extends ComponentExporter> getItems();

	/**
	 * <p>
	 * Method to return exporter type
	 * </p>
	 *
	 * @return String
	 */
	public String getExportedType();

	/**
	 * <p>
	 * Method to return isAddOn
	 * </p>
	 *
	 * @return String
	 */
	public String getIsAddOn();

	/**
	 * <p>
	 * Fetches hotspotPlanTypeFacet
	 * </p>
	 *
	 * @return String - hotspotPlanTypeFacet
	 */
	@JsonProperty("hotspotPlanTypeFacet")
	public String getHotspotPlanTypeFacet();

	/**
	 * <p>
	 * Fetches applyHotspotPlanFacet flag
	 * </p>
	 *
	 * @return String - applyHotspotPlanFacet flag
	 */
	@JsonProperty("applyHotspotPlanFacet")
	public String getApplyHotspotPlanFacet();

	/**
	 * <p>
	 * Method to return query string
	 * </p>
	 *
	 * @return String
	 */
	@JsonProperty("queryString")
	public String getQueryString();

	/**
	 * <p>
	 * Method to return Json Page Path
	 * </p>
	 *
	 * @return String
	 */
	@JsonProperty("jsonPagePath")
	public String getJsonPagePath();

	/**
	 * <p>
	 * Method to return Number of Lines List
	 * </p>
	 *
	 * @return String
	 */
	public List<Object> getNumberOfLinesList();

	/**
	 * <p>
	 * Method to return API Category Path
	 * </p>
	 *
	 * @return String
	 */
	public String getCategoryApiPath();

	/**
	 * <p>
	 * Fetches addOnPlanFacet 
	 * </p>
	 *
	 * @return the addOnPlanFacet
	 */

	public String getAddOnPlanFacet();

	/**
	 * <p>
	 * Method to default plan thumbnail image
	 * </p>
	 *
	 * @return String
	 */
	@JsonProperty("defaultPlanThumbnailImage")
	public String getDefaultPlanThumbnailImage();

	/**
	 * <p>
	 * Fetches skipPlanType property from config
	 * </p>
	 *
	 * @return String[] - skipPlanType
	 */
	@JsonProperty("skipPlanType")
	public String getSkipPlanType();

	/**
	 * <p>
	 * Fetches plan Thumbnail Image WeberId
	 * </p>
	 *
	 * @return String - plan Thumbnail Image WeberId
	 */
	@JsonProperty("planThumbnailImageWeberId")
	public String getPlanThumbnailImageWeberId();

	/**
	 * <p>
	 * Fetches plan Thumbnail Image AssestId
	 * </p>
	 *
	 * @return String - plan Thumbnail Image AssestId
	 */
	@JsonProperty("planThumbnailImageAssestId")
	public String getPlanThumbnailImageAssestId();

	/**
	 * <p>
	 * Fetches showRewardsText
	 * </p>
	 *
	 * @return String - showRewardsText
	 */
	@JsonProperty("showRewardsText")
	public String getShowRewardsText();

	/**
	 * <p>
	 * Fetches discountText
	 * </p>
	 *
	 * @return the discountText
	 */
	@JsonProperty("discountText")
	String getDiscountText();

	/**
	 * <p>
	 * Fetches addButton
	 * </p>
	 *
	 * @return String - addButton
	 */
	@JsonProperty("addButton")
	public String getAddButton();

	/**
	 * <p>
	 * Fetches disableBazaarVoiceRatings
	 * </p>
	 *
	 * @return String - disableBazaarVoiceRatings
	 */
	@JsonProperty("disableBazaarVoiceRatings")
	public String getDisableBazaarVoiceRatings();




	/**
	 * <p>
	 * Fetches activationPlansHeading
	 * </p>
	 *
	 * @return String - activationPlansHeading
	 */
	@JsonProperty("activationPlansHeading")
	public String getActivationPlansHeading();

	/**
	 * <p>
	 * Fetches currentPlanLabel
	 * </p>
	 *
	 * @return String - currentPlanLabel
	 */
	@JsonProperty("currentPlanLabel")
	public String getCurrentPlanLabel();

	/**
	 * <p>
	 * Fetches reactivationPlanTypeFacet
	 * </p>
	 *
	 * @return String - reactivation Plan Type Facet
	 */
	@JsonProperty("reactivationPlanTypeFacet")
	public String getReactivationPlanTypeFacet();

	/**
	 * <p>
	 * Fetches phone number label
	 * </p>
	 *
	 * @return String - Phone Number Label
	 */
	@JsonProperty("phoneNumberLabel")
	public String getPhoneNumberLabel();

	/**
	 * <p>
	 * Fetches service end date label
	 * </p>
	 *
	 * @return String - Service End Date Label
	 */
	@JsonProperty("serviceEndLabel")
	public String getServiceEndLabel();

	/**
	 * <p>
	 * Fetches different number label
	 * </p>
	 *
	 * @return String - Different Number Label
	 */
	@JsonProperty("differentNumberLabel")
	public String getDifferentNumberLabel();

	/**
	 * <p>
	 * Fetches addon section heading
	 * </p>
	 *
	 * @return String - Addon Section Heading
	 */
	@JsonProperty("addonSectionHeading")
	public String getAddonSectionHeading();

	/**
	 * <p>
	 * Fetches refillPlanTypeFacet
	 * </p>
	 *
	 * @return String - refill Plan Type Facet
	 */
	@JsonProperty("refillPlanTypeFacet")
	public String getRefillPlanTypeFacet();

	/**
	 * <p>
	 * Fetches refillPagePath
	 * </p>
	 *
	 * @return String - refill Page Path
	 */
	@JsonProperty("refillPagePath")
	public String getRefillPagePath();

	/**
	 * <p>
	 * Fetches planServiceDaysLabel
	 * </p>
	 *
	 * @return String - plan Service Days Label
	 */
	@JsonProperty("planServiceDaysLabel")
	public String getPlanServiceDaysLabel();

	/**
	 * <p>
	 * Fetches applyHomeInternetPlanFacet flag
	 * </p>
	 *
	 * @return String - applyHomeInternetPlanFacet flag
	 */
	@JsonProperty("applyHomeInternetPlanFacet")
	public String getApplyHomeInternetPlanFacet();

	/**
	 * <p>
	 * Fetches homeInternetPlanFacet 
	 * </p>
	 *
	 * @return the homeInternetPlanFacet
	 */
	@JsonProperty("homeInternetPlanFacet")
	public String getHomeInternetPlanFacet();

	/*
	 * Fetches viewFccLabelText
	 * </p>
	 *
	 * @return String - view Fcc Label link text
	 */
	@JsonProperty("fourthLineDiscountLabel")
	public String getFourthLineDiscountLabel();
	@JsonProperty("pdpJsonForLanding")
	public String getPdpJsonForLanding();
	/*
	 * Fetches viewFccLabelText
	 * </p>
	 *
	 * @return String - view Fcc Label link text
	 */
	@JsonProperty("viewFccLabelText")
	public String getViewFccLabelText();

	/**
	 * <p>
	 * Fetches marketingQueryString
	 * </p>
	 *
	 * @return String - marketing Query String
	 */
	@JsonProperty("marketingQueryString")
	public String getMarketingQueryString();

	/**
	 * <p>
	 * Fetches marketingApiPath
	 * </p>
	 *
	 * @return String - marketing Api Path
	 */
	@JsonProperty("marketingApiPath")
	public String getMarketingApiPath();

	@JsonProperty("hotspotPartClass")
	public String getHotspotPartClass();
}
