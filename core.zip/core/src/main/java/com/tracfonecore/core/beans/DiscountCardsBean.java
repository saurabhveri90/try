package com.tracfonecore.core.beans;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DiscountCardsBean {

    private String cardTitle;
	private String cardIcon;
    private String cardSummary;
	private String cardDisclaimers;
	private List<DiscountCardAccordionBean> accordionList = Collections.emptyList();
	
	public String getCardTitle() {
		return cardTitle;
	}
	public void setCardTitle(String cardTitle) {
		this.cardTitle = cardTitle;
	}
	public String getCardIcon() {
		return cardIcon;
	}
	public void setCardIcon(String cardIcon) {
		this.cardIcon = cardIcon;
	}
    public String getCardSummary() {
		return cardSummary;
	}
	public void setCardSummary(String cardSummary) {
		this.cardSummary = cardSummary;
	}
    public String getCardDisclaimers() {
		return cardDisclaimers;
	}
	public void setCardDisclaimers(String cardDisclaimers) {
		this.cardDisclaimers = cardDisclaimers;
	}
	public List<DiscountCardAccordionBean> getAccordionList() {
		return new ArrayList<>(accordionList);
	}
	public void setAccordionList(List<DiscountCardAccordionBean> accordionList) {
		this.accordionList = new ArrayList<>(accordionList);
	}

}