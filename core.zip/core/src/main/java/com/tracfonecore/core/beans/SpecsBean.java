package com.tracfonecore.core.beans;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.tracfonecore.core.models.SpecsOptions;

public class SpecsBean {

	private List<SpecsOptions> otherSpecs = Collections.emptyList();
	private List<SpecsOptions>  specsOptions = Collections.emptyList();
	/**
	 * @return the specsOptions
	 */
	public List<SpecsOptions> getSpecsOptions() {
		return new ArrayList<>(specsOptions);
	}
	/**
	 * @param specsOptions the specsOptions to set
	 */
	public void setSpecsOptions(List<SpecsOptions> specsOptions) {
		this.specsOptions = Optional.ofNullable(specsOptions)
				.map(List::stream).orElseGet(Stream::empty).collect(Collectors.toList());
	}
	/**
	 * @return the otherSpecs
	 */
	public List<SpecsOptions> getOtherSpecs() {
		return new ArrayList<>(otherSpecs);
	}
	/**
	 * @param otherSpecsOptions the otherSpecs to set
	 */
	public void setOtherSpecs(List<SpecsOptions> otherSpecsOptions) {
		this.otherSpecs = Optional.ofNullable(otherSpecsOptions)
				.map(List::stream).orElseGet(Stream::empty).collect(Collectors.toList());
	}
 
}
