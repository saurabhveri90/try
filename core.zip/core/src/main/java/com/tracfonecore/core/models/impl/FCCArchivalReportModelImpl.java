package com.tracfonecore.core.models.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.constants.FccMapConstants;
import com.tracfonecore.core.models.FCCArchivalReportModel;
import com.tracfonecore.core.services.BroadbandFactsConfigService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { FCCArchivalReportModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/fccarchivalreportpdf", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FCCArchivalReportModelImpl implements FCCArchivalReportModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(FCCArchivalReportModelImpl.class);

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private TracfoneApiGatewayService tracfoneApiService;

	@Inject
	private BroadbandFactsConfigService broadbandFactsConfigService;

	@Inject
	private String startdate;

	@Inject
	private String enddate;

	@Inject
	private String partno;

	@Inject
	private String brand;

	private List<Map<String, String>> fcclabelList  = Collections.emptyList();

	private String messageApiError;
	private static final String ERROR_MESSAGE_DATE = "Invalid date format, Please enter the date in the format YYYY-MM-DD";
	private static final String ERROR_MESSAGE_REDUCE_REG = "An error ocurred while retrieving records. Please reduce the data range and try again.";
	private static final String ERROR_MESSAGE_GENERIC = "Failed to retrieve records";

	@PostConstruct
	private void initModel() {
		LOGGER.debug("Entering initModel method: FCCArchivalReportModelImpl");
		if(!isValidDate(startdate) || !isValidDate(enddate)){
			messageApiError = ERROR_MESSAGE_DATE;
		}else {
			String responseString = getArchivalResponse();

			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode jsonNode = null;
			try {
				if(StringUtils.isNotBlank(responseString)) {
					jsonNode = objectMapper.readTree(responseString);
					if(jsonNode.has("fccCards")){
						JsonNode fccNode = jsonNode.get("fccCards");
						int maxCards = broadbandFactsConfigService.getFccMaxLimitPdfFetched();
						LOGGER.debug("FCCArchivalReportModelImpl fetched {} records ", fccNode.size());
						if(fccNode != null && fccNode.size() >= maxCards){
							messageApiError = ERROR_MESSAGE_REDUCE_REG;
						}else{
							int pdfLimit = broadbandFactsConfigService.getFccMaxLimitPdfDisplayed();
							LOGGER.debug("FCC PDF Limit {}", pdfLimit);
							fcclabelList = new ArrayList<>();
							for(int i = 0; i < pdfLimit && i < fccNode.size(); i++) {
								JsonNode jsonElement = fccNode.get(i);
								Map<String, String> fccLablesMap = new HashMap<>();
								parseJsonNode("", jsonElement, fccLablesMap);
								fccLablesMap.putAll(FccMapConstants.getFccContantsProperties());
								fcclabelList.add(fccLablesMap);			
							}
						}				
					}else{
						if(jsonNode.has("status")) {
							//set the message error
							JsonNode fccNode = jsonNode.get("status");			
							messageApiError = (fccNode.has("message")) ? fccNode.get("message").asText() : null;
							LOGGER.debug("Error message in status: {}", messageApiError);
						}
					}
				}
			} catch (JsonMappingException e) {
				LOGGER.error("Exception occurred while reading Tree of response ", e);  
			} catch (JsonProcessingException e) {
				LOGGER.error("Exception occurred while procesing Json of response ", e);
			}
		}
		
	}

	@Override
	public String getName() {
		return "FCC Archival Report PDF ";
	}

	@Override
	public int getLimitPDF() {
		return broadbandFactsConfigService.getFccMaxLimitPdfDisplayed();
	}

	@Override
	public String getMessageError(){
		return (StringUtils.isNotBlank(messageApiError)) ? messageApiError : ERROR_MESSAGE_GENERIC;
	}

	@Override
	public List<Map<String, String>> getLabelList() {
		return new ArrayList<>(fcclabelList);
	}

	/**
	 * Recursively parses a JsonNode and stores its keys and values in a map
	 * @param currentPath the current path of keys, concatenated with dots.
	 * @param node the JsonNode to parse
	 * @param map the map to store the keys and values.
	 */
	private void parseJsonNode(String currentPath, JsonNode node, Map<String, String> map){
		if(node.isObject()){
			Iterator<Map.Entry<String, JsonNode>> fields = node.fields();
			while(fields.hasNext()){
				Map.Entry<String,JsonNode> entry = fields.next();
				LOGGER.debug("Inside parse Json {} and {}", entry.getKey(), entry.getValue());
				String pathPrefix = (currentPath.isEmpty()) ? "" : (currentPath + ".");
				parseJsonNode(pathPrefix + entry.getKey(), entry.getValue(), map);
			}
		} else if(node.isValueNode()){
			map.put(currentPath, node.asText());
		}
	}

	private String getArchivalResponse() {

		String responseContent = null;

		LOGGER.info("brand is {}", brand);
		/* String clientId = ConfigurationUtil.getConfigValue(tracfoneApiService.getApiClientId(), brand) != null
				? ConfigurationUtil.getConfigValue(tracfoneApiService.getApiClientId(), brand)
				: ""; 
		if(clientId == null || clientId.equals("")){clientId = tracfoneApiService.getFccApiClientId();} */

		String clientId = tracfoneApiService.getFccApiClientId();
		StringBuilder apiUrlBuilder = new StringBuilder(tracfoneApiService.getApiDomain()).append("/catalog-mgmt/fcc-label-archive")
				.append(CommerceConstants.QUESTION_MARK).append(CommerceConstants.BRAND).append(CommerceConstants.EQUALS_TO).append(brand)
				.append(CommerceConstants.AMPERSAND).append(CommerceConstants.START_DATE).append(CommerceConstants.EQUALS_TO).append(startdate)
				.append(CommerceConstants.AMPERSAND).append(CommerceConstants.END_DATE).append(CommerceConstants.EQUALS_TO).append(enddate)
				.append(CommerceConstants.AMPERSAND).append(CommerceConstants.CLIENT_ID).append(CommerceConstants.EQUALS_TO).append(clientId);
		if(StringUtils.isNotBlank(partno)) { apiUrlBuilder.append(CommerceConstants.AMPERSAND).append(CommerceConstants.PART_NUMBER).append(CommerceConstants.EQUALS_TO).append(partno);}
		String apiURL = apiUrlBuilder.toString();
		LOGGER.info("apiURL is {}", apiURL);
		// String apiURL =
		// "https://sit-apigateway.tracfone.com/api/sitf/catalog-mgmt/fcc-label-archive?partNumber=NTAPPACP1&brand=NET10&startDate=2023-11-21&endDate=2024-11-21&client_id=bfca29a8-5476-45ad-b5fb-0e2d4a45056d";
		try {
			int timeout = broadbandFactsConfigService.getFccArchivalTimeoutConection();
			RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(timeout)
					.setSocketTimeout(timeout).build();
			HttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(requestConfig).build();
			HttpGet httpGet = new HttpGet(apiURL);

			HttpResponse response = httpClient.execute(httpGet);
			int statusCode = response.getStatusLine().getStatusCode();
			LOGGER.info("Response Code: " + statusCode);
			responseContent = EntityUtils.toString(response.getEntity());
			LOGGER.info("Response Content: " + responseContent);
			if (responseContent == null) {
				return null;
			}

		} catch(java.net.SocketTimeoutException e){
			LOGGER.error("SocketTimeoutException occurred while executing httpClient ", e);
			messageApiError = ERROR_MESSAGE_REDUCE_REG;
		} 
		catch (ClientProtocolException e) {
			LOGGER.error("ClientProtocolException occurred while executing httpClient ", e);
		} catch (IOException e) {
			LOGGER.error("IOException occurred while executing httpClient ", e);
		}
		
		return responseContent;

	}

	/**
	 * Validate the date is in format YYYY-MM-DD
	 * @param date String date
	 * @return True or false
	 */
	private boolean isValidDate(String date){
		String regex = "\\d{4}-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])";
		Boolean isValid = Pattern.matches(regex, date);
		LOGGER.debug("The date {} is {}", date, isValid);
		return isValid;
	}

	@Override
	public String getExportedType() {
		return null;
	}

}
