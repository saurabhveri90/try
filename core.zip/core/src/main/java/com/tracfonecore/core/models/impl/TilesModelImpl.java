package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.TilesDataBean;
import com.tracfonecore.core.models.TilesModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { TilesModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/tiles", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class TilesModelImpl extends BaseComponentModelImpl implements TilesModel  {


	@Self
	private SlingHttpServletRequest request;
	
	/**
	 * Inject style
	 */
	@ValueMapValue
	private String style;

	/**
	 * Inject Heading
	 */
	@ValueMapValue
	private String heading;

	/**
	 * Inject subtext
	 */
	@ValueMapValue
	private String subtext;

	/**
	 * Inject Heading Alignment
	 */
	@ValueMapValue
	private String headingAlignment;
	
	/**
	 * Inject Tiles Per Row
	 */
	@ValueMapValue
	private String tilesPerRow;
	
	/**
	 * Inject eyebrow image label text
	 */
	@ValueMapValue
	private String eyebrowLabelText;
	
	/**
	 * Inject eyebrow image
	 */
	@ValueMapValue
	private String eyebrowImage;
	
	/**
	 * Inject eyebrow image alt text
	 */
	@ValueMapValue
	private String eyebrowImageAltText;
	
	/**
	 * Inject Tiles
	 */
	@ChildResource
	private List<TilesDataBean> tiles;

	/**
	 * Inject button for header
	 */
	@ValueMapValue

	private String showHeaderCTA;
	
	/**
	 * Inject button for footer
	 */
	@ValueMapValue
	private String showFooterCTA;

	/**
	 * <p>
	 * Returns style from properties
	 * </p>
	 * 
	 * @return String - style
	 */
	@Override
	public String getStyle() {
		return style;
	}

	/**
	 * <p>
	 * Returns heading from properties
	 * </p>
	 * 
	 * @return String - heading
	 */
	@Override
	public String getHeading() {
		return heading;
	}

	/**
	 * <p>
	 * Returns headingAlignment from properties
	 * </p>
	 * 
	 * @return String - headingAlignment
	 */
	@Override
	public String getHeadingAlignment() {
		return headingAlignment;
	}

	/**
	 * <p>
	 * Returns tiles from properties
	 * </p>
	 * 
	 * @return List - tiles
	 */
	@Override
	public List<TilesDataBean> getTiles() {
		return new ArrayList<TilesDataBean>(tiles);
	}

	/**
	 * <p>
	 * Returns getexportertype from resource
	 * </p>
	 * 
	 * @return String - getexportertype
	 */
	@Override
	public String getExportedType() {

		return request.getResource().getResourceType();
	}
	
	/**
	 * <p>
	 * Returns tilesPerRow from properties
	 * </p>
	 * 
	 * @return String - tilesPerRow
	 */
	@Override
	public String getTilesPerRow() {
		return tilesPerRow;
	}

	/**
	 * Returns eyebrowLabelText from properties
	 * 
	 * @return String - eyebrowLabelText
	 */
	@Override
	public String getEyebrowLabelText() {
		return eyebrowLabelText;
	}

	/**
	 * Returns eyebrowImage from properties
	 * 
	 * @return String - eyebrowImage
	 */
	@Override
	public String getEyebrowImage() {
		return eyebrowImage;
	}

	/**
	 * Returns eyebrowImageAltText from properties
	 * 
	 * @return String - eyebrowImageAltText
	 */
	@Override
	public String getEyebrowImageAltText() {
		return eyebrowImageAltText;
	}
	
	/**
	 * Returns showHeaderCTA from properties
	 * 
	 * @return String - showHeaderCTA
	 */
	@Override
	public String getShowHeaderCTA() {
		return showHeaderCTA;
	}

	/**
	 * Returns showFooterCTA from properties
	 * 
	 * @return String - showFooterCTA
	 */
	@Override
	public String getShowFooterCTA() {
		return showFooterCTA;
	}
	
	/**
	 * Returns subtext from properties
	 * 
	 * @return String - subtext
	 */
	@Override
	public String getSubtext() {
		return subtext;
	}
}
