package com.tracfonecore.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.MldCardsContainerModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.utils.CommerceUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { MldCardsContainerModel.class},
    resourceType = "tracfone-core/components/commerce/mldcardscontainer", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
    @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
    @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class MldCardsContainerModelImpl implements MldCardsContainerModel {

    @Inject
	private Page currentPage;

    @Inject
	private ApplicationConfigService applicationConfigService;

    @Inject
	protected TracfoneApiGatewayService tracfoneApiService;
    
    @ValueMapValue
	private String showMultilineSelector;

    @ValueMapValue
	private String multilineSelectorText;

    @ValueMapValue
	private String overridePrice;

    @ValueMapValue
	private String showFccLink;

    @ValueMapValue
	private String fccLinkText;

    @ValueMapValue
	private String showPriceBreakdown;

    @ValueMapValue
	private String fccCommonLink;
    
    @ValueMapValue
	private String showCommonFccLink;

    private String queryString;

    @PostConstruct
    private void initModel() {
        setQueryString();
    }

    /**
	 * <p>
	 * Sets queryString using plan part numbers
	 * </p>
	 */
	private void setQueryString() {
        StringBuilder query = new StringBuilder(CommerceConstants.BRAND)
            .append(CommerceConstants.EQUALS_TO)
            .append(CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()))
            .append(CommerceConstants.AMPERSAND)
            .append(CommerceConstants.PART_NUMBER)
            .append(CommerceConstants.EQUALS_TO);
        queryString = query.toString();
	}

    /**
	 * <p>
	 * Returns priceApiPath from configuration
	 * </p>
	 * 
	 * @return String - priceApiPath
	 */
    @Override
    public String getPriceApiPath() {
		return tracfoneApiService.getPriceApiPath();
	}

    @Override
    public String getQueryString() {
        return queryString;
    }

    @Override
    public String getShowMultilineSelector() {
        return showMultilineSelector;
    }

    @Override
    public String getMultilineSelectorText() {
        return multilineSelectorText;
    }

    @Override
    public String getOverridePrice() {
        return overridePrice;
    }

    @Override
    public String getShowFccLink() {
        return showFccLink;
    }

    @Override
    public String getFccLinkText() {
        return fccLinkText;
    }

    @Override
    public String getShowPriceBreakdown() {
        return showPriceBreakdown;
    }

    public String getPlanPlpPagePath() {
        return CommerceUtil.getPagePropertyValue(currentPage, applicationConfigService.getHomePageLevel(), CommerceConstants.PLANS_PAGE_PATH).toString();
    }

    /**
	 * <p>
	 * Method to return numberOfLinesList
	 *
	 * @return List numberOfLinesList
	 */
	public List<Object> getNumberOfLinesList() {
		int numOfLines = Integer.parseInt(CommerceUtil.getPagePropertyValue(currentPage, applicationConfigService.getBrandPageLevel(), CommerceConstants.NUMBER_OF_LINES).toString());
		List<Object> list = new ArrayList<>(numOfLines);
		for (int i = 0; i < numOfLines; i++) {
			list.add("");
		}
		return list;
	}

    @Override
    public String getShowCommonFccLink() {
        return showCommonFccLink;
    }
    @Override
    public String getFccCommonLink() {
        return fccCommonLink;
    }
    
}
