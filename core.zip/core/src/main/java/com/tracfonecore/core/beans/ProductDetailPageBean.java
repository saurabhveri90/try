package com.tracfonecore.core.beans;

/**
 * <p>Defines bean to hold link detail</p>
 */
public class ProductDetailPageBean {
    /*
     *  Copyright 2019 HCL Technologies Ltd.
     *
     *
     */

	private String title;
	  
    private String path;

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the path
	 */
	public String getPath() {
		return path;
	}

	/**
	 * @param path the path to set
	 */
	public void setPath(String path) {
		this.path = path;
	}

   
}
