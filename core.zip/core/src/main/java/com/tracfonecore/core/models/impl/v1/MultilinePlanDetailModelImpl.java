package com.tracfonecore.core.models.impl.v1;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.MultilinePlanDetailModel;
import com.tracfonecore.core.models.impl.BaseComponentModelImpl;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.PurchaseFlowConfigService;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ItemsExporterUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { MultilinePlanDetailModel.class,
        ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/multilineplandetail/v1/multilineplandetail", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class MultilinePlanDetailModelImpl extends BaseComponentModelImpl implements MultilinePlanDetailModel {

  private Map<String, Object> brandPropertyValueMap;

  @Inject
  private Page currentPage;

  @Inject
  private ApplicationConfigService applicationConfigService;

  @Inject
  private SlingModelFilter slingModelFilter;

  @Inject
  private ModelFactory modelFactory;

  @Inject
  private PurchaseFlowConfigService purchaseFlowConfigService;

  @Self
  private SlingHttpServletRequest request;

  @ValueMapValue
  private String planName;

  @ValueMapValue
  private String planNameType;

  @ValueMapValue
  private Boolean showTimer;

  @ValueMapValue
  private String pricesuperscript;

  @ValueMapValue
  private String pertimeperiod;

  @ValueMapValue
  private String priceAccessibilityLabel;

  @ValueMapValue
  private String priceAccessibilityLabelCents;

  @ValueMapValue
  private String saveAccessibilityLabel;

  private String multilineplanrefillHeading;
  private String multilinerefillSubheading;
  private String planrefillInputLabel;
  private String planrefillOTPLabel;
  private String planrefillEditButtonText;
  private String multilineHeading;
  private String multilineSubheading;
  private String priceBreakdownLabel;
  private String newCustomerCtaText;
  private String newCustomerAccessibility;
  private String returnCustomerCtaText;
  private String returnCustomerAccessibility;
  private String returnCustomerCtaLink;
  private String useBazaarVoiceRatings;
  private String planType;
  private String selection;
  private String disclaimerText;
  private String rewardsPurchaseLabel;
  private String rewardsEarnLabel;
  private String addMoreSaveMore;

  @ValueMapValue
  private String offerDisclaimer;

  @ValueMapValue
  private String offerDisclaimerLabel;

  @ValueMapValue
  private String offerDisclaimerLinklabel;

  @ValueMapValue
  private String specialPromoSummary;

  @ValueMapValue
  private String planDescription;

  @Override
  public String getExportedType() {
    return request.getResource().getResourceType();
  }

  @PostConstruct
  protected void initModel() {
    super.initModel();

    String[] properties = { CommerceConstants.BRANDNAME, CommerceConstants.NUMBER_OF_LINES };
    this.brandPropertyValueMap = CommerceUtil.getMultiplePagePropertyValue(currentPage, getBrandPageLevel(),
            properties);

    Page parentPage = currentPage.getParent();
    Page ancestorPage = parentPage.getParent();
    ValueMap pageProperties = null;
    planType = currentPage.getProperties().get("planType", String.class);
    selection = currentPage.getContentResource().getValueMap().get("partNo", String.class);
    if (null != parentPage && CommerceUtil.checkCategoryValues(parentPage.getProperties())) {
      pageProperties = parentPage.getProperties();
    } else if (null != ancestorPage && CommerceUtil.checkCategoryValues(ancestorPage.getProperties())) {
      pageProperties = ancestorPage.getProperties();
    }
    if (pageProperties != null) {
      multilineHeading = pageProperties.get(CommerceConstants.MULTILINE_HEADING, String.class);
      multilineSubheading = pageProperties.get(CommerceConstants.MULTILINE_SUBHEADING, String.class);
      priceBreakdownLabel = pageProperties.get(CommerceConstants.PRICE_BREAKDOWN_LABEL, String.class);
      newCustomerCtaText = pageProperties.get(CommerceConstants.NEW_CUSTOMER_CTA_TEXT, String.class);
      newCustomerAccessibility = pageProperties.get(CommerceConstants.NEW_CUSTOMER_ACCESSIBILITY, String.class);
      returnCustomerCtaText = pageProperties.get(CommerceConstants.RETURN_CUSTOMER_CTA_TEXT, String.class);
      returnCustomerAccessibility = pageProperties.get(CommerceConstants.RETURN_CUSTOMER_ACCESSIBILITY, String.class);
      returnCustomerCtaLink = pageProperties.get(CommerceConstants.RETURN_CUSTOMER_CTA_LINK, String.class);
      useBazaarVoiceRatings = pageProperties.get(CommerceConstants.USE_BAZAAR_VOICE_RATINGS, String.class);
      disclaimerText = pageProperties.get(CommerceConstants.MULTILINE_DISCLAIMER_TEXT, String.class);
      rewardsPurchaseLabel = pageProperties.get(CommerceConstants.REWARDS_PURCHASE_LABEL, String.class);
      rewardsEarnLabel = pageProperties.get(CommerceConstants.REWARDS_EARN_LABEL, String.class);
      addMoreSaveMore = pageProperties.get(CommerceConstants.ADD_MORE_SAVE_MORE, String.class);
      multilineplanrefillHeading = pageProperties.get(CommerceConstants.MULTILINE_REFILL_HEADING, String.class);
      multilinerefillSubheading = pageProperties.get(CommerceConstants.MULTILINE_REFILL_SUBHEADING, String.class);
      planrefillInputLabel = pageProperties.get(CommerceConstants.MULTILINE_REFILL_INPUT_LABEL, String.class);
      planrefillOTPLabel = pageProperties.get(CommerceConstants.MULTILINE_REFILL_OTP_LABEL, String.class);
      planrefillEditButtonText = pageProperties.get(CommerceConstants.MULTILINE_REFILL_EDIT_BUTTON, String.class);
    }

  }

  /**
   * <p>
   * Fetches brand page level property from config
   * </p>
   *
   * @return int - brand page level
   */
  private int getBrandPageLevel() {
    return applicationConfigService.getBrandPageLevel();
  }

  /**
   * <p>
   * Returns true if valuemap has category type and Id values
   * </p>
   *
   * @return Boolean - true/false
   */
  private Boolean checkCategoryValues(ValueMap properties) {

    if (properties != null && properties.containsKey(CommerceConstants.CATEGORY_ID)
            && !properties.get(CommerceConstants.CATEGORY_ID, String.class).isEmpty()
            && properties.containsKey(CommerceConstants.CATEGORY_TYPE)
            && !properties.get(CommerceConstants.CATEGORY_TYPE, String.class).isEmpty()) {
      return true;
    }

    return false;
  }

  /**
   * <p>
   * Returns Plan Name authored
   * </p>
   *
   * @return String - planName
   */
  @Override
  public String getPlanName() {
    return planName;
  }

  /**
   * <p>
   * Returns Plan Name Type authored
   * </p>
   *
   * @return String - planNameType
   */
  @Override
  public String getPlanNameType() {
    return planNameType;
  }

  /**
   * <p>
   * Method to return showTimer
   *
   * @return String showTimer
   */
  @Override
  public Boolean getShowTimer() {
    return showTimer;
  }

  /**
   * <p>
   * Fetches check for number of lines
   * </p>
   *
   * @return String - Number of Lines
   */
  @Override
  public Integer getNumberOfLines() {
    String numOfLines = CommerceUtil.getPropertyValue(this.brandPropertyValueMap, CommerceConstants.NUMBER_OF_LINES);
    return Integer.parseInt(numOfLines);
  }

  /**
   * <p>
   * Returns Multiline Heading authored
   * </p>
   *
   * @return String - multilineHeading
   */
  @Override
  public String getMultilineHeading() {
    return multilineHeading;
  }

  /**
   * <p>
   * Returns Multiline Subheading authored
   * </p>
   *
   * @return String - multilineSubheading
   */
  @Override
  public String getMultilineSubheading() {
    return multilineSubheading;
  }

  /**
   * <p>
   * Returns Price Breakdown Label authored
   * </p>
   *
   * @return String - priceBreakdownLabel
   */
  @Override
  public String getPriceBreakdownLabel() {
    return priceBreakdownLabel;
  }

  /**
   * <p>
   * Returns New Customer CTA Text authored
   * </p>
   *
   * @return String - newCustomerCtaText
   */
  @Override
  public String getNewCustomerCtaText() {
    return newCustomerCtaText;
  }

  /**
   * <p>
   * Returns New Customer Accessibility authored
   * </p>
   *
   * @return String - newCustomerAccessibility
   */
  @Override
  public String getNewCustomerAccessibility() {
    return newCustomerAccessibility;
  }

  /**
   * <p>
   * Returns Return Customer CTA Text authored
   * </p>
   *
   * @return String - returnCustomerCtaText
   */
  @Override
  public String getReturnCustomerCtaText() {
    return returnCustomerCtaText;
  }

  /**
   * <p>
   * Returns Return Customer Accessibility authored
   * </p>
   *
   * @return String - returnCustomerAccessibility
   */
  @Override
  public String getReturnCustomerAccessibility() {
    return returnCustomerAccessibility;
  }

  /**
   * <p>
   * Returns Return Customer CTA Link authored
   * </p>
   *
   * @return String - returnCustomerCtaLink
   */
  @Override
  public String getReturnCustomerCtaLink() {
    String ctaPath = request.getResourceResolver().map(returnCustomerCtaLink);
    if (StringUtils.isEmpty(ctaPath)) {
      ctaPath = returnCustomerCtaLink;
    }
    return ctaPath;
  }

  /**
   * <p>
   * Returns planType from current page properties
   * </p>
   *
   * @return String - planType
   */
  public String getPlanType() {
    return planType;
  }

  /**
   * <p>
   * Method to return selection
   *
   * @return String selection
   */
  @Override
  public String getSelection() {
    return selection;
  }

  /**
   * <p>
   * Method to return useBazaarVoiceRatings
   *
   * @return String useBazaarVoiceRatings
   */
  @Override
  public String getUseBazaarVoiceRatings() {
    return useBazaarVoiceRatings;
  }

  /**
   * <p>
   * Method to return numberOfLinesList
   *
   * @return List numberOfLinesList
   */
  @Override
  public List<Object> getNumberOfLinesList() {
    List<Object> list = new ArrayList<>(getNumberOfLines());
    for (int i = 0; i < getNumberOfLines(); i++) {
      list.add("");
    }
    return list;
  }

  /**
   * <p>
   * Method to return pricesuperscript
   *
   * @return String pricesuperscript
   */
  @Override
  public String getPricesuperscript() {
    return pricesuperscript;
  }

  /**
   * <p>
   * Method to return pertimeperiod
   *
   * @return String pertimeperiod
   */
  @Override
  public String getPertimeperiod() {
    return pertimeperiod;
  }

  /**
   * <p>
   * Method to return priceAccessibilityLabel
   *
   * @return String priceAccessibilityLabel
   */
  @Override
  public String getPriceAccessibilityLabel() {
    return priceAccessibilityLabel;
  }

  /**
   * <p>
   * Method to return disclaimerText
   *
   * @return String disclaimerText
   */

  @Override
  public String getDisclaimerText() {
    return disclaimerText;
  }

  /**
   * <p>
   * Returns Rewards Purchase Label authored
   * </p>
   *
   * @return String - rewardsPurchaseLabel
   */
  @Override
  public String getRewardsPurchaseLabel() {
    return rewardsPurchaseLabel;
  }

  /**
   * <p>
   * Returns Rewards Earn Label authored
   * </p>
   *
   * @return String - rewardsEarnLabel
   */
  @Override
  public String getRewardsEarnLabel() {
    return rewardsEarnLabel;
  }

  /**
   * <p>
   * Method to return priceAccessibilityLabel
   *
   * @return String priceAccessibilityLabel
   */
  @Override
  public String getSaveAccessibilityLabel() {
    return saveAccessibilityLabel;
  }

  /**
   * <p>
   * Method to return multilineplanrefillHeading
   *
   * @return String multilineplanrefillHeading
   */
  @Override
  public String getMultilineplanrefillHeading() {
    return multilineplanrefillHeading;
  }

  /**
   * <p>
   * Method to return multilinerefillSubheading
   *
   * @return String multilinerefillSubheading
   */
  @Override
  public String getMultilinerefillSubheading() {
    return multilinerefillSubheading;
  }

  /**
   * <p>
   * Method to return planrefillInputLabel
   *
   * @return String planrefillInputLabel
   */
  @Override
  public String getPlanrefillInputLabel() {
    return planrefillInputLabel;
  }

  /**
   * <p>
   * Method to return planrefillOTPLabel
   *
   * @return String planrefillOTPLabel
   */
  @Override
  public String getPlanrefillOTPLabel() {
    return planrefillOTPLabel;
  }

  /**
   * <p>
   * Method to return planrefillEditButtonText
   *
   * @return String planrefillEditButtonText
   */
  @Override
  public String getPlanrefillEditButtonText() {
    return planrefillEditButtonText;
  }

  /**
   * <p>
   * Returns json from items
   * </p>
   *
   * @return Map - items
   */
  @Override
  public Map<String, ? extends ComponentExporter> getItems() {
    return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
  }

  /**
   * <p>
   * Returns addMoreSaveMore
   * </p>
   *
   * @return String - addMoreSaveMore
   */
  @Override
  public String getAddMoreSaveMore() {
    return addMoreSaveMore;
  }

  @Override
  public String[] getPurchaseFlow() {
    return purchaseFlowConfigService.getPurchaseFlow();
  }

  /**
   * <p>
   * Returns offerDisclaimer
   * </p>
   *
   * @return String - offerDisclaimer
   */
  @Override
  public String getOfferDisclaimer() {
    return offerDisclaimer;
  }

  /**
   * <p>
   * Returns offerDisclaimerLabel
   * </p>
   *
   * @return String - offerDisclaimerLabel
   */
  @Override
  public String getOfferDisclaimerLabel() {
    return offerDisclaimerLabel;
  }

  /**
   * <p>
   * Returns offerDisclaimerLinklabel
   * </p>
   *
   * @return String - offerDisclaimerLinklabel
   */
  @Override
  public String getOfferDisclaimerLinklabel() {
    return offerDisclaimerLinklabel;
  }

  /**
   * <p>
   * Returns specialPromoSummary
   * </p>
   *
   * @return String - specialPromoSummary
   */
  @Override
  public String getSpecialPromoSummary() {
    return specialPromoSummary;
  }

  /**
   * <p>
   * Returns planDescription
   * </p>
   *
   * @return String - planDescription
   */
  @Override
  public String getPlanDescription() {
    return planDescription;
  }

}