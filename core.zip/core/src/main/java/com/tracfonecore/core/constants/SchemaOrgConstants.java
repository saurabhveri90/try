/**
 *  Copyright 2020 HCL Technologies Ltd. 
 */
package com.tracfonecore.core.constants;

/**
 * Constants used for schema.org across application.
 */
public class SchemaOrgConstants {
	

	public static final String SCHEMA_ORG_URL = "http://schema.org";
	
	public static final String SCHEMA_ORG_WATCH_ACTION = "http://schema.org/WatchAction";
	
	public static final String AT_CONTEXT = "@context";
	
	public static final String AT_TYPE = "@type";
	
	public static final String BREADCRUMB_LIST = "BreadcrumbList";
	
	public static final String ITEM_LIST_ELEMENT= "itemListElement";

	public static final String LIST_ITEM= "ListItem";
	
	public static final String POSITION = "position";
	
	public static final String AT_ID = "@id";
	
	public static final String NAME = "name";
	
	public static final String DESCRIPTION = "description";
	
	public static final String ITEM = "item";
	
	public static final String VIDEO_OBJECT = "VideoObject";
	
	public static final String THUMBNAIL_URL = "thumbnailUrl";
	
	public static final String UPLOAD_DATE = "uploadDate";
	
	public static final String DURATION = "duration";
	
	public static final String CONTENT_URL = "contentUrl";
	
	public static final String EMBED_URL = "embedUrl";
	
	public static final String INTERACTION_STATISTIC = "interactionStatistic";
	
	public static final String INTERACTION_COUNTER = "InteractionCounter";
	
	public static final String INTERACTION_TYPE = "interactionType";
	
	public static final String USER_INTERATION_COUNT = "userInteractionCount";
	
	public static final String PRODUCT = "Product";
	
	public static final String SKU = "sku";
	
	public static final String MPN = "mpn";
	
	public static final String BRAND = "brand";
	
	public static final String OFFERS = "offers";
	
	public static final String OFFER = "offer";
	
	public static final String PRICE = "price";
	
	public static final String AVAILABILITY = "availability";
	
	public static final String BRAND_APPLE = "Apple";
	
	public static final String BRAND_SAMSUNG = "Samsung";
	
	public static final String LOW_PRICE = "lowPrice";
	
	public static final String HIGH_PRICE = "highPrice";
	
	public static final String AGGREGATE_OFFER = "AggregateOffer";
	
	public static final String PRICE_CURRENCY = "priceCurrency";
	
	public static final String USD = "USD";
	
	public static final String OFFERCOUNT = "offerCount";
	
	public static final String INSTOCK = "InStock";
	
	public static final String OUTOFSTOCK = "OutOfStock";
	
	public static final String URL = "url";
	
	public static final String IMAGE = "image";
}
