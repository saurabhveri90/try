package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.collections4.IterableUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.tracfonecore.core.beans.LocatorBean;
import com.tracfonecore.core.beans.LocatorFiltersBean;
import com.tracfonecore.core.beans.LocatorStoreImagesBean;
import com.tracfonecore.core.models.LocatorModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.MapQuestApiGatewayService;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { LocatorModel.class,
        ComponentExporter.class }, resourceType = "tracfone-core/components/content/locator", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class LocatorModelImpl implements LocatorModel {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(LocatorModelImpl.class);
	
	@Self
	private SlingHttpServletRequest request;
	
	@Inject
	private Page currentPage;
	
	@Inject
	protected ApplicationConfigService applicationConfigService;
	
	@Inject
	private MapQuestApiGatewayService mapQuestApiService;
	
	@ValueMapValue
	private String title;
	
	@ValueMapValue
	private String searchText;
	
	@ValueMapValue
	private String searchButtonAriaLabel;
	
	@ValueMapValue @Default(values="")
	private String directionButtonAriaLabel;
	
	@ValueMapValue @Default(values="Map")
	private String mapViewButton;
	
	@ValueMapValue @Default(values="Live Traffic")
	private String trafficViewButton;
	
	@ValueMapValue @Default(values="Sattellite")
	private String sattleliteViewButton;
	
	@ValueMapValue
	private String placeHolder;
	
	@ValueMapValue @Default(values = "25")
	private String maxMatches;
	
	@ValueMapValue @Default(values = "250")
	private String queryResultsLength;
	
	@ValueMapValue @Default(values = "{1}")
	private String dropDownText;
	
	@ValueMapValue @Default(values = "")
	private String noResultText;
	
	@ValueMapValue @Default(values = "")
	private String routeFailedText;
	
	@ValueMapValue @Default(values = "")
	private String directionButtonText;
	
	@ValueMapValue @Default(values = "")
	private String callStoreButtonText;
	
	@ValueMapValue @Default(values = "")
	private String distanceText;
	
	@ValueMapValue @Default(values = "")
	private String timeText;
	
	@ValueMapValue @Default(values = "")
	private String trafficTimeText;
	
	@ValueMapValue @Default(values = "")
	private String goForText;
	
	@ValueMapValue @Default(values = "")
	private String searchOriginText;
	
	@ValueMapValue @Default(values = "")
	private String showMapText;
	
	@ValueMapValue @Default(values = "")
	private String showListText;
	
	@ValueMapValue @Default(values = "")
	private String selectedMapIcon;
	
	@ValueMapValue @Default(values = "")
	private String customMapIcon;
	
	@ValueMapValue @Default(values = "")
	private String walmartImage;
	
	@ChildResource
	private Resource searchRadius;
	
	@ValueMapValue @Default(values = "")
	private String allFiltersLabel;
	
	@ValueMapValue @Default(values = "")
	private String homeDeliveryFilterLbl;
	
	@ValueMapValue @Default(values = "C74100")
	private String authorizedColor;
	
	@ValueMapValue @Default(values = "313334")
	private String nationalColor;
	
	@ValueMapValue @Default(values = "00CCB7")
	private String exclusiveColor;
	
	@ValueMapValue @Default(values = "000F9F")
	private String selectedColor;
	
	@ValueMapValue @Default(values = "false")
	private String highlightWholeResultCard;

	@ChildResource
	private Resource filterOptions;
	
	@ChildResource
	private Resource storesThumbs;
	
	private String mapQuestApiDetails;
	
	private String mapQuestAuthoring;
	
	private List<LocatorBean> radiusList;
	
	private List<LocatorFiltersBean> filtersList;
	
	private List<LocatorStoreImagesBean> storeImagesList;

	@PostConstruct
	private void initModel() {
		
		Iterable<Resource> childResources = searchRadius!= null ? searchRadius.getChildren() : IterableUtils.emptyIterable();		
		this.radiusList = new ArrayList<LocatorBean>();
		childResources.forEach(res -> {
			String radius = Optional.ofNullable(res.getValueMap()).map(vm -> vm.get("radius", String.class)).orElse("");
			String radiusLabel = dropDownText.replace("{1}", radius);
			LocatorBean locatorBean = new LocatorBean();
			locatorBean.setRadiusLabel(radiusLabel);
			locatorBean.setRadius(radius);
			this.radiusList.add(locatorBean);
		});
		
		Iterable<Resource> filterOptionsChildRes = filterOptions!= null ? filterOptions.getChildren() : IterableUtils.emptyIterable();		
		this.filtersList = new ArrayList<LocatorFiltersBean>();
		filterOptionsChildRes.forEach(res -> {
			String filterOptionLabel = Optional.ofNullable(res.getValueMap()).map(vm -> vm.get("filterOptionLabel", String.class)).orElse("");
			String filterOptionValue = Optional.ofNullable(res.getValueMap()).map(vm -> vm.get("filterOptionValue", String.class)).orElse("");
			String filterOptionIcon = Optional.ofNullable(res.getValueMap()).map(vm -> vm.get("filterOptionIcon", String.class)).orElse("");
			LocatorFiltersBean locatorFiltersBean = new LocatorFiltersBean();
			locatorFiltersBean.setFilterOptionLabel(filterOptionLabel);
			locatorFiltersBean.setFilterOptionValue(filterOptionValue);
			locatorFiltersBean.setFilterOptionIcon(filterOptionIcon);
			this.filtersList.add(locatorFiltersBean);
		});
		
		Iterable<Resource> storesThumbsRes = storesThumbs!= null ? storesThumbs.getChildren() : IterableUtils.emptyIterable();		
		this.storeImagesList = new ArrayList<LocatorStoreImagesBean>();
		storesThumbsRes.forEach(res -> {
			String uniqueStoreName = Optional.ofNullable(res.getValueMap()).map(vm -> vm.get("uniqueStoreName", String.class)).orElse("");
			String storeLogo = Optional.ofNullable(res.getValueMap()).map(vm -> vm.get("storeLogo", String.class)).orElse("");
			String storeImage = Optional.ofNullable(res.getValueMap()).map(vm -> vm.get("storeImage", String.class)).orElse("");
			LocatorStoreImagesBean locatorStoreImagesBean = new LocatorStoreImagesBean();
			locatorStoreImagesBean.setUniqueStoreName(uniqueStoreName);
			locatorStoreImagesBean.setStoreLogo(storeLogo);
			locatorStoreImagesBean.setStoreImage(storeImage);
			this.storeImagesList.add(locatorStoreImagesBean);
		});
		
		String brand = CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel());
		String mapApiKey = ConfigurationUtil.getConfigValue(mapQuestApiService.getApiKey(),brand) != null ? ConfigurationUtil.getConfigValue(mapQuestApiService.getApiKey(),brand):"";
		String fieldList = ConfigurationUtil.getConfigValue(mapQuestApiService.getFieldList(),brand) != null ? ConfigurationUtil.getConfigValue(mapQuestApiService.getFieldList(),brand):"";
		String tableName = ConfigurationUtil.getConfigValue(mapQuestApiService.getTableName(),brand) != null ? ConfigurationUtil.getConfigValue(mapQuestApiService.getTableName(),brand):"";
		String isExclusiveStoreFilter = ConfigurationUtil.getConfigValue(mapQuestApiService.getIsExclusiveStoreFilter(),brand) != null ? ConfigurationUtil.getConfigValue(mapQuestApiService.getIsExclusiveStoreFilter(),brand):"";
		String isAuthorizedStoreFilter = ConfigurationUtil.getConfigValue(mapQuestApiService.getIsAuthorizedStoreFilter(),brand) != null ? ConfigurationUtil.getConfigValue(mapQuestApiService.getIsAuthorizedStoreFilter(),brand):"";
		String isNationalRetailerStoreFilter = ConfigurationUtil.getConfigValue(mapQuestApiService.getIsNationalRetailerStoreFilter(),brand) != null ? ConfigurationUtil.getConfigValue(mapQuestApiService.getIsNationalRetailerStoreFilter(),brand):"";
		String isHomeDeliveryStoreFilter = ConfigurationUtil.getConfigValue(mapQuestApiService.getIsHomeDeliveryStoreFilter(),brand) != null ? ConfigurationUtil.getConfigValue(mapQuestApiService.getIsHomeDeliveryStoreFilter(),brand):"";
		
		Gson gson = new Gson();	
		String storeImagesListJson = gson.toJson(this.storeImagesList);
		//Api Config Object
		JsonObject mapQuestApiObj = new JsonObject();
		mapQuestApiObj.addProperty("domain", mapQuestApiService.getApiDomain());
		mapQuestApiObj.addProperty("apiKey", mapApiKey);
		mapQuestApiObj.addProperty("reversePath", mapQuestApiService.getReversePath());
		mapQuestApiObj.addProperty("radiusPath", mapQuestApiService.getRadiusPath());
		mapQuestApiObj.addProperty("rectanglePath", mapQuestApiService.getRectanglePath());
		mapQuestApiObj.addProperty("routePath", mapQuestApiService.getRoutePath());
		mapQuestApiObj.addProperty("mapIcon", mapQuestApiService.getMapIcon());
		mapQuestApiObj.addProperty("units", mapQuestApiService.getUnits());
		mapQuestApiObj.addProperty("fieldList", fieldList);
		mapQuestApiObj.addProperty("tableName", tableName);
		mapQuestApiObj.addProperty("isExclusiveStoreFilter", isExclusiveStoreFilter);
		mapQuestApiObj.addProperty("isAuthorizedStoreFilter", isAuthorizedStoreFilter);
		mapQuestApiObj.addProperty("isNationalRetailerStoreFilter", isNationalRetailerStoreFilter);
		mapQuestApiObj.addProperty("isHomeDeliveryStoreFilter", isHomeDeliveryStoreFilter);
		mapQuestApiObj.addProperty("maxMatches", this.maxMatches);
		mapQuestApiObj.addProperty("queryResultsLength", this.queryResultsLength);
		this.mapQuestApiDetails = gson.toJson(mapQuestApiObj);
		
		//Authoring text Object
		JsonObject mapQuestAuthoringObj = new JsonObject();
		mapQuestAuthoringObj.addProperty("noResultText", this.noResultText);
		mapQuestAuthoringObj.addProperty("routeFailedText", this.routeFailedText);
		mapQuestAuthoringObj.addProperty("directionButtonText", this.directionButtonText);
		mapQuestAuthoringObj.addProperty("callStoreButtonText", this.callStoreButtonText);
		mapQuestAuthoringObj.addProperty("distanceText", this.distanceText);
		mapQuestAuthoringObj.addProperty("timeText", this.timeText);
		mapQuestAuthoringObj.addProperty("trafficTimeText", this.trafficTimeText);
		mapQuestAuthoringObj.addProperty("goForText", this.goForText);
		mapQuestAuthoringObj.addProperty("searchOriginText", this.searchOriginText);
		mapQuestAuthoringObj.addProperty("customMapIcon", this.customMapIcon);
		mapQuestAuthoringObj.addProperty("selectedMapIcon", this.selectedMapIcon);
		mapQuestAuthoringObj.addProperty("walmartImage", this.walmartImage);
		mapQuestAuthoringObj.addProperty("directionButtonAriaLabel", this.directionButtonAriaLabel);
		mapQuestAuthoringObj.add("storeImagesList", new JsonParser().parse(storeImagesListJson));
		mapQuestAuthoringObj.addProperty("authorizedColor", this.authorizedColor);
		mapQuestAuthoringObj.addProperty("nationalColor", this.nationalColor);
		mapQuestAuthoringObj.addProperty("exclusiveColor", this.exclusiveColor);
		mapQuestAuthoringObj.addProperty("selectedColor", this.selectedColor);
		mapQuestAuthoringObj.addProperty("highlightWholeResultCard", this.highlightWholeResultCard);
		this.mapQuestAuthoring = gson.toJson(mapQuestAuthoringObj);
		
	}
	
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * @return the mapQuestApiDetails
	 */
	@Override
	public String getMapQuestApiDetails() {
		return mapQuestApiDetails;
	}

	/**
	 * @return the radiusList
	 */
	@Override
	public List<LocatorBean> getRadiusList() {
		return new ArrayList<>(radiusList);
	}

	/**
	 * @return the filtersList
	 */
	@Override
	public List<LocatorFiltersBean> getFiltersList() {
		return new ArrayList<>(filtersList);
	}
	
	/**
	 * @return the storeImagesList
	 */
	@Override
	public List<LocatorStoreImagesBean> getStoreImagesList() {
		return new ArrayList<>(storeImagesList);
	}
	
	/**
	 * @return the title
	 */
	@Override
	public String getTitle() {
		return title;
	}

	/**
	 * @return the searchText
	 */
	@Override
	public String getSearchText() {
		return searchText;
	}

	/**
	 * @return the mapViewButton
	 */
	@Override
	public String getMapViewButton() {
		return mapViewButton;
	}

	/**
	 * @return the trafficViewButton
	 */
	@Override
	public String getTrafficViewButton() {
		return trafficViewButton;
	}

	/**
	 * @return the sattleliteViewButton
	 */
	@Override
	public String getSattleliteViewButton() {
		return sattleliteViewButton;
	}

	/**
	 * @return the mapQuestAuthoring
	 */
	@Override
	public String getMapQuestAuthoring() {
		return mapQuestAuthoring;
	}

	/**
	 * @return the showMapText
	 */
	@Override
	public String getShowMapText() {
		return showMapText;
	}

	/**
	 * @return the showListText
	 */
	@Override
	public String getShowListText() {
		return showListText;
	}

	/**
	 * @return the placeHolder
	 */
	@Override
	public String getPlaceHolder() {
		return placeHolder;
	}

	/**
	 * @return the searchButtonAriaLabel
	 */
	@Override
	public String getSearchButtonAriaLabel() {
		return searchButtonAriaLabel;
	}
	
	/**
	 * @return the allFiltersLabel
	 */
	@Override
	public String getAllFiltersLabel() {
		return allFiltersLabel;
	}
	
	/**
	 * @return the allFiltersLabel
	 */
	@Override
	public String getHomeDeliveryFilterLbl() {
		return homeDeliveryFilterLbl;
	}

	@Override
	public String getAuthorizedColor() {
		return authorizedColor;
	}

	@Override
	public String getNationalColor() {
		return nationalColor;
	}

	@Override
	public String getExclusiveColor() {
		return exclusiveColor;
	}

	@Override
	public String getSelectedColor() {
		return selectedColor;
	}

	@Override
	public String getHighlightWholeResultCard() {
		return highlightWholeResultCard;
	}
}
