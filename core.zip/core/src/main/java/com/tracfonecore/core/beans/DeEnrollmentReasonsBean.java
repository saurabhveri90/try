package com.tracfonecore.core.beans;

/**
 * @author saurabh_kumar1
 *
 */
public class DeEnrollmentReasonsBean {
	
	private String deEnrollmentReason;
	private String deEnrollmentReasonText;
	
	public String getDeEnrollmentReason() {
		return deEnrollmentReason;
	}
	public void setDeEnrollmentReason(String deEnrollmentReason) {
		this.deEnrollmentReason = deEnrollmentReason;
	}
	public String getDeEnrollmentReasonText() {
		return deEnrollmentReasonText;
	}
	public void setDeEnrollmentReasonText(String deEnrollmentReasonText) {
		this.deEnrollmentReasonText = deEnrollmentReasonText;
	}
	
}
