/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 */
package com.tracfonecore.core.models.impl.v2;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.ImageAndTextModel;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ImageAndTextModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/imageAndText/v2/imageAndText", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ImageAndTextModelImpl extends com.tracfonecore.core.models.impl.v1.ImageAndTextModelImpl implements ImageAndTextModel {
	private static final Logger LOGGER = LoggerFactory.getLogger(ImageAndTextModelImpl.class);

	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private boolean useStackViewInMobile;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private boolean useRowDefaultPadding;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String useImageBorder;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String mediaType;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String videoThumbnailImage;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String videoThMobileVersion;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String showTimer;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private boolean useOppImageAlignInMobile;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String disclaimerText;

	@ValueMapValue
	private String selectedTimerPosition;

	/**
	 * <p>Fetches stack View in Mobile</p>
	 * 
	 * @return boolean - use stack View in Mobile
	 */
	@Override
	public boolean isUseStackViewInMobile() {
		return useStackViewInMobile;
	}

	/**
	 * <p>Fetches useRowDefaultPadding</p>
	 * 
	 * @return boolean - useRowDefaultPadding
	 */
	@Override
	public boolean isUseRowDefaultPadding() {
		return useRowDefaultPadding;
	}

	/**
	 * <p>Fetches useImageBorder</p>
	 * 
	 * @return String - useImageBorder
	 */
	@Override
	public String isUseImageBorder() {
		return useImageBorder;
	}
	/**
	 * <p>
	 * Fetches video thumbnail image
	 * </p>
	 *
	 * @return String - video thumbnail image
	 */
	@Override
	public String getVideoThumbnailImage() {
		String s7Path = DynamicMediaUtils.changeMediaPathToDMPath(this.videoThumbnailImage,
				request.getResourceResolver());
		LOGGER.debug("Carousel Video thumbnail Path: {}", s7Path);
		return s7Path;
	}
	
	/**
	 * <p>
	 * Fetches media type (video/image)
	 * </p>
	 *
	 * @return String - media type
	 */
	@Override
	public String getMediaType() {
		return mediaType;
	}
	
	/**
	 *<p>Fetches the path for mobile thumbnail</p>
	 *
	 * @return String - mobile thumbnail image path
	 */
	@Override
	public String getMobileThumbnailImagePath() {
		String path = DynamicMediaUtils.getMobileDMPath(this.videoThumbnailImage, request.getResourceResolver());
		if(!ApplicationConstants.VIDEO.equals(this.mediaType) && !ApplicationConstants.MOBILE_IMAGE.equals(this.videoThMobileVersion)) {
			path =  StringUtils.EMPTY;
		}
		return path;
	}
	
	/**
	 *<p>Fetches data type for the video</p>
	 *
	 * @return String - videoDataType
	 */
	@Override
	public String getVideoDataType() {
		return ApplicationConstants.VIDEO_DATA_TYPE;
	}
	
	/**
	 * <p>
	 * Method to return showTimer
	 * 
	 * @return String showTimer
	 */
	@Override
	public String getShowTimer() {
		return showTimer;
	}

	/**
	 *<p>Fetches useOppImageAlignInMobile</p>
	 *
	 * @return the useOppImageAlignInMobile
	 */
	@Override
	public boolean isUseOppImageAlignInMobile() {
		return useOppImageAlignInMobile;
	}

	/**
	 *<p>Fetches declarationText</p>
	 *
	 * @return the declarationText
	 */
	@Override
	public String getDisclaimerText() {
		return disclaimerText;
	}

	/**
	 * 
	 * Method to return selected timer position
	 * 
	 * @return String selectedTimerPosition
	 */
	@Override
	public String getSelectedTimerPosition() {
		return selectedTimerPosition;
	}
}
