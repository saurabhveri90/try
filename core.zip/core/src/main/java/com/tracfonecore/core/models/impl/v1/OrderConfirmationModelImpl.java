/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl.v1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.inject.Inject;
import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.OrderConfirmationVasModel;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.OrderConfirmationModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { OrderConfirmationModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/orderconfirmation/v1/orderconfirmation", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class OrderConfirmationModelImpl implements OrderConfirmationModel {

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private Resource resource;

	@ScriptVariable
	private ValueMap properties;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headerTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String orderConfirmationMessage1;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String orderConfirmationMessage2;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String productLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String positionOrderConfirmation;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String productLogoAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String byop25Logo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String byop25LogoAltText;	

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stByop25EnrollInReawardsLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String moreAboutStraightTalkLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String defaultHeaderTitleAct;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String defaultOrderConfirmationMessageAct;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String tutorialTitleAct;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String tutorialTitleActFWAFlow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String tutorialLinkAct;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String defaultProductLogoAct;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String productLogoAltTextAct;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planDetailsTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planDetailsSubtitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String phonesBasePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String plansBasePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headerTitleForPromoCodeFlow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String messageOneForPromoCodeFlow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String messageTwoForPromoCodeFlow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String productLogoForPromoCodeFlow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String productLogoForPromoCodeFlowAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headerTitleForServicePlanFlow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String messageOneForServicePlanFlow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String messageTwoForServicePlanFlow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String productLogoForServicePlanFlow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String productLogoForServicePlanFlowAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String checkStatusLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String simImagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String esimImagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headerTitleForRefillWithPinFlow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String messageOneForRefillWithPinFlow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String messageTwoForRefillWithPinFlow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String messageOneForRefillWithPinAddNowFlow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String messageTwoForRefillWithPinAddNowFlow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String myAccountLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String servicePlanReserveMessage;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String reserveDisclaimerText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headerTitleForRefillWithCCFlow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String messageOneForRefillWithCCFlow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String messageTwoForRefillWithCCFlow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String productLogoForRefillWithCCFlow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String productLogoForRefillWithCCFlowAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String byopActivateOrderConfirmationMessageAct;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String byopUpgradeOrderConfirmationMessageAct;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String byopPortOrderConfirmationMessageAct;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String activateOrderConfirmationMessageAct;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String upgradeOrderConfirmationMessageAct;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String portOrderConfirmationMessageAct;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String secondLinePinHeading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String componentVersion;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String positionCartSummary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String positionOrderSummary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String cartDetailComponentVersion;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enableEstimateOrder;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String smartPaySummaryText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String smartPayLeasedFrom;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String vasApiFrequency;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String vasApiInterval;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String vasHeaderTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String vasConfirmationMessage1;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String vasConfirmationMessage2;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String vasButtonLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String vasCtaLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String vasProductLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String vasProductLogoAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String homeInternetActivateOrderConfirmationMessageAct;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String homeInternetImagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String vasCategoryId;

	@Override
	public String getComponentVersion() {
		return StringUtils.isNotBlank(componentVersion) ? componentVersion : "v1";
	}

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String homeInternetPlanTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String homeInternetPlanInstructions;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String homeInternetImageForRefillPath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String homeInternetImageForRefillPathAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String dummyCurrentPlanMultilineInstructions;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String dummyCurrentPlanMultilinePinRedeemBy;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String noOfRetryForMultilinePinApi;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String initialTimeIntervalForPinRetry;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String diffInTimeIntervalByForPin;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String rafClickHereLink;

	@Override
	public String getSecondLinePinHeading() {
		return secondLinePinHeading;
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getHeaderTitle() {
		return headerTitle;
	}

	@Override
	public String getByopUpgradeOrderConfirmationMessageAct() {
		return byopUpgradeOrderConfirmationMessageAct;
	}

	@Override
	public String getByopPortOrderConfirmationMessageAct() {
		return byopPortOrderConfirmationMessageAct;
	}

	@Override
	public String getByopActivateOrderConfirmationMessageAct() {
		return byopActivateOrderConfirmationMessageAct;
	}

	@Override
	public String getPositionOrderConfirmation() {
		return positionOrderConfirmation;
	}

	@Override
	public String getUpgradeOrderConfirmationMessageAct() {
		return upgradeOrderConfirmationMessageAct;
	}

	@Override
	public String getPortOrderConfirmationMessageAct() {
		return portOrderConfirmationMessageAct;
	}

	@Override
	public String getActivateOrderConfirmationMessageAct() {
		return activateOrderConfirmationMessageAct;
	}

	@Override
	public String getOrderConfirmationMessage1() {
		return orderConfirmationMessage1;
	}

	@Override
	public String getOrderConfirmationMessage2() {
		return orderConfirmationMessage2;
	}

	@Override
	public String getProductLogo() {
		return DynamicMediaUtils.changeMediaPathToDMPath(productLogo, request.getResourceResolver());
	}

	@Override
	public String getByopProductLogo() {
		return DynamicMediaUtils.changeMediaPathToDMPath(byop25Logo, request.getResourceResolver());
	}
	@Override
	public String getByopProductLogoAltText() {
		return DynamicMediaUtils.changeMediaPathToDMPath(byop25LogoAltText, request.getResourceResolver());
	}	

	@Override
	public String getStByop25EnrollInReawardsLink() {
		return DynamicMediaUtils.changeMediaPathToDMPath(stByop25EnrollInReawardsLink, request.getResourceResolver());
	}

	@Override
	public String getMoreAboutStraightTalkLink() {
		return DynamicMediaUtils.changeMediaPathToDMPath(moreAboutStraightTalkLink, request.getResourceResolver());
	}

	@Override
	public String getPhonesBasePath() {
		return phonesBasePath;
	}

	@Override
	public String getPlansBasePath() {
		return plansBasePath;
	}

	@Override
	public String getPlanDetailsTitle() {
		return planDetailsTitle;
	}

	@Override
	public String getPlanDetailsSubtitle() {
		return planDetailsSubtitle;
	}

	@Override
	public String getProductLogoAltText() {
		return productLogoAltText;
	}

	@Override
	public String getDefaultHeaderTitleAct() {
		return defaultHeaderTitleAct;
	}

	@Override
	public String getDefaultOrderConfirmationMessageAct() {
		return defaultOrderConfirmationMessageAct;
	}

	@Override
	public String getTutorialTitleAct() {
		return tutorialTitleAct;
	}

	@Override
	public String getTutorialTitleActFWAFlow() {
		return tutorialTitleActFWAFlow;
	}

	@Override
	public String getTutorialLinkAct() {
		return tutorialLinkAct;
	}

	@Override
	public String getDefaultProductLogoAct() {
		return DynamicMediaUtils.changeMediaPathToDMPath(defaultProductLogoAct, request.getResourceResolver());
	}

	@Override
	public String getProductLogoAltTextAct() {
		return productLogoAltTextAct;
	}

	@Override
	public String getPlanTitleMappings() {
		String value = CommerceConstants.EMPTY_STRING;
		for (Resource childResource : request.getResource().getChildren()) {
			if (childResource.getName().equals(CommerceConstants.PLAN_TITLE_MAPPING)) {
				value = value + ";" + getMappings(childResource);
			}
		}
		value = value.replaceFirst(ApplicationConstants.SEMICOLON, CommerceConstants.EMPTY_STRING);
		return value;

	}

	private String getMappings(Resource multiResource) {
		String mappings = CommerceConstants.EMPTY_STRING;
		for (Resource resource : multiResource.getChildren()) {
			String mapping = resource.getValueMap().get(CommerceConstants.PLAN_PART_NO, CommerceConstants.EMPTY_STRING)
					.toString() +
					"::"
					+ resource.getValueMap().get(CommerceConstants.PLAN_TITLE, CommerceConstants.EMPTY_STRING)
							.toString()
					+
					ApplicationConstants.TILDA +
					resource.getValueMap().get(CommerceConstants.PLAN_SUBTITLE, CommerceConstants.EMPTY_STRING)
							.toString();
			if (StringUtils.isNotEmpty(mapping)) {
				mappings = mappings + ApplicationConstants.SEMICOLON + mapping;
			}
		}
		if (mappings.startsWith(ApplicationConstants.SEMICOLON)) {
			mappings = mappings.replaceFirst(ApplicationConstants.SEMICOLON, CommerceConstants.EMPTY_STRING);
		}
		return mappings;
	}

	@Override
	public String getHeaderTitleForPromoCodeFlow() {
		return headerTitleForPromoCodeFlow;
	}

	@Override
	public String getMessageOneForPromoCodeFlow() {
		return messageOneForPromoCodeFlow;
	}

	@Override
	public String getMessageTwoForPromoCodeFlow() {
		return messageTwoForPromoCodeFlow;
	}

	@Override
	public String getProductLogoForPromoCodeFlow() {
		return productLogoForPromoCodeFlow;
	}

	@Override
	public String getProductLogoForPromoCodeFlowAltText() {
		return productLogoForPromoCodeFlowAltText;
	}

	@Override
	public String getHeaderTitleForServicePlanFlow() {
		return headerTitleForServicePlanFlow;
	}

	@Override
	public String getMessageOneForServicePlanFlow() {
		return messageOneForServicePlanFlow;
	}

	@Override
	public String getMessageTwoForServicePlanFlow() {
		return messageTwoForServicePlanFlow;
	}

	@Override
	public String getProductLogoForServicePlanFlow() {
		return productLogoForServicePlanFlow;
	}

	@Override
	public String getProductLogoForServicePlanFlowAltText() {
		return productLogoForServicePlanFlowAltText;
	}

	@Override
	public String getCheckStatusLink() {
		return ApplicationUtil.getShortUrl(request.getResourceResolver(), checkStatusLink);
	}

	/**
	 * Get the Image Path of SIM image
	 *
	 * @return String - simImagePath
	 */
	@Override
	public String getSimImagePath() {
		return DynamicMediaUtils.changeMediaPathToDMPath(simImagePath, request.getResourceResolver());
	}

	/**
	 * Get the Image Path of eSIM image
	 *
	 * @return String - esimImagePath
	 */
	@Override
	public String getEsimImagePath() {
		return DynamicMediaUtils.changeMediaPathToDMPath(esimImagePath, request.getResourceResolver());
	}

	@Override
	public String getHeaderTitleForRefillWithPinFlow() {
		return headerTitleForRefillWithPinFlow;
	}

	@Override
	public String getMessageOneForRefillWithPinFlow() {
		return messageOneForRefillWithPinFlow;
	}

	@Override
	public String getMessageTwoForRefillWithPinFlow() {
		return messageTwoForRefillWithPinFlow;
	}

	@Override
	public String getMessageOneForRefillWithPinAddNowFlow() {
		return messageOneForRefillWithPinAddNowFlow;
	}

	@Override
	public String getMessageTwoForRefillWithPinAddNowFlow() {
		return messageTwoForRefillWithPinAddNowFlow;
	}

	@Override
	public String getMyAccountLink() {
		return ApplicationUtil
				.getUrlWithoutDomain(ApplicationUtil.getShortUrl(request.getResourceResolver(), myAccountLink));
	}

	@Override
	public String getServicePlanReserveMessage() {
		return servicePlanReserveMessage;
	}

	@Override
	public String getReserveDisclaimerText() {
		return reserveDisclaimerText;
	}

	@Override
	public String getHeaderTitleForRefillWithCCFlow() {
		return headerTitleForRefillWithCCFlow;
	}

	@Override
	public String getMessageOneForRefillWithCCFlow() {
		return messageOneForRefillWithCCFlow;
	}

	@Override
	public String getMessageTwoForRefillWithCCFlow() {
		return messageTwoForRefillWithCCFlow;
	}

	@Override
	public String getProductLogoForRefillWithCCFlow() {
		return productLogoForRefillWithCCFlow;
	}

	@Override
	public String getProductLogoForRefillWithCCFlowAltText() {
		return productLogoForRefillWithCCFlowAltText;
	}

	@Override
	public String getPositionCartSummary() {
		return positionCartSummary;
	}

	@Override
	public String getPositionOrderSummary() {
		return positionOrderSummary;
	}

	@Override
	public String getCartDetailComponentVersion() {
		return cartDetailComponentVersion;
	}

	@Override
	public String getEnableEstimateOrder() {
		return enableEstimateOrder;
	}

	@Override
	public String getSmartPaySummaryText() {
		return smartPaySummaryText;
	}

	@Override
	public String getSmartPayLeasedFrom() {
		return smartPayLeasedFrom;
	}

	private List<OrderConfirmationVasModel> vasProducts = Collections.emptyList();

	@PostConstruct
	private void initModel() {
		vasProducts = new ArrayList<>();
		if (resource != null) {
			getMultifieldResource();
		}
	}

	private void getMultifieldResource() {
		for (Resource child : resource.getChildren()) {
			Iterator<Resource> it = child.listChildren();
			if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.VAS_PRODUCTS_LIST.equals(child.getName())) {
				setVasProductsData(it, vasProducts);
			}
		}
	}

	private void setVasProductsData(Iterator<Resource> it, List<OrderConfirmationVasModel> vasProducts) {
		while (it.hasNext()) {
			OrderConfirmationVasModel model = new OrderConfirmationVasModel();
			Resource grandChild = it.next();
			model.setVasVendorName(grandChild.getValueMap().get("vasVendorName", String.class));
			model.setVasPartNumber(grandChild.getValueMap().get("vasPartNumber", String.class));
			model.setVasHeaderTitle(grandChild.getValueMap().get("vasHeaderTitle", String.class));
			model.setVasConfirmationMessage1(grandChild.getValueMap().get("vasConfirmationMessage1", String.class));
			model.setVasConfirmationMessage2(grandChild.getValueMap().get("vasConfirmationMessage2", String.class));
			model.setVasButtonLabel(grandChild.getValueMap().get("vasButtonLabel", String.class));
			model.setVasCtaLink(grandChild.getValueMap().get("vasCtaLink", String.class));
			model.setVasProductLogo(grandChild.getValueMap().get("vasProductLogo", String.class));
			model.setVasProductLogoAltText(grandChild.getValueMap().get("vasProductLogoAltText", String.class));
			model.setVasApiFrequency(grandChild.getValueMap().get("vasApiFrequency", String.class));
			model.setVasApiInterval(grandChild.getValueMap().get("vasApiInterval", String.class));

			vasProducts.add(model);
		}
	}

	@Override
	public List<OrderConfirmationVasModel> getVasProducts() {
		return new ArrayList<>(vasProducts);
	}

	@Override
	public String getVasCategoryId() {
		return vasCategoryId;
	}

	@Override
	public String getHomeInternetActivateOrderConfirmationMessageAct() {
		return homeInternetActivateOrderConfirmationMessageAct;
	}

	/**
	 * Get the Image Path of Home Internet image
	 *
	 * @return String - homeInternetImagePath
	 */
	@Override
	public String getHomeInternetImagePath() {
		return DynamicMediaUtils.changeMediaPathToDMPath(homeInternetImagePath, request.getResourceResolver());
	}

	@Override
	public String getHomeInternetPlanTitle() {
		return homeInternetPlanTitle;
	}

	@Override
	public String getHomeInternetPlanInstructions() {
		return homeInternetPlanInstructions;
	}

	@Override
	public String getHomeInternetImageForRefillPath() {
		return homeInternetImageForRefillPath;
	}

	@Override
	public String getHomeInternetImageForRefillPathAltText() {
		return homeInternetImageForRefillPathAltText;
	}

	@Override
	public String getDummyCurrentPlanMultilineInstructions() {
		return dummyCurrentPlanMultilineInstructions;
	}

	@Override
	public String getDummyCurrentPlanMultilinePinRedeemBy() {
		return dummyCurrentPlanMultilinePinRedeemBy;
	}

	@Override
	public String getNoOfRetryForMultilinePinApi() {
		return noOfRetryForMultilinePinApi;
	}

	@Override
	public String getInitialTimeIntervalForPinRetry() {
		return initialTimeIntervalForPinRetry;
	}

	@Override
	public String getDiffInTimeIntervalByForPin() {
		return diffInTimeIntervalByForPin;
	}

	@Override
	public String getRafClickHereLink() {
		return rafClickHereLink;
	}
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String welcomeToStraighttalk;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String getYourPhone;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String bubbleFooterText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String bubbleRafCodePageInfo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String yourPhoneNumberMsg;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String needHelp;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String someConcerns;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String youCanJust;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String textHelp;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String callUs;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String keepYourService;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceRenewal;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceRenewalAutoRefill;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String nextPayment;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String automaticPayment;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String plan;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String straightSavings;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String autoRefillPayMessage;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String payForService;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String payAt;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmart;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String payOnline;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String straightTalkSite;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enroll;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String autoRefill;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String deductPayment;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enrollInAutoRefill;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String freeService;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String letsEnroll;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String yourPlan;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String straight;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String savingsForYou;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String greatPlan;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String realUnlimited;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planActiveForYear;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String bonusCredit;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String newDevice;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String freeRewardsProgram;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String yourAccount;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String keepUpdated;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String paymentSuccessful;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String phoneNumber;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String visitYourAccount;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String signupForRewards;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String purchaseAdditionalDataText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String uteTaxSurchargeInd;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String uteOtherTax;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String uteMandatoryTax;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String powerCycleMessage;
	
	@Override
	public String getWelcomeStraightTalk() {
		return welcomeToStraighttalk;
	}
	@Override
	public String getYourPhone() {
		return getYourPhone;
	}
	@Override
	public String getBubbleFooterText() {
		return bubbleFooterText;
	}
	@Override
	public String getBubbleRafCodePageInfo() {
		return bubbleRafCodePageInfo;
	}

	@Override
	public String getYourPhoneNumberMsg() {
		return yourPhoneNumberMsg;
	}
	@Override
	public String getNeedHelp() {
		return needHelp;
	}
	@Override
	public String getSomeConcerns() {
		return someConcerns;
	}
	@Override
	public String getYouCanJust() {
		return youCanJust;
	}
	@Override
	public String getTextHelp() {
		return textHelp;
	}
	@Override
	public String getCallUs() {
		return callUs;
	}
	@Override
	public String getKeepYourService() {
		return keepYourService;
	}
	@Override
	public String getServiceRenewal() {
		return serviceRenewal;
	}
	@Override
	public String getServiceRenewalAutoRefill() {
		return serviceRenewalAutoRefill;
	}

	@Override
	public String getNextPayment() {
		return nextPayment;
	}

	@Override
	public String getAutomaticPayment() {
		return automaticPayment;
	}
	@Override
	public String getPlan() {
		return plan;
	}
	@Override
	public String getStraightSavings() {
		return straightSavings;
	}
	@Override
	public String getAutoRefillPayMessage() {
		return autoRefillPayMessage;
	}

	@Override
	public String getPayForService() {
		return payForService;
	}
	@Override
	public String getPayAt() {
		return payAt;
	}
	@Override
	public String getWalmart() {
		return walmart;
	}
	@Override
	public String getPayOnline() {
		return payOnline;
	}
	@Override
	public String getStraightTalkSite() {
		return straightTalkSite;
	}
	@Override
	public String getEnroll() {
		return enroll;
	}
	@Override
	public String getAutoRefill() {
		return autoRefill;
	}
	@Override
	public String getDeductPayment() {
		return deductPayment;
	}
	@Override
	public String getEnrollInAutoRefill() {
		return enrollInAutoRefill;
	}
	@Override
	public String getFreeService() {
		return freeService;
	}
	@Override
	public String getLetsEnroll() {
		return letsEnroll;
	}
	@Override
	public String getYourPlan() {
		return yourPlan;
	}
	@Override
	public String getStraight() {
		return straight;
	}
	@Override
	public String getSavingsForYou() {
		return savingsForYou;
	}
	@Override
	public String getGreatPlan() {
		return greatPlan;
	}
	@Override
	public String getRealUnlimited() {
		return realUnlimited;
	}
	@Override
	public String getPlanActiveForYear() {
		return planActiveForYear;
	}
	@Override
	public String getBonusCredit() {
		return bonusCredit;
	}
	@Override
	public String getNewDevice() {
		return newDevice;
	}
	@Override
	public String getFreeRewardsProgram() {
		return freeRewardsProgram;
	}
	@Override
	public String getYourAccount() {
		return yourAccount;
	}
	@Override
	public String getKeepUpdated() {
		return keepUpdated;
	}
	@Override
	public String getPaymentSuccessful() {
		return paymentSuccessful;
	}
	@Override
	public String getPhoneNumber() {
		return phoneNumber;
	}
	@Override
	public String getVisitYourAccount() {
		return visitYourAccount;
	}
	@Override
	public String getSignupForRewards() {
		return signupForRewards;
	}
	@Override
	public String getPurchaseAdditionalDataText() {
		return purchaseAdditionalDataText;
	}
    
	@Override
	public String getUteTaxSurchargeInd() {
		return uteTaxSurchargeInd;
	}

	@Override
	public String getUteOtherTax() {
		return uteOtherTax;
	}

	@Override
	public String getUteMandatoryTax() {
		return uteMandatoryTax;
	}

	@Override
	public String getPowerCycleMessage() {
		return powerCycleMessage;
	}
}
