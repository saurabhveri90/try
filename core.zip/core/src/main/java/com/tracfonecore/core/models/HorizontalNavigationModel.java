package com.tracfonecore.core.models;

import org.apache.sling.api.resource.Resource;
import org.osgi.annotation.versioning.ProviderType;
import com.adobe.cq.export.json.ComponentExporter;

/**
 * 
 * @author HCL
 * Defines the {@code Horizontal Navigation} Sling Model used for the {@code /apps/tracfone-core/components/content/horizontalnavigation} component.
 *
 */

@ProviderType
public interface HorizontalNavigationModel extends ComponentExporter {
    
    /**
     * Get the backgroundcolor
     * @return backgroundcolor
     */
    public Resource getLinks();  
 
	
}
