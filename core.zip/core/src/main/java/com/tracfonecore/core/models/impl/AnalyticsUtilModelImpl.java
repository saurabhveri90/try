/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.AnalyticsUtilModel;
import com.tracfonecore.core.models.ScriptingModel;
import com.tracfonecore.core.utils.ApplicationUtil;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.injectorspecific.RequestAttribute;
import org.apache.sling.models.annotations.injectorspecific.Self;

@Model(adaptables = { Resource.class,
		SlingHttpServletRequest.class }, adapters = {
				AnalyticsUtilModel.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class AnalyticsUtilModelImpl implements AnalyticsUtilModel{

	private static final Logger LOGGER = LoggerFactory.getLogger(AnalyticsUtilModelImpl.class);

	@RequestAttribute
	private String imagePath;

	@RequestAttribute
	private String ctaText;

	@RequestAttribute
	private String componentTitle;

	@RequestAttribute
	private String videoPath;
	
	private String assetId;

	private String ctaAnalyticText;

	private String placementText;

	private String videoAssetId;
	
	private String imageWeberId;
	
	private String videoWeberId;

	@SlingObject
	private ResourceResolver resourceResolver;
	
	@Inject
	@Self
	private ScriptingModel scriptingModel;


	@PostConstruct
	private void initModel() {
		LOGGER.debug("Entering initModel method");
			this.setAssetId(ApplicationUtil.getAssetId(imagePath, resourceResolver,ApplicationConstants.IMAGE));
			this.setVideoAssetId(ApplicationUtil.getAssetId(videoPath, resourceResolver,ApplicationConstants.VIDEO));
			this.setCtaAnalyticText(ApplicationUtil.getLowerCaseWithUnderScore(ctaText));
			this.setPlacementText(ApplicationUtil.getLowerCaseWithUnderScore(componentTitle));
			this.setImageWeberId(fetchAgencyId(imagePath,this.getAssetId()));
			this.setVideoWeberId(fetchAgencyId(videoPath,this.getVideoAssetId()));
		LOGGER.debug("Exiting initModel method");
	}
	/**
	 * <p>
	 * Fetches agency id of asset and if not present then provide default value.
	 * </p>
	 *
	 * @return String - agencyId
	 */
	private String fetchAgencyId(String assetPath,String assetId) {
		LOGGER.debug("Entering fetchAgencyId method");
		String agencyId= ApplicationUtil.getAssetMetaDataValue(assetPath, resourceResolver,ApplicationConstants.WEBER_ID);
		if(StringUtils.isBlank(agencyId) && null != scriptingModel && StringUtils.isNotBlank(assetId)) {			
			agencyId = scriptingModel.getValueFromKey(ApplicationConstants.AGENCY_ID_DEFAULT_SCRIPTING_KEY);	
		}
		LOGGER.debug("Exiting initModel method");
		return agencyId;
	}

	/**
	 * <p>
	 * Fetches assetId of the asset
	 * </p>
	 *
	 * @return String - assetId
	 */
	@Override
	public String getAssetId() {
		return assetId;
	}

	/**
	 * <p>
	 * Sets assetId
	 * </p>
	 *
	 * @param assetId - the assetId to set
	 */
	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	/**
	 * <p>
	 * Fetches ctaAnalyticText
	 * </p>
	 *
	 * @return String - ctaAnalyticText
	 */
	@Override
	public String getCtaAnalyticText() {
		return ctaAnalyticText;
	}

	/**
	 * <p>
	 * Sets ctaAnalyticText
	 * </p>
	 *
	 * @param ctaAnalyticText - the ctaAnalyticText to set
	 */
	public void setCtaAnalyticText(String ctaAnalyticText) {
		this.ctaAnalyticText = ctaAnalyticText;
	}

	/**
	 * <p>
	 * Fetches placementText
	 * </p>
	 *
	 * @return String - placementText
	 */
	@Override
	public String getPlacementText() {
		return placementText;
	}

	/**
	 * <p>
	 * Sets placementText
	 * </p>
	 *
	 * @param placementText - the placementText to set
	 */
	public void setPlacementText(String placementText) {
		this.placementText = placementText;
	}

	/**
	 * <p>
	 * Fetches asset id for the video
	 * </p>
	 *
	 * @return String - videoAssetId
	 */
	@Override
	public String getVideoAssetId() {
		return videoAssetId;
	}

	/**
	 * <p>
	 * Sets videoAssetId
	 * </p>
	 *
	 * @param videoAssetId - the videoAssetId to set
	 */
	public void setVideoAssetId(String videoAssetId) {
		this.videoAssetId = videoAssetId;
	}
	
	/**
	 *<p>Fetches imageWeberId</p>
	 *
	 * @return the imageWeberId
	 */
	@Override
	public String getImageWeberId() {
		return imageWeberId;
	}

	/**
	 * <p>Sets imageWeberId</p>
	 *
	 *@param imageWeberId - the imageWeberId to set
	 */
	public void setImageWeberId(String imageWeberId) {
		this.imageWeberId = imageWeberId;
	}

	/**
	 *<p>Fetches videoWeberId</p>
	 *
	 * @return the videoWeberId
	 */
	@Override
	public String getVideoWeberId() {
		return videoWeberId;
	}

	/**
	 * <p>Sets videoWeberId</p>
	 *
	 *@param videoWeberId - the videoWeberId to set
	 */
	public void setVideoWeberId(String videoWeberId) {
		this.videoWeberId = videoWeberId;
	}
	

}