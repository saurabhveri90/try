package com.tracfonecore.core.beans;


/**
 * <p>Bean to hold link detail</p>
 */
public class BreadcrumbBean {

    private String title;
    private String pageUrl;
    private Boolean active;
    private String doNotFollowLink;

    public String getDoNotFollowLink() {
        return doNotFollowLink;
    }

    public void setDoNotFollowLink(String doNotFollowLink) { this.doNotFollowLink = doNotFollowLink; }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPageUrl() {
        return pageUrl;
    }

    public void setPageUrl(String pageUrl)  { this.pageUrl = pageUrl;  }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

}
