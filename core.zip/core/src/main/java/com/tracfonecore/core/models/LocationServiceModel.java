/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Header} Sling Model used for the {@code /apps/tracfone-core/components/structure/locationservices} component.
 */
public interface LocationServiceModel extends ComponentExporter {

	/**
	 * <p>Fetches locationtext of geolocation</p>
	 *
	 * @return String - locationtext
	 */
	@JsonProperty("locationtext")
	public String getLocationText() ;

	/**
	 * <p>Fetches locationdesc of geolocation</p>
	 *
	 * @return String - locationdesc
	 */
	@JsonProperty("locationdesc")
	public String getLocationDesc();

	/**
	 * <p>Fetches locationlabel of geolocation</p>
	 *
	 * @return String - locationlabel
	 */
	@JsonProperty("locationlabel")
	public String getLocationLabel();

	/**
	 * <p>Fetches errormsg of geolocation</p>
	 *
	 * @return String - errormsg
	 */
	@JsonProperty("errormsg")
	public String getErrorMsg();

	/**
	 * <p>Fetches no-follow value for link</p>
	 *
	 * @return String -  no-follow value
	 */
	@JsonProperty("doNotFollow")
	public String getDoNotFollow();

	/**
	 * <p>Fetches api domain path value</p>
	 *
	 * @return String -  api domain
	 */
	@JsonProperty("apiDomain")
	public String getApiDomain();
	
	/**
	 * <p>Fetches reverse path</p>
	 *
	 * @return String -  reverse path
	 */
	@JsonProperty("reversePath")
	public String getReversePath();
	
	/**
	 * <p>Fetches path</p>
	 *
	 * @return String -  path
	 */
	@JsonProperty(org.apache.sling.api.SlingConstants.PROPERTY_PATH)
	public String getPath();
	
	/**
	 * <p>Fetches api key</p>
	 *
	 * @return String -  apikey
	 */
	@JsonProperty("apiKey")
	public String getApiKey();
	
	/**
	 * <p>Fetches cookie timeout </p>
	 *
	 * @return int - cookie timeout
	 */
	@JsonProperty("cookieTimeout")
	public int getCookieTimeout();

	/**
	 * <p>Privacy Policy Info </p>
	 * 
	 * @return privacyPolicyInfo
	 */
	@JsonProperty("privacyPolicyInfo")
	public String getPrivacyPolicyInfo();

		/**
	 * <p>fetches enterZipMsg of locationservices </p>
	 * 
	 * @return enterZipMsg
	 */
	@JsonProperty("noZipErrorMsg")
	public String getNoZipErrorMsg();
	
	
}
