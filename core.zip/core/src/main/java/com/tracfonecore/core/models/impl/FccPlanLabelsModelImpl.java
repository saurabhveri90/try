/*
 *  Copyright 2023 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.models.FccPlanLabelsModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.BroadbandFactsConfigService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;
import com.tracfonecore.core.constants.ApplicationConstants;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { FccPlanLabelsModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/fccplanlabels", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })

public class FccPlanLabelsModelImpl  extends BaseComponentModelImpl  implements FccPlanLabelsModel {

	@Self
	private SlingHttpServletRequest request;
	
	@Inject
	private Resource resource;
	
	@Inject
	private Page currentPage;
	
	@Inject
	private BroadbandFactsConfigService broadbandFactsConfigService;
	
	@Inject
	private ApplicationConfigService applicationConfigService;

	@Inject
	private TracfoneApiGatewayService tracfoneApiGatewayService;

      @Inject
	private String partno;
	
	@Inject
	private String lang;
	
	@Inject
	private String brand;

	private String cfpath;
	
	private String basePath;

	private String pagetype;

	private static final Logger LOGGER = LoggerFactory.getLogger(FccPlanLabelsModelImpl.class);

	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering initModel method");
		super.initModel();
		
		basePath = getCFBasePath(broadbandFactsConfigService.getFactsContentBasePath());
		basePath = basePath.replace("{language}", getLanguage());
		
		
		ValueMap properties = currentPage.getProperties();
		String propertyId =  (String) properties.getOrDefault("partNo", "");
		cfpath = (!StringUtils.isBlank(propertyId)) ? (basePath + ".facts.json?filter=COMMERCE_PART_NUMBER:" + propertyId) : (basePath + ".facts.json");
            
            if(StringUtils.isBlank(propertyId) && resource.isResourceType("tracfone-core/components/commerce/fccplancardpdf")) {
			cfpath = ApplicationConstants.PATH_DAM + "/" + brand + "/" + lang + "/cf/fcc" + ".facts.json?filter=COMMERCE_PART_NUMBER:" + partno;	
		}
		
		if (resource != null && resource.getParent() != null && resource.getParent().getParent() != null && resource.getParent().getParent().isResourceType("tracfone-core/components/content/fccContainer")) {
			Resource fccContainerResource = resource.getParent().getParent();
			pagetype = fccContainerResource.getValueMap().get("pagetype", String.class);
		} 
	}

	/**
	 * Fetches cfPath
	 * @return cfpath
	 */
	@Override
	public String getCfPath() {
		return cfpath;
	}

	/**
	 * Fetches content fragment folder path
	 * @param pathArray
	 * @return String cfBasePath
	 */
	private String getCFBasePath(String[] pathArray) {
		String brand = CommerceUtil.getBrandValue(currentPage, getHomePageLevel());
		return ConfigurationUtil.getConfigValue(pathArray, brand);
	}
	
	/**
	 * @return homePageLevel
	 */
	private int getHomePageLevel() {
		return applicationConfigService.getHomePageLevel();
	}

	/**
	 * 
	 * @return String - language
	 */
	private String getLanguage() {
		return CommerceUtil.getLanguage(currentPage, applicationConfigService.getHomePageLevel());
	}
	
	/**
	 * @return String - exportedType
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * @return String - pagetype
	 */
	@Override
	public String getPagetype() {
		return pagetype;
	}

	/**
	 * Fetches FccZipcodeFeesApiUrl path
	 * @return String FccZipcodeFeesApiUrl
	 */
	public String getFccZipcodeFeesApiUrl() {
		return broadbandFactsConfigService.getFccZipcodeFeesApiUrl();
	}

	/**
	 * Fetches TaxRequiredStates
	 * @return String TaxRequiredStates
	 */
	public String[] getTaxRequiredStates() {
		return broadbandFactsConfigService.getTaxRequiredStates();
	}
	
	/**
	 * Fetches FccClientId
	 * @return String FccClientId
	 */
	public String getFccClientId() {
		return tracfoneApiGatewayService.getFccApiClientId();
	}

}