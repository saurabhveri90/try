package com.tracfonecore.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Activation Flow Configuration", description = "Activation Flow Configuration")
public @interface ActivationFlowConfig {

	@AttributeDefinition(name = "Activation Primary Flow", description = "Activation Primary Flow")
	String[] activatePrimaryFlow() default { "phones=phoneno" };

	@AttributeDefinition(name = "Activation Secondary Flow", description = "Activation Secondary Flow which will be picked after the primary flow ends")
	String[] activateSecondaryFlow() default { "phones.newact=esn~simcard~paymenttype" };

	@AttributeDefinition(name = "Activation Purchase Flow", description = "Activation Puchase Flow which will be picked after the paymenttype screen")
	String[] activatePuchaseFlow() default { "plan", "extended", "autorefill", "protection" };

	@AttributeDefinition(name = "BYOP Registration Flow", description = "BYOP Registration Flow which will be picked in registration step")
	String[] byopRegistrationFlow() default { "imei", "minwarning", "warning", "simconfirmation", "sim", "devicestatus",
			"devicetype", "shipping" };

	@AttributeDefinition(name = "BYOT Registration Flow", description = "BYOT Registration Flow which will be picked in registration step")
	String[] byotRegistrationFlow() default { "imei", "simcompatible", "sim", "userauth", "paymenttype"};

	@AttributeDefinition(name = "Error code for unqualified HPP", description = "Enter the error code for service PIN which is not eligible because of HPP status  ")
	String errorCodeUnqualifiedHPP() default "816";

	@AttributeDefinition(name = "Resource Managment API Projection Value - Activation ", description = "Projection Value for Resource Management API in Activation")
	String activationResourceMgmtProjection() default "basic-info,account,specifications,supporting-resources,notifications,plans,secondary-info,enrollments,supplementary";

	@AttributeDefinition(name = "ESN Activated Status Code", description = "Status Code for ESN already Activated")
	String esnActivatedStatusCode() default "52";

	@AttributeDefinition(name = "ESN Stolen Status Code", description = "Status Code for ESN stolen")
	String esnStolenStatusCode() default "53";

	@AttributeDefinition(name = "ESN Risk Check Status Code", description = "Status Code for Risk Assessment Check of ESN")
	String esnRiskCheckStatusCode() default "56";

	@AttributeDefinition(name = "Activation Progress Bar percentage", description = "Activation Progress bar perventage")
	String[] progressBarSteps() default {
			"phones=phoneno:10;verify:15;collectcode:15;esn:20;sim:30;zip:30;carrier:45;paymenttype:50;plan:50;extended:50;autorefill:50;hpp:60;login:70;mobileprotect:80;activation:90;" };

	@AttributeDefinition(name = "Resource Managment API Basic Projection Value - Activation ", description = "Basic Projection Value for Resource Management API in Activation")
	String activationResourceMgmtBasicProjection() default "basic-info,supplementary,account,supporting-resources,plans";

	@AttributeDefinition(name = "ESN Used Line Status Code", description = "Status Code for Used Line Check of ESN")
	String esnUsedLineStatusCode() default "51";

	@AttributeDefinition(name = "ESN Past Due Status Code", description = "Status Code for Past Due Check of ESN")
	String esnPastDueStatusCode() default "54";

	@AttributeDefinition(name = "Hard coded value of Zip Code", description = "Hard coded value of Zip Code for service qualification api call in Internal/External/Upgrade flow")
	String zipHardCoded() default "33178";

	@AttributeDefinition(name = "ESN New Status Code", description = "Status Code for New Check of ESN")
	String esnNewStatusCode() default "50";

	@AttributeDefinition(name = "ESN Refurbished Status Code", description = "Status Code for Refurbished Check of ESN")
	String esnRefurbishedStatusCode() default "150";

	@AttributeDefinition(name = "Resource Managment API Projection for BYOP Registration", description = "Projection Value for Resource Management API in BYOP Registration")
	String byopRegistrationResourceMgmtProjection() default "basic-info,specifications,supporting-resources";

	@AttributeDefinition(name = "Resource Managment API Projection for BYOT Registration", description = "Projection Value for Resource Management API in BYOT Registration")
	String byotRegistrationResourceMgmtProjection() default "basic-info,specifications,supporting-resources";

	@AttributeDefinition(name = "Activation Upgrade Success Scenarios", description = "Activation Upgrade Success Scenarios")
	String[] upgradeSuccessScenarios();

	@AttributeDefinition(name = "Upgrade scenarios where account ids needs to be checked", description = "Activation Upgrade scenarios where account ids needs to be checked")
	String[] upgradeCheckObjScenarios();

	@AttributeDefinition(name = "Upgrade error scenarios", description = "Activation Upgrade error scenarios")
	String[] upgradeErrorScenarios();

	@AttributeDefinition(name = "BYOP Registration - Standalone Entry Step", description = "First Step name for BYOP Standalone path")
	String byopStandaloneRegStep() default "serviceprovider";

	@AttributeDefinition(name = "BYOT Registration - Standalone Entry Step", description = "First Step name for BYOT Standalone path")
	String byotStandaloneRegStep() default "serviceprovider";

	@AttributeDefinition(name = "HPP Enrollment Resource Mgnt Projection", description = "HPP Enrollment Resource Mgnt Projection")
	String hppEnrollmentResourceMgmtProjection() default "enrollments";

	@AttributeDefinition(name = "Skip Device Type Screen", description = "Skip Device Type Screen Flag")
	String[] skipDeviceTypeScreen() default { "STRAIGHT_TALK:false", "TRACFONE:true" };

	@AttributeDefinition(name = "Enable or Disable eSIM", description = "Enable or Disable eSIM")
	String[] enableEsim() default { "STRAIGHT_TALK:false", "TRACFONE:true", "TOTAL_WIRELESS:true" };

	@AttributeDefinition(name = "Skip Select Validate", description = "Skips Select Validate")
	String[] skipSelectValidate() default { "STRAIGHT_TALK:false", "TRACFONE:false", "TOTAL_WIRELESS:true" };

	@AttributeDefinition(name = "Fetch User Tickets", description = "Fetch user trouble tickets for logged in users")
	String[] fetchUserTroubleTickets() default { "STRAIGHT_TALK:false", "TRACFONE:false", "TOTAL_WIRELESS:true" };

	@AttributeDefinition(name = "check eligibility call type", description = "check eligibility call type")
	String[] checkEligibilityCallType() default { "STRAIGHT_TALK:rebrand", "TRACFONE:rebrand", "TOTAL_WIRELESS:byop" };

	@AttributeDefinition(name = "Default service provider for BYOP", description = "Default service provider for BYOP")
	String[] defaultServiceProvider() default { "STRAIGHT_TALK:straighttalk~ST", "TRACFONE:tracfone~TF","TOTAL_WIRELESS:verizon~VZW" };

	@AttributeDefinition(name = "Error code for Invalid PIN", description = "Enter the API error code for Invaild PIN.")
	String errorCodeInvalidPin() default "16529";

	@AttributeDefinition(name = "Enable or Disable eSIM for External Ports", description = "Enable or Disable eSIM for External Ports")
	String[] enableEsimExternalPorts() default { "STRAIGHT_TALK:false", "TRACFONE:true", "TOTAL_WIRELESS:true" };

	@AttributeDefinition(name = "Config to enable, BYOP compatibility with Verizon carrier first", description = "Checks BYOP eligibility with VZW carrier first, if not successful, check will happen with TMO")
	String[] enableVZWFirst() default { "STRAIGHT_TALK:true", "TRACFONE:true" };

	@AttributeDefinition(name = "Disable Branded Sim Selection Page", description = "Disable Branded Sim Selection Page")
	String[] disableBrandedSimSelection() default { "STRAIGHT_TALK:true", "TRACFONE:false", "TOTAL_WIRELESS:true" };

	@AttributeDefinition(name = "Resource Managment API Projection Value - BYOP-$25 ", description = "Projection Value for Resource Management API in BYOP-$25")
	String byopResourceMgmtProjection() default "account,basic-info,specifications,supporting-resources";

	@AttributeDefinition(name = "Enable BYOP Dual IMEI Page", description = "Enable BYOP Dual IMEI Page")
	String[] enableByopDualImei() default { "STRAIGHT_TALK:true", "TRACFONE:false", "TOTAL_WIRELESS:false" };

	@AttributeDefinition(name = "Enable Promo Eligibility", description = "Enable Promo Eligibility")
	String[] enablePromoEligibility() default { "STRAIGHT_TALK:true", "TRACFONE:false", "TOTAL_WIRELESS:false" };

	@AttributeDefinition(name = "Promo Eligibility 25 dollar PartNumber", description = "Promo Eligibility 25 dollar PartNumber")
	String promoEligibility25PartNumber() default "STU00025_P";

	@AttributeDefinition(name = "Skip Collect Code", description = "Skips Collect Code")
	String[] skipCollectCodeProvider() default { "STRAIGHT_TALK:true", "TRACFONE:true", "TOTAL_WIRELESS:false" };
	
}
