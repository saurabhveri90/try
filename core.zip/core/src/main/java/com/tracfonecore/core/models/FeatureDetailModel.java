/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.LinkBean;

import java.util.List;
import java.util.Map;

/**
 * Defines the {@code Column-Control} Sling Model used for the {@code /apps/tracfone-core/components/content/card} component.
 */
public interface FeatureDetailModel extends ComponentExporter {
	
	/**
	 * <p>Fetches dispaly type for content</p>
	 * 
	 * @return String - dispaly type
	 */
		@JsonProperty("displayType")
	public String getDisplayType();
	
	/**
     * <p>Fetches title for the section</p>
     *
     * @return String - title for the section
     */
    @JsonProperty("title")
    public String getTitle();
    
 	/**
	 * <p>Fetches all the multi-links</p>
	 *
	 * @return String - all the multi-links
	 */
	@JsonProperty("links")
	public List<LinkBean> getMultilinks();
	/**
	 * <p>Fetches ctaTextShowMore</p>
	 *
	 * @return String - ctaTextShowMore
	 */
	@JsonProperty("ctaTextShowMore")
	public String getCtaTextShowMore();
	/**
	 * <p>Fetches ctaTextShowLess</p>
	 *
	 * @return String - ctaTextShowLess
	 */
	@JsonProperty("ctaTextShowLess")
	public String getCtaTextShowLess();
	
	 /**
     * <p>Fetches exported items</p>
     * 
     * @return getexportertype
     */
    public Map<String, ? extends ComponentExporter> getItems();

}
