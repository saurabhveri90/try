/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;

/**
 * <p>Defines bean to hold apps detail</p>
 */
public class AppsCardsBean {

	private String appName;
	private String appDetails;
	private String appLogoFileReference;
	private String appLogoAltText;
	private String appLogoAssetId;
	private String appLogoAssetAgencyId;
	
	private String appStoreLogoFileReference;
	private String appStoreLogoAltText;
	private String appStoreLogoAssetId;
	private String appStoreLogoAssetAgencyId;
	private String appStoreLogoLink;
	private String openNewTabAppStoreLink;
	private String doNotFollowAppStore;
	
	private String playStoreLogoFileReference;
	private String playStoreLogoAltText;
	private String playStoreLogoAssetId;
	private String playStoreLogoAssetAgencyId;
	private String playStoreLogoLink;
	private String openNewTabPlayStoreLink;
	private String doNotFollowPlayStore;
	
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getAppDetails() {
		return appDetails;
	}
	public void setAppDetails(String appDetails) {
		this.appDetails = appDetails;
	}
	public String getAppLogoFileReference() {
		return appLogoFileReference;
	}
	public void setAppLogoFileReference(String appLogoFileReference) {
		this.appLogoFileReference = appLogoFileReference;
	}
	public String getAppLogoAltText() {
		return appLogoAltText;
	}
	public void setAppLogoAltText(String appLogoAltText) {
		this.appLogoAltText = appLogoAltText;
	}
	public String getAppStoreLogoFileReference() {
		return appStoreLogoFileReference;
	}
	public void setAppStoreLogoFileReference(String appStoreLogoFileReference) {
		this.appStoreLogoFileReference = appStoreLogoFileReference;
	}
	public String getAppStoreLogoAltText() {
		return appStoreLogoAltText;
	}
	public void setAppStoreLogoAltText(String appStoreLogoAltText) {
		this.appStoreLogoAltText = appStoreLogoAltText;
	}
	public String getAppStoreLogoLink() {
		return appStoreLogoLink;
	}
	public void setAppStoreLogoLink(String appStoreLogoLink) {
		this.appStoreLogoLink = appStoreLogoLink;
	}
	public String getOpenNewTabAppStoreLink() {
		return openNewTabAppStoreLink;
	}
	public void setOpenNewTabAppStoreLink(String openNewTabAppStoreLink) {
		this.openNewTabAppStoreLink = openNewTabAppStoreLink;
	}
	public String getDoNotFollowAppStore() {
		return doNotFollowAppStore;
	}
	public void setDoNotFollowAppStore(String doNotFollowAppStore) {
		this.doNotFollowAppStore = doNotFollowAppStore;
	}
	public String getPlayStoreLogoFileReference() {
		return playStoreLogoFileReference;
	}
	public void setPlayStoreLogoFileReference(String playStoreLogoFileReference) {
		this.playStoreLogoFileReference = playStoreLogoFileReference;
	}
	public String getPlayStoreLogoAltText() {
		return playStoreLogoAltText;
	}
	public void setPlayStoreLogoAltText(String playStoreLogoAltText) {
		this.playStoreLogoAltText = playStoreLogoAltText;
	}
	public String getPlayStoreLogoLink() {
		return playStoreLogoLink;
	}
	public void setPlayStoreLogoLink(String playStoreLogoLink) {
		this.playStoreLogoLink = playStoreLogoLink;
	}
	public String getDoNotFollowPlayStore() {
		return doNotFollowPlayStore;
	}
	public void setDoNotFollowPlayStore(String doNotFollowPlayStore) {
		this.doNotFollowPlayStore = doNotFollowPlayStore;
	}
	public String getOpenNewTabPlayStoreLink() {
		return openNewTabPlayStoreLink;
	}
	public void setOpenNewTabPlayStoreLink(String openNewTabPlayStoreLink) {
		this.openNewTabPlayStoreLink = openNewTabPlayStoreLink;
	}

	public String getAppLogoAssetId() {
		return appLogoAssetId;
	}
	public void setAppLogoAssetId(String appLogoAssetId) {
		this.appLogoAssetId = appLogoAssetId;
	}

	public String getAppLogoAssetAgencyId() {
		return appLogoAssetAgencyId;
	}
	public void setAppLogoAssetAgencyId(String appLogoAssetAgencyId) {
		this.appLogoAssetAgencyId = appLogoAssetAgencyId;
	}

	public String getAppStoreLogoAssetId() {
		return appStoreLogoAssetId;
	}
	public void setAppStoreLogoAssetId(String appStoreLogoAssetId) {
		this.appStoreLogoAssetId = appStoreLogoAssetId;
	}

	public String getAppStoreLogoAssetAgencyId() {
		return appStoreLogoAssetAgencyId;
	}
	public void setAppStoreLogoAssetAgencyId(String appStoreLogoAssetAgencyId) {
		this.appStoreLogoAssetAgencyId = appStoreLogoAssetAgencyId;
	}

	public String getPlayStoreLogoAssetId() {
		return playStoreLogoAssetId;
	}
	public void setPlayStoreLogoAssetId(String playStoreLogoAssetId) {
		this.playStoreLogoAssetId = playStoreLogoAssetId;
	}

	public String getPlayStoreLogoAssetAgencyId() {
		return playStoreLogoAssetAgencyId;
	}
	public void setPlayStoreLogoAssetAgencyId(String playStoreLogoAssetAgencyId) {
		this.playStoreLogoAssetAgencyId = playStoreLogoAssetAgencyId;
	}
	
}
