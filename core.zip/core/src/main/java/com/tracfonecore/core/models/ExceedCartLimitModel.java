/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;

public interface ExceedCartLimitModel extends ComponentExporter {


   
}
