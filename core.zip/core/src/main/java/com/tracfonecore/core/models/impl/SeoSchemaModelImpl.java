/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import java.util.Iterator;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.time.DurationFormatUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.RequestAttribute;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.via.ResourceSuperType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.DamConstants;
import com.day.cq.dam.scene7.api.constants.Scene7Constants;
import com.day.cq.wcm.api.Page;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.tracfonecore.core.beans.BreadcrumbBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.SchemaOrgConstants;
import com.tracfonecore.core.models.SeoSchema;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import com.tracfonecore.core.utils.SeoSchemaOrgUtil;

@Model(adaptables = { Resource.class,
		SlingHttpServletRequest.class }, adapters = {
				SeoSchema.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SeoSchemaModelImpl implements SeoSchema{

	private static final Logger LOGGER = LoggerFactory.getLogger(SeoSchemaModelImpl.class);

	@SlingObject
	private Resource resource;

	@SlingObject
	private ResourceResolver resourceResolver;

	@Inject
	private SlingHttpServletRequest request;

	@Inject
	private Page currentPage;

	@Inject
	@Via(type = ResourceSuperType.class)
	private String seotype;

	@Inject
	@Via(type = ResourceSuperType.class)
	private String seoPageName;

	@Inject
	@Via(type = ResourceSuperType.class)
	private String legalName;

	@Inject
	@Via(type = ResourceSuperType.class)
	private String logoUrl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String isItNotFaq;

	private String homePageSchema;

	private String speakableMarkUp;

	private String faqPageSchema;

	private String domainName = "";
	
	@RequestAttribute
	private String videoPath;
	
	@RequestAttribute
	private String videoThumbnailPath;

	private String videoObjSchema;

	//constants
	private static final String LANDING_PAGE = "landing-page";
	private static final String CONTENT_PAGE = "content-page";
	private static final String NAME = "name";
	private static final String LEGAL_NAME = "legalName";
	private static final String DESCRIPTION = "description";
	private static final String URL = "url";
	private static final String LOGO = "logo";
	private static final String SAME_AS = "sameAs";
	private static final String ORGANIZATION = "Organization";
	private static final String WEBPAGE = "WebPage";
	private static final String FAQPAGE = "FAQPage";
	private static final String SPEAKABLE_HEAD_TITLE = "/html/head/title";
	private static final String SPEAKABLE_HEAD_DESC = "/html/head/meta[@name='description']/@content";
	private static final String SPEAKABLE_SPECIFICATION = "SpeakableSpecification";
	private static final String SPEAKABLE = "speakable";
	private static final String XPATH = "xpath";
	private static final String SCHEMA_URL = "https://schema.org";
	private static final String CONTEXT = "@context";
	private static final String TYPE = "@type";
	private static final String MAIN_ENTITY = "mainEntity";
	private static final String TEXT = "text";
	private static final String ACCEPTED_ANSWER = "acceptedAnswer";
	private static final String QUESTION = "Question";
	private static final String ANSWER = "Answer";
	private static final String RTE_TEXT = "rteText";
	private static final String PANEL_TITLE = "cq:panelTitle";
	private static final String RTE = "/rte";
	private static final String HOME_PAGE = "homepage";
	private static final String CONTENT = "content";
	private static final String SOCIAL_ACCOUNT_URL = "socialAccountUrl";

	@PostConstruct
	private void initModel() {
		
		LOGGER.debug("Entering SeoSchemaImpl initModel method");

		domainName = ApplicationUtil.getDomainNameinURL(request.getRequestURL().toString());

			if(seotype!= null)
			{
				if(LANDING_PAGE.equals(currentPage.getTemplate().getName()) && seotype.equals(HOME_PAGE))
				{						
					this.setHomePageSchema(getHomePageSchemaData(domainName,true));
				}
				else if(CONTENT_PAGE.equals(currentPage.getTemplate().getName()) && seotype.equals(CONTENT))
				{
					this.setHomePageSchema(getHomePageSchemaData(domainName,false));
				}				
			}
			
			if(videoPath != null && videoThumbnailPath != null) {
				this.setVideoObjSchema(SeoSchemaOrgUtil.getVideoObjSchemaData(videoPath, videoThumbnailPath, resourceResolver));
			}
			
			this.setSpeakableMarkUp(getSpeakableMarkUpData());
			if(!ApplicationConstants.TRUE.equals(isItNotFaq))
			{
				this.setFaqPageSchema(createFaqSchemaData());
			}
			
			LOGGER.debug("Exiting	 SeoSchemaImpl initModel method");
			
	}

	/**
	 * 
	 * <p>This method is used to genarate Schema structured data for HOmepage & content page</p>
	 * @param domainName
	 * @param setAllParam
	 * @return Home page Schema structure
	 */
	private String getHomePageSchemaData(String domainName, boolean setAllParam)
	{
		LOGGER.debug("Entering getHomePageSchemaData method");

		JsonObject jsonObject = null;
		Resource localResource = null;
		String pagePath = currentPage.getPath();
		JsonArray jsonArray = new JsonArray();

		jsonObject = new JsonObject();

		localResource = getResource(pagePath);

		if(localResource != null)
		{
			Iterator<Resource> it = localResource.listChildren();

			while (it.hasNext()) {
				Resource child = (Resource) it.next();
				jsonArray.add(child.getValueMap().get(SOCIAL_ACCOUNT_URL,String.class));
			}
		}
		jsonObject.addProperty(CONTEXT, SCHEMA_URL);

		jsonObject.addProperty(TYPE, ORGANIZATION);				
		jsonObject.addProperty(NAME, seoPageName);
		if(setAllParam)
			jsonObject.addProperty(LEGAL_NAME.toLowerCase(), legalName);
		jsonObject.addProperty(DESCRIPTION, currentPage.getDescription());
		jsonObject.addProperty(URL, getShortUrl(request.getRequestURI().toString()));

		if(ApplicationUtil.isInternalLink(logoUrl))
			jsonObject.addProperty(LOGO, domainName +logoUrl);
		else
			jsonObject.addProperty(LOGO, logoUrl);
		if(setAllParam)
			jsonObject.add(SAME_AS, jsonArray);


		LOGGER.debug("Exiting getHomePageSchemaData method");
		return jsonObject.toString();
	}

	/**
	 * <p>This method is used to generate Speakable Mark Json-LD data for a page<p>
	 *
	 * @return Speakable mark up 
	 */
	private String getSpeakableMarkUpData()
	{
		LOGGER.debug("Entering getSpeakableMarkUpData method");
		JsonObject jsonObject = null;

		JsonArray jsonArray = new JsonArray();
		jsonObject = new JsonObject();

		jsonObject.addProperty(CONTEXT, SCHEMA_URL);
		jsonObject.addProperty(TYPE, WEBPAGE);
		jsonObject.addProperty(NAME, currentPage.getTitle());
		jsonArray.add(SPEAKABLE_HEAD_TITLE);
		jsonArray.add(SPEAKABLE_HEAD_DESC);

		JsonObject childJsonObject = new JsonObject();

		childJsonObject.addProperty(TYPE, SPEAKABLE_SPECIFICATION);
		childJsonObject.add(XPATH, jsonArray);

		jsonObject.add(SPEAKABLE, childJsonObject);
		jsonObject.addProperty(URL, getShortUrl(request.getRequestURI().toString()));

		LOGGER.debug("Exiting getSpeakableMarkUpData method");
		return jsonObject.toString();
	}

	/**
	 * <p> This method is used to generate the Json-LD data for FAQ page schema<p>
	 * @return Json schema for FAQ page
	 */
	private String createFaqSchemaData()
	{
		LOGGER.debug("Entering createFaqSchemaData method");
		JsonObject jsonObject = null;

		JsonArray jsonArray = new JsonArray();
		jsonObject = new JsonObject();

		jsonObject.addProperty(CONTEXT, SCHEMA_URL);
		jsonObject.addProperty(TYPE, FAQPAGE);

		Iterator<Resource> it = resource.listChildren();

		while (it.hasNext()) {

			JsonObject childJsonObject = new JsonObject();
			Resource child = it.next();
			if (child.getValueMap().get(ApplicationConstants.RESOURCE_TYPE,String.class) != null
					&& child.getValueMap().get(ApplicationConstants.RESOURCE_TYPE,String.class).contains(RTE)) 
			{
				if (child.getValueMap().get(PANEL_TITLE,String.class) !=null) {
					childJsonObject.addProperty(TYPE, QUESTION);
					childJsonObject.addProperty(NAME, child.getValueMap().get(PANEL_TITLE,String.class));
				}


				if (child.getValueMap().get(RTE_TEXT,String.class) !=null) {
					JsonObject answerJsonObject = new JsonObject();
					answerJsonObject.addProperty(TYPE, ANSWER);
					answerJsonObject.addProperty(TEXT,child.getValueMap().get(RTE_TEXT,String.class));
					childJsonObject.add(ACCEPTED_ANSWER, answerJsonObject);
				}
			}
			jsonArray.add(childJsonObject);
		}
		jsonObject.add(MAIN_ENTITY, jsonArray);

		LOGGER.debug("Exiting createFaqSchemaData method");
		return jsonObject.toString();
	}
	
	/**
	 * <p>Get resource from path</p>
	 * @param pagePath- page Path
	 * @return
	 */
	private Resource getResource(String pagePath)
	{
		LOGGER.debug("Entering getResource method");
		Resource socialResource = null;

		if(pagePath!=null && pagePath.indexOf('.') !=-1)
		{
			socialResource = resourceResolver.getResource(
					pagePath.substring(0, pagePath.lastIndexOf('.')) + ApplicationConstants.JCR_CONTENT_SOCIAL_ACCOUNT);
		}
		else
		{
			socialResource = resourceResolver.getResource(pagePath + ApplicationConstants.JCR_CONTENT_SOCIAL_ACCOUNT);
		}
		LOGGER.debug("Exiting getResource method");
		return socialResource;
	}
	/**
	 * This method is used to create short url from absolute url
	 * @param url
	 * @return
	 */
	private String getShortUrl(String url)
	{
		String shortUrl = "";
		if(url!=null && url.indexOf(ApplicationConstants.HTML_EXTENSION) == -1)
		{
			url = url + ApplicationConstants.HTML_EXTENSION;
		}
		shortUrl = request.getResourceResolver().map(url);
		return shortUrl;
	}

	@Override
	public String getHomePageSchema() {
		return homePageSchema;
	}

	@Override
	public void setHomePageSchema(String homePageSchema) {
		this.homePageSchema = homePageSchema;
	}

	@Override
	public String getSpeakableMarkUp() {
		return speakableMarkUp;
	}

	@Override
	public void setSpeakableMarkUp(String speakableMarkUp) {
		this.speakableMarkUp = speakableMarkUp;
	}

	@Override
	public String getIsItNotFaq() {
		return isItNotFaq;
	}

	@Override
	public String getFaqPageSchema() {
		return faqPageSchema;
	}

	@Override
	public void setIsItNotFaq(String isItNotFaq) {
		this.isItNotFaq = isItNotFaq;
	}

	@Override
	public void setFaqPageSchema(String faqPageSchema) {
		this.faqPageSchema = faqPageSchema;
	}

	@Override
	public String getVideoObjSchema() {
		return this.videoObjSchema;
	}

	@Override
	public void setVideoObjSchema(String videoObjSchema) {
		this.videoObjSchema = videoObjSchema;
		
	}

}
