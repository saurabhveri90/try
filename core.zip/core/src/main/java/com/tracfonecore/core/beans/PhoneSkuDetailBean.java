package com.tracfonecore.core.beans;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>Defines bean to hold link detail</p>
 */
public class PhoneSkuDetailBean {
    /*
     *  Copyright 2019 HCL Technologies Ltd.
     *
     *
     */

	private String id;
    private List<String> mediaPaths;
    private String skusSelection;
    private String color;
    private String hexaColor;


    /**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
     *<p>Fetches mediaPath</p>
     *
     * @return String: the mediaPath
     */
    public List<String> getMediaPaths() {
    	return new ArrayList<>(mediaPaths);
    }
    /**
     * <p>Sets mediaPaths</p>
     *
     *@param mediaPaths - the mediaPaths to set
     */
    public void setMediaPaths(List<String> mediaPaths) {
        this.mediaPaths = new ArrayList<>(mediaPaths);
    }

    /**
     * <p>Gets skusSelection</p>
     *
     */

    public String getSkusSelection() {
        return skusSelection;
    }

    /**
     * <p>Sets skusSelection</p>
     *
     * @param skusSelection - the skusSelection to set
     */
    public void setSkusSelection(String skusSelection) {
        this.skusSelection = skusSelection;
    }
    
    /**
	 * @return the color
	 */
	public String getColor() {
		return color;
	}
	
	/**
	 * @param color the color to set
	 */
	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * @return the hexaColor
	 */
	public String getHexaColor() {
		return hexaColor;
	}
	/**
	 * @param hexaColor the hexaColor to set
	 */
	public void setHexaColor(String hexaColor) {
		this.hexaColor = hexaColor;
	}
    
}
