package com.tracfonecore.core.models.impl;

import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;

import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.tracfonecore.core.models.CoverageMapModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.constants.ApplicationConstants;

import java.util.Iterator;
import javax.annotation.PostConstruct;
/**
 * Coverage Map Model Implementation
 *
 */
@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CoverageMapModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/coveragemap", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })

public class CoverageMapModelImpl implements CoverageMapModel {


	@Self
	private SlingHttpServletRequest request;

	@Inject
	private Resource resource;
	
	@Inject
	private Page currentPage;
	
	@Inject
	private ApplicationConfigService applicationConfigService;
	
	@Inject
	private TracfoneApiGatewayService tracfoneApiService;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepOneTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepOneSubTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepOneContinueButtonText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepOneExisitngCustomerLabelText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepTwoTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepTwoSubTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepTwoContinueButtonText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepTwoNewCustomerLabelText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepThreeTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepThreeSubTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepThreeBuyingPhoneText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepThreeBringOwnPhoneNext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepThreeButtonContinue;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String categoryIdPhones;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String phonesPlpPath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String categoryIdSims;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String simsPlpPath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String disclaimer;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepThreeBuyingPhoneHelpText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepThreeBringOwnPhoneHelpText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceProviderModalLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceProviderModalName;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String showCityState;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepOneSummary;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepOneFileReference;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepOneMediaAlignment;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepTwoSummary;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepTwoFileReference;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepTwoMediaAlignment;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hideBuyPhoneHelpText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepThreeBuyingPhoneSlideTitle;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepThreeBuyingPhoneSlideDesc;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String deviceNameHelpModalLabel;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String deviceNameHelpModalName;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String buyNewPhoneButtonContinue;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hideBringOwnPhoneHelpText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepThreeBringOwnPhoneSlideTitle;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepThreeBringOwnPhoneSlideDesc;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String bringOwnPhoneButtonContinue;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepFourTitle;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String restartButtonLabel;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String phoneBannerTitle;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String phoneBannerSummary;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String simBannerTitle;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String simBannerSummary;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enableChangeDevice;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enableChangeServiceProvider;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enableChangeLocation;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enableChangePhoneNo;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepThreeTextSlideTitle;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stepThreeTextSlideDesc;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String showTextSlide;

	private String phonesPlpShortUrl;

	private String simsPlpShortUrl;

	private String serviceProviderModalId;

	private String serviceProviderList;
	
	private String deviceHelpModalId;

	private JsonArray jsonArray;

	private static final Logger LOGGER = LoggerFactory.getLogger(CoverageMapModelImpl.class);

	//Constants
	private static final String OPTIONS = "options";
	private static final String NAME = "name";
	private static final String ID = "id";
	private static final String DISPLAY_NAME = "displayName";
	private static final String SERVICE_PROVIDER = "serviceProvider";
	public static final String PHONES_PAGE_PATH ="phonesPagePath";
	public static final String PHONES_SIM_PAGE_PATH ="phoneSimPagePath";

	@PostConstruct
	private void initModel() {
		this.setServiceProviderModalId(ApplicationUtil.getLowerCaseWithHyphen(serviceProviderModalName) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL);
		
		this.setDeviceHelpModalId(ApplicationUtil.getLowerCaseWithHyphen(deviceNameHelpModalName) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL);

		jsonArray = new JsonArray();
		for (Resource child : resource.getChildren()) {
			if(OPTIONS.equals(child.getName()))
			{
				Iterator<Resource> it = child.listChildren();
				setMultiFieldItems(it, jsonArray);
			}
		}

		this.setServiceProviderList(jsonArray.toString());
	}

	/**
	 * <p>Populates a list with all the multi-links</p>
	 * 
	 * @param it - iterator of the parent node
	 * @param jsonArray - Json Array in which the carrier list data needs to be set
	 */
	private void setMultiFieldItems(Iterator<Resource> it, JsonArray jsonArray) {
		LOGGER.debug("Entering setMultiFieldItems method");
		JsonObject jsonObject = null;
		while (it.hasNext()) {
			jsonObject = new JsonObject();
			Resource grandChild = it.next();

			jsonObject.addProperty(NAME, grandChild.getValueMap().get(DISPLAY_NAME, String.class));
			jsonObject.addProperty(ID, grandChild.getValueMap().get(SERVICE_PROVIDER, String.class));

			jsonArray.add(jsonObject);
		}

		LOGGER.debug("Exiting setMultiFieldItems method ");
	}

	@Override
	public String getStepOneTitle() {

		return stepOneTitle;
	}

	@Override
	public String getStepOneSubTitle() {

		return stepOneSubTitle;
	}

	@Override
	public String getStepOneContinueButtonText() {

		return stepOneContinueButtonText;
	}

	@Override
	public String getStepOneExisitngCustomerLabelText() {

		return stepOneExisitngCustomerLabelText;
	}

	@Override
	public String getStepTwoTitle() {

		return stepTwoTitle;
	}

	@Override
	public String getStepTwoSubTitle() {

		return stepTwoSubTitle;
	}

	@Override
	public String getStepTwoContinueButtonText() {

		return stepTwoContinueButtonText;
	}

	@Override
	public String getStepTwoNewCustomerLabelText() {

		return stepTwoNewCustomerLabelText;
	}


	@Override
	public String getStepThreeTitle() {

		return stepThreeTitle;
	}

	@Override
	public String getStepThreeSubTitle() {

		return stepThreeSubTitle;
	}

	@Override
	public String getStepThreeBuyingPhoneText() {

		return stepThreeBuyingPhoneText;
	}

	@Override
	public String getStepThreeBringOwnPhoneNext() {

		return stepThreeBringOwnPhoneNext;
	}

	@Override
	public String getStepThreeButtonContinue() {

		return stepThreeButtonContinue;
	}

	@Override
	public String getCategoryIdPhones() {
		return categoryIdPhones;
	}

	@Override
	public String getCategoryIdSims() {
		return categoryIdSims;
	}

	@Override
	public String getPhonesPlpPath() {
		String phonePlpPageJsonPath = CommerceUtil.getPagePropertyValue(currentPage, applicationConfigService.getHomePageLevel(), PHONES_PAGE_PATH).toString();
		return phonePlpPageJsonPath;
	}

	@Override
	public String getSimsPlpPath() {
		String simPlpPageJsonPath = CommerceUtil.getPagePropertyValue(currentPage, applicationConfigService.getHomePageLevel(), PHONES_SIM_PAGE_PATH).toString();
		return simPlpPageJsonPath;
	}

	@Override
	public String getPhonesPlpShortUrl() {
		return ApplicationUtil.getShortUrl(request.getResourceResolver(), phonesPlpPath);
	}

	@Override
	public String getSimsPlpShortUrl() {
		return ApplicationUtil.getShortUrl(request.getResourceResolver(), simsPlpPath);
	}

	@Override
	public String getDisclaimer(){
		return disclaimer;
	}

	@Override
	public String getStepThreeBuyingPhoneHelpText(){
		return stepThreeBuyingPhoneHelpText;
	}

	@Override
	public String getStepThreeBringOwnPhoneHelpText(){
		return stepThreeBringOwnPhoneHelpText;
	}

	@Override
	public String getServiceProviderModalLabel(){
		return serviceProviderModalLabel;
	}

	@Override
	public String getServiceProviderModalName(){
		return serviceProviderModalName;
	}

	@Override
	public String getServiceProviderModalId() {
		return serviceProviderModalId;
	}

	/**
	 * <p> Sets serviceProviderModalId </p>
	 *
	 * @param serviceProviderModalId - the serviceProviderModalId to set
	 */
	public void setServiceProviderModalId(String serviceProviderModalId) {
		this.serviceProviderModalId = serviceProviderModalId;
	}

	@Override
	public String getServiceProviderList() {
		return serviceProviderList;
	}

	public void setServiceProviderList(String serviceProviderList) {
		this.serviceProviderList = serviceProviderList;
	}

	@Override
	public String getShowCityState() {
		return showCityState;
	}

	@Override
	public String getStepOneSummary() {
		return stepOneSummary;
	}

	@Override
	public String getStepOneFileReference() {
		return DynamicMediaUtils.changeMediaPathToDMPath(stepOneFileReference, request.getResourceResolver());
		//return stepOneFileReference;
	}

	@Override
	public String getStepOneFilePath() {
		return stepOneFileReference;
	}

	@Override
	public String getStepOneMediaAlignment() {
		return stepOneMediaAlignment;
	}

	@Override
	public String getStepTwoSummary() {
		return stepTwoSummary;
	}

	@Override
	public String getStepTwoFileReference() {
		return DynamicMediaUtils.changeMediaPathToDMPath(stepTwoFileReference, request.getResourceResolver());
		//return stepTwoFileReference;
	}

	@Override
	public String getStepTwoFilePath() {
		return stepTwoFileReference;
	}

	@Override
	public String getStepTwoMediaAlignment() {
		return stepTwoMediaAlignment;
	}

	@Override
	public String getHideBuyPhoneHelpText() {
		return hideBuyPhoneHelpText;
	}

	@Override
	public String getStepThreeBuyingPhoneSlideTitle() {
		return stepThreeBuyingPhoneSlideTitle;
	}

	@Override
	public String getStepThreeBuyingPhoneSlideDesc() {
		return stepThreeBuyingPhoneSlideDesc;
	}

	@Override
	public String getDeviceNameHelpModalLabel() {
		return deviceNameHelpModalLabel;
	}

	@Override
	public String getDeviceNameHelpModalName() {
		return deviceNameHelpModalName;
	}

	@Override
	public String getBuyNewPhoneButtonContinue() {
		return buyNewPhoneButtonContinue;
	}

	@Override
	public String getHideBringOwnPhoneHelpText() {
		return hideBringOwnPhoneHelpText;
	}

	@Override
	public String getStepThreeBringOwnPhoneSlideTitle() {
		return stepThreeBringOwnPhoneSlideTitle;
	}

	@Override
	public String getStepThreeBringOwnPhoneSlideDesc() {
		return stepThreeBringOwnPhoneSlideDesc;
	}

	@Override
	public String getBringOwnPhoneButtonContinue() {
		return bringOwnPhoneButtonContinue;
	}

	@Override
	public String getStepFourTitle() {
		return stepFourTitle;
	}

	@Override
	public String getRestartButtonLabel() {
		return restartButtonLabel;
	}

	@Override
	public String getPhoneBannerTitle() {
		return phoneBannerTitle;
	}

	@Override
	public String getPhoneBannerSummary() {
		return phoneBannerSummary;
	}

	@Override
	public String getSimBannerTitle() {
		return simBannerTitle;
	}

	@Override
	public String getSimBannerSummary() {
		return simBannerSummary;
	}

	@Override
	public String getEnableChangeDevice() {
		return enableChangeDevice;
	}

	@Override
	public String getEnableChangeServiceProvider() {
		return enableChangeServiceProvider;
	}

	@Override
	public String getEnableChangeLocation() {
		return enableChangeLocation;
	}

	@Override
	public String getEnableChangePhoneNo() {
		return enableChangePhoneNo;
	}

	@Override
	public String getDeviceHelpModalId() {
		return deviceHelpModalId;
	}
	
	public void setDeviceHelpModalId(String deviceHelpModalId) {
		this.deviceHelpModalId = deviceHelpModalId;
	}
	
	/**
	 * @return String -  MarketingIdApiPath
	 */
	public String getMarketingIdApiPath() {

		return tracfoneApiService.getMarketingApiPath();
	}

	@Override
	public String getStepThreeTextSlideTitle() {
		return stepThreeTextSlideTitle;
	}

	@Override
	public String getStepThreeTextSlideDesc() {
		return stepThreeTextSlideDesc;
	}

	@Override
	public String getShowTextSlide() {
		return showTextSlide;
	}

	@Override
	public String getExportedType() {

		return request.getResource().getResourceType();
	}

}
