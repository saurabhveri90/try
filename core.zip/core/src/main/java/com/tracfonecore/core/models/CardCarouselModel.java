package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.CarouselCardBean;

public interface CardCarouselModel extends ComponentExporter {
	
	@JsonProperty("carouselTitle")
	public String getCarouselTitle();
	
	@JsonProperty("carouselCards")
	public List<CarouselCardBean> getCarouselCards();

	@JsonProperty("enableDesktopCarousel")
	public boolean getEnableDesktopCarousel();

}