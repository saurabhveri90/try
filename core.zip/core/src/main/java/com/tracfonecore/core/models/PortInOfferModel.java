/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Portin-offer} Sling Model used for the
 * {@code /apps/tracfone-core/components/commerce/portinoffer} component.
 */

public interface PortInOfferModel extends ComponentExporter {

	/**
	 * <p>
	 * Fetches portInHeadingText
	 * </p>
	 *
	 * @return the portInHeadingText
	 */
	@JsonProperty("portInHeadingText")
	public String getPortInHeadingText();

	/**
	 * <p>
	 * Fetches portEligibilitySteps
	 * </p>
	 *
	 * @return the portEligibilitySteps
	 */
	@JsonProperty("portEligibilitySteps")
	public String getPortEligibilitySteps();

	/**
	 * <p>
	 * Fetches verifyPhoneNumberText
	 * </p>
	 *
	 * @return the verifyPhoneNumberText
	 */
	@JsonProperty("verifyPhoneNumberText")
	public String getVerifyPhoneNumberText();

	/**
	 * <p>
	 * Fetches verifyPhoneNumberLabel
	 * </p>
	 *
	 * @return the verifyPhoneNumberLabel
	 */
	@JsonProperty("verifyPhoneNumberLabel")
	public String getVerifyPhoneNumberLabel();

	/**
	 * <p>
	 * Fetches checkMyNumberCtaText
	 * </p>
	 *
	 * @return the checkMyNumberCtaText
	 */
	@JsonProperty("checkMyNumberCtaText")
	public String getCheckMyNumberCtaText();

	/**
	 * <p>
	 * Fetches verifyCodeHeadingText
	 * </p>
	 *
	 * @return the verifyCodeHeadingText
	 */
	@JsonProperty("verifyCodeHeadingText")
	public String getVerifyCodeHeadingText();

	/**
	 * <p>
	 * Fetches verifyCodeSubHeadingText
	 * </p>
	 *
	 * @return the verifyCodeSubHeadingText
	 */
	@JsonProperty("verifyCodeSubHeadingText")
	public String getVerifyCodeSubHeadingText();

	/**
	 * <p>
	 * Fetches verifyCodeInputLabelText
	 * </p>
	 *
	 * @return the verifyCodeInputLabelText
	 */
	@JsonProperty("verifyCodeInputLabelText")
	public String getVerifyCodeInputLabelText();

	/**
	 * <p>
	 * Fetches verifyCodeCtaText
	 * </p>
	 *
	 * @return the verifyCodeCtaText
	 */
	@JsonProperty("verifyCodeCtaText")
	public String getVerifyCodeCtaText();

	/**
	 * <p>
	 * Fetches verifyCodeResendTextOne
	 * </p>
	 *
	 * @return the verifyCodeResendTextOne
	 */
	@JsonProperty("verifyCodeResendTextOne")
	public String getVerifyCodeResendTextOne();

	/**
	 * <p>
	 * Fetches verifyCodeResendTextTwo
	 * </p>
	 *
	 * @return the verifyCodeResendTextTwo
	 */
	@JsonProperty("verifyCodeResendTextTwo")
	public String getVerifyCodeResendTextTwo();

	/**
	 * <p>
	 * Fetches portInAnotherPhoneNumberText
	 * </p>
	 *
	 * @return the portInAnotherPhoneNumberText
	 */
	@JsonProperty("portInAnotherPhoneNumberText")
	public String getPortInAnotherPhoneNumberText();

	/**
	 * <p>
	 * Fetches portInSuccessHeadingText
	 * </p>
	 *
	 * @return the portInSuccessHeadingText
	 */
	@JsonProperty("portInSuccessHeadingText")
	public String getPortInSuccessHeadingText();

	/**
	 * <p>
	 * Fetches portInSuccessDescriptionText
	 * </p>
	 *
	 * @return the portInSuccessDescriptionText
	 */
	@JsonProperty("portInSuccessDescriptionText")
	public String getPortInSuccessDescriptionText();

	/**
	 * <p>
	 * Fetches portInFailureHeadingTextOne
	 * </p>
	 *
	 * @return the portInFailureHeadingTextOne
	 */
	@JsonProperty("portInFailureHeadingTextOne")
	public String getPortInFailureHeadingTextOne();

	/**
	 * <p>
	 * Fetches portInFailureHeadingTextTwo
	 * </p>
	 *
	 * @return the portInFailureHeadingTextTwo
	 */
	@JsonProperty("portInFailureHeadingTextTwo")
	public String getPortInFailureHeadingTextTwo();

	/**
	 * <p>
	 * Fetches portInFailureDescriptionText
	 * </p>
	 *
	 * @return the portInFailureDescriptionText
	 */
	@JsonProperty("portInFailureDescriptionText")
	public String getPortInFailureDescriptionText();

	/**
	 * <p>
	 * Fetches portInFailureOtherOptionsLink
	 * </p>
	 *
	 * @return the portInFailureOtherOptionsLink
	 */
	@JsonProperty("portInFailureOtherOptionsLink")
	public String getPortInFailureOtherOptionsLink();

	/**
	 * <p>
	 * Fetches portInFailureOtherOptionsUrlLink
	 * </p>
	 *
	 * @return the portInFailureOtherOptionsUrlLink
	 */
	@JsonProperty("portInFailureOtherOptionsUrlLink")
	public String getPortInFailureOtherOptionsUrlLink();

	/**
	 * <p>
	 * Fetches portInFootnote
	 * </p>
	 *
	 * @return the portInFootnote
	 */
	@JsonProperty("portInFootnote")
	public String getPortInFootnote();

	/**
	 * <p>
	 * Fetches portInLoaderHeadingText
	 * </p>
	 *
	 * @return the portInLoaderHeadingText
	 */
	@JsonProperty("portInLoaderHeadingText")
	public String getPortInLoaderHeadingText();

	/**
	 * <p>
	 * Fetches portInLoaderStepOne
	 * </p>
	 *
	 * @return the portInLoaderStepOne
	 */
	@JsonProperty("portInLoaderStepOne")
	public String getPortInLoaderStepOne();

	/**
	 * <p>
	 * Fetches portInLoaderStepTwo
	 * </p>
	 *
	 * @return the portInLoaderStepTwo
	 */
	@JsonProperty("portInLoaderStepTwo")
	public String getPortInLoaderStepTwo();

	/**
	 * <p>
	 * Fetches portInLoaderStepThree
	 * </p>
	 *
	 * @return the portInLoaderStepThree
	 */
	@JsonProperty("portInLoaderStepThree")
	public String getPortInLoaderStepThree();

	/**
	 * <p>
	 * Fetches portInFailureOtherOptionsAriaLabel
	 * </p>
	 *
	 * @return the portInFailureOtherOptionsAriaLabel
	 */
	@JsonProperty("portInFailureOtherOptionsAriaLabel")
	public String getPortInFailureOtherOptionsAriaLabel();

	/**
	 * <p>
	 * Fetches portInApiErrorMsgOne
	 * </p>
	 *
	 * @return the portInApiErrorMsgOne
	 */
	@JsonProperty("portInApiErrorMsgOne")
	public String getPortInApiErrorMsgOne();

	/**
	 * <p>
	 * Fetches portInApiErrorMsgTwo
	 * </p>
	 *
	 * @return the portInApiErrorMsgTwo
	 */
	@JsonProperty("portInApiErrorMsgTwo")
	public String getPortInApiErrorMsgTwo();

	/**
	 * <p>
	 * Fetches portInEligibilityApiTimer
	 * </p>
	 *
	 * @return the portInEligibilityApiTimer
	 */
	@JsonProperty("portInEligibilityApiTimer")
	public String getPortInEligibilityApiTimer();

	/**
	 * <p>
	 * Fetches portInResendCodeTimer
	 * </p>
	 *
	 * @return the portInResendCodeTimer
	 */
	@JsonProperty("portInResendCodeTimer")
	public String getPortInResendCodeTimer();

	/**
	 * <p>
	 * Fetches veriffSuccessHeadingText
	 * </p>
	 *
	 * @return the veriffSuccessHeadingText
	 */
	@JsonProperty("veriffSuccessHeadingText")
	public String getVeriffSuccessHeadingText();

	/**
	 * <p>
	 * Fetches veriffSuccessDescriptionText
	 * </p>
	 *
	 * @return the veriffSuccessDescriptionText
	 */
	@JsonProperty("veriffSuccessDescriptionText")
	public String getVeriffSuccessDescriptionText();

	/**
	 * <p>
	 * Fetches veriffSuccessLVDescText
	 * </p>
	 *
	 * @return the veriffSuccessLVDescText
	 */
	@JsonProperty("veriffSuccessLVDescText")
	public String getVeriffSuccessLVDescText();

	/**
	 * <p>
	 * Fetches veriffSuccessNLDescText
	 * </p>
	 *
	 * @return the veriffSuccessNLDescText
	 */
	@JsonProperty("veriffSuccessNLDescText")
	public String getVeriffSuccessNLDescText();

	/**
	 * <p>
	 * Fetches veriffFootnote
	 * </p>
	 *
	 * @return the veriffFootnote
	 */
	@JsonProperty("veriffFootnote")
	public String getVeriffFootnote();

	/**
	 * <p>
	 * Fetches veriffLVFootnote
	 * </p>
	 *
	 * @return the veriffLVFootnote
	 */
	@JsonProperty("veriffLVFootnote")
	public String getVeriffLVFootnote();

	/**
	 * <p>
	 * Fetches veriffNLFootnote
	 * </p>
	 *
	 * @return the veriffNLFootnote
	 */
	@JsonProperty("veriffNLFootnote")
	public String getVeriffNLFootnote();

	/**
	 * <p>
	 * Fetches veriffLFootnote
	 * </p>
	 *
	 * @return the veriffLFootnote
	 */
	@JsonProperty("veriffLFootnote")
	public String getVeriffLFootnote();

	/**
	 * <p>
	 * Fetches verifyCodeResendAccTextTwo
	 * </p>
	 *
	 * @return the verifyCodeResendAccTextTwo
	 */
	@JsonProperty("verifyCodeResendAccTextTwo")
	public String getVerifyCodeResendAccTextTwo();

	/**
	 * <p>
	 * Fetches portInAnotherPhoneNumberAccText
	 * </p>
	 *
	 * @return the portInAnotherPhoneNumberAccText
	 */
	@JsonProperty("portInAnotherPhoneNumberAccText")
	public String getPortInAnotherPhoneNumberAccText();

	/**
	 * <p>
	 * Fetches privacyPolicyDisclaimer
	 * </p>
	 *
	 * @return String return the privacyPolicyDisclaimer
	 */
	@JsonProperty("privacyPolicyDisclaimer")
	public String getPrivacyPolicyDisclaimer();


	/**
	 * <p>
	 * Fetches footNote
	 * </p>
	 *
	 * @return the footNote
	 */
	@JsonProperty("footNote")
	public String getFootNote();

	/**
	 * <p>
	 * Fetches ctaDisableText
	 * </p>
	 *
	 * @return the ctaDisableText
	 */
	@JsonProperty("ctaDisableText")
	public String getCtaDisableText();

	/**
	 * <p>
	 * Fetches ctaText
	 * </p>
	 *
	 * @return the ctaText
	 */
	@JsonProperty("ctaText")
	public String getCtaText();

	/**
	 * <p>
	 * Fetches showStepsNumber
	 * </p>
	 *
	 * @return the showStepsNumber
	 */
	@JsonProperty("showStepsNumber")
	public String getShowStepsNumber();

	/**
	 * <p>
	 * Fetches showPortinInFlow
	 * </p>
	 *
	 * @return the showPortinInFlow
	 */
	@JsonProperty("showPortinInFlow")
	public String getShowPortinInFlow();

	/**
	 * <p>
	 * Fetches anotherpaymenttext
	 * </p>
	 *
	 * @return the anotherpaymenttext
	 */
	@JsonProperty("anotherpaymenttext")
	public String getAnotherPaymentText();

	/**
	 * <p>
	 * Fetches anotherpaymentalttext
	 * </p>
	 *
	 * @return the anotherpaymentalttext
	 */
	@JsonProperty("anotherpaymentalttext")
	public String getAnotherPaymentAltText();

	/**
	 * <p>
	 * Fetches anotherplantext
	 * </p>
	 *
	 * @return the anotherplantext
	 */
	@JsonProperty("anotherplantext")
	public String getAnotherPlanText();

	/**
	 * <p>
	 * Fetches anotherplanalttext
	 * </p>
	 *
	 * @return the anotherplanalttext
	 */
	@JsonProperty("anotherplanalttext")
	public String getAnotherPlanAltText();

	/**
	 * <p>
	 * Fetches CTA link of Add to cart button
	 * </p>
	 * 
	 * @return String - CTA link of Add to cart button
	 */
	@JsonProperty("ctaLink")
	public String getCtaLink();

	/**
	 * <p>
	 * Fetches device PLP page path
	 * </p>
	 * 
	 * @return String - Device PLP page path
	 */
	@JsonProperty("plpPagePath")
	public String getPlpPagePath();

	/**
	 * <p>
	 * Fetches upgradeApiPath
	 * </p>
	 *
	 * @return the upgradeApiPath
	 */
	public String getUpgradeApiPath();

	/**
	 * <p>
	 * Fetches upgradeElgQueryString
	 * </p>
	 *
	 * @return the upgradeElgQueryString
	 */
	public String getUpgradeElgQueryString();

	/**
	 * <p>
	 * Fetches apiDomain
	 * </p>
	 *
	 * @return the apiDomain
	 */

	public String getApiDomain();

	/**
	 * <p>
	 * Fetches portInMinSetApiPath
	 * </p>
	 *
	 * @return the portInMinSetApiPath
	 */

	public String getPortInMinSetApiPath();

	/**
	 * <p>
	 * Fetches portInMinEligibilityApiPath
	 * </p>
	 *
	 * @return the portInMinEligibilityApiPath
	 */

	public String getPortInMinEligibilityApiPath();

	/**
	 * <p>
	 * Fetches portInMinOtpValidateApiPath
	 * </p>
	 *
	 * @return the portInMinOtpValidateApiPath
	 */

	public String getPortInMinOtpValidateApiPath();

	/**
	 * <p>
	 * Fetches resourceMgmtApiPath
	 * </p>
	 *
	 * @return the resourceMgmtApiPath
	 */
	public String getResourceMgmtApiPath();

	/**
	 * <p>
	 * Fetches resourceMgmtApiProjection
	 * </p>
	 *
	 * @return the resourceMgmtApiProjection
	 */
	public String getResourceMgmtApiProjection();

	/**
	 * <p>
	 * Fetches anotherPhoneNoText
	 * </p>
	 *
	 * @return the anotherPhoneNoText
	 */
	@JsonProperty("anotherPhoneNoText")
	public String getAnotherPhoneNoText();

	/**
	 * <p>
	 * Fetches anotherPhoneNoAltText
	 * </p>
	 *
	 * @return the anotherPhoneNoAltText
	 */
	@JsonProperty("anotherPhoneNoAltText")
	public String getAnotherPhoneNoAltText();

	/**
	 * <p>
	 * Fetches anotherPayOptText
	 * </p>
	 *
	 * @return the anotherPayOptText
	 */
	@JsonProperty("anotherPayOptText")
	public String getAnotherPayOptText();

	/**
	 * <p>
	 * Fetches anotherPayOptAltText
	 * </p>
	 *
	 * @return the anotherPayOptAltText
	 */
	@JsonProperty("anotherPayOptAltText")
	public String getAnotherPayOptAltText();

	/**
	 * <p>
	 * Fetches verifyCodeSubHeading2Text
	 * </p>
	 *
	 * @return the verifyCodeSubHeading2Text
	 */
	@JsonProperty("verifyCodeSubHeading2Text")
	public String getVerifyCodeSubHeading2Text();

}
