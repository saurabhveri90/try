package com.tracfonecore.core.models;
import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonGetter;

public interface EnRecaptchaModel {

   /**

     * @return the heading

     */

    @JsonGetter("enCaptchaSiteProjectId")

    public String getEnCaptchaSiteProjectId();

     @JsonGetter("enCaptchaSiteAPIKey")

    public String getEnCaptchaSiteAPIKey();

    @JsonGetter("enCaptchaSiteKey")

    public String getEnCaptchaSiteKey();

    @JsonGetter("enCaptchaSubmitUrl")

    public String getEnCaptchaSubmitUrl();
    
}