package com.tracfonecore.core.models.impl;

import javax.annotation.PostConstruct;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.UpgradeOptionModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { UpgradeOptionModel.class,
  ComponentExporter.class }, resourceType = UpgradeOptionModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
  @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
  @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class UpgradeOptionModelImpl implements UpgradeOptionModel {
    private static final Logger LOGGER = LoggerFactory.getLogger(UpgradeOptionModelImpl.class);
    protected static final String RESOURCE_TYPE = "tracfone-core/components/spa/commerce/upgradeoption";

    @Self
	private SlingHttpServletRequest request;

    @ValueMapValue
	private String[] features;

    @ValueMapValue
	private String heading;

    @ValueMapValue
	private String subheading;

    @ValueMapValue
	private String buttonLabel;

    @ValueMapValue
	private String buttonUrl;

    @ValueMapValue
	private String partClass;

 
    /**
	 * <p>
	 * Init method : 
     * - gets and set plan data for each plan path authored
	 * - sets query string
     * - gets accessbility for price/savings from homepage properties
	 * </p>
	 *
	 */
    @PostConstruct
	protected void initModel() {
        
    }

    

    /**
	 * Method to return features
	 * 
	 * @return String[] features
	 */
    @Override
    public String[] getFeatures() {
        return this.features;
    }


    /**
	 * Method to return heading
	 * 
	 * @return String heading
	 */
    @Override
    public String getHeading() {
        return this.heading;
    }

    /**
	 * Method to return subheading
	 * 
	 * @return String subheading
	 */
    @Override
    public String getSubHeading() {
        return this.subheading;
    }

    /**
	 * Method to return buttonLabel
	 * 
	 * @return String buttonLabel
	 */
    @Override
    public String getButtonLabel() {
        return this.buttonLabel;
    }

    /**
	 * Method to return buttonUrl
	 * 
	 * @return String buttonUrl
	 */
    @Override
    public String getButtonUrl() {
        return this.buttonUrl;
    }

    /**
	 * Method to return partClass
	 * 
	 * @return String partClass
	 */
    @Override
    public String getPartClass() {
        return this.partClass;
    }



    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

}