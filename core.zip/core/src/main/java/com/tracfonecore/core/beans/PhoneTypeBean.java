package com.tracfonecore.core.beans;

/**
 * <p>
 * Defines bean to hold phone type detail
 * </p>
 */
public class PhoneTypeBean {

	private String label;
	private String value;

	/**
	 * <p>
	 * Fetches label
	 * </p>
	 *
	 * @return the label
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * <p>
	 * Sets label
	 * </p>
	 *
	 * @param label - the label to set
	 */
	public void setLabel(String label) {
		this.label = label;
	}

	/**
	 * <p>
	 * Fetches value
	 * </p>
	 *
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * <p>
	 * Sets value
	 * </p>
	 *
	 * @param value - the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
}
