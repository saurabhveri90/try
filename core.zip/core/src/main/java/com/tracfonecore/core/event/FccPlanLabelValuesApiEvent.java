package com.tracfonecore.core.event;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.jcr.ItemExistsException;
import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.lock.LockException;
import javax.jcr.nodetype.ConstraintViolationException;
import javax.jcr.nodetype.NoSuchNodeTypeException;
import javax.jcr.version.VersionException;

import org.apache.commons.lang.StringUtils;
import org.apache.jackrabbit.vault.packaging.JcrPackageDefinition;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.event.Event;
import org.osgi.service.event.EventConstants;
import org.osgi.service.event.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.taskmanagement.Task;
import com.adobe.granite.taskmanagement.TaskManager;
import com.adobe.granite.taskmanagement.TaskManagerException;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.SearchResult;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.constants.FccMapConstants;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.BroadbandFactsConfigService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;

@Component(service = EventHandler.class, immediate = true, property = {
		EventConstants.EVENT_TOPIC + "=" + org.apache.sling.api.SlingConstants.TOPIC_RESOURCE_ADDED,
		EventConstants.EVENT_FILTER + "=" + "(resourceType=dam:Asset)"})
public class FccPlanLabelValuesApiEvent implements EventHandler {
	private static final Logger LOG = LoggerFactory.getLogger(FccPlanLabelValuesApiEvent.class);

	private static final String TF_CREATE_MODIFY_SERVICE = "tf-create-modify-service-user";
	
	private static final String CF_NODE_MASTER = "jcr:content/data/master";
	private static final String TASK_LABEL = "Notification";
	private static final String TASK_NAME = "Duplicated FCC Content Fragment";
	private static final String TASK_DESCRIPTION = "FCC Content Fragment removed as this was duplicate, already have content fragment with same part number in given path";
	private static final String TASK_INSTRUCTIONS = "FCC Content Fragment removed as this was duplicate, already have content fragment with same part number in given path";
	
	
	@Reference
	private ResourceResolverFactory resolverFactory;

	@Reference
	private BroadbandFactsConfigService broadbandFactsConfigService;

	@Reference
	private ApplicationConfigService applicationConfigService;

	@Reference
	private TracfoneApiGatewayService tracfoneApiGatewayService;
	
	private String brandKey;
	
	private String language;

	@Override
	public void handleEvent(Event event) {
		LOG.info("Init handleEvent on FccPlanContentValuesApiEvent");
		//create a Map with a user to get the ResourceResolver
		Map<String, Object> loginParams = new HashMap<>();
		loginParams.put(ResourceResolverFactory.SUBSERVICE, TF_CREATE_MODIFY_SERVICE);
		LOG.info("loginParams.containsKey: {}", loginParams.containsKey(ResourceResolverFactory.SUBSERVICE));
		try (ResourceResolver resolver = resolverFactory.getServiceResourceResolver(loginParams)) {
			//Get the path of the Content Fragment created
			String path = (String) event.getProperty("path");
			LOG.debug("got service resolver/path: {}",path);
			Session session = resolver.adaptTo(Session.class);
			//Check if the node have a "master" node
			Optional.ofNullable(session.getNode(path)).ifPresent(fragmentNode -> {
				try{
					LOG.debug("inside Try processFragmentNode");
					processFragmentNode(fragmentNode, event, resolver);
					session.save();
				}catch(RepositoryException e){
					 LOG.error("RepositoryException at handleEvent caused by : ", e);
				}
			});

		}catch (LoginException | RepositoryException  e) {
            LOG.error("LoginException at handleEvent caused by : ", e);
        }

	}

	/**
	 * Get the CF Node and check if has Master Node 
	 * @param fragmentNode Content Fragment
	 * @param event Event
	 * @param resolver Resource Resolver
	 * @throws PathNotFoundException
	 * @throws ItemExistsException
	 * @throws NoSuchNodeTypeException
	 * @throws LockException
	 * @throws VersionException
	 * @throws ConstraintViolationException
	 * @throws RepositoryException
	 * @throws JSONException 
	 */
	private void processFragmentNode(Node fragmentNode, Event event, ResourceResolver resolver) throws RepositoryException{
		//If the CF not have a masterNode or not is a FCC CF, return null and exit on the method.
		if(!fragmentNode.hasNode(CF_NODE_MASTER)){
			return;	
		}
		Node dataNode = fragmentNode.getNode("jcr:content/data");
		if (!dataNode.hasProperty("cq:model")) {
			return;	
		}else {
			if(!dataNode.getProperty("cq:model").getString().contains("fcc-fragment-model")) return;
		}
		
		Node masterNode = fragmentNode.getNode(CF_NODE_MASTER);
		LOG.debug("Processing fragment node: {}", masterNode.getPath());
		//Get the property in "master" node or the property Name in the Content Fragment.
		String fccName =  fragmentNode.getName().toUpperCase();
		LOG.debug("Processing fragment node: {} {} {}", event.getTopic(), resolver.getUserID(), fccName);
		//get from OSGi config the ContentBasePath of CF
		String contentCFPath = transformToRootPath((String) event.getProperty("path"));
		//Check if the CF with clfyPartNumber already exist
		if(StringUtils.isNotBlank(contentCFPath) && 
			Boolean.FALSE.equals(alreadyExistContentFragment(event, fccName, contentCFPath, resolver, fragmentNode))){	
			String apiPath = createApiPath();
			if(StringUtils.isNotBlank(apiPath) && StringUtils.isNotBlank(contentCFPath)){
				//The the resource "TemplateLevelPath"
				Resource componentResource = resolver.getResource(broadbandFactsConfigService.getTemplateLevelPath());
				if(componentResource != null && componentResource.adaptTo(ValueMap.class) != null) {
					//Populate the masterNode with the properties in TemplateLevelPath
					for(String property : FccMapConstants.getPropertiesTemplateLevel()) {
						setValuesFromProperty(componentResource, property, masterNode);
					}		
				}		
				//Populate the masterNode with the properties fetched from the API
				setValuesFromApi(masterNode, apiPath, fccName);
			}
		}else{
			//if already exist, remove the CF
			TaskManager taskManager = resolver.adaptTo(TaskManager.class);
			try {
				String currentUser = fragmentNode.getProperty(JcrPackageDefinition.PN_CREATED_BY).getString();
				Task newTask = taskManager.getTaskManagerFactory().newTask(TASK_LABEL);
				newTask.setName(TASK_NAME);
				newTask.setContentPath(fragmentNode.getPath());
				newTask.setDescription(TASK_DESCRIPTION);
				newTask.setInstructions(TASK_INSTRUCTIONS);
				newTask.setCurrentAssignee(currentUser != null ? currentUser : resolver.adaptTo(Session.class).getUserID());
				taskManager.createTask(newTask);
				fragmentNode.remove();
				LOG.info("Removed {}", fragmentNode);

			} catch (TaskManagerException e) {
				LOG.error("TaskManagerException at handleEvent caused by : ", e);

			}
			
		}

		
			
	}
	
	/**
	 * populate node from properties in the resource
	 * @param resource resource to get the properties
	 * @param propertyName property name to get
	 * @param cfMaster Master Node to will be populated
	 * @throws RepositoryException 
	 */
	private void setValuesFromProperty(Resource resource, String propertyName, Node masterNode) throws RepositoryException{
		ValueMap properties = resource.adaptTo(ValueMap.class);
		//Create a propertyName with brandKey(Brand short Name) + propertyName + Language
		String propertyLabel = (brandKey + propertyName + (language.substring(0,1).toUpperCase() + language.substring(1)));	
		if(properties.containsKey(propertyLabel)) {
			//Set the property in masterNode with the value or empty text
			masterNode.setProperty(propertyName, (String) properties.getOrDefault(propertyLabel, ""));
		}

	}


	/**
	 * Check if the JSONObject has the properties to insert on the Master Node
	 * @param cfMaster Master Node
	 * @throws JSONException 
	 * @throws RepositoryException 
	 */
	private void setValuesFromApi(Node cfMaster, String apiPath, String fccName) throws RepositoryException{
		JsonObject jsonObject = fetchFromApi(apiPath, fccName);
		LOG.debug("jsonObject : {}", jsonObject);
		if (jsonObject != null) {
			CommerceUtil.populateNodeProperties(cfMaster, jsonObject.getAsJsonArray("fccLabelList").get(0).getAsJsonObject());
		}
	}

	/**
	 * Fetch the API Path to get the JSONObject or null
	 * @return JSONObject Object with the properties or null
	 */
	protected JsonObject fetchFromApi(String apiPath, String fccName) {
		String requestBodyJsonString = getRequestBody(fccName);
		JsonObject jsonObject = CommerceUtil.getApiResponseDataWithRetries(apiPath, broadbandFactsConfigService.getFccRetriesConnectApi(), broadbandFactsConfigService.getFccIntervalConnectApi(), requestBodyJsonString, ApplicationConstants.URL_PROTOCOL_POST);
		LOG.debug("jsonObject : {}", jsonObject);
		if(jsonObject != null) {
			Boolean exist = Optional.ofNullable(jsonObject.getAsJsonObject("status"))
					.map(status -> "0".equals(status.get("code").getAsString()))
					.orElse(false);
				return Boolean.TRUE.equals(exist) ? jsonObject : null ;
		}
		return null;
	
	}

/**
	 * Function to create the path of the API
	 * @param fccName Node name of FCC
	 * @return
	 */
	private String createApiPath(){
		String domainApi = tracfoneApiGatewayService.getApiDomain();
		String clientIdApi = tracfoneApiGatewayService.getFccApiClientId();
		String contentApi = broadbandFactsConfigService.getFccContentApiPath();
		String newApiPath = domainApi + contentApi + ApplicationConstants.QUESTION_MARK + CommerceConstants.CLIENT_ID + ApplicationConstants.EQUAL + clientIdApi;
		LOG.debug("createApiPath :{}",newApiPath);
		return !StringUtils.contains(newApiPath, " ") ? newApiPath : null;
	}

	/**
	 * Transform the path of the event to get the root page of the brand
	 * @param originPath path of the event
	 * @return rootPath
	 */
	private String transformToRootPath(String originPath){
		
		String[] parts = originPath.split(ApplicationConstants.SLASH);
		if(parts.length < 5){
			return null;
		}
		
		language = parts[4];
		
		for(String brandConfig : broadbandFactsConfigService.getFactsContentBasePath() ) {		
			String[] partsConfig = brandConfig.split(":");
			String factsContentBasePath = partsConfig[1].replace("{language}", language);
			if(originPath.matches(factsContentBasePath + ".*")) {
				brandKey = ConfigurationUtil.getConfigValue(broadbandFactsConfigService.getBrandShortName(), partsConfig[0]);		
				return factsContentBasePath;			
			}
		}
		
		return null;

	}

	private String getRequestBody(String fccName) {
		String requestBodyString = "";
		if (fccName != null) {
			JsonObject outerJson = new JsonObject();
			JsonArray fccLabelListArray = new JsonArray();
			JsonObject partNumberObject = new JsonObject();
			partNumberObject.addProperty("partNumber", fccName);
			fccLabelListArray.add(partNumberObject);
			outerJson.add("fccLabelList", fccLabelListArray);
			requestBodyString = outerJson.toString();
		}
		return requestBodyString;
	}

	/**
	 * Check if the CF already exist in the same path/node
	 * @param event creation CF event
	 * @param fccName clfyPartNumber for CF
	 * @param contentCFPath Base path for CF
	 * @param resolver Resource Resolver
	 * @return
	 * @throws RepositoryException 
	 */
	private Boolean alreadyExistContentFragment(Event event, String fccName,String contentCFPath, ResourceResolver resolver, Node fragmentNode ) throws RepositoryException {
		//get the path of the event
		String eventPath = (String) event.getProperty("path"); 
		//user Regex to remove "-1"/"-2"/"-N" if contains or the last number to get the original clfyPartNumber
		Pattern pattern = Pattern.compile("(-\\d|\\d)$");
		Matcher matcher = pattern.matcher(fccName);
		String newFccName = null;
		if(matcher.find()) {
			newFccName = fccName.substring(0,matcher.start()).toLowerCase();
			//check if the path is from "nationalretailer" to use the complete path and not the base path CF
			if(eventPath.contains("nationalretailer")) contentCFPath = eventPath.substring(0, eventPath.lastIndexOf(fragmentNode.getName()));
			Map<String, String> map = createQuery(contentCFPath, newFccName);
			SearchResult result = getSearchResult(map, resolver);
			LOG.info("There are {} results", result.getTotalMatches());
			//Return true if have any result
			return !result.getHits().isEmpty();
		} 
		//if the FccName not have "-1"/"-2"/"-N", return false
		return false;
	}

		/**
	 * <p>
	 * Method send search result from Query Builder
	 * </p>
	 * 
	 * @param Map<String,      String>
	 * @param ResourceResolver
	 * @return SearchResult
	 */
	private SearchResult getSearchResult(Map<String, String> map, ResourceResolver resourceResolver) {
		QueryBuilder queryBuilder = resourceResolver.adaptTo(QueryBuilder.class);
		Query query = queryBuilder.createQuery(PredicateGroup.create(map), resourceResolver.adaptTo(Session.class));
		return query.getResult();
	}

	/**
	 * Create query to search CF with a specific CF Name
	 * @param path path of the CF
	 * @param clfyPartNumber The clfyPartNumber for CF
	 * @return Map<String, String> Query
	 * @throws UnsupportedEncodingException 
	 */
	private Map<String, String> createQuery(String path, String clfyPartNumber) {
		Map<String, String> map = new HashMap<>();
		map.put("path", path);
		map.put("type", "dam:asset");
		map.put("p.hits", "full");
		map.put("p.limit", "-1");
		map.put("nodename", clfyPartNumber);
		return map;
	}
}
