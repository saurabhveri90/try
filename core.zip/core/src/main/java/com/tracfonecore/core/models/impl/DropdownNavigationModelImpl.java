package com.tracfonecore.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.DropdownNavigationModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { DropdownNavigationModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/dropdownNavigation", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class DropdownNavigationModelImpl implements DropdownNavigationModel {

	@Self
	private SlingHttpServletRequest request;
	/**
	 * Inject heading
	 */
	@ValueMapValue
	private String heading;
	
	/**
	 * Inject accessibilityLabel
	 */
	@ValueMapValue
	private String accessibilityLabel;
	
	/**
	 * Inject analyticsLabel
	 */
	@ValueMapValue
	private String analyticsLabel;

	/**
	 * Inject options
	 */
	@ChildResource
	private Resource navigationList;

	/**
	 * <p>
	 * Returns heading from properties
	 * </p>
	 * 
	 * @return String - heading
	 */
	@Override
	public String getHeading() {
		return heading;
	}

	/**
	 * <p>
	 * Returns navigationList from properties
	 * </p>
	 * 
	 * @return String - navigationList
	 */
	@Override
	public Resource getNavigationList() {
		return navigationList;
	}
	
	/**
	 * <p>
	 * Returns accessibilityLabel from properties
	 * </p>
	 * 
	 * @return String - accessibilityLabel
	 */
	@Override
	public String getAccessibilityLabel() {
		return accessibilityLabel;
	}
	
	/**
	 * @return the analyticsLabel
	 */
	@Override
	public String getAnalyticsLabel() {
		return analyticsLabel;
	}


	/**
	 * <p>
	 * Returns getexportertype from resource
	 * </p>
	 * 
	 * @return String - getexportertype
	 */
	@Override
	public String getExportedType() {

		return request.getResource().getResourceType();
	}
}
