/**
 * 
 */
package com.tracfonecore.core.models.impl.v1;

import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.tracfonecore.core.models.CardStyleTeaserModel;
import com.tracfonecore.core.models.impl.BaseComponentModelImpl;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import com.tracfonecore.core.utils.ItemsExporterUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CardStyleTeaserModel.class,ComponentExporter.class },
	resourceType = "tracfone-core/components/content/cardstyleteaser/v1/cardstyleteaser", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR,
	extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
	@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
	@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CardStyleTeaserModelImpl extends BaseComponentModelImpl implements CardStyleTeaserModel {

	@ScriptVariable
	private ValueMap properties;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String title;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String summary;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String mediaType;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String imageAndVideo;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String imageAltText;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String videoThumbnailReference;


	private static final Logger LOGGER = LoggerFactory.getLogger(CardStyleTeaserModelImpl.class);

	@Self
	private SlingHttpServletRequest request;
	@Inject
	private SlingModelFilter slingModelFilter;
	@Inject
	private ModelFactory modelFactory;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String mobileVersion;

	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public String getSummary() {
		return summary;
	}

	@Override
	public String getMediaType() {
		return mediaType;
	}

	@Override
	public String getImageAndVideo() {
		String s7Path = DynamicMediaUtils.changeMediaPathToDMPath(imageAndVideo, request.getResourceResolver());
		LOGGER.debug("Card teaser Image/Video Path: {}",s7Path);
		return s7Path;
	}

	@Override
	public String getImageAltText() {
		return imageAltText;
	}

	@Override
	public String getVideoThumbnailImage() {
		String s7Path = DynamicMediaUtils.changeMediaPathToDMPath(videoThumbnailReference, request.getResourceResolver());
		LOGGER.debug("Card teaser Video thumbnail Path: {}",s7Path);
		return s7Path;
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public Map<String, ? extends ComponentExporter> getItems(){
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}
	
	@Override
	public String getDataMode() {
		return this.mobileVersion;
	}
	/**
	 * <p>Returns the breakpoint for website from Dynamic media config</p>
	 * 
	 * @return String - breakpoints
	 */
	@Override
	public String getImageProfileBreakpoints() {
		String path = this.imageAndVideo;
		String breakPoints = "";
		if("bgsmartcrop".equals(this.getDataMode())) {
			breakPoints = DynamicMediaUtils.getImageProfileBreakpoints(path, request.getResourceResolver());
		}
		return breakPoints;
	}
	
	@Override
	public String getMobileMediaImagePath() {
		String path = DynamicMediaUtils.getMobileDMPath(this.imageAndVideo, request.getResourceResolver());
		if(!"mobileimage".equals(this.mobileVersion)) {
			path = ""; 
		}
		return path;
	}
	
	/**
	 * <p>
	 * initialize the model
	 *  
	 */
	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering initModel method");
		super.initModel();		
		LOGGER.debug("Exiting initModel method");
		
	}

}
