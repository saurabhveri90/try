/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.CreditCardVendorBean;
import com.tracfonecore.core.beans.PaymentOptionBean;
import com.tracfonecore.core.beans.ShippingMethodBean;

/**
 * Defines the {@code Multi-Links} Sling Model used for the {@code /apps/tracfone-core/components/content/checkoutdetail} component.
 */
public interface CheckoutDetailModel extends ComponentExporter {

	/**
	 * <p>Fetches shippingOptionsLink for the checkoutdetail</p>
	 * 
	 * @return String - shippingOptionsLink for the checkout process
	 */
	@JsonProperty("shippingOptionsLink")
	public String getShippingOptionsLink();
	
	/**
	 * <p>Fetches positionCheckoutProcess for the checkoutdetail</p>
	 * 
	 * @return String - positionCheckoutProcess for the checkout process
	 */
	@JsonProperty("positionCheckoutProcess")
	public String getPositionCheckoutProcess();
	
	/**
	 * <p>Fetches positionCheckoutSummary for the checkoutdetail</p>
	 * 
	 * @return String - positionCheckoutSummary for the checkout process
	 */
	@JsonProperty("positionCheckoutSummary")
	public String getPositionCheckoutSummary();
	
	/**
	 * <p>Fetches shippingOptionsModalContent for the checkoutdetail</p>
	 * 
	 * @return String - shippingOptionsModalContent for the checkout detail
	 */
	@JsonProperty("shippingOptionsModalContent")
	public String getShippingOptionsModalContent();
	
	/**
	 * <p>Fetches all the shippingMethods</p>
	 * 
	 * @return List<ShippingMethodsBean> - all the shippingMethods in list
	 */
	@JsonProperty("shippingMethods")
	public List<ShippingMethodBean> getShippingMethods();
	
	/**
	 * <p>Fetches all the checkoutSteps</p>
	 * 
	 * @return List<String> - all the checkoutSteps in a list
	 */
	@JsonProperty("checkoutSteps")
	public List<String> getCheckoutSteps();
	
	/**
	 * <p>Fetches tradeInSubTitle for the checkoutdetail</p>
	 * 
	 * @return String - tradeInSubTitle for the checkout detail
	 */
	@JsonProperty("tradeInSubTitle")
	public String getTradeInSubTitle();
	
	/**
	 * <p>Fetches learnMoreLinkTitle for the checkoutdetail</p>
	 * 
	 * @return String - learnMoreLinkTitle for the checkout detail
	 */
	@JsonProperty("learnMoreLinkTitle")
	public String getLearnMoreLinkTitle();
	
	/**
	 * <p>Fetches characterLimitGiftMessage for the checkoutdetail</p>
	 * 
	 * @return String - characterLimitGiftMessage for the checkout detail
	 */
	@JsonProperty("characterLimitGiftMessage")
	public String getCharacterLimitGiftMessage();
	
	/**
	 * <p>Fetches termsConditionsLink for the checkoutdetail</p>
	 * 
	 * @return String - termsConditionsLink for the checkout detail
	 */
	@JsonProperty("termsConditionsLink")
	public String getTermsConditionsLink();

	/**
	 * <p>Fetches tWPTermsConditionsLink for the checkoutdetail</p>
	 * 
	 * @return String - tWPTermsConditionsLink for the checkout detail
	 */
	@JsonProperty("tWPTermsConditionsLink")
	public String getTWPTermsConditionsLink();
	/**
	 * <p>Fetches legalConsentLink for the checkoutdetail</p>
	 * 
	 * @return String - legalConsentLink for the checkout detail
	 */

	

	@JsonProperty("legalConsentLink")
	public String getLegalConsentLink();


	/**
	 * <p>Fetches stByopReviewCheck for the checkoutdetail</p>
	 *
	 * @return String - stByopReviewCheck for the checkout detail
	 */
	@JsonProperty("stByopReviewCheck")
	public String getStByopReviewCheck();

	/**
	 * <p>Fetches smartPayConsentLink for the checkoutdetail</p>
	 * 
	 * @return String - smartPayConsentLink for the checkout detail
	 */
	@JsonProperty("smartPayConsentLink")
	public String getSmartPayConsentLink();

	/**
	 * <p>Fetches smartPayTcpaConsentLink for the checkoutdetail</p>
	 * 
	 * @return String - smartPayTcpaConsentLink for the checkout detail
	 */
	@JsonProperty("smartPayTcpaConsentLink")
	public String getSmartPayTcpaConsentLink();
	
	/**
	 * <p>Fetches all the paymentOptions</p>
	 * 
	 * @return List<PaymentOptionsBean> - all the paymentOptions in list
	 */
	@JsonProperty("paymentOptions")
	public List<PaymentOptionBean> getPaymentOptions();
	
	/**
	 * <p>Fetches all the tradeInOptions</p>
	 * 
	 * @return List<String> - all the tradeInOptions in a list
	 */
	@JsonProperty("tradeInOptions")
	public List<String> getTradeInOptions();

	/**
	 * <p>Fetches all the activationSupportKitOptions</p>
	 *
	 * @return List<String> - all the activationSupportKitOptions in a list
	 */
	@JsonProperty("activationSupportKitOptions")
	public List<String> getActivationSupportKitOptions();
	
	/**
	 * <p>Fetches all the creditCardVendors</p>
	 * 
	 * @return List<PaymentOptionsBean> - all the creditCardVendors in list
	 */
	@JsonProperty("creditCardVendors")
	public List<CreditCardVendorBean> getCreditCardVendors();
	
	/**
	 * <p>Fetches zeroTransactionPaymentMessage for the checkoutdetail</p>
	 * 
	 * @return String - zeroTransactionPaymentMessage for the checkout detail
	 */
	@JsonProperty("zeroTransactionPaymentMessage")
	public String getZeroTransactionPaymentMessage();
	
	/**
	 * <p>Fetches applicationLearnMoreLink for the checkoutdetail</p>
	 * 
	 * @return String - applicationLearnMoreLink for the checkout detail
	 */
	@JsonProperty("applicationLearnMoreLink")
	public String getApplicationLearnMoreLink();
	
	/**
	 * <p>Fetches smartPayModalHeadline for the checkoutdetail</p>
	 * 
	 * @return String - smartPayModalHeadline for the checkout detail
	 */
	@JsonProperty("smartPayModalHeadline")
	public String getSmartPayModalHeadline();
	
	/**
	 * <p>Fetches smartPayModalContent for the checkoutdetail</p>
	 * 
	 * @return String - smartPayModalContent for the checkout detail
	 */
	@JsonProperty("smartPayModalContent")
	public String getSmartPayModalContent();
	
	/**
	 * <p>Fetches cvvModalHeadline for the checkoutdetail</p>
	 * 
	 * @return String - cvvModalHeadline for the checkout detail
	 */
	@JsonProperty("cvvModalHeadline")
	public String getCvvModalHeadline();
	
	/**
	 * <p>Fetches cvvModalImage for the checkoutdetail</p>
	 * 
	 * @return String - cvvModalImage for the checkout detail
	 */
	@JsonProperty("cvvModalImage")
	public String getCvvModalImage();
	
	/**
	 * <p>Fetches cvvModalImageAltText for the checkoutdetail</p>
	 * 
	 * @return String - cvvModalImageAltText for the checkout detail
	 */
	@JsonProperty("cvvModalImageAltText")
	public String getCvvModalImageAltText();
	
	/**
	 * <p>Fetches paymentNotification for the checkoutdetail</p>
	 * 
	 * @return String - paymentNotification for the checkout detail
	 */
	@JsonProperty("paymentNotification")
	public String getPaymentNotification();

	/**
	 * <p>Fetches cartDetailComponentVersion for the checkoutdetail</p>
	 *
	 * @return String - cartDetailComponentVersion for the checkout detail
	 */
	@JsonProperty("cartDetailComponentVersion")
	public String getCartDetailComponentVersion();
	
	/**
	 * <p>Fetches componentVersion for the checkoutdetail</p>
	 *
	 * @return String - componentVersion for the checkout detail
	 */
	@JsonProperty("componentVersion")
	public String getComponentVersion();
	
	/**
	 * <p>Fetches guestCheckoutPossibleMessage for the checkoutdetail</p>
	 *
	 * @return String - guestCheckoutPossibleMessage for the checkout detail
	 */
	@JsonProperty("guestCheckoutPossibleMessage")
	public String getGuestCheckoutPossibleMessage();
	
	/**
	 * <p>Fetches guestCheckoutNotPossibleMessage for the checkoutdetail</p>
	 *
	 * @return String - guestCheckoutNotPossibleMessage for the checkout detail
	 */
	@JsonProperty("guestCheckoutNotPossibleMessage")
	public String getGuestCheckoutNotPossibleMessage();
	
	/**
	 * <p>Fetches onlyLoginAndGuestCheckoutPossibleMessage for the checkoutdetail</p>
	 *
	 * @return String - onlyLoginAndGuestCheckoutPossibleMessage for the checkout detail
	 */
	@JsonProperty("onlyLoginAndGuestCheckoutPossibleMessage")
	public String getOnlyLoginAndGuestCheckoutPossibleMessage();
	
	/**
	 * <p>Fetches onlyLoginPossibleMessage for the checkoutdetail</p>
	 *
	 * @return String - onlyLoginPossibleMessage for the checkout detail
	 */
	@JsonProperty("onlyLoginPossibleMessage")
	public String getOnlyLoginPossibleMessage();
	
	/**
	 * <p>Fetches shippingDisclaimerMessage for the checkoutdetail</p>
	 *
	 * @return String - shippingDisclaimerMessage for the checkout detail
	 */
	@JsonProperty("shippingDisclaimerMessage")
	public String getShippingDisclaimerMessage();
	
	/** <p>Fetches shippingOptionsLink for the checkoutdetail</p>
	 * 
	 * @return String - shippingOptionsLink for the checkout process
	 */
	@JsonProperty("byPassPayPalMigrationCheck")
	public String getByPassPayPalMigrationCheck();

	/** <p>Fetches paypalBillingAgreementDescription for the checkoutdetail</p>
	 *
	 * @return String - paypalBillingAgreementDescription for the checkoutdetail
	 */
	@JsonProperty("paypalBillingAgreementDescription")
	public String getPaypalBillingAgreementDescription();

	/** <p>Fetches paypalButtonLabel for the checkoutdetail</p>
	 *
	 * @return String - paypalButtonLabel for the checkoutdetail
	 */
	@JsonProperty("paypalButtonLabel")
	public String getPaypalButtonLabel();

	/** <p>Fetches paypalButtonShape for the checkoutdetail</p>
	 *
	 * @return String - paypalButtonShape for the checkoutdetail
	 */
	@JsonProperty("paypalButtonShape")
	public String getPaypalButtonShape();

	/** <p>Fetches paypalButtonColor for the checkoutdetail</p>
	 *
	 * @return String - paypalButtonColor for the checkoutdetail
	 */
	@JsonProperty("paypalButtonColor")
	public String getPaypalButtonColor();

	/** <p>Fetches paypalButtonSize for the checkoutdetail</p>
	 *
	 * @return String - paypalButtonSize for the checkoutdetail
	 */
	@JsonProperty("paypalButtonSize")
	public String getPaypalButtonSize();

	/** <p>Fetches disableIntangiblePaypal for the checkoutdetail</p>
	 *
	 * @return String - disableIntangiblePaypal for the checkoutdetail
	 */
	@JsonProperty("disableIntangiblePaypal")
	public String getDisableIntangiblePaypal();

	/** <p>Fetches disableStore1Paypal for the checkoutdetail</p>
	 *
	 * @return String - disableStore1Paypal for the checkoutdetail
	 */
	@JsonProperty("disableStore1Paypal")
	public String getDisableStore1Paypal();

	/**
	 * <p>Fetches vasStandalonePagePath for the checkoutdetail</p>
	 * 
	 * @return String - vasStandalonePagePath for the checkout detail
	 */
	@JsonProperty("vasStandalonePagePath")
	public String getVasStandalonePagePath();

	/** <p>Fetches hideCheckoutLoginStep for the checkoutdetail</p> *
	* @return String - hideCheckoutLoginStep for the checkoutdetail
	*/
	@JsonProperty("hideCheckoutLoginStep")
	public boolean getHideCheckoutLoginStep();

	/**
	 * <p>Fetches disableCaptcha </p>
	 *
	 * @return String - disableCaptcha
	 */
	@JsonProperty("disableCaptcha")
	public String getDisableCaptcha();

	/**
	 * 	 * <p>Fetches twoFAInfoLink </p>
	 *
	 * @return the twoFAInfoLink
	 */
	@JsonProperty("twoFAInfoLink")
	public String getTwoFAInfoLink();

	/**
	 * <p>Fetches smartPayDisclaimer for the checkoutdetail</p>
	 *
	 * @return String - smartPayDisclaimer for the checkout detail
	 */
	@JsonProperty("smartPayDisclaimer")
	public String getSmartPayDisclaimer();

	@JsonProperty("activationSupportKitTitle")
	public String getActivationSupportKitTitle();

	@JsonProperty("activationSupportKitSubTitle")
	public String getActivationSupportKitSubTitle();

	@JsonProperty("audioDeviceIconPath")
	public String getAudioDeviceIconPath();

	@JsonProperty("audioDeviceTitle")
	public String getAudioDeviceTitle();

	@JsonProperty("braileIconPath")
	public String getBraileIconPath();

	@JsonProperty("braileIconTitle")
	public String getBraileIconTitle();

	@JsonProperty("dyslexiaIconPath")
	public String getDyslexiaIconPath();

	@JsonProperty("dyslexiaIconTitle")
	public String getDyslexiaIconTitle();

	@JsonProperty("qrCodeIconPath")
	public String getQrCodeIconPath();

	@JsonProperty("qrCodeIconTitle")
	public String getQrCodeIconTitle();

	@JsonProperty("accessibilityKitIconPath")
	public String getAccessibilityKitIconPath();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("modalHeading")
	public String getModalHeading();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("codeSentViaText")
	public String getCodeSentViaText();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("codeSentViaEmailText")
	public String getCodeSentViaEmailText();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("didNotGetCodeText")
	public String getDidNotGetCodeText();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("doNotHaveAccessText")
	public String getDoNotHaveAccessText();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("customerCareText")
	public String getCustomerCareText();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("stillUnableToRecieveCodeText")
	public String getStillUnableToRecieveCodeText();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("frequentDialedNumbersText")
	public String getFrequentDialedNumbersText();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("phoneNumberOneText")
	public String getPhoneNumberOneText();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("phoneNumberTwoText")
	public String getPhoneNumberTwoText();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("qualifyingRulesText")
	public String getQualifyingRulesText();


	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("frequentDialedNumberQualifyingRulesText")
	public String getFrequentDialedNumberQualifyingRulesText();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("ruleOne")
	public String getRuleOne();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("ruleTwo")
	public String getRuleTwo();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("ruleOneInTwo")
	public String getRuleOneInTwo();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("ruleTwoInTwo")
	public String getRuleTwoInTwo();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("ruleThreeInTwo")
	public String getRuleThreeInTwo();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("ruleFourInTwo")
	public String getRuleFourInTwo();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("ruleFiveInTwo")
	public String getRuleFiveInTwo();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("stCCNumber")
	public String getSTCCNumber();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("tfCCNumber")
	public String getTFCCNumber();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("tbvzCCNumber")
	public String getTbvzCCNumber();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("migrationAccessCodeText")
	public String getMigrationAccessCodeText();

	/**
	 * <p>Fetches Safe pass code modal text for the checkoutdetail</p>
	 *
	 * @return String -Safe pass code modal text for the checkout detail
	 */
	@JsonProperty("migrationAccessInputText")
	public String getMigrationAccessInputText();

}
