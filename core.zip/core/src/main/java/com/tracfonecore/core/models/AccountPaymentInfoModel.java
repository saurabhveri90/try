/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.SocialMediaAccountsBean;

public interface AccountPaymentInfoModel extends ComponentExporter {

	@JsonProperty("positionAccountAndPayment")
	public String getPositionAccountAndPayment();
	
	@JsonProperty("positionAccountNavigation")
	public String getPositionAccountNavigation();
	
	@JsonProperty("notificationCardHeading")
	public String getNotificationCardHeading();
	
	@JsonProperty("notificationCardSubheading")
	public String getNotificationCardSubheading();
	
	@JsonProperty("enableNotification")
	public String getEnableNotification();
	
	@JsonProperty("socialMediaAccounts")
	public List<SocialMediaAccountsBean> getSocialMediaAccounts();
	
	@JsonProperty("declarationText")
	public String getDeclarationText();
	
	@JsonProperty("submitRequestLink")
	public String getSubmitRequestLink();

	@JsonProperty("yourPrivacyChoicesLink")
	public String getYourPrivacyChoicesLink();
	
	@JsonProperty("checkStatusLink")
	public String getCheckStatusLink();
	
	@JsonProperty("openNewTabSubmitRequestLink")
	public String getOpenNewTabSubmitRequestLink();

	@JsonProperty("openNewTabYourPrivacyChoicesLink")
	public String getOpenNewTabYourPrivacyChoicesLink();
	
	@JsonProperty("openNewTabCheckStatusLink")
	public String getOpenNewTabCheckStatusLink();

	@JsonProperty("checkoutDetailComponentVersion")
	public String getCheckoutDetailComponentVersion();

	@JsonProperty("autoRefillEnrolledHeading")
	public String getAutoRefillEnrolledHeading();

	@JsonProperty("autoRefillEnrolledDescription")
	public String getAutoRefillEnrolledDescription();

	@JsonProperty("autoRefillEnrolledButtonName")
	public String getAutoRefillEnrolledButtonName();

	@JsonProperty("autoRefillEnrolledLink")
	public String getAutoRefillEnrolledLink();

	@JsonProperty("autoRefillNotEnrolledHeading")
	public String getAutoRefillNotEnrolledHeading();

	@JsonProperty("autoRefillNotEnrolledDescription")
	public String getAutoRefillNotEnrolledDescription();

	@JsonProperty("autoRefillNotEnrolledButtonName")
	public String getAutoRefillNotEnrolledButtonName();

	@JsonProperty("autoRefillNotEnrolledLink")
	public String getAutoRefillNotEnrolledLink();
	
	@JsonProperty("ildEnrolledHeading")
	public String getIldEnrolledHeading();

	@JsonProperty("ildEnrolledDescription")
	public String getIldEnrolledDescription();

	@JsonProperty("ildEnrolledButtonName")
	public String getIldEnrolledButtonName();

	@JsonProperty("ildEnrolledLink")
	public String getIldEnrolledLink();
}
