package com.tracfonecore.core.models;

import java.util.List;
import java.util.Map;

import org.osgi.annotation.versioning.ProviderType;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.adobe.cq.export.json.ComponentExporter;
import com.tracfonecore.core.beans.PhoneSpecsBean;

@ProviderType
public interface PhoneSpecsModel extends ComponentExporter{
	 /**
     * Get product characteristics of the product from API(i.e. description, name)
     * @return Ratings
     */
	public List<PhoneSpecsBean> getSelectedProductSpecs() ;
	public String getResourcePath();
	public List<PhoneSpecsBean> getProductSpecs() ;

	@JsonProperty("heading")
	public String getHeading();
	
	@JsonProperty("marketingIds")
	public String getMarketingIds();
	
	/**
	 * <p>Fetches ctaTextShowMore</p>
	 *
	 * @return String - ctaTextShowMore
	 */
	@JsonProperty("ctaTextShowMore")
	public String getCtaTextShowMore();
	/**
	 * <p>Fetches ctaTextShowLess</p>
	 *
	 * @return String - ctaTextShowLess
	 */
	@JsonProperty("ctaTextShowLess")
	public String getCtaTextShowLess();
	
	/**
	 * <p>Fetches addRteComponent</p>
	 * 
	 * @return boolean - addRteComponent
	 */
	@JsonProperty("addRteComponent")
	public boolean isAddRteComponent();
	
	/**
	 * <p>Fetches addXFComponent</p>
	 * 
	 * @return boolean - addXFComponent
	 */
	@JsonProperty("addXFComponent")
	public boolean isAddXFComponent();
	
	/**
	 * <p>Fetches the export child items</p>
	 *
	 * @return Map<String, ? extends ComponentExporter> - the export child items
	 */
	public Map<String, ? extends ComponentExporter> getItems();
	/**
	 * <p>Fetches the author path</p>
	 *
	 * @return String - authorPath
	 */
	public String getAuthorPath();
	/**
	 * <p>Fetches the language</p>
	 *
	 * @return String - language
	 */
	public String getLanguage();
	/**
	 * <p>Fetches the home page level</p>
	 *
	 * @return String - homePageLevel
	 */
	public int getHomePageLevel();
	/**
	 *<p>Fetches layout</p>
	 *
	 * @return the layout
	 */
	@JsonProperty("layout")
	public String getLayout();
	/**
	 *<p>Fetches useNameForSpecs</p>
	 *
	 * @return the useNameForSpecs
	 */
	public boolean isUseNameForSpecs();
	
	/**
	 *<p>Fetches hideSpecHeading</p>
	 *
	 * @return the hideSpecHeading
	 */
	public boolean getHideSpecHeading();
	
	/**
	 *<p>Fetches 2 Column split</p>
	 *
	 * @return the splitRowColumn
	 */
	public boolean getSplitRowColumn();

	/**
	 *<p>Fetches if the spect value will be a heading</p>
	 *
	 * @return the specValAsTitle
	 */
	public boolean getSpecValAsTitle();
	
}
