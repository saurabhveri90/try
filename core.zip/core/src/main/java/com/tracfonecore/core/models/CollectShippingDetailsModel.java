/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Multi-Links} Sling Model used for the
 * {@code /apps/tracfone-core/components/spa/commerce/collectShippingDetails}
 * component.
 */
public interface CollectShippingDetailsModel extends ComponentExporter {
	/**
	 * <p>Fetches shipping title</p>
	 * 
	 * @return String - shippingTitle
	 */
	@JsonProperty("shippingTitle")
	public String getShippingTitle();
	
	/**
	 * <p>Fetches shipping summary</p>
	 * 
	 * @return String - shippingSummary
	 */
	@JsonProperty("shippingSummary")
	public String getShippingSummary();
	
}
