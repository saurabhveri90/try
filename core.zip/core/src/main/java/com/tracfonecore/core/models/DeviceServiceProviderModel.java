package com.tracfonecore.core.models;

import org.apache.sling.api.resource.Resource;
import org.osgi.annotation.versioning.ProviderType;

import com.adobe.cq.export.json.ComponentExporter;

/**
 * 
 * @author HCL Defines the {@code Device Service Provider} Sling Model used for the
 *         {@code /apps/tracfone-core/components/commerce/deviceServiceProvider}
 *         component.
 *
 */

@ProviderType
public interface DeviceServiceProviderModel extends ComponentExporter {

	/**
	 * Get the headerText
	 * 
	 * @return String - headerText
	 */
	public String getHeaderText();

	/**
	 * Get the summary
	 * 
	 * @return String - summary
	 */
	public String getSummary();

	/**
	 * Get the radioOptions
	 * 
	 * @return String - radioOptions
	 */
	public Resource getRadioOptions();

	/**
	 * Get the Privacy Policy Info Label
	 *
	 * @return String - privacyPolicy
	 */
	public String getPrivacyPolicy();

	/**
	 * Get the button Label
	 * 
	 * @return String - buttonLabel
	 */
	public String getButtonLabel();

	/**
	 * Get the cspInputFieldPlaceholder
	 * 
	 * @return String - cspInputFieldPlaceholder
	 */
	public String getCspInputFieldPlaceholder();

	/**
	 * Get the cspFieldDescription
	 * 
	 * @return String - cspFieldDescription
	 */
	public String getCspFieldDescription();

	/**
	 * Get the helpLinkLabel
	 * 
	 * @return String - helpLinkLabel
	 */
	public String getHelpLinkLabel();

	/**
	 * Get the helpLinkModalId
	 * 
	 * @return String - helpLinkModalId
	 */
	public String getHelpLinkModalId();

	/**
	 * Get the zipInputFieldPlaceholder
	 * 
	 * @return String - zipInputFieldPlaceholder
	 */
	public String getZipInputFieldPlaceholder();

	/**
	 * Get the zipInputFieldDescription
	 * 
	 * @return String - zipInputFieldDescription
	 */
	public String getZipInputFieldDescription();
	
	/**
	 * Get the serviceProviderMappingJson
	 * 
	 * @return String - serviceProviderMappingJson
	 */
	public String getServiceProviderMappingJson();
	
	/**
	 * Get the deviceType
	 * 
	 * @return String - deviceType
	 */
	public String getDeviceType();
	
	/**
	 * Get the hotFlashModalId
	 * 
	 * @return String - hotFlashModalId
	 */
	public String getHotFlashModalId();

	/**
	 * Get the tmoModalId
	 * 
	 * @return String - tmoModalId
	 */
	public String getTmoModalId();
	

}
