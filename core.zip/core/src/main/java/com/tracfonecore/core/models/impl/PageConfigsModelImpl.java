/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.via.ResourceSuperType;
import org.apache.sling.settings.SlingSettingsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.PageConfigs;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;
import com.tracfonecore.core.utils.LocaleUtil;
import com.tracfonecore.core.services.TracfoneValueMappingConfigService;

@Model(adaptables = { Resource.class,
		SlingHttpServletRequest.class }, adapters = {
				PageConfigs.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class PageConfigsModelImpl implements PageConfigs {

	private static final Logger LOGGER = LoggerFactory.getLogger(PageConfigsModelImpl.class);

	/* Robots Meta Tags */
	@Inject
	@Via(type = ResourceSuperType.class)
	private String noIndex;

	@Inject
	@Via(type = ResourceSuperType.class)
	private String noFollow;

	@Inject
	@Via(type = ResourceSuperType.class)
	private String unavailableAfter;

	@Inject
	@Via(type = ResourceSuperType.class)
	private String canonicalURL;
	
	@Inject
	@Via(type = ResourceSuperType.class)
	private String seoTitle;

	private String title;

	private String description;
	
	@Inject
	@Via(type = ResourceSuperType.class)
	private String seoDescription;

	private List<String> hrefLangList = Collections.emptyList();

	private Map<String,String> map;
	
	private Resource descriptionCompNode;



	/* Open Graph Tags */

	@Inject
	@Via(type = ResourceSuperType.class)
	private String ogTitle;

	@Inject
	@Via(type = ResourceSuperType.class)
	private String ogDescription;

	@Inject
	@Via(type = ResourceSuperType.class)
	private String ogImage;

	@Inject
	@Via(type = ResourceSuperType.class)
	private String ogType;

	private String ogLocale;

	private String ogAlternateLocale;

	private String ogURL;

	private String ogSiteName;

	/* Twitter cards */

	@Inject
	@Via(type = ResourceSuperType.class)
	private String twitterCard;

	@Inject
	@Via(type = ResourceSuperType.class)
	private String twitterTitle;

	@Inject
	@Via(type = ResourceSuperType.class)
	private String twitterDescription;

	@Inject
	@Via(type = ResourceSuperType.class)
	private String twitterImage;

	private String twitterURL;

	private String twitterSite;

	/* End Twitter Cards */

	// Inject the Links multifield
	@Inject
	@Via(type = ResourceSuperType.class)
	private Resource socialAccount; 

	@Inject
	@Via(type = ResourceSuperType.class)
	private Resource legalName; 

	private String fbAppId;
	
	@Inject
	@Via(type = ResourceSuperType.class)
	@Default(values="false") 
	private String isLocatorPage;

	private String robots;

	private List<String> robotsList;
	
	private String[] dynamicDescriptionConfig;
	
	private Boolean useDynamicSeoTitles;
	
	private Boolean useDynamicSeoDesc;

	@Inject
	@Via(type = ResourceSuperType.class)
	private String searchTypeFacet;

	private String searchFacetDefaultValue;

	private String language;

	private String productPartNumber;

	private String productCategoryType;

	@SlingObject
	private Resource resource;

	@SlingObject
	private ResourceResolver resourceResolver;

	@Inject
	private SlingHttpServletRequest request;

	@OSGiService

	private ApplicationConfigService appConfigService;
	@Inject
	private TracfoneValueMappingConfigService tracfoneValueMappingConfigService;

	@Inject
	private Page currentPage;

	private String domainName;
	@Inject
	private SlingSettingsService slingSettingsService;
	// constants
	private static final String TWITTER_SITE = "twittersite";
	private static final String FB_APP_ID = "fbAppId";
	private static final String OG_SITE_NAME = "ogSiteName";
	private static final String UTC_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS";
	private static final String DD_MMM_FORMAT =  "dd-MMM-yyyy HH:mm:ss";
	private static final String SEARCH_CATEGORY_DEFAUTL_VALUE = "searchCategoryDefaultValue";
	private static final String SEARCH_CATEGORY_TYPE = "searchCategoryType";
	private static final String DEFAULT = "default";
	private static final String PRODUCT_PART_NUMBER = "partNo";
	private static final String PRODUCT_CATEGORY_TYPE = "categorytype";
	private static final String USE_DYNAMIC_SEO_TITLES = "useDynamicSeoTitles";
	private static final String USE_DYNAMIC_SEO_DESC = "useDynamicSeoDesc";
	private static final String DYNAMIC_DESC_CONF = "dynamicDescConf";
	
	private static final String DYNAMIC_DESC_CONF_STRING_SPLITTER =  "~~";
	
	@PostConstruct
	private void initModel() {

		LOGGER.debug("Entering Init method");
		String pagePath = StringUtils.EMPTY;

			String reqUrl=request.getRequestURI();
			if(Boolean.TRUE.equals(ApplicationUtil.isInternalLink(reqUrl)) && reqUrl.indexOf(ApplicationConstants.HTML_EXTENSION) == -1)
			{
				reqUrl = reqUrl + ApplicationConstants.HTML_EXTENSION;
			}
			LOGGER.info("Request URL : {}", request.getResourceResolver().map(reqUrl));
			domainName =  ApplicationUtil.getDomainNameinURL(request.getResourceResolver().map(reqUrl));
			if (null != resource) {
				pagePath = currentPage.getPath();
				LOGGER.info("CurrentPage Path: {}", pagePath);
				
				this.setTitle(ApplicationUtil.getLimitedStringValue(currentPage.getTitle(), ApplicationConstants.META_TITLE_LIMIT, 
						ApplicationConstants.BLANK_SPACE));	
				this.setDescription(ApplicationUtil.getLimitedStringValue(currentPage.getDescription(), ApplicationConstants.META_DESC_LIMIT, 
						ApplicationConstants.DOT));

				setImagePath(pagePath);

				String language = LocaleUtil.getLanguageFromPath(pagePath);
				String country = LocaleUtil.getCountryFromPath(pagePath);
				String localeWithCountry = StringUtils.EMPTY;

				LOGGER.debug("Getting language from page URL {}", language);
				LOGGER.debug("Getting country from page URL {}", country);

				if (StringUtils.isBlank(country))
					country = ApplicationConstants.COUNTRY_US;

				if (StringUtils.isNotEmpty(language))
					localeWithCountry = Locale.forLanguageTag(language).toString() + ApplicationConstants.UNDERSCORE
					+ LocaleUtil.getCountryUpperCase(country);

				LOGGER.debug("LocaleWithCountry:: {}", localeWithCountry);

				map = getLanguageNodes(pagePath,language);
				
				if(seoTitle != null) {
					this.setSeoTitle(ApplicationUtil.getLimitedStringValue(seoTitle, ApplicationConstants.META_TITLE_LIMIT, 
							ApplicationConstants.BLANK_SPACE));
				}			
				if(seoDescription != null) {
					this.setSeoDescription(ApplicationUtil.getLimitedStringValue(seoDescription, ApplicationConstants.META_DESC_LIMIT, 
							ApplicationConstants.DOT));
				} else if(this.getDynamicDescriptionConfig() != null && this.getDynamicDescriptionConfig().length > 0) {
							getProductPageDescription(currentPage);
				} else {
					LOGGER.info("Issue while fetching dynamic description. Please check Site Root page for Dynamic Description Configs.");
				}

				setTitleAndDesc();
				this.setOgLocale(localeWithCountry);
				this.setSearchTypeFacet();
				this.setLanguage(localeWithCountry);
				setProductDetails();

			}


			setRobotsTag();

			createCanonicalURL(pagePath);
			this.setTwitterURL(this.getCanonicalURL());
			this.setOgURL(this.getCanonicalURL());
			LOGGER.debug("CanonicalURL :{}", this.getCanonicalURL());

			LOGGER.debug("Unavailable date {}",unavailableAfter);

			this.setUnavailableAfter(formatDate(unavailableAfter));
			
			LOGGER.debug("Exiting Init method");
		
	}
	
	/**
	 * <p> This method is used to update product page description based on the component on page</p>
	 * @param currentPage
	 */
	private void getProductPageDescription(Page currentPage) {

		String compDescription = null;
		String templatePath = "";
		String resourcePath = "";
		String propertyName = "";

		for (int i = 0; i < this.getDynamicDescriptionConfig().length; i++) {
			if (this.getDynamicDescriptionConfig()[i]
					.contains(currentPage.getProperties().get(ApplicationConstants.CQ_TEMPLATE, String.class))) {
				templatePath = this.getDynamicDescriptionConfig()[i].split(DYNAMIC_DESC_CONF_STRING_SPLITTER)[0];
				resourcePath = this.getDynamicDescriptionConfig()[i].split(DYNAMIC_DESC_CONF_STRING_SPLITTER)[1];
				propertyName = this.getDynamicDescriptionConfig()[i].split(DYNAMIC_DESC_CONF_STRING_SPLITTER)[2];
				LOGGER.debug("Method getProductPageDescription - Dynamic Description Config: {}", this.getDynamicDescriptionConfig()[i]);
			}
		}

		if (currentPage != null
				&& currentPage.getProperties().get(ApplicationConstants.CQ_TEMPLATE, String.class).equalsIgnoreCase(templatePath)) {

			Resource currentResource = currentPage.getContentResource();

			if (componentExists(resourcePath, currentResource)) {
				compDescription = this.descriptionCompNode.getValueMap().get(propertyName, String.class);
			}
		}
		
		if(compDescription != null) {
			this.setSeoDescription(ApplicationUtil.getLimitedStringValue(compDescription,
					ApplicationConstants.META_DESC_LIMIT, ApplicationConstants.DOT));
		}
	}
	
	/**
	 * Recursive function to iterate through content resources
	 * @param resourceType
	 * @param resource
	 * @return boolean
	 */
	boolean componentExists(String resourceType, Resource resource) {

		if (resource == null)
			return false;

		if (resource.isResourceType(resourceType)) {
			this.descriptionCompNode = resource;
			return true;
		} else {
			for (Resource child : resource.getChildren()) {
				boolean val = componentExists(resourceType, child);
				if (val) {
					return true;
				}
			}
		}
		
		return false;
	}

	/**
	 * <p> This method is used to set the OG title, OG description , twitter title, twitter description properties for a page</p>
	 * 
	 */
	private void setTitleAndDesc()
	{
		LOGGER.debug("Entering setTitleAndDesc method ");
		if (StringUtils.isEmpty(ogTitle)) {
			this.setOgTitle(StringUtils.isNotBlank(this.getTitle()) ? this.getTitle() : currentPage.getTitle());
		}
		if (StringUtils.isEmpty(ogDescription) && StringUtils.isNotEmpty(currentPage.getDescription())) {
			this.setOgDescription(StringUtils.isNotBlank(this.getDescription()) ? this.getDescription() : currentPage.getDescription());
		}
		if (StringUtils.isEmpty(twitterTitle)) {

			this.setTwitterTitle(StringUtils.isNotBlank(this.getTitle()) ? this.getTitle() : ApplicationUtil.getLimitedStringValue(currentPage.getTitle(),ApplicationConstants.TWITTER_TITLE_LIMIT,ApplicationConstants.BLANK_SPACE));
		}
		if (StringUtils.isEmpty(twitterDescription) && StringUtils.isNotEmpty(currentPage.getDescription())) {
			this.setTwitterDescription(StringUtils.isNotBlank(this.description) ? this.getDescription() : ApplicationUtil.getLimitedStringValue(currentPage.getDescription(),ApplicationConstants.TWITTER_DESC_LIMIT,ApplicationConstants.DOT));

		}
		LOGGER.debug("Exiting setTitleAndDesc method ");
	}

	/**
	 * <p> This method is used to set the OG Image and twitte iamge properties for a page</p>
	 * @param pagePath- This is the page path
	 */
	private void setImagePath(String pagePath)
	{
		LOGGER.debug("Entering setImagePath method ");
		/*  First will get the image from authored path, if not present then get the thumbnail image and if not present then get it from OSGI Configuration  */
		if (StringUtils.isNotEmpty(twitterImage) && ApplicationUtil.isInternalLink(twitterImage)) {
			twitterImage = domainName + twitterImage;
		}
		if (StringUtils.isNotEmpty(ogImage) && ApplicationUtil.isInternalLink(ogImage)) {
			ogImage = domainName + ogImage;
		}

		if (StringUtils.isEmpty(twitterImage) || StringUtils.isEmpty(ogImage))
		{
			getThumbnailImage(pagePath);
		}
		if (StringUtils.isEmpty(twitterImage) && null != appConfigService) {
			String[] value = appConfigService.getTwitterImagePath();
			if (null != value)
				this.setTwitterImage(domainName + ConfigurationUtil.getConfigValue(value,
						CommerceUtil.getBrandValue(currentPage, appConfigService.getHomePageLevel())));
		}
		if (StringUtils.isEmpty(ogImage) && null != appConfigService) {
			String[] value = appConfigService.getOGImagePath();
			if (null != value)
				this.setOgImage(domainName + ConfigurationUtil.getConfigValue(value,
						CommerceUtil.getBrandValue(currentPage, appConfigService.getHomePageLevel())));
		}
		LOGGER.debug("Exiting setImagePath method ");
	}
	/**
	 * <p> This method is used to set the Robots tag properties for a page</p>
	 */
	private void setRobotsTag()
	{
		LOGGER.debug("Entering setRobotsTag method ");
		robotsList = new ArrayList<String>();
		if (ApplicationConstants.YES.equalsIgnoreCase(noIndex))
			robotsList.add(ApplicationConstants.NO_INDEX);
		else
			robotsList.add(ApplicationConstants.INDEX);
		if (ApplicationConstants.YES.equalsIgnoreCase(noFollow))
			robotsList.add(ApplicationConstants.NO_FOLLOW);
		else
			robotsList.add(ApplicationConstants.FOLLOW);


		this.setRobots(String.join(ApplicationConstants.COMMA_AND_SPACE, robotsList));

		LOGGER.debug("Exiting setRobotsTag method ");
	}
	/**
	 * <p> This method is used to read the thumbnail image path from the page properties of a page</p>
	 * @param pagePath -  path of the page
	 */
	private void getThumbnailImage(String pagePath)
	{
		LOGGER.debug("Entering getThumbnailImage method ");
		Resource getResource = null;
		if (null != pagePath && pagePath.lastIndexOf('.') != -1)
			getResource = resourceResolver.getResource(
					pagePath.substring(0, pagePath.lastIndexOf('.')) + ApplicationConstants.JCR_CONTENT_IMAGE);
		else
			getResource = resourceResolver.getResource(pagePath + ApplicationConstants.JCR_CONTENT_IMAGE);

		if (null != getResource) {
			ValueMap properties = getResource.adaptTo(ValueMap.class);

			if (null != properties && null != properties.get(ApplicationConstants.FILEREFERENCE)) {

				if (StringUtils.isEmpty(twitterImage))
					this.setTwitterImage(
							domainName + properties.get(ApplicationConstants.FILEREFERENCE).toString());

				if (StringUtils.isEmpty(ogImage))
					this.setOgImage(domainName + properties.get(ApplicationConstants.FILEREFERENCE).toString());
			}
		}
		LOGGER.debug("Exiting getThumbnailImage method ");
	}

	/**
	 * <p> This method is used to generate the canonical URL tag value for a page</p>
	 * 
	 * @param pagePath -  page path
	 */
	private void createCanonicalURL(String pagePath)
	{
		LOGGER.debug("Entering createCanonicalURL method ");
		if (StringUtils.isNotEmpty(canonicalURL)) {
			canonicalURL = ApplicationUtil.getUrlWithoutParameters(canonicalURL);
			if (ApplicationUtil.isInternalLink(canonicalURL)) {
				canonicalURL = ApplicationUtil.getUrlWithoutSelectors(canonicalURL);
				this.setCanonicalURL(
						domainName + getResolveURL(canonicalURL));
			}
		} else if (currentPage != null) {
			this.setCanonicalURL(domainName + getResolveURL(pagePath));
		} else {
			this.setCanonicalURL(
					domainName + getResolveURL(canonicalURL));
		}
		LOGGER.debug("Exiting createCanonicalURL method ");
	}
	/**
	 * <p> This method is used to get all the language nodes  under the root node</p>
	 * @param pagePath -  this is the current page path
	 * @param languageName - language node of current page
	 * @return - Map of the language nodes
	 */
	private Map<String,String> getLanguageNodes(String pagePath, String languageName)
	{
		LOGGER.debug("Entering getLanguageNodes method ");
		String [] nodesList= pagePath.split("/");
		StringBuilder rootNodePath = new StringBuilder();
		StringBuilder contentPath = new StringBuilder();
		String countryName = "";



		Map<String,String> localeCountryMap = new HashMap<String, String>();

		for(int i=1;i<3;i++)
		{
			rootNodePath.append(ApplicationConstants.SLASH).append(nodesList[i]);
		}

		for(int i=5;i<nodesList.length;i++)
		{
			contentPath.append(ApplicationConstants.SLASH).append(nodesList[i]);
		}

		Resource rootResource = resourceResolver.getResource(rootNodePath.toString());
		Iterator<Resource> it = rootResource.listChildren();

		while (it.hasNext()) {

			Resource childResource = it.next();
			if(!childResource.getName().equals(ApplicationConstants.LANGUAGE_MASTERS) &&
					!childResource.getName().equals(ApplicationConstants.JCRCONTENT))
			{
				countryName = childResource.getName();
				String path = rootNodePath.toString()+(ApplicationConstants.SLASH)+(countryName);
				Resource countryResource = resourceResolver.getResource(path);
				Iterator<Resource> itLanguage = countryResource.listChildren();
				localeCountryMap = createCountryLocaleMap(itLanguage, countryName, languageName, path, contentPath.toString());

			}
		}			
		getPropertiesFromRootPage(pagePath);

		LOGGER.debug("Exiting getLanguageNodes method ");
		return localeCountryMap;
	}

	/**
	 * <p> This method is used to get the page properties of the root page</p>
	 * @param pagePath -  current page path
	 */
	private void getPropertiesFromRootPage(String pagePath)
	{
		LOGGER.debug("Entering getPropertiesFromRootPage method ");
		String rootNode = LocaleUtil.getSiteNameFromPath(pagePath);
		String rootNodePath = ApplicationConstants.INTERNAL_LINK_PATH+rootNode;

		Resource getResource = resourceResolver.getResource(rootNodePath);

		PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
		Page rootPage = pageManager.getContainingPage(getResource);

		ValueMap properties = rootPage.getProperties();
		if(properties != null)
		{
			this.setOgSiteName(properties.get(OG_SITE_NAME, String.class));
			this.setFbAppId(properties.get(FB_APP_ID, String.class));
			this.setTwitterSite(properties.get(TWITTER_SITE, String.class));
			this.setSearchFacetDefaultValue(properties.get(SEARCH_CATEGORY_DEFAUTL_VALUE, String.class));
			this.setDynamicDescriptionConfig(properties.get(DYNAMIC_DESC_CONF, String[].class));
			this.setUseDynamicSeoTitles(properties.get(USE_DYNAMIC_SEO_TITLES, Boolean.class));
			this.setUseDynamicSeoDesc(properties.get(USE_DYNAMIC_SEO_DESC, Boolean.class));
		}

		LOGGER.debug("Exiting getPropertiesFromRootPage method ");		
	}

	/**
	 * This method is used to format the date
	 * @param date
	 * @return- formatted String date
	 */
	private String formatDate(String date)
	{
		LOGGER.debug("Entering formatDate method ");		

		String newDate = StringUtils.EMPTY;
		if(date != null)
		{
			if(date.indexOf('+')!= -1)
			{
				date = date.split("\\+")[0];
			}
			DateTimeFormatter dateFormatter
			= DateTimeFormatter.ofPattern(UTC_DATE_FORMAT);

			DateTimeFormatter dateFormatterNew
			= DateTimeFormatter.ofPattern(DD_MMM_FORMAT);

			LocalDateTime ldateTime = LocalDateTime.parse(date, dateFormatter);

			newDate = dateFormatterNew.format(ldateTime);
		}		

		LOGGER.debug("Exiting formatDate method ");
		return newDate;
	}

	/**
	 * This method is used to get the resolved URL
	 * @param url - raw url
	 * @return -  resolved url
	 */
	private  String getResolveURL(String url)
	{
		LOGGER.debug("Entering getResolveURL method ");

		if(Boolean.TRUE.equals(ApplicationUtil.isInternalLink(url)) && url.indexOf(ApplicationConstants.HTML_EXTENSION) == -1)
		{
			url = url + ApplicationConstants.HTML_EXTENSION;
		}
		url = request.getResourceResolver().map(url);
		if (!StringUtils.isEmpty(url)) {
        	url = ApplicationUtil.getUrlWithoutDomain(url);
        }
		
		if(url.endsWith(ApplicationConstants.SLASH) && url.lastIndexOf(ApplicationConstants.SLASH)>0)
		{
			url = url.substring(0, url.lastIndexOf(ApplicationConstants.SLASH));
		}

		LOGGER.debug("Exiting getResolveURL method ");
		return url;
	}

	/**
	 * <p> This method creates a map of the combinations of all country nodes  and their respective child locale nodes</p>
	 * @param itLanguage - language resource iterator
	 * @param countryName - country node name of the current page
	 * @param languageName- language node name of the current paeg
	 * @param path -  current page path
	 * @param contentPath - content path
	 * @return -  map of the country locale
	 */
	private Map<String,String> createCountryLocaleMap(Iterator<Resource> itLanguage, String countryName, String languageName, String path, String contentPath)
	{
		LOGGER.debug("Entering createCountryLocaleMap method ");
		String localeCountry = "";
		Map<String,String> localeCountryMap = new HashMap<String, String>();
		while (itLanguage.hasNext()) {
			Resource languageResource = itLanguage.next();

			if(!ApplicationConstants.JCRCONTENT.equals(languageResource.getName()))
			{

				localeCountry = Locale.forLanguageTag(languageResource.getName()).toString() + ApplicationConstants.HYPHEN
						+ LocaleUtil.getCountryUpperCase(countryName);

				createOGAltLocale(languageResource.getName(),languageName,countryName);

				StringBuilder sbUrl = new StringBuilder();
				sbUrl.append(path).append(ApplicationConstants.SLASH).append(languageResource.getName()).append(contentPath);
				String url = domainName + getResolveURL(sbUrl.toString());
				localeCountryMap.put(url, localeCountry);							
			}
		}

		LOGGER.debug("Exiting createCountryLocaleMap method ");
		return localeCountryMap;
	}
	/**
	 * Method to create OG Alternate locale value
	 * @param nodeName
	 * @param languageName
	 * @param countryName
	 */
	private void createOGAltLocale(String nodeName, String languageName, String countryName)
	{
		LOGGER.debug("Entering createOGAltLocale method ");
		if(!nodeName.equals(languageName))
		{
			this.setOgAlternateLocale(Locale.forLanguageTag(nodeName).toString() + ApplicationConstants.UNDERSCORE
					+ LocaleUtil.getCountryUpperCase(countryName));
		}

		LOGGER.debug("Exiting createOGAltLocale method ");
	}
	
	/**
	 * 
	 * <p>
	 * Fetches noIndex
	 * </p>
	 *
	 * @return the noIndex
	 */
	@Override
	public String getNoIndex() {
		return noIndex;
	}

	/**
	 * <p>
	 * Fetches noFollow
	 * </p>
	 *
	 * @return the noFollow
	 */
	public String getNoFollow() {
		return noFollow;
	}

	/**
	 * <p>
	 * Fetches unavailableAfter
	 * </p>
	 *
	 * @return the unavailableAfter
	 */
	@Override
	public String getUnavailableAfter() {
		return unavailableAfter;
	}

	/**
	 * <p>
	 * Fetches canonicalURL
	 * </p>
	 *
	 * @return the canonicalURL
	 */
	@Override
	public String getCanonicalURL() {
		return canonicalURL;
	}

	/**
	 * <p>
	 * Fetches robots
	 * </p>
	 *
	 * @return the robots
	 */
	@Override
	public String getRobots() {
		return robots;
	}

	/**
	 * <p>
	 * Fetches ogTitle
	 * </p>
	 *
	 * @return the ogTitle
	 */
	@Override
	public String getOgTitle() {
		return ogTitle;
	}

	/**
	 * <p>
	 * Fetches ogDescription
	 * </p>
	 *
	 * @return the ogDescription
	 */
	@Override
	public String getOgDescription() {
		return ogDescription;
	}

	/**
	 * <p>
	 * Fetches ogImage
	 * </p>
	 *
	 * @return the ogImage
	 */
	@Override
	public String getOgImage() {
		return ogImage;
	}

	/**
	 * <p>
	 * Fetches ogType
	 * </p>
	 *
	 * @return the ogType
	 */
	@Override
	public String getOgType() {
		return ogType;
	}

	/**
	 * <p>
	 * Fetches twitterCard
	 * </p>
	 *
	 * @return the twitterCard
	 */
	@Override
	public String getTwitterCard() {
		return twitterCard;
	}

	/**
	 * <p>
	 * Fetches twitterTitle
	 * </p>
	 *
	 * @return the twitterTitle
	 */
	@Override
	public String getTwitterTitle() {
		return twitterTitle;
	}

	/**
	 * <p>
	 * Fetches twitterDescription
	 * </p>
	 *
	 * @return the twitterDescription
	 */
	@Override
	public String getTwitterDescription() {
		return twitterDescription;
	}

	/**
	 * <p>
	 * Fetches twitterImage
	 * </p>
	 *
	 * @return the twitterImage
	 */
	@Override
	public String getTwitterImage() {
		return twitterImage;
	}

	/**
	 * <p>
	 * Fetches ogLocale
	 * </p>
	 *
	 * @return the ogLocale
	 */
	@Override
	public String getOgLocale() {
		return ogLocale;
	}

	/**
	 * <p>
	 * Sets ogLocale
	 * </p>
	 *
	 * @param ogLocale - the ogLocale to set
	 */
	public void setOgLocale(String ogLocale) {
		this.ogLocale = ogLocale;
	}

	/**
	 * <p>
	 * Fetches ogURL
	 * </p>
	 *
	 * @return the ogURL
	 */
	@Override
	public String getOgURL() {
		return ogURL;
	}

	/**
	 * <p>
	 * Sets ogURL
	 * </p>
	 *
	 * @param ogURL - the ogURL to set
	 */
	public void setOgURL(String ogURL) {
		this.ogURL = ogURL;
	}

	/**
	 * <p>
	 * Fetches twitterURL
	 * </p>
	 *
	 * @return the twitterURL
	 */
	@Override
	public String getTwitterURL() {
		return twitterURL;
	}

	/**
	 * <p>
	 * Sets twitterURL
	 * </p>
	 *
	 * @param twitterURL - the twitterURL to set
	 */
	public void setTwitterURL(String twitterURL) {
		this.twitterURL = twitterURL;
	}

	/**
	 * <p>
	 * Sets ogTitle
	 * </p>
	 *
	 * @param ogTitle - the ogTitle to set
	 */
	public void setOgTitle(String ogTitle) {
		this.ogTitle = ogTitle;
	}

	/**
	 * <p>
	 * Sets twitterTitle
	 * </p>
	 *
	 * @param twitterTitle - the twitterTitle to set
	 */
	public void setTwitterTitle(String twitterTitle) {
		this.twitterTitle = twitterTitle;
	}

	/**
	 * <p>
	 * Sets twitterDescription
	 * </p>
	 *
	 * @param twitterDescription - the twitterDescription to set
	 */
	public void setTwitterDescription(String twitterDescription) {
		this.twitterDescription = twitterDescription;
	}

	/**
	 * <p>
	 * Sets twitterImage
	 * </p>
	 *
	 * @param twitterImage - the twitterImage to set
	 */
	public void setTwitterImage(String twitterImage) {
		this.twitterImage = twitterImage;
	}

	/**
	 * <p>
	 * Sets robots
	 * </p>
	 *
	 * @param robots - the robots to set
	 */
	public void setRobots(String robots) {
		this.robots = robots;
	}

	/**
	 * <p>
	 * Sets canonicalURL
	 * </p>
	 *
	 * @param canonicalURL - the canonicalURL to set
	 */
	public void setCanonicalURL(String canonicalURL) {
		this.canonicalURL = canonicalURL;
	}

	/**
	 * <p>
	 * Sets ogImage
	 * </p>
	 *
	 * @param ogImage - the ogImage to set
	 */
	public void setOgImage(String ogImage) {
		this.ogImage = ogImage;
	}

	/**
	 * <p>
	 * Sets ogDescription
	 * </p>
	 *
	 * @param ogDescription - the ogDescription to set
	 */
	public void setOgDescription(String ogDescription) {
		this.ogDescription = ogDescription;
	}

	public void setUnavailableAfter(String unavailableAfter) {
		this.unavailableAfter = unavailableAfter;
	}

	/**
	 * @return the hrefLangList
	 */
	@Override
	public List<String> getHrefLangList() {
		return new ArrayList<>(hrefLangList);
	}

	/**
	 * @return the title
	 */
	@Override
	public String getTitle() {
		if(getSeoTitle() != null && (getUseDynamicSeoTitles()!= null && getUseDynamicSeoTitles())) {
			return getSeoTitle();
		}
		return title;
	}
	
	/**
	 * @return the seoTitle
	 */
	@Override
	public String getSeoTitle() {
		return seoTitle;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		if(getSeoDescription() != null && (getUseDynamicSeoDesc() != null && getUseDynamicSeoDesc())) {
			return getSeoDescription();
		}
		return description;
	}
	
	/**
	 * @return the seoDescription
	 */
	public String getSeoDescription() {
		return seoDescription;
	}


	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	
	/**
	 * @param seoTitle
	 */
	public void setSeoTitle(String seoTitle) {
		this.seoTitle = seoTitle;
	}
	
	/**
	 * @return Boolean useDynamicTitles
	 */
	public Boolean getUseDynamicSeoTitles() {
		return useDynamicSeoTitles;
	}
	
	/**
	 * @return Boolean useDynamicDesc
	 */
	public Boolean getUseDynamicSeoDesc() {
		return useDynamicSeoDesc;
	}

	/**
	 * @param useDynamicTitles
	 */
	public void setUseDynamicSeoTitles(Boolean useDynamicSeoTitles) {
		this.useDynamicSeoTitles = useDynamicSeoTitles;
	}
	
	/**
	 * @param useDynamicTitles
	 */
	public void setUseDynamicSeoDesc(Boolean useDynamicSeoDesc) {
		this.useDynamicSeoDesc = useDynamicSeoDesc;
	}
	
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/**
	 * @param seoDescription the SEO description to set
	 */
	public void setSeoDescription(String seoDescription) {
		this.seoDescription = seoDescription;
	}

	/**
	 * @param hrefLangList the hrefLangList to set
	 */
	public void setHrefLangList(List<String> hrefLangList) {
		hrefLangList = new ArrayList<>(hrefLangList);
		this.hrefLangList = Collections.unmodifiableList(hrefLangList);
	}

	@Override
	public Map<String,String> getMap() {
		return map;
	}

	/**
	 * @return the ogSiteName
	 */
	@Override
	public String getOgSiteName() {
		return ogSiteName;
	}

	/**
	 * @param ogSiteName the ogSiteName to set
	 */
	public void setOgSiteName(String ogSiteName) {
		this.ogSiteName = ogSiteName;
	}

	/**
	 * @return the twitterSite
	 */
	@Override
	public String getTwitterSite() {
		return twitterSite;
	}

	/**
	 * @param twitterSite the twitterSite to set
	 */
	public void setTwitterSite(String twitterSite) {
		this.twitterSite = twitterSite;
	}

	/**
	 * @return the fbAppId
	 */
	@Override
	public String getFbAppId() {
		return fbAppId;
	}

	/**
	 * @param fbAppId the fbAppId to set
	 */
	public void setFbAppId(String fbAppId) {
		this.fbAppId = fbAppId;
	}

	/**
	 * @return the ogAlternateLocale
	 */
	@Override
	public String getOgAlternateLocale() {
		return ogAlternateLocale;
	}

	/**
	 * @param ogAlternateLocale the ogAlternateLocale to set
	 */
	public void setOgAlternateLocale(String ogAlternateLocale) {
		this.ogAlternateLocale = ogAlternateLocale;
	}
	
	/**
	 * @param none
	 */
	@Override
	public String getSPAHierarchyRootJsonExportUrl(){
		String selectors = ".model.json";
		Set runModes = slingSettingsService.getRunModes();
	    Page rootPage = ApplicationUtil.getSPARootPage(this.resource, this.currentPage);
		
	    if (rootPage != null) {
	    	String url = rootPage.getPath();
	    	if (StringUtils.isBlank(url)) {
	    	      return null;
	    	    }
	    	    int dotIndex = url.indexOf('.');
	    	    if (dotIndex < 0) {
	    	      dotIndex = url.length();
	    	    }
	    	    url = url.substring(0, dotIndex);
	    	    if(runModes!=null && runModes.contains("publish")) {
	    			selectors = ".model.tfmodel.json";
	    			url = ApplicationUtil.getUrlWithoutDomain(resourceResolver.map(url));

	    		}
	    	    return url + selectors;
	    }
	    return null;
	 }
	
	/**
	 * @return the dynamicDescriptionConfig
	 */
	public String[] getDynamicDescriptionConfig() {
		if(dynamicDescriptionConfig != null) {
			return dynamicDescriptionConfig.clone();
		}
		return null;
	}

	/**
	 * @param dynamicDescriptionConfig the dynamicDescriptionConfig to set
	 */
	public void setDynamicDescriptionConfig(String[] dynamicDescConfig) {
		if (dynamicDescConfig == null) {
			this.dynamicDescriptionConfig = null;
		} else {
			this.dynamicDescriptionConfig = dynamicDescConfig.clone();
		}
	}

	/**
	 * @return the searchTypeFacet
	 */
	public String getSearchTypeFacet() {
		return searchTypeFacet;
	}

	/**
	* Method to set the search type facet depending on the selection on the page property.
	* For PDPs, the value will be as set on PLPs.
	*/
	public void setSearchTypeFacet() {
		Page page = currentPage;
		if(currentPage != null){
		Boolean isPDP = ApplicationUtil.isPdpPage(currentPage,tracfoneValueMappingConfigService.pdpTemplateValues());
			if (Boolean.TRUE.equals(isPDP)) {
				page = currentPage.getParent();
			}
			String searchFacet = (null !=page && StringUtils.isNotEmpty(page.getProperties().get(SEARCH_CATEGORY_TYPE, String.class))) ? page.getProperties().get(SEARCH_CATEGORY_TYPE, String.class) : "" ;
	
			if(StringUtils.isEmpty(searchFacet) || searchFacet.equalsIgnoreCase(DEFAULT)) {
				searchFacet = getSearchFacetDefaultValue();
			}
			this.searchTypeFacet = searchFacet;
		}		
	}

	/**
	 * @return the searchFacetDefaultValue
	 */
	public String getSearchFacetDefaultValue() {
		return searchFacetDefaultValue;
	}

	/**
	 * @param searchFacetDefaultValue the search Facet Default Value to set
	 */
	public void setSearchFacetDefaultValue(String searchFacetDefaultValue) {
		this.searchFacetDefaultValue = searchFacetDefaultValue;
	}

	/**
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * @param language the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * @return the productPartNumber
	 */
	public String getProductPartNumber() {
		return productPartNumber;
	}

	/**
	 * @return the productCategoryType
	 */
	public String getProductCategoryType() {
		return productCategoryType;
	}

	/**
	 * Method to set the part number and product type of the current PDP page.
	 *
	 */
	private void setProductDetails() {
		String partNumber = "";
		String productType = "";
		Page ancestorpage;
		if(currentPage != null) {
			Boolean isPDP = ApplicationUtil.isPdpPage(currentPage, tracfoneValueMappingConfigService.pdpTemplateValues());
			if (Boolean.TRUE.equals(isPDP)) {
				partNumber = currentPage.getProperties().get(PRODUCT_PART_NUMBER, String.class);
				ancestorpage = null!=currentPage.getParent()?currentPage.getParent().getParent():null;
				productType = ancestorpage != null ? ancestorpage.getProperties().get(PRODUCT_CATEGORY_TYPE, String.class) : "";
			}
		}
		this.productPartNumber = partNumber;
		this.productCategoryType = productType;
	}

	/**
	 * @return the isLocatorPage
	 */
	@Override
	public String getIsLocatorPage() {
		return isLocatorPage;
	}
}
