/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl.v1;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.QuestionsModel;
import com.tracfonecore.core.utils.ApplicationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { QuestionsModel.class,
        ComponentExporter.class }, resourceType = "tracfone-core/components/spa/content/questions/v1/questions", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })

public class QuestionsModelImpl implements QuestionsModel {

    @Self
    private SlingHttpServletRequest request;

    @ScriptVariable
    private ValueMap properties;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String componentVersion;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String headlineText;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String faqLinkTitle;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String faqLinkUrl;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String faqNewWindow;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String contactUsLinkTitle;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String contactUsLinkUrl;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String contactUsNewWindow;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String phoneNumber;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String timeAndDaysAvailable;

    @Override
    public String getComponentVersion() {
        return StringUtils.isNotBlank(componentVersion) ? componentVersion : "v1";
    }

    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

    @Override
    public String getHeadlineText() {
        return headlineText;
    }

    @Override
    public String getFaqLinkTitle() {
        return faqLinkTitle;
    }

    @Override
    public String getFaqLinkUrl() {
        return ApplicationUtil.getShortUrl(request.getResourceResolver(), faqLinkUrl);
    }

    @Override
    public String getFaqNewWindow() {
        return faqNewWindow;
    }

    @Override
    public String getContactUsLinkTitle() {
        return contactUsLinkTitle;
    }

    @Override
    public String getContactUsLinkUrl() {
        return ApplicationUtil.getShortUrl(request.getResourceResolver(), contactUsLinkUrl);
    }

    @Override
    public String getContactUsNewWindow() {
        return contactUsNewWindow;
    }

    @Override
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @Override
    public String getTimeAndDaysAvailable() {
        return timeAndDaysAvailable;
    }

}
