/**
 * 
 */
package com.tracfonecore.core.models;

import java.util.List;

import org.osgi.annotation.versioning.ProviderType;

import com.adobe.cq.wcm.core.components.models.Navigation;
import com.drew.lang.annotations.Nullable;
import com.fasterxml.jackson.annotation.JsonProperty;
/**
 * @author vijaykumar.tripathi
 *
 */
@ProviderType
public interface NavigationModel extends Navigation{

		/**
		 * Returns the name of this {@code ListItem}.
		 *
		 * @return the list item name or {@code null}
		 */
		 default List<NavigationItem> getItem() {
	        throw new UnsupportedOperationException();
	    }
	 
	    /**
	     * Returns the name of this {@code NavigationLinks}.
	     *
	     * @return the list NavigationLinks name or {@code null}
	     */
	    @Nullable
	    default List<NavigationLinksItemModel> getNavigationLinks() {
	        throw new UnsupportedOperationException();
	    }

		/**
		 * @return the cartUrlTarget
		 */
	    @Nullable
	    default Boolean getCartUrlTarget() {
	        throw new UnsupportedOperationException();
	    }

		/**
		 * @return the cartIconUrl
		 */
	    @Nullable
	    default String getCartIconUrl() {
	        throw new UnsupportedOperationException();
	    };
	    
	    /**
		 * @return the Search Enable/Disable
		 */
	    @Nullable
	    default Boolean getSearchDisable() {
	        throw new UnsupportedOperationException();
	    };
	    /**
		 * <p>
		 * Fetches flexible navigation width
		 * </p>
		 * 
		 * @return String - flexible navigation width
		 */
		@JsonProperty("flexibleNavigationWidth")
		public boolean getFlexibleNavigationWidth();
}
