/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.PhoneTypeBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.PhoneTypeModel;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.tracfonecore.core.utils.ApplicationUtil;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { PhoneTypeModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/phonetype", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class PhoneTypeModelImpl implements PhoneTypeModel {

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private Resource resource;
	@ScriptVariable
	private ValueMap properties;

	private List<PhoneTypeBean> options = Collections.emptyList();

	@ValueMapValue
	private String modalName;

	private String modalId;

	private static final Logger LOGGER = LoggerFactory.getLogger(PhoneTypeModelImpl.class);

	@PostConstruct
	private void initModel() {

		options = new ArrayList<PhoneTypeBean>();

		for (Resource child : resource.getChildren()) {
			if (ApplicationConstants.OPTIONS.equals(child.getName())) {
				Iterator<Resource> it = child.listChildren();
				setMultiFieldItems(it, options);
			}
		}
		if (StringUtils.isNotBlank(modalName))
			this.setModalId(ApplicationUtil.getLowerCaseWithHyphen(modalName) + ApplicationConstants.HYPHEN
					+ ApplicationConstants.MODAL);

	}

	/**
	 * <p>
	 * Populates a list with all the multi-options
	 * </p>
	 *
	 * @param it             - iterator of the parent node
	 * @param multiFieldData - list in which the multi options data needs to be set
	 */

	private void setMultiFieldItems(Iterator<Resource> it, List<PhoneTypeBean> multiFieldData) {
		LOGGER.debug("Entering setMultiFieldItems method");
		while (it.hasNext()) {
			Resource grandChild = it.next();
			PhoneTypeBean phoneBean = new PhoneTypeBean();
			phoneBean.setValue(grandChild.getValueMap().get("option", String.class));
			phoneBean.setLabel(grandChild.getValueMap().get("deviceTypeLabel", String.class));
			multiFieldData.add(phoneBean);

		}

		LOGGER.debug("Exiting setMultiFieldItems method ");
	}

	/**
	 * <p>
	 * Fetches all the multi-options
	 * </p>
	 *
	 * @return List - all the multi-options
	 */
	@Override
	public List<PhoneTypeBean> getOptions() {
		return new ArrayList<>(options);
	}

	/**
	 * @return String - exportedType
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Fetches modalName
	 * </p>
	 *
	 * @return the modalName
	 */
	@Override
	public String getModalName() {
		return modalName;
	}

	/**
	 * <p>
	 * Fetches modalId
	 * </p>
	 *
	 * @return the modalId
	 */
	public String getModalId() {
		return modalId;
	}

	/**
	 * <p>
	 * Sets modalId
	 * </p>
	 *
	 * @param modalId - the modalId to set
	 */
	public void setModalId(String modalId) {
		this.modalId = modalId;
	}
}