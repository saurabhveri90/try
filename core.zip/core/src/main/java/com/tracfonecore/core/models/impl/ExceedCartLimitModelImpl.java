package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.ExceedCartLimitModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.utils.CommerceUtil;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;


@Model(adaptables = {SlingHttpServletRequest.class, Resource.class}, adapters = {ExceedCartLimitModel.class,
        ComponentExporter.class}, resourceType = ExceedCartLimitModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true")})
public class ExceedCartLimitModelImpl implements ExceedCartLimitModel {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExceedCartLimitModelImpl.class);
    protected static final String RESOURCE_TYPE = "tracfone-core/components/commerce/exceedcartlimitmodal";

    @Inject
    private Page currentPage;

    @Self
    private SlingHttpServletRequest request;

    @Inject
    private TracfoneApiGatewayService tracfoneApiService;

    @Inject
    private ApplicationConfigService applicationConfigService;

    @PostConstruct
    protected void initModel() {

        fetchPagePropertiesData();

    }

    private void fetchPagePropertiesData() {}

    /**
     * @return int - homePageLevel
     */
    private int getHomePageLevel() {

        return applicationConfigService.getHomePageLevel();
    }

    /**
     * @return String - language
     */
    public String getLanguage() {

        return CommerceUtil.getLanguage(currentPage, getHomePageLevel());
    }


    /**
	 * <p> This method is used to generate query string for get cart detail api call
	 * @return -String : Query String
	 */
    public String getQuery() {
        StringBuilder query = new StringBuilder(CommerceConstants.PROJECTION).append(CommerceConstants.EQUALS_TO)
		.append(CommerceConstants.CART_DETAILS);
		
		return query.toString();
    }

    /**
     * @return String - apiDomain
     */
    public String getApiDomain() {
        return tracfoneApiService.getApiDomain();
    }

    /**
     * @return String -  notifyApiPath
     */
    public String getCartDetailApiPath() {
        return tracfoneApiService.getCartApiPath();
    }
    
    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }
    
    public String getItemTypeForDevice()
    {
    	return CommerceConstants.ITEM_TYPE_FOR_DEVICE;
    }
    
    public String getItemTypeForPlan()
    {
    	return CommerceConstants.ITEM_TYPE_FOR_PLAN;
    }
    
    public String getItemTypeForAccessories()
    {
    	return CommerceConstants.ITEM_TYPE_FOR_ACCESSORIES;
    }

}
