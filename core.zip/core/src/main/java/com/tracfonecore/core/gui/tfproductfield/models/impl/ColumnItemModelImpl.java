package com.tracfonecore.core.gui.tfproductfield.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.gui.tfproductfield.models.ColumnItemModel;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.annotation.PostConstruct;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ColumnItemModel.class,
        ComponentExporter.class }, resourceType = "tracfone-core/gui/components/tfproductfield/columnitem", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ColumnItemModelImpl implements ColumnItemModel {

    @Self
    private SlingHttpServletRequest request;

    @ValueMapValue
    private String name;
    @ValueMapValue
    private String id;
    @ValueMapValue
    private String partNo;
    @ValueMapValue
    private boolean hasChildren;
    @ValueMapValue
    private String path;

    @PostConstruct
    private void initModel() {
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public String getId() {
        return this.id;
    }

    @Override
    public String getPartNo() {
        return this.partNo;
    }

    @Override
    public boolean hasChildren() {
        return this.hasChildren;
    }

    @Override
    public String getPath() {
        return this.path;
    }

    @Override
    public String getSelectionId() {
        return ("partNo".equals(request.getParameter("selectionId")))? getPartNo() : getId();
    }

    @Override
    public String getThumbnailImageUrl() {
        return null;
    }

    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }
}
