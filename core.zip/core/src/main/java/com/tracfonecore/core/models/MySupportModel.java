package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

public interface MySupportModel extends ComponentExporter {
	
	
	@JsonProperty("positionMySupport")
	public String getPositionMySupport();
	
	@JsonProperty("positionAccountNavigation")
	public String getPositionAccountNavigation();

	@JsonProperty("title")
	public String getTitle();

	@JsonProperty("statusLabel")
	public String getStatusLabel();

	@JsonProperty("ticketNumberLabel")
	public String getTicketNumberLabel();

	@JsonProperty("descLabel")
	public String getDescLabel();

	@JsonProperty("lineLabel")
	public String getLineLabel();

	@JsonProperty("trackingNumberLabel")
	public String getTrackingNumberLabel();

	@JsonProperty("numberOfItemsOnSinglePage")
	public String getNumberOfItemsOnSinglePage();

	@JsonProperty("numberOfPageDisplayed")
	public String getNumberOfPageDisplayed();

}
