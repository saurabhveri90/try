package com.tracfonecore.core.models;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.tracfonecore.core.constants.ApplicationConstants;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

@Model(adaptables = {SlingHttpServletRequest.class}, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ErrorHandlerRequestModel {
    private static final String DEFAULT_ERROR_PAGE = "/content/straighttalk/us/en";

    private static final Logger LOGGER = LoggerFactory.getLogger(ErrorHandlerRequestModel.class);
    @Self
    private SlingHttpServletRequest slingRequest;

    @Inject
    private SlingHttpServletResponse slingResponse;

    @Inject
    @Default(values = ApplicationConstants.ERROR_CODE_404)
    private String errorCode;

    private String pagePath;

    @PostConstruct
    protected void init() {
        LOGGER.debug("Entering init method");
            pagePath = DEFAULT_ERROR_PAGE;
            final String requestURI = slingRequest.getRequestPathInfo().getResourcePath();
            if (requestURI != null && ! StringUtils.isBlank(requestURI)) {
                pagePath = getErrorPageFromRequestedUrl(errorCode, requestURI);
            }else {
            	 LOGGER.error("Error while fetching errorHandlerRequestModel");
            }
        
        LOGGER.debug("Exiting init method");
    }

    /**
     * <p>Fetches error page path if available</p>
     *
     * @param  errorCode - error code injected
     * @param  requestURI - requested URI
     * @return String - error page path
     *
     */
    private String getErrorPageFromRequestedUrl(final String errorCode, final String requestURI) {
        final Page resolvedPage = getPageFromPath(requestURI);
        if (resolvedPage != null) {
            return getErrorPathFromPage(errorCode, resolvedPage);
        }
        return null;
    }

    /**
     * <p>Fetches page from given path</p>
     *
     * @param  requestURI - error page path
     * @return Page - error page if available
     *
     */
    private Page getPageFromPath(String requestURI) {
        final PageManager pageManager = slingRequest.getResourceResolver().adaptTo(PageManager.class);
        while (requestURI.contains(ApplicationConstants.SLASH)) {
            Page page = pageManager.getContainingPage(requestURI);
            if (page != null) {
                return page;
            } else {
                requestURI = requestURI.substring(0, requestURI.lastIndexOf(ApplicationConstants.SLASH));
            }
        }
        return null;
    }

    /**
     * <p>Fetches error path from page</p>
     *
     * @param  errorCode - error code
     * @param  resolvedPage - resolved page
     * @return String - error page path
     *
     */
    private String getErrorPathFromPage(final String errorCode, final Page resolvedPage) {
        if (resolvedPage.hasChild(errorCode)) {
            return resolvedPage.getPath() + ApplicationConstants.SLASH + errorCode;
        }
        if (resolvedPage.getParent() != null && resolvedPage.getDepth() >= ApplicationConstants.INTEGER_TWO) {
            return getErrorPathFromPage(errorCode, resolvedPage.getParent());
        }
        return null;
    }

    /**
     * <p>Redirect to appropriate error page</p>
     *
     */
    public void redirectToErrorPage() {
        try {
            LOGGER.info("Redirect page path {}", pagePath + ApplicationConstants.HTML_EXTENSION);
            if(StringUtils.isNotBlank(pagePath)) {
            	String errorPagePath = pagePath + ApplicationConstants.HTML_EXTENSION;
            	String shortPagePath = slingRequest.getResourceResolver().map(pagePath);
            	if(StringUtils.isNotBlank(shortPagePath) && (shortPagePath.contains(ApplicationConstants.URL_PROTOCOL_HTTP) || shortPagePath.contains(ApplicationConstants.URL_PROTOCOL_HTTPS))) {
            		errorPagePath = shortPagePath;
            	}
            	slingResponse.sendRedirect(errorPagePath);
            }
        } catch (IOException e) {
            LOGGER.error("Error while redirectToErrorPage method ErrorHandlerRequestModel {}", e);
        }
    }
}
