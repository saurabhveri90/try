/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.utils.ApplicationUtil;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.SaveMoreWaysModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { SaveMoreWaysModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/content/savemoreways", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class SaveMoreWaysModelImpl implements SaveMoreWaysModel {

	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String saveMoreWaysTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String saveMoreWaysSubTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String saveMoreWaysCtaText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String saveMoreWaysCtaLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String saveMoreWaysImagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String saveMoreWaysMobileImagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String saveMoreWaysImageAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean shouldIncludeMyAccountNav;
	
	@Override
	public String getSaveMoreWaysTitle() {
		return saveMoreWaysTitle;
	}

	@Override
	public String getSaveMoreWaysSubTitle() {
		return saveMoreWaysSubTitle;
	}

	@Override
	public String getSaveMoreWaysCtaText() {
		return saveMoreWaysCtaText;
	}

    @Override
	public String getSaveMoreWaysCtaLink() {
		return saveMoreWaysCtaLink;
	}

    @Override
	public String getSaveMoreWaysImagePath() {
	     return DynamicMediaUtils.changeMediaPathToDMPath(saveMoreWaysImagePath, request.getResourceResolver());
	}

	@Override
	public String getSaveMoreWaysMobileImagePath() {
	     return DynamicMediaUtils.changeMediaPathToDMPath(saveMoreWaysMobileImagePath, request.getResourceResolver());
	}

	@Override
	public String getSaveMoreWaysImageAltText() {
		return saveMoreWaysImageAltText;
	}

    @Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getSaveMoreWaysImageAssetId() {
		return ApplicationUtil.getAssetId(saveMoreWaysImagePath,
				request.getResourceResolver(), ApplicationConstants.IMAGE);
	}

	@Override
	public String getSaveMoreWaysImageAssetAgencyId() {
		return ApplicationUtil.getAssetMetaDataValue(saveMoreWaysImagePath,
				request.getResourceResolver(), ApplicationConstants.WEBER_ID);
	}

	@Override
	public Boolean getShouldIncludeMyAccountNav() {
		return shouldIncludeMyAccountNav;
	}
	
}
