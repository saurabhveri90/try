package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Session;

import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.utils.ApplicationUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.day.cq.wcm.api.Page;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.tracfonecore.core.beans.PhoneSpecsBean;
import com.tracfonecore.core.models.PhoneSpecsModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.ProductOfferingApiService;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;
import com.tracfonecore.core.utils.ItemsExporterUtil;
import com.tracfonecore.core.constants.CommerceConstants;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { PhoneSpecsModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/phonespecs", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true"),
		@ExporterOption(name = "SerializationFeature.FAIL_ON_EMPTY_BEANS", value = "false") })

public class PhoneSpecsModelImpl extends BaseComponentModelImpl implements PhoneSpecsModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(PhoneSpecsModelImpl.class);
	protected static final String RESOURCE_TYPE = "tracfone-core/components/commerce/phonespecs";
	private static final String PROVISIONAL = "provisional";
	
	@Self
	private SlingHttpServletRequest request;

	@Inject
	private SlingModelFilter slingModelFilter;

	@Inject
	private ModelFactory modelFactory;

	@Inject
	private Page currentPage;

	@Inject
	private Resource resource;
	
	@ChildResource
	private List<Resource> additionalSpecs;

	@Inject
	private ApplicationConfigService applicationConfigService;

	@Inject
	private ProductOfferingApiService productOfferingApiService;

	@Inject
	private TracfoneApiGatewayService tracfoneApiGatewayService;

	@ValueMapValue
	private String heading;

	@ValueMapValue
	@Default(values = "Show More")
	private String ctaTextShowMore;

	@ValueMapValue
	@Default(values = "Show Less")
	private String ctaTextShowLess;

	@ValueMapValue
	private boolean addRteComponent;

	@ValueMapValue
	private boolean addXFComponent;

	@ValueMapValue
	private String layout;

	@ValueMapValue
	private String includeXfPath;
	
	@ValueMapValue
	private boolean hideSpecHeading;

	@ValueMapValue
	private boolean splitRowColumn;

	@ValueMapValue
	private boolean specValAsTitle;

	private String domainName = "";

	private String authorPath = "";

	private JsonObject product;

	private String selection;

	private List<PhoneSpecsBean> phoneSpecsList = Collections.emptyList();
	private List<PhoneSpecsBean> selectedSpecsList = Collections.emptyList();
	private PhoneSpecsBean phoneSpecsBean;

	Session jcrSession;

	private String marketingIds;

	private boolean useNameForSpecs = false;
	
	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entered init method of PhoneSpecsModelImpl");
		try {
			super.initModel();
			domainName = ApplicationUtil.getDomainNameinURL(request.getRequestURL().toString());

			selection = currentPage.getContentResource().getValueMap().get("partNo", String.class);

			if (selection != null) {
				product = productOfferingApiService.getProductDetailObject(selection, currentPage);
				LOGGER.debug("Product Bean "+product);

				if(null!=product) {
					setProductSpecs(resource);
				}
			}
			LOGGER.debug("Exiting init method of PhoneSpecsModelImpl");
		} catch (RuntimeException re) {
			LOGGER.error("API Exception occurred while fetching phone card details {}", re);
		}
		LOGGER.debug("Exiting init method of PhoneSpecsModelImpl");
	}

	private void setProductSpecs(Resource resource) {
			if (product != null && product.get(CommerceConstants.PRODUCT_CHARACTERISTICS) != null && product.get(CommerceConstants.PRODUCT_CHARACTERISTICS).isJsonArray()) {
				JsonArray prodSpecsArray;
				useNameForSpecs = Arrays.asList(tracfoneApiGatewayService.getProductSpecsForBrand())
						.contains(CommerceUtil.getBrandValue(currentPage, getHomePageLevel()));

				phoneSpecsList = new ArrayList<PhoneSpecsBean>();
				prodSpecsArray = product.get(CommerceConstants.PRODUCT_CHARACTERISTICS).getAsJsonArray();
				if (prodSpecsArray.size() > 0) {
					for (int i = 0; i < prodSpecsArray.size(); i++) {
						JsonObject element = prodSpecsArray.get(i).getAsJsonObject();
						if (!element.get("identifier").getAsString().isEmpty()) {							
							phoneSpecsBean = CommerceUtil.setSpecBeanValues(element);
							String identifier = element.get(CommerceConstants.IDENTIFIER).getAsString().toLowerCase();
							if (CommerceConstants.MARKET.equals(phoneSpecsBean.getIdentifier().toLowerCase())) {
								this.setMarketingIds(phoneSpecsBean.getValue());
							}
							if (!(identifier.contains(PROVISIONAL) && CommerceConstants.WITHOUT_LOGO.equals(layout)))
								phoneSpecsList.add(phoneSpecsBean);
						}
					}
				}
				setContentData(phoneSpecsList, resource);
			}

	}

	private void setContentData(List<PhoneSpecsBean> phoneSpecsList, Resource resource) {
		
		String androidImageName = applicationConfigService.getProductSpecAndroidImageName();
		String appleImageName = applicationConfigService.getProductSpecAppleImageName();
		String productSpecImagePath = getProductSpecImagPath(applicationConfigService.getProductSpecImagePath());
		String compareProductSpecImagePath = getProductSpecImagPath(applicationConfigService.getCompareProductSpecImagePath());
		Map<String, String> params = new HashMap<String,String>();
		params.put(CommerceConstants.ANDROID_IMAGE_NAME, androidImageName);
		params.put(CommerceConstants.APPLE_IMAGE_NAME, appleImageName);
		params.put(CommerceConstants.PRODUCT_SPEC_IMAGE_PATH, productSpecImagePath);
		params.put(CommerceConstants.COMPARE_IMAGE_PATH, compareProductSpecImagePath);
		params.put(CommerceConstants.LAYOUT, layout);

		selectedSpecsList = CommerceUtil.setSelectedSpecBeanValues(resource, phoneSpecsList, request.getResourceResolver(),
				params, currentPage, getHomePageLevel(), false, useNameForSpecs, additionalSpecs);
	}

	@Override
	public List<PhoneSpecsBean> getSelectedProductSpecs() {
		return new ArrayList<>(selectedSpecsList);
	}

	@Override
	public List<PhoneSpecsBean> getProductSpecs() {
		return new ArrayList<>(phoneSpecsList);
	}

	@Override
	public String getAuthorPath() {
		authorPath = domainName;
		return authorPath;
	}

	@Override
	public String getResourcePath() {
		return resource.getPath().toString();
	}

	@Override
	public String getHeading() {
		return heading;
	}

	/**
	 * @return getexportertype
	 */
	@Override
	public String getExportedType() {

		return request.getResource().getResourceType();
	}

	/**
	 * @return homePageLevel
	 */
	@Override
	public int getHomePageLevel() {

		return applicationConfigService.getHomePageLevel();
	}

	/**
	 * @return ProductSpecImagPath
	 */
	private String getProductSpecImagPath(String[] specsPath) {
		return ConfigurationUtil.getConfigValue(specsPath, CommerceUtil.getBrandValue(currentPage, getHomePageLevel()));
	}

	/**
	 * @return language
	 */
	@Override
	public String getLanguage() {

		return CommerceUtil.getLanguage(currentPage, getHomePageLevel());
	}

	/**
	 * @return getexportertype
	 */
	@Override
	public Map<String, ? extends ComponentExporter> getItems() {
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}

	/**
	 * @return marketingIds
	 */
	@Override
	public String getMarketingIds() {
		return marketingIds;
	}

	public void setMarketingIds(String marketingIds) {
		this.marketingIds = marketingIds;
	}

	/**
	 * <p>
	 * Fetches ctaTextShowMore
	 * </p>
	 *
	 * @return the ctaTextShowMore
	 */
	@Override
	public String getCtaTextShowMore() {
		return ctaTextShowMore;
	}

	/**
	 * <p>
	 * Fetches ctaTextShowLess
	 * </p>
	 *
	 * @return the ctaTextShowLess
	 */
	@Override
	public String getCtaTextShowLess() {
		return ctaTextShowLess;
	}

	/**
	 * @return API language value
	 */
	private String getAPILanguageValue() {
		String languageCode = StringUtils.EMPTY;
		String[] apiLanguageArray = tracfoneApiGatewayService.getApiLanguage();
		String languageFromPage = getLanguage();
		if (StringUtils.isNotBlank(languageFromPage) && apiLanguageArray != null) {
			languageCode = ApplicationUtil.getAPILanguageValue(languageFromPage, apiLanguageArray);
		}
		return languageCode;
	}

	/**
	 * <p>
	 * Fetches addRteComponent
	 * </p>
	 * 
	 * @return boolean - addRteComponent
	 */
	@Override
	public boolean isAddRteComponent() {
		return addRteComponent;
	}

	/**
	 * <p>
	 * Fetches addXFComponent
	 * </p>
	 * 
	 * @return boolean - addXFComponent
	 */
	@Override
	public boolean isAddXFComponent() {
		return addXFComponent;
	}

	/**
	 * <p>
	 * Fetches layout
	 * </p>
	 *
	 * @return the layout
	 */
	@Override
	public String getLayout() {
		return layout;
	}

	/**
	 * <p>
	 * Fetches useNameForSpecs
	 * </p>
	 *
	 * @return the useNameForSpecs
	 */
	@Override
	public boolean isUseNameForSpecs() {
		return useNameForSpecs;
	}
	
	/**
	 * <p>
	 * Fetches hideSpecHeading
	 * </p>
	 *
	 * @return the hideSpecHeading
	 */
	@Override
	public boolean getHideSpecHeading() {
		return hideSpecHeading;
	}

	/**
	 * <p>
	 * Fetches splitRowColumn
	 * </p>
	 *
	 * @return the splitRowColumn
	 */
	@Override
	public boolean getSplitRowColumn() {
		return splitRowColumn;
	}

	/**
	 *<p>Fetches if the spec value will be a heading</p>
	 *
	 * @return the specValAsTitle
	 */
	@Override
	public boolean getSpecValAsTitle() {
		return specValAsTitle;
	}

}
