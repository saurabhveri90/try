package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

public interface ByopBundleModel extends ComponentExporter {

	/**
	 * @return the alertText
	 */
	@JsonProperty("alertText")
	public String getAlertText();

	/**
	 * @return the categoryId
	 */
	@JsonProperty("categoryId")
	public String getCategoryId();

	@JsonProperty("deviceTypeParam")
	public String getDeviceTypeParam();

	/**
	 * @return the flowType
	 */
	@JsonProperty("flowType")
	public String getFlowType();

	/**
	 * @return the queryString
	 */
	@JsonProperty("queryString")
	public String getQueryString();

	/**
	 * @return the clientID
	 */
	public String getClientID();

	/**
	 * @return the offerPopupLabel
	 */
	@JsonProperty("offerPopupLabel")
	public String getOfferLinkLabel();

	/**
	 * @return the offerPopupModalId
	 */
	@JsonProperty("offerPopupModalId")
	public String getOfferModalId();

	/**
	 * @return the imeiPopupModalId
	 */
	@JsonProperty("imeiPopupModalId")
	public String getImeiModalId();

	/**
	 * @return the imeiPopupLabel
	 */
	@JsonProperty("imeiPopupLabel")
	public String getImeiLinkLabel();

	/**
	 * @return the homePageLevel
	 */
	@JsonProperty("homePageLevel")
	public int getHomePageLevel();

	/**
	 * @return the bundleDesc
	 */
	@JsonProperty("bundleDesc")
	public String getBundleDesc();

	/**
	 * @return the cartBtnAccText
	 */
	@JsonProperty("cartBtnAccText")
	public String getCartBtnAccText();

	/**
	 * @return the cartBtnLabel
	 */
	@JsonProperty("cartBtnLabel")
	public String getCartBtnLabel();

	/**
	 * @return the cmpBtnAccText
	 */
	@JsonProperty("cmpBtnAccText")
	public String getCmpBtnAccText();

	/**
	 * @return the cmpBtnLabel
	 */
	@JsonProperty("cmpBtnLabel")
	public String getCmpBtnLabel();

	/**
	 * @return the descLS
	 */
	@JsonProperty("descLS")
	public String getDescLS();

	/**
	 * @return the headingCS
	 */
	@JsonProperty("headingCS")
	public String getHeadingCS();

	/**
	 * @return the headingDesc
	 */
	@JsonProperty("headingDesc")
	public String getHeadingDesc();

	/**
	 * @return the headingHS
	 */
	@JsonProperty("headingHS")
	public String getHeadingHS();

	/**
	 * @return the headingPart1
	 */
	@JsonProperty("headingPart1")
	public String getHeadingPart1();

	/**
	 * @return the headingPart2
	 */
	@JsonProperty("headingPart2")
	public String getHeadingPart2();

	/**
	 * @return the headingQRFlow
	 */
	@JsonProperty("headingQRFlow")
	public String getHeadingQRFlow();

	/**
	 * @return the headingSucSrn
	 */
	@JsonProperty("headingSucSrn")
	public String getHeadingSucSrn();

	/**
	 * @return the imgLS
	 */
	@JsonProperty("imgLS")
	public String getImgLS();

	/**
	 * @return the nextSteps
	 */
	@JsonProperty("nextSteps")
	public String getNextSteps();

	/**
	 * @return the ptIMEI
	 */
	@JsonProperty("ptIMEI")
	public String getPtIMEI();

	/**
	 * @return the ptZipCode
	 */
	@JsonProperty("ptZipCode")
	public String getPtZipCode();

	/**
	 * @return the stepsSummary
	 */
	@JsonProperty("stepsSummary")
	public String getStepsSummary();

	/**
	 * @return the subHeadingCS
	 */
	@JsonProperty("subHeadingCS")
	public String getSubHeadingCS();

	/**
	 * @return the subHeadingHS
	 */
	@JsonProperty("subHeadingHS")
	public String getSubHeadingHS();

	/**
	 * @return the subHeadingSucSrn
	 */
	@JsonProperty("subHeadingSucSrn")
	public String getSubHeadingSucSrn();

	/**
	 * @return the summaryIMEI
	 */
	@JsonProperty("summaryIMEI")
	public String getSummaryIMEI();

	/**
	 * @return the summaryZipCode
	 */
	@JsonProperty("summaryZipCode")
	public String getSummaryZipCode();

	/**
	 * @return the planThumbnailImage
	 */
	@JsonProperty("planThmbImg")
	public String getPlanThumbnailImage();

	/**
	 * @return the simThumbnailImage
	 */
	@JsonProperty("simThmbImg")
	public String getSimThumbnailImage();

	/**
	 * @return the eSimHeading
	 */
	@JsonProperty("eSimHeading")
	public String getESimHeading();

	/**
	 * @return the eSimSubHeading
	 */
	@JsonProperty("eSimSubHeading")
	public String getESimSubHeading();

	/**
	 * @return the eSimNxtStepsHeading
	 */
	@JsonProperty("eSimNxtStepsHeading")
	public String getESimNxtStepsHeading();

	/**
	 * @return the eSimNxtSteps
	 */
	@JsonProperty("eSimNxtSteps")
	public String getESimNxtSteps();

	/**
	 * @return the eSimDesc
	 */
	@JsonProperty("eSimDesc")
	public String getESimDesc();

	/**
	 * <p>
	 * Fetches skipPlanType property from config
	 * </p>
	 *
	 * @return String[] - skipPlanType
	 */
	public String getSkipPlanType();

	/**
	 * <p>
	 * Fetches faqXF path from dialog
	 * </p>
	 *
	 * @return String - faqxf
	 */
	@JsonProperty("faqxf")
	public String getFaqxf();

	@JsonProperty("uncompatibleXfPath")
	public String getUncompatibleXfPath();

	@JsonProperty("unEligibleXfPath")
	public String getUnEligibleXfPath();

	@JsonProperty("zipErrorXfPath")
	public String getZipErrorXfPath();

	@JsonProperty("activeUserXfPath")
	public String getActiveUserXfPath();

	@JsonProperty("genericErrorXfPath")
	public String getGenericErrorXfPath();

	@JsonProperty("apiRetryCount")
	public int getCompatibleApiRetryCount();

	@JsonProperty("enbTxtCmpBtn")
	public String getEnbTxtCmpBtn();

	@JsonProperty("disTxtCmpBtn")
	public String getDisTxtCmpBtn();

	@JsonProperty("enbTxtCartBtn")
	public String getEnbTxtCartBtn();

	@JsonProperty("activationPageURL")
	public String getActivationPageURL();

	@JsonProperty("offerPopupAriaLabel")
	public String getOfferPopupAriaLabel();

	@JsonProperty("imeiPopupAriaLabel")
	public String getImeiPopupAriaLabel();

	/**
	 * <p>
	 * Returns true or false from root page page properties
	 * </p>
	 *
	 * @return String - disablePromoEligibility
	 */
	public String getDisablePromoEligibility();

	@JsonProperty("headingIS")
	public String getHeadingIS();
	@JsonProperty("marketingIdApiPath")
	public String getMarketingIdApiPath();
	@JsonProperty("marketIdQueryString")
	public String getMarketIdQueryString();

	@JsonProperty("isTrimmedHeader")
	public String getTrimmHeaderCheck();

	@JsonProperty("isTrimmedFooter")
	public String getTrimFooterCheck();

	@JsonProperty("imgPsim")
	public String getImgPsim();

	@JsonProperty("imgLandPage")
	public String getImgLandPage();

	@JsonProperty("nxtStepsDiffChnl")
	public String getNxtStepsDiffChnl();

	/**
	  * @return the headingDeviceUncompatible
	 **/
	@JsonProperty("headingDeviceUncompatible")
	public String getHeadingDeviceUncompatible();

	/**
	 * @return the headingExistingUser
	 */
	@JsonProperty("headingExistingUser")
	public String getHeadingExistingUser();

	/**
	 * @return the headingTechnicalDiff
	 */
	@JsonProperty("headingTechnicalDiff")
	public String getHeadingTechnicalDiff();

	/**
	 * @return the headingphoneUneligible
	 */
	@JsonProperty("headingPhoneUneligible")
	public String getHeadingPhoneUneligible();

	/**
	 * @return the headingErrorZipCoverage
	 */
	@JsonProperty("headingErrorZipCoverage")
	public String getHeadingErrorZipCoverage();

	/**
	 * @return the anotherPhoneBtnLabel
	 */
	@JsonProperty("anotherPhoneBtnLabel")
	public String getAnotherPhoneBtnLabel();
	
	/**
	 * @return the enbTxtAnotherPhoneBtn
	 */
	@JsonProperty("enbTxtAnotherPhoneBtn")
	public String getEnbTxtAnotherPhoneBtn();

	/**
	 * @return the dualSimBodyHeading
	 */
	@JsonProperty("dualSimBodyHeading")
	public String getDualSimBodyHeading();

	/**
	 * @return the dualSimdiffTxt
	 */
	@JsonProperty("dualSimdiffTxt")
	public String getDualSimdiffTxt();

	/**
	 * @return the diffPopupModalId
	 */
	@JsonProperty("diffPopupModalId")
	public String getDiffPopupModalId();

	/**
	 * @return the diffPopupAriaLabel
	 */
	@JsonProperty("diffPopupAriaLabel")
	public String getDiffPopupAriaLabel();

	/**
	 * @return the dualSimNxtSteps
	 */
	@JsonProperty("dualSimNxtSteps")
	public String getDualSimNxtSteps();

	/**
	 * @return the eSIMBtnLabel
	 */
	@JsonProperty("eSIMBtnLabel")
	public String getESIMBtnLabel();

	/**
	 * @return the eSIMEnbTxtBtn
	 */
	@JsonProperty("eSIMEnbTxtBtn")
	public String getESIMEnbTxtBtn();

	/**
	 * @return the eSIMDisTxtBtn
	 */
	@JsonProperty("eSIMDisTxtBtn")
	public String getESIMDisTxtBtn();

	/**
	 * @return the pSIMBtnLabel
	 */
	@JsonProperty("pSIMBtnLabel")
	public String getPSIMBtnLabel();

	/**
	 * @return the pSIMEnbTxtBtn
	 */
	@JsonProperty("pSIMEnbTxtBtn")
	public String getPSIMEnbTxtBtn();

	/**
	 * @return the pSIMDisTxtBtn
	 */
	@JsonProperty("pSIMDisTxtBtn")
	public String getPSIMDisTxtBtn();

	/**
	 * @return the dualSimMainHeading
	 */
	@JsonProperty("dualSimMainHeading")
	public String getDualSimMainHeading();

	/**
	 * @return the dualSimMainSubHeading
	 */
	@JsonProperty("dualSimMainSubHeading")
	public String getDualSimMainSubHeading();

	/**
	 * @return the eSIMScrnEnbTxtBtn
	 */
	@JsonProperty("eSIMScrnBtnLabel")
	public String getESIMScrnBtnLabel();

	/**
	 * @return the eSIMScrnEnbTxtBtn
	 */
	@JsonProperty("eSIMScrnEnbTxtBtn")
	public String getESIMScrnEnbTxtBtn();


}