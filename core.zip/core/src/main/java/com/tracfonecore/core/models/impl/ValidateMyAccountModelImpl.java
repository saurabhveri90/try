package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.ValidateMyAccountModel;
import com.tracfonecore.core.models.ValidateMyAccountOptionsModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ValidateMyAccountModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/validatemyaccount", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ValidateMyAccountModelImpl implements ValidateMyAccountModel {

	@Self
	private SlingHttpServletRequest request;
	
	@ValueMapValue
	private String heading;
	
	@ValueMapValue
	private String accessibilityText;
	
	@ChildResource
	private List<ValidateMyAccountOptionsModel> options;
	
	@ValueMapValue
	private String nextXfLink;
	
	/**
     * @return String - exported Type
     */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * @return the heading
	 */
	@Override
	public String getHeading() {
		return heading;
	}

	/**
	 * @return the accessibilityText
	 */
	@Override
	public String getAccessibilityText() {
		return accessibilityText;
	}

	/**
	 * @return the options
	 */
	@Override
	public List<ValidateMyAccountOptionsModel> getOptions() {
		List<ValidateMyAccountOptionsModel> list = Optional.ofNullable(options)
				.map(List::stream).orElseGet(Stream::empty).collect(Collectors.toList());
		return new ArrayList<>(list);
	}

	/**
	 * @return the nextXfLink
	 */
	@Override
	public String getNextXfLink() {
		return nextXfLink;
	}
	
}
