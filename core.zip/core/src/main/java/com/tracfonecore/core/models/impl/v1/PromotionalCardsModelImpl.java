package com.tracfonecore.core.models.impl.v1;

import java.util.List;

import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.utils.ApplicationUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.PromotionalCardBean;
import com.tracfonecore.core.beans.ScenarioBasedPromotionalCardBean;
import com.tracfonecore.core.models.PromotionalCardsModel;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { PromotionalCardsModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/content/promotionalcards/v1/promotionalcards", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class PromotionalCardsModelImpl  implements PromotionalCardsModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String componentVersion;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headlineText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subHeadlineText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String includeCardImage;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String cardImage;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String cardImageAltText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String includeCardCta;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String cardCtaLabel;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String cardCtaLink;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String openDeviceInfoModal;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String includeAppStore;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String appstoreFileReference;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String appstore;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String appstorealttext;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String includePlayStore;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String playstoreFileReference;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String playstore;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String playstorealttext;

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getComponentVersion() {
		return StringUtils.isNotBlank(componentVersion) ? componentVersion : "v1";
	}

	@Override
	public String getHeadlineText() {
		return headlineText;
	}

	@Override
	public String getSubHeadlineText() {
		return subHeadlineText;
	}

	@Override
	public String getIncludeCardImage() {
		return includeCardImage;
	}

	@Override
	public String getCardImage() {
		return DynamicMediaUtils.changeMediaPathToDMPath(cardImage,request.getResourceResolver());
	}

	@Override
	public String getCardImageAltText() {
		return cardImageAltText;
	}

	@Override
	public String getIncludeCardCta() {
		return includeCardCta;
	}

	@Override
	public String getCardCtaLabel() {
		return cardCtaLabel;
	}

	@Override
	public String getCardCtaLink() {
		return cardCtaLink;
	}

	@Override
	public String getIncludeAppStore() {
		return includeAppStore;
	}

	@Override
	public String getAppstoreFileReference() {
		return appstoreFileReference;
	}

	@Override
	public String getAppstore() {
		return appstore;
	}

	@Override
	public String getAppstorealttext() {
		return appstorealttext;
	}

	@Override
	public String getIncludePlayStore() {
		return includePlayStore;
	}

	@Override
	public String getPlaystoreFileReference() {
		return playstoreFileReference;
	}

	@Override
	public String getPlaystore() {
		return playstore;
	}

	@Override
	public String getPlaystorealttext() {
		return playstorealttext;
	}

	@Override
	public List<PromotionalCardBean> getPromotionalCards() {
		return null;
	}

	@Override
	public String getAppstoreLogoPathAssetId() {
		return ApplicationUtil.getAssetId(appstoreFileReference,
				request.getResourceResolver(), ApplicationConstants.IMAGE);
	}

	@Override
	public String getAppstoreLogoPathAssetAgencyId() {
		return ApplicationUtil.getAssetMetaDataValue(appstoreFileReference,
				request.getResourceResolver(), ApplicationConstants.WEBER_ID);
	}
	@Override
	public String getPlaystoreLogoPathAssetId() {
		return ApplicationUtil.getAssetId(playstoreFileReference,
				request.getResourceResolver(), ApplicationConstants.IMAGE);
	}

	@Override
	public String getPlaystoreLogoPathAssetAgencyId() {
		return ApplicationUtil.getAssetMetaDataValue(playstoreFileReference,
				request.getResourceResolver(), ApplicationConstants.WEBER_ID);
	}

	@Override
	public String getCardImageAssetId() {
		return ApplicationUtil.getAssetId(cardImage,
				request.getResourceResolver(), ApplicationConstants.IMAGE);
	}

	@Override
	public String getCardImageAssetAgencyId() {
		return ApplicationUtil.getAssetMetaDataValue(cardImage,
				request.getResourceResolver(), ApplicationConstants.WEBER_ID);
	}

	@Override
	public List<ScenarioBasedPromotionalCardBean> getScenarioBasedPromotionalCards() {
		return null;
	}

}

