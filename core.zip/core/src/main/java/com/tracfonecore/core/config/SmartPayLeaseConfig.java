package com.tracfonecore.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "SmartPay Lease Application Config Service",description = "Configurations for SmartPay Lease Application Config Service")
public @interface SmartPayLeaseConfig {

    
    @AttributeDefinition(name = "SmartPay Lease acquistion session JS Url",description = "SmartPay Lease acquistion session JS Url", type = AttributeType.STRING)
    String getSmartPayAcquistionSessionUrl() default "https://sandboxext.smartpaylease.com/acquisitions-api/session";
    
    @AttributeDefinition(name = "SmartPay Lease acquistion JS Url",description = "SmartPay Lease acquistion JS Url", type = AttributeType.STRING)
    String getSmartPayAcquistionLeaseUrl() default "https://sandboxext.smartpaylease.com/acquisitions-api/lease-application";

    @AttributeDefinition(name = "SmartPay Lease acquistion Funding Source JS Url",description = "SmartPay Lease acquistion Funding Source JS Url", type = AttributeType.STRING)
    String getSmartPayAcquistionFundingSrcUrl() default "https://sandboxext.smartpaylease.com/acquisitions-api/funding-source/";

    @AttributeDefinition(name = "SmartPay Lease Application username",description = "SmartPay Lease Application username", type = AttributeType.STRING)
    String[] getSmartPayLeaseAppUsername() default{"STRAIGHT_TALK:tracfone-online,TOTAL_WIRELESS:tracfone-online"};

    @AttributeDefinition(name = "SmartPay Lease Application password",description = "SmartPay Lease Application password", type = AttributeType.STRING)
    String[] getSmartPayLeaseAppPass() default{"STRAIGHT_TALK:vJZ%3A8$7?\u003d0o1B.)s,TOTAL_WIRELESS:vJZ%3A8$7?\u003d0o1B.)s"};   

    @AttributeDefinition(name = "SmartPay Lease Application pool",description = "SmartPay Lease Application pool", type = AttributeType.STRING)
    String[] getSmartPayLeaseAppPool() default{"STRAIGHT_TALK:tracfone-internal,TOTAL_WIRELESS:tracfone-internal"};  

    @AttributeDefinition(name = "SmartPay Lease Application merchant key",description = "SmartPay Lease Application merchant key", type = AttributeType.STRING)
    String[] getSmartPayLeaseAppMerchant() default{"STRAIGHT_TALK:da76ba02cb241a2d222b62a3cd2fbeb52fceda12","TOTAL_WIRELESS:8d5e1c63516c33b9fd004e25b0d576cdb2e2a1f9"}; 

}