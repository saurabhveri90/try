/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
 package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

import org.osgi.framework.Constants;

/**
 * Defines the {@code protectionPlanCardModel} Sling Model used for the {@code /apps/tracfone-core/components/commerce/protectionplancard} component.
 */


public interface ProtectionPlanCardModel extends ComponentExporter {

	/**
	 * <p>Fetches selection of the product</p>
	 * 
	 * @return String - selection of the product
	 */
	@JsonProperty("hppSelection")
	public String getHppSelection();
	
    
	/**
	 * <p>Fetches promotext of the product</p>
	 * 
	 * @return String - hppPromotext
	 */
	@JsonProperty("hppPromotext")
	public String getHppPromoText();
	
	/**
	 * <p>Fetches plan name for the product</p>
	 * 
	 * @return String - hppPlanname
	 */
	@JsonProperty("hppPlanname")
	public String getHppPlanName();

	/**
	 * <p>Fetches details for the product</p>
	 * 
	 * @return String - hppPlanseedetails
	 */
	@JsonProperty("hppPlanseedetails")
	public String getHppPlanseedetails();
	
	/**
	 * <p>Fetches plan data discription for the product</p>
	 * 
	 * @return String - planDataDescription
	 */
	@JsonProperty("hppPlanDataDescription")
		public String getHppPlanDataDescription();

	/**
	 * <p>Fetches plan data label for the product</p>
	 *
	 * @return String - hppPlandatalabel
	 */
	@JsonProperty("hppPlandatalabel")
	public String getHppPlanDataLabel();

	/**
	 * <p>Fetches plan thumbnail image for the product</p>
	 *
	 * @return String - hppPlanthumbnailimage
	 */
	@JsonProperty("hppPlanthumbnailimage")
	public String getHppPlanthumbnailimage();

	/**
	 * <p>Fetches plan service days for the product</p>
	 *
	 * @return String - hppPlanservicedays
	 */
	@JsonProperty("hppPlanservicedays")
	public String getHppPlanservicedays();

	/**
	 * <p>Fetches plan details of the product</p>
	 * @return String - hppPlantermconditions
	 *
	 */
	@JsonProperty("hppPlantermsconditions")
	public String getHppPlantermsconditions();

	/**
	 * <p>Fetches plan enroll title for the product</p>
	 *
	 * @return String - hppEnrolltitle
	 */
	@JsonProperty("hppEnrolltitle")
	public String getHppEnrolltitle();

	/**
	 * <p>Fetches enroll description for the product</p>
	 *
	 * @return String - hppEnrolldecsription
	 */
	@JsonProperty("hppEnrolldecsription")
	public String getHppEnrolldecsription();

	/**
	 * <p>Fetches plan enroll accepteance condition of the product</p>
	 * @return String - hppEnrollcondition
	 *
	 */
	@JsonProperty("hppEnrollcondition")
	public String getHppEnrollcondition();
	
	/**
	 * <p>
	 * Fetches is Monthly Plan Value
	 * </p>
	 * @return Boolean - isMonthlyPlan
	 */
	@JsonProperty("isMonthlyPlan")
	public String getIsMonthlyPlan(); 

	/**
	 * <p>Fetches language</p>
	 * 
	 * @return String - language 
	 */
	@JsonProperty(Constants.BUNDLE_NATIVECODE_LANGUAGE)
	String getLanguage();
	
	/**
	 * <p>Fetches queryString for the price api call</p>
	 * 
	 * @return String - queryString 
	 */
	@JsonProperty("queryString")
	String getQueryString();
	
	/**
	 * <p>
	 * Method to return Price Api domain
	 * </p>
	 * 
	 * @return String
	 */
	public String getApiDomain() ;
	
	/**
	 * <p>
	 * Method to return Price Api Path
	 * </p>
	 * 
	 * @return String
	 */
	public String getPriceApiPath() ;
	
	/**
	 * <p>
	 * Method to return Payment Type text
	 * </p>
	 * 
	 * @return String
	 */
	@JsonProperty("paymentText")
	public String getPaymentText() ;
	
	/**
	 * <p>Fetches plan details of the product</p>
	 * @return String - hppPlantermsconditionslink
	 *
	 */
	@JsonProperty("hppPlantermsconditionslink")
	public String getHppPlanTermsConditionsLink();

	/**
	  * <p>
	 * Fetches the export child items
	 * </p>
	 *
	 * 
	 * @return Map<String, ? extends ComponentExporter> - the export child items
	 */
	public Map<String, ? extends ComponentExporter> getItems();
	
	/**
	 * <p>
	 * Method to return exporter type
	 * </p>
	 * 
	 * @return String
	 */
	@Override
	public String getExportedType();


	public String getDescription();


	public Integer getId();


	public String getName();
}
