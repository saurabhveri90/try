package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import org.apache.sling.models.annotations.Via;
import com.tracfonecore.core.utils.ConfigurationUtil;
import org.apache.commons.lang3.StringUtils;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.models.FreeSimKitToCartModel;

import javax.inject.Inject;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { FreeSimKitToCartModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/freesimkittocart", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class FreeSimKitToCartModelImpl implements FreeSimKitToCartModel {
	
	@Self
	private SlingHttpServletRequest request;

	@Inject
	private ApplicationConfigService applicationConfigService;

	@Inject
	private TracfoneApiGatewayService tracfoneApiService;

	@Inject
	private Page currentPage;
	
	@ValueMapValue
	private String subheading;

	@ValueMapValue
	private String inputFieldPlaceholder;

	@ValueMapValue
	private String summary;

    @ValueMapValue
	private String buttonLabel;

    @ValueMapValue
    private String ctaText;

    @ValueMapValue
	private String ctaLink;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String hideRecaptchaBox;
	
	@Inject
	private Resource resource;

	/**
     * @return String - exported Type
     */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
	/**
	 * <p>
	 * Returns home page level from configuration
	 * </p>
	 * 
	 * @return int - homepagelevel
	 */
	private int getHomePageLevel() {

		return applicationConfigService.getHomePageLevel();
	}

	/**
     * @return String - subheading
     */
	@Override
	public String getSubheading() {
		return subheading;
	}

	/**
     * @return String - inputFieldPlaceholder
     */
	@Override
	public String getInputFieldPlaceholder() {
		return inputFieldPlaceholder;
	}

	/**
     * @return String - summary
     */
	@Override
	public String getSummary() {
		return summary;
	}

    /**
     * @return String - buttonLabel
     */
	@Override
	public String getButtonLabel() {
		return buttonLabel;
	}

    /**
     * @return String - ctatext
     */
	@Override
	public String getCtaText() {
		return ctaText;
	}

    /**
     * @return String - ctaLink
     */
	@Override
	public String getCtaLink() {
		return ctaLink;
	}

	/**
	 * <p>
	 * Fetches ReCaptcha SiteKey property from config
	 * </p>
	 *
	 * @return String[] - reCaptchaSiteKey
	 */
	@Override
	public String getReCaptchaSiteKey() {

		return ConfigurationUtil.getConfigValue(applicationConfigService.getReCaptchaSiteKey(), getBrand());
	}

	private String getBrand() {

		return CommerceUtil.getBrandValue(currentPage, getHomePageLevel());
	}

	/**
	 * <p>
	 * Fetches hide recaptcha
	 * </p>
	 *
	 * @return String - hide recaptcha
	 */
	@Override
	public String getHideRecaptchaBox() {
		return hideRecaptchaBox;
	}
}
