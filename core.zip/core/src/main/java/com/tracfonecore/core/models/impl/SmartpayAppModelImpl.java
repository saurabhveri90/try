package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.SmartpayAppModel;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.utils.ApplicationUtil;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;


@Model(adaptables = {SlingHttpServletRequest.class, Resource.class}, adapters = {SmartpayAppModel.class,
        ComponentExporter.class}, resourceType = SmartpayAppModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true")})
public class SmartpayAppModelImpl implements SmartpayAppModel {

    private static final Logger LOGGER = LoggerFactory.getLogger(SmartpayAppModelImpl.class);
    protected static final String RESOURCE_TYPE = "tracfone-core/components/commerce/smartpayappmodal";


    @Self
    private SlingHttpServletRequest request;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String linkText;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String linkAccessibility;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String fullPricePagePath;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String target;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String donotfollowlink;

    @Inject
    private TracfoneApiGatewayService tracfoneApiService;
    
    @Inject
	private Resource resource;

    @PostConstruct
    protected void initModel() {

    }

    /**
	 * <p> This method is used to get query string for category detail api call
	 * @return -String : Query String
	 */
    public String getSmartPaySearchOptimizedQuery() {
    	return tracfoneApiService.getSmartPaySearchOptimizedQuery();
    }

    /**
     * @return String - apiDomain
     */
    public String getApiDomain() {
        return tracfoneApiService.getApiDomain();
    }

    /**
     * @return String -  category api path
     */
    public String getCategoryApiPath() {
        return tracfoneApiService.getCategoryApiPath();
    }
    
    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

    @Override
	public String getLinkText() {
		return linkText;
	}

	@Override
	public String getLinkAccessibility() {
		return linkAccessibility;
	}

	@Override
	public String getFullPricePagePath() {
		return ApplicationUtil.getShortUrl(request.getResourceResolver(), fullPricePagePath);
	}

	@Override
	public String getTarget() {
		if(target != null && !target.equals(""))
			return target;
		else
		{
			return ApplicationConstants.FALSE;
		}
		
	}
	@Override
	public String getDonotfollowlink() {
		return ApplicationUtil.getNoFollow(donotfollowlink);
	}
	
	public String getQueryString() {
        return CommerceConstants.FULL_PRICE_QUERY;
    }
    
}
