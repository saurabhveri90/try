package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.LinkBean;

public interface CpniAmrPreferenceModel extends ComponentExporter {

	/**
	 * @return heading
	 */
	@JsonProperty("heading")
	public String getHeading();

	/**
	 * @return summary
	 */
	@JsonProperty("summary")
	public String getSummary();

	/**
	 * @return heading
	 */
	@JsonProperty("subHeading")
	public String getSubHeading();

	/**
	 * @return textFieldHeading
	 */
	@JsonProperty("textFieldHeading")
	public String getTextFieldHeading();

	/**
	 * @return inputFieldPlaceholder
	 */
	@JsonProperty("inputFieldPlaceholder")
	public String getInputFieldPlaceholder();

	/**
	 * @return dontShareLabel
	 */
	@JsonProperty("dontShareLabel")
	public String getDontShareLabel();

	/**
	 * @return shareLabel
	 */
	@JsonProperty("shareLabel")
	public String getShareLabel();

    /**
	 * @return buttonLabel
	 */
	@JsonProperty("buttonLabel")
	public String getButtonLabel();

	/**
     * Get the disableEnterpriseCaptcha
     * @return String - disableEnterpriseCaptcha
     */
    public String getDisableEnterpriseCaptcha(); 

	/**
     * Get the reCaptchaSiteKey
    * @return String - reCaptchaSiteKey
     */
    public String getReCaptchaEnterpriseSiteKey(); 

	/**
     * Get the reCaptchaSiteKey
    * @return String - reCaptchaSiteKey
     */
    public String getReCaptchaSiteKey(); 

}
