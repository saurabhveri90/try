/*
 *  Copyright 2023 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;


import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * Defines the {@code Content Facts} Sling Model used for the {@code tracfone-core/components/content/fccplanlabel} component.
 */
public interface FccPlanLabelsModel extends ComponentExporter {

	
	/**
	 * <p>Fetches Content Fragment Path</p>
	 * 
	 * @return String - content fragment path
	 */
	@JsonProperty("cfPath")
	public String getCfPath();

	/**
	 * <p>Fetches Page type</p>
	 * 
	 * @return String - page type
	 */
	@JsonProperty("pagetype")
	public String getPagetype();

	/**
	 * Fetches fccZipcodeFeesApiUrl value
	 * </p>
	 * 
	 * @return String - fccZipcodeFeesApiUrl
	 */
	@JsonProperty("fccZipcodeFeesApiUrl")
	public String getFccZipcodeFeesApiUrl();
	
	/**
	 * Fetches taxRequiredStates value
	 * </p>
	 * 
	 * @return String - taxRequiredStates
	 */
	@JsonProperty("taxRequiredStates")
	public String[] getTaxRequiredStates();

	/**
	 * Fetches fccClientId value
	 * </p>
	 * 
	 * @return String - fccClientId
	 */
	@JsonProperty("fccClientId")
	public String getFccClientId();

}
