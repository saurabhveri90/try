/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Header} Sling Model used for the {@code /apps/tracfone-core/components/spa/structure/checkoutheader} component.
 */
public interface CheckoutHeaderModel extends ComponentExporter {

    /**
     * <p>Fetches file reference for the logo</p>
     *
     * @return String - file reference for the logo
     */
    @JsonProperty("fileReference")
    public String getFileReference();

    /**
     * <p>Fetches Desktop Small file reference for the logo</p>
     *
     * @return String - file reference for the logo
     */
    @JsonProperty("fileReferenceDeskSm")
    public String getFileReferenceDeskSm();

    @JsonProperty("fileReferenceDeskSmAssetId")
    public String getFileReferenceDeskSmAssetId();

    @JsonProperty("fileReferenceDeskSmAssetAgencyId")
    public String getFileReferenceDeskSmAssetAgencyId();

    /**
     * <p>Fetches Mobile Small file reference for the logo</p>
     *
     * @return String - file reference for the logo
     */
    @JsonProperty("fileReferenceMobile")
    public String getFileReferenceMobile();

    @JsonProperty("fileReferenceMobileAssetId")
    public String getFileReferenceMobileAssetId();

    @JsonProperty("fileReferenceMobileAssetAgencyId")
    public String getFileReferenceMobileAssetAgencyId();

    /**
   	 * <p>Fetches no-follow value for link</p>
   	 *
   	 * @return String -  no-follow value
   	 */
   	@JsonProperty("doNotFollow")
    public String getDoNotFollow();
   	
    /**
     * <p>Fetches alt text for Desktop logo</p>
     *
     * @return String - alt text for desktop logo
     */
    @JsonProperty("logoAltTextDesktop")
    public String getLogoAltTextDesktop();

    /**
     * <p>Fetches alt text for Mobile logo</p>
     *
     * @return String - alt text for mobile logo
     */
    @JsonProperty("logoAltTextMobile")
    public String getLogoAltTextMobile();

    /**
     * <p>Fetches destination link for the logo</p>
     *
     * @return String - destination link for the logo
     */
    @JsonProperty("logoTargetURL")
    public String getLogoTargetURL();
    
    /**
     * <p>Fetches destination link for the logo</p>
     *
     * @return String - destination link for the logo
     */
    @JsonProperty("logoNewWindow")
    public String getLogoNewWindow();
    
    /**
     * <p>Fetches destination link for the logo</p>
     *
     * @return String - destination link for the logo
     */
    @JsonProperty("logoRedirectionMessage")
    public String getLogoRedirectionMessage();
    
    /**
     * <p>Fetches destination link for the logo</p>
     *
     * @return String - destination link for the logo
     */
    @JsonProperty("cartIconPageUrl")
    public String getCartIconPageUrl();
    
	
	 /**
     * <p>Fetches destination link for the logo</p>
     *
     * @return String - destination link for the logo
     */
    @JsonProperty("cartUrlTarget")
    public String getCartUrlTarget();
    
    /**
     * <p>Fetches destination link for the logo</p>
     *
     * @return String - destination link for the logo
     */
    @JsonProperty("placementTextGTM")
    public String getPlacementTextGTM();
    
    /**
     * <p>Fetches destination link for the logo</p>
     *
     * @return String - destination link for the logo
     */
    @JsonProperty("dataGTMCTALogoDesktop")
    public String getDataGTMCTALogoDesktop();
    
    /**
     * <p>Fetches destination link for the logo</p>
     *
     * @return String - destination link for the logo
     */
    @JsonProperty("dataGTMCTALogoMobile")
    public String getDataGTMCTALogoMobile();
    
    /**
     * <p>Fetches destination link for the logo</p>
     *
     * @return String - destination link for the logo
     */
    @JsonProperty("dataGTMCTACart")
    public String getDataGTMCTACart();	
    
    /**
	 * <p>Fetches componentVersion for the header</p>
	 *
	 * @return String - componentVersion for the header
	 */
	@JsonProperty("componentVersion")
	public String getComponentVersion();

    /**
	 * <p>Fetches isNationalRetailerPage for the header</p>
	 *
	 * @return Boolean - isNationalRetailerPage for the header
	 */
	@JsonProperty("isNationalRetailerPage")
	public Boolean getIsNationalRetailerPage();

    /**
	 * <p>Fetches isAcpMigration for the header</p>
	 *
	 * @return Boolean - isAcpMigration for the header
	 */
	@JsonProperty("isAcpMigration")
	public Boolean getIsAcpMigration();

}
