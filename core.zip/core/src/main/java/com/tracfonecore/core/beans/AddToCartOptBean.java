/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;

/**
 * <p>Defines bean to hold category type detail</p>
 */
public class AddToCartOptBean {

	private String label;
	private String summary;
	private String customerType;
	private String paymentType;
	private String prefixLabel;
	private String suffixLabel;
	private String flowType;
	private String showLoginModal;
	private String showUpgradeMsg;

	/**
	 * @return the label
	 */
	public String getLabel() {
		return label;
	}
	/**
	 * @return the summary
	 */
	public String getSummary() {
		return summary;
	}
	/**
	 * @return the customerType
	 */
	public String getCustomerType() {
		return customerType;
	}
	/**
	 * @param label the label to set
	 */
	public void setLabel(String label) {
		this.label = label;
	}
	/**
	 * @param summary the summary to set
	 */
	public void setSummary(String summary) {
		this.summary = summary;
	}
	/**
	 * @param customerType the customerType to set
	 */
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	/**
	 *<p>Fetches paymentType</p>
	 *
	 * @return the paymentType
	 */
	public String getPaymentType() {
		return paymentType;
	}
	/**
	 * <p>Sets paymentType</p>
	 *
	 *@param paymentType - the paymentType to set
	 */
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	/**
	 *<p>Fetches prefixLabel</p>
	 *
	 * @return the prefixLabel
	 */
	public String getPrefixLabel() {
		return prefixLabel;
	}
	/**
	 * <p>Sets prefixLabel</p>
	 *
	 *@param prefixLabel - the prefixLabel to set
	 */
	public void setPrefixLabel(String prefixLabel) {
		this.prefixLabel = prefixLabel;
	}
	/**
	 *<p>Fetches suffixLabel</p>
	 *
	 * @return the suffixLabel
	 */
	public String getSuffixLabel() {
		return suffixLabel;
	}
	/**
	 * <p>Sets suffixLabel</p>
	 *
	 *@param suffixLabel - the suffixLabel to set
	 */
	public void setSuffixLabel(String suffixLabel) {
		this.suffixLabel = suffixLabel;
	}

	/**
	 *<p>Fetches flowType</p>
	 *
	 * @return the flowType
	 */
	public String getFlowTypeOption () { return flowType; }

	/**
	 *<p>Sets flowType</p>
	 *
	 * @param flowType - flow type for the option
	 */
	public void setFlowTypeOption(String flowType) {
		this.flowType = flowType;
	}

	/**
	 * <p>Fetches showLoginModal</p>
	 * 
	 * @return the showLoginModal
	 */
	public String getShowLoginModal() {
		return showLoginModal;
	}

	/**
	 * <p>Sets showLoginModal</p>
	 * 
	 * @param showLoginModal - the showLoginModal to set
	 */
	public void setShowLoginModal(String showLoginModal) {
		this.showLoginModal = showLoginModal;
	}

	public String getShowUpgradeMsg() {
		return showUpgradeMsg;
	}
	public void setShowUpgradeMsg(String showUpgradeMsg) {
		this.showUpgradeMsg = showUpgradeMsg;
	}
}
