/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl.v1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.CreditCardVendorBean;
import com.tracfonecore.core.beans.PaymentOptionBean;
import com.tracfonecore.core.beans.ShippingMethodBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.CheckoutDetailModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CheckoutDetailModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/checkoutdetail/v1/checkoutdetail", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CheckoutDetailModelImpl implements CheckoutDetailModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;

	@Inject
	private Resource resource;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String shippingOptionsLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String shippingOptionsModalContent;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String positionCheckoutProcess;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String positionCheckoutSummary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String tradeInSubTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String learnMoreLinkTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String characterLimitGiftMessage;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String termsConditionsLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String tWPTermsConditionsLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String legalConsentLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stByopReviewCheck;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String smartPayConsentLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String smartPayTcpaConsentLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String zeroTransactionPaymentMessage;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String applicationLearnMoreLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String smartPayModalHeadline;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String smartPayModalContent;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String cvvModalHeadline;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String cvvModalImage;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String cvvModalImageAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String cartDetailComponentVersion;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String paymentNotification;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String componentVersion;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String guestCheckoutPossibleMessage;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String guestCheckoutNotPossibleMessage;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String onlyLoginAndGuestCheckoutPossibleMessage;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String onlyLoginPossibleMessage;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String shippingDisclaimerMessage;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String byPassPayPalMigrationCheck;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String paypalButtonSize;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String paypalButtonColor;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String paypalButtonShape;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String paypalButtonLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String paypalBillingAgreementDescription;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String disableIntangiblePaypal;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String disableStore1Paypal;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String vasStandalonePagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hideCheckoutLoginStep;
	
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String disableCaptcha;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String twoFAInfoLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String smartPayDisclaimer;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String activationSupportKitTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String activationSupportKitSubTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String audioDeviceIconPath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String audioDeviceTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String braileIconPath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String braileIconTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String dyslexiaIconPath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String dyslexiaIconTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String qrCodeIconPath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accessibilityKitIconPath;	

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String qrCodeIconTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String modalHeading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String codeSentViaText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String codeSentViaEmailText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String didNotGetCodeText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String doNotHaveAccessText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String customerCareText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stillUnableToRecieveCodeText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String frequentDialedNumbersText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String phoneNumberOneText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String phoneNumberTwoText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String qualifyingRulesText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String frequentDialedNumberQualifyingRulesText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ruleOne;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ruleTwo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ruleOneInTwo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ruleTwoInTwo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ruleThreeInTwo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ruleFourInTwo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ruleFiveInTwo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stCCNumber;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String tfCCNumber;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String tbvzCCNumber;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String migrationAccessCodeText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String migrationAccessInputText;
	

	private List<ShippingMethodBean> shippingMethods = Collections.emptyList();

	private List<String> checkoutSteps = Collections.emptyList();

	private List<PaymentOptionBean> paymentOptions = Collections.emptyList();

	private List<String> tradeInOptions = Collections.emptyList();

	private List<String> activationSupportKitOptions = Collections.emptyList();

	private List<CreditCardVendorBean> creditCardVendors = Collections.emptyList();

	@PostConstruct
	private void initModel() {
		shippingMethods = new ArrayList<>();
		checkoutSteps = new ArrayList<>();
		paymentOptions = new ArrayList<>();
		creditCardVendors = new ArrayList<>();
		tradeInOptions = new ArrayList<>();
		activationSupportKitOptions = new ArrayList<>();
		if (resource != null) {
			getMultifieldResource();
		}
	}

	private void getMultifieldResource() {
		for (Resource child : resource.getChildren()) {
			Iterator<Resource> it = child.listChildren();
			if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.SHIPPING_METHODS.equals(child.getName())) {
				setShippingMethods(it, shippingMethods);
			} else if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.PAYMENT_OPTIONS.equals(child.getName())) {
				setPaymentOptions(it, paymentOptions);
			} else if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.CREDIT_CARD_VENDORS.equals(child.getName())) {
				setCreditCardVendors(it, creditCardVendors);
			} else if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.CHECKOUT_STEPS.equals(child.getName())) {
				setCheckoutSteps(it);
			} else if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.TRADE_IN_OPTIONS.equals(child.getName())) {
				setTradeInOptions(it);
			} else if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.ACTIVATION_SUPPORT_KIT_OPTIONS.equals(child.getName())) {
				setActivationSupportKitOptions(it);
			}
		}
	}

	private void setTradeInOptions(Iterator<Resource> it) {
		while (it.hasNext()) {
			Resource grandChild = it.next();
			tradeInOptions.add(grandChild.getValueMap().get(ApplicationConstants.TRADE_IN_OPTION, String.class));
		}
	}

	private void setActivationSupportKitOptions(Iterator<Resource> it) {
		while (it.hasNext()) {
			Resource grandChild = it.next();
			activationSupportKitOptions.add(grandChild.getValueMap().get(ApplicationConstants.ACTIVATION_SUPPORT_KIT_OPTION, String.class));
		}
	}

	private void setCheckoutSteps(Iterator<Resource> it) {
		while (it.hasNext()) {
			Resource grandChild = it.next();
			checkoutSteps.add(grandChild.getValueMap().get(ApplicationConstants.CHECKOUT_STEP, String.class));
		}
	}

	/**
	 * <p>
	 * Populates a list with all the shipping methods
	 * </p>
	 * 
	 * @param it
	 *            - iterator of the parent node
	 * @param shippingMethods
	 *            - list in which the shipping methods data needs to be set
	 */
	private void setShippingMethods(Iterator<Resource> it, List<ShippingMethodBean> shippingMethods) {
		while (it.hasNext()) {
			ShippingMethodBean shippingMethodsBean = new ShippingMethodBean();
			Resource grandChild = it.next();
			shippingMethodsBean.setShippingMethodId(
					grandChild.getValueMap().get(ApplicationConstants.SHIPPING_METHOD_ID, String.class));
			shippingMethodsBean.setShippingMethodName(
					grandChild.getValueMap().get(ApplicationConstants.SHIPPING_METHOD_NAME, String.class));
			shippingMethodsBean.setShippingCharge(
					grandChild.getValueMap().get(ApplicationConstants.SHIPPING_CHARGE, String.class));
			String deliveryMinDays = grandChild.getValueMap().get(ApplicationConstants.DELIVERY_MIN_DAYS, String.class);
			String deliveryMaxDays = grandChild.getValueMap().get(ApplicationConstants.DELIVERY_MAX_DAYS, String.class);
			String deliveryRange = "";
			if (StringUtils.isNotBlank(deliveryMinDays)) {
				deliveryRange = deliveryMinDays + "-" + deliveryMaxDays;
			} else {
				deliveryRange = deliveryMaxDays;
			}
			shippingMethodsBean.setDeliveryRange(deliveryRange);
			shippingMethodsBean.setDeliveryMaxDays(deliveryMaxDays);
			shippingMethodsBean.setDeliveryMinDays(deliveryMinDays);
			shippingMethodsBean.setShippingVendorLogo(
					grandChild.getValueMap().get(ApplicationConstants.SHIPPING_VENDOR_LOGO, String.class));
			shippingMethodsBean.setShippingVendorLogoAltText(
					grandChild.getValueMap().get(ApplicationConstants.SHIPPING_VENDOR_LOGO_ALT_TEXT, String.class));
			shippingMethods.add(shippingMethodsBean);
		}
	}

	/**
	 * <p>
	 * Populates a list with all the payment options
	 * </p>
	 * 
	 * @param it
	 *            - iterator of the parent node
	 * @param paymentOptions
	 *            - list in which the payment options data needs to be set
	 */
	private void setPaymentOptions(Iterator<Resource> it, List<PaymentOptionBean> paymentOptions) {
		while (it.hasNext()) {
			PaymentOptionBean paymentOptionBean = new PaymentOptionBean();
			Resource grandChild = it.next();
			paymentOptionBean.setPaymentOptionId(
					grandChild.getValueMap().get(ApplicationConstants.PAYMENT_OPTION_ID, String.class));
			paymentOptionBean.setPaymentOptionName(
					grandChild.getValueMap().get(ApplicationConstants.PAYMENT_OPTION_NAME, String.class));
			paymentOptionBean.setPaymentOptionLogo(
					grandChild.getValueMap().get(ApplicationConstants.PAYMENT_OPTION_LOGO, String.class));
			paymentOptionBean.setPaymentOptionLogoAltText(
					grandChild.getValueMap().get(ApplicationConstants.PAYMENT_OPTION_LOGO_ALT_TEXT, String.class));
			paymentOptions.add(paymentOptionBean);
		}
	}

	/**
	 * <p>
	 * Populates a list of all credit card vendors
	 * </p>
	 * 
	 * @param it
	 *            - iterator of the parent node
	 * @param creditCardVendors
	 *            - list in which the credit card vendor data to be set
	 */
	private void setCreditCardVendors(Iterator<Resource> it, List<CreditCardVendorBean> creditCardVendors) {
		while (it.hasNext()) {
			CreditCardVendorBean creditCardVendorBean = new CreditCardVendorBean();
			Resource grandChild = it.next();
			creditCardVendorBean.setCreditCardVendorName(
					grandChild.getValueMap().get(ApplicationConstants.CREDIT_CARD_VENDOR_NAME, String.class));
			creditCardVendorBean.setCreditCardVendorLogo(
					grandChild.getValueMap().get(ApplicationConstants.CREDIT_CARD_VENDOR_LOGO, String.class));
			creditCardVendorBean.setCreditCardVendorLogoAltText(
					grandChild.getValueMap().get(ApplicationConstants.CREDIT_CARD_VENDOR_LOGO_ALT_TEXT, String.class));
			creditCardVendors.add(creditCardVendorBean);
		}
	}

	@Override
	public String getShippingOptionsLink() {
		return shippingOptionsLink;
	}

	@Override
	public String getShippingOptionsModalContent() {
		return shippingOptionsModalContent;
	}

	@Override
	public List<ShippingMethodBean> getShippingMethods() {
		return new ArrayList<>(shippingMethods);
	}

	@Override
	public List<String> getCheckoutSteps() {
		return new ArrayList<>(checkoutSteps);
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getPositionCheckoutProcess() {
		return positionCheckoutProcess;
	}

	@Override
	public String getPositionCheckoutSummary() {
		return positionCheckoutSummary;
	}

	@Override
	public String getTradeInSubTitle() {
		return tradeInSubTitle;
	}

	@Override
	public String getLearnMoreLinkTitle() {
		return learnMoreLinkTitle;
	}

	@Override
	public String getCharacterLimitGiftMessage() {
		return characterLimitGiftMessage;
	}

	@Override
	public String getTermsConditionsLink() {
		return termsConditionsLink;
	}

	@Override
	public String getLegalConsentLink() {
		return legalConsentLink;
	}

	@Override
	public String getStByopReviewCheck() {
		return stByopReviewCheck;
	}
	@Override
	public String getSmartPayConsentLink() {
		return smartPayConsentLink;
	}

	@Override
	public String getSmartPayTcpaConsentLink() {
		return smartPayTcpaConsentLink;
	}

	@Override
	public List<PaymentOptionBean> getPaymentOptions() {
		return new ArrayList<>(paymentOptions);
	}

	@Override
	public List<String> getTradeInOptions() {
		return new ArrayList<>(tradeInOptions);
	}

	@Override
	public List<String> getActivationSupportKitOptions() {
		return new ArrayList<>(activationSupportKitOptions);
	}


	@Override
	public List<CreditCardVendorBean> getCreditCardVendors() {
		return new ArrayList<>(creditCardVendors);
	}

	@Override
	public String getZeroTransactionPaymentMessage() {
		return zeroTransactionPaymentMessage;
	}
	
	@Override
	public String getApplicationLearnMoreLink() {
		return applicationLearnMoreLink;
	}

	@Override
	public String getSmartPayModalHeadline() {
		return smartPayModalHeadline;
	}

	@Override
	public String getSmartPayModalContent() {
		return smartPayModalContent;
	}

	@Override
	public String getCvvModalHeadline() {
		return cvvModalHeadline;
	}

	@Override
	public String getCvvModalImage() {
		return cvvModalImage;
	}

	@Override
	public String getCvvModalImageAltText() {
		return cvvModalImageAltText;
	}

	@Override
	public String getPaymentNotification() {
		return paymentNotification;
	}

	@Override
	public String getCartDetailComponentVersion() {
		return StringUtils.isNotBlank(cartDetailComponentVersion)? cartDetailComponentVersion: "v1";
	}
	
	@Override
    public String getComponentVersion() {
        return StringUtils.isNotBlank(componentVersion) ?  componentVersion: "v1";
    }

	@Override
    public String getGuestCheckoutPossibleMessage() {
        return guestCheckoutPossibleMessage;
    }
    
    @Override
    public String getGuestCheckoutNotPossibleMessage() {
        return guestCheckoutNotPossibleMessage;
    }
    
    @Override
    public String getOnlyLoginAndGuestCheckoutPossibleMessage() {
        return onlyLoginAndGuestCheckoutPossibleMessage;
    }
    
    @Override
    public String getOnlyLoginPossibleMessage() {
        return onlyLoginPossibleMessage;
    }

	@Override
	public String getShippingDisclaimerMessage() {
		return shippingDisclaimerMessage;
	}

	@Override
	public String getByPassPayPalMigrationCheck() {
		return byPassPayPalMigrationCheck;
	}

	@Override
	public String getPaypalButtonSize() {
		return paypalButtonSize;
	}

	@Override
	public String getPaypalButtonColor() {
		return paypalButtonColor;
	}

	@Override
	public String getPaypalButtonShape() {
		return paypalButtonShape;
	}

	@Override
	public String getPaypalButtonLabel() {
		return paypalButtonLabel;
	}

	@Override
	public String getPaypalBillingAgreementDescription() {
		return paypalBillingAgreementDescription;
	}

	@Override
	public String getDisableIntangiblePaypal() {
		return disableIntangiblePaypal;
	}

	@Override
	public String getDisableStore1Paypal() {
		return disableStore1Paypal;
	}

	@Override
	public String getVasStandalonePagePath() {
		return vasStandalonePagePath;
	}
	
	@Override
	public boolean getHideCheckoutLoginStep() {
		if(StringUtils.isNotBlank(hideCheckoutLoginStep)){
			return  Boolean.parseBoolean(hideCheckoutLoginStep);
		} else{
			return false;
		}
	}

	@Override
	public String getDisableCaptcha() {
		return disableCaptcha;
	}

	/**
	 * @return String - twoFAInfoLink
	 */
	@Override
	public String getTwoFAInfoLink() {
		return twoFAInfoLink;
	}

	@Override
	public String getSmartPayDisclaimer() {
		return smartPayDisclaimer;
	}

	@Override
	public String getActivationSupportKitTitle() {
		return activationSupportKitTitle;
	}

	@Override
	public String getActivationSupportKitSubTitle() {
		return activationSupportKitSubTitle;
	}

	@Override
	public String getAudioDeviceIconPath() {
		return audioDeviceIconPath;
	}

	@Override
	public String getAudioDeviceTitle() {
		return audioDeviceTitle;
	}

	@Override
	public String getBraileIconPath() {
		return braileIconPath;
	}

	@Override
	public String getBraileIconTitle() {
		return braileIconTitle;
	}

	@Override
	public String getDyslexiaIconPath() {
		return dyslexiaIconPath;
	}

	@Override
	public String getDyslexiaIconTitle() {
		return dyslexiaIconTitle;
	}

	@Override
	public String getQrCodeIconPath() {
		return qrCodeIconPath;
	}

	@Override
	public String getQrCodeIconTitle() {
		return qrCodeIconTitle;
	}

	@Override
	public String getAccessibilityKitIconPath() {
		return accessibilityKitIconPath;
	}

	@Override
	public String getModalHeading() {
		return modalHeading;
	}

	@Override
	public String getCodeSentViaText() {
		return codeSentViaText;
	}

	@Override
	public String getCodeSentViaEmailText() {
		return codeSentViaEmailText;
	}

	@Override
	public String getDidNotGetCodeText() {
		return didNotGetCodeText;
	}

	@Override
	public String getDoNotHaveAccessText() {
		return doNotHaveAccessText;
	}

	@Override
	public String getCustomerCareText() {
		return customerCareText;
	}

	@Override
	public String getStillUnableToRecieveCodeText() {
		return stillUnableToRecieveCodeText;
	}

	@Override
	public String getFrequentDialedNumbersText() {
		return frequentDialedNumbersText;
	}

	@Override
	public String getPhoneNumberOneText() {
		return phoneNumberOneText;
	}

	@Override
	public String getPhoneNumberTwoText() {
		return phoneNumberTwoText;
	}

	@Override
	public String getQualifyingRulesText() {
		return qualifyingRulesText;
	}

	@Override
	public String getFrequentDialedNumberQualifyingRulesText() {
		return frequentDialedNumberQualifyingRulesText;
	}

	@Override
	public String getRuleOne() {
		return ruleOne;
	}

	@Override
	public String getRuleTwo() {
		return ruleTwo;
	}

	@Override
	public String getRuleOneInTwo() {
		return ruleOneInTwo;
	}

	@Override
	public String getRuleTwoInTwo() {
		return ruleTwoInTwo;
	}

	@Override
	public String getRuleThreeInTwo() {
		return ruleThreeInTwo;
	}

	@Override
	public String getRuleFourInTwo() {
		return ruleFourInTwo;
	}

	@Override
	public String getRuleFiveInTwo() {
		return ruleFiveInTwo;
	}

	@Override
	public String getSTCCNumber() {
		return stCCNumber;
	}

	@Override
	public String getTFCCNumber() {
		return tfCCNumber;
	}

	@Override
	public String getTbvzCCNumber() {
		return tbvzCCNumber;
	}

	@Override
	public String getMigrationAccessCodeText() {
		return migrationAccessCodeText;
	}

	@Override
	public String getMigrationAccessInputText() {
		return migrationAccessInputText;
	}

	@Override
	public String getTWPTermsConditionsLink() {
		return tWPTermsConditionsLink;
	}
}
