package com.tracfonecore.core.beans;

public class CarouselCardBean {

    private String cardTitle;
	private String cardText;
	private String cardBackgroundColor;
	private String cardTextColor;
	private String cardImage;
	private String imageAltText;
	private String imgVerticalAlign;
	private String cardMobileImage;
	private String tooltipLogo;
	private String tooltipMsg;
	private boolean disableButton;


	public String getCardTitle() {
		return cardTitle;
	}

	public void setCardTitle(String cardTitle) {
		this.cardTitle = cardTitle;
	}

	public String getCardText() {
		return cardText;
	}

	public void setCardText(String cardText) {
		this.cardText = cardText;
	}

	public String getCardTextColor() {
		return cardTextColor;
	}

	public void setCardTextColor(String cardTextColor) {
		this.cardTextColor = cardTextColor;
	}

	public String getCardBackgroundColor() {
		return cardBackgroundColor;
	}

	public void setCardBackgroundColor(String cardBackgroundColor) {
		this.cardBackgroundColor = cardBackgroundColor;
	}

	public String getCardImage() {
		return cardImage;
	}

	public void setCardImage(String cardImage) {
		this.cardImage = cardImage;
	}

	public String getImageAltText() {
		return imageAltText;
	}

	public void setImageAltText(String imageAltText) {
		this.imageAltText = imageAltText;
	}

	public String getImgVerticalAlign() {
		return imgVerticalAlign;
	}

	public void setImgVerticalAlign(String imgVerticalAlign) {
		this.imgVerticalAlign = imgVerticalAlign;
	}

	public String getCardMobileImage() {
		return cardMobileImage;
	}

	public void setCardMobileImage(String cardMobileImage) {
		this.cardMobileImage = cardMobileImage;
	}

	public String getTooltipLogo() {
		return tooltipLogo;
	}

	public void setTooltipLogo(String tooltipLogo) {
		this.tooltipLogo = tooltipLogo;
	}

	public String getTooltipMsg() {
		return tooltipMsg;
	}

	public void setTooltipMsg(String tooltipMsg) {
		this.tooltipMsg = tooltipMsg;
	}

	public boolean isDisableButton() {
		return disableButton;
	}

	public void setDisableButton(boolean disableButton) {
		this.disableButton = disableButton;
	}
    
}