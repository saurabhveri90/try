/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;


import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Header} Sling Model used for the {@code /apps/tracfone-core/components/content/appdownload} component.
 */
public interface AppDownloadModel extends ComponentExporter {
	
	/**
	 * <p>Fetches logo image path for app download</p>
	 * 
	 * @return String - logo image path for app download
	 */
	@JsonProperty("logo")
	public String getFileReference() ;

	/**
	 * <p>Fetches Alt-text for logo of app download</p>
	 * 
	 * @return String - Alt-text for logo of app download
	 */
	@JsonProperty("altText")
	public String getAltText();
	
	/**
	 * <p>Fetches do not follow link flag for play store link in app download</p>
	 * 
	 * @return String - do not follow link flag for play store link in app download
	 */
	@JsonProperty("donotfollowplaystore")
	public String getDonotfollowplaystore();

	/**
	 * <p>Fetches Alt-text for play store link/image of app download</p>
	 * 
	 * @return String - Alt-text for play store link/image of app download
	 */
	@JsonProperty("playstorealttext")
	String getPlaystorealttext();
	
	/**
	 * <p>Fetches Play store link for app download</p>
	 * 
	 * @return String -  Play store link for app download
	 */
	@JsonProperty("playstore")
	String getPlaystore();
	
	/**
	 * <p>Fetches do not follow link flag for app store link in app download</p>
	 * 
	 * @return String - do not follow link flag for app store link in app download
	 */
	@JsonProperty("donotfollowappstore")
	String getDonotfollowappstore();
	
	/**
	 * <p>Fetches Alt-text for app store link/image of app download</p>
	 * 
	 * @return String - Alt-text for app store link/image of app download
	 */
	@JsonProperty("appstorealttext")
	String getAppstorealttext();
	
	/**
	 * <p>Fetches App store link for app download</p>
	 * 
	 * @return String -  App store link for app download
	 */
	@JsonProperty("appstore")
	String getAppstore();
	
	/**
	 * <p>Fetches heading text app download</p>
	 * 
	 * @return String - Heading text app download
	 */
	@JsonProperty("heading")
	String getHeading();
	
	/**
	 * <p>Fetches description text app download</p>
	 * 
	 * @return String - Description text app download
	 */
	@JsonProperty("description")
	String getDescription();
	
	/**
	 * <p>Fetches App store logo image path for app download</p>
	 * 
	 * @return String -  App store logo image path for app download
	 */
	@JsonProperty("appstoreLogoPath")
	String getAppstoreFileReference();

	/**
	 * <p>Fetches Play store logo image path for app download</p>
	 * 
	 * @return String -  Play store logo image path for app download
	 */
	@JsonProperty("playstoreLogoPath")
	String getPlaystoreFileReference();

	@JsonProperty("appstoreLogoPathAssetId")
	public String getAppstoreLogoPathAssetId();

	@JsonProperty("appstoreLogoPathAssetAgencyId")
	public String getAppstoreLogoPathAssetAgencyId();

	@JsonProperty("playstoreLogoPathAssetId")
	public String getPlaystoreLogoPathAssetId();

	@JsonProperty("playstoreLogoPathAssetAgencyId")
	public String getPlaystoreLogoPathAssetAgencyId();

	/**
	 * <p>Boolean to enable see details link</p>
	 * 
	 * @return boolean -  Boolean to enable see details link
	 */
	@JsonProperty("enableSeeDetails")
	boolean getEnableSeeDetails();

	/**
	 * <p>Fetches see details text</p>
	 * 
	 * @return String -  see details text
	 */
	@JsonProperty("seeDetailsText")
	String getSeeDetailsText();

	/**
	 * <p>Fetches hide details text</p>
	 * 
	 * @return String -  hide details text
	 */
	@JsonProperty("hideDetailsText")
	String getHideDetailsText();

	/**
	 * <p>Fetches see details description</p>
	 * 
	 * @return String -  see details description
	 */
	@JsonProperty("seeDetailsDescription")
	String getSeeDetailsDescription();

	/**
	 * <p>Boolean to enable CTA Button</p>
	 * 
	 * @return boolean -  Boolean to enable cta button
	 */
	boolean getEnableCtaButton();
	
	/**
	 * <p>Boolean to enable Both App and CTA Buttons</p>
	 * 
	 * @return boolean -  Boolean to enable app and cta buttons
	 */
	boolean getEnableAppAndCtaButton();
	
}
