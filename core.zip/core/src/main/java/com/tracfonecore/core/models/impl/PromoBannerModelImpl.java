package com.tracfonecore.core.models.impl;

import com.tracfonecore.core.models.PromoBannerModel;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;


@Model(adaptables = {Resource.class, SlingHttpServletRequest.class}, adapters = PromoBannerModel.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class PromoBannerModelImpl implements PromoBannerModel{
    @Self
    private Resource resource;

    @Self
    private SlingHttpServletRequest request;


    @ValueMapValue
    private String bannerBackground;
   
    @ValueMapValue
    private String bannerHeader;

    @ValueMapValue
    private String bannerDescription;

    @ValueMapValue
    private String bannerCtaLabel;

    @ValueMapValue
    private String bannerCtaLink;


    @Override
    public String getBannerBackground() {
        return bannerBackground;
    }


    @Override
    public String getBannerHeader() {
        return bannerHeader;
    }

    @Override
    public String getBannerDescription() {
        return bannerDescription;
    }
    @Override
    public String getBannerCtaLabel() {
        return bannerCtaLabel;
    }

    @Override
    public String getBannerCtaLink() {
        if(bannerCtaLink != null && bannerCtaLink.startsWith("/content")) {
            return bannerCtaLink+".html";
        }
        return bannerCtaLink;
    }
}
