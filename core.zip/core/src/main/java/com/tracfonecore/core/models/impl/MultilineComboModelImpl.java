package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.google.gson.JsonObject;
import com.tracfonecore.core.beans.ProductDetailJsonBean;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.MultilineComboModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.ProductOfferingApiService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.services.TracfoneValueMappingConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { MultilineComboModel.class,
  ComponentExporter.class }, resourceType = MultilineComboModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
  @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
  @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class MultilineComboModelImpl extends BaseComponentModelImpl implements MultilineComboModel {
    private static final Logger LOGGER = LoggerFactory.getLogger(MultilineComboModelImpl.class);
    protected static final String RESOURCE_TYPE = "tracfone-core/components/commerce/multilinecombo";

    @Self
	private SlingHttpServletRequest request;

    @Inject
	private Page currentPage;
  
    @Inject
	private ProductOfferingApiService productOfferingApiService;

    @Inject
	protected TracfoneApiGatewayService tracfoneApiService;

    @Inject
	protected ApplicationConfigService applicationConfigService;

    @OSGiService
	private TracfoneValueMappingConfigService tracfoneValueMappingConfigService;

	private List<ProductDetailJsonBean> plans = Collections.emptyList();;

    @ValueMapValue
	private String[] planPaths;

    @ValueMapValue
	private String orderIndex;

    @ValueMapValue
	private String ctaText;

    @ValueMapValue
	private String ctaAccessibility;

    @ValueMapValue
	private String ctaLink;

    private String queryString;

    private String priceSaveAccessibility;

    /**
	 * <p>
	 * Init method : 
     * - gets and set plan data for each plan path authored
	 * - sets query string
     * - gets accessbility for price/savings from homepage properties
	 * </p>
	 *
	 */
    @PostConstruct
	protected void initModel() {
        try {
            super.initModel();
            if (this.planPaths != null) {
                this.plans = new ArrayList<ProductDetailJsonBean>();
                for (int index = 0; index < this.planPaths.length; index++) {
                    this.plans.add(new ProductDetailJsonBean());
                    setPlanData(this.plans.get(index), this.planPaths[index]);
                }
            } 
            setQueryString();
            this.priceSaveAccessibility = CommerceUtil.getPagePropertyValue(currentPage,
                applicationConfigService.getHomePageLevel(), CommerceConstants.PRICE_SAVE_ACCESSIBILITY).toString();
        } catch (RuntimeException re) {
            LOGGER.error("Exception occurred while fetching plan details {}", re);
        }
    }

    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

    /**
     * <p>
     * Fetches the plans
     * </p>
     *
     * @return List of ProductDetailJsonBean (plans)
     */
    @Override
    public List<ProductDetailJsonBean> getPlans() {
        return new ArrayList<>(this.plans);
    }

    /**
     * <p>
     * Fetches the plan paths
     * </p>
     *
     * @return String - plan paths
     */
    @Override
    public String[] getPlanPaths() {
        return Arrays.copyOf(this.planPaths, this.planPaths.length);
    }

    /**
     * <p>
     * Fetches the cta text
     * </p>
     *
     * @return String - ctaText
     */
    @Override
    public String getCtaText() {
        return this.ctaText;
    }

    /**
     * <p>
     * Fetches the cta accessibility
     * </p>
     *
     * @return String - ctaAccessibility
     */
    @Override
    public String getCtaAccessibility() {
        return this.ctaAccessibility;
    }

    /**
     * <p>
     * Fetches the cta link
     * </p>
     *
     * @return String - ctaLink
     */
    @Override
    public String getCtaLink() {
        return this.ctaLink;
    }

    /**
     * <p>
     * Fetches the number of plans
     * </p>
     *
     * @return String - noOfPlans
     */
    @Override
    public String getNoOfPlans() {
        if (this.plans != null) {
            return Integer.toString(this.plans.size());
        }
        return "0";
    }

    /**
     * <p>
     * Fetches card width or default
     * </p>
     *
     * @return String - cardWidth
     */
    @Override
    public String getCardWidth() {
        if (this.plans != null) {
            return Integer.toString(this.plans.size()+1);
        }
        return "4";
    }

    /**
     * <p>
     * Set plan data
     * </p>
     * 
     * @param {ProductDetailJsonBean} planData - bean object to set data in
     * @param {String} path - plan page path
     */
    private void setPlanData(ProductDetailJsonBean planData, String path) {
        String pagePath = path;
        if (pagePath != null && StringUtils.isNotEmpty(pagePath)) {
            Resource planResource = request.getResourceResolver().resolve(pagePath);
            if (planResource != null) {
                // get and set plan type from pdp properties
                Page productPage = planResource.adaptTo(Page.class);
                planData.setPlantype(productPage.getProperties().get(CommerceConstants.PLAN_TYPE, String.class));
                // check if authored page is a pdp page
                if (ApplicationUtil.isPdpPage(productPage, tracfoneValueMappingConfigService.pdpTemplateValues())
                    && !ApplicationUtil.isPageDeleted(productPage)) {
                    // get resource for plan detail and plan card on pdp
                    Resource planDetailResource = request.getResourceResolver()
                        .resolve(pagePath + CommerceConstants.MULTILINE_PLAN_DETAIL_ROOT_PATH);
                    Resource planCardResource = request.getResourceResolver()
                        .resolve(pagePath + CommerceConstants.MULTILINE_PLAN_DETAIL_NODE_PATH);
                    Boolean twoLinePlanName = true;
                    if (planDetailResource.isResourceType(Resource.RESOURCE_TYPE_NON_EXISTING)) {
                        planDetailResource = request.getResourceResolver()
                            .resolve(pagePath + CommerceConstants.PLAN_DETAIL_ROOT_PATH);
                        planCardResource = request.getResourceResolver()
                            .resolve(pagePath + CommerceConstants.PLAN_DETAIL_NODE_PATH);
                        if (planDetailResource != null)
                            twoLinePlanName = false;
                    }
                    // get and set plan name from plan detail on pdp
                    if (planDetailResource != null && planDetailResource.getValueMap() != null
                            && !planDetailResource.isResourceType(Resource.RESOURCE_TYPE_NON_EXISTING)) {
                        ValueMap planDetailProperties = planDetailResource.getValueMap();
                        if (twoLinePlanName) {
                            planData.setPlanname(planDetailProperties.get(CommerceConstants.MULTILINE_PLAN_NAME_TYPE, String.class));
                            planData.setPlanDescription(planDetailProperties.get(CommerceConstants.MULTILINE_PLAN_NAME,String.class));
                            planData.setExpriceduration(planDetailProperties.get(CommerceConstants.PER_TIME_PERIOD,String.class));
                        } else {
                            planData.setPlanname(planDetailProperties.get(CommerceConstants.PLAN_NAME_DETAIL, String.class));
                        }
                    }
                    // get and set price superscript and accessbility from plan card on pdp
                    if (planCardResource != null && planCardResource.getValueMap() != null
                            && !planCardResource.isResourceType(Resource.RESOURCE_TYPE_NON_EXISTING)) {
                        ValueMap planCardProperties = planCardResource.getValueMap();
                        planData.setPricesuperscript(planCardProperties.get(CommerceConstants.PRICE_SUPER_SCRIPT, String.class));
                        planData.setPricecaption(planCardProperties.get(CommerceConstants.PRICE_ACCESSIBILITY_LABEL, String.class));
                    }
                    // get and set selection/part number from pdp 
                    ValueMap pageProperties = request.getResourceResolver()
                        .resolve(pagePath + CommerceConstants.JCR_CONTENT)
                        .getValueMap();
                    String selection = pageProperties.get(CommerceConstants.PART_NO, String.class);
                    if (!selection.equals(StringUtils.EMPTY)) {
                        planData.setPartno(selection);
                    }
                }
            }
        } else {
            LOGGER.debug("setPlanData() - plan path is empty or null");
        }
    }

    /**
	 * <p>
	 * Returns priceApiPath from configuration
	 * </p>
	 * 
	 * @return String - priceApiPath
	 */
	@Override
    public String getPriceApiPath() {
		return tracfoneApiService.getPriceApiPath();
	}

    /**
	 * <p>
	 * Returns apiDomain from configuration
	 * </p>
	 * 
	 * @return String - apiDomain
	 */
	@Override
	public String getApiDomain() {
		return tracfoneApiService.getApiDomain();
	}

    /**
	 * <p>
	 * Returns queryString
	 * </p>
	 * 
	 * @return String - queryString
	 */
	@Override
	public String getQueryString() {
		return this.queryString;
	}

    /**
	 * <p>
	 * Sets queryString using plan part numbers
	 * </p>
	 */
	private void setQueryString() {
        if(this.plans != null && this.plans.size() > 0) {
            StringBuilder query = new StringBuilder(CommerceConstants.BRAND)
                .append(CommerceConstants.EQUALS_TO)
                .append(CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()))
                .append(CommerceConstants.AMPERSAND)
                .append(CommerceConstants.PART_NUMBER)
                .append(CommerceConstants.EQUALS_TO);
            for (int index = 0; index < this.plans.size(); index++) {
                query.append(this.plans.get(index).getPartno());
                if(this.plans.size()-1 != index) query.append(",");
            }
            this.queryString = query.toString();
        }
	}

    /**
	 * <p>
	 * Returns priceSaveAccessibility
	 * </p>
	 * 
	 * @return String - priceSaveAccessibility
	 */
	@Override
	public String getPriceSaveAccessibility() {
		return this.priceSaveAccessibility;
	}

    /**
	 * Method to return orderIndex
	 * 
	 * @return String orderIndex
	 */
	@Override
	public String getOrderIndex() {
		return orderIndex;
	}

}