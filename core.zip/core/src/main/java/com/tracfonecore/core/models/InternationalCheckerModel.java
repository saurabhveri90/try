/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;


import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface InternationalCheckerModel extends ComponentExporter {

	/**
	 * <p>Fetches Component Type</p>
	 * 
	 * @return String - component type
	 */
	@JsonProperty("componenttype")
	public String getComponentType();
	
	/**
	 * <p>Fetches Modal Variation Check</p>
	 * 
	 * @return String - modal variation?
	 */
	@JsonProperty("modalvariation")
	public boolean getModalVariation();
	
	/**
	 * <p>Fetches Section Heading</p>
	 * 
	 * @return String - heading
	 */
	@JsonProperty("heading")
	public String getHeading();

	/**
	 * <p>Fetches Section description</p>
	 * 
	 * @return String - description
	 */
	@JsonProperty("description")
	public String getDescription();
	
	/**
	 * <p>Fetches search title</p>
	 * 
	 * @return String - search title
	 */
	@JsonProperty("searchtitle")
	public String getSearchTitle();
	
	/**
	 * <p>Fetches search input placeholder text</p>
	 * 
	 * @return String -  placeholder text
	 */
	@JsonProperty("placeholdertxt")
	public String getPlaceholderTxt();
	
	/**
	 * <p>Fetches landlineonly text</p>
	 * 
	 * @return String -  landlineonly
	 */
	@JsonProperty("landlineonly")
	public String getLandlineOnly();
	
	/**
	 * <p>Fetches landline and mobile text</p>
	 * 
	 * @return String -  landandmobile
	 */
	@JsonProperty("landandmobile")
	public String getLandAndMobile();
	
	/**
	 * <p>Fetches Intl Destinations JSON file path</p>
	 * 
	 * @return String -  intlDestinations JSON file path
	 */
	@JsonProperty("intlDestinations")
	public String getIntlDestinations();

	/**
	 * <p>Fetches Image file path</p>
	 * 
	 * @return String - image file path
	 */
	@JsonProperty("image")
	default String getImage() {
		return null;
	}

	/**
	 * <p>Fetches Image alt text</p>
	 * 
	 * @return String - image alt text
	 */
	@JsonProperty("imageAltText")
	default String getImageAltText() {
		return null;
	}

	/**
	 * <p>Fetches Rate per minute text</p>
	 * 
	 * @return String - rate per minute text
	 */
	@JsonProperty("ratePerMinText")
	default String getRatePerMinText() {
		return null;
	}
	
	/**
	 * <p>Fetches Rate per minute post text</p>
	 * 
	 * @return String - rate per minute post text
	 */
	@JsonProperty("ratePerMinPostText")
	default String getRatePerMinPostText() {
		return null;
	}
	
	/**
	 * <p>Fetches desclaimer</p>
	 * 
	 * @return String - desclaimer
	 */
	@JsonProperty("desclaimer")
	default String getDesclaimer() {
		return null;
	}

	/**
	 * <p>Fetches dropDownErrTxt</p>
	 * 
	 * @return String - dropDownErrTxt
	 */
	@JsonProperty("dropDownErrTxt")
	default String getDropDownErrTxt() {
		return null;
	}

}