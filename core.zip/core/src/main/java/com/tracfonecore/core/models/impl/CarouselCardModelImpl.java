/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.CarouselCardModel;
import com.tracfonecore.core.services.DynamicMediaConfigService;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CarouselCardModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/carouselcarditem", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CarouselCardModelImpl extends BaseComponentModelImpl implements CarouselCardModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(CarouselCardModelImpl.class);
	
	private static final String TYPE = "type";

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private Resource resource;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String title;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String summary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String mediaPath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String imageAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accessbilityLabel;

	private String cardType;
	
	private String mobileVersion;
	
	@Inject
	private DynamicMediaConfigService dynamicMediaConfig;

	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering initModel method");
		super.initModel();	
			Resource getResource = resource.getParent().getParent();
			if (null != getResource) {
				ValueMap properties = getResource.adaptTo(ValueMap.class);
					if (null != properties) {
						if(null!= properties.get(TYPE)) 
							this.setCardType(properties.get(TYPE).toString());
						if(null != properties.get(ApplicationConstants.MOBILE_VERSION)) 
							this.mobileVersion = properties.get(ApplicationConstants.MOBILE_VERSION,"");
					}
					
		}			
		
		LOGGER.debug("Exiting initModel method");
	}
	/**
	 * <p>Fetches exported type</p>
	 * 
	 * @return String - exported type
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	/**
	 * <p>Fetches title of the carousel</p>
	 * 
	 * @return String - title of the carousel
	 */
	@Override
	public String getTitle() {
		return title;
	}
	/**
	 * <p>Fetches summary of the carousel</p>
	 * 
	 * @return String - summary of the carousel
	 */
	@Override
	public String getSummary() {
		return summary;
	}
	/**
	 * <p>Fetches image path</p>
	 * 
	 * @return String - image path
	 */
	@Override
	public String getMediaPath() {
		String s7Path = DynamicMediaUtils.changeMediaPathToDMPath(this.mediaPath, request.getResourceResolver());
		LOGGER.debug("Carousel Media Path: {}", s7Path);
		return s7Path;
	}
	/**
	 * <p>Fetches alt text for the image</p>
	 * 
	 * @return String - alt text for the image
	 */
	@Override
	public String getImageAltText() {
		return imageAltText;

	}
	/**
	 * <p>Fetches accessbility label</p>
	 * 
	 * @return String - accessbility label
	 */
	@Override
	public String getAccessbilityLabel() {
		return accessbilityLabel;
	}
	
	/**
	 * <p>Returns the breakpoint for website from Dynamic media config</p>
	 * 
	 * @return String - breakpoints
	 */
	public String getImageProfileBreakpoints() {
		String path = this.mediaPath;
		String breakPoints = StringUtils.EMPTY;
		if(ApplicationConstants.BG_SMART_CROP.equals(this.getDataMode())) {
			breakPoints = DynamicMediaUtils.getImageProfileBreakpoints(path, request.getResourceResolver());
		}
		return breakPoints;
	}
	/**
	 *<p>Fetches the path for mobile image path</p>
	 *
	 * @return String - mobile image path
	 */
	public String getMobileMediaImagePath() {
		String path = DynamicMediaUtils.getMobileDMPath(this.mediaPath, request.getResourceResolver());
		if(!ApplicationConstants.MOBILE_IMAGE.equals(this.mobileVersion)) {
			path = ""; 
		}
		return path;
	}
	/**
	 * <p>
	 * Sets cardType
	 * </p>
	 *
	 * @param cardType - the cardType to set
	 */
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	/**
	 *<p>Fetches type of card</p>
	 *
	 * @return String - card type
	 */
	public String getCardType() {
		return cardType;
	}
	/**
	 *<p>Fetches the data mode</p>
	 *
	 * @return String - data mode
	 */
	public String getDataMode() {
		return this.mobileVersion;
	}
	
	public String getBreakPoints() {
		return dynamicMediaConfig.getBreakPoint();
	}
	
}
