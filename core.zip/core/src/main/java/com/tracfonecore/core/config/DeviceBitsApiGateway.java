package com.tracfonecore.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "DeviceBits Api Gateway paths", description = "Paths for DeviceBits Api Gateway are added here")
public @interface DeviceBitsApiGateway {

    @AttributeDefinition(name = "DeviceBits Api Domain",description = "Configuration for API Domain")
    String apiDomain() default "https://search-api.devicebits.com/v1/";

    @AttributeDefinition(name = "API Key for DeviceBits",description = "Configuration for API Key")
    String apiKey() default "Bd0JWqm71j1xxV2epIGeI2lW3fhYCc3d3DPbDVqx";

    @AttributeDefinition(name = "Customer ID for DeviceBits",description = "Configuration for Customer ID")
    String[] brandId() default {"STRAIGHT_TALK:stacademy"};

    @AttributeDefinition(name = "Language ID for DeviceBits", description = "Configuration for language in DeviceBits API")
	String[] languageId() default {"ENG:1","SPA:2"};

    @AttributeDefinition(name = "Image Server Domain",description = "Configuration for image server domain")
    String imageServerDomain() default "https://s3.amazonaws.com/tpassets.devicebits.com";

    @AttributeDefinition(name = "All Phones API Path",description = "Get details for all phones")
    String allPhonesApiPath() default "phones";

    @AttributeDefinition(name = "Single Phone Details API Path",description = "Get details for one phone by providing part number. {partNumber} will be replaced with part number.")
    String phoneDetailsApiPath() default "phones/{partNumber}";

    @AttributeDefinition(name = "Phone Content API Path",description = "Get content for a single phone")
    String phoneContentApiPath() default "top";

    @AttributeDefinition(name = "Phone Content By Type API Path",description = "Get content by type for a single phone. {type} will be replaced with content type.")
    String phoneContentByTypeApiPath() default "top/{type}";
    
    @AttributeDefinition(name = "Part Number Suffix based on Page Language", description = "Part Number Suffix based on Page Language")
	String[] partNumberSuffixByLanguage();

    @AttributeDefinition(name = "Phone Content By Type API Path",description = "Get URL for tutorial landing page. {partNumber} will be replaced with part number.")
    String[] phoneTutorialLandingURL() default {"STRAIGHT_TALK:https://support.straighttalk.com/tutorials/?custId={partNumber}","TRACFONE:https://support.tracfone.com/tutorials/?custId={partNumber}","TOTAL_WIRELESS:https://support.totalwireless.com/tutorials/?custId={partNumber}"};
    
}



