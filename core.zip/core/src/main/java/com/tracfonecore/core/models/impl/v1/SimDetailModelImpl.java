
package com.tracfonecore.core.models.impl.v1;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.SimDetailModel;
import com.tracfonecore.core.models.impl.BaseComponentModelImpl;
import com.tracfonecore.core.utils.ItemsExporterUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tracfonecore.core.services.ApplicationConfigService;
import org.apache.commons.lang3.StringUtils;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.constants.ApplicationConstants;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.Map;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { SimDetailModel.class,
		ComponentExporter.class }, resourceType = SimDetailModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class SimDetailModelImpl extends BaseComponentModelImpl implements SimDetailModel {
	private static final Logger LOGGER = LoggerFactory.getLogger(SimDetailModelImpl.class);
	protected static final String RESOURCE_TYPE = "tracfone-core/components/commerce/simdetail/v1/simdetail";

	@Inject
	private Page currentPage;

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private SlingModelFilter slingModelFilter;

	@Inject
	private ModelFactory modelFactory;

	@Inject
	@Via("resource")
	private String showTimer;

	@Inject
	@Via("resource")
	private String isTabletSim;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String simNameDetail;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addSimCardDescription;

	private String productCardImage;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String displayPriceSimPDP;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String displayCDMAText;
	
	private String termsCondModalId;
	private String termsCondModalLabel;
	private String termsCondLink;
	private String termsCondType;
	private String useBazaarVoiceinSimDetails;
	private String notifyBtn;
	private String stockTitle;
	private String preTextNotifyMeBtn;


	@ScriptVariable
	private ValueMap properties;
	
	@PostConstruct
	public void initModel() {
		fetchPagePropertiesData();
	}

	/**
	 * <p>
	 * Sets value from page properties for productCardImage
	 * </p>
	 *
	 * @return void
	 */
	private void fetchPagePropertiesData() {
		Page parentPage = currentPage.getParent();
		Page ancestorPage = parentPage.getParent();
		ValueMap pageProperties = null;
		if (CommerceUtil.checkCategoryValues(parentPage.getProperties())) {
			pageProperties = parentPage.getProperties();
		} else if (CommerceUtil.checkCategoryValues(ancestorPage.getProperties())) {
			pageProperties = ancestorPage.getProperties();
		}
		if (pageProperties != null) {
			productCardImage = pageProperties.get(CommerceConstants.PRODUCT_CARD_IMAGE, String.class);
			LOGGER.debug(
					"product card image: {0}, rewards purchase label: {1}, rewards earn label: {2}",
					productCardImage);
			termsCondModalId = pageProperties.get(CommerceConstants.TERMS_AND_CONDITION_MODAL_ID, String.class);
			termsCondModalLabel = pageProperties.get(CommerceConstants.TERMS_AND_CONDITION_MODAL_ID_LINK_LABEL, String.class);
			termsCondLink = pageProperties.get(CommerceConstants.TERMS_AND_CONDITION_LINK, String.class);
			termsCondType = pageProperties.get(CommerceConstants.TERMS_AND_CONDITION_TYPE, String.class);
			useBazaarVoiceinSimDetails = pageProperties.get(CommerceConstants.USE_BAZAAR_VOICE_RATINGS_SIM_PDP, String.class);
			notifyBtn = pageProperties.get(CommerceConstants.NOTIFY_ME_BUTTON, String.class);
			stockTitle = pageProperties.get(CommerceConstants.STOCK_POPOVER_TITLE, String.class);
			preTextNotifyMeBtn = pageProperties.get(CommerceConstants.PRE_TEXT_NOTIFY_ME_BUTTON, String.class);
		}
	}

	/**
	 * <p>
	 * Returns true if valuemap has category type and Id values
	 * </p>
	 *
	 * @return Boolean - true/false
	 */
	private Boolean checkCategoryValues(ValueMap properties) {

		if (properties != null && properties.containsKey(CommerceConstants.CATEGORY_ID)
				&& !properties.get(CommerceConstants.CATEGORY_ID, String.class).isEmpty()
				&& properties.containsKey(CommerceConstants.CATEGORY_TYPE)
				&& !properties.get(CommerceConstants.CATEGORY_TYPE, String.class).isEmpty()) {
			return true;
		}

		return false;
	}

	/**
	 * <p>
	 * Returns Sim Name Detail authored
	 * </p>
	 *
	 * @return String - simNameDetail
	 */
	@Override
	public String getSimNameDetail() {
		return simNameDetail;
	}

	/**
	 * @return the productCardImage
	 */
	@Override
	public String getProductCardImage() {
		return productCardImage;
	}

	/**
	 * <p>
	 * Returns exporter type
	 * </p>
	 *
	 * @return String - getexportertype
	 */
	@Override
	public String getExportedType() {

		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Returns json from items
	 * </p>
	 *
	 * @return Map - items
	 */
	public Map<String, ? extends ComponentExporter> getItems() {
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}

	/**
	 * <p>
	 * Method to return showTimer
	 *
	 * @return String showTimer
	 */
	@Override
	public String getShowTimer() {
		return showTimer;
	}

	/**
	 * <p>
	 * Returns if sim descritpion section is to be added or not
	 * </p>
	 *
	 * @return String - addSimCardDescription
	 */
	@Override
	public String getAddSimCardDescription() {
		return addSimCardDescription;
	}

	@Override
	public String getSelection() {
		return currentPage.getContentResource().getValueMap().get("partNo", String.class);
	}

	/**
	 * <p>
	 * Fetches Terms and Condition Modal Label/p>
	 * 
	 * @return String - Terms and Condition Modal Label
	 */
	@Override
	public String getTermsCondModalLabel() {
		return termsCondModalLabel;
	}

	/**
	 * <p>
	 * Fetches CTA text of Terms and Condition link/p>
	 * 
	 * @return String - CTA text of Terms and Condition
	 */
	@Override
	public String getTermsCondModalId() {
		String modalId= StringUtils.EMPTY;
		if(StringUtils.isNotBlank(termsCondModalId)) {
			modalId = ApplicationUtil.getLowerCaseWithHyphen(termsCondModalId) + ApplicationConstants.HYPHEN
					+ ApplicationConstants.MODAL;
		}
		return modalId;		
	}

	/**
	 * @return the termsCondLink
	 */
	public String getTermsCondLink() {
		return termsCondLink;
	}

	/**
	 * @return the termsCondType
	 */
	public String getTermsCondType() {
		return termsCondType;
	}

	/**
     * <p>
     * Method to return useBazaarVoiceinSimDetails
     *
     * @return String useBazaarVoiceinSimDetails
     */
    @Override
    public String getUseBazaarVoiceinSimDetails() {
        return useBazaarVoiceinSimDetails;
    }

	/**
	* @return String - the getStockTitle 
	*/
	@Override
	public String getStockTitle() {
	return stockTitle;
	}
	public void setStockTitle(String stockTitle) {
	this.stockTitle = stockTitle;
	}

	/**
	* @return String - the preTextNotifyMeBtn 
	*/
	@Override
	public String getPreTextNotifyMeBtn() {
	return preTextNotifyMeBtn;
	}
	public void setPreTextNotifyMeBtn(String preTextNotifyMeBtn) {
	this.preTextNotifyMeBtn = preTextNotifyMeBtn;
	}

	/**
	* @return String - the getNotifyBtn 
	*/
	@Override
	public String getNotifyBtn() {
	return notifyBtn;
	}
	public void setNotifyBtn(String notifyBtn) {
	this.notifyBtn = notifyBtn;
	}

	/**
     * <p>
     * Method to return hidePriceSimPDP
     *
     * @return String hidePriceSimPDP
     */
    @Override
    public String getDisplayPriceSimPDP() {
        return displayPriceSimPDP;
    }

	/**
     * <p>
     * Method to return displayCDMAText
     *
     * @return String displayCDMAText
     */
    @Override
    public String getDisplayCDMAText() {
        return displayCDMAText;
    }

	/**
	 * <p>
	 * Method to return showTimer
	 *
	 * @return String showTimer
	 */
	@Override
	public String getIsTabletSim() {
		return isTabletSim;
	}

	/**
	 * <p>
	 * Returns if sim descritpion section is to be added or not
	 * </p>
	 *
	 * @return String - addSimCardDescription
	 */

}
