
package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.inject.Inject;
import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.beans.DynamicVasBean;
import com.tracfonecore.core.models.DynamicVasActivationModal;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { DynamicVasActivationModal.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/dynamicvasactivation", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class DynamicVasActivationModalImpl implements DynamicVasActivationModal {

	@Self
	private SlingHttpServletRequest request;
	
	@Inject
	private Resource resource;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String pageHeader;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String loginBtnLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String defaultLoginMsg;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String noSubscriptionMsg;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String alreadyActiveMsg;


	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String manageVasBtnLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String manageVasPageUrl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String totalApiRepeats;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String vasApiInterval;

	

	private List<DynamicVasBean> dynamicVasList = Collections.emptyList();


	@PostConstruct
	private void initModel() {
		dynamicVasList = new ArrayList<>();				
		if (resource != null) {
			getMultifieldResource();
		}		
	}

	private void getMultifieldResource() {
		for (final Resource child : resource.getChildren()) {
			final Iterator<Resource> it = child.listChildren();
			if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.DYNAMIC_VAS_LIST.equals(child.getName())) {
				setDynamicVas(it, dynamicVasList);
			}
		}
	}

	private void setDynamicVas(final Iterator<Resource> it, final List<DynamicVasBean> dynamicVasList) {
		while (it.hasNext()) {
			final DynamicVasBean dynamicVasBean = new DynamicVasBean();
			final Resource grandChild = it.next();
			dynamicVasBean.setVendorName(
					grandChild.getValueMap().get("vendorName", String.class));
			dynamicVasBean.setActivationInfoHeader(
				grandChild.getValueMap().get("activationInfoHeader", String.class));		
			dynamicVasBean.setActivationPageTitle(
					grandChild.getValueMap().get("activationPageTitle", String.class));			
			dynamicVasBean.setDynamicVasVendorUrl(
					grandChild.getValueMap().get("dynamicVasVendorUrl", String.class));	
			dynamicVasBean.setActivationPageDescription(
					grandChild.getValueMap().get("activationPageDescription", String.class));
			dynamicVasBean.setActivationPageBtnAcceLabel(
					grandChild.getValueMap().get("activationPageBtnAcceLabel", String.class));
			dynamicVasBean.setVendorActivationdesc(
				grandChild.getValueMap().get("vendorActivationdesc", String.class));
			dynamicVasBean.setVendorActivationdisclaimer(
					grandChild.getValueMap().get("vendorActivationdisclaimer", String.class));
			dynamicVasBean.setVendorActivationBtnLabel(
				grandChild.getValueMap().get("vendorActivationBtnLabel", String.class));
			dynamicVasBean.setVendorActivationBtnAccLabel(
				grandChild.getValueMap().get("vendorActivationBtnAccLabel", String.class));	
						
			dynamicVasList.add(dynamicVasBean);
		}
	}


	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getPageHeader(){
		return pageHeader;
	}

	@Override
    public String getLoginBtnLabel(){
		return loginBtnLabel;
	}
	@Override
	public String getDefaultLoginMsg(){
		return defaultLoginMsg;
	}
	@Override
	public String getNoSubscriptionMsg(){
		return noSubscriptionMsg;
	}

	@Override
    public String getAlreadyActiveMsg(){
		return alreadyActiveMsg;
	}

    @Override
    public String getManageVasBtnLabel(){
		return manageVasBtnLabel;
	}

    @Override
    public String getManageVasPageUrl(){
		return manageVasPageUrl;
	} 
	

	public List<DynamicVasBean> getDynamicVasList() {
		return new ArrayList<>(dynamicVasList);
	}

	@Override
    public String getTotalApiRepeats(){
		return totalApiRepeats;
	} 

	@Override
    public String getVasApiInterval(){
		return vasApiInterval;
	} 
	
}
