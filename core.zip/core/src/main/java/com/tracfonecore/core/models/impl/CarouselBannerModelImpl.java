/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.CarouselBannerModel;
import com.tracfonecore.core.services.DynamicMediaConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CarouselBannerModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/carouselbanneritem", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CarouselBannerModelImpl extends BaseComponentModelImpl implements CarouselBannerModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(CarouselBannerModelImpl.class);

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private DynamicMediaConfigService dynamicMediaConfig;

	// constants
	private static final String CAROUSEL_LABEL = "Carousel Slide 1";

	@ValueMapValue
	private String label;

	@ValueMapValue
	private String title;

	@ValueMapValue
	private String summary;
		
	@ValueMapValue
	private String includeInlineDisclaimer;

	@ValueMapValue
	private String mediaType;

	@ValueMapValue
	private String mediaPath;

	@ValueMapValue
	private String videoThumbnailImage;

	@ValueMapValue
	private String imageAltText;

	@ValueMapValue
	private String accessbilityLabel;

	@ValueMapValue
	private String doNotFollowVideo;

	@ValueMapValue
	private String mobileVersion;

	@ValueMapValue
	private String videoThMobileVersion;
	
	@ValueMapValue
	private String mediaAlignment;
	
	@ValueMapValue
	private String includeCoverageSearch;

	@ValueMapValue
	private String doNotUseBackgroundImage;
	
	@ValueMapValue
	private String showTimer;
	
	@ValueMapValue
	private String showLabelLeftBorder;

	@ValueMapValue
	private String flowType;

	@ValueMapValue(name="image")
	private String logoImage;

	@ValueMapValue
	private String displayBanner;

	@ValueMapValue(name="altText")
	private String logoAltText;
	
	@ValueMapValue
	private String orderIndex;
	
	@ValueMapValue
	private String includeMultiLinks;

	@ValueMapValue
	private String showTitleAsH1;

	@ValueMapValue
	private String selectedTimerPosition;

	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering initModel method");
		super.initModel();	
		doNotFollowVideo = ApplicationUtil.getNoFollow(doNotFollowVideo);
		LOGGER.debug("Exiting initModel method");
	}

	/**
	 * <p>
	 * Fetches exported type
	 * </p>
	 * 
	 * @return String - exported type
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Fetches label of the carousel
	 * </p>
	 *
	 * @return String - label of the carousel
	 */
	@Override
	public String getLabel() {
		return label;
	}

	/**
	 * <p>
	 * Fetches title of the carousel
	 * </p>
	 *
	 * @return String - title of the carousel
	 */
	@Override
	public String getTitle() {
		return title;
	}

	/**
	 * <p>
	 * Fetches summary of the carousel
	 * </p>
	 * 
	 * @return String - summary of the carousel
	 */
	@Override
	public String getSummary() {
		return summary;
	}

	/**
	 * <p>
	 * Method to return inlineDisclaimer
	 * 
	 * @return String includeinlineDisclaimer
	 */
	@Override
	public String getIncludeInlineDisclaimer() {
		return includeInlineDisclaimer;
	}
	
	/**
	 * <p>
	 * Fetches media type (video/image)
	 * </p>
	 *
	 * @return String - media type
	 */
	@Override
	public String getMediaType() {
		return mediaType;
	}

	/**
	 * <p>
	 * Fetches image path
	 * </p>
	 * 
	 * @return String - image path
	 */
	@Override
	public String getMediaPath() {
		String s7Path = DynamicMediaUtils.changeMediaPathToDMPath(this.mediaPath, request.getResourceResolver());
		LOGGER.debug("Carousel Media Path: {}", s7Path);
		return s7Path;
	}

	/**
	 * <p>
	 * Fetches alt text for the image
	 * </p>
	 * 
	 * @return String - alt text for the image
	 */
	@Override
	public String getImageAltText() {
		return imageAltText;

	}

	/**
	 * <p>
	 * Fetches video thumbnail image
	 * </p>
	 *
	 * @return String - video thumbnail image
	 */
	@Override
	public String getVideoThumbnailImage() {
		String s7Path = DynamicMediaUtils.changeMediaPathToDMPath(this.videoThumbnailImage,
				request.getResourceResolver());
		LOGGER.debug("Carousel Video thumbnail Path: {}", s7Path);
		return s7Path;
	}

	/**
	 * <p>
	 * Fetches accessbility label
	 * </p>
	 * 
	 * @return String - accessbility label
	 */
	@Override
	public String getAccessbilityLabel() {
		String carouselLabel = CAROUSEL_LABEL;
		if (StringUtils.isNotEmpty(accessbilityLabel))
			carouselLabel = accessbilityLabel;
		return carouselLabel;
	}

	/**
	 * <p>
	 * Fetches no-follow for video link
	 * </p>
	 * 
	 * @return String - no-follow value
	 */
	@Override
	public String getDoNotFollowVideo() {
		return doNotFollowVideo;
	}

	/**
	 * <p>
	 * Fetches aspect ratio value
	 * </p>
	 * 
	 * @return String - aspect ratio
	 */
	@Override
	public String getAspectRatio() {
		return dynamicMediaConfig.getAspectRatio();
	}

	/**
	 * <p>
	 * Fetches break points for the image
	 * </p>
	 * 
	 * @return String - imageProfileBreakpoints
	 */
	@Override
	public String getImageProfileBreakpoints() {
		String path = this.mediaPath;
		String breakPoints = StringUtils.EMPTY;
		if (ApplicationConstants.VIDEO.equals(this.mediaType)) {
			path = this.videoThumbnailImage;
		}
		if (ApplicationConstants.BG_SMART_CROP.equals(this.getDataMode())) {
			breakPoints = DynamicMediaUtils.getImageProfileBreakpoints(path, request.getResourceResolver());
		}
		return breakPoints;
	}

	/**
	 * <p>
	 * Fetches data type for the video
	 * </p>
	 *
	 * @return String - videoDataType
	 */
	@Override
	public String getVideoDataType() {
		return ApplicationConstants.VIDEO_DATA_TYPE;
	}

	/**
	 * <p>
	 * Fetches the path for mobile thumbnail
	 * </p>
	 *
	 * @return String - mobile thumbnail image path
	 */
	@Override
	public String getMobileThumbnailImagePath() {
		String path = DynamicMediaUtils.getMobileDMPath(this.videoThumbnailImage, request.getResourceResolver());
		if (!ApplicationConstants.VIDEO.equals(this.mediaType)
				&& !ApplicationConstants.MOBILE_IMAGE.equals(this.videoThMobileVersion)) {
			path = StringUtils.EMPTY;
		}
		return path;
	}

	/**
	 * <p>
	 * Fetches the path for mobile image path
	 * </p>
	 *
	 * @return String - mobile image path
	 */
	@Override
	public String getMobileMediaImagePath() {
		String path = DynamicMediaUtils.getMobileDMPath(this.mediaPath, request.getResourceResolver());
		if (!ApplicationConstants.IMAGE.equals(this.mediaType)
				&& !ApplicationConstants.MOBILE_IMAGE.equals(this.mobileVersion)) {
			path = StringUtils.EMPTY;
		}
		return path;
	}

	/**
	 * <p>
	 * Fetches the data mode
	 * </p>
	 *
	 * @return String - data mode
	 */
	@Override
	public String getDataMode() {
		String mode = this.videoThMobileVersion;
		if (ApplicationConstants.IMAGE.equals(this.mediaType)) {
			mode = this.mobileVersion;
		}
		return mode;
	}

	/**
	 *<p>Fetches the mediaAlignment</p>
	 *
	 * @return the mediaAlignment
	 */
	@Override
	public String getMediaAlignment() {
		return mediaAlignment;
	}

	/**
	 *<p>Fetches coverage search include flag</p>
	 *
	 * @return String - includeCoverageSearch
	 */
	@Override
	public String getIncludeCoverageSearch() {
		return includeCoverageSearch;
	}

	/**
	 * <p>Fetches flag value to not use background image</p>
	 *
	 * @return String - doNotUseBackgroundImage
	 */
	public String getDoNotUseBackgroundImage() {
		return doNotUseBackgroundImage;
	}
	
	/**
	 * <p>
	 * Method to return showTimer
	 * 
	 * @return String showTimer
	 */
	@Override
	public String getShowTimer() {

		return showTimer;
	}
	
	/**
	 * <p>
	 * Method to return showLabelLeftBorder
	 * 
	 * @return String showLabelLeftBorder
	 */
	@Override
	public String getShowLabelLeftBorder() {

		return showLabelLeftBorder;
	}
	/**
	 * <p>
	 * Fetches the flow type
	 * </p>
	 *
	 * @return String - Flow Type
	 */
	@Override
	public String getFlowType(){
		return flowType;
	}

	/**
	 * <p>
	 * Fetches the image logo
	 * </p>
	 *
	 * @return String - logoImage
	 */
	@Override
	public String getLogoImage(){
		return logoImage;
	}

	/**
	 * <p>
	 * Fetches the display banner value
	 * </p>
	 *
	 * @return String - displayBanner
	 */
	@Override
	public String getDisplayBanner(){
		return displayBanner;
	}

	/**
	 * <p>
	 *Fetches alt text for the logo
	 * </p>
	 *
	 * @return String - alt text for the logo
	 */
	@Override
	public String getLogoAltText(){
		return logoAltText;
	}

	/**
	 * Method to return orderIndex
	 * 
	 * @return String orderIndex
	 */
	@Override
	public String getOrderIndex() {
		return orderIndex;
	}

	/**
	 *<p>Fetches multilinks include flag</p>
	 *
	 * @return String - includeMultiLinks
	 */
	@Override
	public String getIncludeMultiLinks() {
		return includeMultiLinks;
	}

	/**
	 * <p>
	 * Method to return show Title As H1
	 * </p>
	 * @return String showTitleAsH1
	 */
	@Override
	public String getShowTitleAsH1() {
		return showTitleAsH1;
	}

	/**
	 * 
	 * Method to return selected timer position
	 * 
	 * @return String selectedTimerPosition
	 */
	@Override
	public String getSelectedTimerPosition() {
		return selectedTimerPosition;
	}
}
