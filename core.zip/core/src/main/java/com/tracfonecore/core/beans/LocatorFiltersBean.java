package com.tracfonecore.core.beans;

public class LocatorFiltersBean {
	
	private String filterOptionLabel;
	
	private String filterOptionValue;
	
	private String filterOptionIcon;

	/**
	 * @return the filterOptionLabel
	 */
	public String getFilterOptionLabel() {
		return filterOptionLabel;
	}

	/**
	 * @param filterOptionLabel the filterOptionLabel to set
	 */
	public void setFilterOptionLabel(String filterOptionLabel) {
		this.filterOptionLabel = filterOptionLabel;
	}

	/**
	 * @return the filterOptionValue
	 */
	public String getFilterOptionValue() {
		return filterOptionValue;
	}

	/**
	 * @param filterOptionValue the filterOptionValue to set
	 */
	public void setFilterOptionValue(String filterOptionValue) {
		this.filterOptionValue = filterOptionValue;
	}

	/**
	 * @return the filterOptionIcon
	 */
	public String getFilterOptionIcon() {
		return filterOptionIcon;
	}

	/**
	 * @param filterOptionIcon the filterOptionIcon to set
	 */
	public void setFilterOptionIcon(String filterOptionIcon) {
		this.filterOptionIcon = filterOptionIcon;
	}
	
}
