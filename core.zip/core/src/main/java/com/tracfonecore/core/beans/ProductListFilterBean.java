package com.tracfonecore.core.beans;

import java.util.ArrayList;
import java.util.List;

import org.apache.sling.api.resource.Resource;

/**
 * <p>
 * Defines bean to hold link detail
 * </p>
 */
public class ProductListFilterBean {
	/*
	 * Copyright 2019 HCL Technologies Ltd.
	 *
	 *
	 */

	private String filterLabel;
	private List<ProductFilterBean> filerData;
	private String filterTypeFacetId;
	private String filterType;
	private String selectedCheckboxView;
	private String subtext;
	private String dataType;
	private String sliderMinValue;
	private String sliderMaxValue;
	private String sliderStepValue;
	private String showCheckboxesWithSlider;
	private String showCheckboxesWithoutSlider;
	private Resource checkboxList;

	/**
	 * @return the filterLabel
	 */
	public String getFilterLabel() {
		return filterLabel;
	}

	/**
	 * @param filterLabel the filterLabel to set
	 */
	public void setFilterLabel(String filterLabel) {
		this.filterLabel = filterLabel;
	}

	/**
	 * @return the filerData
	 */
	public List<ProductFilterBean> getFilerData() {
		List<ProductFilterBean> filerBean = filerData;
		return filerBean;
	}

	/**
	 * @param filerData the filerData to set
	 */
	public void setFilerData(List<ProductFilterBean> filerData) {
		this.filerData = new ArrayList<>(filerData);
	}

	/**
	 * @return the filterTypeFacetId
	 */
	public String getFilterTypeFacetId() {
		return filterTypeFacetId;
	}

	/**
	 * @param filterTypeFacetId the filterTypeFacetId to set
	 */
	public void setFilterTypeFacetId(String filterTypeFacetId) {
		this.filterTypeFacetId = filterTypeFacetId;
	}

	/**
	 * @return the filterType
	 */
	public String getFilterType() {
		return filterType;
	}

	/**
	 * @param filterType the filterType to set
	 */
	public void setFilterType(String filterType) {
		this.filterType = filterType;
	}

	/**
	 * @return the selectedCheckboxView
	 */
	public String getSelectedCheckboxView() {
		return selectedCheckboxView;
	}

	/**
	 * @param selectedCheckboxView the selectedCheckboxView to set
	 */
	public void setSelectedCheckboxView(String selectedCheckboxView) {
		this.selectedCheckboxView = selectedCheckboxView;
	}

	/**
	 * @return the dataType
	 */
	public String getDataType() {
		return dataType;
	}

	/**
	 * @param dataType the dataType to set
	 */
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	/**
	 * @return the sliderMinValue
	 */
	public String getSliderMinValue() {
		return sliderMinValue;
	}

	/**
	 * @param sliderMinValue the sliderMinValue to set
	 */
	public void setSliderMinValue(String sliderMinValue) {
		this.sliderMinValue = sliderMinValue;
	}

	/**
	 * @return the sliderMaxValue
	 */
	public String getSliderMaxValue() {
		return sliderMaxValue;
	}

	/**
	 * @param sliderMaxValue the sliderMaxValue to set
	 */
	public void setSliderMaxValue(String sliderMaxValue) {
		this.sliderMaxValue = sliderMaxValue;
	}

	/**
	 * @return the sliderStepValue
	 */
	public String getSliderStepValue() {
		return sliderStepValue;
	}

	/**
	 * @param sliderStepValue the sliderStepValue to set
	 */
	public void setSliderStepValue(String sliderStepValue) {
		this.sliderStepValue = sliderStepValue;
	}

	/**
	 * @return the showCheckboxesWithSlider
	 */
	public String getShowCheckboxesWithSlider() {
		return showCheckboxesWithSlider;
	}

	/**
	 * @param showCheckboxesWithSlider the showCheckboxesWithSlider to set
	 */
	public void setShowCheckboxesWithSlider(String showCheckboxesWithSlider) {
		this.showCheckboxesWithSlider = showCheckboxesWithSlider;
	}

	/**
	 * @return the checkboxList
	 */
	public Resource getCheckboxList() {
		return checkboxList;
	}

	/**
	 * @param checkboxList the checkboxList to set
	 */
	public void setCheckboxList(Resource checkboxList) {
		this.checkboxList = checkboxList;
	}

	/**
	 * @return the subtext
	 */
	public String getSubtext() {
		return subtext;
	}

	/**
	 * @param subtext the subtext to set
	 */
	public void setSubtext(String subtext) {
		this.subtext = subtext;
	}

	/**	
	 * @return the showCheckboxesWithoutSlider
	 */
	public String getShowCheckboxesWithoutSlider() {
		return showCheckboxesWithoutSlider;
	}

	/**
	 * @param showCheckboxesWithoutSlider the showCheckboxesWithoutSlider to set
	 */
	public void setShowCheckboxesWithoutSlider(String showCheckboxesWithoutSlider) {
		this.showCheckboxesWithoutSlider = showCheckboxesWithoutSlider;
	}

	@Override
	public String toString() {
		return "ProductListFilterBean [filterLabel=" + filterLabel + ", filerData=" + filerData
				+ "filterTypeFacetId" + filterTypeFacetId +  "filterType" + filterType +  "selectedCheckboxView" + selectedCheckboxView 
				+ "subtext" + subtext + "sliderMinValue" + sliderMinValue + "sliderMaxValue" + sliderMaxValue + "sliderStepValue" + sliderStepValue +  "showCheckboxesWithSlider" + showCheckboxesWithSlider + "checkboxList" + checkboxList + "showCheckboxesWithoutSlider" + showCheckboxesWithoutSlider + "]";
	}

}
