package com.tracfonecore.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = {Resource.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class IconListModel {

	@Self
	private Resource resource;

	@ValueMapValue
	private String iconTitle;

	@ValueMapValue
	private String iconLogo;

	@ValueMapValue
	private String iconLabel;

	public String getIconTitle() {
		return iconTitle;
	}

	public String getIconLogo() {
		return DynamicMediaUtils.changeMediaPathToDMPath(iconLogo, resource.getResourceResolver());
	}

	public String getIconLabel() {
		return iconLabel;
	}

}
