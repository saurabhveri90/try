/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.settings.SlingSettingsService;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.TutorialsModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { TutorialsModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/tutorials", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class TutorialsModelImpl implements TutorialsModel {

	@Self
	private SlingHttpServletRequest request;
	
	@Inject
	private SlingSettingsService settingService;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String positionTutorials;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String positionAccountNavigation;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String tutorialsSubheading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String legalCopyTextForTutorials;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headlineDeviceUnknown;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subHeadlineDeviceUnknown;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String provideDeviceInformationText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String unknownDeviceImage;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String unknownDeviceImageAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headlinePopularTutorial;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subHeadlinePopularTutorial;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headlinePopularFaqs;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subHeadlinePopularFaqs;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headlinePopularGuides;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subHeadlinePopularGuides;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String tutorialsBasePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String openNewTabTutorialsLink;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String faqsBasePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String openNewTabFaqsLink;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String guidesBasePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String openNewTabGuidesLink;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String deviceSupportPage;
	

	@Override
	public String getTutorialsSubheading() {
		return tutorialsSubheading;
	}
	
	@Override
	public String getLegalCopyTextForTutorials() {
		return legalCopyTextForTutorials;
	}

	@Override
	public String getHeadlineDeviceUnknown() {
		return headlineDeviceUnknown;
	}

	@Override
	public String getSubHeadlineDeviceUnknown() {
		return subHeadlineDeviceUnknown;
	}

	@Override
	public String getProvideDeviceInformationText() {
		return provideDeviceInformationText;
	}

	@Override
	public String getUnknownDeviceImage() {
	     return DynamicMediaUtils.changeMediaPathToDMPath(unknownDeviceImage, request.getResourceResolver());
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getPositionTutorials() {
		return positionTutorials;
	}

	@Override
	public String getPositionAccountNavigation() {
		return positionAccountNavigation;
	}

	@Override
	public String getUnknownDeviceImageAltText() {
		return unknownDeviceImageAltText;
	}

	@Override
	public String getHeadlinePopularTutorial() {
		return headlinePopularTutorial;
	}

	@Override
	public String getSubHeadlinePopularTutorial() {
		return subHeadlinePopularTutorial;
	}

	@Override
	public String getHeadlinePopularFaqs() {
		return headlinePopularFaqs;
	}

	@Override
	public String getSubHeadlinePopularFaqs() {
		return subHeadlinePopularFaqs;
	}

	@Override
	public String getHeadlinePopularGuides() {
		return headlinePopularGuides;
	}

	@Override
	public String getSubHeadlinePopularGuides() {
		return subHeadlinePopularGuides;
	}
	
	@Override
	public String getTutorialsBasePath() {
		return getFinalPagePath(tutorialsBasePath);
	}

	@Override
	public String getOpenNewTabTutorialsLink() {
		return openNewTabTutorialsLink;
	}

	@Override
	public String getFaqsBasePath() {
		return getFinalPagePath(faqsBasePath);
	}

	@Override
	public String getOpenNewTabFaqsLink() {
		return openNewTabFaqsLink;
	}

	@Override
	public String getGuidesBasePath() {
		return getFinalPagePath(guidesBasePath);
	}

	@Override
	public String getOpenNewTabGuidesLink() {
		return getFinalPagePath(openNewTabGuidesLink);
	}
	
	public String getFinalPagePath(String inputPath) {
		String finalPagePath = inputPath;
		if (StringUtils.isNotBlank(finalPagePath) &&  Boolean.TRUE.equals(ApplicationUtil.isInternalLink(finalPagePath))) {
			if (finalPagePath.indexOf(ApplicationConstants.HTML_EXTENSION) == -1) {
				finalPagePath = finalPagePath + ApplicationConstants.HTML_EXTENSION;
			}
			if (StringUtils.isNotBlank(finalPagePath)) {
				String ctaPath = request.getResourceResolver().map(finalPagePath);
				if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
					finalPagePath = ApplicationUtil
							.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
				}
			}
		}
		return finalPagePath;
	}
	
	@Override
	public String getDeviceSupportPage() {
		return getFinalPagePath(deviceSupportPage);
	}
	
	private String getShortURL(String serverDomain, String url) {
		if(StringUtils.isNotBlank(url) && StringUtils.isNotBlank(serverDomain) && url.contains(serverDomain)) {
			url = url.split(serverDomain)[1];
		}
		return url;
	}
}
