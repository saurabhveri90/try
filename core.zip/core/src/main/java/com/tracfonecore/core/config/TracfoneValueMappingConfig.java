/**
 * Copyright 2020 HCL Technologies Ltd.
 */
package com.tracfonecore.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Tracfone Value Mapping Configuration", description = "Language specific API value Mapping")

public @interface TracfoneValueMappingConfig {

    @AttributeDefinition(name = "Language Value Mapping", description = "Provide the language specific value to API key.")
    String[] languageValueMapping();
    
    @AttributeDefinition(name = "PDP Templates", description = "Provide the templates specific to PDP pages.")
    String[] pdpTemplateValues() default {"/conf/straighttalk/settings/wcm/templates/product-page","/conf/straighttalk/settings/wcm/templates/product-phone-page","/conf/straighttalk/settings/wcm/templates/product-plan-page","/conf/straighttalk/settings/wcm/templates/product-device-page","/conf/tracfone/settings/wcm/templates/product-page","/conf/tracfone/settings/wcm/templates/product-phone-page","/conf/tracfone/settings/wcm/templates/product-plan-page","/conf/tracfone/settings/wcm/templates/product-device-page","/conf/tracfone/settings/wcm/templates/product-accessory-page","/conf/tracfone/settings/wcm/templates/product-sim-page"};

    @AttributeDefinition(name = "Phone Upgrade Referrer URLs List", description = "Provide the list of phone upgrade referrer URLS.")
    String[] phoneUpgradeReferrerList();
    
    @AttributeDefinition(name = "Publish local host url", description = "Publish local host url")
	String publishLocalHostUrl()default "http://localhost:4503";
	
	@AttributeDefinition(name = "Error codes for API call retry", description = "Error codes for API call retry, in case of multiple error codes, separate them with ~ tilda")
    String[] retryStatusCodes();
	
	@AttributeDefinition(name = "Retry count for failed API", description = "Number of times API should be called in case of failure.")
	String[] apiRetryCount();
}
