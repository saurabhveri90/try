/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;

/**
 * <p>Defines bean to hold link detail</p>
 */
public class FeatureBean {

	private String featureTitle;
	private String featureDescription;
	private String featureLogo;
	private String accessText;
	/**
	 * @return the featureTitle
	 */
	public String getFeatureTitle() {
		return featureTitle;
	}
	public String getFeatureDescription() {
		return featureDescription;
	}
	public void setFeatureDescription(String featureDescription) {
		this.featureDescription = featureDescription;
	}
	public String getFeatureLogo() {
		return featureLogo;
	}
	public void setFeatureLogo(String featureLogo) {
		this.featureLogo = featureLogo;
	}
	/**
	 * @param columnwidth the featureTitle to set
	 */
	public void setFeatureTitle(String featureTitle) {
		this.featureTitle = featureTitle;
	}
	public String getAccessText() {
		return accessText;
	}
	public void setAccessText(String accessText) {
		this.accessText = accessText;
	}
	
}
