/*
 *  Copyright 2020 HCL Technologies Ltd.
 *
 */
package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;

import com.tracfonecore.core.models.VasPlanDetailAutoRefillPopupModel;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { VasPlanDetailAutoRefillPopupModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/vasplandetailautorefillpopup", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class VasPlanDetailAutoRefillPopupModelImpl implements VasPlanDetailAutoRefillPopupModel {

	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String vasArDescription;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String vasAcceptanceDescription;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String vasTandCDescription;

	/**
	 * <p>
	 * Returns selection authored
	 * </p>
	 * 
	 * @return String - selection
	 */
	@Override
	public String getVasArDescription() {
		return vasArDescription;
	}

    /**
	 * <p>
	 * Returns is Monthly Plan Value
	 * </p>
	 * @return Boolean - vasAcceptanceDescription
	 */
	@Override
	public String getVasAcceptanceDescription() {
		return vasAcceptanceDescription;
	}

    /**
	 * <p>
	 * Returns is Monthly Plan Value
	 * </p>
	 * @return Boolean - vasTandCDescription
	 */
	@Override
	public String getVasTandCDescription() {
		return vasTandCDescription;
	}

    /**
	 * <p>
	 * Returns exporter type
	 * </p>
	 * 
	 * @return String - getexportertype
	 */
	@Override
	public String getExportedType() {

		return request.getResource().getResourceType();
	}

}
