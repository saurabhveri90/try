package com.tracfonecore.core.models.impl;

import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.LoginOrCreateAccountModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.api.resource.ResourceResolver;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { LoginOrCreateAccountModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/loginorcreateaccount/v1/loginorcreateaccount", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class LoginOrCreateAccountModelImpl extends BaseComponentModelImpl implements LoginOrCreateAccountModel {

	@Self
	private SlingHttpServletRequest request;

	@SlingObject
	private ResourceResolver resourceResolver;

	@Inject
	private ApplicationConfigService applicationConfigService;

	@Inject
	private Page currentPage;

	/**
	 * Inject header text
	 */
	@Inject
	@Via("resource")
	private String headerText;

	/**
	 * Inject summary
	 */
	@Inject
	@Via("resource")
	private String summary;

	/**
	 * Inject enabletooltip
	 */
	@Inject
	@Via("resource")
	private String enabletooltip;

	/**
	 * Inject learmMoreModalContent
	 */
	@Inject
	@Via("resource")
	private String learnMoreModalContent;

	/**
	 * Inject forgotPasswordLink
	 */
	@Inject
	@Via("resource")
	private String forgotPasswordLink;

	/**
	 * Inject disableCaptcha
	 */
	@Inject
	@Via("resource")
	private String disableCaptcha;

	/**
	 * Inject forgotPasswordSuccessMessage
	 */
	@Inject
	@Via("resource")
	private String forgotPasswordSuccessMessage;

	/**
	 * Inject forgotPasswordSuccessTitle
	 */
	@Inject
	@Via("resource")
	private String forgotPasswordSuccessTitle;

	/**
	 * Inject forgotPasswordSuccessTitle
	 */
	@Inject
	@Via("resource")
	private String enableFacebookLogin;

	private String phonesPagePath;

	private static final Logger LOGGER = LoggerFactory.getLogger(LoginOrCreateAccountModelImpl.class);

	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering initModel method");
		super.initModel();
		setPhonesPagePath(CommerceUtil
				.getPagePropertyValue(currentPage, applicationConfigService.getHomePageLevel(),
						CommerceConstants.PHONES_PAGE_PATH) != null ? CommerceUtil
								.getPagePropertyValue(currentPage, applicationConfigService.getHomePageLevel(),
										CommerceConstants.PHONES_PAGE_PATH)
								.toString() : StringUtils.EMPTY);

		LOGGER.debug("Exiting initModel method");
	}

	/**
	 * <p>
	 * Returns headerText from properties
	 * </p>
	 * 
	 * @return String - headerText
	 */
	@Override
	public String getHeaderText() {
		return headerText;
	}

	/**
	 * <p>
	 * Returns summary from properties
	 * </p>
	 * 
	 * @return String - summary
	 */
	@Override
	public String getSummary() {
		return summary;
	}

	/**
	 * <p>
	 * Returns enabletooltip from properties
	 * </p>
	 * 
	 * @return String - enabletooltip
	 */
	@Override
	public String getEnabletooltip() {
		return enabletooltip;
	}

	/**
	 * <p>
	 * Returns learnMoreModalContent from properties
	 * </p>
	 * 
	 * @return the learnMoreModalContent
	 */
	@Override
	public String getLearnMoreModalContent() {
		return learnMoreModalContent;
	}

	/**
	 * <p>
	 * Returns forgotPasswordLink from properties
	 * </p>
	 * 
	 * @return the forgotPasswordLink
	 */
	@Override
	public String getForgotPasswordLink() {
		return forgotPasswordLink;
	}

	/**
	 * <p>
	 * Returns disableCaptcha from properties
	 * </p>
	 * 
	 * @return the disableCaptcha
	 */
	@Override
	public String getDisableCaptcha() {
		return disableCaptcha;
	}

	/**
	 * <p>
	 * Returns exportertype from resource
	 * </p>
	 * 
	 * @return String - exportertype
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Fetches ReCaptcha SiteKey property from config
	 * </p>
	 *
	 * @return String[] - reCaptchaSiteKey
	 */
	@Override
	public String getReCaptchaSiteKey() {
		return ConfigurationUtil.getConfigValue(applicationConfigService.getReCaptchaSiteKey(),
				CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}

	/**
	 * <p>
	 * Returns forgotPasswordSuccessMessage from properties
	 * </p>
	 * 
	 * @return the forgotPasswordSuccessMessage
	 */
	@Override
	public String getForgotPasswordSuccessMessage() {
		return forgotPasswordSuccessMessage;
	}

	/**
	 * <p>
	 * Returns forgotPasswordSuccessTitle from properties
	 * </p>
	 * 
	 * @return the forgotPasswordSuccessTitle
	 */
	@Override
	public String getForgotPasswordSuccessTitle() {
		return forgotPasswordSuccessTitle;
	}

	/**
	 * <p>
	 * Returns enableFacebookLogin from properties
	 * </p>
	 * 
	 * @return the enableFacebookLogin
	 */
	@Override
	public String getEnableFacebookLogin() {
		return enableFacebookLogin;
	}

	/**
	 * @return String return the phonesPagePath
	 */
	@Override
	public String getPhonesPagePath() {
		return ApplicationUtil.getShortUrl(resourceResolver, phonesPagePath);
	}

	/**
	 * @param phonesPagePath the phonesPagePath to set
	 */
	public void setPhonesPagePath(String phonesPagePath) {
		this.phonesPagePath = phonesPagePath;
	}

}
