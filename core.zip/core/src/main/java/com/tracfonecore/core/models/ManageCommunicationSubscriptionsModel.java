/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonGetter;
import java.util.List;

public interface ManageCommunicationSubscriptionsModel extends ComponentExporter {

	@JsonProperty("subTitle")
	public String getSubTitle();

	@JsonProperty("headerSubTitle")
	public String getHeaderSubTitle();
	
	@JsonProperty("emailLabel")
	public String getEmailLabel();
	
	@JsonProperty("mailLabel")
	public String getMailLabel();
	
	@JsonProperty("directmailLabel")
	public String getDirectmailLabel();
	
	@JsonGetter("communicationCategories")
    public List<ManageCommunicationCategoryModel> getCommunicationCategories();
	
	@JsonProperty("communicationsLabel")
	public String getCommunicationsLabel();
	
	@JsonProperty("privacyLabel")
	public String getPrivacyLabel();

	@JsonProperty("headerTitle")
	public String getHeaderTitle();

	@JsonProperty("smsLabel")
	public String getSmsLabel();

	@JsonProperty("unsubscribeallLabel")
	public String getUnsubscribeallLabel();

	@JsonProperty("updatepreferencesctaText")
	public String getUpdatepreferencesctaText();
	
	@JsonProperty("unsubscribeallhelpLabel")
	public String getUnsubscribeallhelpLabel();

	@JsonProperty("unsubscribedisclaimerText")
	public String getUnsubscribedisclaimerText();

	@JsonProperty("successText")
	public String getSuccessText();

	@JsonProperty("ccpaTitle")
	public String getCcpaTitle();

	@JsonProperty("ccpasubmitreqTxt")
	public String getCcpasubmitreqTxt();

	@JsonProperty("ccpasubmitctaLbl")
	public String getCcpasubmitctaLbl();

	@JsonProperty("ccpastatusreqTxt")
	public String getCcpastatusreqTxt();

	@JsonProperty("ccpacheckstatusctaLbl")
	public String getCcpacheckstatusctaLbl();

	@JsonProperty("successheaderText")
	public String getSuccessheaderText();
	
	@JsonProperty("unsuballsuccessText")
	public String getUnsuballsuccessText();

	@JsonProperty("errorTitle")
	public String getErrorTitle();
	
	@JsonProperty("errorText")
	public String getErrorText();

	@JsonProperty("submitRequestLink")
	public String getSubmitRequestLink();

	@JsonProperty("checkStatusLink")
	public String getCheckStatusLink();

	@JsonProperty("yourPrivacyChoicesLink")
	public String getYourPrivacyChoicesLink();

	@JsonProperty("openNewTabYourPrivacyChoicesLink")
	public String getOpenNewTabYourPrivacyChoicesLink();

	@JsonProperty("openNewTabCheckStatusLink")
	public String getOpenNewTabCheckStatusLink();

	@JsonProperty("openNewTabSubmitRequestLink")
	public String getOpenNewTabSubmitRequestLink();
}
