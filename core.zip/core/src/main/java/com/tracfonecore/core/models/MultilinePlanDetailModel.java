package com.tracfonecore.core.models;

import java.util.List;
import java.util.Map;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

public interface MultilinePlanDetailModel extends ComponentExporter {

  /**
   * <p>
   * Fetches the planName
   * </p>
   *
   * @return String - planName
   */
  @JsonProperty("planName")
  public String getPlanName();

  /**
   * <p>
   * Fetches the planNameType
   * </p>
   *
   * @return String - planNameType
   */
  @JsonProperty("planNameType")
  public String getPlanNameType();

  /**
   * <p>
   * Fetches show timer option
   * </p>
   *
   * @return String - Show Timer
   */
  @JsonProperty("showTimer")
  public Boolean getShowTimer();

  /**
   * <p>
   * Fetches the numberOfLines
   * </p>
   *
   * @return int - numberOfLines
   */
  @JsonProperty("numberOfLines")
  public Integer getNumberOfLines();

  /**
   * <p>
   * Fetches the multilineHeading
   * </p>
   *
   * @return String - multilineHeading
   */
  @JsonProperty("multilineHeading")
  public String getMultilineHeading();

  /**
   * <p>
   * Fetches the multilineSubheading
   * </p>
   *
   * @return String - multilineSubheading
   */
  @JsonProperty("multilineSubheading")
  public String getMultilineSubheading();

  /**
   * <p>
   * Fetches the priceBreakdownLabel
   * </p>
   *
   * @return String - priceBreakdownLabel
   */
  @JsonProperty("priceBreakdownLabel")
  public String getPriceBreakdownLabel();

  /**
   * <p>
   * Fetches the newCustomerCtaText
   * </p>
   *
   * @return String - newCustomerCtaText
   */
  @JsonProperty("newCustomerCtaText")
  public String getNewCustomerCtaText();

  /**
   * <p>
   * Fetches the newCustomeAccessibility
   * </p>
   *
   * @return String - newCustomerAccessibility
   */
  @JsonProperty("newCustomerAccessibility")
  public String getNewCustomerAccessibility();

  /**
   * <p>
   * Fetches the returnCustomerCtaText
   * </p>
   *
   * @return String - returnCustomerCtaText
   */
  @JsonProperty("returnCustomerCtaText")
  public String getReturnCustomerCtaText();

  /**
   * <p>
   * Fetches the returnCustomerAccessibility
   * </p>
   *
   * @return String - returnCustomerAccessibility
   */
  @JsonProperty("returnCustomerAccessibility")
  public String getReturnCustomerAccessibility();

  /**
   * <p>
   * Fetches the returnCustomerCtaLink
   * </p>
   *
   * @return String - returnCustomerCtaLink
   */
  @JsonProperty("returnCustomerCtaLink")
  public String getReturnCustomerCtaLink();

  /**
   * <p>
   * Fetches the planType
   * </p>
   *
   * @return String - planType
   */
  @JsonProperty("planType")
  public String getPlanType();

  /**
   * <p>
   * Fetches the selection
   * </p>
   *
   * @return String - selection
   */
  @JsonProperty("selection")
  public String getSelection();

  /**
   * <p>
   * Fetches the useBazaarVoiceRatings
   * </p>
   *
   * @return String - useBazaarVoiceRatings
   */
  @JsonProperty("useBazaarVoiceRatings")
  public String getUseBazaarVoiceRatings();

  /**
   * <p>
   * Fetches the numberOfLinesList
   * </p>
   *
   * @return String - numberOfLinesList
   */
  @JsonProperty("numberOfLinesList")
  public List<Object> getNumberOfLinesList();

  /**
   * <p>
   * Fetches the pricesuperscript
   * </p>
   *
   * @return String - pricesuperscript
   */
  @JsonProperty("pricesuperscript")
  public String getPricesuperscript();

  /**
   * <p>
   * Fetches the pertimeperiod
   * </p>
   *
   * @return String - pertimeperiod
   */
  @JsonProperty("pertimeperiod")
  public String getPertimeperiod();

  /**
   * <p>
   * Fetches the priceAccessibilityLabel
   * </p>
   *
   * @return String - priceAccessibilityLabel
   */
  @JsonProperty("priceAccessibilityLabel")
  public String getPriceAccessibilityLabel();

  /**
   * <p>
   * Fetches the disclaimerText
   * </p>
   *
   * @return String - disclaimerText
   */
  @JsonProperty("disclaimerText")
  public String getDisclaimerText();

  /**
   * <p>
   * Returns Rewards Purchase Label authored
   * </p>
   *
   * @return String - rewardsPurchaseLabel
   */
  @JsonProperty("rewardsPurchaseLabel")
  public String getRewardsPurchaseLabel();

  /**
   * <p>
   * Returns Rewards Earn Label authored
   * </p>
   *
   * @return String - rewardsEarnLabel
   */
  @JsonProperty("rewardsEarnLabel")
  public String getRewardsEarnLabel();

  /**
   * <p>
   * Returns saveAccessibilityLabel
   * </p>
   *
   * @return String - saveAccessibilityLabel
   */
  @JsonProperty("saveAccessibilityLabel")
  public String getSaveAccessibilityLabel();

  /**
   * <p>
   * Returns multilineplanrefillHeading
   * </p>
   *
   * @return String - multilineplanrefillHeading
   */
  @JsonProperty("multilineplanrefillHeading")
  public String getMultilineplanrefillHeading();

  /**
   * <p>
   * Returns multilinerefillSubheading
   * </p>
   *
   * @return String - multilinerefillSubheading
   */
  @JsonProperty("multilinerefillSubheading")
  public String getMultilinerefillSubheading();

  /**
   * <p>
   * Returns planrefillInputLabel
   * </p>
   *
   * @return String - planrefillInputLabel
   */
  @JsonProperty("planrefillInputLabel")
  public String getPlanrefillInputLabel();

  /**
   * <p>
   * Returns planrefillOTPLabel
   * </p>
   *
   * @return String - planrefillOTPLabel
   */
  @JsonProperty("planrefillOTPLabel")
  public String getPlanrefillOTPLabel();

  /**
   * <p>
   * Returns planrefillEditButtonText
   * </p>
   *
   * @return String - planrefillEditButtonText
   */
  @JsonProperty("planrefillEditButtonText")
  public String getPlanrefillEditButtonText();

  /**
   * <p>
   * Fetches the export child items
   * </p>
   *
   * 
   * @return Map<String, ? extends ComponentExporter> - the export child items
   */
  public Map<String, ? extends ComponentExporter> getItems();

  /**
   * <p>
   * Returns addMoreSaveMore
   * </p>
   *
   * @return String - addMoreSaveMore
   */
  @JsonProperty("addMoreSaveMore")
  public String getAddMoreSaveMore();

  /**
   * <p>
   * Returns purchaseFlow
   * </p>
   *
   * @return String - purchaseFlow
   */
  @JsonProperty("purchaseFlow")
  public String[] getPurchaseFlow();

  /**
   * <p>
   * Returns offerDisclaimer
   * </p>
   *
   * @return String - offerDisclaimer
   */
  @JsonProperty("offerDisclaimer")
  public String getOfferDisclaimer();

  /**
   * <p>
   * Returns offerDisclaimerLabel
   * </p>
   *
   * @return String - offerDisclaimerLabel
   */
  @JsonProperty("offerDisclaimerLabel")
  public String getOfferDisclaimerLabel();

  /**
   * <p>
   * Returns offerDisclaimerLinklabel
   * </p>
   *
   * @return String - offerDisclaimerLinklabel
   */
  @JsonProperty("offerDisclaimerLinklabel")
  public String getOfferDisclaimerLinklabel();

  /**
   * <p>
   * Returns specialPromoSummary
   * </p>
   *
   * @return String - specialPromoSummary
   */
  @JsonProperty("specialPromoSummary")
  public String getSpecialPromoSummary();

  /**
   * <p>
   * Fetches the planDescription
   * </p>
   *
   * @return String - planDescription
   */
  @JsonProperty("planDescription")
  public String getPlanDescription();

}
