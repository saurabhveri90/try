/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;

/**
 * <p>Defines bean to hold image detail</p>
 */
public class ImageBean {

	private String imagePath;
	private String text;
	private String altText;
	private String assetId;
	private String weberId;

	/**
	 * <p>Fetches path of Image</p>
	 * 
	 * @return String - path of Image
	 */
	public String getImagePath() {
		return imagePath;
	}

	/**
	 * <p>Sets image path</p>
	 * 
	 * @param imagePath - path of Image
	 */
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	/**
	 * <p>Fetches title text</p>
	 * 
	 * @return String - title text
	 */
	public String getText() {
		return text;
	}
	/**
	 * <p>Sets title text</p>
	 * 
	 * @param text - title text
	 */
	public void setText(String text) {
		this.text = text;
	}

	/**
	 * <p>Fetches alt text</p>
	 * 
	 * @return String - alt text
	 */
	public String getAltText() {
		return altText;
	}

	/**
	 * <p>Sets alt text</p>
	 * 
	 * @param alttext - alt text
	 */
	public void setAltText(String altText) {
		this.altText = altText;
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public String getWeberId() {
		return weberId;
	}

	public void setWeberId(String weberId) {
		this.weberId = weberId;
	}
	

	
	

	
	

}
