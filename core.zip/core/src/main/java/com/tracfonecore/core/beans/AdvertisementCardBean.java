/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * <p>Defines bean to hold Advertisement card detail</p>
 */
public class AdvertisementCardBean {

	private String cardType;
	private String title;
	private String subTitle;
	private String cardImage;
	private String cardImageAltText;
	private String textAlignment;
	private String cardCtaSize;
	private String cardCtaType;
	private String buttonTextAlignment;
	private String cardCtaLabel;
	private String cardCtaLink;
	private String linkTarget;
	private String doNotFollowLink;
	private String disableCard;
	private String assetId;
	private String weberId;
	private String textColor;
	private String mobileVersion;
	private String mode;
	private String imageProfileBreakPoint;
	private String mobileMediaImagePath; 
	private String bgColor;
	private String mobileImagePath;
	private String includeAppStore;
	private String appstore; 
	private String appstoreFileReference;
	private String appstorealttext;
	private String includePlayStore;
	private String playstore; 
	private String playstoreFileReference;
	private String playstorealttext;
	
	
	private List<CardFlowMappingBean> cardsFlowMappingList = Collections.emptyList();

	/**
	 * <p>Fetches card type</p>
	 * 
	 * @return String - card type
	 */
	public String getCardType() {
		return cardType;
	}

	/**
	 * <p>Fetches headline text of the card</p>
	 * 
	 * @return String - headline text of the card
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * <p>Fetches sub-headline text of the card</p>
	 * 
	 * @return String - sub-headline text of the card
	 */
	public String getSubTitle() {
		return subTitle;
	}

	/**
	 * <p>Fetches image path of the card</p>
	 * 
	 * @return String - image path the card
	 */
	public String getCardImage() {
		return cardImage;
	}

	/**
	 * <p>Fetches alt-text of the card image</p>
	 * 
	 * @return String - alt-text of the card image
	 */
	public String getCardImageAltText() {
		return cardImageAltText;
	}

	/**
	 * <p>Fetches alt-text of the card image</p>
	 * 
	 * @return String - alt-text of the card image
	 */
	public String getCardCtaLabel() {
		return cardCtaLabel;
	}

	/**
	 * <p>Fetches link of the card CTA</p>
	 * 
	 * @return String - link of the card CTA
	 */
	public String getCardCtaLink() {
		return cardCtaLink;
	}

	/**
	 * <p>Fetches target of the card CTA link</p>
	 * 
	 * @return String - target of the card CTA link
	 */
	public String getLinkTarget() {
		return linkTarget;
	}

	/**
	 * <p>Fetches flag to disable/enable card</p>
	 * 
	 * @return String - flag to disable/enable card
	 */
	public String getDisableCard() {
		return disableCard;
	}

	/**
	 * <p>Sets card type</p>
	 * 
	 * @param cardType - card type
	 */
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	/**
	 * <p>Sets headline text of the card</p>
	 * 
	 * @param headlineText - headline text of the card
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * <p>Sets sub-headline text of the card</p>
	 * 
	 * @param subHeadlineText - sub-headline text of the card
	 */
	public void setSubTitle(String subTitle) {
		this.subTitle = subTitle;
	}

	/**
	 * <p>Sets path of the card image</p>
	 * 
	 * @param cardImage - path of the card image
	 */
	public void setCardImage(String cardImage) {
		this.cardImage = cardImage;
	}

	/**
	 * <p>Sets alt-text of the card image</p>
	 * 
	 * @param cardImageAltText - alt-text of the card image
	 */
	public void setCardImageAltText(String cardImageAltText) {
		this.cardImageAltText = cardImageAltText;
	}

	/**
	 * <p>Sets cta label of the card</p>
	 * 
	 * @param cardCtaLabel - cta label of the card
	 */
	public void setCardCtaLabel(String cardCtaLabel) {
		this.cardCtaLabel = cardCtaLabel;
	}

	/**
	 * <p>Sets link path of the card cta</p>
	 * 
	 * @param cardCtaLink - link path of the card cta
	 */
	public void setCardCtaLink(String cardCtaLink) {
		this.cardCtaLink = cardCtaLink;
	}

	/**
	 * <p>Sets target of the card cta link</p>
	 * 
	 * @param linkTarget - target of the card cta link
	 */
	public void setLinkTarget(String linkTarget) {
		this.linkTarget = linkTarget;
	}

	/**
	 * <p>Sets disable card flag</p>
	 * 
	 * @param disableCard - disable card flag
	 */
	public void setDisableCard(String disableCard) {
		this.disableCard = disableCard;
	}

	/**
	 * <p>Fetches do not follow link flag</p>
	 * 
	 * @return String - do not follow link flag
	 */
	public String getDoNotFollowLink() {
		return doNotFollowLink;
	}

	/**
	 * <p>Sets do not follow link flag</p>
	 * 
	 * @param doNotFollowLink - do not follow link flag
	 */
	public void setDoNotFollowLink(String doNotFollowLink) {
		this.doNotFollowLink = doNotFollowLink;
	}
	/**
	 * <p>Fetches Asset Id of the image</p>
	 * 
	 * @return String - Asset Id of the image
	 */
	public String getAssetId() {
		return assetId;
	}

	/**
	 * <p>Sets Asset Id of the image</p>
	 * 
	 * @param assetId - Asset Id of the image
	 */
	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	/**
	 * <p>Fetches Weber Id of the image</p>
	 * 
	 * @return String - Weber Id of the image
	 */
	public String getWeberId() {
		return weberId;
	}

	/**
	 * <p>Sets Weber Id of the image</p>
	 * 
	 * @param weberId - Weber Id of the image
	 */
	public void setWeberId(String weberId) {
		this.weberId = weberId;
	}
	/**
	 * <p>Fetches Flow transaction mapping list of the card </p>
	 * 
	 * @return List<CardFlowMappingBean> -Flow transaction mapping list of the card 
	 */
	public List<CardFlowMappingBean> getCardsFlowMappingList() {
		return new ArrayList<>(cardsFlowMappingList);
	}

	/**
	 * <p>Sets Flow transaction mapping list of the card </p>
	 * 
	 * @param cardsList
	 */
	public void setCardsFlowMappingList(List<CardFlowMappingBean> cardsList) {
		this.cardsFlowMappingList = new ArrayList<>(cardsList);
	}

	/**
	 * <p>Fetches Alignment type of the card text</p>
	 * 
	 * @return String - Alignment type of the card text
	 */
	public String getTextAlignment() {
		return textAlignment;
	}

	/**
	 * <p>Sets Alignment type of the card text</p>
	 * 
	 * @param textAlignment
	 */
	public void setTextAlignment(String textAlignment) {
		this.textAlignment = textAlignment;
	}

	/**
	 * <p>Fetches CTA button size of the card </p>
	 * 
	 * @return String -CTA button size of the card 
	 */
	public String getCardCtaSize() {
		return cardCtaSize;
	}

	/**
	 * <p>Sets size of the CTA button text</p>
	 * 
	 * @param cardCtaSize
	 */
	public void setCardCtaSize(String cardCtaSize) {
		this.cardCtaSize = cardCtaSize;
	}

	/**
	 * <p>Fetches CTA button type of the card </p>
	 * 
	 * @return String - CTA button type of the card
	 */
	public String getCardCtaType() {
		return cardCtaType;
	}

	/**
	 * <p>Sets CTA button type of the card </p>
	 * 
	 * @param cardCtaType
	 */
	public void setCardCtaType(String cardCtaType) {
		this.cardCtaType = cardCtaType;
	}

	/**
	 * <p>Fetches CTA button text alignment of the card </p>
	 * 
	 * @return String - CTA button text alignment of the card
	 */
	public String getButtonTextAlignment() {
		return buttonTextAlignment;
	}

	/**
	 * <p>Sets CTA button text alignment of the card </p>
	 * 
	 * @param buttonTextAlignment
	 */
	public void setButtonTextAlignment(String buttonTextAlignment) {
		this.buttonTextAlignment = buttonTextAlignment;
	}

	/**
	 * <p>Fetches Text color of the card </p>
	 * 
	 * @return
	 */
	public String getTextColor() {
		return textColor;
	}

	/**
	 * <p>Sets Text color of the card </p>
	 * 
	 * @param textColor
	 */
	public void setTextColor(String textColor) {
		this.textColor = textColor;
	}

	/**
	 * <p>Fetches mobile version option of the card image </p>
	 * 
	 * @return
	 */
	public String getMobileVersion() {
		return mobileVersion;
	}

	/**
	 * <p>Sets mobile version option of the card image </p>
	 * 
	 * @param mobileVersion
	 */
	public void setMobileVersion(String mobileVersion) {
		this.mobileVersion = mobileVersion;
	}

	/**
	 * <p>Fetches mode of the card image </p>
	 * 
	 * @return
	 */
	public String getMode() {
		return mode;
	}

	/**
	 * <p>Sets mode of the card image </p>
	 * @param mode
	 */
	public void setMode(String mode) {
		this.mode = mode;
	}

	/**
	 * <p>Fetches image breakpoint card image </p>
	 * 
	 * @return
	 */
	public String getImageProfileBreakPoint() {
		return imageProfileBreakPoint;
	}

	/**
	 * <p>Sets image breakpoint card image </p>
	 * 
	 * @param imageProfileBreakPoint
	 */
	public void setImageProfileBreakPoint(String imageProfileBreakPoint) {
		this.imageProfileBreakPoint = imageProfileBreakPoint;
	}

	/**
	 * <p>Fetches mobile image path card image </p>
	 * 
	 * @return
	 */
	public String getMobileMediaImagePath() {
		return mobileMediaImagePath;
	}

	/**
	 * <p>Sets mobile image path card image </p>
	 * 
	 * @param mobileMediaImagePath
	 */
	public void setMobileMediaImagePath(String mobileMediaImagePath) {
		this.mobileMediaImagePath = mobileMediaImagePath;
	}

	/**
	 * <p>Fetches background color card image </p>
	 * 
	 * @return
	 */
	public String getBgColor() {
		return bgColor;
	}

	/**
	 * <p>Sets background color card image </p>
	 * @param bgColor
	 */
	public void setBgColor(String bgColor) {
		this.bgColor = bgColor;
	}
	
	/**
	 * <p>Fetches image path of the card for mobile view </p>
	 * 
	 * @return
	 */
	public String getMobileImagePath() {
		return mobileImagePath;
	}

	/**
	 * <p>Sets image path of the card for mobile view </p>
	 * 
	 * @param mobileImagePath
	 */
	public void setMobileImagePath(String mobileImagePath) {
		this.mobileImagePath = mobileImagePath;
	}

	/**
	 * <p>Fetches Include App store flag value</p>
	 * 
	 * @return String - Include App store flag value
	 */
	public String getIncludeAppStore() {
		return includeAppStore;
	}

	/**
	 * <p>Fetches App store target url</p>
	 * 
	 * @return String - App store target url
	 */
	public String getAppstore() {
		return appstore;
	}

	/**
	 * <p>Fetches App store logo image path</p>
	 * 
	 * @return String - App store logo image path
	 */
	public String getAppstoreFileReference() {
		return appstoreFileReference;
	}

	/**
	 * <p>Fetches App store button alt-text</p>
	 * 
	 * @return String - App store button alt-text
	 */
	public String getAppstorealttext() {
		return appstorealttext;
	}

	/**
	 * <p>Fetches Include Playstore flag value</p>
	 * 
	 * @return String - Include Playstore flag value
	 */
	public String getIncludePlayStore() {
		return includePlayStore;
	}

	/**
	 * <p>Fetches Playstore target url</p>
	 * 
	 * @return String - Playstore target url
	 */
	public String getPlaystore() {
		return playstore;
	}

	/**
	 * <p>Fetches Playstore logo image path</p>
	 * 
	 * @return String - Playstore logo image path
	 */
	public String getPlaystoreFileReference() {
		return playstoreFileReference;
	}

	/**
	 * <p>Fetches Playstore button alt-text</p>
	 * 
	 * @return String - Playstore button alt-text
	 */
	public String getPlaystorealttext() {
		return playstorealttext;
	}

	/**
	 * <p>Sets Include Appstore flag value</p>
	 * 
	 * @param includeAppStore - Include Appstore flag value
	 */
	public void setIncludeAppStore(String includeAppStore) {
		this.includeAppStore = includeAppStore;
	}

	/**
	 * <p>Sets Appstore target Url</p>
	 * 
	 * @param appstore - Appstore target Url
	 */
	public void setAppstore(String appstore) {
		this.appstore = appstore;
	}

	/**
	 * <p>Sets Appstore logo image path</p>
	 * 
	 * @param appstoreFileReference - Appstore logo image path
	 */
	public void setAppstoreFileReference(String appstoreFileReference) {
		this.appstoreFileReference = appstoreFileReference;
	}

	/**
	 * <p>Sets Appstore button alt-text</p>
	 * 
	 * @param appstorealttext - Appstore button alt-text
	 */
	public void setAppstorealttext(String appstorealttext) {
		this.appstorealttext = appstorealttext;
	}

	/**
	 * <p>Sets Include Playstore flag value</p>
	 * 
	 * @param includePlayStore - Include Playstore flag value
	 */
	public void setIncludePlayStore(String includePlayStore) {
		this.includePlayStore = includePlayStore;
	}

	/**
	 * <p>Sets Playstore target Url</p>
	 * 
	 * @param playstore - Playstore target Url
	 */
	public void setPlaystore(String playstore) {
		this.playstore = playstore;
	}

	/**
	 * <p>Sets Playstore logo image path</p>
	 * 
	 * @param playstoreFileReference - Playstore logo image path
	 */
	public void setPlaystoreFileReference(String playstoreFileReference) {
		this.playstoreFileReference = playstoreFileReference;
	}

	/**
	 * <p>Sets Playstore button alt-text</p>
	 * 
	 * @param playstorealttext - Playstore button alt-text
	 */
	public void setPlaystorealttext(String playstorealttext) {
		this.playstorealttext = playstorealttext;
	}

}
