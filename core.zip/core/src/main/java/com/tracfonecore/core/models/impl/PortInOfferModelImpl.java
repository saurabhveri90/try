/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.tracfonecore.core.constants.CommerceConstants;

import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.models.PortInOfferModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { PortInOfferModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/portinoffer", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class PortInOfferModelImpl extends BaseComponentModelImpl implements PortInOfferModel {

	@Inject
	private Page currentPage;

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;

	private ResourceResolver resolver;

	@Inject
	private TracfoneApiGatewayService tracfoneApiService;

	@Inject
	private Resource resource;

	@Inject
	@Via("resource")
	private String portInHeadingText;

	@Inject
	@Via("resource")
	private String portEligibilitySteps;

	@Inject
	@Via("resource")
	private String verifyPhoneNumberText;

	@Inject
	@Via("resource")
	private String verifyPhoneNumberLabel;

	@Inject
	@Via("resource")
	private String checkMyNumberCtaText;

	@Inject
	@Via("resource")
	private String verifyCodeHeadingText;

	@Inject
	@Via("resource")
	private String verifyCodeSubHeadingText;

	@Inject
	@Via("resource")
	private String verifyCodeInputLabelText;

	@Inject
	@Via("resource")
	private String verifyCodeCtaText;

	@Inject
	@Via("resource")
	private String verifyCodeResendTextOne;

	@Inject
	@Via("resource")
	private String verifyCodeResendTextTwo;

	@Inject
	@Via("resource")
	private String portInAnotherPhoneNumberText;

	@Inject
	@Via("resource")
	private String portInSuccessHeadingText;

	@Inject
	@Via("resource")
	private String portInSuccessDescriptionText;

	@Inject
	@Via("resource")
	private String veriffSuccessHeadingText;

	@Inject
	@Via("resource")
	private String veriffSuccessDescriptionText;

	@Inject
	@Via("resource")
	private String portInFailureHeadingTextOne;

	@Inject
	@Via("resource")
	private String portInFailureHeadingTextTwo;

	@Inject
	@Via("resource")
	private String portInFailureDescriptionText;

	@Inject
	@Via("resource")
	private String portInFailureOtherOptionsLink;

	@Inject
	@Via("resource")
	private String portInFailureOtherOptionsUrlLink;

	@Inject
	@Via("resource")
	private String portInFootnote;

	@Inject
	@Via("resource")
	private String portInLoaderHeadingText;

	@Inject
	@Via("resource")
	private String portInLoaderStepOne;

	@Inject
	@Via("resource")
	private String portInLoaderStepTwo;

	@Inject
	@Via("resource")
	private String portInLoaderStepThree;

	@Inject
	@Via("resource")
	private String portInFailureOtherOptionsAriaLabel;

	@Inject
	@Via("resource")
	private String portInApiErrorMsgOne;

	@Inject
	@Via("resource")
	private String portInApiErrorMsgTwo;

	@Inject
	@Via("resource")
	private String portInEligibilityApiTimer;

	@Inject
	@Via("resource")
	private String portInResendCodeTimer;

	@Inject
	@Via("resource")
	private String veriffFootnote;

	@Inject
	@Via("resource")
	private String veriffLVFootnote;

	@Inject
	@Via("resource")
	private String veriffNLFootnote;

	@Inject
	@Via("resource")
	private String veriffLFootnote;

	@Inject
	@Via("resource")
	private String veriffSuccessLVDescText;

	@Inject
	@Via("resource")
	private String veriffSuccessNLDescText;

	@Inject
	@Via("resource")
	private String verifyCodeResendAccTextTwo;

	@Inject
	@Via("resource")
	private String portInAnotherPhoneNumberAccText;

	@Inject
	@Via("resource")
	private String verifyCodeSubHeading2Text;

	@Inject
	private ApplicationConfigService applicationConfigService;

	@ValueMapValue
	private String plpPagePath;
	@ValueMapValue
	private String anotherPaymentText;
	@ValueMapValue
	private String anotherPaymentAltText;
	@ValueMapValue
	private String anotherPlanText;
	@ValueMapValue
	private String anotherPlanAltText;
	@ValueMapValue
	private String anotherPhoneNoText;
@ValueMapValue
	private String anotherPayOptText;
	@ValueMapValue
	private String anotherPayOptAltText;
	@ValueMapValue
	private String anotherPhoneNoAltText;

	private String privacyPolicyDisclaimer;
	private String showStepsNumber;
	private String categoryType;
	private String footNote;
	private String ctaDisableText;
	private String ctaText;
	private String ctaLink;
	private String showPortinInFlow;

	private static final Logger LOGGER = LoggerFactory.getLogger(PortInOfferModelImpl.class);

	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering initModel method");
		super.initModel();
		fetchPagePropertiesData();
		LOGGER.debug("Exiting initModel method");
	}

	private void fetchPagePropertiesData() {
		LOGGER.debug("Entering fetchPagePropertiesData method");
		Page parentPage = null;
		Page ancestorPage = null;
		resolver = resource.getResourceResolver();
		PageManager pm = resolver.adaptTo(PageManager.class);
		Page currentPage = pm.getContainingPage(resource);
		if (currentPage != null)
			parentPage = currentPage.getParent();
		if (parentPage != null) {
			ancestorPage = parentPage.getParent();
			properties = parentPage.getProperties();
		}

		PageManager plpPageManager = resolver.adaptTo(PageManager.class);
		Page currentPlpPage = plpPageManager.getPage(plpPagePath);
		Page parentPlppage = null;
		if (currentPlpPage != null) {
			parentPlppage = currentPlpPage.getParent();
		}

		if (currentPlpPage != null && currentPlpPage.getProperties() != null) {
			ValueMap currentPlpPageProperties = currentPlpPage.getProperties();
			if (currentPlpPageProperties != null
					&& currentPlpPageProperties.containsKey(CommerceConstants.CATEGORY_ID)) {
				properties = currentPlpPageProperties;
			} else if (parentPlppage != null && parentPlppage.getProperties() != null) {
				ValueMap parentPlpPageProperties = parentPlppage.getProperties();
				if (parentPlpPageProperties != null
						&& parentPlpPageProperties.containsKey(CommerceConstants.CATEGORY_ID)) {
					properties = parentPlpPageProperties;
				}
			}
		} else if (!(properties != null && properties.containsKey(CommerceConstants.CATEGORY_ID)
				&& !properties.get(CommerceConstants.CATEGORY_ID, String.class).isEmpty() &&
				properties.containsKey(CommerceConstants.CATEGORY_TYPE)
				&& !properties.get(CommerceConstants.CATEGORY_TYPE, String.class).isEmpty())
				&& ancestorPage != null) {
			properties = ancestorPage.getProperties();
		}

		if (properties != null) {

			if (null != properties.get(CommerceConstants.PORT_IN_HEADING_TEXT))
				setPortInHeadingText(properties.get(CommerceConstants.PORT_IN_HEADING_TEXT, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_ELIGIBILITY_STEPS))
				setPortEligibilitySteps(properties.get(CommerceConstants.PORT_IN_ELIGIBILITY_STEPS, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_VERIFY_PHONE_TEXT))
				setVerifyPhoneNumberText(properties.get(CommerceConstants.PORT_IN_VERIFY_PHONE_TEXT, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_VERIFY_PHONE_LABEL))
				setVerifyPhoneNumberLabel(properties.get(CommerceConstants.PORT_IN_VERIFY_PHONE_LABEL, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_CHECK_CTA_TEXT))
				setCheckMyNumberCtaText(properties.get(CommerceConstants.PORT_IN_CHECK_CTA_TEXT, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_VERIFY_CODE_HEADING_TEXT))
				setVerifyCodeHeadingText(
						properties.get(CommerceConstants.PORT_IN_VERIFY_CODE_HEADING_TEXT, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_VERIFY_CODE_SUB_HEADING_TEXT))
				setVerifyCodeSubHeadingText(
						properties.get(CommerceConstants.PORT_IN_VERIFY_CODE_SUB_HEADING_TEXT, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_VERIFY_CODE_SUB_HEADING_2_TEXT))
				setVerifyCodeSubHeading2Text(
						properties.get(CommerceConstants.PORT_IN_VERIFY_CODE_SUB_HEADING_2_TEXT, String.class));

			if (null != properties.get(CommerceConstants.PORT_IN_VERIFY_CODE_INPUT_LABEL))
				setVerifyCodeInputLabelText(
						properties.get(CommerceConstants.PORT_IN_VERIFY_CODE_INPUT_LABEL, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_VERIFY_CODE_CTA_TEXT))
				setVerifyCodeCtaText(properties.get(CommerceConstants.PORT_IN_VERIFY_CODE_CTA_TEXT, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_VERIFY_CODE_RESEND_TEXT_ONE))
				setVerifyCodeResendTextOne(
						properties.get(CommerceConstants.PORT_IN_VERIFY_CODE_RESEND_TEXT_ONE, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_VERIFY_CODE_RESEND_TEXT_TWO))
				setVerifyCodeResendTextTwo(
						properties.get(CommerceConstants.PORT_IN_VERIFY_CODE_RESEND_TEXT_TWO, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_ANOTHER_PHONE_NUM_LABEL))
				setPortInAnotherPhoneNumberText(
						properties.get(CommerceConstants.PORT_IN_ANOTHER_PHONE_NUM_LABEL, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_SUCCESS_HEADING_TEXT))
				setPortInSuccessHeadingText(
						properties.get(CommerceConstants.PORT_IN_SUCCESS_HEADING_TEXT, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_SUCCESS_DESCRIPTION_TEXT))
				setPortInSuccessDescriptionText(
						properties.get(CommerceConstants.PORT_IN_SUCCESS_DESCRIPTION_TEXT, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_FAILURE_HEADING_TEXT_ONE))
				setPortInFailureHeadingTextOne(
						properties.get(CommerceConstants.PORT_IN_FAILURE_HEADING_TEXT_ONE, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_FAILURE_HEADING_TEXT_TWO))
				setPortInFailureHeadingTextTwo(
						properties.get(CommerceConstants.PORT_IN_FAILURE_HEADING_TEXT_TWO, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_FAILURE_DESCRIPTION_TEXT))
				setPortInFailureDescriptionText(
						properties.get(CommerceConstants.PORT_IN_FAILURE_DESCRIPTION_TEXT, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_FAILURE_OPTIONS_LINK))
				setPortInFailureOtherOptionsLink(
						properties.get(CommerceConstants.PORT_IN_FAILURE_OPTIONS_LINK, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_FAILURE_OPTIONS_URL_LINK))
				setPortInFailureOtherOptionsUrlLink(
						properties.get(CommerceConstants.PORT_IN_FAILURE_OPTIONS_URL_LINK, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_FOOT_NOTE))
				setPortInFootnote(properties.get(CommerceConstants.PORT_IN_FOOT_NOTE, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_LOADER_HEADING_TEXT))
				setPortInLoaderHeadingText(properties.get(CommerceConstants.PORT_IN_LOADER_HEADING_TEXT, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_LOADER_STEP_ONE_TEXT))
				setPortInLoaderStepOne(properties.get(CommerceConstants.PORT_IN_LOADER_STEP_ONE_TEXT, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_LOADER_STEP_TWO_TEXT))
				setPortInLoaderStepTwo(properties.get(CommerceConstants.PORT_IN_LOADER_STEP_TWO_TEXT, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_LOADER_STEP_THREE_TEXT))
				setPortInLoaderStepThree(
						properties.get(CommerceConstants.PORT_IN_LOADER_STEP_THREE_TEXT, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_FAILURE_OPTIONS_ARIA_LINK))
				setPortInFailureOtherOptionsAriaLabel(
						properties.get(CommerceConstants.PORT_IN_FAILURE_OPTIONS_ARIA_LINK, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_LOADER_STEP_ERROR_ONE_TEXT))
				setPortInApiErrorMsgOne(
						properties.get(CommerceConstants.PORT_IN_LOADER_STEP_ERROR_ONE_TEXT, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_LOADER_STEP_ERROR_TWO_TEXT))
				setPortInApiErrorMsgTwo(
						properties.get(CommerceConstants.PORT_IN_LOADER_STEP_ERROR_TWO_TEXT, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_ELIGIBILITY_API_TIMER))
				setPortInEligibilityApiTimer(
						properties.get(CommerceConstants.PORT_IN_ELIGIBILITY_API_TIMER, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_RESEND_CODE_TIMER))
				setPortInResendCodeTimer(properties.get(CommerceConstants.PORT_IN_RESEND_CODE_TIMER, String.class));
			if (null != properties.get(CommerceConstants.VERIFF_SUCCESS_HEADING_TEXT))
				setVeriffSuccessHeadingText(
						properties.get(CommerceConstants.VERIFF_SUCCESS_HEADING_TEXT, String.class));
			if (null != properties.get(CommerceConstants.VERIFF_SUCCESS_DESCRIPTION_TEXT))
				setVeriffSuccessDescriptionText(
						properties.get(CommerceConstants.VERIFF_SUCCESS_DESCRIPTION_TEXT, String.class));
			if (null != properties.get(CommerceConstants.VERIFF_SUCCESS_LV_DESCRIPTION_TEXT))
				setVeriffSuccessLVDescText(
						properties.get(CommerceConstants.VERIFF_SUCCESS_LV_DESCRIPTION_TEXT, String.class));
			if (null != properties.get(CommerceConstants.VERIFF_SUCCESS_NL_DESCRIPTION_TEXT))
				setVeriffSuccessNLDescText(
						properties.get(CommerceConstants.VERIFF_SUCCESS_NL_DESCRIPTION_TEXT, String.class));
			if (null != properties.get(CommerceConstants.VERIFF_FOOT_NOTE))
				setVeriffFootnote(properties.get(CommerceConstants.VERIFF_FOOT_NOTE, String.class));
			if (null != properties.get(CommerceConstants.VERIFF_LV_FOOT_NOTE))
				setVeriffLVFootnote(properties.get(CommerceConstants.VERIFF_LV_FOOT_NOTE, String.class));
			if (null != properties.get(CommerceConstants.VERIFF_NL_FOOT_NOTE))
				setVeriffNLFootnote(properties.get(CommerceConstants.VERIFF_NL_FOOT_NOTE, String.class));
			if (null != properties.get(CommerceConstants.VERIFF_LOGGED_IN_FOOT_NOTE))
				setVeriffLFootnote(properties.get(CommerceConstants.VERIFF_LOGGED_IN_FOOT_NOTE, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_VERIFY_CODE_RESEND_ACC_TEXT_TWO))
				setVerifyCodeResendAccTextTwo(
						properties.get(CommerceConstants.PORT_IN_VERIFY_CODE_RESEND_ACC_TEXT_TWO, String.class));
			if (null != properties.get(CommerceConstants.PORT_IN_ANOTHER_PHONE_NUM_ACC_LABEL))
				setPortInAnotherPhoneNumberAccText(
						properties.get(CommerceConstants.PORT_IN_ANOTHER_PHONE_NUM_ACC_LABEL, String.class));
			if (null != properties.get(CommerceConstants.CTA_TEXT))
				setCtaText(properties.get(CommerceConstants.CTA_TEXT, String.class));
			if (null != properties.get(CommerceConstants.CTA_DISABLE_TEXT))
				setCtaDisableText(properties.get(CommerceConstants.CTA_DISABLE_TEXT, String.class));
			if (null != properties.get(CommerceConstants.SHOW_STEPS_NUMBER))
				setShowStepsNumber(properties.get(CommerceConstants.SHOW_STEPS_NUMBER, String.class));
			if (null != properties.get(CommerceConstants.PRIVACY_POLICY_DISCLAIMER))
				setPrivacyPolicyDisclaimer(
						properties.get(CommerceConstants.PRIVACY_POLICY_DISCLAIMER, String.class));
			if (null != properties.get(CommerceConstants.FOOT_NOTE))
				setFootNote(properties.get(CommerceConstants.FOOT_NOTE, String.class));
			if (null != properties.get(CommerceConstants.SHOW_PORT_IN_SCREEN_IN_FLOW))
				setShowPortinInFlow(properties.get(CommerceConstants.SHOW_PORT_IN_SCREEN_IN_FLOW, String.class));
			if (null != properties.get(CommerceConstants.CTA_LINK))
				setCtaLink(properties.get(CommerceConstants.CTA_LINK, String.class));


		}
		LOGGER.debug("Exiting fetchPagePropertiesData method");
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Fetches portInHeadingText text/p>
	 *
	 * @return String - portInHeadingText text
	 */
	@Override
	public String getPortInHeadingText() {
		return portInHeadingText;
	}

	/**
	 * <p>
	 * Sets portInHeadingText
	 * </p>
	 *
	 * @param portInHeadingText - the portInHeadingText to set
	 */
	public void setPortInHeadingText(String portInHeadingText) {
		this.portInHeadingText = portInHeadingText;
	}

	/**
	 * <p>
	 * Fetches portEligibilitySteps text/p>
	 *
	 * @return String - portEligibilitySteps text
	 */
	@Override
	public String getPortEligibilitySteps() {
		return portEligibilitySteps;
	}

	/**
	 * <p>
	 * Sets portEligibilitySteps
	 * </p>
	 *
	 * @param portEligibilitySteps - the portEligibilitySteps to set
	 */
	public void setPortEligibilitySteps(String portEligibilitySteps) {
		this.portEligibilitySteps = portEligibilitySteps;
	}

	/**
	 * <p>
	 * Fetches verifyPhoneNumberText/p>
	 *
	 * @return String - verifyPhoneNumberText
	 */
	@Override
	public String getVerifyPhoneNumberText() {
		return verifyPhoneNumberText;
	}

	/**
	 * <p>
	 * Sets verifyPhoneNumberText
	 * </p>
	 *
	 * @param verifyPhoneNumberText - the verifyPhoneNumberText to set
	 */
	public void setVerifyPhoneNumberText(String verifyPhoneNumberText) {
		this.verifyPhoneNumberText = verifyPhoneNumberText;
	}

	/**
	 * <p>
	 * Fetches verifyPhoneNumberLabel text/p>
	 *
	 * @return String - verifyPhoneNumberLabel text
	 */
	@Override
	public String getVerifyPhoneNumberLabel() {
		return verifyPhoneNumberLabel;
	}

	/**
	 * <p>
	 * Sets -verifyPhoneNumberLabel
	 * </p>
	 *
	 * @param verifyPhoneNumberLabel - the verifyPhoneNumberLabel to set
	 */
	public void setVerifyPhoneNumberLabel(String verifyPhoneNumberLabel) {
		this.verifyPhoneNumberLabel = verifyPhoneNumberLabel;
	}

	/**
	 * <p>
	 * Fetches checkMyNumberCtaText text/p>
	 *
	 * @return String - checkMyNumberCtaText text
	 */
	@Override
	public String getCheckMyNumberCtaText() {
		return checkMyNumberCtaText;
	}

	/**
	 * <p>
	 * Sets checkMyNumberCtaText
	 * </p>
	 *
	 * @param checkMyNumberCtaText - the checkMyNumberCtaText to set
	 */
	public void setCheckMyNumberCtaText(String checkMyNumberCtaText) {
		this.checkMyNumberCtaText = checkMyNumberCtaText;
	}

	/**
	 * <p>
	 * Fetches verifyCodeHeadingText text/p>
	 *
	 * @return String - verifyCodeHeadingText text
	 */
	@Override
	public String getVerifyCodeHeadingText() {
		return verifyCodeHeadingText;
	}

	/**
	 * <p>
	 * Sets verifyCodeHeadingText
	 * </p>
	 *
	 * @param verifyCodeHeadingText - the verifyCodeHeadingText to set
	 */
	public void setVerifyCodeHeadingText(String verifyCodeHeadingText) {
		this.verifyCodeHeadingText = verifyCodeHeadingText;
	}

	/**
	 * <p>
	 * Fetches verifyCodeSubHeadingText text/p>
	 *
	 * @return String - verifyCodeSubHeadingText text
	 */
	@Override
	public String getVerifyCodeSubHeadingText() {
		return verifyCodeSubHeadingText;
	}

	/**
	 * <p>
	 * Sets verifyCodeSubHeadingText
	 * </p>
	 *
	 * @param verifyCodeSubHeadingText - the verifyCodeSubHeadingText to set
	 */
	public void setVerifyCodeSubHeadingText(String verifyCodeSubHeadingText) {
		this.verifyCodeSubHeadingText = verifyCodeSubHeadingText;
	}

	/**
	 * <p>
	 * Fetches verifyCodeInputLabelText text/p>
	 *
	 * @return String - verifyCodeInputLabelText text
	 */
	@Override
	public String getVerifyCodeInputLabelText() {
		return verifyCodeInputLabelText;
	}

	/**
	 * <p>
	 * Sets verifyCodeInputLabelText
	 * </p>
	 *
	 * @param verifyCodeInputLabelText - the verifyCodeInputLabelText to set
	 */
	public void setVerifyCodeInputLabelText(String verifyCodeInputLabelText) {
		this.verifyCodeInputLabelText = verifyCodeInputLabelText;
	}

	/**
	 * <p>
	 * Fetches verifyCodeCtaText text/p>
	 *
	 * @return String - verifyCodeCtaText text
	 */
	@Override
	public String getVerifyCodeCtaText() {
		return verifyCodeCtaText;
	}

	/**
	 * <p>
	 * Sets verifyCodeCtaText
	 * </p>
	 *
	 * @param verifyCodeCtaText - the verifyCodeCtaText to set
	 */
	public void setVerifyCodeCtaText(String verifyCodeCtaText) {
		this.verifyCodeCtaText = verifyCodeCtaText;
	}

	/**
	 * <p>
	 * Fetches verifyCodeResendTextOne text/p>
	 *
	 * @return String - verifyCodeResendTextOne text
	 */
	@Override
	public String getVerifyCodeResendTextOne() {
		return verifyCodeResendTextOne;
	}

	/**
	 * <p>
	 * Sets verifyCodeResendTextOne
	 * </p>
	 *
	 * @param verifyCodeResendTextOne - the verifyCodeResendTextOne to set
	 */
	public void setVerifyCodeResendTextOne(String verifyCodeResendTextOne) {
		this.verifyCodeResendTextOne = verifyCodeResendTextOne;
	}

	/**
	 * <p>
	 * Fetches verifyCodeResendTextTwo text/p>
	 *
	 * @return String - verifyCodeResendTextTwo text
	 */
	@Override
	public String getVerifyCodeResendTextTwo() {
		return verifyCodeResendTextTwo;
	}

	/**
	 * <p>
	 * Sets verifyCodeResendTextTwo
	 * </p>
	 *
	 * @param verifyCodeResendTextTwo - the verifyCodeResendTextTwo to set
	 */
	public void setVerifyCodeResendTextTwo(String verifyCodeResendTextTwo) {
		this.verifyCodeResendTextTwo = verifyCodeResendTextTwo;
	}

	/**
	 * <p>
	 * Fetches portInAnotherPhoneNumberText text/p>
	 *
	 * @return String - portInAnotherPhoneNumberText text
	 */
	@Override
	public String getPortInAnotherPhoneNumberText() {
		return portInAnotherPhoneNumberText;
	}

	/**
	 * <p>
	 * Sets portInAnotherPhoneNumberText
	 * </p>
	 *
	 * @param portInAnotherPhoneNumberText - the portInAnotherPhoneNumberText to set
	 */
	public void setPortInAnotherPhoneNumberText(String portInAnotherPhoneNumberText) {
		this.portInAnotherPhoneNumberText = portInAnotherPhoneNumberText;
	}

	/**
	 * <p>
	 * Fetches portInSuccessHeadingText text/p>
	 *
	 * @return String - portInSuccessHeadingText text
	 */
	@Override
	public String getPortInSuccessHeadingText() {
		return portInSuccessHeadingText;
	}

	/**
	 * <p>
	 * Sets portInSuccessHeadingText
	 * </p>
	 *
	 * @param portInSuccessHeadingText - the portInSuccessHeadingText to set
	 */
	public void setPortInSuccessHeadingText(String portInSuccessHeadingText) {
		this.portInSuccessHeadingText = portInSuccessHeadingText;
	}

	/**
	 * <p>
	 * Fetches portInSuccessDescriptionText text/p>
	 *
	 * @return String - portInSuccessDescriptionText text
	 */
	@Override
	public String getPortInSuccessDescriptionText() {
		return portInSuccessDescriptionText;
	}

	/**
	 * <p>
	 * Sets portInSuccessDescriptionText
	 * </p>
	 *
	 * @param portInSuccessDescriptionText - the portInSuccessDescriptionText to set
	 */
	public void setPortInSuccessDescriptionText(String portInSuccessDescriptionText) {
		this.portInSuccessDescriptionText = portInSuccessDescriptionText;
	}

	/**
	 * <p>
	 * Fetches portInFailureHeadingTextOne text/p>
	 *
	 * @return String - portInFailureHeadingTextOne text
	 */
	@Override
	public String getPortInFailureHeadingTextOne() {
		return portInFailureHeadingTextOne;
	}

	/**
	 * <p>
	 * Sets portInFailureHeadingTextOne
	 * </p>
	 *
	 * @param portInFailureHeadingTextOne - the portInFailureHeadingTextOne to set
	 */
	public void setPortInFailureHeadingTextOne(String portInFailureHeadingTextOne) {
		this.portInFailureHeadingTextOne = portInFailureHeadingTextOne;
	}

	/**
	 * <p>
	 * Fetches portInFailureHeadingTextTwo text/p>
	 *
	 * @return String - portInFailureHeadingTextTwo text
	 */
	@Override
	public String getPortInFailureHeadingTextTwo() {
		return portInFailureHeadingTextTwo;
	}

	/**
	 * <p>
	 * Sets portInFailureHeadingTextTwo
	 * </p>
	 *
	 * @param portInFailureHeadingTextTwo - the portInFailureHeadingTextTwo to set
	 */
	public void setPortInFailureHeadingTextTwo(String portInFailureHeadingTextTwo) {
		this.portInFailureHeadingTextTwo = portInFailureHeadingTextTwo;
	}

	/**
	 * <p>
	 * Fetches portInFailureDescriptionText text/p>
	 *
	 * @return String - portInFailureDescriptionText text
	 */
	@Override
	public String getPortInFailureDescriptionText() {
		return portInFailureDescriptionText;
	}

	/**
	 * <p>
	 * Sets portInFailureDescriptionText
	 * </p>
	 *
	 * @param portInFailureDescriptionText - the portInFailureDescriptionText to set
	 */
	public void setPortInFailureDescriptionText(String portInFailureDescriptionText) {
		this.portInFailureDescriptionText = portInFailureDescriptionText;
	}

	/**
	 * <p>
	 * Fetches portInFailureOtherOptionsLink text/p>
	 *
	 * @return String - portInFailureOtherOptionsLink text
	 */
	@Override
	public String getPortInFailureOtherOptionsLink() {
		return portInFailureOtherOptionsLink;
	}

	/**
	 * <p>
	 * Sets portInFailureOtherOptionsLink
	 * </p>
	 *
	 * @param portInFailureOtherOptionsLink - the portInFailureOtherOptionsLink to
	 *                                      set
	 */
	public void setPortInFailureOtherOptionsLink(String portInFailureOtherOptionsLink) {
		this.portInFailureOtherOptionsLink = portInFailureOtherOptionsLink;
	}

	/**
	 * <p>
	 * Fetches portInFailureOtherOptionsUrlLink text/p>
	 *
	 * @return String - portInFailureOtherOptionsUrlLink text
	 */
	@Override
	public String getPortInFailureOtherOptionsUrlLink() {
		return ApplicationUtil.getShortUrl(request.getResourceResolver(), portInFailureOtherOptionsUrlLink);
	}

	/**
	 * <p>
	 * Sets portInFailureOtherOptionsUrlLink
	 * </p>
	 *
	 * @param portInFailureOtherOptionsUrlLink - the
	 *                                         portInFailureOtherOptionsUrlLink to
	 *                                         set
	 */
	public void setPortInFailureOtherOptionsUrlLink(String portInFailureOtherOptionsUrlLink) {
		this.portInFailureOtherOptionsUrlLink = portInFailureOtherOptionsUrlLink;
	}

	/**
	 * <p>
	 * Fetches portInFootnote text/p>
	 *
	 * @return String - portInFootnote text
	 */
	@Override
	public String getPortInFootnote() {
		return portInFootnote;
	}

	/**
	 * <p>
	 * Sets portInFootnote
	 * </p>
	 *
	 * @param portInFootnote - the portInFootnote to set
	 */
	public void setPortInFootnote(String portInFootnote) {
		this.portInFootnote = portInFootnote;
	}

	/**
	 * <p>
	 * Fetches portInLoaderHeadingText text/p>
	 *
	 * @return String - portInLoaderHeadingText text
	 */
	@Override
	public String getPortInLoaderHeadingText() {
		return portInLoaderHeadingText;
	}

	/**
	 * <p>
	 * Sets portInLoaderHeadingText
	 * </p>
	 *
	 * @param portInLoaderHeadingText - the portInLoaderHeadingText to set
	 */
	public void setPortInLoaderHeadingText(String portInLoaderHeadingText) {
		this.portInLoaderHeadingText = portInLoaderHeadingText;
	}

	/**
	 * <p>
	 * Fetches portInLoaderStepOne text/p>
	 *
	 * @return String - portInLoaderStepOne text
	 */
	@Override
	public String getPortInLoaderStepOne() {
		return portInLoaderStepOne;
	}

	/**
	 * <p>
	 * Sets portInLoaderStepOne
	 * </p>
	 *
	 * @param portInLoaderStepOne - the portInLoaderStepOne to set
	 */
	public void setPortInLoaderStepOne(String portInLoaderStepOne) {
		this.portInLoaderStepOne = portInLoaderStepOne;
	}

	/**
	 * <p>
	 * Fetches portInLoaderStepTwo text/p>
	 *
	 * @return String - portInLoaderStepTwo text
	 */
	@Override
	public String getPortInLoaderStepTwo() {
		return portInLoaderStepTwo;
	}

	/**
	 * <p>
	 * Sets portInLoaderStepTwo
	 * </p>
	 *
	 * @param portInLoaderStepTwo - the portInLoaderStepTwo to set
	 */
	public void setPortInLoaderStepTwo(String portInLoaderStepTwo) {
		this.portInLoaderStepTwo = portInLoaderStepTwo;
	}

	/**
	 * <p>
	 * Fetches portInLoaderStepThree text/p>
	 *
	 * @return String - portInLoaderStepThree text
	 */
	@Override
	public String getPortInLoaderStepThree() {
		return portInLoaderStepThree;
	}

	/**
	 * <p>
	 * Sets portInLoaderStepThree
	 * </p>
	 *
	 * @param portInLoaderStepThree - the portInLoaderStepThree to set
	 */
	public void setPortInLoaderStepThree(String portInLoaderStepThree) {
		this.portInLoaderStepThree = portInLoaderStepThree;
	}

	/**
	 * <p>
	 * Fetches portInFailureOtherOptionsAriaLabel text/p>
	 *
	 * @return String - portInFailureOtherOptionsAriaLabel text
	 */
	@Override
	public String getPortInFailureOtherOptionsAriaLabel() {
		return portInFailureOtherOptionsAriaLabel;
	}

	/**
	 * <p>
	 * Sets portInFailureOtherOptionsAriaLabel
	 * </p>
	 *
	 * @param portInFailureOtherOptionsAriaLabel - the
	 *                                           portInFailureOtherOptionsAriaLabel
	 *                                           to set
	 */
	public void setPortInFailureOtherOptionsAriaLabel(String portInFailureOtherOptionsAriaLabel) {
		this.portInFailureOtherOptionsAriaLabel = portInFailureOtherOptionsAriaLabel;
	}

	/**
	 * <p>
	 * Fetches portInApiErrorMsgOne text/p>
	 *
	 * @return String - portInApiErrorMsgOne text
	 */
	@Override
	public String getPortInApiErrorMsgOne() {
		return portInApiErrorMsgOne;
	}

	/**
	 * <p>
	 * Sets portInApiErrorMsgOne
	 * </p>
	 *
	 * @param portInApiErrorMsgOne - the portInApiErrorMsgOne to set
	 */
	public void setPortInApiErrorMsgOne(String portInApiErrorMsgOne) {
		this.portInApiErrorMsgOne = portInApiErrorMsgOne;
	}

	/**
	 * <p>
	 * Fetches portInApiErrorMsgTwo text/p>
	 *
	 * @return String - portInApiErrorMsgTwo text
	 */
	@Override
	public String getPortInApiErrorMsgTwo() {
		return portInApiErrorMsgTwo;
	}

	/**
	 * <p>
	 * Sets portInApiErrorMsgTwo
	 * </p>
	 *
	 * @param portInApiErrorMsgTwo - the portInApiErrorMsgTwo to set
	 */
	public void setPortInApiErrorMsgTwo(String portInApiErrorMsgTwo) {
		this.portInApiErrorMsgTwo = portInApiErrorMsgTwo;
	}

	/**
	 * <p>
	 * Fetches portInEligibilityApiTimer text/p>
	 *
	 * @return String - portInEligibilityApiTimer text
	 */
	@Override
	public String getPortInEligibilityApiTimer() {
		return portInEligibilityApiTimer;
	}

	/**
	 * <p>
	 * Sets portInEligibilityApiTimer
	 * </p>
	 *
	 * @param portInEligibilityApiTimer - the portInEligibilityApiTimer to set
	 */
	public void setPortInEligibilityApiTimer(String portInEligibilityApiTimer) {
		this.portInEligibilityApiTimer = portInEligibilityApiTimer;
	}

	/**
	 * <p>
	 * Fetches portInResendCodeTimer text/p>
	 *
	 * @return String - portInResendCodeTimer text
	 */
	@Override
	public String getPortInResendCodeTimer() {
		return portInResendCodeTimer;
	}

	/**
	 * <p>
	 * Sets portInResendCodeTimer
	 * </p>
	 *
	 * @param portInResendCodeTimer - the portInResendCodeTimer to set
	 */
	public void setPortInResendCodeTimer(String portInResendCodeTimer) {
		this.portInResendCodeTimer = portInResendCodeTimer;
	}

	/**
	 * <p>
	 * Fetches veriffSuccessHeadingText
	 * </p>
	 *
	 * @return the veriffSuccessHeadingText
	 */
	@Override
	public String getVeriffSuccessHeadingText() {
		return veriffSuccessHeadingText;
	}

	/**
	 * <p>
	 * Sets veriffSuccessHeadingText
	 * </p>
	 *
	 * @param veriffSuccessHeadingText - the veriffSuccessHeadingText to set
	 */
	public void setVeriffSuccessHeadingText(String veriffSuccessHeadingText) {
		this.veriffSuccessHeadingText = veriffSuccessHeadingText;
	}

	/**
	 * <p>
	 * Fetches veriffSuccessDescriptionText
	 * </p>
	 *
	 * @return the veriffSuccessDescriptionText
	 */
	@Override
	public String getVeriffSuccessDescriptionText() {
		return veriffSuccessDescriptionText;
	}

	/**
	 * <p>
	 * Sets veriffSuccessDescriptionText
	 * </p>
	 *
	 * @param veriffSuccessDescriptionText - the veriffSuccessDescriptionText to set
	 */
	public void setVeriffSuccessDescriptionText(String veriffSuccessDescriptionText) {
		this.veriffSuccessDescriptionText = veriffSuccessDescriptionText;
	}

	/**
	 * <p>
	 * Fetches veriffFootnote text/p>
	 *
	 * @return String - veriffFootnote text
	 */
	@Override
	public String getVeriffFootnote() {
		return veriffFootnote;
	}

	/**
	 * <p>
	 * Sets veriffFootnote
	 * </p>
	 *
	 * @param veriffFootnote - the veriffFootnote to set
	 */
	public void setVeriffFootnote(String veriffFootnote) {
		this.veriffFootnote = veriffFootnote;
	}

	/**
	 * @return String return the veriffLVFootnote
	 */
	@Override
	public String getVeriffLVFootnote() {
		return veriffLVFootnote;
	}

	/**
	 * @param veriffLVFootnote the veriffLVFootnote to set
	 */
	public void setVeriffLVFootnote(String veriffLVFootnote) {
		this.veriffLVFootnote = veriffLVFootnote;
	}

	/**
	 * @return String return the veriffNLFootnote
	 */
	@Override
	public String getVeriffNLFootnote() {
		return veriffNLFootnote;
	}

	/**
	 * @param veriffNLFootnote the veriffNLFootnote to set
	 */
	public void setVeriffNLFootnote(String veriffNLFootnote) {
		this.veriffNLFootnote = veriffNLFootnote;
	}

	/**
	 * @return String return the veriffLFootnote
	 */
	@Override
	public String getVeriffLFootnote() {
		return veriffLFootnote;
	}

	/**
	 * @param veriffLFootnote the veriffLFootnote to set
	 */
	public void setVeriffLFootnote(String veriffLFootnote) {
		this.veriffLFootnote = veriffLFootnote;
	}

	/**
	 * @return String return the veriffSuccessLVDescText
	 */
	@Override
	public String getVeriffSuccessLVDescText() {
		return veriffSuccessLVDescText;
	}

	/**
	 * @param veriffSuccessLVDescText the veriffSuccessLVDescText to set
	 */
	public void setVeriffSuccessLVDescText(String veriffSuccessLVDescText) {
		this.veriffSuccessLVDescText = veriffSuccessLVDescText;
	}

	/**
	 * @return String return the veriffSuccessNLDescText
	 */
	@Override
	public String getVeriffSuccessNLDescText() {
		return veriffSuccessNLDescText;
	}

	/**
	 * @param veriffSuccessNLDescText the veriffSuccessNLDescText to set
	 */
	public void setVeriffSuccessNLDescText(String veriffSuccessNLDescText) {
		this.veriffSuccessNLDescText = veriffSuccessNLDescText;
	}

	/**
	 * @return String return the verifyCodeResendAccTextTwo
	 */
	@Override
	public String getVerifyCodeResendAccTextTwo() {
		return verifyCodeResendAccTextTwo;
	}

	/**
	 * @param verifyCodeResendAccTextTwo the verifyCodeResendAccTextTwo to set
	 */
	public void setVerifyCodeResendAccTextTwo(String verifyCodeResendAccTextTwo) {
		this.verifyCodeResendAccTextTwo = verifyCodeResendAccTextTwo;
	}

	/**
	 * @return String return the portInAnotherPhoneNumberAccText
	 */
	@Override
	public String getPortInAnotherPhoneNumberAccText() {
		return portInAnotherPhoneNumberAccText;
	}

	/**
	 * @param portInAnotherPhoneNumberAccText the portInAnotherPhoneNumberAccText to
	 *                                        set
	 */
	public void setPortInAnotherPhoneNumberAccText(String portInAnotherPhoneNumberAccText) {
		this.portInAnotherPhoneNumberAccText = portInAnotherPhoneNumberAccText;
	}

	/**
	 * <p>
	 * Fetches showStepsNumber
	 * </p>
	 *
	 * @return String return the privacyPolicyDisclaimer
	 */
	@Override
	public String getPrivacyPolicyDisclaimer() {
		return privacyPolicyDisclaimer;
	}

	/**
	 * @param privacyPolicyDisclaimer the privacyPolicyDisclaimer to set
	 */
	public void setPrivacyPolicyDisclaimer(String privacyPolicyDisclaimer) {
		this.privacyPolicyDisclaimer = privacyPolicyDisclaimer;
	}

	/**
	 * <p>
	 * Fetches showStepsNumber
	 * </p>
	 *
	 * @return the showStepsNumber
	 */
	@Override
	public String getShowStepsNumber() {
		return showStepsNumber;
	}

	/**
	 * <p>
	 * Sets setShowStepsNumber
	 * </p>
	 *
	 * @param showStepsNumber - the showStepsNumber to set
	 */
	public void setShowStepsNumber(String showStepsNumber) {
		this.showStepsNumber = showStepsNumber;
	}



	/**
	 * <p>
	 * Fetches footNote
	 * </p>
	 *
	 * @return the footNote
	 */
	@Override
	public String getFootNote() {
		return footNote;
	}

	/**
	 * @param footNote the footNote to set
	 */
	public void setFootNote(String footNote) {
		this.footNote = footNote;
	}

	/**
	 * <p>
	 * Fetches ctaDisableText
	 * </p>
	 *
	 * @return the ctaDisableText
	 */
	@Override
	public String getCtaDisableText() {
		return ctaDisableText;
	}

	/**
	 * <p>
	 * Sets ctaDisableText
	 * </p>
	 *
	 * @param ctaDisableText - the ctaDisableText to set
	 */
	public void setCtaDisableText(String ctaDisableText) {
		this.ctaDisableText = ctaDisableText;
	}

	/**
	 * <p>
	 * Fetches ctaText
	 * </p>
	 *
	 * @return the ctaText
	 */
	@Override
	public String getCtaText() {
		return ctaText;
	}

	/**
	 * @param ctaText the ctaText to set
	 */
	public void setCtaText(String ctaText) {
		this.ctaText = ctaText;
	}

	/**
	 * <p>
	 * Fetches showPortinInFlow
	 * </p>
	 *
	 * @return the showPortinInFlow
	 */
	@Override
	public String getShowPortinInFlow() {
		return showPortinInFlow;
	}

	/**
	 * <p>
	 * Sets showPortinInFlow
	 * </p>
	 *
	 * @param showPortinInFlow - the showPortinInFlow to set
	 */
	public void setShowPortinInFlow(String showPortinInFlow) {
		this.showPortinInFlow = showPortinInFlow;
	}

	/**
	 * <p>
	 * Fetches anotherpaymenttext
	 * </p>
	 *
	 * @return the anotherpaymenttext
	 */
	@Override
	public String getAnotherPaymentText() {
		return anotherPaymentText;
	}

	/**
	 * <p>
	 * Fetches anotherpaymentalttext
	 * </p>
	 *
	 * @return the anotherpaymentalttext
	 */
	@Override
	public String getAnotherPaymentAltText() {
		return anotherPaymentAltText;
	}

	/**
	 * <p>
	 * Fetches anotherplantext
	 * </p>
	 *
	 * @return the anotherplantext
	 */
	@Override
	public String getAnotherPlanText() {
		return anotherPlanText;
	}

	/**
	 * <p>
	 * Fetches anotherplanalttext
	 * </p>
	 *
	 * @return the anotherplanalttext
	 */
	@Override
	public String getAnotherPlanAltText() {
		return anotherPlanAltText;
	}

	/**
	 * @return String return the veriffSuccessNLDescText
	 */
	@Override
	public String getCtaLink() {
		String ctaPath = resolver.map(ctaLink);
		if (StringUtils.isEmpty(ctaPath)) {
			ctaPath = ctaLink;
		}
		return ctaPath;
	}

	/**
	 * @param ctaLink the ctaLink to set
	 */
	public void setCtaLink(String ctaLink) {
		this.ctaLink = ctaLink;
	}

	/**
	 * @return String return the plpPagePath
	 * 
	 */
	@Override
	public String getPlpPagePath() {
		return plpPagePath;
	}

	/**
	 * @return String - apiDomain
	 */
	@Override
	public String getApiDomain() {

		return tracfoneApiService.getApiDomain();
	}

	/**
	 * @return String - UpgradeEligibilityApiPath
	 */
	@Override
	public String getUpgradeApiPath() {

		return tracfoneApiService.getUpgradeEligibilityApiPath();
	}

	/**
	 * @return String - PortInMinSetApiPath
	 */
	@Override
	public String getPortInMinSetApiPath() {

		return tracfoneApiService.getPortInMinSetApiPath();
	}

	/**
	 * @return String - PortInMinOtpValidate
	 */
	@Override
	public String getPortInMinOtpValidateApiPath() {

		return tracfoneApiService.getPortInMinOtpValidateApiPath();
	}

	/**
	 * @return String - PortInMinEligibilityApiPath
	 */
	@Override
	public String getPortInMinEligibilityApiPath() {

		return tracfoneApiService.getPortInMinEligibilityApiPath();
	}

	/**
	 * <p>
	 * This method is used to generate query string for marketing id call
	 * 
	 * @return -String : Query String
	 */
	@Override
	public String getUpgradeElgQueryString() {

		StringBuilder query = new StringBuilder(CommerceConstants.BRANDNAME).append(CommerceConstants.EQUALS_TO)
				.append(getBrand()).append(CommerceConstants.AMPERSAND)
				.append(CommerceConstants.IDENTIFIER).append(CommerceConstants.EQUALS_TO);

		LOGGER.info(" abc *** " + query.toString());
		return query.toString();
	}

	/**
	 * @return String - brand
	 */
	public String getBrand() {
		return CommerceUtil.getBrandValue(currentPage, getHomePageLevel());
	}

	/**
	 * @return int - homePageLevel
	 */
	private int getHomePageLevel() {
		return applicationConfigService.getHomePageLevel();
	}

	/**
	 * @return String - ResourceMgmtApiPath
	 */
	@Override
	public String getResourceMgmtApiPath() {

		return tracfoneApiService.getResourceMgmtApiPath();
	}

	/**
	 * @return String - ResourceMgmtApiProjection
	 */
	@Override
	public String getResourceMgmtApiProjection() {

		return tracfoneApiService.getResourceMgmtApiProjection();
	}

	/**
	 * <p>
	 * Fetches anotherPhoneNoText
	 * </p>
	 *
	 * @return the anotherPhoneNoText
	 */
	@Override
	public String getAnotherPhoneNoText() {
		return anotherPhoneNoText;
	}

	/**
	 * <p>
	 * Fetches anotherPhoneNoAltText
	 * </p>
	 *
	 * @return the anotherPhoneNoAltText
	 */
	@Override
	public String getAnotherPhoneNoAltText() {
		return anotherPhoneNoAltText;
	}

	/**
	 * <p>
	 * Fetches anotherPayOptText
	 * </p>
	 *
	 * @return the anotherPayOptText
	 */
	@Override
	public String getAnotherPayOptText() {
		return anotherPayOptText;
	}

	/**
	 * <p>
	 * Fetches anotherPayOptAltText
	 * </p>
	 *
	 * @return the anotherPayOptAltText
	 */
	@Override
	public String getAnotherPayOptAltText() {
		return anotherPayOptAltText;
	}

	/**
	 * <p>
	 * Fetches verifyCodeSubHeading2Text text/p>
	 *
	 * @return String - verifyCodeSubHeading2Text text
	 */
	@Override
	public String getVerifyCodeSubHeading2Text() {
		return verifyCodeSubHeading2Text;
	}

	/**
	 * <p>
	 * Sets verifyCodeSubHeading2Text
	 * </p>
	 *
	 * @param verifyCodeSubHeading2Text - the verifyCodeSubHeading2Text to set
	 */
	public void setVerifyCodeSubHeading2Text(String verifyCodeSubHeading2Text) {
		this.verifyCodeSubHeading2Text = verifyCodeSubHeading2Text;
	}

}
