/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl.v1;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.RecommendedProductsModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { RecommendedProductsModel.class,
        ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/recommendedproducts/v1/recommendedproducts", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })

public class RecommendedProductsModelImpl implements RecommendedProductsModel {

    @Self
    private SlingHttpServletRequest request;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String headline;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String subheadline;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String categoryIdAccessories;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String categoryIdPlans;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String carouselSpeed;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String dotNavigationLength;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String componentVersion;

    @Override
    public String getHeadline() {
        return headline;
    }

    @Override
    public String getSubheadline() {
        return subheadline;
    }

    @Override
    public String getCategoryIdAccessories() {
        return categoryIdAccessories;
    }

    @Override
    public String getCategoryIdPlans() {
        return categoryIdPlans;
    }

    @Override
    public String getCarouselSpeed() { return carouselSpeed; }

    @Override
    public String getDotNavigationLength() { return dotNavigationLength; }

    @Override
    public String getComponentVersion() {return StringUtils.isNotBlank(componentVersion) ?  componentVersion: "v1"; }

    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

}
