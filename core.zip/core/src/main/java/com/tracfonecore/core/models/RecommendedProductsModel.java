/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * Defines the {@code Multi-Links} Sling Model used for the {@code /apps/tracfone-core/components/spa/commerce/recommendedProducts} component.
 */
public interface RecommendedProductsModel extends ComponentExporter {

	/**
	 * <p>Fetches headline for RecommendedProducts Component</p>
	 * 
	 * @return String - headline for RecommendedProducts Component
	 */
	@JsonProperty("headline")
	public String getHeadline();

	/**
	 * <p>Fetches subheadline for RecommendedProducts Component</p>
	 * 
	 * @return String - subheadline for RecommendedProducts Component
	 */
	@JsonProperty("subheadline")
	public String getSubheadline();

	/**
	 * <p>Fetches categoryIdAccessories for RecommendedProducts Component</p>
	 * 
	 * @return String - categoryIdAccessories for RecommendedProducts Component
	 */
	@JsonProperty("categoryIdAccessories")
	public String getCategoryIdAccessories();
	
	/**
	 * <p>Fetches categoryIdPlans for RecommendedProducts Component</p>
	 * 
	 * @return String - categoryIdPlans for RecommendedProducts Component
	 */
	@JsonProperty("categoryIdPlans")
	public String getCategoryIdPlans();
	
	/**
	 * <p>Fetches carouselSpeed for RecommendedProducts Component</p>
	 * 
	 * @return String - carouselSpeed for RecommendedProducts Component
	 */
	@JsonProperty("carouselSpeed")
	public String getCarouselSpeed();

	/**
	 * <p>Fetches dotNavigationLength for RecommendedProducts Component</p>
	 *
	 * @return String - dotNavigationLength for RecommendedProducts Component
	 */
	@JsonProperty("dotNavigationLength")
	public String getDotNavigationLength();

	/**
	 * <p>Fetches componentVersion for RecommendedProducts Component</p>
	 *
	 * @return String - componentVersion for RecommendedProducts Component
	 */
	@JsonProperty("componentVersion")
	public String getComponentVersion();
		
}
