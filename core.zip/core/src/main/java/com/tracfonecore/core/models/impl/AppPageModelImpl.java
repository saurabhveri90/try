/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.models.AppPageModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.BazaarVoiceConfigService;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.annotation.PostConstruct;
import javax.inject.Inject;

@Model(adaptables = { Resource.class,
		SlingHttpServletRequest.class }, adapters = {
		AppPageModel.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class AppPageModelImpl implements AppPageModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(AppPageModelImpl.class);

	private String clientName;
	private String siteId;
	private String environment;
	private String locale;

	@OSGiService
	private BazaarVoiceConfigService bazaarVoiceConfigService;

	@Inject
	private ApplicationConfigService applicationConfigService;

	@Inject
	private Page currentPage;

	@PostConstruct
	private void initModel() {
		LOGGER.debug("Entering initModel method");
			if (null != bazaarVoiceConfigService) {
				String[] clientNames = bazaarVoiceConfigService.getClientName();
				String[] siteIds = bazaarVoiceConfigService.getSiteId();
				if (null != clientNames && null != siteIds){
					clientName = ConfigurationUtil.getConfigValue(clientNames,
							CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
					siteId = ConfigurationUtil.getConfigValue(siteIds,
							CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
					environment = bazaarVoiceConfigService.getEnvironment();
					locale = bazaarVoiceConfigService.getLocale();
				}
			}
		LOGGER.debug("Exiting initModel method");
	}

	/**
	 * <p>Fetches client name</p>
	 *
	 * @return String - client name
	 */
	@Override
	public String getClientName() {
		return clientName;
	}

	/**
	 * <p>Fetches site ID</p>
	 *
	 * @return String - site ID
	 */
	@Override
	public String getSiteId() {
		return siteId;
	}

	/**
	 * <p>Fetches environment</p>
	 *
	 * @return String - environment
	 */
	@Override
	public String getEnvironment() {
		return environment;
	}

	/**
	 * <p>Fetches locale</p>
	 *
	 * @return String - locale
	 */
	@Override
	public String getLocale() {
		return locale;
	}

}