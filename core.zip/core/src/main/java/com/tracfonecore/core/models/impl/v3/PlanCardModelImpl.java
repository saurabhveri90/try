package com.tracfonecore.core.models.impl.v3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.tracfonecore.core.beans.PhoneSpecsBean;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.PlanCardModel;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { PlanCardModel.class,
		ComponentExporter.class }, resourceType = {
				PlanCardModelImpl.RESOURCE_TYPE_V3 }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class PlanCardModelImpl extends com.tracfonecore.core.models.impl.v2.PlanCardModelImpl {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PlanCardModelImpl.class);
	protected static final String RESOURCE_TYPE_V3 = "tracfone-core/components/commerce/plancard/v3/plancard";
	public static final String DISNEY_PLUS = "Disney+";
	private static final String DISNEY_PLUS_REGEX = "Disney\\+";

	@Self
	private SlingHttpServletRequest request;

	@Inject
	@Optional
	private TracfoneApiGatewayService tracfoneApiGatewayService;

	@ValueMapValue
	private String ctaLink;

	@ChildResource
	List<Resource> additionalSpecs;

	private String domainName;

	private boolean useNameForSpecs;

	private List<PhoneSpecsBean> planSpecsList = Collections.emptyList();

	private List<PhoneSpecsBean> selectedSpecsList = Collections.emptyList();

	private String planName;

	private String planNameType;

	@ValueMapValue
	private String autoRefillDiscountLabel;

	@ValueMapValue
	private String showRecommendedPlan;

	@ValueMapValue
	private String vasTooltipContent;

	@ValueMapValue
	private String vasTerms;

	
	/**
	 * <p>
	 * Init method : Calls initModel() from v2.PlanCardModelImpl and then sets additional data
	 * </p>
	 */
	@PostConstruct
	protected void initModel() {
		try {
			LOGGER.debug("Entering init method of V3 PlanCardModelImpl");
			if (StringUtils.isNotEmpty(getType()) && StringUtils.equalsIgnoreCase("dynamic", getType())
					&& StringUtils.isNotEmpty(pdpPagePath)) {
				ctaLink = pdpPagePath;
				Resource planCardResource = resource.getResourceResolver()
						.getResource(pdpPagePath + CommerceConstants.MULTILINE_PLAN_DETAIL_NODE_PATH);
				if (null != planCardResource) {
					planCardModel = planCardResource
							.adaptTo(PlanCardModel.class);

				}
			} else {
				super.initModel();
				if (request != null)
					domainName = ApplicationUtil.getDomainNameinURL(request.getRequestURL().toString());

				if (null != product) {
					setProductSpecs();
				}
				if (resource != null && currentPage != null && resource.getResourceResolver() != null) {
					Resource productRes = resource.getResourceResolver()
							.resolve(currentPage.getPath() + CommerceConstants.MULTILINE_PLAN_DETAIL_ROOT_PATH);
					if (productRes != null) {
						ValueMap vm = productRes.getValueMap();
						planNameType = vm.get(CommerceConstants.MULTILINE_PLAN_NAME_TYPE, String.class);
						planName = vm.get(CommerceConstants.MULTILINE_PLAN_NAME, String.class);
					}
				}
			}
			LOGGER.debug("Exiting init method of V3 PlanCardModelImpl");
		} catch (RuntimeException re) {
			LOGGER.error("Product Offering API not available for resource", re);
		}
	}

	/**
	 * <p>
	 * setProductSpecs: gets all product specs from product api response and authored specs from the component's multifield and adds them to planSpecsList
	 * </p>
	 */
	private void setProductSpecs() {
		if (product != null && product.get(CommerceConstants.PRODUCT_CHARACTERISTICS) != null
				&& product.get(CommerceConstants.PRODUCT_CHARACTERISTICS).isJsonArray()) {
			JsonArray prodSpecsArray;
			useNameForSpecs = Arrays.asList(tracfoneApiGatewayService.getProductSpecsForBrand())
					.contains(CommerceUtil.getBrandValue(currentPage, getHomePageLevel()));

			planSpecsList = new ArrayList<PhoneSpecsBean>();
			prodSpecsArray = product.get(CommerceConstants.PRODUCT_CHARACTERISTICS).getAsJsonArray();
			if (prodSpecsArray.size() > 0) {
				for (int i = 0; i < prodSpecsArray.size(); i++) {
					JsonObject element = prodSpecsArray.get(i).getAsJsonObject();
					if (!element.get(CommerceConstants.IDENTIFIER).getAsString().isEmpty()) {
						PhoneSpecsBean phoneSpecsBean = CommerceUtil.setSpecBeanValues(element);
						phoneSpecsBean
								.setIdentifier(CommerceConstants.SPEC_PREFIX.concat(phoneSpecsBean.getIdentifier()));
						if (CommerceConstants.SPEC_PREFIX.concat(CommerceConstants.PLAN_PERK_DESCRIPTION)
								.equals(phoneSpecsBean.getIdentifier())) {
							String value = phoneSpecsBean.getValue();
							if (value.contains(DISNEY_PLUS)) {
								if (value.split(DISNEY_PLUS_REGEX).length > 1) {
									phoneSpecsBean.setDescription(value.split(DISNEY_PLUS_REGEX)[0]);
									phoneSpecsBean.setValue(value.split(DISNEY_PLUS_REGEX)[1]);
								} else {
									phoneSpecsBean.setValue(value.split(DISNEY_PLUS_REGEX)[0]);
								}
							}
						}
						planSpecsList.add(phoneSpecsBean);
					}
				}
			}
			setContentData();
		}
	}
	
	/**
	 * <p>
	 * setContentData: for specs that are selected to be shown, get the data to be shown using planSpecsList and en node values
	 * </p>
	 */
	private void setContentData() {
		String androidImageName = applicationConfigService.getProductSpecAndroidImageName();
		String appleImageName = applicationConfigService.getProductSpecAppleImageName();
		String productSpecImagePath = getProductSpecImagPath(applicationConfigService.getProductSpecImagePath());
		String compareProductSpecImagePath = getProductSpecImagPath(applicationConfigService.getCompareProductSpecImagePath());
		Map<String, String> params = new HashMap<String,String>();
		params.put(CommerceConstants.ANDROID_IMAGE_NAME, androidImageName);
		params.put(CommerceConstants.APPLE_IMAGE_NAME, appleImageName);
		params.put(CommerceConstants.PRODUCT_SPEC_IMAGE_PATH, productSpecImagePath);
		params.put(CommerceConstants.COMPARE_IMAGE_PATH, compareProductSpecImagePath);

		selectedSpecsList = CommerceUtil.setSelectedSpecBeanValues(resource, planSpecsList,
				resource.getResourceResolver(),
				params, currentPage, getHomePageLevel(), true, useNameForSpecs, additionalSpecs);
	}

	/**
	 * @return ProductSpecImagPath
	 */
	private String getProductSpecImagPath(String[] specsPath) {
		return ConfigurationUtil.getConfigValue(specsPath, CommerceUtil.getBrandValue(currentPage, getHomePageLevel()));
	}

	/**
	 * <p>
	 * Method to check plan name value
	 * </p>
	 */
	@Override
	public String getPlanNameValue() {
		String productName = StringUtils.EMPTY;
		if (planName != null)
			productName = productName.concat(planName);
		if (planNameType != null)
			productName = productName.concat(StringUtils.SPACE).concat(planNameType);

		return productName;
	}

	/**
	 * <p>
	 * Returns name from API response
	 * </p>
	 * 
	 * @return String - name
	 */
	@Override
	public String getName() {
		String productName = StringUtils.EMPTY;
		if (planNameType != null)
			productName = productName.concat(planNameType).concat(StringUtils.SPACE);
		if (planName != null)
			productName = productName.concat(planName);
		return productName;
	}

	/**
	 * <p>
	 * Returns name post converting to lower case from API response
	 * </p>
	 * 
	 * @return String - productNameForAnalytics
	 */
	@Override
	public String getProductNameForAnalytics() {
		String productNameForAnalytics = getName();
		if (productNameForAnalytics != StringUtils.EMPTY) {
			productNameForAnalytics = ApplicationUtil.getLowerCaseWithUnderScore(productNameForAnalytics);
		}
		return productNameForAnalytics;
	}

	/**
	 * <p>
	 * Fetches planSpecsList
	 * </p>
	 *
	 * @return the planSpecsList
	 */
	@Override
	public List<PhoneSpecsBean> getProductSpecs() {
		return new ArrayList<>(planSpecsList);
	}

	/**
	 * <p>
	 * Fetches selectedSpecsList
	 * </p>
	 *
	 * @return the selectedSpecsList
	 */
	@Override
	public List<PhoneSpecsBean> getSelectedProductSpecs() {
		return new ArrayList<>(selectedSpecsList);
	}

	
	/**
	 * <p>
	 * Fetches resource path
	 * </p>
	 *
	 * @return the resource path
	 */
	@Override
	public String getResourcePath() {
		return resource.getPath().toString();
	}

	/**
	 * <p>
	 * Fetches domainName
	 * </p>
	 *
	 * @return the domainName
	 */
	@Override
	public String getAuthorPath() {
		return domainName;
	}

	/**
	 * <p>
	 * Fetches useNameForSpecs
	 * </p>
	 *
	 * @return the useNameForSpecs
	 */
	@Override
	public Boolean isUseNameForSpecs() {
		return useNameForSpecs;
	}

	/**
	 * <p>
	 * Fetches billingPlanType
	 * </p>
	 *
	 * @return the billingPlanType
	 */
	@Override
	public String getBillingPlanType() {
		return billingPlanType;
	}

	/**
	 * <p>
	 * Fetches autoRefillDiscountLabel
	 * </p>
	 *
	 * @return the autoRefillDiscountLabel
	 */
	@Override
	public String getAutoRefillDiscountLabel() {
		return autoRefillDiscountLabel;
	}

	/**
	 * <p>
	 * Fetches showRecommendedPlan
	 * </p>
	 *
	 * @return the showRecommendedPlan
	 */
	@Override
	public String getShowRecommendedPlan() {
		return showRecommendedPlan;
	}

	/**
	 * Method to return ctaLink
	 * </p>
	 *
	 * @return the ctaLink
	 */
	@Override
	public String getCtaLink() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), this.ctaLink);
	}

	/**
	 * <p>
	 * Returns type
	 * </p>
	 * 
	 * @return String - getType
	 */
	@Override
	public String getType() {
		return type;
	}

	/**
	 * <p>
	 * Fetches taxInclusive
	 * </p>
	 *
	 * @return the taxInclusive
	 */
	@Override
	public String getTaxInclusive() {
		return taxInclusive;
	}

	/**
	 * <p>
	 * Fetches vasTooltipContent
	 * </p>
	 *
	 * @return the vasTooltipContent
	 */
	@Override
	public String getVasTooltipContent() {
		return vasTooltipContent;
	}

	/**
	 * <p>
	 * Fetches vasTerms
	 * </p>
	 *
	 * @return the vasTerms
	 */
	@Override
	public String getVasTerms() {
		return vasTerms;
	}

}
