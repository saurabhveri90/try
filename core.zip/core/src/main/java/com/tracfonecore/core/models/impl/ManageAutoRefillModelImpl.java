package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.settings.SlingSettingsService;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.DeEnrollmentReasonsBean;
import com.tracfonecore.core.beans.ManageLinesBean;
import com.tracfonecore.core.beans.ManageLinesNotificationsBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.ManageAutoRefillModel;
import com.tracfonecore.core.utils.ApplicationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ManageAutoRefillModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/manageautorefill", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ManageAutoRefillModelImpl implements ManageAutoRefillModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;
	
	@Inject
	private SlingSettingsService settingService;

	@Inject
	private Resource resource;


	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String manageAutoRefillTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String manageAutoRefillDescriptionText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String categoryIdPlans;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String plansPlpPagePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String titleDeEnrollmentForPlan;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String paragraphDeEnrollmentForPlan;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String refillLandingPagePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String autoRefillHomePagePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String refillPLPPagePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String phonesPLPPagePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String refillPLPPageSelector;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String refillBuyNowPLPPageSelector;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String refillStartDateSelector;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String checkoutDetailComponentVersion;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planServiceEndDateInfoModalContent;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planDetailsEditCartUrl;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String notificationCardHeading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String notificationCardSubheading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enableNotification;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enrollAutoRefillTermsAndConditionsText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String errorMessageForInactiveDevices;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String manageLinesPagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String notAllowAutoRefillDescriptionText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String alreadyARByopText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Via("dcot")
	private String dcotDeEnrollModalTitleText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Via("dcot")
	private String dcotDeEnrollModalDescriptionText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Via("dcot")
	private String dcotDeEnrollModalYesButtonLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Via("dcot")
	private String dcotDeEnrollModalNoButtonLabel;

	private String byopAlertModalMainText;
	private static final String JCR_BYOP_ALERT_PATH = "/jcr:content/root/responsivegrid/managelines";
	
	private List<ManageLinesBean> statusPendingTransactionList = Collections.emptyList();
	private List<ManageLinesNotificationsBean> notificationCards = Collections.emptyList();
	private List<DeEnrollmentReasonsBean> deEnrollmentReasons = Collections.emptyList();
	
	@PostConstruct
	private void initModel() {
		statusPendingTransactionList = new ArrayList<>();
		notificationCards= new ArrayList<>();
		deEnrollmentReasons = new ArrayList<DeEnrollmentReasonsBean>();
		if (resource != null) {
			getMultifieldResource();
		}

		//get child node for DCOT Autorefill DeEnrollment modal
		if (dcotDeEnrollModalTitleText == null || dcotDeEnrollModalTitleText.trim().length() < 1 || dcotDeEnrollModalDescriptionText == null || dcotDeEnrollModalDescriptionText.trim().length() < 1
		|| dcotDeEnrollModalYesButtonLabel == null || dcotDeEnrollModalYesButtonLabel.trim().length() < 1 || dcotDeEnrollModalNoButtonLabel == null || dcotDeEnrollModalNoButtonLabel.trim().length() < 1) {
			try {
				dcotDeEnrollModalTitleText =request.getResource().getChild("dcot").getValueMap().get("dcotDeEnrollModalTitleText").toString();
				dcotDeEnrollModalDescriptionText =request.getResource().getChild("dcot").getValueMap().get("dcotDeEnrollModalDescriptionText").toString();
				dcotDeEnrollModalYesButtonLabel =request.getResource().getChild("dcot").getValueMap().get("dcotDeEnrollModalYesButtonLabel").toString();
				dcotDeEnrollModalNoButtonLabel =request.getResource().getChild("dcot").getValueMap().get("dcotDeEnrollModalNoButtonLabel").toString();
			}catch(RuntimeException e) {
				dcotDeEnrollModalTitleText = "";
				dcotDeEnrollModalDescriptionText = "";
				dcotDeEnrollModalYesButtonLabel = "";
				dcotDeEnrollModalNoButtonLabel = "";
			}
		}
	}
	
	private void getMultifieldResource() {
		for (Resource child : resource.getChildren()) {
			Iterator<Resource> it = child.listChildren();
			if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.NOTIFICATION_CARDS.equals(child.getName())) {
				setNotificationCards(it, notificationCards);
			} else if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.STATUS_PENDING_TRANSACTION_LIST.equals(child.getName())) {
				setStatusPendingTransactionList(it, statusPendingTransactionList);
			} else if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.DEENROLLMENT_REASONS.equals(child.getName())) {
				setDeEnrollmentReasons(it);
			}
		}
	}
	
	private void setDeEnrollmentReasons(Iterator<Resource> it) {
		while (it.hasNext()) {
			Resource grandChild = it.next();
			DeEnrollmentReasonsBean deEnrollmentReasonsBean = new DeEnrollmentReasonsBean();
			deEnrollmentReasonsBean.setDeEnrollmentReason(grandChild.getValueMap().get(ApplicationConstants.DEENROLLMENT_REASON, String.class));
			deEnrollmentReasonsBean.setDeEnrollmentReasonText(grandChild.getValueMap().get(ApplicationConstants.DEENROLLMENT_REASON_TEXT, String.class));
			deEnrollmentReasons.add(deEnrollmentReasonsBean);
		}
	}
	
	private void setNotificationCards(Iterator<Resource> it,
			List<ManageLinesNotificationsBean> notificationCards) {
		while (it.hasNext()) {
			ManageLinesNotificationsBean manageLinesNotificationsBean = new ManageLinesNotificationsBean();
			Resource grandChild = it.next();
			manageLinesNotificationsBean.setNotificationCardType(
					grandChild.getValueMap().get("notificationCardType", String.class));
			manageLinesNotificationsBean.setNotificationCardHeading(
					grandChild.getValueMap().get("notificationCardHeading", String.class));
			manageLinesNotificationsBean.setNotificationCardSubheading(
					grandChild.getValueMap().get("notificationCardSubheading", String.class));
			manageLinesNotificationsBean.setActiveDeviceTutorialsSubheading(
					grandChild.getValueMap().get("activeDeviceTutorialsSubheading", String.class));
			manageLinesNotificationsBean.setNewDeviceTutorialsSubheading(
					grandChild.getValueMap().get("newDeviceTutorialsSubheading", String.class));
			manageLinesNotificationsBean.setEnableNotification(
					grandChild.getValueMap().get("enableNotification", String.class));
			notificationCards.add(manageLinesNotificationsBean);
		}
	}
	
	private void setStatusPendingTransactionList(Iterator<Resource> it,
			List<ManageLinesBean> statusPendingTransactionList) {
		while (it.hasNext()) {
			ManageLinesBean manageLinesBean = new ManageLinesBean();
			Resource grandChild = it.next();
			manageLinesBean.setTransactionStatus(
					grandChild.getValueMap().get("transactionStatus", String.class));
			manageLinesBean.setTransactionStatusValue(
					grandChild.getValueMap().get("transactionStatusValue", String.class));
			
			statusPendingTransactionList.add(manageLinesBean);
		}
	}

	private String getShortURL(String serverDomain, String url) {
		if(StringUtils.isNotBlank(url) && StringUtils.isNotBlank(serverDomain) && url.contains(serverDomain)) {
			url = url.split(serverDomain)[1];
		}
		return url;
	}
	
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
	@Override
	public String getCategoryIdPlans() {
		return categoryIdPlans;
	}

	@Override
	public List<ManageLinesBean> getStatusPendingTransactionList() {
		return new ArrayList<>(statusPendingTransactionList);
	}

	@Override
	public String getPlansPlpPagePath() {
		return getFinalPagePath(plansPlpPagePath);
	}

	@Override
	public String getTitleDeEnrollmentForPlan() {
		return titleDeEnrollmentForPlan;
	}

	@Override
	public String getParagraphDeEnrollmentForPlan() {
		return paragraphDeEnrollmentForPlan;
	}

	@Override
	public List<ManageLinesNotificationsBean> getNotificationCards() {
		return new ArrayList<>(notificationCards);
	}
	
	@Override
	public String getAutoRefillHomePagePath() {
		return getFinalPagePath(autoRefillHomePagePath);
	}

	@Override
	public String getPlanDetailsEditCartUrl() {
		return planDetailsEditCartUrl;
	}

	@Override
	public String getRefillLandingPagePath() {
		return getFinalPagePath(refillLandingPagePath);
	}

	@Override
	public String getRefillPLPPagePath() {
		return getFinalPagePathWithoutExtension(refillPLPPagePath);
	}

	@Override
	public String getPhonesPLPPagePath() {
		return getFinalPagePath(phonesPLPPagePath);
	}
	
	public String getFinalPagePath(String inputPath) {
		String finalPagePath = inputPath;
		if (StringUtils.isNotBlank(finalPagePath) &&  Boolean.TRUE.equals(ApplicationUtil.isInternalLink(finalPagePath))) {
			if (finalPagePath.indexOf(ApplicationConstants.HTML_EXTENSION) == -1) {
				finalPagePath = finalPagePath + ApplicationConstants.HTML_EXTENSION;
			}
			if (StringUtils.isNotBlank(finalPagePath)) {
				String ctaPath = request.getResourceResolver().map(finalPagePath);
				if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
					finalPagePath = ApplicationUtil
							.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
				}
			}
		}
		return finalPagePath;
	}

	public String getFinalPagePathWithoutExtension(String inputPath) {
		String finalPagePath = inputPath;
		if (StringUtils.isNotBlank(finalPagePath)) {
			String ctaPath = request.getResourceResolver().map(finalPagePath);
			if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
				finalPagePath = ApplicationUtil
						.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
			}
		}
		return finalPagePath;
	}

	@Override
	public String getRefillPLPPageSelector() {
		return refillPLPPageSelector;
	}

	@Override
	public String getRefillStartDateSelector() {
		return refillStartDateSelector;
	}
	
	@Override
	public String getRefillBuyNowPLPPageSelector() {
		return refillBuyNowPLPPageSelector;
	}

	@Override
	public String getCheckoutDetailComponentVersion() {
		return StringUtils.isNotBlank(checkoutDetailComponentVersion)?checkoutDetailComponentVersion: "v3";
	}

	@Override
	public String getPlanServiceEndDateInfoModalContent() {
		return planServiceEndDateInfoModalContent;
		
	}

	@Override
	public String getManageAutoRefillTitle() {
		return manageAutoRefillTitle;
	}

	@Override
	public String getManageAutoRefillDescriptionText() {
		return manageAutoRefillDescriptionText;
	}

	@Override
	public List<DeEnrollmentReasonsBean> getDeEnrollmentReasons() {
		return new ArrayList<DeEnrollmentReasonsBean>(deEnrollmentReasons);
	}
	
	@Override
	public String getNotificationCardHeading() {
		return notificationCardHeading;
	}

	@Override
	public String getNotificationCardSubheading() {
		return notificationCardSubheading;
	}

	@Override
	public String getEnableNotification() {
		return enableNotification;
	}

	@Override
	public String getEnrollAutoRefillTermsAndConditionsText() {
		return enrollAutoRefillTermsAndConditionsText;
	}

	@Override
	public String getErrorMessageForInactiveDevices() {
		return errorMessageForInactiveDevices;
	}

	@Override
	public String getNotAllowAutoRefillDescriptionText(){
		return notAllowAutoRefillDescriptionText;
	}

	@Override
	public String getAlreadyARByopText(){
		return alreadyARByopText;
	}

	@Override
	public String getDcotDeEnrollModalTitleText() {
		return dcotDeEnrollModalTitleText;
	}

	@Override
	public String getDcotDeEnrollModalDescriptionText() {
		return dcotDeEnrollModalDescriptionText;
	}

	@Override
	public String getDcotDeEnrollModalYesButtonLabel() {
		return dcotDeEnrollModalYesButtonLabel;
	}

	@Override
	public String getDcotDeEnrollModalNoButtonLabel() {
		return dcotDeEnrollModalNoButtonLabel;
	}
}
