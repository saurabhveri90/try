/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl;


import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.RecommProductModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.ProductOfferingApiService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.utils.CommerceUtil;


@Model(adaptables = {SlingHttpServletRequest.class, Resource.class}, adapters = {RecommProductModel.class,
        ComponentExporter.class}, resourceType = RecommProductModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true")})
public class RecommProductModelImpl extends BaseComponentModelImpl implements RecommProductModel {

    protected static final String RESOURCE_TYPE = "tracfone-core/components/commerce/recommendedplan";

    @Self
    private SlingHttpServletRequest request;

    private ResourceResolver resolver;

    @Inject
    private Resource resource;

    @Inject
    private Page currentPage;

    @Inject
    private ApplicationConfigService applicationConfigService;

    @Inject
    private TracfoneApiGatewayService tracfoneApiService;
    
	@Inject
	private ProductOfferingApiService productOfferingApiService;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String pagePath;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String partNo;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String planName;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String priceDescription;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String planDataDescription;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String priceSuperScript;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String promoText;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String planDataLabel;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String priceAccessibilityLabel;

    private String planData;
    private String planTalkMinutes;
    private String skuId;

    private JsonObject product = null;

    private static final Logger LOGGER = LoggerFactory.getLogger(RecommProductModelImpl.class);

    @PostConstruct
    protected void initModel() {
		LOGGER.debug("Entering init method of RecommProductModelImpl");
    	super.initModel();
        StringBuilder sb = new StringBuilder();

        resolver = resource.getResourceResolver();
        LOGGER.debug("Page Path {} ", pagePath);

        if (pagePath != null && !pagePath.equals("")) {
            resource = resolver.getResource(pagePath);
            partNo = getPartNoFromPageProp();
            sb.append(pagePath);
            if (pagePath.indexOf(CommerceConstants.JCR_CONTENT) == -1) {
                sb.append(CommerceConstants.JCR_CONTENT);
            }

            sb.append(CommerceConstants.PRODUCT_NODE_PATH);
            pagePath = sb.toString();
            readPlanDetailsPageValues(pagePath);
            if (product != null) {
                getProductCharacteristics();
            }
        }

		LOGGER.debug("Exiting init method of RecommProductModelImpl");
    }

    private void readPlanDetailsPageValues(String pagePath) {
        resource = resource.getResourceResolver().getResource(pagePath);
        if (resource != null) {
            LOGGER.debug("Resource not null" + resource.getPath());
            Node currentNode = resource.adaptTo(Node.class);
            NodeIterator ni;
            try {
                ni = currentNode.getNodes();
                while (ni.hasNext()) {
                    Node grandChild = (Node) ni.nextNode();
                    LOGGER.debug("Inside iterator {} ", grandChild.getPath());
                    setPageValues(grandChild);
                }
                getPlanDetailsFromCIF(partNo);
            } catch (RepositoryException e) {
                LOGGER.error("RepositoryException in reading node values of Plan detail page {}", e);
            }

        }
    }
private void setPageValues(Node grandChild) {
    try {
        if ((grandChild.hasProperty(CommerceConstants.PLAN_NAME))) {
            planName = grandChild.getProperty(CommerceConstants.PLAN_NAME).getString();
        }
        if ((grandChild.hasProperty(CommerceConstants.PRICE_DESCRIPTION))) {
            priceDescription = grandChild.getProperty(CommerceConstants.PRICE_DESCRIPTION).getString();
        }
        if ((grandChild.hasProperty(CommerceConstants.PLAN_DATA_DESCRIPTION))) {
            planDataDescription = grandChild.getProperty(CommerceConstants.PLAN_DATA_DESCRIPTION).getString();
        }
        if ((grandChild.hasProperty(CommerceConstants.PRICE_SUPER_SCRIPT))) {
            priceSuperScript = grandChild.getProperty(CommerceConstants.PRICE_SUPER_SCRIPT).getString();
        }
        if ((grandChild.hasProperty(CommerceConstants.PLAN_PROMO_TEXT))) {
            promoText = grandChild.getProperty(CommerceConstants.PLAN_PROMO_TEXT).getString();
        }
        if ((grandChild.hasProperty(CommerceConstants.PLAN_DATA_LABEL))) {
            planDataLabel = grandChild.getProperty(CommerceConstants.PLAN_DATA_LABEL).getString();
        }
        if ((grandChild.hasProperty(CommerceConstants.PRICE_ACCESSIBILITY_LABEL))) {
            priceAccessibilityLabel = grandChild.getProperty(CommerceConstants.PRICE_ACCESSIBILITY_LABEL).getString();
        }
    } catch (RepositoryException e) {
        LOGGER.error("Exception in reading node values of Plan detail page - setPageValues.RecoomProductModel {}", e);
    }
}

    private String getPartNoFromPageProp() {
        LOGGER.debug("Entering RecommProductModelImpl.getPartNoFromPageProp");

        String partNumber = "";
        PageManager pm = null;
        Page containingPage = null;
        ValueMap pageProperties;

        pm = resolver.adaptTo(PageManager.class);
        containingPage = pm.getContainingPage(resource);

        pageProperties = containingPage.getProperties();

        if (pageProperties != null) {
            partNumber = pageProperties.get(CommerceConstants.PART_NO, String.class);
            LOGGER.debug(" Part No. value {} ", partNumber);
        }

        LOGGER.debug("Exiting RecommProductModelImpl.getPartNoFromPageProp");
        return partNumber;

    }

    private void getPlanDetailsFromCIF(String partNo) {
        String currentDateTime;
        String selection = partNo;
		
        LOGGER.debug("Part No in getPlanDetailsFromCIF() of RecommProductModelImpl: {}", selection);
		currentDateTime = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SS")
				.format(Calendar.getInstance().getTime());
		LOGGER.debug("Product Offering API call starts, time: {}", currentDateTime);

		this.product = productOfferingApiService.getProductDetailObject(selection, currentPage);
	
		currentDateTime = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SS")
				.format(Calendar.getInstance().getTime());
		LOGGER.debug("Product Offering API call ends, time: {}", currentDateTime);

		getProductCharacteristics();
		getSKUDetails();
		LOGGER.debug("Query response in getPlanDetailsFromCIF() of RecommProductModelImpl {}", product);
    }


    /**
     * @return productCharacteristics
     */
    private JsonArray getProductCharacteristics() {
    	if (product != null && product.get(CommerceConstants.PRODUCT_CHARACTERISTICS) != null && product.get(CommerceConstants.PRODUCT_CHARACTERISTICS).isJsonArray()) {
    		JsonArray jsonArray = product.get(CommerceConstants.PRODUCT_CHARACTERISTICS).getAsJsonArray();
    		if (jsonArray.size() > 0) {
    			for (int i = 0; i < jsonArray.size(); i++) {
    				String key = jsonArray.get(i).getAsJsonObject().get(CommerceConstants.NAME).getAsString();
    				if (key.equalsIgnoreCase(CommerceConstants.PLAN_DATA)) {
    					
    					planData = jsonArray.get(i).getAsJsonObject().get(CommerceConstants.VALUE).getAsString();
    				} else if (key.equalsIgnoreCase(CommerceConstants.PLAN_TALK_MINUTES)) {
    					
    					planTalkMinutes = jsonArray.get(i).getAsJsonObject().get(CommerceConstants.VALUE).getAsString();
    				}
    			}
    		}
    		return jsonArray;
    	}
    	return null;
    }

    private void getSKUDetails(){
    	if(product != null && product.get(CommerceConstants.SKUS) != null && product.get(CommerceConstants.SKUS).isJsonArray()) {
    		JsonArray skusArray;
    		skusArray = product.get(CommerceConstants.SKUS).getAsJsonArray();
    		if (skusArray.size() > 0) {
    			JsonObject element = skusArray.get(0).getAsJsonObject();
    			skuId = element.get(CommerceConstants.ID).getAsString();
    		}
    	}
    }

    /**
     * @return ratings
     */
    @Override
    public String getRating() {

        String rating = "0.0";

        if (product != null && StringUtils.isNotBlank(product.get(CommerceConstants.RATINGS).getAsString())) {
            rating = product.get(CommerceConstants.RATINGS).getAsString();
            LOGGER.debug("Plan ratings value {}", rating);
        }
        return rating;
    }

    /**
     * @return reviews
     */
    @Override
    public String getReviews() {
        String reviews = "0";

        if (product != null && StringUtils.isNotBlank(product.get(CommerceConstants.REVIEWS).getAsString())) {
            reviews = product.get(CommerceConstants.REVIEWS).getAsString();
            LOGGER.debug("Plan reviews value {}", reviews);
        }
        return reviews;
    }

    /**
     * <p>Format rating and remove trailing zeros </p>
     *
     * @return String - rating without trailing zero
     */
    @Override
    public String getAccessibilityRating() {
        DecimalFormat format = new DecimalFormat(ApplicationConstants.TRAILING_ZERO);
        String accessibilityRating = getRating();
        if (StringUtils.isNotBlank(accessibilityRating)) {
            double ratingval = Double.parseDouble(getRating());
            accessibilityRating = format.format(ratingval);
        }
        return accessibilityRating;
    }

    /**
     * <p>
     * Returns apiDomain from configuration
     * </p>
     *
     * @return String - apiDomain
     */
    public String getApiDomain() {

        return tracfoneApiService.getApiDomain();
    }

    /**
     * <p>
     * Returns priceApiPath from configuration
     * </p>
     *
     * @return String - priceApiPath
     */
    public String getPriceApiPath() {

        return tracfoneApiService.getPriceApiPath();
    }

    /**
     * @return String - queryString String is used for price API call
     */
    @Override
    public String getQueryString() {
        String query = CommerceConstants.BRAND + CommerceConstants.EQUALS_TO +
                CommerceUtil.getBrandValue(currentPage, getHomePageLevel()) + CommerceConstants.AMPERSAND +
                CommerceConstants.PRODUCT_ID + CommerceConstants.EQUALS_TO + this.getId() +
                CommerceConstants.AMPERSAND + CommerceConstants.LANGUAGE +
                CommerceConstants.EQUALS_TO + getLanguage();
        return query;
    }

    /**
     * <p>
     * Returns id from API response
     * </p>
     *
     * @return Integer - id from api response
     */
    public Integer getId() {
        if (product != null && product.get(CommerceConstants.ID)!=null) {
        	return product.get(CommerceConstants.ID).getAsInt();
        }
        return null;
    }

    /**
     * <p>
     * Method to return skuid
     * </p>
     *
     * @return String skuid
     */
    public String getSkuId() {
        return skuId;
    }

    @Override
    public String getPagePath() {
        return pagePath;
    }

    @Override
    public String getPlanName() {
        return planName;
    }

    @Override
    public String getPriceDescription() {
        return priceDescription;
    }

	@Override
    public String getPlanDataDescription() {
        return planDataDescription;
    }

	@Override
    public String getPriceSuperScript() {
        return priceSuperScript;
    }

	@Override
    public String getPromoText() {
        return promoText;
    }

	@Override
    public String getPlanDataLabel() {
        return planDataLabel;
    }

    @Override
    public String getPriceAccessibilityLabel(){
        return priceAccessibilityLabel;
    }

	@Override
    public String getPlanData() {
        return planData;
    }

	@Override
    public String getPlanTalkMinutes() {
        return planTalkMinutes;
    }

    /**
     * <p>
     * Returns home page level from configuration
     * </p>
     *
     * @return int - homepagelevel
     */
    private int getHomePageLevel() {

        return applicationConfigService.getHomePageLevel();
    }

    /**
     * <p>
     * Returns language from util
     * </p>
     *
     * @return String - language
     */
    public String getLanguage() {

        return CommerceUtil.getLanguage(currentPage, getHomePageLevel());
    }

    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

    /**
	 * @return the enableButtonForProductCards
	 */
	@Override
	public String getEnableButtonForProductCards() {
		return (String) CommerceUtil.getPropertiesFromRootPage(currentPage,CommerceConstants.ENABLE_BUTTON_FOR_CAROUSEL_PRODUCT_CARD);
	}

}