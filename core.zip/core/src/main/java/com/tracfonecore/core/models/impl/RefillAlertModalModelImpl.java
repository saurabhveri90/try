/*
 *  Copyright 2024 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl;

import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.RefillAlertModalModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import org.apache.sling.settings.SlingSettingsService;

@Model(adaptables = { SlingHttpServletRequest.class}, adapters = { RefillAlertModalModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/refillalertmodal", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class RefillAlertModalModelImpl implements RefillAlertModalModel {

	@Self
	private SlingHttpServletRequest request;
	
	@ValueMapValue
	private String titleModal;

	@ValueMapValue
	private String mainTextModal;

	@ValueMapValue
	private String buttonCancelText;

	@ValueMapValue
	private String buttonAcceptText;

	@ValueMapValue
	private String titleModalGuest;

	@ValueMapValue
	private String mainTextModalGuest;

	@ValueMapValue
	private String buttonCancelTextGuest;

	@ValueMapValue
	private String buttonAcceptTextGuest;
	
	@Override
	public String getTitleModal() {
		return titleModal;
	}

	@Override
	public String getMainTextModal() {
		return mainTextModal;
	}

	@Override
	public String getButtonCancelText() {
		return buttonCancelText;
	}

	@Override
	public String getButtonAcceptText() {
		return buttonAcceptText;
	}

	@Override
	public String getTitleModalGuest() {
		return titleModalGuest;
	}

	@Override
	public String getMainTextModalGuest() {
		return mainTextModalGuest;
	}

	@Override
	public String getButtonCancelTextGuest() {
		return buttonCancelTextGuest;
	}

	@Override
	public String getButtonAcceptTextGuest() {
		return buttonAcceptTextGuest;
	}
	
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
}