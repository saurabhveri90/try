package com.tracfonecore.core.beans;

/**
 * @author saurabh_kumar1
 *
 */
public class PurchaseScenarioBean {

	private String purchaseScenario;
	private String whatsNextHeadlineForSelectedScenario;
	private String whatsNextSubheadlineForSelectedScenario;
	private String activationTipsHeadlineForSelectedScenario;
	private String activationTipsSubheadlineForSelectedScenario;
	private String activationTipsProductLogoForSelectedScenario;
	private String activationTipsProductLogoAltTextForSelectedScenario;

	private String stpurchaseScenario;
	private String stwhatsNextHeadlineForSelectedScenario;
	private String stwhatsNextSubheadlineForSelectedScenario;
	private String stactivationTipsHeadlineForSelectedScenario;
	private String stactivationTipsSubheadlineForSelectedScenario;
	private String stactivationTipsProductLogoForSelectedScenario;
	private String stactivationTipsProductLogoAltTextForSelectedScenario;



	public String getPurchaseScenario() {
		return purchaseScenario;
	}

	public void setPurchaseScenario(String purchaseScenario) {
		this.purchaseScenario = purchaseScenario;
	}

	public String getWhatsNextHeadlineForSelectedScenario() {
		return whatsNextHeadlineForSelectedScenario;
	}

	public void setWhatsNextHeadlineForSelectedScenario(String whatsNextHeadlineForSelectedScenario) {
		this.whatsNextHeadlineForSelectedScenario = whatsNextHeadlineForSelectedScenario;
	}

	public String getWhatsNextSubheadlineForSelectedScenario() {
		return whatsNextSubheadlineForSelectedScenario;
	}

	public void setWhatsNextSubheadlineForSelectedScenario(String whatsNextSubheadlineForSelectedScenario) {
		this.whatsNextSubheadlineForSelectedScenario = whatsNextSubheadlineForSelectedScenario;
	}

	public String getActivationTipsHeadlineForSelectedScenario() {
		return activationTipsHeadlineForSelectedScenario;
	}

	public void setActivationTipsHeadlineForSelectedScenario(String activationTipsHeadlineForSelectedScenario) {
		this.activationTipsHeadlineForSelectedScenario = activationTipsHeadlineForSelectedScenario;
	}

	public String getActivationTipsSubheadlineForSelectedScenario() {
		return activationTipsSubheadlineForSelectedScenario;
	}

	public void setActivationTipsSubheadlineForSelectedScenario(String activationTipsSubheadlineForSelectedScenario) {
		this.activationTipsSubheadlineForSelectedScenario = activationTipsSubheadlineForSelectedScenario;
	}

	public String getActivationTipsProductLogoForSelectedScenario() {
		return activationTipsProductLogoForSelectedScenario;
	}

	public void setActivationTipsProductLogoForSelectedScenario(String activationTipsProductLogoForSelectedScenario) {
		this.activationTipsProductLogoForSelectedScenario = activationTipsProductLogoForSelectedScenario;
	}

	public String getActivationTipsProductLogoAltTextForSelectedScenario() {
		return activationTipsProductLogoAltTextForSelectedScenario;
	}

	public void setActivationTipsProductLogoAltTextForSelectedScenario(
			String activationTipsProductLogoAltTextForSelectedScenario) {
		this.activationTipsProductLogoAltTextForSelectedScenario = activationTipsProductLogoAltTextForSelectedScenario;
	}


	public String getSTPurchaseScenario() {
		return stpurchaseScenario;
	}

	public void setSTPurchaseScenario(String stpurchaseScenario) {
		this.stpurchaseScenario = stpurchaseScenario;
	}

	public String getSTWhatsNextHeadlineForSelectedScenario() {
		return stwhatsNextHeadlineForSelectedScenario;
	}

	public void setSTWhatsNextHeadlineForSelectedScenario(String stwhatsNextHeadlineForSelectedScenario) {
		this.stwhatsNextHeadlineForSelectedScenario = stwhatsNextHeadlineForSelectedScenario;
	}

	public String getSTWhatsNextSubheadlineForSelectedScenario() {
		return stwhatsNextSubheadlineForSelectedScenario;
	}

	public void setSTWhatsNextSubheadlineForSelectedScenario(String stwhatsNextSubheadlineForSelectedScenario) {
		this.stwhatsNextSubheadlineForSelectedScenario = stwhatsNextSubheadlineForSelectedScenario;
	}

	public String getSTActivationTipsHeadlineForSelectedScenario() {
		return stactivationTipsHeadlineForSelectedScenario;
	}

	public void setSTActivationTipsHeadlineForSelectedScenario(String stactivationTipsHeadlineForSelectedScenario) {
		this.stactivationTipsHeadlineForSelectedScenario = stactivationTipsHeadlineForSelectedScenario;
	}

	public String getSTActivationTipsSubheadlineForSelectedScenario() {
		return stactivationTipsSubheadlineForSelectedScenario;
	}

	public void setSTActivationTipsSubheadlineForSelectedScenario(String stactivationTipsSubheadlineForSelectedScenario) {
		this.stactivationTipsSubheadlineForSelectedScenario = stactivationTipsSubheadlineForSelectedScenario;
	}

	public String getSTActivationTipsProductLogoForSelectedScenario() {
		return stactivationTipsProductLogoForSelectedScenario;
	}

	public void setSTActivationTipsProductLogoForSelectedScenario(String stactivationTipsProductLogoForSelectedScenario) {
		this.stactivationTipsProductLogoForSelectedScenario = stactivationTipsProductLogoForSelectedScenario;
	}

	public String getSTActivationTipsProductLogoAltTextForSelectedScenario() {
		return stactivationTipsProductLogoAltTextForSelectedScenario;
	}

	public void setSTActivationTipsProductLogoAltTextForSelectedScenario(
			String stactivationTipsProductLogoAltTextForSelectedScenario) {
		this.stactivationTipsProductLogoAltTextForSelectedScenario = stactivationTipsProductLogoAltTextForSelectedScenario;
	}

}
