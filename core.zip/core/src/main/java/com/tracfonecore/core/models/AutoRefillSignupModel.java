/*
 *  Copyright 2021 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;


import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code New Line} Sling Model used for the {@code /apps/tracfone-core/components/commerce/autorefillsignup} component.
 */
public interface AutoRefillSignupModel extends ComponentExporter {

	
	/**
	 * <p>Fetches title for Auto Refill Signup</p>
	 * 
	 * @return String - title for Auto Refill Signup
	 */
	@JsonProperty("title")
	public String getTitle();

	/**
	 * <p>Fetches description for Auto Refill Signup</p>
	 *
	 * @return String - description for Auto Refill Signup
	 */
	@JsonProperty("description")
	public String getDescription();
	
	/**
	 * <p>Fetches currentplanicon for Auto Refill Signup</p>
	 * 
	 * @return String - currentplanicon for Auto Refill Signup
	 */
	@JsonProperty("currentplanicon")
	public String getCurrentPlanIcon();

	/**
	 * <p>Fetches currentplanheading for Auto Refill Signup</p>
	 *
	 * @return String - currentplanheading for Auto Refill Signup
	 */
	@JsonProperty("currentplanheading")
	public String getCurrentPlanHeading();
	
	/**
	 * <p>Fetches currentplandesc for Auto Refill Signup</p>
	 *
	 * @return String - currentplandesc for Auto Refill Signup
	 */
	@JsonProperty("currentplandesc")
	public String getCurrentPlanDesc();
	
	/**
	 * <p>Fetches CTA text of Modal Link/p>
	 * 
	 * @return String - CTA text of Modal Link
	 */
	@JsonProperty("infoCtaText")
	public String getInfoCtaText();
	
	/**
	 * <p>Fetches CTA Alt-text of Modal Link</p>
	 * 
	 * @return String - CTA Alt-text of Modal Link
	 */
	@JsonProperty("infoCtaAltText")
	public String getInfoCtaAltText();
	
	/**
	 * <p>Fetches Modal ID</p>
	 * 
	 * @return String - Modal ID
	 */
	@JsonProperty("infoCtaModalId")
	public String getInfoCtaModalId();
	
	/**
	 * <p>Fetches diffplanicon for Auto Refill Signup</p>
	 * 
	 * @return String - diffplanicon for Auto Refill Signup
	 */
	@JsonProperty("diffplanicon")
	public String getDiffPlanIcon();

	/**
	 * <p>Fetches diffplanheading for Auto Refill Signup</p>
	 *
	 * @return String - diffplanheading for Auto Refill Signup
	 */
	@JsonProperty("diffplanheading")
	public String getDiffPlanHeading();
	
	/**
	 * <p>Fetches diffplandesc for Auto Refill Signup</p>
	 *
	 * @return String - diffplandesc for Auto Refill Signup
	 */
	@JsonProperty("diffplandesc")
	public String getDiffPlanDesc();
	
	/**
	 * <p>Fetches loginButtonLabel for Auto Refill Signup</p>
	 *
	 * @return String - loginButtonLabel for Auto Refill Signup
	 */
	@JsonProperty("loginButtonLabel")
	public String getLoginButtonLabel();
	
	/**
	 * <p>
	 * Returns language from util
	 * </p>
	 * 
	 * @return String - language
	 */
	String getLanguage();
	
	/**
	  *  <p>Returns categoryid from the configured Plans category page.</p>
	  *  
	   * @return String - categoryID
	  */
	String getCategoryID();

	/**
	  *  <p>Returns plan pdp json servlet path</p>
	  *  
	   * @return String - planPDPServletPath
	  */
	String getPlanPDPServletPath();		
	
	/**
	 * @return purchasePagePath
	 */
	@JsonProperty("purchasePagePath")
	public String getPurchasePagePath();
	
	/**
	 * @return planThumbImgPath
	 */
	@JsonProperty("planThumbImgPath")
	public String getPlanThumbImgPath();
	
	/**
	 * <p>Fetches refillPlanTypeFacet</p>
	 *
	 * @return String - refill Plan Type Facet
	 */
	@JsonProperty("refillPlanTypeFacet")
	public String getRefillPlanTypeFacet();
	
	/**
	 * <p>
	 * Fetches ReCaptcha SiteKey property from config
	 * </p>
	 *
	 * @return String[] - reCaptchaSiteKey
	 */
	public String getReCaptchaSiteKey();
		
	/**
	 * <p>Fetches flag value to include right side panel</p>
	 *
	 * @return String - includeRightSidePanel
	 */
	@JsonProperty("includeRightSidePanel")
	default String getIncludeRightSidePanel() {
		return null;
	}

}
