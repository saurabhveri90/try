/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.TestimonialBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.TestimonialModel;
import com.tracfonecore.core.services.DynamicMediaConfigService;
import com.tracfonecore.core.utils.DynamicMediaUtils;


@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { TestimonialModel.class,ComponentExporter.class },
		resourceType = "tracfone-core/components/content/testimonial", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR,
		extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class TestimonialModelImpl implements TestimonialModel {

	@ScriptVariable
	private ValueMap properties;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String title;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subTitle;

	private List<TestimonialBean> multiTestimonial = Collections.emptyList();
	@Inject
	private DynamicMediaConfigService dynamicMediaConfig;
	private static final Logger LOGGER = LoggerFactory.getLogger(TestimonialModelImpl.class);

	// constants
	private static final String MULTI_TESTIMONIAL = "multiTestimonial";
	private static final String IMAGE = "image";
	private static final String ALT_TEXT = "altText";
	private static final String FEEDBACK = "feedback";
	private static final String NAME = "name";
	private static final String LOCATION = "location";

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private Resource resource;

	@PostConstruct
	private void initModel() {
		try {
			multiTestimonial = new ArrayList<TestimonialBean>();
			Node currentNode = resource.adaptTo(Node.class);
			Node child = currentNode.getNode(MULTI_TESTIMONIAL);
			NodeIterator ni = child.getNodes();
			setMultiTestimonialItems(ni, multiTestimonial);
		} catch (RepositoryException re) {
			LOGGER.error("Repository Exception occurred while fetching multi testimonial details {}", re);
		}
	}

	/**
	 * <p>Populates a list with all the multi-testimonial</p>
	 *
	 * @param ni - iterator of the parent node
	 * @param multiTestimonialData - list in which the multi testimonial data needs to be set
	 */
	private void setMultiTestimonialItems(NodeIterator ni, List<TestimonialBean> multiTestimonialData) {

		try {
			float count = ApplicationConstants.INTEGER_ONE;
			while (ni.hasNext()) {
				TestimonialBean testimonialBean = new TestimonialBean();
				Node grandChild = (Node) ni.nextNode();

				if ((grandChild.hasProperty(IMAGE))) {
					testimonialBean.setImage(DynamicMediaUtils.changeMediaPathToDMPath(grandChild.getProperty(IMAGE).getString(), request.getResourceResolver()));
				}

				if ((grandChild.hasProperty(ALT_TEXT))) {
					testimonialBean.setAltText(grandChild.getProperty(ALT_TEXT).getString());
				}

				if ((grandChild.hasProperty(FEEDBACK))) {
					testimonialBean.setFeedback(grandChild.getProperty(FEEDBACK).getString());
				}

				if ((grandChild.hasProperty(NAME))) {
					testimonialBean.setName(grandChild.getProperty(NAME).getString());
				}

				if ((grandChild.hasProperty(LOCATION))) {
					testimonialBean.setLocation(grandChild.getProperty(LOCATION).getString());
				}
				testimonialBean.setDelay((ApplicationConstants.INTEGER_THREE * count)/ApplicationConstants.INTEGER_TEN );
				multiTestimonialData.add(testimonialBean);
				count++;
			}
		} catch (RepositoryException re) {
			LOGGER.error("Repository Exception occurred while fetching multi testimonial details {}", re);
		}
	}


	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public String getSubTitle() {
		return subTitle;
	}

	@Override
	public List<TestimonialBean> getMultiTestimonial() {
		return new ArrayList<>(multiTestimonial);
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
	@Override
	public String getBreakPoints() {
		return dynamicMediaConfig.getBreakPoint();
	}
}