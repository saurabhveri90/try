package com.tracfonecore.core.models;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables=SlingHttpServletRequest.class)
public class ImageUtilModel {

    @Inject
    @Optional
    private String assetPath;

    @Inject
	protected Resource resource;

    /**
	 * <p>
	 * Returns the JCR UUID for the given assetPath
	 * </p>
	 * 
	 * @return String - assetPath
	 */
    public String getAssetUUID() {  
        if(StringUtils.isNotBlank(assetPath) && resource !=null) {
            return ApplicationUtil.getAssetId(assetPath,resource.getResourceResolver(), ApplicationConstants.IMAGE);
        }
        return StringUtils.EMPTY;
    }

    /**
	 * <p>
	 * Returns the dynamic media Image path for the given assetPath
	 * </p>
	 * 
	 * @return String - assetPath
	 */
	public String getAssetDMPath() {
        if(StringUtils.isNotBlank(assetPath) && resource !=null) {
            return DynamicMediaUtils.changeMediaPathToDMPath(assetPath, resource.getResourceResolver());
        }
        return StringUtils.EMPTY;
	}
    
}
