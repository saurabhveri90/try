package com.tracfonecore.core.models;

import org.apache.sling.api.resource.Resource;
import org.osgi.annotation.versioning.ProviderType;
import com.adobe.cq.export.json.ComponentExporter;

/**
 * 
 * @author HCL
 * Defines the {@code Device Identification} Sling Model used for the {@code /apps/tracfone-core/components/commerce/deviceIdentification} component.
 *
 */

@ProviderType
public interface DeviceIdentificationModel extends ComponentExporter {
    
    /**
     * Get the device Type
     * @return String - deviceType
     */
    public String getDeviceType();  
 
    /**
     * Get the headerText
     * @return String - headerText
     */
    public String getHeaderText();  
    
    /**
     * Get the summary
     * @return String - summary
     */
    public String getSummary();  
    
    /**
     * Get the helpLinkLabel
     * @return String - helpLinkLabel
     */
    public String getHelpLinkLabel();  
    
    /**
     * Get the helpLinkType
     * @return String - helpLinkType
     */
    public String getHelpLinkType();
    
    /**
     * Get the helpLinkModalId
     * @return String - helpLinkModalId
     */
    public String getHelpLinkModalId();

    /**
     * Get the helpLinkAccessibility
     * @return String - helpLinkAccessibility
     */
    public String getHelpLinkAccessibility();  

    /**
     * Get the deviceImage
     * @return String - deviceImage
     */
    public String getDeviceImage();  
    
    /**
     * Get the imageAltText
     * @return String - imageAltText
     */
    public String getImageAltText();  
    
    /**
     * Get the scanTextLabel
     * @return String - scanTextLabel
     */
    public String getScanTextLabel(); 
    
    /**
     * Get the inputFieldLabel
     * @return String - inputFieldLabel
     */
    
    public String getInputFieldLabel();  
    
    /**
     * Get the input Field Placeholder
     * @return String - inputFieldPlaceholder
     */
    public String getInputFieldPlaceholder();  
    
    /**
     * Get the privacyPolicyInfo
     *
     * @return String - privacyPolicyInfo
     */
    public String getPrivacyPolicyInfo();

    /**
     * Get the tncText
     * @return String - tncText
     */
    public String getTncText();  
    
    /**
     * Get the button Label
     * @return String - buttonLabel
     */
    public String getButtonLabel();  
	
	 /**
     * Get the helpLinkIMEIModalId
     * @return String - helpLinkIMEIModalId
     */
    public String getHelpLinkIMEIModalId();

    /**
     * Get the second button Label
     * @return String - secondButtonLabel
     */
    public String getSecondButtonLabel();  
    
}
