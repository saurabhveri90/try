/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;


import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * Defines the {@code New Line} Sling Model used for the {@code /apps/tracfone-core/components/commerce/deviceTypeCard} component.
 */
public interface DeviceTypeCardModel extends ComponentExporter {

	
	/**
	 * <p>Fetches title for Device Type Card</p>
	 * 
	 * @return String - title for Device Type Card
	 */
	@JsonProperty("title")
	public String getTitle();
	
	/**
	 * <p>Fetches summary for Device Type Card</p>
	 * 
	 * @return String - summary for Device Type Card
	 */
	@JsonProperty("summary")
	public String getSummary();

	/**
	 * <p>Fetches image Path for Device Type Card</p>
	 * 
	 * @return String - image Path for Device Type Card
	 */
	@JsonProperty("imagePath")
	public String getImagePath();
	
	/**
	 * <p>Fetches image Alt Text for Device Type Card</p>
	 * 
	 * @return String - image Alt Text for Device Type Card
	 */
	@JsonProperty("imageAltText")
	public String getImageAltText();
	
	/**
	 * <p>Fetches accessbility Label for Device Type Card</p>
	 * 
	 * @return String - accessbility Label for Device Type Card
	 */
	@JsonProperty("accessibilityLabel")
	public String getAccessibilityLabel();
	
	/**
	 * <p>Fetches progressbarTitle for Activation flow</p>
	 * 
	 * @return String - progressbar Title for Activation flow
	 */
	@JsonProperty("progressbarTitle")
	public String getProgressbarTitle();
	
	/**
	 * <p>Fetches deviceType for Activation flow</p>
	 * 
	 * @return String - deviceType for Activation flow
	 */
	@JsonProperty("deviceType")
	public String getDeviceType();

	/**
	 * <p>Fetches subType for Magic Cookie</p>
	 * 
	 * @return the subType
	 */
	@JsonProperty("subType")
	public String getSubType();
		
}
