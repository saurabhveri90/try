/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Tracfone Application Config Service", description = "Tracfone Application Config Service")
public @interface TracfoneApplicationConfig {

	@AttributeDefinition(name = "Configuration for Filter with Smartpay",description = "Configuration for facetid of filter with smartpay")
    String[] smartpayFilterFacetId() default {"ads_f140004_ntk_cs%3A%22Monthly+Payment+Option%22"};
}


