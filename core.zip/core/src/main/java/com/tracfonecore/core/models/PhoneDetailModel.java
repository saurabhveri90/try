
package com.tracfonecore.core.models;

import java.util.List;
import java.util.Map;

import org.apache.sling.api.resource.Resource;
import org.osgi.annotation.versioning.ProviderType;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.PhoneSkuDetailBean;

@ProviderType
public interface PhoneDetailModel extends  ComponentExporter {
	
	 /**
     * Get ratings of the product(i.e. "0 to 5")
     * @return Ratings
     */
	public String getRating();
	
	/**
     * Get reviews of the product
     * @return Reviews
     */
    public String getReviews();
    
    /**
     * Get variants of the product(i.e. color)
     * @return List<PhoneCardBean>
     */
    public List<PhoneSkuDetailBean> getSKUs();

	/**
	 * Get schema.org list for product videos.
	 * @return List<String>
	 */
	public List<String> getVideoSchemaList();
      
    /**
     * returns tab links
     * @return tabLinks
     */
    public Resource getTablinks();
    
    /**
	 * <p>Fetches queryString for the price api call</p>
	 * 
	 * @return String - queryString 
	 */
   	public String getQueryString();
   	
	/**
	 * <p>Fetches queryString for the inventory api call</p>
	 *
	 * @return String - inventoryQueryString
	 */
	public String getInventoryQueryString();

	/**
	 * <p>Fetches excellient price duration of the phone</p>
	 * 
	 * @return String - expriceduration 
	 */
	@JsonProperty("expriceduration")
	public String getExpriceduration();

	/**
	 * <p>Fetches price caption of the phone</p>
	 * 
	 * @return String - pricecaptionplp 
	 */
	@JsonProperty("retailpricecaption")
	public String getPricecaptionplp();
	
	/**
	 * <p>Fetches first image path of the phone</p>
	 * 
	 * @return String - firstImagePath 
	 */	
	@JsonProperty("firstImagePath")
	public String getFirstImagePath();

	/**
	 * <p>Fetches first image asset if of the phone</p>
	 *
	 * @return String - firstImagePathAssetId
	 */
	@JsonProperty("firstImagePathAssetId")
	public String getFirstImagePathAssetId();

	/**
	 * <p>Fetches first image agency id of the phone</p>
	 *
	 * @return String - firstImagePathAgencyId
	 */
	@JsonProperty("firstImagePathAgencyId")
	public String getFirstImagePathAgencyId();

	/**
	 * <p>Fetches smartpay images's Asset id of the phone</p>
	 *
	 * @return String - smartPayImageAssetId
	 */
	@JsonProperty("smartPayImageAssetId")
	String getSmartpayImageAssetId();

	/**
	 * <p>Fetches smartPay image's agency id of the phone</p>
	 *
	 * @return String - getSmartpayImageWeberId
	 */
	@JsonProperty("smartpayImageWeberId")
	String getSmartpayImageWeberId();
	/**
	 * <p>Fetches phone name for Analytics</p>
	 *
	 * @return String - getProductNameForAnalytics
	 */
	@JsonProperty("productNameForAnalytics")
	public String getProductNameForAnalytics() ;

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - API Domain
	 */
	public String getApiDomain();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - Price API Path
	 */
	public String getPriceApiPath();
	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return int - home Page Level
	 */
	public int getHomePageLevel();

	/**
	 * <p>
	 * Fetches the export child items
	 * </p>
	 *
	 *
	 * @return Map<String, ? extends ComponentExporter> - the export child items
	 */
	public Map<String, ? extends ComponentExporter> getItems();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - get Language Level
	 */
	public String getLanguage();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - get brand
	 */
	public String getBrand();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - get inventory API Path
	 */
	public String getInventoryApiPath();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - get name
	 */
	public String getName();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - get Experience price prefix
	 */
	public String getExperiencePricePrefix();

		/**
	* <p>Sets expriceprefix</p>
	*
	*@param expriceprefix - the expriceprefix to set
	*/
	public void setExperiencePricePrefix(String expriceprefix);

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - get Experience price suffix
	 */
	public String getExperiencePriceSufix();

	/**
	* <p>Sets expricesuffix</p>
	*
	*@param expricesuffix - the expricesuffix to set
	*/
	public void setExperiencePriceSufix(String expricesuffix);

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - get smart pay
	 */
	public String getSmartPayLogo();

		/**
	* <p>Sets smartPayLogo</p>
	*
	*@param smartPayLogo - the smartPayLogo to set
	*/
	public void setSmartPayLogo(String smartPayLogo);

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - get Alt Text
	 */
	public String getAltText();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - get Color heading
	 */
	public String getColorsheading();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - get Selection
	 */
	public String getSelection();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - get image rendition thumbnail Path
	 */
	public String getImageRenditionThumbnailPath();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - stock title
	 */
	public String getStockTitle();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - notify btn title
	 */
	public String getNotifyBtn();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - pre text notify btn
	 */
	public String getPreTextNotifyMeBtn();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - Cantentry Id
	 */
	public String getCantentryId();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - ThumbnailImageAssetId
	 */
	public String getThumbnailImageAssetId();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - ThumbnailImageAssetAgencyId
	 */
	public String getThumbnailImageAssetAgencyId();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - PlanThumbnailImage
	 */
	public String getDefaultPlanThumbnailImage();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - PlanThumbnailImageAssetId
	 */
	public String getPlanThumbnailImageAssestId();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - ThumbnailImageAssetAgencyId
	 */
	public String getPlanThumbnailImageWeberId();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - Phone migration group
	 */
	public String getPhoneMigrationGroupUpg();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - EOL variable
	 */
	public String getEOL();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - pre order flag
	 */
	public String getPreOrderFlag();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - preorder shipping date
	 */
	public String getPreorderShippingDate();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - marketing Id
	 */
	public String getMarketingIds();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - plan type in case of skip plan
	 */
	public String getSkipPlanType();
	
	/**
	 * <p>
	 * Fetches Terms and Condition Modal Id/p>
	 * 
	 * @return String - Terms and Condition Modal Id
	 */
	public String getTermsCondModalLabel() ;
	/**
	 * <p>
	 * Fetches CTA text of Terms and Condition link/p>
	 * 
	 * @return String - CTA text of Terms and Condition
	 */
	public String getTermsCondModalId() ;
	/**
	 *<p>Fetches retailPriceLabel</p>
	 *
	 * @return the retailPriceLabel
	 */
 	public String getRetailPriceLabel() ;
 	/**
	 * <p>Sets retailPriceLabel</p>
	 *
	 *@param retailPriceLabel - the retailPriceLabel to set
	 */
	public void setRetailPriceLabel(String retailPriceLabel);

	
	/**
	 *<p>Fetches showPriceDetailsAboveImg</p>
	 *
	 * @return the showPriceDetailsAboveImg
	 */
	public String getShowPriceDetailsAboveImg();

	/**
	 * <p>Sets showPriceDetailsAboveImg</p>
	 *
	 *@param showPriceDetailsAboveImg - the showPriceDetailsAboveImg to set
	 */
	public void setShowPriceDetailsAboveImg(String showPriceDetailsAboveImg);
	
	/**
	 *<p>Fetches showStepsNumber</p>
	 *
	 * @return the showStepsNumber
	 */
	public String getShowStepsNumber();
	
	/**
	  * <p>
	  * Fetches show timer option
	  * </p>
	  * 
	  * @return String - Show Timer
	 */
	public String getShowTimer();

	/**
	 *<p>Fetches marketplace Icon Image</p>
	 *
	 * @return the marketplace Icon Image
	 */
	@JsonProperty("marketPlaceIconImage")
	public String getMarketPlaceIconImage() ;

	/**
	  * <p>
	  * Fetches marketPlace title text
	  * </p>
	  *
	  * @return String - Market Place title text
	 */
	public String getMarketPlaceTitleText();

	/**
	  * <p>
	  * Fetches Free Phone text
	  * </p>
	  *
	  * @return String - Phone Free text
	 */
	public String getFreePhoneText();

	/**
	  * <p>
	  * Fetches marketPlace subtitle text
	  * </p>
	  *
	  * @return String - Market Place subtitle text
	 */
	public String getMarketPlaceSubTitleText();

	/**
	  * <p>
	  * Fetches marketPlace option
	  * </p>
	  *
	  * @return String - Market Place
	 */
	public String getMarketPlace();

	/**
	 * <p>Fetches CTA text of marketplace link/p>
	 *
	 * @return String - CTA text of marketplace learnmore link
	 */
	public String getMarketPlaceCtaText();

	/**
	 * <p>Fetches CTA Alt-text of marketplace link</p>
	 *
	 * @return String - CTA Alt-text of marketplace link
	 */
	public String getMarketPlaceCtaAltText();

	/**
	 * <p>Fetches CTA link of marketplace link</p>
	 *
	 * @return String - CTA link of marketplace link
	 */
	public String getMarketPlaceCtaLink();
	/**
	 * <p>
	 * Returns categoryApiPath from configuration
	 * </p>
	 * 
	 * @return String - categoryApiPath
	 */
	public String getCategoryApiPath();
	/**
	 * String is used for part number API call
	 * @return String - fall back queryString
	 */
	public String getFallBackQueryString();
	/**
	 * Customization for Skus map .
	 */
	public Map<String, List<String>> getSKUsMap() ;

	/**
	 * <p>
	 * Returns productSchemaObj 
	 * </p>
	 * 
	 * @return productSchemaObj
	 */
	public String getProductSchemaObj();

	/**
	 * <p>
	 * Set productSchemaObj
	 * </p>
	 * 
	 * @param  productSchemaObj
	 */
	public void setProductSchemaObj(String productSchemaObj);
	
	/**
	 * <p>
	 * Get Make
	 * </p>
	 * 
	 * @return String phone make
	 */
	public String getMake();

	/**
	 * <p>
	 * Fetches enablePromotionalOffers
	 * </p>
	 *
	 * @return the enablePromotionalOffers
	 */
	public String getEnablePromotionalOffers();

	/**
	 * <p>
	 * Fetches the DCOT Promo flag for a devic
	 * </p>
	 * 
	 * @return the DCOT Promo flag for a device
	 */
	public String getDcotPromoOffer();

	/**
	 * <p>
	 * Fetches enableDcotPromoOffers
	 * </p>
	 *
	 * @return the enableDcotPromoOffers
	 */
	public String getEnableDcotPromoOffers();

	/**
	 * <p>
	 * Fetches enableDcotPaymentOptionPosition
	 * </p>
	 *
	 * @return the enableDcotPaymentOptionPosition
	 */
    String getEnableDcotPaymentOptionPosition();

	/**
	 * <p>
	 * Fetches dcotFullpricePromoTextPDP
	 * </p>
	 *
	 * @return the dcotFullpricePromoTextPDP
	 */
    String getDcotFullpricePromoTextPDP();

    /**
	 * <p>
	 * Fetches dcotPromoTextPDP
	 * </p>
	 *
	 * @return the dcotPromoTextPDP
	 */
	public String getDcotPromoTextPDP();

	/**
	 * <p>
	 * Fetches veriffPromoTextPDP
	 * </p>
	 *
	 * @return the veriffPromoTextPDP
	 */
	public String getVeriffPromoTextPDP();

	/**
	 * <p>
	 * Fetches portInPromoTextPDP
	 * </p>
	 *
	 * @return the portInPromoTextPDP
	 */
	public String getPortInPromoTextPDP();

	/**
	 * <p>
	 * Fetches activationPromoTextPDP
	 * </p>
	 *
	 * @return the activationPromoTextPDP
	 */
	public String getActivationPromoTextPDP();

	/**
	 * <p>
	 * Fetches the DCOT Model Name for a devic
	 * </p>
	 *
	 * @return the DCOT Model Name for a device
	 */
	public String getDcotModelName();

	/**
	 * <p>
	 * Fetches the DCOT Monthly Discount for a devic
	 * </p>
	 *
	 * @return the DCOT Monthly Discount for a device
	 */
	public String getDcotMonthlyDisc();

	/**
	 * <p>
	 * Fetches the DCOT Min Monthly for a devic
	 * </p>
	 *
	 * @return the DCOT Min Monthly for a device
	 */
	public String getDcotMinMonthly();

	/**
	 * <p>
	 * Fetches the DCOT Offer End Date for a devic
	 * </p>
	 *
	 * @return the DCOT Offer End Date for a device
	 */
	public String getDcotOfferEndDt();

	/**
	 * <p>
	 * Fetches the DCOT Paid Amount for a devic
	 * </p>
	 *
	 * @return the DCOT Paid Amount for a device
	 */
	public String getDcotPaidAmt();

	/**
	 * <p>
	 * Fetches the DCOT Saving for a devic
	 * </p>
	 *
	 * @return the DCOT Saving for a device
	 */
	public String getDcotSaving();

	/**
	 * <p>
	 * Fetches the DCOT autorefill flag for a device
	 * </p>
	 *
	 * @return the DCOT autorefill flag for a device
	 */
	public String getDcotAutoRefillFlag();

	/**
	 * <p>
	 * Fetches the DCOT new line or upgrade flow for a device
	 * </p>
	 *
	 * @return the DCOT new line or upgrade flow for a device
	 */
	public String getDcotNewLineUpgValue();

	/**
	 * <p>
	 * Fetches the DCOT total month text for a device
	 * </p>
	 *
	 * @return the DCOT total month text for a device
	 */
	public String getDcotTotalMonthText();

	/**
	 * <p>
	 * Fetches the DCOT Upgrade for a device
	 * </p>
	 *
	 * @return the DCOT upgrade text for a device
	 */
	public String getDcotUpgrade();
	/**
	 * <p>
	 * Fetches the DCOT Active new line text for a device
	 * </p>
	 *
	 * @return the DCOT Active new line text for a device
	 */
	public String getDcotActivateNewLine();

}
