/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;

/**
 * <p>Defines bean to hold link detail</p>
 */
public class AccountNavigationBean {

	private String navigationPageTitle;
	private String navigationPageLinkUrl;
	private String openPageLinkNewTabWindow;
	private String pageIconClass;
	
	public String getNavigationPageTitle() {
		return navigationPageTitle;
	}
	public void setNavigationPageTitle(String navigationPageTitle) {
		this.navigationPageTitle = navigationPageTitle;
	}
	public String getNavigationPageLinkUrl() {
		return navigationPageLinkUrl;
	}
	public void setNavigationPageLinkUrl(String navigationPageLinkUrl) {
		this.navigationPageLinkUrl = navigationPageLinkUrl;
	}
	public String getOpenPageLinkNewTabWindow() {
		return openPageLinkNewTabWindow;
	}
	public void setOpenPageLinkNewTabWindow(String openPageLinkNewTabWindow) {
		this.openPageLinkNewTabWindow = openPageLinkNewTabWindow;
	}
	public String getPageIconClass() {
		return pageIconClass;
	}
	public void setPageIconClass(String pageIconClass) {
		this.pageIconClass = pageIconClass;
	}	
}
