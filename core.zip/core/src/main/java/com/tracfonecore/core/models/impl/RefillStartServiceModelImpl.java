package com.tracfonecore.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.RefillStartServiceModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { RefillStartServiceModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/refillstartservice", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class RefillStartServiceModelImpl implements RefillStartServiceModel {

	@Self
	private SlingHttpServletRequest request;
	
	@ValueMapValue
	private String startdatelbl;
	
	@ValueMapValue
	private String heading;
	
	@ValueMapValue
	private String subheading;
	
	@ValueMapValue
	private String opt1label;
	
	@ValueMapValue
	private String opt1labelsummary;
	
	@ValueMapValue
	private String opt2label;
	
	@ValueMapValue
	private String opt2labelsummary;

	@ValueMapValue
	private String buttonText;
	@ValueMapValue
	private String opt2labelsummaryProrated;
	
	/**
     * @return String - exported Type
     */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * @return the startdatelbl
	 */
	@Override
	public String getStartdatelbl() {
		return startdatelbl;
	}

	/**
	 * @return the heading
	 */
	@Override
	public String getHeading() {
		return heading;
	}

	/**
	 * @return the subheading
	 */
	@Override
	public String getSubheading() {
		return subheading;
	}

	/**
	 * @return the opt1label
	 */
	@Override
	public String getOpt1label() {
		return opt1label;
	}

	/**
	 * @return the opt1labelsummary
	 */
	@Override
	public String getOpt1labelsummary() {
		return opt1labelsummary;
	}

	/**
	 * @return the opt2label
	 */
	@Override
	public String getOpt2label() {
		return opt2label;
	}
	
	/**
	 * @return the opt2labelsummary
	 */
	@Override
	public String getOpt2labelsummary() {
		return opt2labelsummary;
	}
	
	/**
	 * @return the buttonText
	 */
	@Override
	public String getButtonText() {
		return buttonText;
	}
		/**
	 * @return the opt2labelsummary
	 */
	@Override
	public String getOpt2labelsummaryProrated() {
		return opt2labelsummaryProrated;
	}
	
}
