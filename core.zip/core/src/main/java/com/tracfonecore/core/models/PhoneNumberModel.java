/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.LinkBean;

import java.util.List;

/**
 * Defines the {@code New Line} Sling Model used for the {@code /apps/tracfone-core/components/commerce/phonenumber} component.
 */
public interface PhoneNumberModel extends ComponentExporter {


	/**
	 * <p>Fetches all the multi-options</p>
	 *
	 * @return List - all the multi-options
	 */
	@JsonProperty("options")
	public List<LinkBean> getOptions();
	/**
	 * <p>Fetches modal name</p>
	 *
	 * @return String - modalName
	 */
	@JsonProperty("modalName")
	public String getModalName();

	/**
	 * <p>Fetches flow type</p>
	 *
	 * @return String - flowType
	 */
	@JsonProperty("flowType")
	public String getFlowType();

	/**
	 * <p>Fetches heading</p>
	 *
	 * @return String - heading
	 */
	@JsonProperty("heading")
	public String getHeading();

	/**
	 * <p>Fetches summary</p>
	 *
	 * @return String - summary
	 */
	@JsonProperty("summary")
	public String getSummary();

	/**
	 * <p>Fetches help text</p>
	 *
	 * @return String - helptext
	 */
	@JsonProperty("helptext")
	public String getHelptext();

	/**
	 * <p>Fetches button text</p>
	 *
	 * @return String - buttontext
	 */
	@JsonProperty("buttontext")
	public String getButtontext();
	
	/**
     * Get the resource Mgmt Projection
     * @return resourceMgmtProjection
     */
    public String getResourceMgmtProjection();  
    
    /**
     * Get the esnUsedStatusCode
     * @return esnUsedStatusCode
     */
    public String getEsnUsedStatusCode();  
    
    /**
     * Get the esnPastDueStatusCode
     * @return esnPastDueStatusCode
     */
    public String getEsnPastDueStatusCode();

	/**
     * Get the inlineSumSkipBtn
     * @return inlineSumSkipBtn
     */
    public String getInlineSumSkipBtn();
    
	/**
	 * @return the skipButtonText
	 */
    public String getSkipButtonText();

    /**
     * <p>
     * Fetches hideModalLink flag
     * </p>
     *
     * @return the hideModalLink
     */
    @JsonProperty("hideModalLink")
    public String getHideModalLink();

	/**
     * <p>
     * Fetches tncText
     * </p>
     *
     * @return the tncText
     */
    @JsonProperty("tncText")
    public String getTncText();

	/**
     * <p>
     * Fetches privacyPolicyInfo
     * </p>
     *
     * @return the privacyPolicyInfo
     */
    @JsonProperty("privacyPolicyInfo")
    public String getPrivacyPolicyInfo();
	
}
