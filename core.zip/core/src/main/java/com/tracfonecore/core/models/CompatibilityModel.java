/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import java.util.List;
import java.util.Map;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.CompatibilityCardBean;
import com.tracfonecore.core.beans.CompatibilityButtonBean;

/**
 * Defines the {@code CompatibilityModel} Sling Model used for the {@code /apps/tracfone-core/components/content/compatibilityflow/v2/compatibility} component.
 */
public interface CompatibilityModel extends ComponentExporter {
	
	
	
	/**
	 * <p>Fetches title for the Compatibility</p>
	 * 
	 * @return String - title  of the Compatibility
	 */
	@JsonProperty("compatibilitymaintitle")
	public String getCompatibilitymaintitle();


	/**
	 * <p>Fetches imageAndVideo for the Compatibility</p>
	 * 
	 * @return String - imageAndVideo of the Compatibility
	 */
	@JsonProperty("compatibilityimageAndVideo")
	public String getCompatibilityimageAndVideo();

	/**
	 * <p>Fetches contenttitle for the Compatibility</p>
	 * 
	 * @return String - contenttitle of the Compatibility
	 */
	@JsonProperty("compatibilitytitle")
	public String getCompatibilitytitle();


	/**
	 * <p>Fetches content for the Compatibility</p>
	 * 
	 * @return String - content of the Compatibility
	 */
	@JsonProperty("compatibilitycontent")
	public String getCompatibilitycontent();


	/**
	 * <p>Fetches detail for all the columns</p>
	 * 
	 * @return String - detail for all the columns
	 */
	@JsonProperty("compatibilitycardsList")
	public List<CompatibilityCardBean> getCompatibilitycardsList();

		/**
	 * <p>Fetches detail for all the columns</p>
	 * 
	 * @return String - detail for all the columns
	 */
	@JsonProperty("simnotcompatibilitybuttonsList")
	public List<CompatibilityButtonBean> getSimnotcompatibilitybuttonsList();


	/**
	 * <p>Fetches title for the notcompatibilitymaintitle</p>
	 * 
	 * @return String - title  of the notcompatibilitymaintitle
	 */
	@JsonProperty("simnotcompatibilitymaintitle")
	public String getSimnotcompatibilitymaintitle();


	
	/**
	 * <p>Fetches title for the notcompatibilityimageAndVideo</p>
	 * 
	 * @return String - title  of the notcompatibilityimageAndVideo
	 */
	@JsonProperty("simnotcompatibilityimageAndVideo")
	public String getSimnotcompatibilityimageAndVideo();


	/**
	 * <p>Fetches title for the notcompatibilitytitle</p>
	 * 
	 * @return String - title  of the notcompatibilitytitle
	 */
	@JsonProperty("simnotcompatibilitytitle")
	public String getSimnotcompatibilitytitle();


	/**
	 * <p>Fetches title for the notcompatibilitycontent</p>
	 * 
	 * @return String - title  of the notcompatibilitycontent
	 */
	@JsonProperty("simnotcompatibilitycontent")
	public String getSimnotcompatibilitycontent();

		/**
	 * <p>Fetches detail for all the columns</p>
	 * 
	 * @return String - detail for all the columns
	 */
	@JsonProperty("devicenotcompatibilitybuttonsList")
	public List<CompatibilityButtonBean> getDevicenotcompatibilitybuttonsList();


	/**
	 * <p>Fetches title for the Devicenotcompatibilitymaintitle</p>
	 * 
	 * @return String - title  of the Devicenotcompatibilitymaintitle
	 */
	@JsonProperty("devicenotcompatibilitymaintitle")
	public String getDevicenotcompatibilitymaintitle();


	
	/**
	 * <p>Fetches title for the DevicenotcompatibilityimageAndVideo</p>
	 * 
	 * @return String - title  of the DevicenotcompatibilityimageAndVideo
	 */
	@JsonProperty("devicenotcompatibilityimageAndVideo")
	public String getDevicenotcompatibilityimageAndVideo();


	/**
	 * <p>Fetches title for the Devicenotcompatibilitytitle</p>
	 * 
	 * @return String - title  of the Devicenotcompatibilitytitle
	 */
	@JsonProperty("devicenotcompatibilitytitle")
	public String getDevicenotcompatibilitytitle();


	/**
	 * <p>Fetches title for the Devicenotcompatibilitycontent</p>
	 * 
	 * @return String - title  of the Devicenotcompatibilitycontent
	 */
	@JsonProperty("devicenotcompatibilitycontent")
	public String getDevicenotcompatibilitycontent();


	/**
	 * <p>Fetches title for the activemaintitle</p>
	 * 
	 * @return String - title  of the activemaintitle
	 */
	@JsonProperty("activemaintitle")
	public String getActivemaintitle();

	/**
	 * <p>Fetches title for the activeimageAndVideo</p>
	 * 
	 * @return String - title  of the activeimageAndVideo
	 */
	@JsonProperty("activeimageAndVideo")
	public String getActiveimageAndVideo();

	/**
	 * <p>Fetches title for the activetitle</p>
	 * 
	 * @return String - title  of the activetitle
	 */
	@JsonProperty("activetitle")
	public String getActivetitle();

	/**
	 * <p>Fetches title for the activecontent</p>
	 * 
	 * @return String - title  of the activecontent
	 */
	@JsonProperty("activecontent")
	public String getActivecontent();

	/**
	 * <p>Fetches detail for all the activebuttonsList</p>
	 * 
	 * @return String - detail for all the activebuttonsList
	 */
	@JsonProperty("activebuttonsList")
	public List<CompatibilityButtonBean> getActivebuttonsList();

	
	

}
