/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Simple Mobile Configuration Service", description = "Simple Mobile Configuration Service")
public @interface SimpleMobileConfig {
	
	 @AttributeDefinition(name = "Tracfone API Domain", description = "Configuration for API Domain", type = AttributeType.STRING)
     String getApiDomain() default "https://sit-apigateway.tracfone.com/api/sitf";
	 @AttributeDefinition(name = "API Language", description = "Configuration for API Language", type = AttributeType.STRING)
     String getApiLanguage() default "ENG";
	 @AttributeDefinition(name = "API Source System", description = "Configuration for API Source System", type = AttributeType.STRING)
     String getApiSourceSystem() default "WEB";
	 @AttributeDefinition(name = "Brand Name", description = "Configuration for Brand Name", type = AttributeType.STRING)
     String getBrandName() default "SIMPLE_MOBILE";	 
	 @AttributeDefinition(name = "Decryption Endpoint Url", description = "Please provide Decryption Endpoint")
	String  decryptionEndpointUrl() default "/api/utility-mgmt/data/";
	@AttributeDefinition(name = "TCetra Client ID", description = "Please provide TCetra Client ID")
	String  tCetraClientID() default "4ddfa1bd653cfce22aa2666314182e07";
	@AttributeDefinition(name = "Resource Management API", description = "URI of Resource Management API")
    String getResourceMgmtApiPath() default "/resource-mgmt/resource";
	@AttributeDefinition(name = "Get Account Convertion Api Path", description = "URI of Account Convertion from Dummy to Real")
    String getAccountConvertionApiPath() default "/customer-mgmt/customer/addProfile";
	@AttributeDefinition(name = "mapQuestEndpointUrl", description = "mapQuestEndpointUrl")
    String getMapQuestEndpointUrl() default "https://www.mapquestapi.com";
	@AttributeDefinition(name = "Map Quest Api Path", description = "Map Quest Api Path")
    String getMapQuestApiPath() default "/geocoding/v1/address";
	@AttributeDefinition(name = "Map Quest Authentication Token", description = "Map Quest Authentication Token")
    String getMapQuestAuthToken() default "IQWpZsttQHDa5BjHFlNpV3n25HEuOZFU";
	@AttributeDefinition(name = "HPP Enrollment API Path", description = "HPP Enrollment API Path")
    String getHppEnrollmentApiPath() default "/order-mgmt/productorder";
	@AttributeDefinition(name = "AEM CMS Path", description = "AEM CMS Path")
    String getAemCmsPath() default "https://sitfapifull.tracfone.com/api/catalog-mgmt/aem-messagelookup";
	@AttributeDefinition(name = "Aem DP CMS Api Path", description = "Aem DP CMS Api Path")
    String getAemDPCMSApiPath() default "https://sit-apigateway.tracfone.com/api/sitf/utility-mgmt/indirect-payment-collection";
	@AttributeDefinition(name = "Aem DP API ClientId", description = "Aem DP API ClientId")
    String getAemDPAPIClientId() default "7822b10eda0adac963e18787a1084436";
	@AttributeDefinition(name = "getAemDPConfigApiPath", description = "getAemDPConfigApiPath")
    String getAemDPConfigApiPath() default "https://sit-apigateway.tracfone.com/api/sitf/utility-mgmt/aem-payment-config";
	@AttributeDefinition(name = "DataPowerEnLanguage", description = "DataPowerEnLanguage")
    String getDataPowerEnLanguage() default "en";
	@AttributeDefinition(name = "getAemDPConfigApiPath", description = "getAemDPConfigApiPath")
    String getDataPowerEsLanguage() default "es";
	
	
	@AttributeDefinition(name = "getCCTokenApiPath", description = "getCCTokenApiPath")
    String getCCTokenApiPath() default "https://sitfapifull.tracfone.com/oauth/cc";
	@AttributeDefinition(name = "getCcGrant", description = "getCcGrant")
    String getCcGrant() default "client_credentials";
	@AttributeDefinition(name = "cc_scope", description = "cc_scope")
    String getCcScope() default "createNewAccount";
	@AttributeDefinition(name = "cc_client_id", description = "cc_client_id")
    String getCcClientId() default "SMWebMyAcct_CCU";
	
	@AttributeDefinition(name = "cc_client_secret", description = "cc_client_secret")
    String getCcClientSecret() default "abc123**";
	@AttributeDefinition(name = "assetsDomain", description = "assetsDomain")
    String getAssetsDomain() default "https://sit1.totalwireless.com";	
	@AttributeDefinition(name = "Voltage API Url", description = "Please provide Voltage API Url")
	String  voltageUrl() default "https://pie.uat.verizon.com";	
	@AttributeDefinition(name = "Encryption Js File Path in Library", description = "Please provide Encryption Js File Path in Library")
	String  voltageEncryptionJsFilePath() default "/pie/v1/encryption.js";
	@AttributeDefinition(name = "Encryption Js File Path in Library", description = "Please provide Encryption Js File Path in Library")
	String  voltageEncryptionKeyFilePath() default "/pie/v1/verizon/getkey.js";
	@AttributeDefinition(name = "Session Timeout in Minutes", description = "Please provide Session Timeout in Minutes for submit functionality on payment collection page")
	String  sessionTimeoutMinutesForIndirectChannel() default "30";
	@AttributeDefinition(name = "Country Mapping", description = "Please provide Country Mapping")
	String  countryMapping()default "{\"displayValue\":\"United States\",\"value\":\"US\"},\r\n" + 
			" {\"displayValue\":\"Guam\",\"value\":\"GU\"},\r\n" + 
			" {\"displayValue\":\" Virgin Islands\",\"value\":\"VI\"},\r\n" + 
			" {\"displayValue\":\"American Samoa\",\"value\":\"AS\"},\r\n" + 
			" {\"displayValue\":\"Mariana Islands\",\"value\":\"MP\"}";
	@AttributeDefinition(name = "Logo Image Url for web ", description = "Please provide Logo Image Url for Indirect channel")
	String  webLogoUrl() default "/content/dam/tbvz/logos/Total_Logo_Positive_RGB.png";
	@AttributeDefinition(name = "Logo Image Url for mobile", description = "Please provide Logo Image Url for Indirect channel")
	String  mobileLogoUrl() default "https://s7d1.scene7.com/is/image/tracfonestage/total_dot_logo_2x-desktop2?scl=1&fmt=webp-alpha&qlt=80,0&resMode=sharp2&op_usm=1.75,0.3,2,0";
	@AttributeDefinition(name = "Number of retries for Voltage JS scripts", description = "Please provide Number of retries for Voltage JS scripts")
	String voltageScriptRetries() default "1";
	@AttributeDefinition(name = "Country State Mapping", description = "Provide country and state data")
	String[] getCountryStateMapping();
	@AttributeDefinition(name = "Payment High Error Codes", description = "Provide Payment High Error Codes that could occure mroe frequently")
	String[] getPaymentHighErrorCodes() default {"25014","20204","20230","20231"};
}

