package com.tracfonecore.core.beans;

/**
 * <p>
 * Defines bean to hold link detail
 * </p>
 */
public class ProductFilterBean implements Comparable<ProductFilterBean> {
	/*
	 * Copyright 2019 HCL Technologies Ltd.
	 *
	 *
	 */

	private String subfilterAttribute;
	private String subfilterValue;
	private String count;
	private Boolean setSmartPayImage;
	/**
	 * @return the subfilterattribute
	 */
	public String getSubfilterAttribute() {
		return subfilterAttribute;
	}

	/**
	 * @param subfilterattribute the subfilterattribute to set
	 */
	public void setSubfilterAttribute(String subfilterAttribute) {
		this.subfilterAttribute = subfilterAttribute;
	}

	/**
	 * @return the subfiltervalue
	 */
	public String getSubfilterValue() {
		return subfilterValue;
	}

	/**
	 * @param subfiltervalue the subfiltervalue to set
	 */
	public void setSubfilterValue(String subfilterValue) {
		this.subfilterValue = subfilterValue;
	}

	/**
	 * @return the count
	 */
	public String getCount() {
		return count;
	}

	/**
	 * @param count the count to set
	 */
	public void setCount(String count) {
		this.count = count;
	}

	/**
	 * @return the setSmartPayImage
	 */
	public Boolean getSetSmartPayImage() {
		return setSmartPayImage;
	}

	/**
	 * @param setSmartPayImage the setSmartPayImage to set
	 */
	public void setSetSmartPayImage(Boolean setSmartPayImage) {
		this.setSmartPayImage = setSmartPayImage;
	}

	@Override
	public String toString() {
		return "ProductFilterBean [subfiltervalue=" + subfilterValue + ", subfilterattribute=" + subfilterAttribute
				+ "count" + count + "setSmartPayImage" + setSmartPayImage + "]";
	}

	@Override
	public int compareTo(ProductFilterBean o) {
		return this.getSubfilterAttribute().compareTo(o.getSubfilterAttribute());
	}

}
