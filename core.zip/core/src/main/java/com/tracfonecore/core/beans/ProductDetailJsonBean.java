package com.tracfonecore.core.beans;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonRawValue;
import com.google.gson.JsonArray;
import com.tracfonecore.core.constants.ApplicationConstants;
import org.apache.commons.lang3.StringUtils;

public class ProductDetailJsonBean {

	private String pageTitle;
	private String pageDescription;
	private String categoryType;
	private String partno;
	private String AppPartNumber;
	private String promotext;
	private String alternatePromotext;
	private String churnInfo;
	private String enrollmentSubText;
	private String promoadditionaltext;
	private String pricecaption;
	private String expriceprefix;
	private String expriceduration;
	private String expricedefaultduration;
	private String expricesuffix;
	private String imagepath;
	private String skuid;
	private List<String> allSKUs;
	private String plandatadescription;
	private String plandatalabel;
	private String planname;
	private String plantype;
	private String planFilter;
	private String planservicedays;
	private String pricedescription;
	private String acpDiscountedArDescription;
	private String acpDiscountedArAccsDescription;
	private String pricesuperscript;
	private String pagePath;
	private String fullPagePath;
	private String smartPayLogoPath;
	private String compareImagePath;
	private String hppSeeDetailData;
	private String hppTncData;
	private String hppEnrollTile;
	private String hppEnrollCondition;
	private String hppEnrollDescription;
	private String thumbnailImageAssetId;
	private String thumbnailImageAssetAgencyId;
	private String hppPlanDuration;
	private String imageAssetId;
	private String imageAgencyId;
	private String isMonthlyPlan;
	private String planServiceDaysPopoverText;
	private String globalCardMaxQuantity;
	private String hideRating;
	private String planShortDescription;
	private String planDescription;
	private String showPlanThumbnailImage;
	private String paymentTypeText;
	private String paymentType;
	private String planCardMaxQuantity;
	private String hppPlanThumbnailImage;
	private String hppPlanTermsconditionsLink;
	private String parentCategoryType;
	private String planNameType;
	private String perTimePeriod;
	private String priceAccessibilityLabel;
	private List<String> specsName = Collections.emptyList();
	private JsonArray otherSpecs;
	private String disablePaypalOption;
	private String saveAccessibilityLabel;
	private String isVasBundlePlan;
	private String vasProductThumbnailImage;
	private String vasProdImgAccessibleText;
	private String vasProdImgSubscript;
	private String vasTermsContent;
	private String addLineRibbonText;
	private String addLineAutoRefill;
	private String addLineAutoRefillPrice;
	private String promoColor;
	private String hidePlanInSimPlp;
	private String autoRefillDiscountLabel;
	private boolean hidePlanForPortIn;
	private String planPromoText;
	private String byodPlanPromoText;
	private String offerDisclaimer;
	private String offerDisclaimerLabel;
	private String offerDisclaimerLinkLabel;

	private String readmoreCTALink;
	private String readmoreCTALabel;
	private String readmoreAccessibilityText;

	private String bestPlan;
	private String planDurationMonthlyLabel;
	private String specialPromoSummary;
	private String veriffPlanPromoText;
	private String showRecommendedPlan;
	private String alternateDataUnitForPlanCard;
	private String dcotTitle;
	private String dcotDescription;

	private String veriffTitle;

	private String veriffDescription;

	private String portInTitle;

	private String portInDescription;

	private String activationTitle;

	private String activationDescription;

	private String vasTooltipContent;
	private String vasTerms;
	private String planDisclaimer;
	private String planDisclaimerId;
	private String disclaimerCTALabel;
	private String disclaimerAccessibilityText;

	private String tabletPlanIcon;
	public String getDcotTitle() {
		return dcotTitle;
	}

	public void setDcotTitle(String dcotTitle) {
		this.dcotTitle = dcotTitle;
	}

	public String getDcotDescription() {
		return dcotDescription;
	}

	public void setDcotDescription(String dcotDescription) {
		this.dcotDescription = dcotDescription;
	}

	public String getVeriffTitle() {
		return veriffTitle;
	}
	public void setVeriffTitle(String veriffTitle) {
		this.veriffTitle = veriffTitle;
	}
	public String getVeriffDescription() {
		return veriffDescription;
	}
	public void setVeriffDescription(String veriffDescription) {
		this.veriffDescription = veriffDescription;
	}


	public String getPortInTitle() {
		return portInTitle;
	}

	public void setPortInTitle(String portInTitle) {
		this.portInTitle = portInTitle;
	}
	public String getPortInDescription() {
		return portInDescription;
	}

	public void setPortInDescription(String portInDescription) {
		this.portInDescription = portInDescription;
	}

	public String getActivationTitle() {
		return activationTitle;
	}

	public void setActivationTitle(String activationTitle) {
		this.activationTitle = activationTitle;
	}

	public String getActivationDescription() {
		return activationDescription;
	}

	public void setActivationDescription(String activationDescription) {
		this.activationDescription = activationDescription;
	}

	public String getPageTitle() {
		return pageTitle;
	}

	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}

	public String getPageDescription() {
		return pageDescription;
	}

	public void setPageDescription(String pageDescription) {
		this.pageDescription = pageDescription;
	}

	public String getCategoryType() {
		return categoryType;
	}

	public void setCategoryType(String categoryType) {
		this.categoryType = categoryType;
	}

	public String getParentCategoryType() {
		return parentCategoryType;
	}

	public void setParentCategoryType(String parentCategoryType) {
		this.parentCategoryType = parentCategoryType;
	}

	public String getPlanDisclaimerId() {
		return planDisclaimerId;
	}

	public void setPlanDisclaimerId(String planDisclaimerId) {
		this.planDisclaimerId = planDisclaimerId;
	}

	public String getDisclaimerCTALabel() {
	  return disclaimerCTALabel;
	}

	public void setDisclaimerCTALabel(String disclaimerCTALabel) {
		this.disclaimerCTALabel = disclaimerCTALabel;
	}

	public String getDisclaimerAccessibilityText() {
	  return disclaimerAccessibilityText;
	}

	public void setDisclaimerAccessibilityText(String disclaimerAccessibilityText) {
		this.disclaimerAccessibilityText = disclaimerAccessibilityText;
	}

	public String getTabletPlanIcon() {
		return tabletPlanIcon;
	}

	public void setTabletPlanIcon(String tabletPlanIcon) {
		this.tabletPlanIcon = tabletPlanIcon;
	}

	public List<String> getAllSKUs() {
		return new ArrayList<>(allSKUs);
	}

	public void setAllSKUs(List<String> allSKUs) {
		this.allSKUs = new ArrayList<>(allSKUs);
	}

	public String getCompareImagePath() {
		return compareImagePath;
	}

	public void setCompareImagePath(String compareImagePath) {
		this.compareImagePath = compareImagePath;
	}

	public String getPagePath() {
		return pagePath;
	}

	public void setPagePath(String pagePath) {
		this.pagePath = pagePath;
	}

	public String getSmartPayLogoPath() {
		return smartPayLogoPath;
	}

	public void setSmartPayLogoPath(String smartPayLogoPath) {
		this.smartPayLogoPath = smartPayLogoPath;
	}

	public String getPlandatadescription() {
		return plandatadescription;
	}

	public void setPlandatadescription(String plandatadescription) {
		this.plandatadescription = plandatadescription;
	}

	public String getPlandatalabel() {
		return plandatalabel;
	}

	public void setPlandatalabel(String plandatalabel) {
		this.plandatalabel = plandatalabel;
	}

	@JsonRawValue
	public String getPlanname() {
		return planname;
	}

	public void setPlanname(String planname) {
		this.planname = planname;
	}

	/**
	 * @return the plantype
	 */
	public String getPlantype() {
		return plantype;
	}

	/**
	 * @param plantype the plantype to set
	 */
	public void setPlantype(String plantype) {
		this.plantype = plantype;
	}

	/**
	 * @return the planservicedays
	 */
	public String getPlanservicedays() {
		return planservicedays;
	}

	/**
	 * @param planservicedays the planservicedays to set
	 */
	public void setPlanservicedays(String planservicedays) {
		this.planservicedays = planservicedays;
	}

	public String getPricedescription() {
		return pricedescription;
	}

	public void setPricedescription(String pricedescription) {
		this.pricedescription = pricedescription;
	}

	public String getAcpDiscountedArDescription() {
		return acpDiscountedArDescription;
	}

	public void setAcpDiscountedArDescription(String acpDiscountedArDescription) {
		this.acpDiscountedArDescription = acpDiscountedArDescription;
	}

	public String getAcpDiscountedArAccsDescription() {
		return acpDiscountedArAccsDescription;
	}

	public void setAcpDiscountedArAccsDescription(String acpDiscountedArAccsDescription) {
		this.acpDiscountedArAccsDescription = acpDiscountedArAccsDescription;
	}

	public String getPricesuperscript() {
		return pricesuperscript;
	}

	public void setPricesuperscript(String pricesuperscript) {
		this.pricesuperscript = pricesuperscript;
	}

	public String getSkuid() {
		return skuid;
	}

	public void setSkuid(String skuid) {
		this.skuid = skuid;
	}

	public String getPartno() {
		return partno;
	}

	public void setPartno(String partno) {
		this.partno = partno;
	}

	public void setAppPartNumber(String AppPartNumber) {
		this.AppPartNumber = AppPartNumber;
	}
	
	public String getAppPartNumber() {
		return AppPartNumber;
	}

	public String getImagepath() {
		return imagepath;
	}

	public void setImagepath(String imagepath) {
		this.imagepath = imagepath;
	}

	public String getPromotext() {
		return promotext;
	}

	public void setPromotext(String promotext) {
		this.promotext = promotext;
	}

	public String getAlternatePromotext() {
		return alternatePromotext;
	}

	public void setAlternatePromotext(String alternatePromotext) {
		this.alternatePromotext = alternatePromotext;
	}

	public String getChurnInfo() {
		return churnInfo;
	}

	public void setChurnInfo(String churnInfo) {
		this.churnInfo = churnInfo;
	}
	
	public String getEnrollmentSubText() {
		return enrollmentSubText;
	}

	public void setEnrollmentSubText(String enrollmentSubText) {
		this.enrollmentSubText = enrollmentSubText;
	}

	@JsonRawValue
	public String getPromoadditionaltext() {
		return promoadditionaltext;
	}

	public void setPromoadditionaltext(String promoadditionaltext) {
		this.promoadditionaltext = promoadditionaltext;
	}

	public String getPricecaption() {
		return pricecaption;
	}

	public void setPricecaption(String pricecaption) {
		this.pricecaption = pricecaption;
	}

	public String getExpriceprefix() {
		return expriceprefix;
	}

	public void setExpriceprefix(String expriceprefix) {
		this.expriceprefix = expriceprefix;
	}

	public String getExpriceduration() {
		return expriceduration;
	}

	public void setExpriceduration(String expriceduration) {
		this.expriceduration = expriceduration;
	}

	public String getExpricesuffix() {
		return expricesuffix;
	}

	public void setExpricesuffix(String expricesuffix) {
		this.expricesuffix = expricesuffix;
	}

	public String getExpricedefaultduration() {
		return expricedefaultduration;
	}

	public void setExpricedefaultduration(String expricedefaultduration) {
		this.expricedefaultduration = expricedefaultduration;
	}

	/**
	 * @return the hppSeeDetailData
	 */
	public String getHppSeeDetailData() {
		return hppSeeDetailData;
	}

	/**
	 * @param hppSeeDetailData the hppSeeDetailData to set
	 */
	public void setHppSeeDetailData(String hppSeeDetailData) {
		this.hppSeeDetailData = hppSeeDetailData;
	}

	/**
	 * @return the hppPlanDuration
	 */
	public String getHppPlanDuration() {
		return hppPlanDuration;
	}

	/**
	 * @param hppPlanDuration the hppPlanDuration to set
	 */
	public void setHppPlanDuration(String hppPlanDuration) {
		this.hppPlanDuration = hppPlanDuration;
	}

	/**
	 * @return the hppTncData
	 */
	public String getHppTncData() {
		return hppTncData;
	}

	/**
	 * @param hppTncData the hppTncData to set
	 */
	public void setHppTncData(String hppTncData) {
		this.hppTncData = hppTncData;
	}

	/**
	 * @return the hppEnrollTile
	 */
	public String getHppEnrollTile() {
		return hppEnrollTile;
	}

	/**
	 * @param hppEnrollTile the hppEnrollTile to set
	 */
	public void setHppEnrollTile(String hppEnrollTile) {
		this.hppEnrollTile = hppEnrollTile;
	}

	/**
	 * @return the hppEnrollCondition
	 */
	public String getHppEnrollCondition() {
		return hppEnrollCondition;
	}

	/**
	 * @param hppEnrollCondition the hppEnrollCondition to set
	 */
	public void setHppEnrollCondition(String hppEnrollCondition) {
		this.hppEnrollCondition = hppEnrollCondition;
	}

	/**
	 * @return the hppEnrollDescription
	 */
	public String getHppEnrollDescription() {
		return hppEnrollDescription;
	}

	/**
	 * @param hppEnrollDescription the hppEnrollDescription to set
	 */
	public void setHppEnrollDescription(String hppEnrollDescription) {
		this.hppEnrollDescription = hppEnrollDescription;
	}

	/**
	 * @return the thumbnailImageAssetId
	 */
	public String getThumbnailImageAssetId() {
		return thumbnailImageAssetId;
	}

	/**
	 * @param thumbnailImageAssetId the thumbnailImageAssetId to set
	 */
	public void setThumbnailImageAssetId(String thumbnailImageAssetId) {
		this.thumbnailImageAssetId = thumbnailImageAssetId;
	}

	/**
	 * @return the thumbnailImageAssetAgencyId
	 */
	public String getThumbnailImageAssetAgencyId() {
		return thumbnailImageAssetAgencyId;
	}

	/**
	 * @param thumbnailImageAssetAgencyId the thumbnailImageAssetAgencyId to set
	 */
	public void setThumbnailImageAssetAgencyId(String thumbnailImageAssetAgencyId) {
		this.thumbnailImageAssetAgencyId = thumbnailImageAssetAgencyId;
	}

	/**
	 * @return the imageAssetId
	 */
	public String getImageAssetId() {
		return imageAssetId;
	}

	/**
	 * @param imageAssetId the imageAssetId to set
	 */
	public void setImageAssetId(String imageAssetId) {
		this.imageAssetId = imageAssetId;
	}

	/**
	 * @return the imageAgencyId
	 */
	public String getImageAgencyId() {
		return imageAgencyId;
	}

	/**
	 * @param imageAgencyId the imageAgencyId to set
	 */
	public void setImageAgencyId(String imageAgencyId) {
		this.imageAgencyId = imageAgencyId;
	}

	/**
	 * @return the fullPagePath
	 */
	public String getFullPagePath() {
		return fullPagePath;
	}

	/**
	 * @param fullPagePath the fullPagePath to set
	 */
	public void setFullPagePath(String fullPagePath) {
		this.fullPagePath = fullPagePath;
	}

	/**
	 * @return the isMonthlyPlan
	 */
	public String getIsMonthlyPlan() {
		return isMonthlyPlan;
	}

	/**
	 * @param isMonthlyPlan the isMonthlyPlan to set
	 */
	public void setIsMonthlyPlan(String isMonthlyPlan) {
		this.isMonthlyPlan = isMonthlyPlan;
	}

	/**
	 * @return the globalCardMaxQuantity
	 */
	public String getGlobalCardMaxQuantity() {
		return globalCardMaxQuantity;
	}

	/**
	 * @param globalCardMaxQuantity the globalCardMaxQuantity to set
	 */
	public void setGlobalCardMaxQuantity(String globalCardMaxQuantity) {
		this.globalCardMaxQuantity = globalCardMaxQuantity;
	}

	/**
	 * @return the hideRating
	 */
	public String getHideRating() {
		return hideRating;
	}

	/**
	 * @param hideRating the hideRating to set
	 */
	public void setHideRating(String hideRating) {
		this.hideRating = hideRating;
	}

	/**
	 * @return the disablePaypalOption
	 */
	public String getDisablePaypalOption() {
		return disablePaypalOption;
	}

	/**
	 * @param disablePaypalOption the disablePaypalOption to set
	 */
	public void setDisablePaypalOption(String disablePaypalOption) {
		this.disablePaypalOption = disablePaypalOption;
	}

	/**
	 * @return the planShortDescription
	 */
	public String getPlanShortDescription() {
		return planShortDescription;
	}

	/**
	 * @param planShortDescription the planShortDescription to set
	 */
	public void setPlanShortDescription(String planShortDescription) {
		this.planShortDescription = planShortDescription;
	}

	/**
	 * @return the planDescription
	 */
	public String getPlanDescription() {
		return planDescription;
	}

	/**
	 * @param planDescription the planDescription to set
	 */
	public void setPlanDescription(String planDescription) {
		this.planDescription = planDescription;
	}

	/**
	 * @return the showPlanThumbnailImage
	 */
	public String getShowPlanThumbnailImage() {
		return showPlanThumbnailImage;
	}

	/**
	 * @param hidePlanThumbnailImage the hidePlahidePlanThumbnailImagenBenefits to
	 *                               set
	 */
	public void setShowPlanThumbnailImage(String showPlanThumbnailImage) {
		this.showPlanThumbnailImage = showPlanThumbnailImage;
	}

	/**
	 * @return the planServiceDaysPopoverText
	 */
	public String getPlanServiceDaysPopoverText() {
		return planServiceDaysPopoverText;
	}

	/**
	 * @param planServiceDaysPopoverText the planServiceDaysPopoverText to set
	 */
	public void setPlanServiceDaysPopoverText(String planServiceDaysPopoverText) {
		this.planServiceDaysPopoverText = planServiceDaysPopoverText;
	}

	public String getPaymentTypeText() {
		return paymentTypeText;
	}

	public void setPaymentTypeText(String paymentTypeText) {
		this.paymentTypeText = paymentTypeText;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	/**
	 * @return the hppPlanThumbnailImage
	 */
	public String getHppPlanThumbnailImage() {
		return hppPlanThumbnailImage;
	}

	/**
	 * @param hppPlanThumbnailImage the hppPlanThumbnailImage to set
	 */
	public void setHppPlanThumbnailImage(String hppPlanThumbnailImage) {
		this.hppPlanThumbnailImage = hppPlanThumbnailImage;
	}

	/**
	 * @return the hppPlanTermsconditionsLink
	 */
	public String getHppPlanTermsconditionsLink() {
		return hppPlanTermsconditionsLink;
	}

	/**
	 * <p>
	 * Fetches planCardMaxQuantity
	 * </p>
	 *
	 * @return the planCardMaxQuantity
	 */
	public String getPlanCardMaxQuantity() {
		return planCardMaxQuantity;
	}

	/**
	 * <p>
	 * Sets planCardMaxQuantity
	 * </p>
	 *
	 * @param planCardMaxQuantity - the planCardMaxQuantity to set
	 */
	public void setPlanCardMaxQuantity(String planCardMaxQuantity) {
		this.planCardMaxQuantity = planCardMaxQuantity;
	}

	/**
	 * * @param hppPlanTermsconditionsLink the hppPlanTermsconditionsLink to set
	 */
	public void setHppPlanTermsconditionsLink(String hppPlanTermsconditionsLink) {
		this.hppPlanTermsconditionsLink = hppPlanTermsconditionsLink;
	}

	/**
	 * <p>
	 * Fetches planNameType
	 * </p>
	 *
	 * @return the planNameType
	 */
	public String getPlanNameType() {
		return planNameType;
	}

	/**
	 * <p>
	 * Fetches perTimePeriod
	 * </p>
	 *
	 * @return the perTimePeriod
	 */
	public String getPerTimePeriod() {
		return perTimePeriod;
	}

	/**
	 * <p>
	 * Sets perTimePeriod
	 * </p>
	 *
	 * @param perTimePeriod the perTimePeriod to set
	 */
	public void setPerTimePeriod(String perTimePeriod) {
		this.perTimePeriod = perTimePeriod;
	}

	/**
	 * <p>
	 * Sets planNameType
	 * </p>
	 *
	 * @param planNameType the planNameType to set
	 */
	public void setPlanNameType(String planNameType) {
		this.planNameType = planNameType;
	}

	/**
	 * <p>
	 * Fetches priceAccessibilityLabel
	 * </p>
	 *
	 * @return the priceAccessibilityLabel
	 */
	public String getPriceAccessibilityLabel() {
		return priceAccessibilityLabel;
	}

	/**
	 * <p>
	 * Sets priceAccessibilityLabel
	 * </p>
	 *
	 * @param priceAccessibilityLabel the priceAccessibilityLabel to set
	 */
	public void setPriceAccessibilityLabel(String priceAccessibilityLabel) {
		this.priceAccessibilityLabel = priceAccessibilityLabel;
	}

	/**
	 * <p>
	 * Fetches specsName
	 * </p>
	 *
	 * @return the specsName
	 */
	public List<String> getSpecsName() {
		return new ArrayList<>(specsName);
	}

	/**
	 * <p>
	 * Sets specsName
	 * </p>
	 *
	 * @param specsName the specsName to set
	 */
	public void setSpecsName(List<String> specsName) {
		this.specsName = new ArrayList<>(specsName);
	}

	/**
	 * <p>
	 * Fetches otherSpecs
	 * </p>
	 *
	 * @return the otherSpecs
	 */
	public JsonArray getOtherSpecs() {
		return otherSpecs;
	}

	/**
	 * <p>
	 * Sets otherSpecs
	 * </p>
	 *
	 * @param otherSpecs the otherSpecs to set
	 */
	public void setOtherSpecs(JsonArray otherSpecs) {
		this.otherSpecs = otherSpecs;
	}

	/**
	 * <p>
	 * Fetches saveAccessibilityLabel
	 * </p>
	 *
	 * @return the saveAccessibilityLabel
	 */
	public String getSaveAccessibilityLabel() {
		return saveAccessibilityLabel;
	}

	/**
	 * <p>
	 * Sets saveAccessibilityLabel
	 * </p>
	 *
	 * @param saveAccessibilityLabel the saveAccessibilityLabel to set
	 */
	public void setSaveAccessibilityLabel(String saveAccessibilityLabel) {
		this.saveAccessibilityLabel = saveAccessibilityLabel;
	}

	/**
	 * <p>
	 * Fetches isVasBundlePlan
	 * </p>
	 *
	 * @return the isVasBundlePlan
	 */
	public String getIsVasBundlePlan() {
		return isVasBundlePlan;
	}

	/**
	 * <p>
	 * Sets isVasBundlePlan
	 * </p>
	 *
	 * @param isVasBundlePlan the isVasBundlePlan to set
	 */
	public void setIsVasBundlePlan(String isVasBundlePlan) {
		this.isVasBundlePlan = isVasBundlePlan;
	}

	/**
	 * <p>
	 * Fetches vasProductThumbnailImage
	 * </p>
	 *
	 * @return the vasProductThumbnailImage
	 */
	public String getVasProductThumbnailImage() {
		return vasProductThumbnailImage;
	}

	/**
	 * <p>
	 * Sets vasProductThumbnailImage
	 * </p>
	 *
	 * @param vasProductThumbnailImage the vasProductThumbnailImage to set
	 */
	public void setVasProductThumbnailImage(String vasProductThumbnailImage) {
		this.vasProductThumbnailImage = vasProductThumbnailImage;
	}

	/**
	 * <p>
	 * Fetches vasProdImgAccessibleText
	 * </p>
	 *
	 * @return the vasProdImgAccessibleText
	 */
	public String getVasProdImgAccessibleText() {
		return vasProdImgAccessibleText;
	}

	/**
	 * <p>
	 * Sets vasProdImgAccessibleText
	 * </p>
	 *
	 * @param vasProdImgAccessibleText the vasProdImgAccessibleText to set
	 */
	public void setVasProdImgAccessibleText(String vasProdImgAccessibleText) {
		this.vasProdImgAccessibleText = vasProdImgAccessibleText;
	}

	/**
	 * <p>
	 * Fetches vasProdImgSubscript
	 * </p>
	 *
	 * @return the vasProdImgSubscript
	 */
	public String getVasProdImgSubscript() {
		return vasProdImgSubscript;
	}

	/**
	 * <p>
	 * Sets vasProdImgSubscript
	 * </p>
	 *
	 * @param vasProdImgSubscript the vasProdImgSubscript to set
	 */
	public void setVasProdImgSubscript(String vasProdImgSubscript) {
		this.vasProdImgSubscript = vasProdImgSubscript;
	}

	/**
	 * <p>
	 * Fetches vasTermsContent
	 * </p>
	 *
	 * @return the vasTermsContent
	 */
	public String getVasTermsContent() {
		return vasTermsContent;
	}

	/**
	 * <p>
	 * Sets vasTermsContent
	 * </p>
	 *
	 * @param vasTermsContent the vasTermsContent to set
	 */
	public void setVasTermsContent(String vasTermsContent) {
		this.vasTermsContent = vasTermsContent;
	}

	/**
	 * @return the addLineRibbonText
	 */
	public String getAddLineRibbonText() {
		return addLineRibbonText;
	}

	/**
	 * @param addLineRibbonText the addLineRibbonText to set
	 */
	public void setAddLineRibbonText(String addLineRibbonText) {
		this.addLineRibbonText = addLineRibbonText;
	}

	/**
	 * @return the addLineAutoRefill
	 */
	public String getAddLineAutoRefill() {
		return addLineAutoRefill;
	}

	/**
	 * @param addLineAutoRefill the addLineAutoRefill to set
	 */
	public void setAddLineAutoRefill(String addLineAutoRefill) {
		this.addLineAutoRefill = addLineAutoRefill;
	}

	/**
	 * @return the addLineAutoRefillPrice
	 */
	public String getAddLineAutoRefillPrice() {
		return addLineAutoRefillPrice;
	}

	/**
	 * @param addLineAutoRefillPrice the addLineAutoRefillPrice to set
	 */
	public void setAddLineAutoRefillPrice(String addLineAutoRefillPrice) {
		this.addLineAutoRefillPrice = addLineAutoRefillPrice;
	}

	/**
	 * @return the promoColor
	 */
	public String getPromoColor() {
		return promoColor;
	}

	/**
	 * @param promoColor the promoColor to set
	 */
	public void setPromoColor(String promoColor) {
		this.promoColor = promoColor;
	}

	/**
	 * @return the hidePlanInSimPlp
	 */
	public String getHidePlanInSimPlp() {
		return hidePlanInSimPlp;
	}

	/**
	 * @param hidePlanInSimPlp the hidePlanInSimPlp to set
	 */
	public void setHidePlanInSimPlp(String hidePlanInSimPlp) {
		this.hidePlanInSimPlp = hidePlanInSimPlp;
	}

	/**
	 * @return the autoRefillDiscountLabel
	 */
	public String getAutoRefillDiscountLabel() {
		return autoRefillDiscountLabel;
	}

	/**
	 * @param autoRefillDiscountLabel the autoRefillDiscountLabel to set
	 */
	public void setAutoRefillDiscountLabel(String autoRefillDiscountLabel) {
		this.autoRefillDiscountLabel = autoRefillDiscountLabel;
	}

	/**
	 * @return the hidePlanForPortIn
	 */
	public boolean getHidePlanForPortIn() {
		return hidePlanForPortIn;
	}

	/**
	 * @param hidePlanForPortIn - the hidePlanForPortIn to set
	 */
	public void setHidePlanForPortIn(String hidePlanForPortIn) {
		this.hidePlanForPortIn = StringUtils.isNotBlank(hidePlanForPortIn) &&
				hidePlanForPortIn.equalsIgnoreCase(ApplicationConstants.TRUE) ? true : false;
	}

	/**
	 * @return the planPromoText
	 */
	public String getPlanPromoText() {
		return planPromoText;
	}

	/**
	 * @param planPromoText the planPromoText to set
	 */
	public void setPlanPromoText(String planPromoText) {
		this.planPromoText = planPromoText;
	}

	/**
	 * @return the byodPlanPromoText
	 */
	public String getByodPlanPromoText() {
		return byodPlanPromoText;
	}

	/**
	 * @param byodPlanPromoText the byodPlanPromoText to set
	 */
	public void setByodPlanPromoText(String byodPlanPromoText) {
		this.byodPlanPromoText = byodPlanPromoText;
	}


	public void setReadmoreCTALink(String readmoreCTALink) {
		this.readmoreCTALink = readmoreCTALink;
	}
	public void setReadmoreCTALabel(String readmoreCTALabel) {
		this.readmoreCTALabel = readmoreCTALabel;
	}
	public void setReadmoreAccessibilityText(String readmoreAccessibilityText) {
		this.readmoreAccessibilityText = readmoreAccessibilityText;
	}

	public String getReadmoreCTALink() {
		return readmoreCTALink;
	}
	public String getReadmoreCTALabel() {
		return readmoreCTALabel;
	}
	public String getReadmoreAccessibilityText() {
		return readmoreAccessibilityText;
	}



	/**
	 * @return String return the offerDisclaimer
	 */
	public String getOfferDisclaimer() {
		return offerDisclaimer;
	}

	/**
	 * @param offerDisclaimer the offerDisclaimer to set
	 */
	public void setOfferDisclaimer(String offerDisclaimer) {
		this.offerDisclaimer = offerDisclaimer;
	}

	/**
	 * @return String return the offerDisclaimerLabel
	 */
	public String getOfferDisclaimerLabel() {
		return offerDisclaimerLabel;
	}

	/**
	 * @param offerDisclaimerLabel the offerDisclaimerLabel to set
	 */
	public void setOfferDisclaimerLabel(String offerDisclaimerLabel) {
		this.offerDisclaimerLabel = offerDisclaimerLabel;
	}

	/**
	 * @return String return the offerDisclaimerLinkLabel
	 */
	public String getOfferDisclaimerLinkLabel() {
		return offerDisclaimerLinkLabel;
	}

	/**
	 * @param offerDisclaimerLinkLabel the offerDisclaimerLinkLabel to set
	 */
	public void setOfferDisclaimerLinkLabel(String offerDisclaimerLinkLabel) {
		this.offerDisclaimerLinkLabel = offerDisclaimerLinkLabel;
	}
	/*
	 * @return the bestPlan
	 */
	public String getBestPlan() {
		return bestPlan;
	}

	/**
	 * @param bestPlan the bestPlan to set
	 */
	public void setBestPlan(String bestPlan) {
		this.bestPlan = bestPlan;
	}

	/**
	 * @return the planDurationMonthlyLabel
	 */
	public String getPlanDurationMonthlyLabel() {
		return planDurationMonthlyLabel;
	}

	/**
	 * @param planDurationMonthlyLabel the planDurationMonthlyLabel to set
	 */
	public void setPlanDurationMonthlyLabel(String planDurationMonthlyLabel) {
		this.planDurationMonthlyLabel = planDurationMonthlyLabel;
	}

	/**  @return String return the specialPromoSummary
	 */
	public String getSpecialPromoSummary() {
		return specialPromoSummary;
	}

	/**
	 * @param specialPromoSummary the specialPromoSummary to set
	 */
	public void setSpecialPromoSummary(String specialPromoSummary) {
		this.specialPromoSummary = specialPromoSummary;
	}

	/**
	 * @return String return the veriffPlanPromoText
	 */
	public String getVeriffPlanPromoText() {
		return veriffPlanPromoText;
	}

	/**
	 * @param veriffPlanPromoText the veriffPlanPromoText to set
	 */
	public void setVeriffPlanPromoText(String veriffPlanPromoText) {
		this.veriffPlanPromoText = veriffPlanPromoText;
	}

	/**
	 * @return String return the showRecommendedPlan
	 */
	public String getShowRecommendedPlan() {
		return showRecommendedPlan;
	}

	/**
	 * @param showRecommendedPlan the showRecommendedPlan to set
	 */
	public void setShowRecommendedPlan(String showRecommendedPlan) {
		this.showRecommendedPlan = showRecommendedPlan;
	}

	/**
	 * @return the alternateDataUnitForPlanCard
	 */
	public String getAlternateDataUnitForPlanCard() {
		return alternateDataUnitForPlanCard;
	}
	
	/**
	 * @param alternateDataUnitForPlanCard the alternateDataUnitForPlanCard to set
	 */
	public void setAlternateDataUnitForPlanCard(String alternateDataUnitForPlanCard) {
		this.alternateDataUnitForPlanCard = alternateDataUnitForPlanCard;
	}

	/**
	 * @return the vasTooltipContent
	 */
	public String getVasTooltipContent() {
		return vasTooltipContent;
	}
	
	/**
	 * @param vasTooltipContent the vasTooltipContent to set
	 */
	public void setVasTooltipContent(String vasTooltipContent) {
		this.vasTooltipContent = vasTooltipContent;
	}

	/**
	 * @return the vasTerms
	 */
	public String getVasTerms() {
		return vasTerms;
	}
	
	/**
	 * @param vasTerms the vasTerms to set
	 */
	public void setVasTerms(String vasTerms) {
		this.vasTerms = vasTerms;
	}

	public String getPlanDisclaimer() {
		return planDisclaimer;
	}

	public void setPlanDisclaimer(String planDisclaimer) {
		this.planDisclaimer = planDisclaimer;
	}

	public String getPlanFilter() {
		return planFilter;
	}

	public void setPlanFilter(String planFilter) {
		this.planFilter = planFilter;
	}
}
