package com.tracfonecore.core.beans;

import com.fasterxml.jackson.annotation.JsonRawValue;
import com.google.gson.JsonArray;

public class PlanDetailJsonBean {

	private String pageTitle;
	private String pageDescription;
	private String categoryType;
	private String partno;
	private String promotext;
	private String plandatadescription;
	private String plandatalabel;
	private String planname;
	private String plantype;
	private String planservicedays;
	private String pricedescription;
	private String pagePath;
	private String fullPagePath;
	private String smartPayLogoPath;
	private String compareImagePath;
	private String thumbnailImageAssetId;
	private String thumbnailImageAssetAgencyId;
	private String hideRating;
	private String planShortDescription;
	private String planDescription;
	private String showPlanThumbnailImage;
	private String paymentTypeText;
	private String paymentType;
	private String planCardMaxQuantity;
	private String parentCategoryType;
	private String priceAccessibilityLabel;
	private String addLineRibbonText;
	private String addLineAutoRefill;
	private String addLineAutoRefillPrice;
	private String promoColor;
	private String isVasBundlePlan;
	private String vasProductThumbnailImage;
	private String vasProdImgAccessibleText;
	private String vasProdImgSubscript;
	private String vasTermsContent;
	private JsonArray otherSpecs;

	public String getPageTitle() {
		return pageTitle;
	}

	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}

	public String getPageDescription() {
		return pageDescription;
	}

	public void setPageDescription(String pageDescription) {
		this.pageDescription = pageDescription;
	}

	public String getCategoryType() {
		return categoryType;
	}

	public void setCategoryType(String categoryType) {
		this.categoryType = categoryType;
	}

	public String getParentCategoryType() {
		return parentCategoryType;
	}

	public void setParentCategoryType(String parentCategoryType) {
		this.parentCategoryType = parentCategoryType;
	}

	public String getCompareImagePath() {
		return compareImagePath;
	}

	public void setCompareImagePath(String compareImagePath) {
		this.compareImagePath = compareImagePath;
	}

	public String getPagePath() {
		return pagePath;
	}

	public void setPagePath(String pagePath) {
		this.pagePath = pagePath;
	}

	public String getSmartPayLogoPath() {
		return smartPayLogoPath;
	}

	public void setSmartPayLogoPath(String smartPayLogoPath) {
		this.smartPayLogoPath = smartPayLogoPath;
	}

	public String getPlandatadescription() {
		return plandatadescription;
	}

	public void setPlandatadescription(String plandatadescription) {
		this.plandatadescription = plandatadescription;
	}

	public String getPlandatalabel() {
		return plandatalabel;
	}

	public void setPlandatalabel(String plandatalabel) {
		this.plandatalabel = plandatalabel;
	}

	@JsonRawValue
	public String getPlanname() {
		return planname;
	}

	public void setPlanname(String planname) {
		this.planname = planname;
	}

	/**
	 * @return the plantype
	 */
	public String getPlantype() {
		return plantype;
	}

	/**
	 * @param plantype the plantype to set
	 */
	public void setPlantype(String plantype) {
		this.plantype = plantype;
	}

	/**
	 * @return the planservicedays
	 */
	public String getPlanservicedays() {
		return planservicedays;
	}


	public String getPartno() {
		return partno;
	}

	public void setPartno(String partno) {
		this.partno = partno;
	}


	/**
	 * @param planservicedays the planservicedays to set
	 */
	public void setPlanservicedays(String planservicedays) {
		this.planservicedays = planservicedays;
	}

	public String getPricedescription() {
		return pricedescription;
	}

	public void setPricedescription(String pricedescription) {
		this.pricedescription = pricedescription;
	}

	public String getPromotext() {
		return promotext;
	}

	public void setPromotext(String promotext) {
		this.promotext = promotext;
	}

	/**
	 * @return the thumbnailImageAssetId
	 */
	public String getThumbnailImageAssetId() {
		return thumbnailImageAssetId;
	}

	/**
	 * @param thumbnailImageAssetId the thumbnailImageAssetId to set
	 */
	public void setThumbnailImageAssetId(String thumbnailImageAssetId) {
		this.thumbnailImageAssetId = thumbnailImageAssetId;
	}

	/**
	 * @return the thumbnailImageAssetAgencyId
	 */
	public String getThumbnailImageAssetAgencyId() {
		return thumbnailImageAssetAgencyId;
	}

	/**
	 * @param thumbnailImageAssetAgencyId the thumbnailImageAssetAgencyId to set
	 */
	public void setThumbnailImageAssetAgencyId(String thumbnailImageAssetAgencyId) {
		this.thumbnailImageAssetAgencyId = thumbnailImageAssetAgencyId;
	}

	/**
	 * @return the fullPagePath
	 */
	public String getFullPagePath() {
		return fullPagePath;
	}

	/**
	 * @param fullPagePath the fullPagePath to set
	 */
	public void setFullPagePath(String fullPagePath) {
		this.fullPagePath = fullPagePath;
	}

	/**
	 * @return the hideRating
	 */
	public String getHideRating() {
		return hideRating;
	}

	/**
	 * @param hideRating the hideRating to set
	 */
	public void setHideRating(String hideRating) {
		this.hideRating = hideRating;
	}

	/**
	 * @return the planShortDescription
	 */
	public String getPlanShortDescription() {
		return planShortDescription;
	}

	/**
	 * @param planShortDescription the planShortDescription to set
	 */
	public void setPlanShortDescription(String planShortDescription) {
		this.planShortDescription = planShortDescription;
	}

	/**
	 * @return the planDescription
	 */
	public String getPlanDescription() {
		return planDescription;
	}

	/**
	 * @param planDescription the planDescription to set
	 */
	public void setPlanDescription(String planDescription) {
		this.planDescription = planDescription;
	}

	/**
	 * @return the showPlanThumbnailImage
	 */
	public String getShowPlanThumbnailImage() {
		return showPlanThumbnailImage;
	}

	/**
	 * @param hidePlanThumbnailImage the hidePlahidePlanThumbnailImagenBenefits to
	 *                               set
	 */
	public void setShowPlanThumbnailImage(String showPlanThumbnailImage) {
		this.showPlanThumbnailImage = showPlanThumbnailImage;
	}

	public String getPaymentTypeText() {
		return paymentTypeText;
	}

	public void setPaymentTypeText(String paymentTypeText) {
		this.paymentTypeText = paymentTypeText;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	/**
	 * <p>
	 * Fetches planCardMaxQuantity
	 * </p>
	 *
	 * @return the planCardMaxQuantity
	 */
	public String getPlanCardMaxQuantity() {
		return planCardMaxQuantity;
	}

	/**
	 * <p>
	 * Sets planCardMaxQuantity
	 * </p>
	 *
	 * @param planCardMaxQuantity - the planCardMaxQuantity to set
	 */
	public void setPlanCardMaxQuantity(String planCardMaxQuantity) {
		this.planCardMaxQuantity = planCardMaxQuantity;
	}

	/**
	 * <p>
	 * Fetches priceAccessibilityLabel
	 * </p>
	 *
	 * @return the priceAccessibilityLabel
	 */
	public String getPriceAccessibilityLabel() {
		return priceAccessibilityLabel;
	}

	/**
	 * <p>
	 * Sets priceAccessibilityLabel
	 * </p>
	 *
	 * @param priceAccessibilityLabel the priceAccessibilityLabel to set
	 */
	public void setPriceAccessibilityLabel(String priceAccessibilityLabel) {
		this.priceAccessibilityLabel = priceAccessibilityLabel;
	}

	/**
	 * @return the addLineRibbonText
	 */
	public String getAddLineRibbonText() {
		return addLineRibbonText;
	}

	/**
	 * @param addLineRibbonText the addLineRibbonText to set
	 */
	public void setAddLineRibbonText(String addLineRibbonText) {
		this.addLineRibbonText = addLineRibbonText;
	}

	/**
	 * @return the addLineAutoRefill
	 */
	public String getAddLineAutoRefill() {
		return addLineAutoRefill;
	}

	/**
	 * @param addLineAutoRefill the addLineAutoRefill to set
	 */
	public void setAddLineAutoRefill(String addLineAutoRefill) {
		this.addLineAutoRefill = addLineAutoRefill;
	}

	/**
	 * @return the addLineAutoRefillPrice
	 */
	public String getAddLineAutoRefillPrice() {
		return addLineAutoRefillPrice;
	}

	/**
	 * @param addLineAutoRefillPrice the addLineAutoRefillPrice to set
	 */
	public void setAddLineAutoRefillPrice(String addLineAutoRefillPrice) {
		this.addLineAutoRefillPrice = addLineAutoRefillPrice;
	}

	/**
	 * @return the promoColor
	 */
	public String getPromoColor() {
		return promoColor;
	}

	/**
	 * @param promoColor the promoColor to set
	 */
	public void setPromoColor(String promoColor) {
		this.promoColor = promoColor;
	}


	public String getIsVasBundlePlan() {
		return isVasBundlePlan;
	}

	public void setIsVasBundlePlan(String isVasBundlePlan) {
		this.isVasBundlePlan = isVasBundlePlan;
	}

	public String getVasProductThumbnailImage() {
		return vasProductThumbnailImage;
	}

	public void setVasProductThumbnailImage(String vasProductThumbnailImage) {
		this.vasProductThumbnailImage = vasProductThumbnailImage;
	}

	public String getVasProdImgAccessibleText() {
		return vasProdImgAccessibleText;
	}

	public void setVasProdImgAccessibleText(String vasProdImgAccessibleText) {
		this.vasProdImgAccessibleText = vasProdImgAccessibleText;
	}

	public String getVasProdImgSubscript() {
		return vasProdImgSubscript;
	}

	public void setVasProdImgSubscript(String vasProdImgSubscript) {
		this.vasProdImgSubscript = vasProdImgSubscript;
	}

	public String getVasTermsContent() {
		return vasTermsContent;
	}

	public void setVasTermsContent(String vasTermsContent) {
		this.vasTermsContent = vasTermsContent;
	}

	public JsonArray getOtherSpecs() {
		return otherSpecs;
	}

	public void setOtherSpecs(JsonArray otherSpecs) {
		this.otherSpecs = otherSpecs;
	}

}
