package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.tracfonecore.core.beans.LinkBean;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.BrandSpecificConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.RefillRegisterModel;
import com.tracfonecore.core.models.RefillRegisterOptionsModel;
import com.tracfonecore.core.utils.ConfigurationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { RefillRegisterModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/refillregister", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class RefillRegisterModelImpl implements RefillRegisterModel {
	
	@Self
	private SlingHttpServletRequest request;

	@Inject
    private ApplicationConfigService applicationConfigService;
	
	@Inject
	BrandSpecificConfigService brandSpecificConfigService;

    @Inject
    private Page currentPage;
	
	@ValueMapValue
	private String heading;
	
	@ValueMapValue
	private String subheading;

	@ValueMapValue
	private String purchasePagePath;

	@ValueMapValue
	private String loginPagePath;

	@ValueMapValue
	private String byopEsnPagePath;
	
	@ChildResource
	private List<RefillRegisterOptionsModel> refillConfig;
	
    private List<LinkBean> options = Collections.emptyList();
    LinkBean linkBean;

	@ValueMapValue
	private String modalTitle;

	@ValueMapValue
	private String modalDescription;

	@ValueMapValue
	private String modalAltPlanLabel;
	
	@ValueMapValue @Default(booleanValues = false)
	private boolean hideRibbonHeadingContainer;
	
	@ValueMapValue @Default(values = "Learn More")
	private String modalName;
	
    @ValueMapValue
    private Boolean showpromocode;
	
	@Inject
	private Resource resource;
	
	private String brand;
	
	private Map<String, Object> propertyValueMap;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RefillRegisterModelImpl.class);
	
    @PostConstruct
    private void initModel() {
		String[] properties = {CommerceConstants.BRANDNAME};
        this.propertyValueMap = CommerceUtil.getMultiplePagePropertyValue(currentPage, getHomePageLevel(), properties);
        this.brand = CommerceUtil.getPropertyValue(this.propertyValueMap, CommerceConstants.BRANDNAME);
    }
    /**
     * <p>Populates a list with all the multi-options</p>
     *
     * @param it - iterator of the parent node
     * @param multiFieldData - list in which the multi options data needs to be set
     */

    private void setMultiFieldItems(Iterator<Resource> it, List<LinkBean> multiFieldData) {
        LOGGER.debug("Entering setMultiFieldItems method");
        while (it.hasNext()) {
            linkBean = new LinkBean();
            Resource grandChild = it.next();
            linkBean.setHeading(grandChild.getValueMap().get("option", String.class));
            linkBean.setLinkText(grandChild.getValueMap().get("placeholder", String.class));
            linkBean.setLinkAltText(grandChild.getValueMap().get("description", String.class));

            multiFieldData.add(linkBean);
        }

        LOGGER.debug("Exiting setMultiFieldItems method ");
    }

	/**
     * @return String - exported Type
     */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
	/**
     * @return String - heading
     */
	@Override
	public String getHeading() {
		return heading;
	}
	
	/**
     * @return String - subheading
     */
	@Override
	public String getSubheading() {
		return subheading;
	}

	/**
     * @return String - purchasePagePath
     */
	@Override
	public String getPurchasePagePath() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), this.purchasePagePath);
	}

	/**
     * @return String - loginPagePath
     */
	@Override
	public String getLoginPagePath() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), this.loginPagePath);
	}
		
	/**
	 * @return the options
	 */
	@Override
	public List<RefillRegisterOptionsModel> getRefillConfig() {
		return new ArrayList<>(refillConfig);
	}

	/**
     * @return String - modalTitle
     */
	@Override
	public String getModalTitle() {
		return modalTitle;
	}
	
	/**
     * @return String - modalDescription
     */
	@Override
	public String getModalDescription() {
		return modalDescription;
	}

	/**
     * @return String - modalAltPlanLabel
     */
	@Override
	public String getModalAltPlanLabel() {
		return modalAltPlanLabel;
	}

	/**
	 * @return the hideRibbonHeadingContainer
	 */
	@Override
	public boolean getHideRibbonHeadingContainer() {
		return hideRibbonHeadingContainer;
	}
	
	/**
     * @return String - modal name
     */
	@Override
	public String getModalName() {
		String modal_Name=ApplicationUtil.getLowerCaseWithHyphen(modalName);
		return (modal_Name+ ApplicationConstants.HYPHEN + ApplicationConstants.MODAL);
	}


	@Override
	public Boolean getShowPromoCode() {
		return showpromocode;
	}
	
	@Override
	public String getShowPromo() {
		String enablePromoCodeFlag = null;
		String[] enableActivationRefillPromoCodeArray = applicationConfigService.enableActivationRefillPromoCode();
		String brandName = CommerceUtil.getBrandValue(currentPage, getHomePageLevel());
		if (StringUtils.isNotBlank(brandName) && enableActivationRefillPromoCodeArray != null) {
			enablePromoCodeFlag = ConfigurationUtil.getConfigValue(enableActivationRefillPromoCodeArray, brandName);
		}
		return enablePromoCodeFlag;
	}
	
	/**
	 * <p>
	 * Fetches home page level property from config
	 * </p>
	 * 
	 * @return int - homePageLevel
	 */
	private int getHomePageLevel() {
		return applicationConfigService.getHomePageLevel();
	}

	/**
	 * Get the cusg enabling check
	 *
	 * @return String - check for cusg enable from home page properties
	 */
	@Override
	public String getCusgEnable() {
		String cusgCheck = (CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(), CommerceConstants.ENABLE_CUSG) != null) ? 
			CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(), CommerceConstants.ENABLE_CUSG).toString() : "";
		return cusgCheck;
	}

	/**
	 * <p>
	 * Fetches ReCaptcha SiteKey property from config
	 * </p>
	 *
	 * @return String[] - reCaptchaSiteKey
	 */
	@Override
	public String getReCaptchaSiteKey() {
		return ConfigurationUtil.getConfigValue(applicationConfigService.getReCaptchaSiteKey(), brand);
	}

	/**
     * @return String - byopEsnPagePath
     */
	@Override
	public String getByopEsnPagePath() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), this.byopEsnPagePath);
	}
	
	/**
	 * <p>Fetches enableMultilinePlan value from config</p>
	 *
	 * @return String - enableMultilinePlan
	 */
	@Override
	public String getEnableMultilinePlan() {
		PageManager pm = resource.getResourceResolver().adaptTo(PageManager.class);
		Page currentPage = pm.getContainingPage(resource);
		return ConfigurationUtil.getConfigValue(brandSpecificConfigService.enableMultilinePlans(), CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}

}
