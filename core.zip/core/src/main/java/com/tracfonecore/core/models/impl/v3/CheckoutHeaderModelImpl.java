/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl.v3;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.CheckoutHeaderModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CheckoutHeaderModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/structure/checkoutheader/v3/checkoutheader", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CheckoutHeaderModelImpl extends com.tracfonecore.core.models.impl.v1.CheckoutHeaderModelImpl implements CheckoutHeaderModel {

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String componentVersion;

    @Override
    public String getComponentVersion() {
        return StringUtils.isNotBlank(componentVersion) ?  componentVersion: "v3";
    }
}