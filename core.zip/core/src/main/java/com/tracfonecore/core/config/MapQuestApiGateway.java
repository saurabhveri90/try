package com.tracfonecore.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

    @ObjectClassDefinition(name = "MapQuest Api Gateway paths", description = "Paths for MapQuest Api Gateway are added here")
    public @interface MapQuestApiGateway {

        @AttributeDefinition(name = "MapQuest Api Domain",description = "Configuration for API Domain", type = AttributeType.STRING)
        String getApiDomain() default "https://www.mapquestapi.com/";

        @AttributeDefinition(name = "Reverse Path for MapQuest api",description = "Reverse Path for MapQuest api", type = AttributeType.STRING)
        String getReversePath() default "geocoding/v1/reverse";

        @AttributeDefinition(name = "Address Path for MapQuest api",description = "Configuration for Address Path", type = AttributeType.STRING)
        String getPath() default "geocoding/v1/address";

		@AttributeDefinition(name = "API Key for MapQuest", description = "Configuration for API Key")
		String[] getApiKey() default { "STRAIGHT_TALK:IQWpZsttQHDa5BjHFlNpV3n25HEuOZFU",
				"TRACFONE:Gmjtd|lu6zn1ua2d,7s=o5-l67n9" };

        @AttributeDefinition(name = "Configuration for Setting Cookie time",description = "Configuration for setting up cookie timeout limit", type = AttributeType.INTEGER)
        int getCookieTimeout() default 86400;

        @AttributeDefinition(name = "Path for MapQuest Radius search api",description = "Configuration for MapQuest Radius API", type = AttributeType.STRING)
        String getRadiusPath() default "search/v2/radius";
        
        @AttributeDefinition(name = "Path for MapQuest rectangle search api",description = "Configuration for MapQuest rectangle search API", type = AttributeType.STRING)
        String getRectanglePath() default "search/v2/rectangle";
        
        @AttributeDefinition(name = "Path for MapQuest route api",description = "Configuration for MapQuest Route API", type = AttributeType.STRING)
        String getRoutePath() default "directions/v2/route";
        
        @AttributeDefinition(name = "Path for MapQuest icon",description = "Configuration for MapQuest Icon", type = AttributeType.STRING)
        String getMapIcon() default "staticmap/geticon";
        
        @AttributeDefinition(name = "Distance unit",description = "Configuration for Disatnce unit", type = AttributeType.STRING)
        String getUnits() default "dm";
        
		@AttributeDefinition(name = "Field List for Map", description = "Configuration for MapQuest field list", type = AttributeType.STRING)
		String[] getFieldList() default {
				"STRAIGHT_TALK:storeName%2CstoreAdd%2CstoreCity%2CstoreState%2CstoreZip%2CstorePhone%2Cmqap_geography",
				"TRACFONE:DAPID%2CNAME%2CADDRESS%2CCITY%2CSTATE%2CZIPCODE%2CPHONE%2Cmqap_geography%2CSTORETYPE%2CISEXCLUSIVE%2CISSPECIALTY%2CLINK%2CSERVICEDELIVERY%2CSERVICEAPPOINTMENT%2CSERVICEPAYMENTTYPES%2CSERVICEDELIVERYTYPES%2CBRANDTF" };

		@AttributeDefinition(name = "Table name of MapQuest with Brand Filter - Default", description = "Configuration for MapQuest Table - Table name of MapQuest with Brand Filter - Default", type = AttributeType.STRING)
		String[] getTableName() default { "STRAIGHT_TALK:mqap.36750_st_public|||",
				"TRACFONE:mqap.37706_all_brands_CashForService|%22BRANDTF%22=?|true%2C|" };

		@AttributeDefinition(name = "Table name of MapQuest with Exclusive Stores Filter", description = "Configuration for MapQuest Table - Table name of MapQuest with Exclusive Stores Filter", type = AttributeType.STRING)
		String[] getIsExclusiveStoreFilter() default { "STRAIGHT_TALK:mqap.36750_st_public|||",
				"TRACFONE:mqap.37706_all_brands_CashForService|%22BRANDTF%22=? AND %22ISEXCLUSIVE%22=?|true%2Ctrue|" };
				
		@AttributeDefinition(name = "Table name of MapQuest with Authorized Stores Filter", description = "Configuration for MapQuest Table - Table name of MapQuest with Authorized Stores Filter", type = AttributeType.STRING)
		String[] getIsAuthorizedStoreFilter() default { "STRAIGHT_TALK:mqap.36750_st_public|||",
				"TRACFONE:mqap.37706_all_brands_CashForService|%22BRANDTF%22=? AND %22STORETYPE%22=?|true%2CFullService|" };
						
		@AttributeDefinition(name = "Table name of MapQuest with National Retailers Filter", description = "Configuration for MapQuest Table - Table name of MapQuest with National Retailers Filter", type = AttributeType.STRING)
		String[] getIsNationalRetailerStoreFilter() default { "STRAIGHT_TALK:mqap.36750_st_public|||",
				"TRACFONE:mqap.37706_all_brands_CashForService|%22BRANDTF%22=? AND %22STORETYPE%22=?|true%2CNationalRetailer|" };
								
		@AttributeDefinition(name = "Table name of MapQuest with Home Delivery Filter", description = "Table name of MapQuest with Home Delivery Filter", type = AttributeType.STRING)
		String[] getIsHomeDeliveryStoreFilter() default { "STRAIGHT_TALK:mqap.36750_st_public|||",
				"TRACFONE:mqap.37706_all_brands_CashForService|%22BRANDTF%22=? AND %22SERVICEDELIVERY%22=?|true%2Ctrue|" };
}



