
package com.tracfonecore.core.models;

import java.util.List;
import java.util.Map;

import com.adobe.cq.export.json.ComponentExporter;
import com.tracfonecore.core.beans.PhoneCardBean;
import com.fasterxml.jackson.annotation.JsonProperty;

public interface PhoneCardModel extends ComponentExporter {
	
	 /**
     * Get ratings of the product(i.e. "0 to 5")
     * @return Ratings
     */
	public String getRating();
	
	/**
     * Get reviews of the product
     * @return Reviews
     */
    public String getReviews();
    
    /**
     * Get variants of the product(i.e. color)
     * @return List<PhoneCardBean>
     */
    public List<PhoneCardBean> getSKUs();
    
    /**
     * Get image of the product
     * @return Ratings
     */
    public String getThumbnail();
    
    /**
	 * <p>Fetches queryString for the price api call</p>
	 * 
	 * @return String - queryString 
	 */
   	public String getQueryString();
   	
   	/**
	 * <p>Method to return skuid</p>
	 * 
	 * @return String - skuId
	 */
	public String getSkuId() ;
	
	/**
	 * <p>Method to return product name like iphone</p>
	 * 
	 * @return String - name
	 */
	public String getName() ;
	 /**
	 * <p>Format rating and remove trailing zeros </p>
	 * 
	 * @return String - rating without trailing zero
	 * 
	 */
	public String getAccessibilityRating();
	/**
	 * <p>
	 * Method to return BreakPoints
	 * </p>
	 * 
	 * @return String
	 */
	public String getBreakPoints() ;
	/**
	 * <p>
	 * Method to return Price Api domain
	 * </p>
	 * 
	 * @return String
	 */
	public String getApiDomain() ;
	/**
	 * <p>
	 * Method to return Price Api Path
	 * </p>
	 * 
	 * @return String
	 */
	public String getPriceApiPath() ;

	/**
	* @return the selection
    */
	public String getSelection();
 	
	/**
	 * Checks if the phone card is first in carousel then return animation timing.
	 * 
	 * @return String - animation value
	 */
	public String getAnimationValue();
	
	/**
	  * <p>
	 * Fetches the export child items
	 * </p>
	 *
	 * 
	 * @return Map<String, ? extends ComponentExporter> - the export child items
	 */
	public Map<String, ? extends ComponentExporter> getItems();
	
	/**
	 * <p>
	 * Method to return exporter type
	 * </p>
	 * 
	 * @return String
	 */
	@Override
	public String getExportedType();
	/**
	 * <p>
	 * Returns ctaLink 
	 * </p>
	 * 
	 * @return String - ctaLink
	 */
	public String getCtaLink();
	/**
	 *<p>Fetches promotext</p>
	 *
	 * @return the promotext
	 */
	public String getPromotext() ;

	/**
	 *<p>Fetches rrcheck</p>
	 *
	 * @return the rrcheck
	 */
	public String getRrcheck() ;
	
	/**
	 *<p>Fetches smartpayIcon</p>
	 *
	 * @return the smartpayIcon
	 */
	public String getSmartpayIcon() ;

	/**
	 *<p>Fetches logoalt</p>
	 *
	 * @return the logoalt
	 */
	public String getLogoalt() ;

	/**
	 *<p>Fetches expriceprefix</p>
	 *
	 * @return the expriceprefix
	 */
	public String getExpriceprefix();

	/**
 	* <p>
	* Check to hide  Bazaar Voice Ratings
	* </p>
	* 
	* @return String - disableBazaarVoiceRatings
	*/
	@JsonProperty("disableBazaarVoiceRatings")
	public Boolean getDisableBazaarVoiceRatings(); 

	/**
	 *<p>Fetches expriceduration</p>
	 *
	 * @return the expriceduration
	 */
	public String getExpriceduration();

	/**
	 *<p>Fetches expricesuffix</p>
	 *
	 * @return the expricesuffix
	 */
	public String getExpricesuffix() ;
	/**
	 *<p>Fetches pricecaption</p>
	 *
	 * @return the pricecaption
	 */
	public String getPricecaption();
	/**
	 *<p>Fetches type</p>
	 *
	 * @return the type
	 */
	public String getType();
	/**
	 *<p>Fetches pdpPagePath</p>
	 *
	 * @return the pdpPagePath
	 */
	public String getPdpPagePath();
	/**
	 * <p>
	 * Method to return path of phone image related to first SKU only
	 * </p>
	 * 
	 * @return String thumbnailPath
	 */
	public String getImagePath();
	
	/**
	 * <p>
	 * Fetches productID
	 * </p>
	 *
	 * @return the productID
	 */
	public int getProductID();

	/**
	 * <p>
	 * Fetches partNumber
	 * </p>
	 *
	 * @return the partNumber
	 */
	public String getPartNumber();

	/**
	 * <p>
	 * Fetches categoryType
	 * </p>
	 *
	 * @return the categoryType
	 */
	public String getCategoryType();
	
	/**
	 * <p>
	 * Fetches productType
	 * </p>
	 *
	 * @return the productType
	 */
	String getProductType();
	
	/**
	 *  <p>
	 * Fetches phoneCardButtonLabel
	 * </p>
	 * @return the phoneCardButtonLabel
	 */
	public String getPhoneCardButtonLabel();
	/**
	 *  <p>
	 * Fetches enableButtonForProductCards
	 * </p>
	 * @return the enableButtonForProductCards
	 */
	public String getEnableButtonForProductCards();
	/**
	 *<p>Fetches orderIndex</p>
	 *
	 * @return the orderIndex
	 */
	public String getOrderIndex();

	/**
	 * <p>
	 * Fetches the DCOT Promo flag for a devic
	 * </p>
	 *
	 * @return the DCOT Promo flag for a device
	 */
	public String getDcotPromoOffer();

	/**
	 * <p>
	 * Fetches the DCOT Model Name for a devic
	 * </p>
	 *
	 * @return the DCOT Model Name for a device
	 */
	public String getDcotModelName();

	/**
	 * <p>
	 * Fetches the DCOT Monthly Discount for a devic
	 * </p>
	 *
	 * @return the DCOT Monthly Discount for a device
	 */
	public String getDcotMonthlyDisc();

	/**
	 * <p>
	 * Fetches the DCOT Offer End Date for a devic
	 * </p>
	 *
	 * @return the DCOT Offer End Date for a device
	 */
	public String getDcotOfferEndDt();

	/**
	 * <p>
	 * Fetches the DCOT Paid Amount for a devic
	 * </p>
	 *
	 * @return the DCOT Paid Amount for a device
	 */
	public String getDcotPaidAmt();

	/**
	 * <p>
	 * Fetches the DCOT Saving for a devic
	 * </p>
	 *
	 * @return the DCOT Saving for a device
	 */
	public String getDcotSaving();

	/**
	 * <p>
	 * Fetches enableDcotPromoOffers
	 * </p>
	 *
	 * @return the enableDcotPromoOffers
	 */
	public String getEnableDcotPromoOffers();

	/**
	 * <p>
	 * Fetches dcotPromoTextPLP
	 * </p>
	 *
	 * @return the dcotPromoTextPLP
	 */
	public String getDcotPromoTextPLP();

	/**
	 * <p>
	 * Fetches dcotPromoDescPLP
	 * </p>
	 *
	 * @return the dcotPromoDescPLP
	 */
	public String getDcotPromoDescPLP();

	/**
	 * <p>
	 * Fetches veriffPromoTextPLP
	 * </p>
	 *
	 * @return the veriffPromoTextPLP
	 */
	public String getVeriffPromoTextPLP();

	/**
	 * <p>
	 * Fetches veriffPromoDescPLP
	 * </p>
	 *
	 * @return the veriffPromoDescPLP
	 */
	public String getVeriffPromoDescPLP();


	/**
	 * <p>
	 * Fetches portInPromoTextPLP
	 * </p>
	 *
	 * @return the portInPromoTextPLP
	 */
	public String getPortInPromoTextPLP();

	/**
	 * <p>
	 * Fetches portInPromoDescPLP
	 * </p>
	 *
	 * @return the portInPromoDescPLP
	 */
	public String getPortInPromoDescPLP();


	/**
	 * <p>
	 * Fetches activationPromoTextPLP
	 * </p>
	 *
	 * @return the activationPromoTextPLP
	 */
	public String getActivationPromoTextPLP();

	/**
	 * <p>
	 * Fetches activationPromoDescPLP
	 * </p>
	 *
	 * @return the activationPromoDescPLP
	 */
	public String getActivationPromoDescPLP();

}