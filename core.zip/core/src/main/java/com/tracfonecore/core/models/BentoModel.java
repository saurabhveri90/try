package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

public interface BentoModel extends ComponentExporter {

	@JsonProperty("card1heading")
	public String getCard1heading();

	@JsonProperty("bentoHeader")
	public String getBentoHeader();

	@JsonProperty("card1SubHeading")
	public String getCard1SubHeading();

	@JsonProperty("card1Image")
	public String getCard1Image();

	@JsonProperty("card1ImageAlt")
	public String getCard1ImageAlt();

	@JsonProperty("card1TooltipMsg")
	public String getCard1TooltipMsg();

	@JsonProperty("card1tooltipLogo")
	public String getCard1tooltipLogo();

	@JsonProperty("card2heading")
	public String getCard2heading();

	@JsonProperty("card2SubHeading")
	public String getCard2SubHeading();

	@JsonProperty("card2Image")
	public String getCard2Image();

	@JsonProperty("card2ImageAlt")
	public String getCard2ImageAlt();

	@JsonProperty("card2TooltipMsg")
	public String getCard2TooltipMsg();

	@JsonProperty("card2tooltipLogo")
	public String getCard2tooltipLogo();

	@JsonProperty("card3heading")
	public String getCard3heading();

	@JsonProperty("card3SubHeading")
	public String getCard3SubHeading();

	@JsonProperty("card3BgImage")
	public String getCard3BgImage();

	@JsonProperty("card3Image")
	public String getCard3Image();

	@JsonProperty("card3ImageAlt")
	public String getCard3ImageAlt();

	@JsonProperty("card3TooltipMsg")
	public String getCard3TooltipMsg();

	@JsonProperty("card3TooltipLogo")
	public String getCard3tooltipLogo();

	@JsonProperty("card4heading")
	public String getCard4heading();

	@JsonProperty("card4SubHeading")
	public String getCard4SubHeading();

	@JsonProperty("card4Image")
	public String getCard4Image();

	@JsonProperty("card4ImageAlt")
	public String getCard4ImageAlt();

	@JsonProperty("card4TooltipMsg")
	public String getCard4TooltipMsg();

	@JsonProperty("card4tooltipLogo")
	public String getCard4tooltipLogo();

	@JsonProperty("card5heading")
	public String getCard5heading();

	@JsonProperty("card5SubHeading")
	public String getCard6SubHeading();

	@JsonProperty("card5TooltipMsg")
	public String getCard5TooltipMsg();

	@JsonProperty("card5tooltipLogo")
	public String getCard5tooltipLogo();

	@JsonProperty("card6heading")
	public String getCard6heading();

	@JsonProperty("card6SubHeading")
	public String getCard5SubHeading();

	@JsonProperty("card6TooltipMsg")
	public String getCard6TooltipMsg();

	@JsonProperty("card6tooltipLogo")
	public String getCard6tooltipLogo();

	@JsonProperty("card1background")
	public String getCard1background();

	@JsonProperty("card2background")
	public String getCard2background();

	@JsonProperty("card3background")
	public String getCard3background();

	@JsonProperty("card4background")
	public String getCard4background();

	@JsonProperty("card5background")
	public String getCard5background();

	@JsonProperty("card6background")
	public String getCard6background();

	@JsonProperty("card6font")
	public String getCard6font();

	@JsonProperty("card5font")
	public String getCard5font();

	@JsonProperty("card4font")
	public String getCard4font();

	@JsonProperty("card3font")
	public String getCard3font();

	@JsonProperty("card2font")
	public String getCard2font();

	@JsonProperty("card1font")
	public String getCard1font();

}
