package com.tracfonecore.core.gui.tfproductfield.models;

import com.adobe.cq.export.json.ComponentExporter;

public interface ColumnItemModel extends ComponentExporter {
	public String getName();
	public String getId();
	public String getPartNo();
	public String getSelectionId();
	public boolean hasChildren();
	public String getPath();
	public String getThumbnailImageUrl();
}
