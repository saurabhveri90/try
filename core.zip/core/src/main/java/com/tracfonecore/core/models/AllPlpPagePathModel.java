package com.tracfonecore.core.models;

import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.tracfonecore.core.utils.ApplicationUtil;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Model(adaptables = { Resource.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class AllPlpPagePathModel {
	
	@Self
	private Resource resource;
	
	@SlingObject
	private ResourceResolver resourceResolver;
	
	@ValueMapValue
	private String accessoriesPagePath;
	
	@ValueMapValue
	private String plansPagePath;
	
	@ValueMapValue
	private String phonesPagePath;
	
	@ValueMapValue
	private String devicesPagePath;
	
	@ValueMapValue
	private String tabletSimPagePath;
	
	@ValueMapValue
	private String phoneSimPagePath;

	@ValueMapValue
	private String watchesPagePath;
	
	@JsonGetter("accessory")
	public ObjectNode getAccessory() {
		return getPlpPagePathWithCatgoryId(accessoriesPagePath);
	}
	
	@JsonGetter("plan")
	public ObjectNode getPlan() {
		return getPlpPagePathWithCatgoryId(plansPagePath);
	}
	
	@JsonGetter("phone")
	public ObjectNode getPhone() {
		return getPlpPagePathWithCatgoryId(phonesPagePath);
	}

	@JsonGetter("wearables")
	public ObjectNode getWatch() {
		return getPlpPagePathWithCatgoryId(watchesPagePath);
	}
	
	@JsonGetter("device")
	public ObjectNode getDevice() {
		return getPlpPagePathWithCatgoryId(devicesPagePath);
	}
	
	@JsonGetter("tabletsim")
	public ObjectNode getTabletsim() {
		return getPlpPagePathWithCatgoryId(tabletSimPagePath);
	}
	
	@JsonGetter("phonesim")
	public ObjectNode getPhonesim() {
		return getPlpPagePathWithCatgoryId(phoneSimPagePath);
	}
	
	private ObjectNode getPlpPagePathWithCatgoryId(String plpPagePath) {
		ObjectMapper mapper = new ObjectMapper();
		ObjectNode objetNode = mapper.createObjectNode();
		objetNode.put("path", plpPagePath);
		objetNode.put("plpPageFinalPath", getFinalPagePath(plpPagePath));
		objetNode.put("categoryId", getCategoryIdByPath(plpPagePath));
		return objetNode;
	}
	
	private String getCategoryIdByPath(String plpPagePath){
		PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
		Page currentPage = pageManager.getContainingPage(plpPagePath);
		String categoryId = Optional.ofNullable(currentPage).filter(Objects::nonNull)
				.map(Page::getProperties).map(vm -> vm.get("categoryId",String.class)).orElse("");
		if (StringUtils.isBlank(categoryId)) {
			categoryId = Optional.ofNullable(currentPage).map(Page :: getParent).filter(Objects::nonNull)
					.map(Page::getProperties).map(vm -> vm.get("categoryId",String.class)).orElse("");
		}
		return categoryId;	
	} 
	
	private String getFinalPagePath(String inputPath) {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), inputPath);
	}
}
