package com.tracfonecore.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Tracfone API Gateway Service", description = "Paths for Tracfone Api Gateway are added here")
public @interface TracfoneApiGateway {

        @AttributeDefinition(name = "Tracfone API Domain", description = "Configuration for API Domain", type = AttributeType.STRING)
        String getApiDomain() default "https://sit-apigateway.tracfone.com/api/sitf";

        @AttributeDefinition(name = "Tracfone FR API Domain", description = "Configuration for FR API Domain", type = AttributeType.STRING)
        String getFRApiDomain() default "https://sit-apigateway.tracfone.com";

        @AttributeDefinition(name = "Tracfone FR Access Path", description = "Configuration for FR Access API Path", type = AttributeType.STRING)
        String getFRApiAccessPath() default "/api/site/valueiam/vzauth/oauth2/realms/tf/authorize";

        @AttributeDefinition(name = "Tracfone FR Authenticate Path", description = "Configuration for FR Authenticate API Path", type = AttributeType.STRING)
        String getFRApiAuthPath() default "/api/site/valueiam-tf/vzauth/json/realms/tf/authenticate";      

        @AttributeDefinition(name = "Tracfone API Token Path", description = "Configuration for Token Path ", type = AttributeType.STRING)
        String getFRApiTokenPath() default "/api/site/resource-authorization/services/digital-access-token";
        
        @AttributeDefinition(name = "Tracfone FR Session Path", description = "Configuration for FR sessions API Path", type = AttributeType.STRING)
        String getFRApiSessionsPath() default "/api/site//valueiam-tf/vzauth/json/realms/tf/sessions"; 
        
        @AttributeDefinition(name = "Tracfone FR End Session Path", description = "Configuration for FR endSession API Path", type = AttributeType.STRING)
        String getFRApiEndSessionPath() default "/api/site//valueiam-tf/vzauth/oauth2/realms/tf/connect/endSession";  
        
        @AttributeDefinition(name = "Tracfone FR Revoke Path", description = "Configuration for FR revoke API Path", type = AttributeType.STRING)
        String getFRApiRevokePath() default "/api/site//valueiam-tf/vzauth/oauth2/realms/tf/token/revoke";
        
        @AttributeDefinition(name = "Tracfone FR Userinfo Path", description = "Configuration for FR userinfo API Path", type = AttributeType.STRING)
        String getFRApiUserInfoPath() default "/api/site/valueiam-tf/vzauth/oauth2/realms/tf/userinfo";

    @AttributeDefinition(name = "API ClientId", description = "Configuration for API ClientId", type = AttributeType.STRING)
    String[] getApiClientId() default { "STRAIGHT_TALK:15a86354-7c65-46f0-ac3a-f0cc63b5219c",
            "TRACFONE:7db825bf-58e5-4338-b01c-731755272735" };
	@AttributeDefinition(name = "Legacy API ClientId", description = "Configuration for Legacy API ClientId", type = AttributeType.STRING)
        String[] getLegacyApiClientId() default { "SIMPLE_MOBILE:SMWebMyAcct_CCU" };

        @AttributeDefinition(name = "ForgeRock API ClientId", description = "Configuration for ForgeRock API ClientId", type = AttributeType.STRING)
        String[] getForgeRockApiClientId() default { "STRAIGHT_TALK:15a86354-7c65-46f0-ac3a-f0cc63b5219c",
                        "TRACFONE:f40e586f01f7e7fc0011286dec161fce" };

	@AttributeDefinition(name = "Nuance Order Confirmation Page Id", description = "Nuance Order confirmation Page Id", type = AttributeType.STRING)
    String[] getNuanceOrderConfirmationPageId() default { "STRAIGHT_TALK:38448995", "TRACFONE:38451478",
            "TOTAL_WIRELESS:38453182" };

    @AttributeDefinition(name = "API Source System", description = "Configuration for API Source System", type = AttributeType.STRING)
    String getApiSourceSystem() default "WEB";

    @AttributeDefinition(name = "API Party Id", description = "Configuration for API Party Id", type = AttributeType.STRING)
    String[] getApiPartyId() default { "STRAIGHT_TALK:STWEB", "TRACFONE:TFWEB" };

    @AttributeDefinition(name = "API Language", description = "Configuration for API Language")
    String[] getApiLanguage();

    @AttributeDefinition(name = "Google Maps API URL", description = "Google Maps API URL", type = AttributeType.STRING)
    String getGoogleMapsApiDomain() default "https://www.google.com/maps/search/?api=1&query=";

    @AttributeDefinition(name = "Price API", description = "URI of price api")
    String getPriceApiPath() default "/catalog-mgmt/productoffering/price";

    @AttributeDefinition(name = "Category API", description = "URI of category api")
    String getCategoryApiPath() default "/catalog-mgmt/product-offerings";

    @AttributeDefinition(name = "Cart API", description = "URI of cart api")
    String getCartApiPath() default "/cart-mgmt/shoppingCart";

    @AttributeDefinition(name = "Change Lease API", description = "URI of change lease api")
    String getChangeLeaseApiPath() default "/order-mgmt/change-device";

    @AttributeDefinition(name = "Order Manage API", description = "URI of Manage Order(Add/Remove Promocode)")
    String getOrderApiPath() default "/order-mgmt/manage-order";

    @AttributeDefinition(name = "Cart Email API", description = "URI of Cart Email API")
    String getEmailCartApiPath() default "/communication-mgmt/email-my-cart";

    @AttributeDefinition(name = "Recommended Products API", description = "URI of Recommended Products(Accessories/Plans)")
    String getRecommendedProductsAPIPath() default "/catalog-mgmt/product-offerings";

    @AttributeDefinition(name = "Extended Plans API", description = "URI of Extended Plans")
    String getExtendedPlansAPIPath() default "/catalog-mgmt/product-offerings";

    @AttributeDefinition(name = "Plan PDP Servlet", description = "URI of Plan PDP Servlet")
    String getPlanPDPServletPath() default "/content/straighttalk/us/en/plans-and-services/plan.plpjson.html";

    @AttributeDefinition(name = "Inventory API", description = "URI of inventory api")
    String getInventoryApiPath() default "/inventory-mgmt/inventoryavailability";

    @AttributeDefinition(name = "Marketing API", description = "URI of marketing api")
    String getMarketingApiPath() default "/catalog-mgmt/marketing-segment";

    @AttributeDefinition(name = "Notify API", description = "URI of notify api")
    String getNotifyApiPath() default "/communication-mgmt/out-of-stock-notify";

    @AttributeDefinition(name = "Upgrade Eligibility API", description = "URI to check upgrade eligibility")
    String getUpgradeEligibilityApiPath() default "/service-mgmt/check-upgrade-eligibility";

    @AttributeDefinition(name = "Upgrade Eligibility RO API", description = "URI to check upgrade eligibility RO")
    String getUpgradeEligibilityROApiPath() default "/service-mgmt/check-upgrade-eligibilityRO";

    @AttributeDefinition(name = "AVS API End Point URL", description = "AVS API End Point URL", type = AttributeType.STRING)
    String getAvsEndPointUrl() default "https://api.experianmarketingservices.com";

    @AttributeDefinition(name = "AVS API URI", description = "AVS API URI", type = AttributeType.STRING)
    String getAvsApiPath() default "/capture/v1/verify-address/text";

    @AttributeDefinition(name = "AVS API Auth Token", description = "AVS API Auth Token", type = AttributeType.STRING)
    String getAvsAuthToken() default "fb8bf133-c669-4c71-9c7f-caa6a394e5fb";

    @AttributeDefinition(name = "Map Quest API End Point URL", description = "Map Quest API End Point URL", type = AttributeType.STRING)
    String getMapQuestEndPointUrl() default "https://www.mapquestapi.com";

    @AttributeDefinition(name = "Map Quest API URI", description = "Map Quest API URI", type = AttributeType.STRING)
    String getMapQuestApiPath() default "/geocoding/v1/address";

    @AttributeDefinition(name = "Map Quest API Auth Token", description = "Map Quest API Auth Token", type = AttributeType.STRING)
    String getMapQuestAuthToken() default "IQWpZsttQHDa5BjHFlNpV3n25HEuOZFU";

    @AttributeDefinition(name = "Map Quest Store Locator API URI", description = "Map Quest Store Locator API URI", type = AttributeType.STRING)
    String getMapQuestStoreLocatorApiPath() default "/search/v2/radius";

    @AttributeDefinition(name = "Map Quest Store Locator URL Params", description = "Map Quest Store Locator URL Params", type = AttributeType.STRING)
    String[] getMapQuestStoreLocatorUrlParams() default {
            "STRAIGHT_TALK:ambiguities=ignore&hostedData=mqap.IQWpZsttQHDa5BjHFlNpV3n25HEuOZFU_all_brands|\"BRANDSM\"%20=%20?AND%20\"STORETYPE\"=?|TRUE;FullService|NAME;ADDRESS;CITY;STATE;PHONE;ZIPCODE;STORETYPE;ISEXCLUSIVE;mqap_geography&radius={radius}&maxMatches={result}&origin={origin}&outFormat=json",
            "TRACFONE:ambiguities=ignore&hostedData=mqap.IQWpZsttQHDa5BjHFlNpV3n25HEuOZFU_all_brands|\"BRANDSM\"%20=%20?AND%20\"STORETYPE\"=?|TRUE;FullService|NAME;ADDRESS;CITY;STATE;PHONE;ZIPCODE;STORETYPE;ISEXCLUSIVE;mqap_geography&radius={radius}&maxMatches={result}&origin={origin}&outFormat=json",
            "TOTAL_WIRELESS:ambiguities=ignore&hostedData=mqap.IQWpZsttQHDa5BjHFlNpV3n25HEuOZFU_all_brands|\"BRANDSM\"%20=%20?AND%20\"STORETYPE\"=?|TRUE;FullService|NAME;ADDRESS;CITY;STATE;PHONE;ZIPCODE;STORETYPE;ISEXCLUSIVE;mqap_geography&radius={radius}&maxMatches={result}&origin={origin}&outFormat=json" };

    @AttributeDefinition(name = "Address Mgmt API URI", description = "Address Mgmt API URI", type = AttributeType.STRING)
    String getAddressMgmtApiPath() default "/address-mgmt/address";

    @AttributeDefinition(name = "Payment Method Mgmt API URI", description = "Payment Method Mgmt API URI", type = AttributeType.STRING)
    String getPaymentMethodMgmtApiPath() default "/payment-method-mgmt/payment-method";

    @AttributeDefinition(name = "Send Verification Code API URI", description = "Send Verification Code", type = AttributeType.STRING)
    String getSendVerificationCodeApiPath() default "/resource-mgmt/resource/verification-code";

    @AttributeDefinition(name = "Send OTP to any phone API URI", description = "Send OTP to any phone API URI", type = AttributeType.STRING)
    String getSendOtpToAnyPhoneApiPath() default "/resource-mgmt/resource/verification-code/generate";

    @AttributeDefinition(name = "Validate Verification Code API URI", description = "Validate Verification Code API URI", type = AttributeType.STRING)
    String getValidateVerificationCodeApiPath() default "/resource-mgmt/resource/verification-code/validate";

    @AttributeDefinition(name = "Create Account API URI", description = "Create Account API URI", type = AttributeType.STRING)
    String getCreateAccountApiPath() default "/customer-mgmt/customer/profile";

    @AttributeDefinition(name = "Prepare Order API", description = "URI of Prepare Order")
    String getPrepareOrderApiPath() default "/order-mgmt/prepare-order";

    @AttributeDefinition(name = "Submit Order  API", description = "URI of Submit Order")
    String getSubmitOrderApiPath() default "/order-mgmt/submit-order";

    @AttributeDefinition(name = "WC Token Api Path", description = "WC Token Api Path")
    String[] getWcTokenApiPath() default { "STRAIGHT_TALK:/customer-mgmt/customer/guest",
            "TRACFONE:/customer-mgmt/customer/guest" };

    @AttributeDefinition(name = "WC token expiry time", description = "WC token expiry time in seconds")
    String[] getWcTokenExpiryTime() default { "STRAIGHT_TALK:604800", "TRACFONE:604800" };

    @AttributeDefinition(name = "Account Profile  API", description = "URI of Account Profile API")
    String getAccountProfileApiPath() default "/customer-mgmt/customer/{accountId}/profile";

    @AttributeDefinition(name = "Qualified Lines For MFA API", description = "URI of Qualified Lines For MFA API")
    String getQualifiedLinesForMFAApiPath() default "/customer-mgmt/security-options/customer/{accountId}/qualified-lines-for-mfa";

    @AttributeDefinition(name = "Resource Management API", description = "URI of Resource Management API")
    String getResourceMgmtApiPath() default "/resource-mgmt/resource";

    @AttributeDefinition(name = "Projection Value for Resource Management API", description = "Projection Value for Resource Management API")
    String getResourceMgmtApiProjection() default "basic-info,plans,enrollments,account,specifications,supporting-resources,agreements";

    @AttributeDefinition(name = "Check PlanIds for HPP Eligibility API", description = "Check Plan Ids - HPP Eligibility")
    String getCatalogHppEligibilityApiPath() default "/catalog-mgmt/vas-productoffering?planCategory=VAS&planSubCategory=INSURANCE";

    @AttributeDefinition(name = "Cart Migration API", description = "URI of Cart Migration API")
    String getCartMigrationApiPath() default "/cart-mgmt/cart-migration";

    @AttributeDefinition(name = "RO Token API", description = "URI of RO Token API")
    String getRoTokenApiPath() default "/oauth/token/ro";

    @AttributeDefinition(name = "Header Web Token Scope", description = "Header Web Token Scope")
    String[] getHeaderScope() default { "STRAIGHT_TALK:ST-AEM-WEB", "TRACFONE:TF-AEM-WEB" };

    @AttributeDefinition(name = "Marketing Id Facet", description = "Marketing Id Facet for Search Optimized Query", type = AttributeType.STRING)
    String[] getMarketingIdFacet() default { "STRAIGHT_TALK:ads_f3_ntk_cs%3A%22{{marketingId}}%22",
            "TRACFONE:ads_f3_ntk_cs%3A%22{{marketingId}}%22" };

    @AttributeDefinition(name = "Price Facet", description = "Price Facet for Search Optimized Query", type = AttributeType.STRING)
    String[] getPriceFacet() default { "STRAIGHT_TALK:price_USD%3A(%7B*+{{approvedPrice}}%7D)",
            "TRACFONE:price_USD%3A(%7B*+{{approvedPrice}}%7D)" };

    @AttributeDefinition(name = "Plan Id Facet", description = "PlanId Facet for Search Optimized Query", type = AttributeType.STRING)
    String[] getPlanIdFacet() default { "STRAIGHT_TALK:ads_f140001_ntk_cs", "TRACFONE:ads_f140001_ntk_cs",
            "TOTAL_WIRELESS:ads_f140001_ntk_cs" };

    @AttributeDefinition(name = "Smartpay Plan Facet", description = "Smart Pay Plan Facet for Search Optimized Query", type = AttributeType.STRING)
    String[] getSmartPayPlanFacet() default { "STRAIGHT_TALK:ads_f153503_ntk_cs%3A%22TRUE%22",
            "TRACFONE:ads_f153503_ntk_cs%3A%22TRUE%22" };

    @AttributeDefinition(name = "Offer Hpp True Facet", description = "Offer Hpp True Facet for Search Optimized Query", type = AttributeType.STRING)
    String[] getOfferHppTrueFacet() default { "STRAIGHT_TALK:ads_f153501_ntk_cs%3A%22TRUE%22",
            "TRACFONE:ads_f153501_ntk_cs%3A%22TRUE%22" };

    @AttributeDefinition(name = "Activation Plan Type Facet", description = "Activation Plan Type Facet for Search Optimized Query", type = AttributeType.STRING)
    String[] getActivationPlanTypeFacet() default { "STRAIGHT_TALK:ads_f155001_ntk_cs%3A%22Activation%22",
            "TRACFONE:ads_f155001_ntk_cs%3A%22Activation%22",
            "TOTAL_WIRELESS:ads_f155001_ntk_cs%3A%22Activation%22" };

    @AttributeDefinition(name = "Purchase Plan Type Facet", description = "Purchase Plan Type Facet for Search Optimized Query", type = AttributeType.STRING)
    String[] getPurchasePlanTypeFacet() default { "STRAIGHT_TALK:ads_f155001_ntk_cs%3A%22Purchase%22",
            "TRACFONE:ads_f155001_ntk_cs%3A%22Purchase%22",
            "TOTAL_WIRELESS:ads_f155001_ntk_cs%3A%22Purchase%22" };

    @AttributeDefinition(name = "Refill Plan Type Facet", description = "Refill Plan Type Facet for Search Optimized Query", type = AttributeType.STRING)
    String[] getRefillPlanTypeFacet() default { "STRAIGHT_TALK:ads_f155001_ntk_cs%3A%22Refill%22",
            "TRACFONE:ads_f155001_ntk_cs%3A%22Refill%22" };

    @AttributeDefinition(name = "Service Plan Facet", description = "Service Plan Facet for Search Optimized Query")
    String[] getServicePlanFacet() default { "TRACFONE:ads_f140001_ntk_cs",
            "TOTAL_WIRELESS:ads_f155003_ntk_cs%3A%22SERVICE_PLAN%22" };

    @AttributeDefinition(name = "Tablet Plan Facet", description = "Tablet Plan Facet for Search Optimized Query")
    String[] getTabletPlanTypeFacet() default { "TRACFONE:ads_f140001_ntk_cs",
            "TOTAL_WIRELESS:ads_f140005_ntk_cs%3A%22Tablet%22" };

    @AttributeDefinition(name = "Pay Go Facet", description = "Pay Go Facet for Search Optimized Query")
    String[] getPayGoFacet() default { "TRACFONE:ads_f157501_ntk_cs%3A%22PAY_GO%22" };

    @AttributeDefinition(name = "Upsell Facet", description = "Upsell Facet for Search Optimized Query")
    String[] getUpsellFacet() default { "TRACFONE:ads_f155003_ntk_cs%3A%22UPSELL%22" };

    @AttributeDefinition(name = "Refresh token call time before expiry", description = "Refresh token call time before expiry in seconds")
    String[] getRefreshTokenCallTime() default { "STRAIGHT_TALK:300", "TRACFONE:300" };

    @AttributeDefinition(name = "Refresh token permissible limit", description = "Refresh token permissible limit to call the api(0 limit means no refresh token call will happen)")
    String[] getRefreshTokenLimit() default { "STRAIGHT_TALK:1", "TRACFONE:1" };

    @AttributeDefinition(name = "SmartPay Search Optimized Query", description = "Query String for BySearch Optimized API call for Smartpay App", type = AttributeType.STRING)
    String getSmartPaySearchOptimizedQuery() default "searchKeyword=*&facet=(price_USD:(%7B0+{{approvedPrice}}%7D)-ads_f129001_ntk_cs:%22MIGRATION_GROUP_EXCLUSIVE%22)";

    @AttributeDefinition(name = "Approve Url Params", description = "Approve Url Params for Change Lease API", type = AttributeType.STRING)
    String getApproveUrlParam() default "?orderId={orderIdValue}&upfrontPayment={upfrontPayment}&currPayAmt={currPayAmt}&nextPayAmt={nextPayAmt}&nextPayDt={nextPayDt}&noOfMonths={noOfMonths}&lesseEmailId={lesseEmailId}&ccLastFour={ccLastFour}&approval_amount={sp_amount}&risk_grade={sp_grade}";

    @AttributeDefinition(name = "Decline Url Params", description = "Decline Url Params for Change Lease API", type = AttributeType.STRING)
    String getDeclineUrlParams() default "?actionCode=SP_DECLINE_URL";

    @AttributeDefinition(name = "Amount Decline Url Params", description = "Amount Decline Url Params for Change Lease API", type = AttributeType.STRING)
    String getAmountDeclineUrlParams() default "?actionCode=SP_DECLINE_PRODUCT_URL";

    @AttributeDefinition(name = "Zero Offer Denial Url Params", description = "Zero Offer Denial Url Params for Change Lease API", type = AttributeType.STRING)
    String getZeroOfferDenialUrlParams() default "?approval_amount={sp_amount}&risk_grade={sp_grade}";

    @AttributeDefinition(name = "Idle Session alert time", description = "Session management alert time before logout in seconds")
    String[] getIdleSessionAlertTime() default { "STRAIGHT_TALK:600", "TRACFONE:600" };

    @AttributeDefinition(name = "Idle Session time", description = "Login Session management idle time in seconds")
    String[] getLoginIdleSessionTime() default { "STRAIGHT_TALK:1800", "TRACFONE:1800" };

    @AttributeDefinition(name = "HPP Estimate Order API Path", description = "URI of HPP Estimate Order API")
    String getHppEstimateOrderApiPath() default "/order-mgmt/productorder/estimate";

    @AttributeDefinition(name = "Estimate Order API Path", description = "URI of Estimate Order API")
    String getEstimateOrderApiPath() default "/order-mgmt/vas/order-estimate";

    @AttributeDefinition(name = "VAS Standalone Service Order API Path", description = "Asynchronous Call VAS Standalone Products Api Path")
    String getVasStandaloneServiceOrderApiPath() default "/order-mgmt/vas/service-order/order-reference";

    @AttributeDefinition(name = "VAS Standalone Service to Subscription Reference", description = "Asynchronous Call VAS Subscription Reference Api Path")
    String getVasSubscriptionReferenceApiPath() default "/order-mgmt/vas/service-order/subscription-reference";

    @AttributeDefinition(name = "Email Verification API Path", description = "URI of Email Verification API")
    String getEmailVerificationApiPath() default "/service-qualification-mgmt/vas/plan-eligibility";

    @AttributeDefinition(name = "Vas Plan Qualification API Path", description = "URI of Vas Plan Qualification API")
    String getVasPlanQualificationApiPath() default "/service-qualification-mgmt/vas/plan-qualification";

    @AttributeDefinition(name = "Vas Details Submission API path", description = "URI of Vas Details Submission API path")
    String getSubmitVasDetailsApiPath() default "/order-mgmt/vas/service-order";

    @AttributeDefinition(name = "Validate BYOP API Path", description = "URI of Validate BYOP API")
    String getValidateBYOPApiPath() default "/service-qualification-mgmt/service-qualification/gsm-byop-eligibility";

    @AttributeDefinition(name = "HPP Enrollment API Path", description = "URI of HPP Enrollment API")
    String getHppEnrollmentApiPath() default "/order-mgmt/productorder";

    @AttributeDefinition(name = "Update BYOP API Path", description = "URI of Update BYOP API")
    String getUpdateBYOPApiPath() default "/service-mgmt/service/vas/subscription";

    @AttributeDefinition(name = "Remove Lease Payment Api Path", description = "URI of Remove Lease Payment Api Path")
    String getRemoveLeasePaymentApiPath() default "/order-mgmt/remove-leasepayment";

    @AttributeDefinition(name = "Create Lease Payment Api Path", description = "URI of Create Lease Payment Api Path")
    String getCreateLeasePaymentApiPath() default "/order-mgmt/create-leasepayment";

    @AttributeDefinition(name = "Remove Hyla Api Path", description = "URI of Remove Hyla Api Path")
    String getRemoveHylaApiPath() default "/order-mgmt/removeHyla";

    @AttributeDefinition(name = "Communication Preferences API Path", description = "URI of Communication Preferences API")
    String getCommunicationPreferencesApiPath() default "/customer-mgmt/customer/{accountId}/preferences";

    @AttributeDefinition(name = "Privacy Portal Ro Token API Path", description = "URI of Privacy Portal Ro token API")
    String getPrivacyPortalRoTokenApiPath() default "/privacy-portal/token/ro";

        @AttributeDefinition(name = "Security Preferences API Path", description = "URI of Security Preferences API")
        String getSecurityPreferencesApiPath() default "/customer-mgmt/customer/{accountId}/preferences/security";

        @AttributeDefinition(name = "Update Security Preferences API Path", description = "URI of Update Security Preferences API")
        String getUpdateSecurityPreferencesApiPath() default "/customer-mgmt/customer/{accountId}/preferences/security";

        @AttributeDefinition(name = "Update Personal Info API Path", description = "URI of Update Personal Info API")
        String getUpdatePersonalInfoApiPath() default "/customer-mgmt/customer/{accountId}/personal-info";

    @AttributeDefinition(name = "Update Credential API Path", description = "URI of Update Credential API")
    String getUpdateCredentialsApiPath() default "/customer-mgmt/customer/{accountId}/credentials";

    @AttributeDefinition(name = "Get Security Questions API Path", description = "URI of Get Security Questions API")
    String getSecurityQuestionsApiPath() default "/customer-mgmt/customer/identity-challenges";

    @AttributeDefinition(name = "Update Security Questions API Path", description = "URI of Update Security Questions API")
    String getUpdateSecurityQuestionsApiPath() default "/customer-mgmt/customer/{accountId}/identity-challenges";

    @AttributeDefinition(name = "Catalog Mgmt Coupons API Path", description = "URI of Catalog Mgmt Coupons API")
    String getCatalogMgmtCouponsApiPath() default "/catalog-mgmt/coupons";

    @AttributeDefinition(name = "Airtime details API URI", description = "Airtime details API URI", type = AttributeType.STRING)
    String getAirtimeDetailsApiPath() default "/resource-mgmt/resource/airtime-reserve/index/1";

    @AttributeDefinition(name = "Web Account Contact  API", description = "URI of Web Account Contact  API")
    String webAccountContactApiPath() default "/customer-mgmt/customer/{accountId}/contact";

    @AttributeDefinition(name = "Service Order API", description = "URI of Service Order API")
    String serviceOrderApiPath() default "/order-mgmt/serviceorder";

    @AttributeDefinition(name = "FB Check Linking Status API", description = "FB Check Linking Status API")
    String fbLinkingStatusApiPath() default "/fb-linking/check/linkingStatus";

    @AttributeDefinition(name = "Service Qualification technology Api Path", description = "URI of Service Qualification Technology API")
    String getServiceQualTechnologyApiPath() default "/service-qualification-mgmt/service-qualification/carrier-availability";

    @AttributeDefinition(name = "Service Qualification Activation Api Path", description = "URI of Service Qualification Activation API")
    String getServiceQualActivationApiPath() default "/service-qualification-mgmt/service-qualification/activation";

    @AttributeDefinition(name = "Service Qualification Compatibility Api Path", description = "URI of Service Qualification Compatibility API")
    String getServiceQualCompatibilityApiPath() default "/service-qualification-mgmt/service-qualification/service-compatibility";

    @AttributeDefinition(name = "Product Inv Mgmt Airtime  API", description = "URI of Product Inv Mgmt Airtime  API")
    String getProductInvMgmtApiPath() default "/inventory-mgmt/product-inventory/airtime/{pin}";

    @AttributeDefinition(name = "Facebook User Name", description = "Brand specific Facebook User Name")
    String[] getFBUserName() default { "STRAIGHT_TALK:StraightTalk_AEM", "TRACFONE:StraightTalk_AEM" };

    @AttributeDefinition(name = "Loyalty Enrolment API", description = "URI of Loyalty Enrolment API")
    String getLoyaltyEnrolApiPath() default "/service-qualification-mgmt/service-qualification/loyalty-rewards-enrollment";

    @AttributeDefinition(name = "Port Carrier API", description = "URI of port carrier api")
    String getPortCarrierApiPath() default "/config-mgmt/config/port-carriers";

    @AttributeDefinition(name = "Port Carrier Info Api Path", description = "URI of Port Carrier Info API")
    String getPortCarrierInfoApiPath() default "/config-mgmt/config/port-carriers/carrier/{carrier-name}";

    @AttributeDefinition(name = "Service Qualification Port Coverage Api Path", description = "URI of Service Qualification Port Coverage API")
    String getServiceQualPortCoverageApiPath() default "/service-qualification-mgmt/service-qualification/port-coverage";

    @AttributeDefinition(name = "Get Account Profile By Type API URI", description = "Get Account Profile By Type  API URI", type = AttributeType.STRING)
    String getAccountProfileByTypeApiPath() default "/customer-mgmt/customer/profile";

    @AttributeDefinition(name = "Get Rewards Enrollment API URI", description = "Get Rewards Enrollment API URI", type = AttributeType.STRING)
    String getRewardsEnrollmentApiPath() default "/order-mgmt/serviceorder";

    @AttributeDefinition(name = "Get Payment History API URI", description = "Get Payment History API URI", type = AttributeType.STRING)
    String getPaymentHistoryApiPath() default "/order-mgmt/order/payment";

    @AttributeDefinition(name = "Address Validation API URI", description = "Address Validation API URI", type = AttributeType.STRING)
    String getAddressValidationApiPath() default "/address-mgmt/address/validate";

    @AttributeDefinition(name = "Address Validation Url Params", description = "Address Validation Url Params for USA Country", type = AttributeType.STRING)
    String getAddressValidationUrlParams() default "country=USA";

    @AttributeDefinition(name = "Get Service Provider API URI", description = "Get Service Provider API URI", type = AttributeType.STRING)
    String getServiceProviderApiPath() default "/config-mgmt/config/service-providers";

    @AttributeDefinition(name = "Service Qualification ESN compatiblity API URI", description = "API call for Service Qualification ESN Compatibilty")
    String getServiceQualEsnCompatibilityApiPath() default "/service-qualification-mgmt/service-qualification/esn-compatibility";

    @AttributeDefinition(name = "BYOP Eligibility API URI", description = "API call for BYOP Eligibility")
    String getByopEligibilityApiPath() default "/service-qualification-mgmt/service-qualification/byop-eligibility";
	
	@AttributeDefinition(name = "Synched BYOP Eligibility API URI", description = "API call for Synched BYOP Eligibility")
    String getSynchedByopEligibilityApiPath() default "/service-qualification-mgmt/service-qualification/byop-eligibility";

    @AttributeDefinition(name = "BYOP Registration API URI", description = "API call for BYOP Registration")
    String getByopRegistrationApiPath() default "/inventory-mgmt/resource-inventory/resource";

    @AttributeDefinition(name = "Track Order API URI", description = "URI of Track Order API", type = AttributeType.STRING)
    String getTrackOrderApiPath() default "/order-mgmt/track-order";

    @AttributeDefinition(name = "Service Qualification Availability Api Path", description = "URI of Service Qualification Availability API")
    String getServiceQualAvailabilityApiPath() default "/service-qualification-mgmt/service-qualification/service-availibility";

    @AttributeDefinition(name = "Expiry Time for Account Information", description = "Account Information cookie expiry time in seconds")
    String[] getAccountInfoExpiryTime() default { "STRAIGHT_TALK:3600", "TRACFONE:3600" };

    @AttributeDefinition(name = "Remove device from Account API", description = "URI of remove device from Account API")
    String getRemoveDeviceFromAccountPath() default "/customer-mgmt/customer/{accountId}/device";

    @AttributeDefinition(name = "Service Ticket API URI", description = "URI of Service Ticket API", type = AttributeType.STRING)
    String getServiceTicketApiPath() default "/ticket-mgmt/trouble-ticket";

    @AttributeDefinition(name = "Device Rebrand API URI", description = "URI of Device Rebrand API", type = AttributeType.STRING)
    String getDeviceRebrandApiPath() default "/resource-mgmt/resource/rebrand";

    @AttributeDefinition(name = "Rebrand Eligibilty API URI", description = "URI of Rebrand Eligibilty API", type = AttributeType.STRING)
    String getRebrandEligibiltyApiPath() default "/service-qualification-mgmt/service-qualification/rebrand";

    @AttributeDefinition(name = "Add Device to Account API URI", description = "URI of Add Device to Account API", type = AttributeType.STRING)
    String getAddDeviceToAccountApiPath() default "/customer-mgmt/customer/{accountId}/device";

    @AttributeDefinition(name = "Reserved Airtime Get API URI", description = "Reserved Airtime Get API URI", type = AttributeType.STRING)
    String getReservedAirtimeGetApiPath() default "/resource-mgmt/resource/airtime-reserve";

    @AttributeDefinition(name = "Edit Nick Name API URI", description = "Edit Nick Name API URI", type = AttributeType.STRING)
    String getEditNickNameApiPath() default "/resource-mgmt/nickname";

    @AttributeDefinition(name = "Email Coupon API URI", description = "Email Coupon API URI", type = AttributeType.STRING)
    String getEmailCouponApiPath() default "/comm-mgmt/email/coupon";

    @AttributeDefinition(name = "Retention Matrix API URI", description = "Retention Matrix API URI", type = AttributeType.STRING)
    String getRetentionMatrixApiPath() default "/service-mgmt/continuity-options";

    @AttributeDefinition(name = "Refill Resource Management Projections", description = "Refill Resource Management Projections", type = AttributeType.STRING)
    String getRefillResourceMgmtProjection() default "basic-info,specifications,enrollments,account,plans,notifications,secondary-info";

    @AttributeDefinition(name = "Reserved Airtime Sort API URI", description = "Reserved Airtime Sort API URI", type = AttributeType.STRING)
    String getReservedAirtimeSortApiPath() default "/resource-mgmt/resource/airtime-reserve/index";

    @AttributeDefinition(name = "FB Link Account API URI", description = "FB Link Account API URI", type = AttributeType.STRING)
    String getFbLinkAccountApiPath() default "/fb-linking/linkAccount/{accountId}";

    @AttributeDefinition(name = "Catalog management API URI", description = "Catalog managemen API URI", type = AttributeType.STRING)
    String getCatalogMgmtApiPath() default "/catalog-mgmt/product-offerings";

    @AttributeDefinition(name = "Validate Account API URI", description = "Validate Account API URI", type = AttributeType.STRING)
    String getValidateAccountApiPath() default "/customer-mgmt/customer/profile/validate";

    @AttributeDefinition(name = "Retrieve Order No Api Path", description = "Retrieve Order No Api Path")
    String retrieveOrderNoApiPath() default "/communication-mgmt/forgot-orderId";

    @AttributeDefinition(name = "Cancel Enrollment Api Path", description = "Cancel Enrollment Api Path")
    String getCancelEnrollmentApiPath() default "/service-mgmt/subscriptions";

    @AttributeDefinition(name = "Retention Matrix Api Path", description = "Retention Matrix Api Path")
    String retentionMatrixApiPath() default "/service-mgmt/continuity-options";

    @AttributeDefinition(name = "Validate Login Api Path", description = "Forgot Password - Validate User Api Path")
    String getValidateLoginApiPath() default "/customer-mgmt/customer/forgotPassword/validateUserToken";

    @AttributeDefinition(name = "Get Operating System by Phone No. Api Path", description = "Get Operating System by Phone No. Api Path")
    String getOSByPhoneNumberApiPath() default "/resource-mgmt/resource/operating-systems";

    @AttributeDefinition(name = "Get APN Settings Api Path", description = "Get APN Settings Api Path")
    String getAPNSettingsApiPath() default "/resource-mgmt/resource/apn-settings";

    @AttributeDefinition(name = "Update Login Api Path", description = "Forgot Password - Update Login Api Path")
    String getUpdateLoginApiPath() default "/customer-mgmt/customer/forgotPassword/updateLogin";

    @AttributeDefinition(name = "Service Plan Balance Api Path", description = "Service Plan Balance Api Path")
    String getServicePlanBalanceApiPath() default "/service-mgmt/v1/service/balance";

    @AttributeDefinition(name = "ILD Balance Api Path", description = "ILD Balance Api Path")
    String getIldBalanceApiPath() default "/usage-mgmt/ild/balance";

    @AttributeDefinition(name = "Resource Mgmt Projections - Post Login", description = "Projections required in Resource Management API after login.")
    String resourceMgmtProjPostLogin() default "notifications";

    @AttributeDefinition(name = "Update Login Api Path", description = "Forgot Password - Update Login Api Path")
    String getSendEmailApiPath() default "/customer-mgmt/customer/forgotPassword";

    @AttributeDefinition(name = "Reset Voicemail Api Path", description = "Reset Voicemail Api Path")
    String getResetVoicemailApiPath() default "/customer-mgmt/customer/{accountId}/reset-voicemail";

    @AttributeDefinition(name = "DeEnrollment Reasons Api Path", description = "DeEnrollment Reasons Api Path")
    String getDeEnrollmentReasonsApiPath() default "/config-mgmt/deenrollment-reasons";

    @AttributeDefinition(name = "Transaction History Api Path", description = "Transaction History Api Path")
    String getTransactionHistoryApiPath() default "/order-mgmt/order/transaction";

    @AttributeDefinition(name = "Expiry Time for Remember Me Cookie", description = "Remember Me cookie expiry time in Days")
    String[] getRememberMeExpiryTime() default { "STRAIGHT_TALK:365", "TRACFONE:365" };

    @AttributeDefinition(name = "Wifi Address Api Path", description = "Wifi Address Api Path")
    String getWifiAddressApiPath() default "/customer-mgmt/customer/address";

    @AttributeDefinition(name = "Augeo Token API path", description = "Augeo Token API path")
    String getAugeoTokenApiPath() default "/augeo/token";

    @AttributeDefinition(name = "Default Augeo Rewards Dashboard path", description = "Default Augeo Rewards Dashboard path")
    String[] getAugeoRewardsDashboardPath() default {
            "STRAIGHT_TALK:https://sitf-tracfone.augeocms.com/home/dashboard",
            "TRACFONE:https://sitf-tracfonerewards.augeocms.com/home/dashboard" };

    @AttributeDefinition(name = "Rewards Plan Type Facets", description = "Rewards Plan Type Facets", type = AttributeType.STRING)
    String[] getPLPFacets() default { "ALL_PLANS:ads_f155001_ntk_cs%3A%22TRUE%22",
            "ILD_ADDON:ads_f156001_ntk_cs%3A%22ILD_ADDON%22",
            "DATA_ADDON:ads_f156001_ntk_cs%3A%22DATA_ADDON%22" };

    @AttributeDefinition(name = "Wifi Calling Eligibility Api Path", description = "Wifi Calling Eligibility Api Path")
    String getWifiCallEligibilityApiPath() default "/service-qualification-mgmt/service-qualification/wificall-eligibility";

    @AttributeDefinition(name = "Fetch Order Api Path", description = "Fetch Order Api Path")
    String getFetchOrderApiPath() default "/order-mgmt/fetch-order";

    @AttributeDefinition(name = "Coverage Map Api Path", description = "Coverage Map Api Path")
    String getCoverageMapApiPath() default "/service-qualification-mgmt/service-qualification/coverage-map";

    @AttributeDefinition(name = "Brand Names use Name attribute to save for Product Specifications", description = "Brand Names use Name attribute to save for Product Specifications")
    String[] getProductSpecsForBrand() default { "STRAIGHT_TALK" };

    @AttributeDefinition(name = "Retrieve Cart Api Path", description = "Retrieve Cart Api Path")
    String getRetrieveCartApiPath() default "/cart-mgmt/retrieve-my-cart";

    @AttributeDefinition(name = "Retrieve AppleCare Eligibility Api Path", description = "Retrieve AppleCare Eligibility Api Path")
    String getAppleCareEligibilityApiPath() default "/service-qualification-mgmt/service-qualification/hpp-applecare-eligibility";

    @AttributeDefinition(name = "Activation Promocode Api Path", description = "Activation Promocode Api Path")
    String getActivationPromoApiPath() default "/order-mgmt/order/promocode/validate";

    @AttributeDefinition(name = "Partner Member Api Path", description = "Partner Member Api Path")
    String getPartnerMemberApiPath() default "/customer-mgmt/customer/{accountId}/partner-members";

    @AttributeDefinition(name = "Apple Care Call required on HPP page", description = "Configuration for Apple care call required on HPP page in Activation", type = AttributeType.STRING)
    String[] hppAppleCareApiCallRequired() default { "TRACFONE:yes" };

    @AttributeDefinition(name = "Paypal Braintree Token Api Path", description = "Paypal Braintree Token Api Path", type = AttributeType.STRING)
    String getPaypalBraintreeTokenApiPath() default "/payment-mgmt/payment/braintree/client-token";

    @AttributeDefinition(name = "CPNI AMR Pref", description = "CPNI AMR Pref status")
    String getCpniAmrPrefApiPath() default "/customer-mgmt/customer/cpni-amr-pref";

    @AttributeDefinition(name = "One step activation", description = "One Step Activation")
    String getOneStepActivationApiPath() default "/order-mgmt/validate-onestep-activation";

    @AttributeDefinition(name = "One step activation Last Four Digits", description = "Last four digits check")
    String getOneStepActivationLastFourApiPath() default "/order-mgmt/onestep-eligibility";

    @AttributeDefinition(name = "One step activation BYOP Eligibility", description = "One step activation BYOP elig")
    String getOneStepActivationByopEligApiPath() default "/service-qualification-mgmt/service-qualification";

    @AttributeDefinition(name = "One step activation No Case", description = "No Case Created")
    String getOneStepActivationNoCaseApiPath() default "/order-mgmt/onestep-nocase";

    @AttributeDefinition(name = "Disable Product Inventory/Airtime API call", description = "Disable Product Inventory/Airtime API call")
    String[] disableProductInventoryApiCall() default { "STRAIGHT_TALK:false", "TRACFONE:true" };

    @AttributeDefinition(name = "LogOut Registered User Api Path", description = "Path for LogOut Registered User", type = AttributeType.STRING)
    String getLogOutRegisteredUserApiPath() default "/customer-mgmt/customer/registered/logout";

    @AttributeDefinition(name = "Disable Retention Matrix API call", description = "Disable Retention Matrix API call")
    String[] disableRetentionMatrixApiCall() default { "STRAIGHT_TALK:false", "TRACFONE:true" };

    @AttributeDefinition(name = "Service Qualification Hpp Applecare Eligibility Api Path", description = "URI of Service Qualification Hpp Applecare Eligibility API")
    String getServiceQualHppApplecareEligibilityApiPath() default "/service-qualification-mgmt/service-qualification/hpp-applecare-eligibility";

    @AttributeDefinition(name = "Use smartPayPlanFacet in Product Offering API Call", description = "Use smartPayPlanFacet in Product Offering API Call")
    String[] smartPayPlanFacetRequired() default { "STRAIGHT_TALK:true", "TRACFONE:false" };

    @AttributeDefinition(name = "Use offerHppplanFacet in Product Offering API Call", description = "Use offerHppplanFacet in Product Offering API Call")
    String[] offerHppplanFacetRequired() default { "STRAIGHT_TALK:true", "TRACFONE:false", "TOTAL_WIRELESS:true" };

    @AttributeDefinition(name = "Pega Offer Api Path", description = "Pega Offer Api Path Url", type = AttributeType.STRING)
    String getPegaOfferContainerApiPath() default "/PegaMKTContainer/V2/Container";

    @AttributeDefinition(name = "Pega Offer Capture Response Api Path", description = "Pega Offer Capture Response Api Path Url", type = AttributeType.STRING)
    String getPegaOfferCaptureResponseApiPath() default "/PegaMKTContainer/V2/CaptureResponse";

    @AttributeDefinition(name = "Recommended Subscription Services API", description = "URI of Subscription Services API")
    String getDynamicVasApiPath() default "/service-mgmt/vas/service/enrollment";

    @AttributeDefinition(name = "Subscription Services DeEnrollment Reasons Api Path", description = "Subscription Services DeEnrollment Reasons Api Path")
    String getDynamicVasCancelReasonsApiPath() default "/api/service-mgmt/vas/cancel-reasons";

    @AttributeDefinition(name = "Subscription Experian Enrollment Completion Redirection Path", description = "Subscription Experian Enrollment Completion Redirection Path", type = AttributeType.STRING)
    String getDynamicVasExperianEnrollmentRedirectionPath() default "https://imc2-staging.csid.co/enrollment/validate-member-number?RTN=90000605&memberNumber=";

    @AttributeDefinition(name = "Coupon Purchase API", description = "URI of Coupon Purchase API")
    String getCouponPurchaseApiPath() default "/order-mgmt/coupon-productorder";

    @AttributeDefinition(name = "CUSG Eligibility Check API", description = "URI of CUSG Eligibility Check API")
    String cusgEligibilityCheckPath() default "/service-mgmt/cusg/eligiblity-check";

    @AttributeDefinition(name = "Hide Skip Plan Button for Cusg flow", description = "Hide Skip Plan Button for Cusg flow")
    String[] hideSkipPlanButtonForCusg() default { "STRAIGHT_TALK:false", "TRACFONE:true" };

    @AttributeDefinition(name = "Set Plan localStorage as Array for refill flow", description = "Set Plan localStorage as Array for refill flow")
    String[] setPlanLocalStorageAsArray() default { "STRAIGHT_TALK:false", "TRACFONE:true" };

    @AttributeDefinition(name = "Category List API", description = "Path of Category Listing API")
    String getCategoryListApiPath() default "/catalog-mgmt/categoryview";

    @AttributeDefinition(name = "Mutiline Cart Eligibility Check API", description = "Path of Mutiline Cart Eligibility Check")
    String getMultilineCartEligibilityCheckApiPath() default "/service-mgmt/multiline/cart-eligiblitycheck";

    @AttributeDefinition(name = "Add On Plan Facet", description = "Add On Plan Facet for Search Optimized Query")
    String[] getAddOnPlanFacet() default { "TOTAL_WIRELESS:ads_f140005_ntk_cs%3A%22Add-Ons%22" };

    @AttributeDefinition(name = "Hotspot Plan Type Facet", description = "Hotspot Type Plan Facet for Search Optimized Query")
    String[] getHotspotPlanTypeFacet() default { "TOTAL_WIRELESS:ads_f140005_ntk_cs%3A%22Mobile+Hotspot%22" };

    @AttributeDefinition(name = "Service Qualification Account Capacity Api Path", description = "URI of Service Qualification Account Capacity API")
    String getServiceQualAccountCapacityApiPath() default "/service-qualification-mgmt/service-qualification/account-capacity";

    @AttributeDefinition(name = "Edit Group Name API", description = "Path of Edit Group Name Api")
    String getEditGroupNameApiPath() default "/customer-mgmt/customer/{accountId}/device-group";

    @AttributeDefinition(name = "Mulitline Guest Resource Mgmt Projection", description = "Projection for the first resource mgmt api call for multiline guest user")
    String getMultilineGuestResourceMgmtProjection() default "basic-info,notifications,supporting-resources,plans,supplementary,specifications,enrollments,account";

    @AttributeDefinition(name = "Reactivation Plan Type Facet", description = "Rectivation Plan Type Facet for Search Optimized Query", type = AttributeType.STRING)
    String[] getReactivationPlanTypeFacet() default { "TOTAL_WIRELESS:ads_f11001_ntk_cs%3A%22SHARED%22" };

    @AttributeDefinition(name = "DeEnrollment API", description = "Path of DeEnrollment API")
    String getDeEnrollmentApiPath() default "/service-mgmt/subscriptions/deenroll";

    @AttributeDefinition(name = "Trouble Ticket API URI", description = "URI for fetching Trouble Ticket from API for external port scenarios.", type = AttributeType.STRING)
    String getTroubleTicketApiPath() default "/ticket-mgmt/web/trouble-ticket";

    @AttributeDefinition(name = "Account Capacity API URI", description = "URI for Account Capacity Api", type = AttributeType.STRING)
    String getAccountCapacityApiPath() default "/service-qualification-mgmt/service-qualification/account-capacity";

    @AttributeDefinition(name = "Unsubscription Email API", description = "Unsubscription API for Email notifications")
    String getUnsubscribeEmailApiPath() default "/customer-mgmt/customer/unsubscribe";

    @AttributeDefinition(name = "IP address API URI", description = "URI to get IP Address Api", type = AttributeType.STRING)
    String getIpifyURL() default "https://api.ipify.org/?format=json";

    @AttributeDefinition(name = "Acp Copay Enabled", description = "Enable ACP Copay for Refill Flow")
    String[] acpCopayEnabled() default { "STRAIGHT_TALK:true", "TRACFONE:true", "TOTAL_WIRELESS:true" };

    @AttributeDefinition(name = "SmartPay Lease Agreement API", description = "URI of SmartPay Lease Agreement")
    String getSmartPayLeaseAgreementApiPath() default "/order-mgmt/lease/smartpay/agreement";

    @AttributeDefinition(name = "SmartPay Create Cart API", description = "URI of SmartPay Create Cart")
    String getSmartPayCreateCartApiPath() default "/order-mgmt/lease/smartpay/create-cart/";

    @AttributeDefinition(name = "SmartPay Create Lease API", description = "URI of SmartPay Create Lease")
    String getSmartPayLeaseApiPath() default "/order-mgmt/lease/smartpay";

    @AttributeDefinition(name = "Verizon Address Mgmt API URI", description = "Verizon Address Mgmt API URI", type = AttributeType.STRING)
    String getVerizonAddressMgmtApiPath() default "/service-qualification-mgmt/fixedwireless/eligibility";

    @AttributeDefinition(name = "Enable Address Mgmt for Fixed Wireless", description = "Enable Address Mgmt for Fixed Wireless", type = AttributeType.STRING)
    String getEnableAddressMgmt() default "true";

    @AttributeDefinition(name = "Set Channel Query Params for Walmart In-Store flow", description = "Set Channel Query Params for Walmart In-Store flow")
    String setChannelQueryParams() default "st,tas";

    @AttributeDefinition(name = "ESN New Status Code", description = "ESN New Status Code", type = AttributeType.STRING)
    String getNewESNStatusCode() default "50";

    @AttributeDefinition(name = "ESN Activated Status Code", description = "ESN Activated Status Code", type = AttributeType.STRING)
    String getActivatedESNStatusCode() default "52";

    @AttributeDefinition(name = "Node Reservation API URI", description = "Node Reservation API URI", type = AttributeType.STRING)
    String getNodeReservationApiPath() default "/order-mgmt/fixedwireless/capacity";

    @AttributeDefinition(name = "Home Internet URL", description = "Home Internet URL", type = AttributeType.STRING)
    String getHomeInternetUrl() default "/home-internet/check-availability";

    @AttributeDefinition(name = "Home Internet Capacity Api Path", description = "Home Internet Capacity Api Path", type = AttributeType.STRING)
    String getHomeIntenetCapacityApiPath() default "/order-mgmt/fixedwireless/capacity";

    @AttributeDefinition(name = "Home Internet Fetch Address Api Path", description = "Home Internet Fetch Address Api Path", type = AttributeType.STRING)
    String getHomeIntenetFetchAddressApiPath() default "/service-qualification-mgmt/fixedwireless/eligibility";

    @AttributeDefinition(name = "Home Internet Update Contact Details Api Path", description = "Home Internet Update Contact Details Api Path", type = AttributeType.STRING)
    String getHomeIntenetUpdateContactDetailsApiPath() default "/service-qualification-mgmt/fixedwireless/eligibility/updateContactDetails";

    @AttributeDefinition(name = "Walmart Marketing Landing Page Url", description = "Walmart Marketing Landing Page Url", type = AttributeType.STRING)
    String getWalmartMarketingLandingPageUrl() default "https://www.walmart.com/cp/1045119";

    @AttributeDefinition(name = "Hide Dummy Current Plan", description = "Hide Dummy Current Plan")
    String[] hideDummyCurrentPlan() default { "STRAIGHT_TALK:false", "TRACFONE:false" };

    @AttributeDefinition(name = "Update Auto Refill Api Path", description = "Update the auto refill toggle Api Path")
    String getUpdateAutoRefillApiPath() default "/cart-mgmt/updateAR";

    @AttributeDefinition(name = "Flow Proposal Api Path", description = "Flow proposal Api path")
    String getFlowProposalApiPath() default "/service-mgmt/flow-proposals";

    @AttributeDefinition(name = "Product Inv Mgmt Multiline Airtime API", description = "URI of Product Inv Mgmt Multiline Airtime API")
    String getSecondPinApiPath() default "/inventory-mgmt/product-inventory/multiline-airtime";

    @AttributeDefinition(name = "Walmart Home Internet PDP Page Url", description = "Walmart Home Internet PDP Page Url", type = AttributeType.STRING)
    String getWalmartHomeInternetPDPPageUrl() default "https://www.walmart.com/ip/Straight-Talk-FOXCONN-Home-Internet-FWF100V5L-CDMA-LTE-WHITE-HOME-INTERNET-Prepaid/5301368831?classType=REGULAR&athbdg=L1102&adsRedirect=true";

    @AttributeDefinition(name = "Verizon API Domain", description = "Configuration for API Domain", type = AttributeType.STRING)
    String getVerizonApiDomain() default "https://api.verizon.com";

    @AttributeDefinition(name = "Verizon TypeAhead Adress URL", description = "Verizon TypeAhead Adress URL", type = AttributeType.STRING)
    String getVerizonTypeAheadAdressUrl() default "/address-mgmt/address/locus-typeahead-yz/typeahead-address";

    @AttributeDefinition(name = "Verizon TypeAhead Adress Locus Unit URL", description = "Verizon TypeAhead Adress Locus Unit URL", type = AttributeType.STRING)
    String getVerizonTypeAheadLocusUnitUrl() default "/address-mgmt/address/locus-typeahead-yz/typeahead-loc-unit";

    @AttributeDefinition(name = "Verizon TypeAhead API key", description = "Verizon TypeAhead API key", type = AttributeType.STRING)
    String getVerizonTypeAheadApiKey() default "pTBHVAjyjWUaLfyRv1KDnYeiVfSwvk9s";

    @AttributeDefinition(name = "Enable Verizon API for Fixed Wireless", description = "Enable Verizon API for Fixed Wireless", type = AttributeType.STRING)
    String getSwitchToVerizonAPI() default "true";

    @AttributeDefinition(name = "Walmart Logo Clickable Page URL", description = "Walmart Logo Clickable Page URL", type = AttributeType.STRING)
    String getWalmartDefaultPageUrl() default "https://www.walmart.com/sthomeinternet";

    @AttributeDefinition(name = "Cancel Reasons API", description = "Path of Cancel Reasons API")
    String getCancelReasonsApiPath() default "/service-mgmt/subscriptions/cancel-reasons";

    @AttributeDefinition(name = "Setup 3DS API", description = "URI of Setup 3DS")
    String getSetup3DSApiPath() default "/payment-mgmt/cybs/payer/authorization";

    @AttributeDefinition(name = "Activation check validity Rafcode Api Path", description = "Activation check validity Rafcode Api Path")
    String getActivationRafCheckApiPath() default "/loyalty-mgmt/refer-a-friend-code-validation";

    @AttributeDefinition(name = "Activation Rafcode Api Path", description = "Activation Rafcode Api Path")
    String getActivationRafApiPath() default "/loyalty-mgmt/rafValidateAndProvisioning";

    @AttributeDefinition(name = "Set Port In Min Api Path", description = "Set Port In Min Api Path")
    String getPortInMinSetApiPath() default "/service-qualification-mgmt/set/portin-min";

    @AttributeDefinition(name = "Get Port In Min Eligibility Api Path", description = "Get Port In Min Eligibility Api Path")
    String getPortInMinEligibilityApiPath() default "/service-qualification-mgmt/portin/eligibility/";

    @AttributeDefinition(name = "VAS OrderMgmt Partner Gateway  API", description = "URI of VAS OrderMgmt Partner Gateway  API")
    String vasOrdermgmtPatnergatewayApiPath() default "/order-mgmt/vas/partner-gateway";

    @AttributeDefinition(name = "Unsubscribe email category communications get API URI", description = "Unsubscribe email category communications get API URI", type = AttributeType.STRING)
    String getUnsubscribeEmailCategoryCommunicationsApiPath() default "/customer-mgmt/email/preferences";

    @AttributeDefinition(name = "Unsubscribe email category communications update API URI", description = "Unsubscribe email category communications update API URI", type = AttributeType.STRING)
    String getUnsubscribeEmailCategoryCommunicationsUpdateApiPath() default "/customer-mgmt/email/preferences";

    @AttributeDefinition(name = "Get Communication Preferences For Categories API Path", description = "URI of Get Categories Communication Preferences API")
    String getCategoryCommunicationPreferencesApiPath() default "/customer-mgmt/customer/{accountId}/preferences";

    @AttributeDefinition(name = "Update Communication Preferences For Categories API Path", description = "URI of Update Categories Communication Preferences API")
    String getCategoryCommunicationPreferencesUpdateApiPath() default "/customer-mgmt/customer/{accountId}/preferences";

    @AttributeDefinition(name = "Get Account Convertion Api Path", description = "URI of Account Convertion from Dummy to Real")
    String getAccountConvertionApiPath() default "/customer-mgmt/customer/addProfile";

    @AttributeDefinition(name = "Enable CPC Migration for TBV brand", description = "CPC Migration to support different communication categories", type = AttributeType.STRING)
    String getEnableCPCMigrationForTBV() default "true";

    @AttributeDefinition(name = "Get Port In Min Validate OTP Api Path", description = "Get Port In Min Otp Validate Api Path")
    String getPortInMinOtpValidateApiPath() default "/service-qualification-mgmt/validate/otp";

    @AttributeDefinition(name = "Get Veriff Decision Api Path", description = "Get Veriff Decision Api Path")
    String veriffDecisionApiPath() default "/service-qualification-mgmt/portin/veriff";

    @AttributeDefinition(name = "Hide Dummy Current Plan", description = "Hide Dummy Current Plan")
    String[] veriffApiKey() default { "TOTAL_WIRELESS:5ff2590b-8fc2-4a95-b5b6-46f3143a39f4" };

    @AttributeDefinition(name = "Enable or Disable TypeAhead for FWA", description = "Enable or Disable TypeAhead for FWA")
    String[] enableTypeAhead() default { "STRAIGHT_TALK:true", "TRACFONE:false", "TOTAL_WIRELESS:true" };

    @AttributeDefinition(name = "Home Internet Plan Facet", description = "Home Internet Plan Facet for Search Optimized Query")
    String[] getHomeInternetPlanFacet() default { "TOTAL_WIRELESS:ads_f140005_ntk_cs%3A%22Home+Internet%22" };

    @AttributeDefinition(name = "Enable CPC Migration for TF brand", description = "CPC Migration to support different communication categories", type = AttributeType.STRING)
    String getEnableCPCMigrationForTF() default "true";

    @AttributeDefinition(name = "Enable CPC Migration for ST brand", description = "CPC Migration to support different communication categories", type = AttributeType.STRING)
    String getEnableCPCMigrationForST() default "true";

    @AttributeDefinition(name = "Update Preferences during Reactivation", description = "Update CPC Preferences during Reactivation API", type = AttributeType.STRING)
    String getUpdatePreferencesForReactivation() default "/customer-mgmt/customer/preferences/reactivation";
        
    @AttributeDefinition(name = "Tracfone WFM API Path", description = "Configuration for WFM API Path", type = AttributeType.STRING)
    String getApiPathWFM() default "https://sitfapifull.tracfone.com/api/catalog-mgmt/productoffering";

	@AttributeDefinition(name = "Tracfone NET10 SM API Path", description = "Configuration for Net10 SM API Path", type = AttributeType.STRING)
	String getApiPathNet10() default "https://sitfapifull.tracfone.com/pep/servicePlanSelector/v2/";
	
	@AttributeDefinition(name = "Tracfone NET10 SM API Path", description = "Configuration for Net10 SM API Path", type = AttributeType.STRING)
	String getApiPathSM() default "https://sitfapifull.tracfone.com/pep/servicePlanSelector/v2/";
	
	@AttributeDefinition(name = "Tracfone GoSmart API Path En", description = "Configuration for GoSmart API Path En", type = AttributeType.STRING)
	String getApiPathGoSmartEn() default "https://www.gosmartmobile.com/wps/wcm/connect/GoSmart%20EN/Shop/Service+Plans/serviceplans?subtype=application/json&devicetype=Wireless";
	
	@AttributeDefinition(name = "Tracfone GoSmart API Path Es", description = "Configuration for GoSmart API Path Es", type = AttributeType.STRING)
	String getApiPathGoSmartEs() default "https://www.gosmartmobile.com/wps/wcm/connect/GoSmart%20ES/Shop/Service+Plans/serviceplans?subtype=application/json&devicetype=Wireless";
	
	@AttributeDefinition(name = "Get GDP Enrollment Save API", description = "Get GDP Enrollment Save API")
	String getGdpEnrollmentSaveApiPath() default "/customer-mgmt/gdp-customer/profile/{customerId}";


	@AttributeDefinition(name = "Tracfone Access Token WFM API Path", description = "Configuration for Access token API Path for WFM", type = AttributeType.STRING)
	String getApiPathAccessTokenWFM() default "https://sitfapifull.tracfone.com/oauth/cc";
	
	@AttributeDefinition(name = "Tracfone Access Token SM API Path", description = "Configuration for Access token API Path for SM", type = AttributeType.STRING)
	String getApiPathAccessTokenSM() default "https://sitfapifull.tracfone.com/oauth/cc";
	
	@AttributeDefinition(name = "Tracfone Access Token NET10 API Path", description = "Configuration for Access token API Path for NET10", type = AttributeType.STRING)
	String getApiPathAccessTokenNET10() default "https://sitfapifull.tracfone.com/oauth/cc";

	@AttributeDefinition(name = "Tracfone API Client Secret", description = "Configuration for Client Secret for Access Token API ", type = AttributeType.STRING)
	String getClientSecret() default "abc123**";

	@AttributeDefinition(name = "API FCC ClientId", description = "Configuration for API ClientId in FCC API")
	String fccApiClientId() default "184119e4c97ebce0cc8fd412a24ba804";

	@AttributeDefinition(name = "Get ACP Migration Eligibility API", description = "Get ACP Migration Eligibility API", type = AttributeType.STRING)
	String getAcpMigrationEligibiltyApiPath() default "/service-qualification-mgmt/safelink-migration-eligibility";

	@AttributeDefinition(name = "Support Min Validate Api", description = "to validate support min validation Api path")
	String getSupportMinValidateApiPath() default "/resource-mgmt/resource/support-min/validate";

	@AttributeDefinition(name = " Verification Code Validate Api", description = "to validate Verificaation code Api path")
	String getVerificationCodeApiPath() default "/resource-mgmt/resource/send-verification-code";
	@AttributeDefinition(name = "Genrate Verification Code For Email API Path", description = "To generate otp for email verification")
	String getGenerateVerificaitonCodeForEmailApiPath() default "/customer-mgmt/account/verification-code/generate";

	@AttributeDefinition(name = "Validate Verification Code For Email API Path", description = "To validate otp for email verification")
	String getValidateVerificaitonCodeForEmailApiPath() default "/customer-mgmt/account/verification-code/validate";

	@AttributeDefinition(name = "BYOP $25 True Facet", description = "BYOP $25 True Facet for Byop $25 promotional offer", type = AttributeType.STRING)
	String[] getByop25TrueFacet() default { "STRAIGHT_TALK:ads_f186001_ntk_cs%3A%22true%22",
		"TRACFONE:ads_f186001_ntk_cs%3A%22true%22",
		"TOTAL_WIRELESS:ads_f186001_ntk_cs%3A%22true%22" };

	@AttributeDefinition(name = "Promo Eligibility API URI", description = "API call for Promo Eligibility")
	String getPromoEligibilityApiPath() default "/service-qualification-mgmt/service-qualification/promo-eligibility";
	
	@AttributeDefinition(name = "Tribal Land Check", description = "Get API to check if Address is Tribal Land or not")
	String getIsTribalAddressApiPath() default "/address-mgmt/address/tribalstatus";

	@AttributeDefinition(name = "Get GDP Programs API", description = "Get Available GDP programs")
	String getGdpProductOfferingApiPath() default "/catalog-mgmt/gdp-program-offerings";

	@AttributeDefinition(name = "Get Api to Send OTP to  email  provided", description = "Get Api to Send OTP to  email provided")
	String getSendOtpToEmailApiPath() default "/customer-mgmt/customer/verification/generate";

	@AttributeDefinition(name = "Get Api to validate OTP sent to email provided", description = "Get Api to validate OTP sent to email provided")
	String getValidateOtpToEmailApiPath() default "/customer-mgmt/customer/verification/validate";

	@AttributeDefinition(name = "Get Api to submit GDP application", description = "Get Api to submit GDP application")
	String getGdpEnrollmentSubmitApiPath() default "/service-mgmt/gdp/enrollment";

	@AttributeDefinition(name = "Get Api to update GDP application", description = "Get Api to update GDP application")
	String getGdpEnrollmentUpdateApiPath() default "/customer-mgmt/gdp-customer/pre-enrollment/gdp/new-customer/update";

	@AttributeDefinition(name = "Get Api to validate LID of  GDP application", description = "Get Api to validate LID of  GDP application")
	String getGdpLidValidateApiPath() default "/service-qualification-mgmt/gdp-new-customer-eligibility";

	@AttributeDefinition(name = "Get Api to check whether the custimer is eligible for GDP enrollment", description = "Get Api to check whether the custimer is eligible for GDP enrollment")
	String getGdpEnrollmentEligibilityApiPath() default "/service-qualification-mgmt/gdp-eligibility";

	@AttributeDefinition(name = "BYOP register for GDP", description = "BYOP registration for GDP")
	String getGdpByopRegistrationApiPath() default "/product-inventory-mgmt/product/register";

	@AttributeDefinition(name = "GDP Application Status API", description = "GDP Application Status API")
	String getGdpEnrollmentStatusApiPath() default "/service-mgmt/gdp/enrollment/status";
        @AttributeDefinition(name = "E911 Adress URL", description = "E911 Adress URL", type = AttributeType.STRING)
        String getE911AdressUrl() default "/customer-mgmt/customer/profile/address";

        @AttributeDefinition(name = "E911 Adress Validatiom URL", description = "E911 Adress URL", type = AttributeType.STRING)
        String getE911AdressGeoLocationValidationUrl() default "/geolocation-mgmt/address/validate";

        @AttributeDefinition(name = "Customer Promotion Details Api Path", description = "URI of Customer Promotion Details API")
        String getByopPromotionDetailsApiPath() default "/service-mgmt/service-alert";

        @AttributeDefinition(name = "Verify Email API", description = "to verify the email using token")
        String getVerifyEmailByTokenApiPath() default "/customer-mgmt/email/verifyEmail";

        @AttributeDefinition(name = "Real Email check API", description = "To validate the email is real non blocked email")
        String getRealEmailCheckApiPath() default "/customer-mgmt/email/validate";
			
        @AttributeDefinition(name = "DCOT Upgrade Promotion URL", description = "DCOT Upgrade Promotion URL for 45,55 and 65 Plan", type = AttributeType.STRING)
        String getDcotUpgradePromotion() default "/customer-mgmt/customer/{accountId}/promotion";

	@AttributeDefinition(name = " TopUpBalance Api", description = "to add balance to Account wallet path")
        String getTopUpBalanceApiPath()  default "/prepay-balance-mgmt/topupBalance";

        @AttributeDefinition(name = " ViewBalance Api", description = "to get available balance of the user from his wallet")
        String getViewBalanceApiPath()  default "/prepay-balance-mgmt/bucket";

        @AttributeDefinition(name = "Line freeze for Renewal", description = "Line freeze for Renewal")
        String updateFreezeLineForRenewalApiPath() default "/service-mgmt/service/renewal-action";

        @AttributeDefinition(name = "5G mobile Facet", description = "5G capable mobile Facet")        
        String[] fiveGCapablefacet() default {"TOTAL_WIRELESS:ads_f154501_ntk_cs%3A%225G+Capable%22"};

        @AttributeDefinition(name = "ST All devices page URL", description = "ST All devices page URL", type = AttributeType.STRING)
        String getStExpolreDevicesURL() default "/devices/wifi-hotspots";

        @AttributeDefinition(name = "VAS Purchase API Path" , description = "VAS Purchase API Path")
        String getVasPurchaseApiPath() default "/service-qualification-mgmt/service-qualification/vas-purchase";

        @AttributeDefinition(name = "Webview Change Plan API ClientId", description = "Configuration for Webview Change Plan API ClientId", type = AttributeType.STRING)
        String[] getWebViewChangePlanApiClientId() default {"STRAIGHT_TALK:c639537fc4dcce998cf62a91803ffa88"};

        @AttributeDefinition(name="TWP Refund API Path", description="TWP Refund API Path")
        String getRefundOptionsApiPath() default "/order-mgmt/order/refund-options";

}
