package com.tracfonecore.core.beans;

/**
 * <p>Defines bean to hold promo card detail</p>
 */
public class PromoCardsBean {
	
	private String headlineText;
	private String subHeadlineText;
	private String promoCardImage;
	private String promoCardImageAltText;
	private String promoCardCtaText;
	private String promoCardCtaLink;
	private String promoCardTextColor;
	private String promoCardBgColor;
	private String promoCardButtonClassName;
	private String promoCardTextHeadingColor;
	private String promoCardTextSubHeadingColor;
	private String promoCardImageAssetId;
	private String promoCardImageAssetAgencyId;


	public String getHeadlineText() {
		return headlineText;
	}
	public void setHeadlineText(String headlineText) {
		this.headlineText = headlineText;
	}

	public String getSubHeadlineText() {
		return subHeadlineText;
	}
	public void setSubHeadlineText(String subHeadlineText) {
		this.subHeadlineText = subHeadlineText;
	}

	public String getPromoCardImage() {
		return promoCardImage;
	}
	public void setPromoCardImage(String promoCardImage) {
		this.promoCardImage = promoCardImage;
	}

	public String getPromoCardImageAltText() {
		return promoCardImageAltText;
	}
	public void setPromoCardImageAltText(String promoCardImageAltText) {
		this.promoCardImageAltText = promoCardImageAltText;
	}

	public String getPromoCardCtaText() {
		return promoCardCtaText;
	}
	public void setPromoCardCtaText(String promoCardCtaText) {
		this.promoCardCtaText = promoCardCtaText;
	}

	public String getPromoCardCtaLink() {
		return promoCardCtaLink;
	}
	public void setPromoCardCtaLink(String promoCardCtaLink) {
		this.promoCardCtaLink = promoCardCtaLink;
	}

	public String getPromoCardTextColor() {
		return promoCardTextColor;
	}
	public void setPromoCardTextColor(String promoCardTextColor) {
		this.promoCardTextColor = promoCardTextColor;
	}
	
	public String getPromoCardBgColor() {
		return promoCardBgColor;
	}
	public void setPromoCardBgColor(String promoCardBgColor) {
		this.promoCardBgColor = promoCardBgColor;
	}

	public String getPromoCardButtonClassName() {
		return promoCardButtonClassName;
	}
	public void setPromoCardButtonClassName(String promoCardButtonClassName) {
		this.promoCardButtonClassName = promoCardButtonClassName;
	}

	public String getPromoCardTextHeadingColor() {
		return promoCardTextHeadingColor;
	}
	public void setPromoCardTextHeadingColor(String promoCardTextHeadingColor) {
		this.promoCardTextHeadingColor = promoCardTextHeadingColor;
	}

	public String getPromoCardTextSubHeadingColor() {
		return promoCardTextSubHeadingColor;
	}
	public void setPromoCardTextSubHeadingColor(String promoCardTextSubHeadingColor) {
		this.promoCardTextSubHeadingColor = promoCardTextSubHeadingColor;
	}

	public String getPromoCardImageAssetId() {
		return promoCardImageAssetId;
	}
	public void setPromoCardImageAssetId(String promoCardImageAssetId) {
		this.promoCardImageAssetId = promoCardImageAssetId;
	}

	public String getPromoCardImageAssetAgencyId() {
		return promoCardImageAssetAgencyId;
	}
	public void setPromoCardImageAssetAgencyId(String promoCardImageAssetAgencyId) {
		this.promoCardImageAssetAgencyId = promoCardImageAssetAgencyId;
	}

}
