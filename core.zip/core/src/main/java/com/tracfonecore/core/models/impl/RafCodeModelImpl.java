package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.settings.SlingSettingsService;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.RafCodeModel;
import com.tracfonecore.core.utils.ApplicationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { RafCodeModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/rafcode", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true")})
public class RafCodeModelImpl implements RafCodeModel{
	
	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue
	private String heading;

  @ValueMapValue
	private String subHeading;

  @ValueMapValue
	private String rafCodePageImagePath;

	@ValueMapValue
	private String rafCodeheading;

	@ValueMapValue
	private String rafCodePlaceHolder;

	@ValueMapValue
	private String minHeading;

	@ValueMapValue
	private String minPlaceHolder;

  @ValueMapValue
	private String termsConditionsPagePath;

  @ValueMapValue
	private String privacyPolicyPagePath;

  @ValueMapValue
	private String termsConditionsAriaLabel;

  @ValueMapValue
	private String continueBtnAriaLabel;

  @ValueMapValue
	private String learnMoreAriaLabel;

  @ValueMapValue
	private String oneTimeErrorCodes;

  @ValueMapValue
	private String threeTimesErrorCodes;

	@Inject
	private Resource resource;

	/**
     * @return String - exported Type
     */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
     * <p>Fetches heading </p>
     *
     * @return String - heading
     */
    @Override
    public String getHeading(){
		return heading;
	}

  /**
     * <p>Fetches sub heading </p>
     *
     * @return String - sub heading
     */
    @Override
    public String getSubHeading(){
		return subHeading;
	}

   /**
     * <p>Fetches raf code image path </p>
     *
     * @return String - raf code image path
     */
    @Override
    public String getRafCodePageImagePath(){
		return rafCodePageImagePath;
	}

    /**
     * <p>Fetches minheading </p>
     *
     * @return String - minheading
     */
    @Override
    public String getMinHeading(){
		return minHeading;
	}

    /**
     * <p>Fetches min placeholder </p>
     *
     * @return String - min placeholder
     */
    @Override
    public String getMinPlaceHolder(){
		return minPlaceHolder;
	}

    /**
     * <p>Fetches rafcode heading </p>
     *
     * @return String - rafcode heading
     */
    @Override
    public String getRafCodeheading(){
		return rafCodeheading;
	}

    /**
     * <p>Fetches raf code placehoder </p>
     *
     * @return String - raf code placeholder
     */
    @Override
    public String getRafCodePlaceHolder(){
		return rafCodePlaceHolder;
	}

  /**
     * <p>Fetches path for termsandconditions </p>
     *
     * @return String - path for termsandconditions
     */
    @Override
    public String getTermsConditionsPagePath(){
		return termsConditionsPagePath;
	}

  /**
     * <p>Fetches path for privacyPolicyPagePath </p>
     *
     * @return String - path for privacyPolicyPagePath
     */
    @Override
    public String getPrivacyPolicyPagePath(){
		return privacyPolicyPagePath;
	}

   /**
     * <p>Fetches path for termsandconditions </p>
     *
     * @return String - path for termsandconditions
     */
    @Override
    public String getTermsConditionsAriaLabel(){
		return termsConditionsAriaLabel;
	}

   /**
     * <p>Fetches path for continueBtnAriaLabel </p>
     *
     * @return String - path for continueBtnAriaLabel
     */
    @Override
    public String getContinueBtnAriaLabel(){
		return continueBtnAriaLabel;
	}

  /**
     * <p>Fetches path for learnMoreAriaLabel </p>
     *
     * @return String - path for learnMoreAriaLabel
     */
    @Override
    public String getLearnMoreAriaLabel(){
		return learnMoreAriaLabel;
	}

   /**
     * <p>Fetches path for oneTimeErrorCodes </p>
     *
     * @return String - path for oneTimeErrorCodes
     */
    @Override
    public String getOneTimeErrorCodes(){
		return oneTimeErrorCodes;
	}

   /**
     * <p>Fetches path for threeTimesErrorCodes </p>
     *
     * @return String - path for threeTimesErrorCodes
     */
    @Override
    public String getThreeTimesErrorCodes(){
		return threeTimesErrorCodes;
	}

  
}
