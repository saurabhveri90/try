/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.ApnSettingsModel;

/**
 * Defines the model for APN Settings component
 */
@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ApnSettingsModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/content/apnsettings", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ApnSettingsModelImpl implements ApnSettingsModel {

	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String title;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String instructionsHeading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String settingsUpdateAlertBoxTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String settingsUpdateAlertBoxSummary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String disclaimerText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String footerText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String helpModalLinkText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String helpModalContent;

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>Title of APN Settings component</p>
	 * 
	 * @return String - title
	 */
	@Override
	public String getTitle() {
		return title;
	}

	/**
	 * <p>Instructions Heading.</p>
	 *
	 * @return String - instructionsHeading.
	 */
	@Override
	public String getInstructionsHeading() {
		return instructionsHeading;
	}

	/**
	 * <p>Settings Update Alert Box Title.</p>
	 *
	 * @return String - settingsUpdateAlertBoxTitle.
	 */
	@Override
	public String getSettingsUpdateAlertBoxTitle() {
		return settingsUpdateAlertBoxTitle;
	}

	/**
	 * <p>Settings Update Alert Box Summary</p>
	 * 
	 * @return String - settingsUpdateAlertBoxSummary
	 */
	@Override
	public String getSettingsUpdateAlertBoxSummary() {
		return settingsUpdateAlertBoxSummary;
	}

	/**
	 * <p>Disclaimer Text</p>
	 *
	 * @return String - disclaimerText.
	 */
	@Override
	public String getDisclaimerText() {
		return disclaimerText;
	}

	/**
	 * <p>Footer Text</p>
	 *
	 * @return String - footerText.
	 */
	@Override
	public String getFooterText() {
		return footerText;
	}

	/**
	 * <p>Help Modal Link Text</p>
	 *
	 * @return String - helpModalLinkText.
	 */
	@Override
	public String getHelpModalLinkText() {
		return helpModalLinkText;
	}

	/**
	 * <p>Help Modal Content</p>
	 *
	 * @return String - helpModalContent.
	 */
	@Override
	public String getHelpModalContent() {
		return helpModalContent;
	}

}