/**
 * 
 */
package com.tracfonecore.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.tracfonecore.core.utils.ApplicationUtil;

/**
 * @author vijaykumar.tripathi
 *
 */
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class NavigationQuickLinksModel {

	@Self
	private Resource resource;

	@ValueMapValue(name="ctaPath")
	private String ctaPath;

	@ValueMapValue(name="ctaSize")
	private String ctaSize;

	@ValueMapValue(name="ctaText")
	private String ctaText;

	@ValueMapValue(name="doNotFollow")
	private String doNotFollow;

	@ValueMapValue(name="iconAltText")
	private String iconAltText;

	@ValueMapValue(name="iconPath")
	private String iconPath;

	@ValueMapValue(name="newtab")
	private String newtab;

	/**
	 * @return the resource
	 */
	public Resource getResource() {
		return resource;
	}

	/**
	 * @return the ctaPath
	 */
	public String getCtaPath() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), ctaPath);
	}

	/**
	 * @return the ctaSize
	 */
	public String getCtaSize() {
		return ctaSize;
	}

	/**
	 * @return the ctaText
	 */
	public String getCtaText() {
		return ctaText;
	}

	/**
	 * @return the doNotFollow
	 */
	public String getDoNotFollow() {
		return doNotFollow;
	}

	/**
	 * @return the iconAltText
	 */
	public String getIconAltText() {
		return iconAltText;
	}

	/**
	 * @return the iconPath
	 */
	public String getIconPath() {
		return iconPath;
	}

	/**
	 * @return the newtab
	 */
	public String getNewtab() {
		return newtab;
	}
	
}
