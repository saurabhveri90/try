/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.settings.SlingSettingsService;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.MyRewardsModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.utils.CommerceUtil;
import com.day.cq.wcm.api.Page;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { MyRewardsModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/myrewards", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class MyRewardsModelImpl implements MyRewardsModel {

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private SlingSettingsService settingService;

	@Inject
	private ApplicationConfigService applicationConfigService;

	@Inject
	private Page currentPage;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String positionMyRewards;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String positionAccountNavigation;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String joinRewardsImageFileReference;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String joinRewardsImageAltText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String privacyPolicyPagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String termsConditionsPagePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String categoryIdPlans;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String rewardsPlpPagePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String joinMyRewardsSuccessModalHeading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String joinMyRewardsSuccessModalSubHeading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String alreadyEnrolledModalHeading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String alreadyEnrolledModalSubHeading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String  joinMyRewardsSuccessModalSummary;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String alreadyEnrolledModalSummary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planInfoModalContent;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String disableCaptcha;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enableMyRewardsForNonLoggedIn;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String errorMessageForInactiveDevices;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String selectPlanDatePagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String refillLandingPagePath;
	
	@Override
	public String getPositionMyRewards() {
		return positionMyRewards;
	}

	@Override
	public String getPositionAccountNavigation() {
		return positionAccountNavigation;
	}

	@Override
	public String getJoinRewardsImageFileReference() {
		return joinRewardsImageFileReference;
	}

	@Override
	public String getJoinRewardsImageAltText() {
		return joinRewardsImageAltText;
	}

    @Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getTermsConditionsPagePath() {
		String finalTermsConditionsPagePath = termsConditionsPagePath;
		if (StringUtils.isNotBlank(finalTermsConditionsPagePath) &&  Boolean.TRUE.equals(ApplicationUtil.isInternalLink(finalTermsConditionsPagePath))) {
			if (finalTermsConditionsPagePath.indexOf(ApplicationConstants.HTML_EXTENSION) == -1) {
				finalTermsConditionsPagePath = finalTermsConditionsPagePath + ApplicationConstants.HTML_EXTENSION;
			}
			if (StringUtils.isNotBlank(finalTermsConditionsPagePath)) {
				String ctaPath = request.getResourceResolver().map(finalTermsConditionsPagePath);
				if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
					finalTermsConditionsPagePath = ApplicationUtil.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
				}
			}
		}
		return finalTermsConditionsPagePath;
	}
	private String getShortURL(String serverDomain, String url) {
		if (StringUtils.isNotBlank(url) && StringUtils.isNotBlank(serverDomain) && url.contains(serverDomain)) {
			url = url.split(serverDomain)[1];
		}
		return url;
	}

	@Override
	public String getPrivacyPolicyPagePath() {
		return privacyPolicyPagePath;
	}

	@Override
	public String getCategoryIdPlans() {
		return categoryIdPlans;
	}

	@Override
	public String getJoinMyRewardsSuccessModalHeading() {
		return joinMyRewardsSuccessModalHeading;
	}

	@Override
	public String getJoinMyRewardsSuccessModalSubHeading() {
		return joinMyRewardsSuccessModalSubHeading;
	}

	@Override
	public String getAlreadyEnrolledModalHeading() {
		return alreadyEnrolledModalHeading;
	}

	@Override
	public String getAlreadyEnrolledModalSubHeading() {
		return alreadyEnrolledModalSubHeading;
	}

	@Override
	public String getAlreadyEnrolledModalSummary() {
		return alreadyEnrolledModalSummary;
	}

	@Override
	public String getJoinMyRewardsSuccessModalSummary() {
		return joinMyRewardsSuccessModalSummary;
	}

	@Override
	public String getPlanInfoModalContent() {
		return planInfoModalContent;
	}

	@Override
	public String getJoinRewardsImageAssetId() {
		return ApplicationUtil.getAssetId(joinRewardsImageFileReference,
				request.getResourceResolver(), ApplicationConstants.IMAGE);
	}
	
	@Override
	public String getErrorMessageForInactiveDevices() {
		return errorMessageForInactiveDevices;
	}
	
	@Override
	public String getSelectPlanDatePagePath() {
		return ApplicationUtil.getUrlWithoutDomain(ApplicationUtil.getShortUrl(request.getResourceResolver(), selectPlanDatePagePath));
	}

	@Override
	public String getJoinRewardsImageAssetAgencyId() {
		return ApplicationUtil.getAssetMetaDataValue(joinRewardsImageFileReference,
				request.getResourceResolver(), ApplicationConstants.WEBER_ID);
	}

	@Override
	public String getDisableCaptcha() {
		return disableCaptcha;
	}

	@Override
	public String getReCaptchaSiteKey() {
		return ConfigurationUtil.getConfigValue(applicationConfigService.getReCaptchaSiteKey(), CommerceUtil.getBrandValue(currentPage, getHomePageLevel()));
	}

	@Override
	public int getHomePageLevel() {
		return applicationConfigService.getHomePageLevel();
	}

	@Override
	public String getRefillLandingPagePath() {
		return getFinalPagePath(refillLandingPagePath);
	}
	
	public String getFinalPagePath(String inputPath) {
		String finalPagePath = inputPath;
		if (StringUtils.isNotBlank(finalPagePath) &&  Boolean.TRUE.equals(ApplicationUtil.isInternalLink(finalPagePath))) {
			if (finalPagePath.indexOf(ApplicationConstants.HTML_EXTENSION) == -1) {
				finalPagePath = finalPagePath + ApplicationConstants.HTML_EXTENSION;
			}
			if (StringUtils.isNotBlank(finalPagePath)) {
				String ctaPath = request.getResourceResolver().map(finalPagePath);
				if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
					finalPagePath = ApplicationUtil
							.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
				}
			}
		}
		return finalPagePath;
	}

	@Override
	public Boolean getEnableMyRewardsForNonLoggedIn() {
		return StringUtils.isNotBlank(enableMyRewardsForNonLoggedIn)&& ApplicationConstants.TRUE.equalsIgnoreCase(enableMyRewardsForNonLoggedIn)?true:false;
	}
	
}
