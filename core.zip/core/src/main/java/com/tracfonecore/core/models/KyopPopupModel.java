package com.tracfonecore.core.models;

import org.osgi.annotation.versioning.ProviderType;

import com.adobe.cq.export.json.ComponentExporter;

/**
 * 
 * @author HCL
 * Defines the {@code KYOP Popup Model} Sling Model used for the {@code /apps/tracfone-core/components/content/kyopModal} component.
 *
 */

@ProviderType
public interface KyopPopupModel extends ComponentExporter {

 
    /**
     * Get the headerText
     * @return String - headerText
     */
    public String getHeaderText();  
    
    /**
     * Get the summary
     * @return String - summary
     */
    public String getSummary();  
    
}
