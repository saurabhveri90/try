package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

public interface CtaCardModel extends ComponentExporter {
    /**
	 * <p>
	 * Fetches cardText
	 * </p>
	 * 
	 * @return String - cardText
	 */
	@JsonProperty("cardText")
	public String getCardText();
}