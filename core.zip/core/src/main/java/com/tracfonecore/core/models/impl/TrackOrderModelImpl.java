/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.TrackOrderModel;
import com.tracfonecore.core.utils.ApplicationUtil;
/**
 * Defines the model for Track Order component
 */
@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { TrackOrderModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/trackorder", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class TrackOrderModelImpl implements TrackOrderModel {

	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String forgotOrderIdLinkLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String forgotOrderIdPagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String forgotOrderIdNewWindow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String faqLinkLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String faqLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String faqNewWindow;

	/**
	 * <p>Retrieve Order No API Path</p>
	 * 
	 * @return String - retrieveOrderNoApiPath
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>Forgot Order Id link label</p>
	 * 
	 * @return String - forgotOrderIdLinkLabel
	 */
	@Override
	public String getForgotOrderIdLinkLabel() {
		return forgotOrderIdLinkLabel;
	}

	/**
	 * <p>Forgot Order ID Page Path.</p>
	 * 
	 * @return String - forgotOrderIdPagePath
	 */
	@Override
	public String getForgotOrderIdPagePath() {
		return ApplicationUtil.getUrlWithoutDomain(ApplicationUtil.getShortUrl(request.getResourceResolver(), forgotOrderIdPagePath));
	}

	/**
	 * <<p>Forgot Order ID link target value.</p>
	 * 
	 * @return String - forgotOrderIdNewWindow
	 */
	@Override
	public String getForgotOrderIdNewWindow() {
		return forgotOrderIdNewWindow;
	}

	/**
	 * <p>FAQ link label</p>
	 * 
	 * @return String - faqLinkLabel
	 */
	@Override
	public String getFaqLinkLabel() {
		return faqLinkLabel;
	}

	/**
	 * <p>FAQ link</p>
	 *
	 * @return String - faqLink.
	 */
	@Override
	public String getFaqLink() {
		return ApplicationUtil.getShortUrl(request.getResourceResolver(), faqLink);
	}

	/**
	 * <p>FAQ link target value.</p>
	 *
	 * @return String - faqNewWindow.
	 */
	@Override
	public String getFaqNewWindow() {
		return faqNewWindow;
	}

}