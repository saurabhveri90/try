package com.tracfonecore.core.models.impl.v1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.WifiCallingModel;
import com.tracfonecore.core.utils.ApplicationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { WifiCallingModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/wificalling/v1/wificalling", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class WifiCallingModelImpl implements WifiCallingModel {
	
	@Self
	private SlingHttpServletRequest request;
	
	@ChildResource(name = "checkList")
	private Resource childResource;
	
	@ValueMapValue
	private String heading;
	
	@ValueMapValue
	private String phoneSummary;
	
	@ValueMapValue
	private String phoneSubtitle;
	
	@ValueMapValue
	private String phoneInformationLabel;
	
	@ValueMapValue
	private String changeNumberHyperlinkText;
	
	@ValueMapValue
	private String addressHeading;
	
	@ValueMapValue
	private String addressSummary;
	
	@ValueMapValue
	private String addressInformationLabel;
	
	@ValueMapValue
	private String modalSummary;
	
	@ValueMapValue
	private String ctaTargetLink;
	
	@ValueMapValue
	private String openInNewWindow;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    protected String componentVersion;
	
	@ValueMapValue
	protected String addressLegalStatement;
	
	private List<String> checkList;
	
	@PostConstruct
	protected void initModel() {
		Iterable<Resource> resorceList = Optional.ofNullable(childResource).map(Resource :: getChildren).orElse(Collections.emptyList());
		this.checkList = StreamSupport.stream(resorceList.spliterator(),false)
			.map(Resource :: getValueMap).filter(Objects::nonNull).map(vm -> vm.get("checkListItem", String.class))
				.filter(str -> StringUtils.isNotBlank(str)).collect(Collectors.toList());
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * @return the heading
	 */
	@Override
	public String getHeading() {
		return heading;
	}

	/**
	 * @return the phoneSummary
	 */
	@Override
	public String getPhoneSummary() {
		return phoneSummary;
	}

	/**
	 * @return the phoneSubtitle
	 */
	@Override
	public String getPhoneSubtitle() {
		return phoneSubtitle;
	}

	/**
	 * @return the phoneInformationLabel
	 */
	@Override
	public String getPhoneInformationLabel() {
		return phoneInformationLabel;
	}

	/**
	 * @return the changeNumberHyperlinkText
	 */
	@Override
	public String getChangeNumberHyperlinkText() {
		return changeNumberHyperlinkText;
	}

	/**
	 * @return the checkList
	 */
	@Override
	public List<String> getCheckList() {
		return new ArrayList<>(checkList);
	}
	
	/**
	 * @return the addressHeading
	 */
	@Override
	public String getAddressHeading(){
		return addressHeading;
	}
	
	/**
	 * @return the addressSummary
	 */
	@Override
	public String getAddressSummary(){
		return addressSummary;
	}
	
	/**
	 * @return the addressInformationLabel
	 */
	@Override
	public String getAddressInformationLabel(){
		return addressInformationLabel;
	}
	
	/**
	 * <p>CTA link open in new window value.</p>
	 *
	 * @return String - openInNewWindow.
	 */
	@Override
	public String getOpenInNewWindow() {
		return openInNewWindow;
	}
	
	/**
	 * <p>CTA Target link</p>
	 *
	 * @return String - ctaTargetLink.
	 */
	@Override
	public String getCtaTargetLink() {
		return ApplicationUtil.getShortUrl(request.getResourceResolver(), ctaTargetLink);
	}
	
	/**
	 * <p>Modal Summary value.</p>
	 *
	 * @return String - modalSummary.
	 */
	@Override
	public String getModalSummary() {
		return modalSummary;
	}

	@Override
    public String getComponentVersion() {
        return StringUtils.isNotBlank(componentVersion) ?  componentVersion: "v1";
    }

	@Override
	public String getAddressLegalStatement() {
		return addressLegalStatement;
	}

}
