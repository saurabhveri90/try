package com.tracfonecore.core.models.impl;

import com.tracfonecore.core.models.ByotSimModel;
import com.tracfonecore.core.models.ByotSimOptionsModel;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;


import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.annotation.PostConstruct;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ByotSimModel.class,
    ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/byotsim", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
    @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
    @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ByotSimModelImpl implements ByotSimModel{
    
    private static final Logger LOGGER = LoggerFactory.getLogger(ByotSimModelImpl.class);

    @Self
    private SlingHttpServletRequest request;

    @ChildResource
	private List<ByotSimOptionsModel> options = Collections.emptyList();

    @ValueMapValue
    private String heading;

    @ValueMapValue
    private String summary;
    
    @ValueMapValue
    private String scanText;

    @ValueMapValue
    private String scanPlacement;

    /**
     * <p>Fetches heading</p>
     *
     * @return String - heading
     */
    @Override
    public String getHeading() {
        return heading;
    }

    /**
     * <p>Fetches summary</p>
     *
     * @return String - summary
     */
    @Override
    public String getSummary() {
        return summary;
    }

    /**
     * <p>Fetches all the multi-options</p>
     *
     * @return List - all the multi-options
     */
    @Override
    public List<ByotSimOptionsModel> getOptions() {
        return new ArrayList<ByotSimOptionsModel>(options);
    }

    /**
     * @return String - exportedType
     */
    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }
    
    /**
     * <p>Fetches scanText</p>
     *
     * @return String - scanText
     */
    @Override
    public String getScanText() {
        return scanText;
    }

    /**
     * <p>Fetches scanPlacement</p>
     *
     * @return String - scanPlacement
     */
    @Override
    public String getScanPlacement() {
        return scanPlacement;
    }
}


