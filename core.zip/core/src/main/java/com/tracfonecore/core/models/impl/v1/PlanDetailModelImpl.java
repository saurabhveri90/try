
package com.tracfonecore.core.models.impl.v1;

import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.PlanDetailModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.ItemsExporterUtil;
import com.tracfonecore.core.utils.CommerceUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { PlanDetailModel.class,
		ComponentExporter.class }, resourceType = PlanDetailModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class PlanDetailModelImpl implements PlanDetailModel {
	private static final Logger LOGGER = LoggerFactory.getLogger(PlanDetailModelImpl.class);
	protected static final String RESOURCE_TYPE = "tracfone-core/components/commerce/plandetail/v1/plandetail";

	@Inject
	private Page currentPage;

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private SlingModelFilter slingModelFilter;

	@Inject
	private ModelFactory modelFactory;

	@Inject
    @Via("resource")
    private String showTimer;
	
	@ValueMapValue
	private String planNameDetail;
	
	@ValueMapValue
    private String planNameType;
	
	private String planType;
	private String rewardsPurchaseLabel;
	private String rewardsEarnLabel;
	private String productCardImage;
	private String termsCondModalId;
	private String termsCondModalLabel;
	private String termsCondLink;
	private String termsCondType;
	private String useBazaarVoiceRatings;
	private String selection;
	private String useFullWidthEarnRewards;


	@ScriptVariable
	private ValueMap properties;
	
	@PostConstruct
	public void initModel() {
		fetchPagePropertiesData();
	}

	/**
	 * <p>
	 * Sets value from page properties for productCardImage, productCardHeading,
	 * productCardDescription
	 * </p>
	 *
	 * @return void
	 */
	private void fetchPagePropertiesData() {
			Page parentPage = currentPage.getParent();
			Page ancestorPage = parentPage.getParent();
			ValueMap pageProperties = null;
			
			planType = currentPage.getProperties().get("planType", String.class);
			selection = currentPage.getContentResource().getValueMap().get("partNo", String.class);
			if (CommerceUtil.checkCategoryValues(parentPage.getProperties())) {
				pageProperties = parentPage.getProperties();
			} else if (CommerceUtil.checkCategoryValues(ancestorPage.getProperties())) {
				pageProperties = ancestorPage.getProperties();
			}
			if (pageProperties != null) {
				productCardImage = pageProperties.get(CommerceConstants.PRODUCT_CARD_IMAGE, String.class);
				rewardsPurchaseLabel = pageProperties.get(CommerceConstants.REWARDS_PURCHASE_LABEL, String.class);
				rewardsEarnLabel = pageProperties.get(CommerceConstants.REWARDS_EARN_LABEL, String.class);
				termsCondModalId = pageProperties.get(CommerceConstants.TERMS_AND_CONDITION_MODAL_ID, String.class);
				termsCondModalLabel = pageProperties.get(CommerceConstants.TERMS_AND_CONDITION_MODAL_ID_LINK_LABEL, String.class);
				termsCondLink = pageProperties.get(CommerceConstants.TERMS_AND_CONDITION_LINK, String.class);
				termsCondType = pageProperties.get(CommerceConstants.TERMS_AND_CONDITION_TYPE, String.class);
				useBazaarVoiceRatings = pageProperties.get(CommerceConstants.USE_BAZAAR_VOICE_RATINGS, String.class);
				useFullWidthEarnRewards = pageProperties.get(CommerceConstants.USE_FULL_WIDTH_EARN_REWARDS, String.class);
				LOGGER.debug(
						"product card image: {0}, rewards purchase label: {1}, rewards earn label: {2}",
						productCardImage, rewardsPurchaseLabel, rewardsEarnLabel);				
			}			
	}
	
	/**
	 * <p>
	 * Returns true if valuemap has category type and Id values
	 * </p>
	 *
	 * @return Boolean - true/false
	 */
	private Boolean checkCategoryValues(ValueMap properties) {

		if (properties != null && properties.containsKey(CommerceConstants.CATEGORY_ID)
				&& !properties.get(CommerceConstants.CATEGORY_ID, String.class).isEmpty()
				&& properties.containsKey(CommerceConstants.CATEGORY_TYPE)
				&& !properties.get(CommerceConstants.CATEGORY_TYPE, String.class).isEmpty()) {
			return true;
		}

		return false;
	}
	
	/**
	 * <p>
	 * Fetches Terms and Condition Modal Label/p>
	 * 
	 * @return String - Terms and Condition Modal Label
	 */
	@Override
	public String getTermsCondModalLabel() {
		return termsCondModalLabel;
	}
	/**
	 * <p>
	 * Fetches CTA text of Terms and Condition link/p>
	 * 
	 * @return String - CTA text of Terms and Condition
	 */
	@Override
	public String getTermsCondModalId() {
		String modalId= StringUtils.EMPTY;
		if(StringUtils.isNotBlank(termsCondModalId)) {
			modalId = ApplicationUtil.getLowerCaseWithHyphen(termsCondModalId) + ApplicationConstants.HYPHEN
					+ ApplicationConstants.MODAL;
		}
		return modalId;		
	}
	
	
	/**
	 * @return the termsCondLink
	 */
	public String getTermsCondLink() {
		return termsCondLink;
	}

	/**
	 * @return the termsCondType
	 */
	public String getTermsCondType() {
		return termsCondType;
	}

	/**
	 * <p>
	 * Returns planType from current page properties
	 * </p>
	 *
	 * @return String - planType
	 */
	public String getPlanType() {
		return planType;
	}
	
	/**
	 * <p>
	 * Returns Plan Name Detail authored
	 * </p>
	 *
	 * @return String - planNameDetail
	 */
	@Override
	public String getPlanNameDetail() {
		return planNameDetail;
	}

	/**
	 * <p>
	 * Returns Rewards Purchase Label authored
	 * </p>
	 *
	 * @return String - rewardsPurchaseLabel
	 */
	@Override
	public String getRewardsPurchaseLabel() {
		return rewardsPurchaseLabel;
	}

	/**
	 * <p>
	 * Returns Rewards Earn Label authored
	 * </p>
	 *
	 * @return String - rewardsEarnLabel
	 */
	@Override
	public String getRewardsEarnLabel() {
		return rewardsEarnLabel;
	}

	/**
	 * @return the productCardImage
	 */
	@Override
	public String getProductCardImage() {
		return productCardImage;
	}

	/**
	 * <p>
	 * Returns exporter type
	 * </p>
	 * 
	 * @return String - getexportertype
	 */
	@Override
	public String getExportedType() {

		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Returns json from items
	 * </p>
	 * 
	 * @return Map - items
	 */
	public Map<String, ? extends ComponentExporter> getItems() {
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}
	
	/**
     * <p>
     * Method to return showTimer
     *
     * @return String showTimer
     */
    @Override
    public String getShowTimer() {
        return showTimer;
    }
    
    /**
     * <p>
     * Method to return useBazaarVoiceRatings
     *
     * @return String useBazaarVoiceRatings
     */
    @Override
    public String getUseBazaarVoiceRatings() {
        return useBazaarVoiceRatings;
    }
    
    /**
     * <p>
     * Method to return selection
     *
     * @return String selection
     */
    @Override
    public String getSelection() {
        return selection;
    }
    
    /**
     * <p>
     * Method to return useFullWidthEarnRewards
     *
     * @return String useFullWidthEarnRewards
     */
    @Override
    public String getUseFullWidthEarnRewards() {
        return useFullWidthEarnRewards;
    }
    
    /**
     * <p>
     * Returns Plan Name Type authored
     *
     * @return String - planNameType
     */
    @Override
    public String getPlanNameType() {
    	return planNameType;
    }
    
}
