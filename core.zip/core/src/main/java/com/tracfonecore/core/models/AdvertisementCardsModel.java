/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.AdvertisementCardBean;

/**
 * Defines the {@code Multi-image} Sling Model used for the {@code /apps/tracfone-core/components/spa/commerce/advertisementcards} component.
 */
public interface AdvertisementCardsModel extends ComponentExporter {
	
	public String getImageProfileBreakpoints(String imagePath,String mode);
	
	public String getMobileMediaImagePath(String imagePath, String mobileVersion);
	
	/**
	 * <p>Fetches all the advertisement cards list</p>
	 * 
	 * @return String - all the advertisement cards list
	 */
	@JsonProperty("adCardslist")
	public List<AdvertisementCardBean> getCardsList();

	/**
	 * <p>Fetches componentVersion for the Advertisement Card</p>
	 *
	 * @return String - componentVersion for the Advertisement Card
	 */
	@JsonProperty("componentVersion")
	public String getComponentVersion();
}
