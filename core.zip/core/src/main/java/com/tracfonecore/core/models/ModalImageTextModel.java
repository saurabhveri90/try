/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;


import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.ImageBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.utils.ApplicationUtil;

import java.util.List;
import java.util.Map;

import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface ModalImageTextModel extends ComponentExporter {

	/**
	 * <p>Fetches title</p>
	 * 
	 * @return String - title
	 */
	@JsonProperty("title")
	public String getTitle();

	/**
	 * <p>Fetches modal name</p>
	 * 
	 * @return String - modalName
	 */
	@JsonProperty("modalName")
	public String getModalName();
		
	/**
	 *<p>Fetches modalId</p>
	 *
	 * @return the modalId
	 */
	public String getModalId();
	
	/**
	 *<p>Fetches accessibilityLabel</p>
	 *
	 * @return the accessibilityLabel
	 */
	public String getAccessibilityLabel();
	
	/**
	 *<p>Fetches imageMultiFieldItems</p>
	 *
	 * @return the imageMultiFieldItems
	 */
	public List<ImageBean> getImageMultiFieldItems();

	/**
	 * <p>Fetches number of columns for Image Text items</p>
	 *
	 * @return String - number of columns for Image Text items
	 */
	@JsonProperty("layoutSize")
	public String getLayoutSize();

	/**
	 * <p>Fetches number of columns for Image Text items for mobile</p>
	 *
	 * @return String - number of columns for Image Text items for Mobile
	 */
	@JsonProperty("mobileLayoutSize")
	public String getMobileLayoutSize();

	/**
	 * <p>Fetches style class to display number of columns for image text for desktop</p>
	 *
	 * @return String - number of columns for image text items for Desktop
	 */
	public String getDesktopStyleClass();
	
	/**
	 * <p>Fetches style class to display number of columns for image text for mobie</p>
	 *
	 * @return String - number of columns for image text items for Mobile
	 */
	public String getMobileStyleClass() ;

	/**
	 *<p>Fetches placementText</p>
	 *
	 * @return the placementText
	 */
	public String getPlacementText();

}