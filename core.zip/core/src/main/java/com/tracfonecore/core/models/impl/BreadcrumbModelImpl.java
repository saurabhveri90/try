/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.tracfonecore.core.beans.BreadcrumbBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.SchemaOrgConstants;
import com.tracfonecore.core.models.BreadcrumbModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.ItemsExporterUtil;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.*;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.*;
import java.util.Optional;

@Model(adaptables = {SlingHttpServletRequest.class, Resource.class}, adapters = {
        BreadcrumbModel.class,
        ComponentExporter.class
},
        resourceType = "tracfone-core/components/content/breadcrumb",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true")})
public class BreadcrumbModelImpl implements BreadcrumbModel {

    private static final Logger LOGGER = LoggerFactory.getLogger(BreadcrumbModelImpl.class);
    @ScriptVariable
    private Page currentPage;
    
    @Inject
    private Resource resource;
    
    @SlingObject
    private ResourceResolver resourceResolver;

    @Inject
    private SlingModelFilter slingModelFilter;

    @Inject
    private ModelFactory modelFactory;

    @Self
    private SlingHttpServletRequest request;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private int startLevel;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private boolean hideCurrent;

    private List<BreadcrumbBean> itemsList;
    
    private String breadCrumbSchema;
    private String domainName = "";

    @PostConstruct
    protected void initModel() {
        LOGGER.debug("Inside Custom Breadcrumb init method");
        
        domainName = ApplicationUtil.getDomainNameinURL(request.getRequestURL().toString());
        
            if (itemsList == null) {
                itemsList = createItems();
                this.setBreadCrumbSchema(getBreadcrumbSchemaData(domainName, itemsList));
            }

        LOGGER.debug("Exiting initModel method");
    }

    @Override
    public List<BreadcrumbBean> getItemsList() {
        List<BreadcrumbBean> items = itemsList;
        return items;
    }
    
    /**
	 * 
	 * <p>This method is used to genarate Schema structured data for breadcrumb</p>
	 * @param domainName
	 * @param navItemsList
	 * @return Breadcrumb schema structure
	 */
	private String getBreadcrumbSchemaData(String domainName, List<BreadcrumbBean> navItemsList) {
		
		LOGGER.debug("Entering getBreadcrumbSchemaData method");

		JsonObject jsonObject = null;
		JsonArray jsonArray = new JsonArray();
		jsonObject = new JsonObject();
		
		if(!navItemsList.isEmpty()) {
			
			JsonObject listObject = null;
			JsonObject itemObject = null;
			
			Iterator<BreadcrumbBean> listItr =  navItemsList.iterator();
			int position = 1;
	        while (listItr.hasNext()) {	        	
	        	BreadcrumbBean breadcrumb = listItr.next();	        	
	        	listObject = new JsonObject();
	        	itemObject = new JsonObject();
	            listObject.addProperty(SchemaOrgConstants.AT_TYPE, SchemaOrgConstants.LIST_ITEM);
				listObject.addProperty(SchemaOrgConstants.POSITION, position);
				itemObject.addProperty(SchemaOrgConstants.AT_ID, domainName+ resourceResolver.map(request, breadcrumb.getPageUrl()));
				itemObject.addProperty(SchemaOrgConstants.NAME, breadcrumb.getTitle());
				listObject.add(SchemaOrgConstants.ITEM, itemObject);							
				jsonArray.add(listObject);
				position++;
	        }			
		}

		jsonObject.addProperty(SchemaOrgConstants.AT_CONTEXT, SchemaOrgConstants.SCHEMA_ORG_URL);

		jsonObject.addProperty(SchemaOrgConstants.AT_TYPE, SchemaOrgConstants.BREADCRUMB_LIST);				
		jsonObject.add(SchemaOrgConstants.ITEM_LIST_ELEMENT, jsonArray);
		
		LOGGER.debug("Exiting getBreadcrumbSchemaData method");
		return jsonObject.toString();
	}

    /**
     * <p> This method is used to populate the breadcrumb bean with the page values</p>
     */
    private List<BreadcrumbBean> createItems() {
        LOGGER.debug("Entering BreadcrumbModelImpl.createItems method ");
        List<BreadcrumbBean> navItem = new ArrayList<>();
        PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
        Page resourcePage = Optional.ofNullable(pageManager).map(pm -> pm.getContainingPage(resource.getPath())).orElse(currentPage);
        int currentLevel = Optional.ofNullable(resourcePage).map(Page :: getDepth).orElse(0);
        while (startLevel < currentLevel) {
            Page page = resourcePage.getAbsoluteParent(startLevel);
            if (page != null) {
                BreadcrumbBean breadcrumbBean = new BreadcrumbBean();
                boolean isActivePage = page.equals(resourcePage);
                breadcrumbBean.setActive(isActivePage);
                if (isActivePage && hideCurrent) {
                    break;
                }
                if (!checkHideInBreadcrumb(page)) {
                    navItem.add(getNavigationListItems(page, breadcrumbBean));
                }
            }
            startLevel++;
        }
        LOGGER.debug("Exiting BreadcrumbModelImpl.createItems method ");
        return navItem;
    }

    /**
     * <p> This method is used to get the page properties of the current page and populate the breadcrumb navigation list</p>
     */

    private BreadcrumbBean getNavigationListItems(Page page, BreadcrumbBean breadcrumbBean) {
        LOGGER.debug("Entering BreadcrumbModelImpl.getNavigationListItems method ");
        String breadcrumbTitle = page.getProperties().get(ApplicationConstants.BREADCRUMB_TITLE, String.class);

        breadcrumbBean.setPageUrl(ApplicationUtil.getShortUrl(resourceResolver, page.getPath()));

        if (ApplicationConstants.YES.equalsIgnoreCase(page.getProperties().get(ApplicationConstants.PAGE_NO_FOLLOW, String.class)))
            breadcrumbBean.setDoNotFollowLink(ApplicationConstants.NO_FOLLOW);
        else
            breadcrumbBean.setDoNotFollowLink(ApplicationConstants.FOLLOW);

        String title = "";
        if (StringUtils.isNotEmpty(breadcrumbTitle)) {
            title = breadcrumbTitle;
        } else if (StringUtils.isNotEmpty(page.getNavigationTitle())) {
            title = page.getNavigationTitle();
        } else if (StringUtils.isNotEmpty(page.getPageTitle())) {
            title = page.getPageTitle();
        } else {
            title = page.getTitle();
        }
        breadcrumbBean.setTitle(title);
        LOGGER.debug("Entering BreadcrumbModelImpl.getNavigationListItems method ");
        return breadcrumbBean;
    }

    private boolean checkHideInBreadcrumb(Page page) {
        String hideInBreadcrumb = page.getProperties().get(ApplicationConstants.HIDE_IN_BREADCRUMB, ApplicationConstants.FALSE);
        return (ApplicationConstants.TRUE).equalsIgnoreCase(hideInBreadcrumb);
    }

    @Override
    public int getStartLevel() {
        return startLevel;
    }

    @Override
    public boolean getHideCurrent() {
        return hideCurrent;
    }

    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

    public Map<String, ? extends ComponentExporter> getItems() {
        return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
    }

	@Override
	public String getBreadCrumbSchema() {
		return this.breadCrumbSchema;
	}

	@Override
	public void setBreadCrumbSchema(String breadcrumbSchema) {
		this.breadCrumbSchema = breadcrumbSchema;
		
	}

}