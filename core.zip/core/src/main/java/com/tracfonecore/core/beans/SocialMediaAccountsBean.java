package com.tracfonecore.core.beans;

import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.utils.ApplicationUtil;

public class SocialMediaAccountsBean {
	
	private String accountTitle;
	private String accountLogoImage;
	private String accountLogoImageAltText;
	private String accountLogoImageAssetId;
	private String accountLogoImageAssetAgencyId;
	
	public String getAccountTitle() {
		return accountTitle;
	}
	public void setAccountTitle(String accountTitle) {
		this.accountTitle = accountTitle;
	}
	public String getAccountLogoImage() {
		return accountLogoImage;
	}
	public void setAccountLogoImage(String accountLogoImage) {
		this.accountLogoImage = accountLogoImage;
	}
	public String getAccountLogoImageAltText() {
		return accountLogoImageAltText;
	}
	public void setAccountLogoImageAltText(String accountLogoImageAltText) {
		this.accountLogoImageAltText = accountLogoImageAltText;
	}
	public String getAssetId() {
		return accountLogoImageAssetId;
	}
	public void setAccountLogoImageAssetId(String accountLogoImageAssetId) {
		this.accountLogoImageAssetId = accountLogoImageAssetId;
	}

	public String getAssetAgencyId() {
		return accountLogoImageAssetAgencyId;
	}
	public void setAccountLogoImageAssetAgencyId(String accountLogoImageAssetAgencyId) {
		this.accountLogoImageAssetAgencyId = accountLogoImageAssetAgencyId;
	}

}
