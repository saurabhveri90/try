/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;

/**
 * <p>Defines bean to hold card-flow-transaction mapping detail</p>
 */
public class CardFlowMappingBean {

	private String deviceType;
	private String flowType;
	private String transactionType;
	private String enableCard;
	
	/**
	 * <p>Fetches Device type of the card flow mapping</p>
	 * 
	 * @return String - Device type of the card flow mapping
	 */
	public String getDeviceType() {
		return deviceType;
	}
	/**
	 * <p>Fetches Flow type of the card flow mapping</p>
	 * 
	 * @return String - Flow type of the card flow mapping
	 */
	public String getFlowType() {
		return flowType;
	}
	/**
	 * <p>Fetches Transaction type of the card flow mapping</p>
	 * 
	 * @return String - Transaction type of the card flow mapping
	 */
	public String getTransactionType() {
		return transactionType;
	}
	/**
	 * <p>Fetches enable flag of the card for flow-transaction type</p>
	 * 
	 * @return String - enable flag of the card for flow-transaction type
	 */
	public String getEnableCard() {
		return enableCard;
	}
	/**
	 * <p>Sets Device type of the card flow mapping</p>
	 * 
	 * @param deviceType
	 */
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	/**
	 * <p>Sets Flow type of the card flow mapping</p>
	 * 
	 * @param flowType
	 */
	public void setFlowType(String flowType) {
		this.flowType = flowType;
	}
	/**
	 * <p>Sets Transaction type of the card flow mapping</p>
	 * 
	 * @param transactionType
	 */
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	/**
	 * <p>Sets enable flag of the card for flow-transaction type</p>
	 * 
	 * @param enableCard
	 */
	public void setEnableCard(String enableCard) {
		this.enableCard = enableCard;
	}

}
