package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.AccessibilityFeaturesModel;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { AccessibilityFeaturesModel.class,
        ComponentExporter.class }, resourceType = "tracfone-core/components/content/accessibilityfeatures", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class AccessibilityFeaturesModelImpl implements AccessibilityFeaturesModel {

    private static final Logger LOGGER = LoggerFactory.getLogger(AccessibilityFeaturesModelImpl.class);

    @Self
    private SlingHttpServletRequest request;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String label;

    @Inject
    @Via("resource")
    private Resource accPhoneFeatures;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String accDevicesSummary;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String accDevicesSummarySub;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String accDevicesSummarySubLink;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String accDevicesSummarySubLinkLabel;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String doNotFollow;

    @Inject
    @Via("resource")
    private Resource accDeviceInfoLinks;

    @PostConstruct
    private void initModel() {
        LOGGER.debug("Entering initModel method: AccessibilityFeaturesModelImpl");
    }

    @Override
    public String getLabel() {
        return this.label;
    }

    @Override
    public Resource getAccPhoneFeatures() {
        return this.accPhoneFeatures;
    }

    @Override
    public String getAccDevicesSummary() {
        return this.accDevicesSummary;
    }

    @Override
    public String getAccDevicesSummarySub() {
        return this.accDevicesSummarySub;
    }

    @Override
    public String getAccDevicesSummarySubLink() {
        return this.accDevicesSummarySubLink;
    }

    @Override
    public String getAccDevicesSummarySubLinkLabel() {
        return this.accDevicesSummarySubLinkLabel;
    }

    @Override
    public String getDoNotFollow() {
        return doNotFollow;
    }

    @Override
    public Resource getAccDeviceInfoLinks() {
        return this.accDeviceInfoLinks;
    }

    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }
}
