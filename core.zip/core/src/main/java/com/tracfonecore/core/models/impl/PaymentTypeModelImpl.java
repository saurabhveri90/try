package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.beans.LinkBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.PaymentTypeModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { PaymentTypeModel.class,
        ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/paymenttype", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class PaymentTypeModelImpl implements PaymentTypeModel {

    @Self
    private SlingHttpServletRequest request;

    @Inject
    private Resource resource;

    @Inject
    private ApplicationConfigService applicationConfigService;

    @Inject
    private Page currentPage;

    @ScriptVariable
    private ValueMap properties;

    private List<LinkBean> options = Collections.emptyList();
    LinkBean linkBean;

    @ValueMapValue
    private String heading;

    @ValueMapValue
    private String summary;

    @ValueMapValue
    private String promoPlaceholder;

    @ValueMapValue
    private String modalName;

    @ValueMapValue
    private String helpText;

    @ValueMapValue
    private Boolean showpromocode;

    private static final Logger LOGGER = LoggerFactory.getLogger(PaymentTypeModelImpl.class);

    @PostConstruct
    private void initModel() {

        //options = new ArrayList<>();
        options = new ArrayList<LinkBean>();
        for (Resource child : resource.getChildren()) {
            if (ApplicationConstants.OPTIONS.equals(child.getName())) {
                Iterator<Resource> it = child.listChildren();
                setMultiFieldItems(it, options);
            }
        }
    }
    /**
     * <p>Populates a list with all the multi-options</p>
     *
     * @param it - iterator of the parent node
     * @param multiFieldData - list in which the multi options data needs to be set
     */

    private void setMultiFieldItems(Iterator<Resource> it, List<LinkBean> multiFieldData) {
        LOGGER.debug("Entering setMultiFieldItems method");
        while (it.hasNext()) {
            linkBean = new LinkBean();
            Resource grandChild = it.next();
            linkBean.setHeading(grandChild.getValueMap().get("option", String.class));
            linkBean.setLinkText(grandChild.getValueMap().get("placeholder", String.class));
            linkBean.setLinkAltText(grandChild.getValueMap().get("description", String.class));

            multiFieldData.add(linkBean);
        }

        LOGGER.debug("Exiting setMultiFieldItems method ");
    }

    @Override
    public String getHeading() {
        return heading;
    }

    @Override
    public String getSummary() {
        return summary;
    }

    @Override
    public List<LinkBean> getOptions() {
        return new ArrayList<LinkBean>(options);
    }

    /**
     * @return String - exportedType
     */
    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

    @Override
    public String getPromoCodePlaceholder() {
        return promoPlaceholder;
    }

    @Override
    public String getPromoCodeModalId() {
        return ApplicationUtil.getLowerCaseWithHyphen(modalName) + ApplicationConstants.HYPHEN
                + ApplicationConstants.MODAL;
    }

    @Override
    public String getHelpText() {
        return helpText;
    }

    @Override
    public Boolean getShowPromoCode() {
        return showpromocode;
    }

    /**
     * @return homePageLevel
     */
    private int getHomePageLevel() {
        return applicationConfigService.getHomePageLevel();
    }

    @Override
    public String getShowPromo() {
        String enablePromoCodeFlag = null;
        String[] enableActivationRefillPromoCodeArray = applicationConfigService.enableActivationRefillPromoCode();
        String brandName = CommerceUtil.getBrandValue(currentPage, getHomePageLevel());
        if (StringUtils.isNotBlank(brandName) && enableActivationRefillPromoCodeArray != null && showpromocode) {
            enablePromoCodeFlag = ConfigurationUtil.getConfigValue(enableActivationRefillPromoCodeArray, brandName);
        }
        return enablePromoCodeFlag;
    }
}
