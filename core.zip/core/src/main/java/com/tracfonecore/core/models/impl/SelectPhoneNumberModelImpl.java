package com.tracfonecore.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.SelectPhoneNumberModel;
import com.tracfonecore.core.utils.ApplicationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { SelectPhoneNumberModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/selectphonenumber", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class SelectPhoneNumberModelImpl implements SelectPhoneNumberModel {

	@Self
	private SlingHttpServletRequest request;
	
	@ValueMapValue
	private String title;
	
	@ValueMapValue
	private String selectionTitle;
	
	@ValueMapValue
	private String dropDownPlaceHolder;
	
	@ValueMapValue
	private String sumbitButtonLabel;
	
	@ValueMapValue
	private String link;
	
	/**
	 * @return the title
	 */
	@Override
	public String getTitle() {
		return title;
	}

	/**
	 * @return the selectionTitle
	 */
	@Override
	public String getSelectionTitle() {
		return selectionTitle;
	}

	/**
	 * @return the link
	 */
	@Override
	public String getLink() {
		return ApplicationUtil.getUrlWithoutDomain(ApplicationUtil.getShortUrl(request.getResourceResolver(), link));
	}

	/**
	 * @return the dropDownPlaceHolder
	 */
	@Override
	public String getDropDownPlaceHolder() {
		return dropDownPlaceHolder;
	}

	/**
	 * @return the sumbitButtonLabel
	 */
	@Override
	public String getSumbitButtonLabel() {
		return sumbitButtonLabel;
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

}
