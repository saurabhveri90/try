/**
 *  Copyright 2019 HCL Technologies Ltd.
 *  
 */
package com.tracfonecore.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Extended Plans Configuration Service", description = "Extended Plans Configuration Service")
public @interface ExtendedPlansConfig {
	
	@AttributeDefinition(name = "Extended Plans Query", description = "Please provide extended plans query.", type = AttributeType.STRING)
	String getExtPlanQuery() default "&projection=bysearchtermoptimized&searchKeyword=*&facet=(ads_f140005_ntk_cs:\"Extended%20Plans\")";
	
	@AttributeDefinition(name = "Extended Plans Query with Spanish Facet", description = "Please provide extended plans query with Spanish Facet.", type = AttributeType.STRING)
	String getExtPlanQueryESFacet() default "&projection=bysearchtermoptimized&searchKeyword=*&facet=(ads_f140005_ntk_cs:\"Planes%20Extendidos\")";
	
}

