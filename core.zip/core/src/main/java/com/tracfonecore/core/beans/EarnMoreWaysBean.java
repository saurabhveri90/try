package com.tracfonecore.core.beans;

/**
 * <p>Defines bean to hold earn more ways detail</p>
 */
public class EarnMoreWaysBean {
	
	private String earnMoreWaysCardTitle;
	private String earnMoreWaysCardClassName;
	
	public String getEarnMoreWaysCardTitle() {
		return earnMoreWaysCardTitle;
	}
	public void setEarnMoreWaysCardTitle(String earnMoreWaysCardTitle) {
		this.earnMoreWaysCardTitle = earnMoreWaysCardTitle;
	}

	public String getEarnMoreWaysCardClassName() {
		return earnMoreWaysCardClassName;
	}
	public void setEarnMoreWaysCardClassName(String earnMoreWaysCardClassName) {
		this.earnMoreWaysCardClassName = earnMoreWaysCardClassName;
	}

}
