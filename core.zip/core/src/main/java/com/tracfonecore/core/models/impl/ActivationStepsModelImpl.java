/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.ActivationStepsModel;


@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ActivationStepsModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/activationsteps", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ActivationStepsModelImpl implements ActivationStepsModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ctaAltText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ctaLabel;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String title;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headingSummary;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String footerText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String rafCodePageInfo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String showActivatedEsn;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean showRafCodePage;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String esnTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String homeInternetHeadingSummary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String errorCodes;
		
	@Override
	public String getCtaAltText() {
		return ctaAltText;
	}

	@Override
	public String getCtaLabel() {
		return ctaLabel;
	}
	
	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public String getHeadingSummary() {
		return headingSummary;
	}

	/**
	 * <p>Fetches showActivatedEsn flag for activation steps</p>
	 *
	 * @return Boolean - showActivatedEsn flag for activation steps
	 */
	@Override
	public String getShowActivatedEsn() {
		return showActivatedEsn;
	}

	/**
	 * <p>Fetches esnTitle for activation steps</p>
	 *
	 * @return Boolean - esnTitle for activation steps
	 */
	@Override
	public String getEsnTitle() {
		return esnTitle;
	}

	@Override
	public String getFooterText() {
		return footerText;
	}

	@Override
	public String getRafCodePageInfo() {
		return rafCodePageInfo;
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getHomeInternetHeadingSummary() {
		return homeInternetHeadingSummary;
	}

	/**
	 * <p>Fetches showRafCodePage flag for activation steps</p>
	 *
	 * @return Boolean - showRafCodePage flag for activation steps
	 */
	@Override
	public Boolean getShowRafCodePage() {
		return showRafCodePage;
	}

	@Override
	public String getErrorCodes() {
		return errorCodes;
	}

}
