/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.VeriffModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { VeriffModel.class,
        ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/veriff", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class VeriffModelImpl implements VeriffModel {

    @Self
    private SlingHttpServletRequest request;

    @Inject
    private Page currentPage;

    @ValueMapValue
    private String ctaText;

    @ValueMapValue
    private String ctaAccessibility;

    @ValueMapValue
    private String heading;

    @ValueMapValue
    private String summary;

    @ValueMapValue
    private String veriffCtaText;

    @ValueMapValue
    private String footnote;

    @ValueMapValue
    private String decisionApiTimer;

    @ValueMapValue
    private String velocityDeclineCodes;

    @ValueMapValue
    private String successfulHeading;

    @ValueMapValue
    private String unsuccessfulHeading;

    @ValueMapValue
    private String successfulSummary;

    @ValueMapValue
    private String resubmissionSummary;

    @ValueMapValue
    private String declineSummary;

    @ValueMapValue
    private String velocityDeclineSummary;

    @ValueMapValue
    private String successfulButtonText;

    @ValueMapValue
    private String successfulAccButtonText;

    @ValueMapValue
    private String resubmissionButtonText;

    @ValueMapValue
    private String resubmissionAccButtonText;

    @ValueMapValue
    private String declineButtonText;

    @ValueMapValue
    private String declineAccButtonText;

    @ValueMapValue
    private String logo;

    @ValueMapValue
    private String imageAltText;

    @ValueMapValue
    private String declineSecButtonText;

    @ValueMapValue
    private String declineSecAccButtonText;

    @Inject
    private TracfoneApiGatewayService tracfoneApiGatewayService;

    @Inject
    private ApplicationConfigService applicationConfigService;

    @ValueMapValue
    private String decisionApiRetry;

    @ValueMapValue
    private String decisionLoaderHeading;

    @ValueMapValue
    private String expiredVeriffMessage;


    private String plansPagePath;
    
	@PostConstruct
	protected void initModel() {
         setPlansPagePath(CommerceUtil
								.getPagePropertyValue(currentPage, getHomePageLevel(), CommerceConstants.PLANS_PAGE_PATH)!=null?CommerceUtil
										.getPagePropertyValue(currentPage, getHomePageLevel(), CommerceConstants.PLANS_PAGE_PATH)
										.toString():StringUtils.EMPTY);
	}
    /**
     * @return String return the ctaText
     */
    @Override
    public String getPlansPLPPagePath() {
        return plansPagePath;
    }

     /**
     * @param plansPagePath the plansPagePath to set
     */
    public void setPlansPagePath(String plansPagePath) {
        this.plansPagePath = plansPagePath;
    }

    /**
     * @return String return the ctaText
     */
    @Override
    public String getCtaText() {
        return ctaText;
    }

    /**
     * @return String return the ctaAccessibility
     */
    @Override
    public String getCtaAccessibility() {
        return ctaAccessibility;
    }

    /**
     * @return String return the heading
     */
    @Override
    public String getHeading() {
        return heading;
    }

    /**
     * @return String return the summary
     */
    @Override
    public String getSummary() {
        return summary;
    }

    /**
     * @return String return the veriffCtaText
     */
    @Override
    public String getVeriffCtaText() {
        return veriffCtaText;
    }

    /**
     * @return String return the footnote
     */
    @Override
    public String getFootnote() {
        return footnote;
    }

    /**
     * @return String - exportedType
     */
    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

    /**
     * @return String return the decisionApiTimer
     */
    @Override
    public String getDecisionApiTimer() {
        return decisionApiTimer;
    }

    /**
     * @return String return the veriffDecisionApiPath
     */
    @Override
    public String getVeriffDecisionApiPath() {
        return tracfoneApiGatewayService.getVeriffDecisionApiPath();
    }

    /**
     * @return String - apiDomain
     */
    @Override
    public String getApiDomain() {

        return tracfoneApiGatewayService.getApiDomain();
    }

    /**
     * @return String - apiDomain
     */
    @Override
    public String getVeriffApiKey() {
        return ConfigurationUtil.getConfigValue(tracfoneApiGatewayService.getVeriffApiKey(), getBrand());
    }

    /**
     * @return String - brand
     */
    @Override
    public String getBrand() {
        return CommerceUtil.getBrandValue(currentPage, getHomePageLevel());
    }

    /**
     * @return int - homePageLevel
     */
    @Override
    public int getHomePageLevel() {
        return applicationConfigService.getHomePageLevel();
    }

    /**
     * @return String return the velocityDeclineCodes
     */
    @Override
    public String getVelocityDeclineCodes() {
        return velocityDeclineCodes;
    }

    /**
     * @return String return the successfulHeading
     */
    @Override
    public String getSuccessfulHeading() {
        return successfulHeading;
    }

    /**
     * @return String return the unsuccessfulHeading
     */
    @Override
    public String getUnsuccessfulHeading() {
        return unsuccessfulHeading;
    }

    /**
     * @return String return the successfulSummary
     */
    @Override
    public String getSuccessfulSummary() {
        return successfulSummary;
    }

    /**
     * @return String return the resubmissionSummary
     */
    @Override
    public String getResubmissionSummary() {
        return resubmissionSummary;
    }

    /**
     * @return String return the declineSummary
     */
    @Override
    public String getDeclineSummary() {
        return declineSummary;
    }

    /**
     * @return String return the velocityDeclineSummary
     */
    @Override
    public String getVelocityDeclineSummary() {
        return velocityDeclineSummary;
    }

    /**
     * @return String return the successfulButtonText
     */
    @Override
    public String getSuccessfulButtonText() {
        return successfulButtonText;
    }

    /**
     * @return String return the successfulAccButtonText
     */
    @Override
    public String getSuccessfulAccButtonText() {
        return successfulAccButtonText;
    }

    /**
     * @return String return the resubmissionButtonText
     */
    @Override
    public String getResubmissionButtonText() {
        return resubmissionButtonText;
    }

    /**
     * @return String return the resubmissionAccButtonText
     */
    @Override
    public String getResubmissionAccButtonText() {
        return resubmissionAccButtonText;
    }

    /**
     * @return String return the declineButtonText
     */
    @Override
    public String getDeclineButtonText() {
        return declineButtonText;
    }

    /**
     * @return String return the declineAccButtonText
     */
    @Override
    public String getDeclineAccButtonText() {
        return declineAccButtonText;
    }

    /**
     * Get the logo
     * 
     * @return String - logo
     */
    @Override
    public String getLogo() {
        return logo;
    }

    /**
     * Get the imageAltText
     * 
     * @return String - imageAltText
     */
    @Override
    public String getImageAltText() {
        return imageAltText;
    }

    /**
     * @return String return the declineSecButtonText
     */
    @Override
    public String getDeclineSecButtonText() {
        return declineSecButtonText;
    }

    /**
     * @return String return the declineSecAccButtonText
     */
    @Override
    public String getDeclineSecAccButtonText() {
        return declineSecAccButtonText;
    }

    /**
     * @return String return the decisionApiRetry
     */
    @Override
    public String getDecisionApiRetry() {
        return decisionApiRetry;
    }

    /**
     * <p>
     * Fetches decisionLoaderHeading
     * </p>
     *
     * @return the decisionLoaderHeading
     */
    @Override
    public String getDecisionLoaderHeading() {
        return decisionLoaderHeading;
    }

    /**
     * <p>
     * Fetches expiredVeriffMessage
     * </p>
     *
     * @return the expiredVeriffMessage
     */
    @Override
    public String getExpiredVeriffMessage() {
        return expiredVeriffMessage;
    }
}
