/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.osgi.service.metatype.annotations.Option;

@ObjectClassDefinition(name = "Application Config Service", description = "Application Config Service")
public @interface ApplicationConfig {

	@AttributeDefinition(name = "Homepage Level",description = "Homepage Level", type = AttributeType.INTEGER)
	int homePageLevel() default 3;
	
	@AttributeDefinition(name = "Brand Page Level",description = "Brand Page Level", type = AttributeType.INTEGER)
	int brandPageLevel() default 1;
	
	@AttributeDefinition(name = "Twitter image path", description = "Please provide Twitter default image path from dam")
	String[] twitterImagePath() default {"STRAIGHT_TALK:/content/dam/straighttalk/logos/mobile-logo.svg","TRACFONE:/content/dam/tracfone/logos/mobile-logo.svg"};

	@AttributeDefinition(name = "Open Graph image path", description = "Please provide Open Graph default image path from dam")
	String[] ogImagePath() default {"STRAIGHT_TALK:/content/dam/straighttalk/logos/mobile-logo.svg","TRACFONE:/content/dam/tracfone/logos/mobile-logo.svg"};
    
	@AttributeDefinition(name = "Script Variables Path", description = "Provide the path of script variables.")
	String[] scriptVariablesPath();
	
	@AttributeDefinition(name = "Script Variables Limit", description = "No of items to show in scripting json.")
	String scriptVariablesLimit() default "10000";
	
	@AttributeDefinition(name = "Product Specification images path", description = "Please provide Product Specification images path from dam")
	String[] productSpecImagePath() default {"STRAIGHT_TALK:/content/dam/straighttalk/icons/product-specs/small/","TRACFONE:/content/dam/tracfone/icons/product-specs/small/"};
	
	@AttributeDefinition(name = "Compare Product Specification images path", description = "Please provide Compare Product Specification images path from dam")
	String[] compareProductSpecImagePath() default {"STRAIGHT_TALK:/content/dam/straighttalk/icons/product-specs/large/","TRACFONE:/content/dam/tracfone/icons/product-specs/large/"};
	
	@AttributeDefinition(name = "Country State Mapping", description = "Provide country and state data")
	String[] countryStateMapping();
	
	@AttributeDefinition(name = "Transaction Flow Checkout Steps Mapping", description = "This config determines the checkout steps and its sequence as per the transaction flow. Values you can choose from are: tradeIn,shipping,payment,application,mobileProtection,reviewOrder [*values are case-sensitive]")
	String[] transactionFlowCheckoutMapping();
	
	@AttributeDefinition(name = "Allowed Credit Card Regex", description = "Allowed Credit Card Regex")
	String allowedCreditCardRegex();

	@AttributeDefinition(name = "Allowed Acquisition Credit Card Regex", description = "Allowed Acquisition Credit Card Regex")
	String allowedAcquisitionCreditCardRegex();
	
	@AttributeDefinition(name = "State Toggle Countries Regex", description = "State Toggle Countries Regex")
	String stateToggleCountriesRegex();
	
	@AttributeDefinition(name = "Zip Restricted Countries Regex", description = "Zip Restricted Countries Regex")
	String zipRestrictedCountriesRegex();

	@AttributeDefinition(name = "Allowed Payment Method Regex for Transaction History", description = "Allowed Payment Method Regex for Transaction History")
	String[] allowedPaymentMethodRegex() default {"STRAIGHT_TALK:CREDITCARD|DIGITAL_WALLET","TRACFONE:CREDITCARD|DIGITAL_WALLET"};

	@AttributeDefinition(name = "Web Scripting path in Content Fragment", description = "Web Scripting path in Content Fragment")
	String[] scriptingContentBasePath() default {"STRAIGHT_TALK:/content/dam/straighttalk/{language}/cf/scripting/web","TRACFONE:/content/dam/tracfone/{language}/cf/scripting/web"};
	
	@AttributeDefinition(name = "Web Scripting Default Error Content Fragment", description = "Default Error Content Fragment that needs to be shown if CF not present in Prod")
	String[] defaultErrorCF() default {"STRAIGHT_TALK:_ERR_GENERIC_ERROR.1000","TRACFONE:_ERR_GENERIC_ERROR.1000"};
	
	@AttributeDefinition(name = "Device type param mapping", description = "Device type param for zip to marketing api")
	String [] deviceTypeParam() default {"STRAIGHT_TALK:phone~PHONE;phonesimkit~SIM_TYPE1;tabletsimkit~HOTSPOT;homephone~HOMEPHONE;homeinternet~HOME_INTERNET;tablets~TABLET","TRACFONE:phone~PHONE;phonesimkit~SIM_TYPE1;tabletsimkit~HOTSPOT;homephone~HOMEPHONE;smartpayphone~PHONE;device~HOTSPOT;carconnect~CARCONNECT;homeinternet~HOME_INTERNET"};
	
    @AttributeDefinition(name = "reCaptcha Site Key", description = "Provide the site key for reCaptch.")
    String[] reCaptchaSiteKey() default {"STRAIGHT_TALK:6LfiDsQpAAAAAHj2p8kfrXeRRJAb2VU79-lMTV_H","TRACFONE:6LfiDsQpAAAAAHj2p8kfrXeRRJAb2VU79-lMTV_H"};

	@AttributeDefinition(name = "reCaptcha enterprise Site Key", description = "Provide the site key for reCaptch.")
    String[] reCaptchaEnterpriseSiteKey() default {"STRAIGHT_TALK:6Lcni-kiAAAAAGKMv28uJeVUa8A8StxJnwCEpRWM","TRACFONE:6LcDjukiAAAAAK4lpoJkbftssFV_P-zF-kk187Xn"};

	@AttributeDefinition(name = "No Plan Check", description = "Check for No Plan")
	String noPlanCheck() default "No Plan";
	
	@AttributeDefinition(name = "Skip Plan Check", description = "Check for Skip Plan")
	String skipPlanCheck() default "Skip Plan";
	
	@AttributeDefinition(name = "Extended Plans",description = "Configuration for Extended Plans")
    String[] extendedPlans();
	
	@AttributeDefinition(name = "Previous Recommended Product",description = "Configuration for Previous Recommended Product")
    String[] previousRecommendedProduct();
	
	@AttributeDefinition(name = "Next Recommended Product",description = "Configuration for Next Recommended Product")
    String[] nextRecommendedProduct();
	
	@AttributeDefinition(name = "Cookie mapping", description = "Cookie mapping in the format domain#path#isHttpOnly#isSecure#sameSite. In case of passing subdomain as first parameter, it will create the cookie at subdomain for e.g: .straighttalk.com")
	String [] cookieMapping() default {"STRAIGHT_TALK:LtpaToken2~subdomain#/#true#false#","TRACFONE:LtpaToken2~subdomain#/#true#false#"};

	@AttributeDefinition(name = "iOS Image Name", description = "Product Specification Image Name for Apple")
	String productSpecAppleImageName() default "apple";

	@AttributeDefinition(name = "Android Image Name", description = "Product Specification Image Name for Android")
	String productSpecAndroidImageName() default "android";
	
	@AttributeDefinition(name = "Facet for Plan Purchase With Rewards", description = "This filter used for Most Expensive Plan Card on My Rewards Page")
	String facetForPlanPurchaseWithRewards() default "facet=(ads_f155001_ntk_cs%3A%22TRUE%22)";
	
	@AttributeDefinition(name = "Rewards Plan Type Facets",description = "These facets will be used on Rewards PLP", type = AttributeType.STRING)
    String[] rewardsPLPFacets() default {"allPlans:ads_f155002_ntk_cs%3A%22TRUE%22","addOns:ads_f155002_ntk_cs%3A%22TRUE%22%20AND%20ads_f140005_ntk_cs%3A%22Add-Ons%22","ILD:ads_f155002_ntk_cs%3A%22TRUE%22%20AND%20ads_f155003_ntk_cs%3A%22ILD_ADDON%22","LRP_PLANS:%22ads_f155001_ntk_cs%3A%22TRUE%22%22 AND ads_f155001_ntk_cs%3A%22Activation%22"};

	@AttributeDefinition(name = "All PLP Paths", description = "All PLP Paths with {language} param")
	String[] allPlpPaths() default { "phoneplp:/content/straighttalk/us/{language}/phones-and-devices/phones",
			"deviceplp:/content/straighttalk/us/{language}/phones-and-devices/devices",
			"accessoryplp:/content/straighttalk/us/{language}/phones-and-devices/accessories",
			"planplp:/content/straighttalk/us/{language}/plans-and-services/plans",
			"phonesimplp:/content/straighttalk/us/{language}/phones-and-devices/devices/phone-sim-cards",
			"tabletsimplp:/content/straighttalk/us/{language}/phones-and-devices/devices/tablet-sim-cards",
			"protectionplanplp:/content/straighttalk/us/{language}/plans-and-services/handset-protection",
			"smartpayphoneplp:/content/straighttalk/us/{language}/phones-and-devices/phones" };
	
	@AttributeDefinition(name = "Regex for Transaction type", description = "Regex for Transaction Types")
	String transactionTypeRegex() default "ACTIVATION|DEACTIVATION|REACTIVATION|REDEMPTION";
	
	@AttributeDefinition(name = "Configuration for Redemption Transaction Type",description = "Configuration for Redemption Transaction Type")
    String[] redemptionTransactionType() default {"en:Refill","es:Rellenar"};
    
    @AttributeDefinition(name = "Root Brand Folder Path ", description = "Please provide brand folder path to include components")
	String[] rootBrandFolder() default {"STRAIGHT_TALK:straighttalk","TRACFONE:tracfone"};
	
	@AttributeDefinition(name = "Identifier for data unit conversion ", description = "Please provide identifier for data unit conversion")
	String[] dataUnitConversion() default {"planData", "dataMultiplier"};
	
	@AttributeDefinition(name = "Select Line Handset Regex ", description = "Please provide brand based value for Line Handset Regex")
	String[] selectLineHandsetRegex();
	
	@AttributeDefinition(name = "Service Balance Module Config", description = "Provide brand specific Service balance module config")
	String[] serviceBalanceModuleConfig();

	@AttributeDefinition(name = "Activation Refill PromoCode Enable", description = "Please provide brand based true/false value to enable/disable promocode for Activation/Refill")
	String[] enableActivationRefillPromoCode() default {"STRAIGHT_TALK:false","TRACFONE:true"};
	
	@AttributeDefinition(name = "Pre Order Shipping Method Id ", description = "Please provide brand specific Pre Order Shipping method Id")
	String[] preOrderShippingMethodID() default {"STRAIGHT_TALK:50001","TRACFONE:80001","TOTAL_WIRELESS:70001"};

	@AttributeDefinition(name = "Cyber Source Profiling Domain", description = "Cyber Source Profiling Domain")
	String cyberSourceProfilingDomain() default "https://h.online-metrix.net";

	@AttributeDefinition(name = "Cyber Source Org Id ", description = "Please provide brand specific Cyber Source Org Id")
	String[] cyberSourceOrgId() default {"STRAIGHT_TALK:1snn5n9w","TRACFONE:1snn5n9w"};

	@AttributeDefinition(name = "Merchant Id for Tangible Purchase", description = "Please provide brand specific Cyber Source Merchant Id for Tangible Purchase")
	String[] merchantIdForTangible() default {"STRAIGHT_TALK:tfstraighttalkb2c","TRACFONE:tftracfoneb2c"};

	@AttributeDefinition(name = "Merchant Id for Intangible Purchase without enrollment", description = "Please provide brand specific Cyber Source Merchant Id for Intangible Purchase without enrollment")
	String[] merchantIdForInTangibleWithoutEnrollment() default {"STRAIGHT_TALK:straighttalk","TRACFONE:toppteleco"};

	@AttributeDefinition(name = "Merchant Id for Intangible Purchase with enrollment", description = "Please provide brand specific Cyber Source Merchant Id for Intangible Purchase with enrollment")
	String[] merchantIdForInTangibleWithEnrollment() default {"STRAIGHT_TALK:billingstraighttalk","TRACFONE:billingtracfone"};

	@AttributeDefinition(name = "Disable HPP for Smartpay", description = "Disable HPP for Smartpay")
	String[] disableHppForSmartPay() default {"STRAIGHT_TALK:false","TRACFONE:false"};
	
	@AttributeDefinition(name = "Amazon Prime Enrollment Regex", description = "Amazon Prime Enrollment Regex")
	String amazonPrimeEnrollmentRegex() default "AMZN";
	
	@AttributeDefinition(name = "Disable Rewards Modal", description = "Please provide brand based true/false value to enable/disable rewards modal")
	String[] enableRewardsModal() default {"STRAIGHT_TALK:false","TRACFONE:true"};

	@AttributeDefinition(name = "Facet for HPP Plan Details", description = "This filter used to Get HPP Plan Details")
	String facetForHppPlanDetails() default "ads_f140001_ntk_cs%3A%22{planId}%22";
	
	@AttributeDefinition(name = "Enable Switch Plan Id", description = "Please provide true/false value to enable/disable switch plan id")
	String[] enableSwitchPlanId() default {"STRAIGHT_TALK:true","TRACFONE:false"};
	
	@AttributeDefinition(name = "Phone Type",description = "Configuration for Phone Type")
    String[] phoneType() default {"en:Wireless Phones|planphone","es:Telefonos Moviles|planphone"};

	@AttributeDefinition(name = "Tablet Type",description = "Configuration for Tablet Type")
	String[] tabletType() default {"en:Tablet Devices|plantablets","es:Dispositivos de Tableta|plantablets"};

	@AttributeDefinition(name = "DeEnrollment Timeline Mapping", description = "Provide DeEnrollment Timeline Options")
	String[] selectDeEnrollmentTimeline() default {"IMMEDIATE,END_OF_CYCLE"};

	@AttributeDefinition(name = "OTP Retry Limit", description = "This field should be used for the OTP verification of Two factor Authentication")
	String otpRetryLimit() default "10";

	@AttributeDefinition(name = "otp Expire Time Limit", description = "This field is used for OTP expiry time limit in minutes")
	String otpExpireTimeLimit() default "10";

	@AttributeDefinition(name = "Tealium Script Account name", description = "Tealium Script Account name")
	String tealiumAccountName() default "vzvalue";

	@AttributeDefinition(name = "Tealium Script Profile name", description = "Tealium Script Profile name")
	String[] tealiumProfileName() default {"STRAIGHT_TALK:straighttalk","TOTAL_WIRELESS:totalbyverizon","TRACFONE:tracfone"};

	@AttributeDefinition(name = "Tealium Script Environment name", description = "Tealium Script Environment name")
	String tealiumEnvName() default "dev";

	@AttributeDefinition(name = "Default IP Address", description = "Default IP Address")
	String defaultIpAddress() default "192.168.0.1";
}
