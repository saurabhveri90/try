package com.tracfonecore.core.beans;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ScenarioBasedPromotionalCardBean {
	
	
	private String purchaseScenario;
	private List<PromotionalCardBean> promotionalCardsList = Collections.emptyList();
	
	public String getPurchaseScenario() {
		return purchaseScenario;
	}
	public void setPurchaseScenario(String purchaseScenario) {
		this.purchaseScenario = purchaseScenario;
	}
	public List<PromotionalCardBean> getPromotionalCardsList() {
		return new ArrayList<>(promotionalCardsList);
	}
	public void setPromotionalCardsList(List<PromotionalCardBean> promotionalCardsList) {
		this.promotionalCardsList = new ArrayList<>(promotionalCardsList);
	}

}
