package com.tracfonecore.core.models.impl;

import java.util.Objects;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.tracfonecore.core.models.HearingAidCompatibilityModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { HearingAidCompatibilityModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/hearingaidcompatibility", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class HearingAidCompatibilityModelImpl implements HearingAidCompatibilityModel {
	
	@Self
	private SlingHttpServletRequest request;
	
	@SlingObject
	private ResourceResolver resourceResolver;
	
	@ValueMapValue
	private String brand;
	
	@ValueMapValue
	private String model;
	
	@ValueMapValue
	private String hacRating;
	
	@ValueMapValue
	private String fccId;
	
	@ValueMapValue
	private String availability;
	
	@ValueMapValue
	private String lastUpdatedLabel;
	
	@ValueMapValue
	private String plpPagePath;
	
	private String categoryId;
	
	@PostConstruct
	private void initModel() {
		PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
		this.categoryId = Optional.ofNullable(pageManager).map(pm -> pm.getContainingPage(plpPagePath)).filter(Objects::nonNull)
				.map(Page::getProperties).map(vm -> vm.get("categoryId",String.class)).orElse("");
	}
	
	/**
     * @return String - exported Type
     */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
	/**
	 * @return the brand
	 */
	@Override
	public String getBrand() {
		return brand;
	}

	/**
	 * @return the model
	 */
	@Override
	public String getModel() {
		return model;
	}

	/**
	 * @return the hacRating
	 */
	@Override
	public String getHacRating() {
		return hacRating;
	}

	/**
	 * @return the fccId
	 */
	@Override
	public String getFccId() {
		return fccId;
	}

	/**
	 * @return the availability
	 */
	@Override
	public String getAvailability() {
		return availability;
	}

	/**
	 * @return the lastUpdatedLabel
	 */
	@Override
	public String getLastUpdatedLabel() {
		return lastUpdatedLabel;
	}

	/**
	 * @return the categoryId
	 */
	@Override
	public String getCategoryId() {
		return categoryId;
	}

}
