/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl.v1;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.settings.SlingSettingsService;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.UserAuthenticationModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import com.tracfonecore.core.utils.ConfigurationUtil;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.utils.CommerceUtil;
import com.day.cq.wcm.api.Page;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { UserAuthenticationModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/userauthentication/v1/userauthentication", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class UserAuthenticationnModelImpl implements UserAuthenticationModel {

	@Self
	private SlingHttpServletRequest request;
	
	@Inject
	private SlingSettingsService settingService;

	@Inject
	private ApplicationConfigService applicationConfigService;

	@Inject
	private Page currentPage;

	@ScriptVariable
	private ValueMap properties;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String logoImage;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String checkoutPagePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String logoImageAltText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String returnLinkLabel;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String authLandingPageHeading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headlineCreateAccount;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ageConsent;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String whyNeedThisLinkText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String whyNeedThisLinkModalContent;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String learnMoreLinkText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String learnMoreLinkModalContent;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headlineLogin;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String loginTab1;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String loginTab2;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String whatIsThisLinkText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String whatIsThisLinkModalContent;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String loginLearnMoreLinkText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String loginLearnMoreLinkModalContent;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String title;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String checkBalanceTitle;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headingSummary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String disableCaptcha;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enableFacebookAuth;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    protected String componentVersion;

	@ValueMapValue
	private String twoFAInfoLink;
	
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getCheckoutPagePath() {
		String finalCheckoutPagePath = checkoutPagePath;
        if (StringUtils.isNotBlank(finalCheckoutPagePath) && Boolean.TRUE.equals(ApplicationUtil.isInternalLink(finalCheckoutPagePath))){
        	if(finalCheckoutPagePath.indexOf(ApplicationConstants.HTML_EXTENSION)==-1){
        		finalCheckoutPagePath = finalCheckoutPagePath + ApplicationConstants.HTML_EXTENSION;
        	}
        	if (StringUtils.isNotBlank(finalCheckoutPagePath)) {
    			String ctaPath = request.getResourceResolver().map(finalCheckoutPagePath);
    	  		if(!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
    	  			finalCheckoutPagePath = ApplicationUtil.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
    	  		}
    		}
        }
        return finalCheckoutPagePath;
	}

	private String getShortURL(String serverDomain, String url) {
			if(StringUtils.isNotBlank(url) && StringUtils.isNotBlank(serverDomain) && url.contains(serverDomain)) {
				url = url.split(serverDomain)[1];
			}
			return url;
	}
	 
	@Override
	public String getLogoImage() {
	     return DynamicMediaUtils.changeMediaPathToDMPath(logoImage, request.getResourceResolver());
	}

	@Override
	public String getLogoImageAltText() {
		return logoImageAltText;
	}

	@Override
	public String getReturnLinkLabel() {
		return returnLinkLabel;
	}

	@Override
	public String getAuthLandingPageHeading() {
		return authLandingPageHeading;
	}

	@Override
	public String getHeadlineCreateAccount() {
		return headlineCreateAccount;
	}

	@Override
	public String getAgeConsent() {
		return ageConsent;
	}

	@Override
	public String getWhyNeedThisLinkText() {
		return whyNeedThisLinkText;
	}

	@Override
	public String getWhyNeedThisLinkModalContent() {
		return whyNeedThisLinkModalContent;
	}

	@Override
	public String getLearnMoreLinkText() {
		return learnMoreLinkText;
	}

	@Override
	public String getLearnMoreLinkModalContent() {
		return learnMoreLinkModalContent;
	}

	@Override
	public String getHeadlineLogin() {
		return headlineLogin;
	}

	@Override
	public String getLoginTab1() {
		return loginTab1;
	}

	@Override
	public String getLoginTab2() {
		return loginTab2;
	}

	@Override
	public String getWhatIsThisLinkText() {
		return whatIsThisLinkText;
	}

	@Override
	public String getWhatIsThisLinkModalContent() {
		return whatIsThisLinkModalContent;
	}

	@Override
	public String getLoginLearnMoreLinkText() {
		return loginLearnMoreLinkText;
	}

	@Override
	public String getLoginLearnMoreLinkModalContent() {
		return loginLearnMoreLinkModalContent;
	}
	
	@Override
	public String getTitle() {
		return title;
	}
	
	@Override
	public String getHeadingSummary() {
		return headingSummary;
	}

	@Override
	public String getDisableCaptcha() {
		return disableCaptcha;
	}

	@Override
	public String getReCaptchaSiteKey() {
		return ConfigurationUtil.getConfigValue(applicationConfigService.getReCaptchaSiteKey(), CommerceUtil.getBrandValue(currentPage, getHomePageLevel()));
	}
	
	@Override
	public int getHomePageLevel() {
		return applicationConfigService.getHomePageLevel();
	}
	
	@Override
	public String getEnableFacebookAuth() {
		return enableFacebookAuth;
	}

	/**
	 * @return the checkBalanceTitle
	 */
	@Override
	public String getCheckBalanceTitle() {
		return checkBalanceTitle;
	}
	
	@Override
    public String getComponentVersion() {
        return StringUtils.isNotBlank(componentVersion) ?  componentVersion: "v1";
    }

	/**
	 * @return String - twoFAInfoLink
	 */
	@Override
	public String getTwoFAInfoLink() {
		return twoFAInfoLink;
	}
}
