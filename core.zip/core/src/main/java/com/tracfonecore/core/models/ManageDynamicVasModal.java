package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.tracfonecore.core.beans.DynamicVasBean;


/**
 * Defines the {@code Multi-Links} Sling Model used for the {@code /apps/tracfone-core/components/spa/commerce/managedynamicvas} component.
 */
public interface ManageDynamicVasModal extends ComponentExporter {
	
	@JsonProperty("dynamicVasList")
	public List<DynamicVasBean> getDynamicVasList();

	@JsonProperty("dynamicVasHeading")
	public String getDynamicVasHeading();

	@JsonProperty("dynamicVasSubHeading")
	public String getDynamicVasSubHeading();

	@JsonProperty("noDynamicVasFoundMsg")
	public String getNoDynamicVasFoundMsg();

	@JsonProperty("dynamicVasCategoryId")
	public String getDynamicVasCategoryId();

	@JsonProperty("categoryIdHPP")
	public String getCategoryIdHPP();

	@JsonProperty("hppPlanImage")
	public String getHppPlanImage();

	@JsonProperty("manageClaimsUrl")
	public String getManageClaimsUrl();
	
	@JsonProperty("resumeSubCheckoutUrl")
	public String getResumeSubCheckoutUrl();
	
}
