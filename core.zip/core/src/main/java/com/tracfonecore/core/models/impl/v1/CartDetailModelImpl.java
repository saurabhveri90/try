/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl.v1;

import com.tracfonecore.core.beans.DeEnrollmentReasonsBean;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.*;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.CartDetailModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;

import javax.annotation.PostConstruct;
import javax.inject.Named;
import java.util.ArrayList;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CartDetailModel.class,
        ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/cartdetail/v1/cartdetail", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CartDetailModelImpl implements CartDetailModel {

    @Self
    protected SlingHttpServletRequest request;

    @ScriptVariable
    private ValueMap properties;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String positionCartListing;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String positionOrderSummary;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String checkoutPagePath;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String loginPagePath;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String phonesImagePath;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String phonesLink;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String simsImagePath;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String simsLink;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String dealsImagePath;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String dealsLink;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String termsAndConditionPagePathForRewardSummary;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String componentVersion;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String tracSizeCategoryId;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String parentPathForSimPLPPage;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String simPlanEditURL;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String disableCaptcha;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String editCartPath;
    
    /*Plan first flow*/
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String planOnlyBundleHeading;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String planOnlyBundleSubHeading;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String pickDeviceButtonLabel;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String pickDeviceButtonLink;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String pickDeviceButtonLinkSelector;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String bringYourOwnPhoneButtonLabel;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String bringYourOwnPhoneLink;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String purchaseNewPhoneButtonLabel;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String purchaseNewPhoneLink;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String selectorForPurchaseNewPhoneLink;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String purchaseNewTabletButtonLabel;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String purchaseNewTabletLink;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String selectorForPurchaseNewTabletLink;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String addLineButtonLink;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String addLineButtonLinkSelector;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String addLineButtonDisclaimerText;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private Boolean enablePurchaseToRefillLink;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String purchaseToRefillLinkLabel;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String disableTooltip;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String tooltipText;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String planOnlyDisclaimerRichText;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String hideCheckoutForPlanFirst;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String noDeviceImage;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String twoFAInfoLink;

    /*Set ACP line with free plan*/

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private Boolean enableAcpCheckout;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String acpDisclaimerRichText;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String acpButtonLabel;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String removeAcpDisclaimer;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String removeAcpCTALabel;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String disableAutoRefillCheckboxValidation;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String autoRefillCheckboxValidationText;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String smartpayPurchaseAmount;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String dcotPromoModelTxt;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String dcotArModalHeading;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String dcotArModalBody;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String dcotArModalEnrollBtn;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String dcotArModalEnrollBtnAriaLabel;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String dcotArModalDisenrollBtn;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String dcotArModalDisenrollBtnAriaLabel;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String stBYOPModelTxt;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String byopSimKitPath;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    @Via("autorefill")
    private String stBYOPSimswapTxt;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String tabletHeading;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String tabletDescription;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String tabletShopBtn;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String tabletShopBtnAriaLabel;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String tabletShopCta;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String tabletBuySimBtn;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String tabletBuySimBtnAriaLabel;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String tabletBuySimCta;

    @PostConstruct
    private void initModel() {

        //get child node for stBYOPSimswapTxt
        if (stBYOPSimswapTxt == null || stBYOPSimswapTxt.length() < 1) {
            try {
                stBYOPSimswapTxt =request.getResource().getChild("autorefill").getValueMap().get("stBYOPSimswapTxt").toString();
            }catch(RuntimeException e) {
                stBYOPSimswapTxt = "";
            }
        }

    }

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String uteTaxSurchargeInd;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String uteOtherTax;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String uteMandatoryTax;

    @Override
    public String getPositionCartListing() {
        return positionCartListing;
    }

    @Override
    public String getPositionOrderSummary() {
        return positionOrderSummary;
    }

    @Override
    public String getPhonesImagePath() {
        return phonesImagePath;
    }

    @Override
    public String getPhonesLink() {
        return ApplicationUtil.getShortUrl(request.getResourceResolver(), phonesLink);
    }

    @Override
    public String getSimsImagePath() {
        return simsImagePath;
    }

    @Override
    public String getSimsLink() {
        return ApplicationUtil.getShortUrl(request.getResourceResolver(), simsLink);
    }

    @Override
    public String getDealsImagePath() {
        return dealsImagePath;
    }

    @Override
    public String getDealsLink() {
        return ApplicationUtil.getShortUrl(request.getResourceResolver(), dealsLink);
    }

    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

    @Override
    public String getTermsAndConditionPagePathForRewardSummary() {
        return ApplicationUtil.getShortUrl(request.getResourceResolver(), termsAndConditionPagePathForRewardSummary);
    }

    @Override
    public String getComponentVersion() {
        return StringUtils.isNotBlank(componentVersion) ?  componentVersion: "v1";
    }

    @Override
    public String getTracSizeCategoryId() {
        return tracSizeCategoryId;
    }
    
    @Override
	public String getParentPathForSimPLPPage() {
		return parentPathForSimPLPPage+".plpjson.html";
	}
	
	@Override
	public String getSimPlanEditURL() {
		return simPlanEditURL;
	}

    @Override
    public String getDisableCaptcha() {
        return disableCaptcha;
    }
    
    @Override
	public String getEditCartPath() {
        return ApplicationUtil.getUrlWithoutDomain(ApplicationUtil.getShortUrl(request.getResourceResolver(), editCartPath));
	}
    
    /**Plan first flow*/
    @Override
    public String getPlanOnlyBundleHeading() {
        return planOnlyBundleHeading;
    }
    
    @Override
    public String getPlanOnlyBundleSubHeading() {
        return planOnlyBundleSubHeading;
    }
    
    @Override
    public String getPurchaseNewPhoneButtonLabel() {
        return purchaseNewPhoneButtonLabel;
    }

    @Override
    public String getPurchaseNewPhoneLink() {
        return ApplicationUtil.getUrlWithoutDomain(ApplicationUtil.getShortUrl(request.getResourceResolver(), purchaseNewPhoneLink));
    }
    
    @Override
    public String getSelectorForPurchaseNewPhoneLink() {
        return selectorForPurchaseNewPhoneLink;
    }
    
    @Override
    public String getBringYourOwnPhoneButtonLabel() {
        return bringYourOwnPhoneButtonLabel;
    }
    
    @Override
    public String getBringYourOwnPhoneLink() {
        return ApplicationUtil.getUrlWithoutDomain(ApplicationUtil.getShortUrl(request.getResourceResolver(), bringYourOwnPhoneLink));
    }
    
    @Override
    public String getPickDeviceButtonLabel() {
        return pickDeviceButtonLabel;
    }

    @Override
    public String getPickDeviceButtonLink() {
        return ApplicationUtil.getUrlWithoutDomain(ApplicationUtil.getShortUrl(request.getResourceResolver(), pickDeviceButtonLink));
    }
    
    @Override
    public String getPickDeviceButtonLinkSelector() {
        return pickDeviceButtonLinkSelector;
    }

    @Override
    public String getPurchaseNewTabletButtonLabel() {
        return purchaseNewTabletButtonLabel;
    }

    @Override
    public String getPurchaseNewTabletLink() {
        return ApplicationUtil.getUrlWithoutDomain(ApplicationUtil.getShortUrl(request.getResourceResolver(), purchaseNewTabletLink));
    }

    @Override
    public String getSelectorForPurchaseNewTabletLink() {
        return selectorForPurchaseNewTabletLink;
    }
    @Override
    public String getAddLineButtonLink() {
        return ApplicationUtil.getUrlWithoutDomain(ApplicationUtil.getShortUrl(request.getResourceResolver(), addLineButtonLink));
    }

    @Override
    public String getAddLineButtonDisclaimerText() {
        return addLineButtonDisclaimerText;
    }
    
    @Override
    public String getAddLineButtonLinkSelector() {
        return addLineButtonLinkSelector;
    }
    
    @Override
    public Boolean getEnablePurchaseToRefillLink() {
        return enablePurchaseToRefillLink;
    }

    @Override
    public String getPurchaseToRefillLinkLabel() {
        return purchaseToRefillLinkLabel;
    }
    
    @Override
    public Boolean getDisableTooltip() {
        return StringUtils.isEmpty(disableTooltip)||"false".equalsIgnoreCase(disableTooltip)?false:true;
    }
    
    @Override
    public String getTooltipText() {
        return tooltipText;
    }
    
    @Override
    public String getPlanOnlyDisclaimerRichText() {
        return planOnlyDisclaimerRichText;
    }
    
    @Override
    public Boolean getHideCheckoutForPlanFirst() {
        return StringUtils.isEmpty(hideCheckoutForPlanFirst)||"false".equalsIgnoreCase(hideCheckoutForPlanFirst)?false:true;
    }
    
    @Override
    public String getNoDeviceImage() {
        return DynamicMediaUtils.changeMediaPathToDMPath(noDeviceImage, request.getResourceResolver());
    }

    /**
	 * @return String - twoFAInfoLink
	 */
	@Override
	public String getTwoFAInfoLink() {
		return twoFAInfoLink;
	}

      /*Set ACP line with free plan*/

    @Override
    public Boolean getEnableAcpCheckout() {
        return enableAcpCheckout;
    }
     
    @Override
    public String getAcpDisclaimerRichText() {
    return acpDisclaimerRichText;
    }

    @Override
    public String getAcpButtonLabel() {
        return acpButtonLabel;
    }

    @Override
    public String getRemoveAcpDisclaimer() {
        return removeAcpDisclaimer;
    }

    @Override
    public String getRemoveAcpCTALabel() {
        return removeAcpCTALabel;
    }

    @Override
    public Boolean getDisableAutoRefillCheckboxValidation() {
        return StringUtils.isEmpty(disableAutoRefillCheckboxValidation)||"false".equalsIgnoreCase(disableAutoRefillCheckboxValidation)?false:true;
    }

    @Override
    public String getAutoRefillCheckboxValidationText() {
        return autoRefillCheckboxValidationText;
    }

    @Override
    public String getSmartpayPurchaseAmount() {
        return smartpayPurchaseAmount;
    }

    @Override
    public String getDcotPromoModelTxt() {
        return dcotPromoModelTxt;
    }

    @Override
    public String getStBYOPModelTxt() {
        return stBYOPModelTxt;
    }

    @Override
    public String getByopSimKitPath () { 
        return byopSimKitPath; 
    }

    @Override
    public String getUteTaxSurchargeInd () { 
        return uteTaxSurchargeInd; 
    }

    @Override
	public String getUteOtherTax() {
		return uteOtherTax;
	}

	@Override
	public String getUteMandatoryTax() {
		return uteMandatoryTax;
	}

    @Override
    public String getDcotArModalHeading() {
        return dcotArModalHeading;
    }

    @Override
    public String getDcotArModalBody() {
        return dcotArModalBody;
    }

    @Override
    public String getDcotArModalEnrollBtn() {
        return dcotArModalEnrollBtn;
    }

    @Override
    public String getDcotArModalEnrollBtnAriaLabel() {
        return dcotArModalEnrollBtnAriaLabel;
    }

    @Override
    public String getDcotArModalDisenrollBtn() {
        return dcotArModalDisenrollBtn;
    }

    @Override
    public String getDcotArModalDisenrollBtnAriaLabel() {
        return dcotArModalDisenrollBtnAriaLabel;
    }
    
    public String getStBYOPSimswapTxt () {
        return stBYOPSimswapTxt;
    }

    @Override
    public String getTabletDescription() {
        return tabletDescription;
    }

    @Override
    public String getTabletHeading() {
        return tabletHeading;
    }

    @Override
    public String getTabletShopBtn() {
        return tabletShopBtn;
    }

    @Override
    public String getTabletShopBtnAriaLabel() {
        return tabletShopBtnAriaLabel;
    }

    @Override
    public String getTabletShopCta() {
        return tabletShopCta;
    }

    @Override
    public String getTabletBuySimBtn() {
        return tabletBuySimBtn;
    }

    @Override
    public String getTabletBuySimBtnAriaLabel() {
        return tabletBuySimBtnAriaLabel;
    }

    @Override
    public String getTabletBuySimCta() {
        return tabletBuySimCta;
    }

}
