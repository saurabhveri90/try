/*
 *  Copyright 2024 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Header} Sling Model used for the {@code tracfone-core/components/commerce/refillalertmodal} component.
 */
public interface RefillAlertModalModel extends ComponentExporter {
    /**
     * <p>Fetches reference for the titleModal</p>
     *
     * @return String - reference for the titleModal
     */
    @JsonProperty("titleModal")
    public String getTitleModal();

        
    /**
	 * <p>Fetches text for the mainTextModal</p>
	 *
	 * @return String - text for the mainTextModal
	 */
	@JsonProperty("mainTextModal")
	public String getMainTextModal();

    /**
	 * <p>Fetches text for the button cancel</p>
	 *
	 * @return String - text for the button cancel
	 */
	@JsonProperty("buttonCancelText")
	public String getButtonCancelText();

    /**
	 * <p>Fetches text for the button continue</p>
	 *
	 * @return String - text for the button continue
	 */
	@JsonProperty("buttonAcceptText")
	public String getButtonAcceptText();

      /**
     * <p>Fetches reference for the titleModal for guest user</p>
     *
     * @return String - reference for the titleModal
     */
    @JsonProperty("titleModalGuest")
    public String getTitleModalGuest();

        
   /**
	 * <p>Fetches text for the mainTextModal for guest user</p>
	 *
	 * @return String - text for the mainTextModal
	 */
	@JsonProperty("mainTextModalGuest")
	public String getMainTextModalGuest();

   /**
	 * <p>Fetches text for the button cancel  for guest user</p>
	 *
	 * @return String - text for the button cancel
	 */
	@JsonProperty("buttonCancelTextGuest")
	public String getButtonCancelTextGuest();

    /**
	 * <p>Fetches text for the button continue  for guest user</p>
	 *
	 * @return String - text for the button continue
	 */
	@JsonProperty("buttonAcceptTextGuest")
	public String getButtonAcceptTextGuest();

}
