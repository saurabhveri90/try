package com.tracfonecore.core.models;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.utils.ApplicationUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ButtonListOptionsModel {
    
	@Self
	private Resource resource;
	
	@ValueMapValue
	private String ctaType;
	
	@ValueMapValue
	private String text;
	
	@ValueMapValue
	private String link;

	@ValueMapValue
	private String eventName;
	
	@ValueMapValue
	private String target;
	
	@ValueMapValue
	private String accessibilityLabel;

	@ValueMapValue
	private String btnIcon;
	
	/**
	 * @return the ctaType
	 */
	public String getCtaType() {
		return ctaType;
	}

	/**
	 * @return the text
	 */
	public String getText() {
		return text;
	}

	/**
	 * @return the getLink
	 */
	public String getLink() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(),link);
	}


	/**
	 * @return the eventName
	 */
	public String getEventName() {
		return eventName;
	}

	/**
	 * @return the target
	 */
	public String getTarget() {
		return StringUtils.isNotBlank(target) && target.equalsIgnoreCase("true")?
			ApplicationConstants.TARGET_BLANK:ApplicationConstants.TARGET_SELF;
	}

	/**
	 * @return the accessibilityLabel
	 */
	public String getAccessibilityLabel() {
		return accessibilityLabel;
	} 

	/**
	 * @return the btnIcon
	 */
	public String getBtnIcon() {
		return btnIcon;
	}

	/**
	 * @return true if the link contains csv download link
	 */
	public Boolean getIsCsvDownload() {
		return getLink().contains("/csv/fcclabel.csv");
	}
}
