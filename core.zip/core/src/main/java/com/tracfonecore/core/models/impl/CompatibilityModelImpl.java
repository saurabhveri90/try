/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.CompatibilityModel;
import com.tracfonecore.core.utils.ItemsExporterUtil;
import com.tracfonecore.core.beans.CompatibilityCardBean;
import com.tracfonecore.core.beans.CompatibilityButtonBean;



@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CompatibilityModel.class,
		ComponentExporter.class }, resourceType = {"tracfone-core/components/commerce/compatibilityflow/v2/compatibility","tracfone-core/components/commerce/compatibilityflow/v1/compatibility"}, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CompatibilityModelImpl implements CompatibilityModel {

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private Resource resource;
	@Inject
	private SlingModelFilter slingModelFilter;

	@Inject
	private ModelFactory modelFactory;
	@ScriptVariable
	private ValueMap properties;

	@ValueMapValue
	private String compatibilitymaintitle;

	@ValueMapValue
	private String compatibilityimageAndVideo;

	@ValueMapValue
	private String compatibilitytitle;

	@ValueMapValue
	private String compatibilitycontent;

	private List<CompatibilityCardBean> compatibilitycardsList = Collections.emptyList();

	@ValueMapValue
	private String simnotcompatibilitymaintitle;

	
	@ValueMapValue
	private String simnotcompatibilityimageAndVideo;

	@ValueMapValue
	private String simnotcompatibilitytitle;

	@ValueMapValue
	private String simnotcompatibilitycontent;

	private List<CompatibilityButtonBean> simnotcompatibilitybuttonsList = Collections.emptyList();

	@ValueMapValue
	private String devicenotcompatibilitymaintitle;

	
	@ValueMapValue
	private String devicenotcompatibilityimageAndVideo;

	@ValueMapValue
	private String devicenotcompatibilitytitle;

	@ValueMapValue
	private String devicenotcompatibilitycontent;

	private List<CompatibilityButtonBean> devicenotcompatibilitybuttonsList = Collections.emptyList();

	
	@ValueMapValue
	private String activemaintitle;

	@ValueMapValue
	private String activeimageAndVideo;

	@ValueMapValue
	private String activetitle;

	@ValueMapValue
	private String activecontent;

    private List<CompatibilityButtonBean> activebuttonsList = Collections.emptyList();


	private static final Logger LOGGER = LoggerFactory.getLogger(CompatibilityModelImpl.class);

	@PostConstruct
	private void initModel() {
		try {
			compatibilitycardsList = new ArrayList<CompatibilityCardBean>();
			devicenotcompatibilitybuttonsList = new ArrayList<CompatibilityButtonBean>();
			simnotcompatibilitybuttonsList = new ArrayList<CompatibilityButtonBean>();
			activebuttonsList = new ArrayList<CompatibilityButtonBean>();
			Node currentNode = resource.adaptTo(Node.class);

		    if (currentNode != null && currentNode.hasNode(ApplicationConstants.COMPATIBILITYCARDS)) {

				Node child = currentNode.getNode(ApplicationConstants.COMPATIBILITYCARDS);

				// get the grandchild node of the currentNode - which represents where the
				// Column control values are stored
				NodeIterator ni = child.getNodes();
				while (ni.hasNext()) {
					CompatibilityCardBean compatibilityCardBean = new CompatibilityCardBean();
					Node grandChild = (Node) ni.nextNode();
	
					if ((grandChild.hasProperty(ApplicationConstants.CARD_TITLE))) {
						compatibilityCardBean.setCardtitle(grandChild.getProperty(ApplicationConstants.CARD_TITLE).getString());
						compatibilityCardBean.setCardcontent(grandChild.getProperty(ApplicationConstants.CARDCONTENT).getString());
						compatibilityCardBean.setCardbuttonlabel(grandChild.getProperty(ApplicationConstants.CARDBUTTONLABEL).getString());
						compatibilityCardBean.setCardbuttonlink(grandChild.getProperty(ApplicationConstants.CARDBUTTONLINK).getString());
						compatibilityCardBean.setCardimage(grandChild.getProperty(ApplicationConstants.CARDIMAGE).getString());
						compatibilityCardBean.setCardevent(grandChild.getProperty(ApplicationConstants.CARDEVENT).getString());

					}
	
					compatibilitycardsList.add(compatibilityCardBean);
	
				}
			}

			if (currentNode != null && currentNode.hasNode(ApplicationConstants.SIMNOTCOMPATIBILITYBUTTONS)) {

				Node child = currentNode.getNode(ApplicationConstants.SIMNOTCOMPATIBILITYBUTTONS);

				// get the grandchild node of the currentNode - which represents where the
				// Column control values are stored
				NodeIterator ni = child.getNodes();
				while (ni.hasNext()) {
					CompatibilityButtonBean compatibilityButtonBean = new CompatibilityButtonBean();
					Node grandChild = (Node) ni.nextNode();
	
					if ((grandChild.hasProperty(ApplicationConstants.BUTTONLABEL))) {
						compatibilityButtonBean.setButtonlabel(grandChild.getProperty(ApplicationConstants.BUTTONLABEL).getString());
					}	
					if ((grandChild.hasProperty(ApplicationConstants.BUTTONLINK))) {
						compatibilityButtonBean.setButtonlink(grandChild.getProperty(ApplicationConstants.BUTTONLINK).getString());
					}	
					if ((grandChild.hasProperty(ApplicationConstants.CHECKEVENT))) {
						compatibilityButtonBean.setCheckevent(grandChild.getProperty(ApplicationConstants.CHECKEVENT).getString());
					}	
						
					
	
					simnotcompatibilitybuttonsList.add(compatibilityButtonBean);
	
				}

			}

			if (currentNode != null && currentNode.hasNode(ApplicationConstants.DEVICENOTCOMPATIBILITYBUTTONS)) {

				Node child = currentNode.getNode(ApplicationConstants.DEVICENOTCOMPATIBILITYBUTTONS);

				// get the grandchild node of the currentNode - which represents where the
				// Column control values are stored
				NodeIterator ni = child.getNodes();
				while (ni.hasNext()) {
					CompatibilityButtonBean compatibilityButtonBean = new CompatibilityButtonBean();
					Node grandChild = (Node) ni.nextNode();
	
					if ((grandChild.hasProperty(ApplicationConstants.BUTTONLABEL))) {
						compatibilityButtonBean.setButtonlabel(grandChild.getProperty(ApplicationConstants.BUTTONLABEL).getString());
					}	
					if ((grandChild.hasProperty(ApplicationConstants.BUTTONLINK))) {
						compatibilityButtonBean.setButtonlink(grandChild.getProperty(ApplicationConstants.BUTTONLINK).getString());
					}	
					if ((grandChild.hasProperty(ApplicationConstants.CHECKEVENT))) {
						compatibilityButtonBean.setCheckevent(grandChild.getProperty(ApplicationConstants.CHECKEVENT).getString());
					}	
						
					
	
					devicenotcompatibilitybuttonsList.add(compatibilityButtonBean);
	
				}

			}


			if (currentNode != null && currentNode.hasNode(ApplicationConstants.ACTIVEBUTTONS)) {

				Node child = currentNode.getNode(ApplicationConstants.ACTIVEBUTTONS);

				// get the grandchild node of the currentNode - which represents where the
				// Column control values are stored
				NodeIterator ni = child.getNodes();
				while (ni.hasNext()) {
					CompatibilityButtonBean compatibilityButtonBean = new CompatibilityButtonBean();
					Node grandChild = (Node) ni.nextNode();
	
					if ((grandChild.hasProperty(ApplicationConstants.BUTTONLABEL))) {
						compatibilityButtonBean.setButtonlabel(grandChild.getProperty(ApplicationConstants.BUTTONLABEL).getString());
					}	
					if ((grandChild.hasProperty(ApplicationConstants.BUTTONLINK))) {
						compatibilityButtonBean.setButtonlink(grandChild.getProperty(ApplicationConstants.BUTTONLINK).getString());
					}	
					if ((grandChild.hasProperty(ApplicationConstants.CHECKEVENT))) {
						compatibilityButtonBean.setCheckevent(grandChild.getProperty(ApplicationConstants.CHECKEVENT).getString());
					}	
						
					
	
					activebuttonsList.add(compatibilityButtonBean);
	
				}

			}
				
			

		} catch (RepositoryException re) {
			LOGGER.error("Repository Exception occurred while fetching column control details {}", re);
		}

		
	}


	@Override
	public String getCompatibilitymaintitle() {
		return compatibilitymaintitle;
	}
	
	@Override
	public String getCompatibilityimageAndVideo() {
		return compatibilityimageAndVideo;
	}
	@Override
	public String getCompatibilitytitle() {
		return compatibilitytitle;
	}
	@Override
	public String getCompatibilitycontent() {
		return compatibilitycontent;
	}
	@Override
	public List<CompatibilityCardBean> getCompatibilitycardsList() {
		return new ArrayList<>(compatibilitycardsList);
	}

	@Override
	public String getSimnotcompatibilitymaintitle() {
		return simnotcompatibilitymaintitle;
	}
	
	@Override
	public String getSimnotcompatibilityimageAndVideo() {
		return simnotcompatibilityimageAndVideo;
	}
	@Override
	public String getSimnotcompatibilitytitle() {
		return simnotcompatibilitytitle;
	}
	@Override
	public String getSimnotcompatibilitycontent() {
		return simnotcompatibilitycontent;
	}
	
    @Override
	public List<CompatibilityButtonBean> getSimnotcompatibilitybuttonsList() {
		return new ArrayList<>(simnotcompatibilitybuttonsList);
	}

	@Override
	public String getDevicenotcompatibilitymaintitle() {
		return devicenotcompatibilitymaintitle;
	}
	
	@Override
	public String getDevicenotcompatibilityimageAndVideo() {
		return devicenotcompatibilityimageAndVideo;
	}
	@Override
	public String getDevicenotcompatibilitytitle() {
		return devicenotcompatibilitytitle;
	}
	@Override
	public String getDevicenotcompatibilitycontent() {
		return devicenotcompatibilitycontent;
	}
	
    @Override
	public List<CompatibilityButtonBean> getDevicenotcompatibilitybuttonsList() {
		return new ArrayList<>(devicenotcompatibilitybuttonsList);
	}

	@Override
	public String getActivemaintitle() {
		return activemaintitle;
	}

	@Override
	public String getActiveimageAndVideo() {
		return activeimageAndVideo;
	}

	@Override
	public String getActivetitle() {
		return activetitle;
	}

	@Override
	public String getActivecontent() {
		return activecontent;
	}
	@Override
	public List<CompatibilityButtonBean> getActivebuttonsList() {
		return new ArrayList<>(activebuttonsList);
	}
	
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}	
	
}