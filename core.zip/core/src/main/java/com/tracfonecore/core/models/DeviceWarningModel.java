package com.tracfonecore.core.models;

import org.osgi.annotation.versioning.ProviderType;

import com.adobe.cq.export.json.ComponentExporter;

/**
 * 
 * @author HCL
 * Defines the {@code Device Warning} Sling Model used for the {@code /apps/tracfone-core/components/commerce/deviceWarning} component.
 *
 */

@ProviderType
public interface DeviceWarningModel extends ComponentExporter {
    
    /**
     * Get the headerText
     * @return String - headerText
     */
    public String getHeaderText();  
    
    /**
     * Get the summary
     * @return String - summary
     */
    public String getSummary();  
   
    /**
     * Get the showInput
     * @return String - showInput
     */
    
    public String getShowInput(); 
    
    /**
     * Get the inputFieldLabel
     * @return String - inputFieldLabel
     */
    
    public String getInputFieldLabel();   
    
    /**
     * Get the subtext
     * @return String - subtext
     */
    public String getSubtext(); 
    
    /**
     * Get the button Label
     * @return String - buttonLabel
     */
    public String getButtonLabel();  
    
}
