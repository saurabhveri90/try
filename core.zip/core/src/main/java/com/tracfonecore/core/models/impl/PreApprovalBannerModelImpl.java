package com.tracfonecore.core.models.impl;

import com.tracfonecore.core.models.PreApprovalBannerModel;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.annotation.PostConstruct;

@Model(adaptables = {Resource.class, SlingHttpServletRequest.class}, adapters = PreApprovalBannerModel.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class PreApprovalBannerModelImpl implements PreApprovalBannerModel{
    @Self
    private Resource resource;

    @Self
    private SlingHttpServletRequest request;


    @ValueMapValue
    private String bannerBackground;

    @ValueMapValue
    private String bannerFont;
    @ValueMapValue
    private String bannerHeader;

    @ValueMapValue
    private String bannerDescription;

    @ValueMapValue
    private String bannerCtaLabel;

    @ValueMapValue
    private String financingHeader;

    @ValueMapValue
    private String financingDescription;

    @ValueMapValue
    private String financingOptionsCtaLabel;

    @ValueMapValue
    private String financingOptionsPath;

    @Override
    public String getBannerBackground() {
        return bannerBackground;
    }

    @Override
    public String getBannerFont() {
        return bannerFont;
    }

    @Override
    public String getBannerHeader() {
        return bannerHeader;
    }

    @Override
    public String getBannerDescription() {
        return bannerDescription;
    }
    @Override
    public String getBannerCtaLabel() {
        return bannerCtaLabel;
    }

    @Override
    public String getFinancingHeader() {
        return financingHeader;
    }

    @Override
    public String getFinancingDescription() {
        return financingDescription;
    }

    @Override
    public String getFinancingOptionsCtaLabel() {
        return financingOptionsCtaLabel;
    }

    @Override
    public String getFinancingOptionsPath() {
        return financingOptionsPath;
    }

}
