
package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;

import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.models.NavigationItem;
import com.tracfonecore.core.models.NavigationQuickLinksModel;
import com.tracfonecore.core.utils.ApplicationUtil;
/**
 * @author vijaykumar.tripathi
 *
 */
public class NavigationItemImpl extends PageListItemImpl implements NavigationItem {

    protected List<NavigationItem> children = Collections.emptyList();
    protected int level;
    protected boolean active;   
    private ValueMap valueMap;

    public NavigationItemImpl(Page page, boolean active, SlingHttpServletRequest request, int level, List<NavigationItem> children) {
        super(request, page);
        this.active = active;
        this.level = level;
        this.children = children;
        this.valueMap =  page.getContentResource() != null ? page.getContentResource().getValueMap() : null;    
    }

    @Override
    public boolean isActive() {
        return active;
    }

    @Override
    public List<NavigationItem> getChildren() {
        return children;
    }

    @Override
    public int getLevel() {
        return level;
    }

	@Override
	public String getHighlightLink() {
		return this.valueMap != null ? this.valueMap.get("highlightLinkNavFlyout", String.class) : "";
	}

	@Override
	public String getQuickLinksHeading() {
		return this.valueMap != null ? this.valueMap.get("quickLinksHeading", String.class) : "";
	}

	/**
	 * @return the quickLinks
	 */
	@Override
	public List<NavigationQuickLinksModel> getQuickLinks() {
		List<NavigationQuickLinksModel> quickLinks = new ArrayList<NavigationQuickLinksModel>();
		Resource quickLinkRes = Optional.ofNullable(page).map(Page::getContentResource).filter(Objects::nonNull)
			.map(res -> res.getChild("quickLinks")).orElse(null);
		if(quickLinkRes != null) {
			quickLinkRes.getChildren().forEach(res -> {
				quickLinks.add(res.adaptTo(NavigationQuickLinksModel.class));
    		});
			}
		return quickLinks;
	}

	@Override
	public String getFlyoutType() {
		return this.valueMap != null ? this.valueMap.get("navigationFlyoutType", String.class) : "";
	}

	/**
	 * @return the flyoutHeader
	 */
	@Override
	public String getFlyoutHeader() {
		return this.valueMap != null ? this.valueMap.get("flyoutHeader", String.class) : "";
	}

	
	/**
	 * @return the flyoutHeaderLink
	 */
	@Override
	public String getFlyoutHeaderLink() {		
		return this.valueMap != null ? ApplicationUtil.getShortUrl(request.getResourceResolver(), this.valueMap.get("flyoutHeaderLink", String.class)) : "";
	}

	/**
	 * @return the flyoutButtonLabel
	 */
	@Override
	public String getFlyoutButtonLabel() {
		return this.valueMap != null ? this.valueMap.get("flyoutButtonLabel", String.class) : "";
	}
	/**
	 * @return the flyoutAriaLabel
	 */
	@Override
	public String getFlyoutAriaLabel() {
		return this.valueMap != null ? this.valueMap.get("flyoutAriaLabel", String.class) : "";
	}

	/**
	 * @return the flyoutButtonLink
	 */
	@Override
	public String getFlyoutButtonLink() {
		return this.valueMap != null ? ApplicationUtil.getShortUrl(request.getResourceResolver(), this.valueMap.get("flyoutButtonLink", String.class)) : "";
	}
	
	/**
	 * @return the smallWidthNavDropdown
	 */
	@Override
	public String getSmallWidthNavDropdown() {
		return this.valueMap != null ? this.valueMap.get("smallWidthNavDropdown", String.class) : "";
	}

	/**
	 * @return the needAuthentication
	 */
	@Override
	public String getNeedAuthentication() {
		return this.valueMap != null ? this.valueMap.get("needAuthentication", String.class) : "";
	}

	@Override
    public String getShowFlyoutHeaderAsNavitem() {
        return this.valueMap != null ? this.valueMap.get("showFlyoutHeaderAsNavitem", String.class) : "false";
    }
}
