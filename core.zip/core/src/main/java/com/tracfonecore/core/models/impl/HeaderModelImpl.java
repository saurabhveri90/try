/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.SlingModelFilter;
import com.day.cq.wcm.api.NameConstants;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.beans.LinkBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ItemsExporterUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.HeaderModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.SearchConfigService;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import com.tracfonecore.core.services.DynamicMediaConfigService;


@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { HeaderModel.class,ComponentExporter.class },
        resourceType = { "tracfone-core/components/structure/header/v1/header",
                "tracfone-core/components/structure/header/v2/header" }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class HeaderModelImpl extends BaseComponentModelImpl implements HeaderModel {

    @ScriptVariable
    private ValueMap properties;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String fileReference;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String fileReferenceDeskSm;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String fileReferenceMobile;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String logoAltTextDesktop;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String logoAltTextMobile;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String logoTargetURL;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String doNotFollow;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String cartIconUrl;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String logoRedirectionMessage;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String logoNewWindow;
    @ValueMapValue @Default(values="Skip To Main Content")
    private String skipToMainContent;

    @Inject
    private SlingModelFilter slingModelFilter;
    @Inject
    private ModelFactory modelFactory;

    @Inject
    private SearchConfigService searchConfigService;

    @Inject
    private ApplicationConfigService applicationConfigService;

    @Inject
    private DynamicMediaConfigService dynamicMediaConfig;

    @SlingObject
    private ResourceResolver resourceResolver;

    @Inject
    private Page currentPage;

    @Inject
    @Via("resource")
    private String durationInDays;

    @Inject
    @Via("resource")
    private String countOfTopKeywords;

    @Inject
    @Via("resource")
    private String typeaheadMaxCount;

    @Inject
    @Via("resource")
    private String searchIconUrl;

    @Inject
    private Resource resource;

    @ValueMapValue
    private String mediaPath;

    @ValueMapValue
    private String mobileVersion;

    @ValueMapValue
    private String mediaType;

    @ValueMapValue
    private String theme;

    @ValueMapValue
    private String showBackgroundImage;

    @ValueMapValue
    private String videoThumbnailImage;

    @ValueMapValue
    private String videoThMobileVersion;

    private List<LinkBean> multilinks = Collections.emptyList();

    private List<LinkBean> userIconlinks = Collections.emptyList();

    private static final Logger LOGGER = LoggerFactory.getLogger(HeaderModelImpl.class);

    // constants
    private static final String MULTI_LINKS = "multilinks";
    private static final String LINK_URL = "linkurl";

    private static final String LINK_URL_TARGET = "newWindow";
    private static final String LINK_TEXT = "linktext";
    private static final String LINK_ALT_TEXT = "linkalttext";
    private static final String DO_NOT_FOLLOW_LINK = "doNotFollowLink";

    private static final String USER_ICON_LINKS = "userIconlinks";
    private static final String LINK_NAME = "linkName";
    private static final String ICON_NAME = "iconName";
    private static final String PAGE_PATH = "pagePath";


    @Self
    private SlingHttpServletRequest request;


    @Override
    public String getFileReference() {
        return DynamicMediaUtils.changeMediaPathToDMPathWithQueryParam(fileReference, resource.getResourceResolver());
    }

    @Override
    public String getFileReferenceDeskSm() {
        return DynamicMediaUtils.changeMediaPathToDMPathWithQueryParam(fileReferenceDeskSm, resource.getResourceResolver());
    }

    @Override
    public String getFileReferenceMobile() {
        return DynamicMediaUtils.changeMediaPathToDMPathWithQueryParam(fileReferenceMobile, resource.getResourceResolver());
    }

    @Override
    public String getLogoAltTextDesktop() {
        return logoAltTextDesktop;
    }

    @Override
    public String getLogoAltTextMobile() {
        return logoAltTextMobile;
    }

    /**
     * <p>Fetches Trim Header Text/p>
     *
     * @return String -  trimHeaderText value
     */
    public String getTrimHeaderText(){
        String trimHeaderText = null;
        if(currentPage != null){
            trimHeaderText = currentPage.getProperties().get("trimHeaderText",String.class);
        }
        return trimHeaderText;
    }

    /**
     * <p>Fetches Trim Header Bar/p>
     *
     * @return String -  isBarOnHeader value
     */
    public String getTrimHeaderBar(){
        String barOnHeader = null;
        if(currentPage != null){
            barOnHeader = currentPage.getProperties().get("isBarOnHeader",String.class);
        }
        return barOnHeader;
    }

    /**
     * <p>Fetches redirection message for logo link/p>
     *
     * @return String -  logoRedirectionMessage value
     */
    @Override
    public String getLogoRedirectionMessage() {
        return logoRedirectionMessage;
    }
    /**
     * <p>Fetches target of the logo link</p>
     *
     * @return String - target of the logo link
     */
    @Override
    public String getLogoNewWindow() {
        return logoNewWindow;
    }

    @Override
    public String getLogoTargetURL() {
        String finalLogoTargetURL = logoTargetURL;
        if (ApplicationUtil.isInternalLink(logoTargetURL)) {
            finalLogoTargetURL = ApplicationUtil.getShortUrl(request.getResourceResolver(), logoTargetURL);
        }
        return finalLogoTargetURL;
    }

    @PostConstruct
    protected void initModel() {
        try {
            super.initModel();
            multilinks = new ArrayList<LinkBean>();
            userIconlinks = new ArrayList<LinkBean>();
            doNotFollow = ApplicationUtil.getNoFollow(doNotFollow);

            Node currentNode = resource.adaptTo(Node.class);
            if (currentNode != null && currentNode.hasNode(MULTI_LINKS)) {
                Node child = currentNode.getNode(MULTI_LINKS);

                // get the grandchild node of the currentNode - which represents where the
                // MultiLinks values are stored
                NodeIterator ni = child.getNodes();
                setMultiFieldItems(ni, multilinks);
            }
            if (currentNode != null && currentNode.hasNode(USER_ICON_LINKS)) {
                Node child = currentNode.getNode(USER_ICON_LINKS);

                // get the grandchild node of the currentNode - which represents where the
                // MultiLinks values are stored
                NodeIterator ni = child.getNodes();
                setUserIconLinks(ni, userIconlinks);
            }
        } catch (RepositoryException re) {
            LOGGER.error("Repository Exception occurred while fetching multi link details {}", re);
        }
    }

    /**
     * <p>Populates a list with all the multi-links</p>
     *
     * @param ni             - iterator of the parent node
     * @param multiFieldData - list in which the multi links data needs to be set
     */

    private void setMultiFieldItems(NodeIterator ni, List<LinkBean> multiFieldData) {
        try {
            while (ni.hasNext()) {
                LinkBean linkBean = new LinkBean();
                Node grandChild = (Node) ni.nextNode();

                if ((grandChild.hasProperty(LINK_TEXT))) {
                    linkBean.setLinkText(grandChild.getProperty(LINK_TEXT).getString());
                }
                if ((grandChild.hasProperty(LINK_ALT_TEXT))) {
                    linkBean.setLinkAltText(grandChild.getProperty(LINK_ALT_TEXT).getString());
                }
                setLinkURL(grandChild, linkBean);
                setTargetValue(grandChild, linkBean);
                setDoNoFollowValue(grandChild, linkBean);
                multiFieldData.add(linkBean);
            }

        } catch (RepositoryException re) {
            LOGGER.error("Repository Exception occurred while fetching multi link details {}", re);
        }
    }

    private void setUserIconLinks(NodeIterator ni, List<LinkBean> userIconlinks) {
        try {
            while (ni.hasNext()) {
                LinkBean linkBean = new LinkBean();
                Node grandChild = (Node) ni.nextNode();

                if ((grandChild.hasProperty(LINK_NAME))) {
                    linkBean.setLinkName(grandChild.getProperty(LINK_NAME).getString());
                }
                if ((grandChild.hasProperty(ICON_NAME))) {
                    linkBean.setIconName(grandChild.getProperty(ICON_NAME).getString());
                }
                setPagePath(grandChild, linkBean);
                userIconlinks.add(linkBean);
            }

        } catch (RepositoryException re) {
            LOGGER.error("Repository Exception occurred while fetching multi link details {}", re);
        }
    }


    private void setDoNoFollowValue(Node grandChild, LinkBean linkBean) throws PathNotFoundException, ValueFormatException, RepositoryException {
        if ((grandChild.hasProperty(DO_NOT_FOLLOW_LINK))) {
            Property doNotFollowLink = grandChild.getProperty(DO_NOT_FOLLOW_LINK);
            linkBean.setDoNotFollowLink(doNotFollowLink.getValue() != null ? ApplicationConstants.NO_FOLLOW : ApplicationConstants.FOLLOW);
        } else
            linkBean.setDoNotFollowLink(ApplicationConstants.FOLLOW);
    }

    private void setLinkURL(Node grandChild,LinkBean linkBean ) throws ValueFormatException, PathNotFoundException, RepositoryException
    {
        if ((grandChild.hasProperty(LINK_URL))) {
            String url = grandChild.getProperty(LINK_URL).getString();
            if (ApplicationUtil.isInternalLink(url)) {
                url = url + ApplicationConstants.HTML_EXTENSION;
            }
            linkBean.setLinkUrl(url);
        }
    }

    private void setPagePath(Node grandChild,LinkBean linkBean ) throws ValueFormatException, PathNotFoundException, RepositoryException
    {
        if ((grandChild.hasProperty(PAGE_PATH))) {
            String pagePath = grandChild.getProperty(PAGE_PATH).getString();
            if (StringUtils.isNotBlank(pagePath)) {
				pagePath = ApplicationUtil
						.getUrlWithoutDomain(ApplicationUtil.getShortUrl(request.getResourceResolver(), pagePath));
			}
            linkBean.setPagePath(pagePath);
        }
    }    

    private void setTargetValue(Node grandChild,LinkBean linkBean) throws PathNotFoundException, ValueFormatException, RepositoryException
    {
        if ((grandChild.hasProperty(LINK_URL_TARGET))) {
            Property newWindow = grandChild.getProperty(LINK_URL_TARGET);
            linkBean.setNewWindow(newWindow.getValue() == null ? ApplicationConstants.FALSE : newWindow.getValue().toString());
        }
    }

    @Override
    public List<LinkBean> getMultilinks() {
        return new ArrayList<>(multilinks);
    }
    @Override
    public String getDoNotFollow() {
        return doNotFollow;
    }

    @Override
    public String getCartIconUrl() {
        String finalCartIconUrl = cartIconUrl;
        if (ApplicationUtil.isInternalLink(cartIconUrl)) {
            finalCartIconUrl = cartIconUrl + ApplicationConstants.HTML_EXTENSION;
        }
        return finalCartIconUrl;
    }

    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }
    public Map<String, ? extends ComponentExporter> getItems(){
        return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
    }

    @Override
    public String getSearchAutoCompleteApiDomain() {
        return searchConfigService.searchAutoCompleteApiDomain();
    }

    @Override
    public String getSearchAutoCompleteApiPath() {
        String finalValue="";
        if(StringUtils.isNotBlank(searchConfigService.searchAutoCompleteApiPath())&& searchConfigService.searchAutoCompleteApiPath().indexOf("{engine_id}")!=-1) {
            finalValue = searchConfigService.searchAutoCompleteApiPath().replace("{engine_id}", getSearchAutoCompleteApiEngineId());
        }
        return finalValue;
    }

    @Override
    public String getSearchAutoCompleteApiEngineId() {
        return getValueByBrandAndLanguage(searchConfigService.searchAutoCompleteApiEngineId());
    }

    @Override
    public String getDurationInDays() {
        return durationInDays;
    }

    @Override
    public String getCountOfTopKeywords() {
        return countOfTopKeywords;
    }

    @Override
    public String getTypeaheadMaxCount() {
        return typeaheadMaxCount;
    }

    private String getValueByBrandAndLanguage(String[] valueArray) {
        String retValue="";
        Map<String, String> retMap = new HashMap<>();
        String brandName = CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel());
        String language = CommerceUtil.getLanguage(currentPage, applicationConfigService.getHomePageLevel());
        if (StringUtils.isNotBlank(brandName) && valueArray != null) {
            for (String configValue : valueArray) {
                if (StringUtils.isNotBlank(configValue)&& configValue.indexOf(ApplicationConstants.COLON)!=-1) {
                    String[] valuesArray = configValue.split(ApplicationConstants.COLON);
                    if(null != valuesArray && valuesArray.length == 3 && StringUtils.isNotBlank(valuesArray[0])&& brandName.equals(valuesArray[0]) && StringUtils.isNotBlank(valuesArray[1])&&StringUtils.isNotBlank(valuesArray[2])) {
                        retMap.put(valuesArray[1].trim(), valuesArray[2].trim());
                        if(retMap!=null && StringUtils.isNotBlank(language)){
                            retValue = retMap.get(language);
                        }
                    }else if(null != valuesArray && valuesArray.length == 2 && StringUtils.isNotBlank(valuesArray[0])&& brandName.equals(valuesArray[0]) && StringUtils.isNotBlank(valuesArray[1])){
                        retValue = valuesArray[1].trim();
                    }
                }
            }

        }
        return retValue;
    }

    @Override
    public String getSearchIconUrl() {
        return ApplicationUtil.getShortUrl(request.getResourceResolver(), searchIconUrl);
    }

    @Override
    public String getSkipToMainContent() {
        return skipToMainContent;
    }
    /**
     * Fetches the brand name
     */
    @Override
    public String getBrandName() {
        String brandName = StringUtils.EMPTY;
        if(null!=currentPage){
            brandName = ApplicationUtil.getLowerCaseWithUnderScore(CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
        }
        return brandName;
    }
    /**
     * Get Page template Name
     */
    public String getTemplateName() {
        String templateName = StringUtils.EMPTY;
        if(null!=currentPage){
            templateName = currentPage.getProperties().get(NameConstants.NN_TEMPLATE,"");
        }
        return templateName;
    }

    /**
     * <p>
     * Fetches image path
     * </p>
     *
     * @return String - image path
     */
    @Override
    public String getMediaPath() {
        String s7Path = DynamicMediaUtils.changeMediaPathToDMPath(this.mediaPath, request.getResourceResolver());
        LOGGER.debug("Carousel Media Path: {}", s7Path);
        return s7Path;
    }

    /**
     * <p>
     * Fetches media type (video/image)
     * </p>
     *
     * @return String - media type
     */
    @Override
    public String getMediaType() {
        return mediaType;
    }

    @Override
    public String getTheme() {

        return theme;
    }

    @Override
    public String getShowBackgroundImage() {

        return showBackgroundImage;
    }

    /**
     * <p>
     * Fetches break points for the image
     * </p>
     *
     * @return String - imageProfileBreakpoints
     */
    @Override
    public String getImageProfileBreakpoints() {
        String path = this.mediaPath;
        String breakPoints = StringUtils.EMPTY;
        if (ApplicationConstants.VIDEO.equals(this.mediaType)) {
            path = this.videoThumbnailImage;
        }
        if (ApplicationConstants.BG_SMART_CROP.equals(this.getDataMode())) {
            breakPoints = DynamicMediaUtils.getImageProfileBreakpoints(path, request.getResourceResolver());
        }
        return breakPoints;
    }

    /**
     * <p>
     * Fetches data type for the video
     * </p>
     *
     * @return String - videoDataType
     */
    @Override
    public String getVideoDataType() {
        return ApplicationConstants.VIDEO_DATA_TYPE;
    }

    /**
     * <p>
     * Fetches the path for mobile thumbnail
     * </p>
     *
     * @return String - mobile thumbnail image path
     */
    @Override
    public String getMobileThumbnailImagePath() {
        String path = DynamicMediaUtils.getMobileDMPath(this.videoThumbnailImage, request.getResourceResolver());
        if (!ApplicationConstants.VIDEO.equals(this.mediaType)
                && !ApplicationConstants.MOBILE_IMAGE.equals(this.videoThMobileVersion)) {
            path = StringUtils.EMPTY;
        }
        return path;
    }

    /**
     * <p>
     * Fetches the path for mobile image path
     * </p>
     *
     * @return String - mobile image path
     */
    @Override
    public String getMobileMediaImagePath() {
        String path = DynamicMediaUtils.getMobileDMPath(this.mediaPath, request.getResourceResolver());
        if (!ApplicationConstants.IMAGE.equals(this.mediaType)
                && !ApplicationConstants.MOBILE_IMAGE.equals(this.mobileVersion)) {
            path = StringUtils.EMPTY;
        }
        return path;
    }

    /**
     * <p>
     * Fetches the data mode
     * </p>
     *
     * @return String - data mode
     */
    @Override
    public String getDataMode() {
        String mode = this.videoThMobileVersion;
        if (ApplicationConstants.IMAGE.equals(this.mediaType)) {
            mode = this.mobileVersion;
        }
        return mode;
    }

    @Override
    public List<LinkBean> getUserIconLinks() {
        return new ArrayList<>(userIconlinks);
    }

}
