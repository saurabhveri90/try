package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public interface ACPMigrationModel  extends ComponentExporter {

    @JsonProperty("general")
    public List<KeyValuePairModel> getGeneralList();

}
