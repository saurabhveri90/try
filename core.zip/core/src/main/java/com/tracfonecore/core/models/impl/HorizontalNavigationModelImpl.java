package com.tracfonecore.core.models.impl;

import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.HorizontalNavigationModel;


@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { HorizontalNavigationModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/horizontalnavigation", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class HorizontalNavigationModelImpl implements HorizontalNavigationModel {


	@Self
	private SlingHttpServletRequest request;



	/**
	 *  Inject the Links multifield
	 */
	 @Inject @Via("resource")
    private Resource links;

	/**
	 * @return the links
	 */
	public Resource getLinks() {
		return links;
	}

	/**
	 * @return getexportertype
	 */
	@Override
	public String getExportedType() {

		return request.getResource().getResourceType();
	}

}
