/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * Defines the {@code Multi-Links} Sling Model used for the {@code /apps/tracfone-core/components/spa/content/accountdashboard} component.
 */
public interface AccountDashboardModel extends ComponentExporter {

	@JsonProperty("accountProfileImagePath")
	public String getAccountProfileImagePath();

	@JsonProperty("accountProfileMobileImagePath")
	public String getAccountProfileMobileImagePath();

	@JsonProperty("accountProfileImageAltText")
	public String getAccountProfileImageAltText();
	
	@JsonProperty("refillNotifyMinDays")
	public String getRefillNotifyMinDays();
	
	@JsonProperty("ccExpiryNotifyMinMonth")
	public String getCcExpiryNotifyMinMonth();
	
	@JsonProperty("activationDateDifference")
	public String getActivationDateDifference();
	
	@JsonProperty("noOfRetryForServicePlanApi")
	public String getNoOfRetryForServicePlanApi();
	
	@JsonProperty("initialTimeIntervalForRetry")
	public String getInitialTimeIntervalForRetry();
	
	@JsonProperty("diffInTimeIntervalBy")
	public String getDiffInTimeIntervalBy();
	
	@JsonProperty("maxMinutes")
	public String getMaxMinutes();
	
	@JsonProperty("maxMessage")
	public String getMaxMessage();
	
	@JsonProperty("maxData")
	public String getMaxData();

	@JsonProperty("maxDataTMOCarrier")
	public String getMaxDataTMOCarrier();
	
	@JsonProperty("deviceTypeRegexForMyUsageTalk")
	public String getDeviceTypeRegexForMyUsageTalk();
	
	@JsonProperty("deviceTypeRegexForMyUsageText")
	public String getDeviceTypeRegexForMyUsageText();

	@JsonProperty("deviceTypeRegexToShowMyUsageTalkText")
	public String getDeviceTypeRegexToShowMyUsageTalkText();

	@JsonProperty("activationPagePath")
	public String getActivationPagePath();

	@JsonProperty("refillPLPPageSelector")
	public String getRefillPLPPageSelector();

	@JsonProperty("refillPLPPagePath")
	public String getRefillPLPPagePath();

	@JsonProperty("refillLandingPagePath")
	public String getRefillLandingPagePath();

	@JsonProperty("ildPlanPartNumber")
	public String getIldPlanPartNumber();

	@JsonProperty("ildPlanEditCartUrl")
	public String getIldPlanEditCartUrl();

	@JsonProperty("categoryIdPlans")
	public String getCategoryIdPlans();
		
	@JsonProperty("refillBuyNowPLPPageSelector")
	public String getRefillBuyNowPLPPageSelector();
	
	@JsonProperty("enableClosestStoreComponent")
	public Boolean getEnableClosestStoreComponent();

	@JsonProperty("disableEstimateCallForAccBal")
	public Boolean getDisableEstimateCallForAccBal();

	@JsonProperty("accBalanceAutoPayOnDueMsg")
	public String getAccBalanceAutoPayOnDueMsg();
	
	@JsonProperty("notificationCardHeading")
	public String getNotificationCardHeading();
	
	@JsonProperty("notificationCardSubheading")
	public String getNotificationCardSubheading();
	
	@JsonProperty("enableNotification")
	public String getEnableNotification();

	@JsonProperty("checkoutDetailComponentVersion")
	public String getCheckoutDetailComponentVersion();
	
	@JsonProperty("fetchMyUsagePlanDetail")
	public Boolean getFetchMyUsagePlanDetail();
	
	@JsonProperty("maxNumberOfClosestStores")
	public String getMaxNumberOfClosestStores();
	
	@JsonProperty("maxRadiusForClosestStores")
	public String getMaxRadiusForClosestStores();
	
	@JsonProperty("myBalanceServicePeriodNote")
	public String getMyBalanceServicePeriodNote();
	
	@JsonProperty("myBalanceExpirationDateNote")
	public String getMyBalanceExpirationDateNote();

	@JsonProperty("refillStartDateSelector")
	public String getRefillStartDateSelector();

	@JsonProperty("activationCardHeading")
	public String getActivationCardHeading();

	@JsonProperty("activationCardCardSubheading")
	public String getActivationCardCardSubheading();

	@JsonProperty("enableActivationNotification")
	public Boolean getEnableActivationNotification();

	@JsonProperty("restartYourPhoneText")
	public String getRestartYourPhoneText();

	@JsonProperty("videoStreamingText")
	public String getVideoStreamingText();

	@JsonProperty("purchaseSubheading")
	default String getPurchaseSubheading(){
		return null;
	}
	@JsonProperty("purchaseSubHeadingIconPath")
	default String getPurchaseSubHeadingIconPath(){
		return null;
	}
	@JsonProperty("purchaseHeading")
	default String getPurchaseHeading(){
		return null;
	}
	@JsonProperty("purchaseDescription")
	default String getPurchaseDescription(){
		return null;
	}
	@JsonProperty("purchaseCtaLabel")
	default String getPurchaseCtaLabel(){
		return null;
	}
	@JsonProperty("purchaseCtaLink")
	default String getPurchaseCtaLink(){
		return null;
	}
	@JsonProperty("purchaseLearnmoreLabel")
	default String getPurchaseLearnmoreLabel(){
		return null;
	}
	@JsonProperty("purchaseLearnmoreLink")
	default String getPurchaseLearnmoreLink(){
		return null;
	}

	@JsonProperty("partNumberToogle")
	public String getPartNumberToogle();

	@JsonProperty("walmartActivationPagePath")
    public String getWalmartActivationPagePath();
	
	@JsonProperty("walmartImagePath")
    public String getWalmartImagePath();
}
