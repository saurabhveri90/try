package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

public interface CusgModel extends ComponentExporter {

	/**
	 * <p>Fetches modal id for Cusg</p>
	 * 
	 * @return String - modal id
	 */
	@JsonProperty("modalId")
	public String getModalId();


  /**
	 * <p>Fetches Add Rte Component Check</p>
	 * 
	 * @return boolean - add rte component
	 */
	@JsonProperty("addRteComponent")
	public boolean getAddRteComponent();

  /**
	 * <p>Fetches websites for Cusg</p>
	 * 
	 * @return String - string of websites for cusg
	 */
	@JsonProperty("websites")
	public String getWebsites();

}
