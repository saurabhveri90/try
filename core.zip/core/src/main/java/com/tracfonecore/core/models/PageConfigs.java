/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import java.util.List;
import java.util.Map;

public interface PageConfigs {

	
	/**
	 * 
	 * <p>
	 * Fetches noIndex
	 * </p>
	 *
	 * @return the noIndex
	 */
	public String getNoIndex() ;

	/**
	 * <p>
	 * Fetches noFollow
	 * </p>
	 *
	 * @return the noFollow
	 */
	public String getNoFollow() ;

	/**
	 * <p>
	 * Fetches unavailableAfter
	 * </p>
	 *
	 * @return the unavailableAfter
	 */
	public String getUnavailableAfter() ;

	/**
	 * <p>
	 * Fetches canonicalURL
	 * </p>
	 *
	 * @return the canonicalURL
	 */
	public String getCanonicalURL() ;

	/**
	 * <p>
	 * Fetches robots
	 * </p>
	 *
	 * @return the robots
	 */
	public String getRobots() ;

	/**
	 * <p>
	 * Fetches ogTitle
	 * </p>
	 *
	 * @return the ogTitle
	 */
	public String getOgTitle();

	/**
	 * <p>
	 * Fetches ogDescription
	 * </p>
	 *
	 * @return the ogDescription
	 */
	public String getOgDescription();

	/**
	 * <p>
	 * Fetches ogImage
	 * </p>
	 *
	 * @return the ogImage
	 */
	public String getOgImage() ;

	/**
	 * <p>
	 * Fetches ogType
	 * </p>
	 *
	 * @return the ogType
	 */
	public String getOgType() ;

	/**
	 * <p>
	 * Fetches twitterCard
	 * </p>
	 *
	 * @return the twitterCard
	 */
	public String getTwitterCard() ;

	/**
	 * <p>
	 * Fetches twitterTitle
	 * </p>
	 *
	 * @return the twitterTitle
	 */
	public String getTwitterTitle();

	/**
	 * <p>
	 * Fetches twitterDescription
	 * </p>
	 *
	 * @return the twitterDescription
	 */
	public String getTwitterDescription() ;

	/**
	 * <p>
	 * Fetches twitterImage
	 * </p>
	 *
	 * @return the twitterImage
	 */
	public String getTwitterImage() ;

	/**
	 * <p>
	 * Fetches ogLocale
	 * </p>
	 *
	 * @return the ogLocale
	 */
	public String getOgLocale();

	/**
	 * <p>
	 * Fetches ogURL
	 * </p>
	 *
	 * @return the ogURL
	 */
	public String getOgURL() ;
	/**
	 * <p>
	 * Sets ogURL
	 * </p>
	 *
	 * @param ogURL - the ogURL to set
	 */
	public void setOgURL(String ogURL) ;

	/**
	 * <p>
	 * Fetches twitterURL
	 * </p>
	 *
	 * @return the twitterURL
	 */
	public String getTwitterURL() ;

	/**
	 * @return the hrefLangList
	 */
	public List<String> getHrefLangList() ;

	/**
	 * @return the title
	 */
	public String getTitle() ;
	
	/**
	 * @return the seoTitle
	 */
	public String getSeoTitle() ;

	/**
	 * @return the description
	 */
	public String getDescription() ;

	
	public Map<String,String> getMap() ;

	/**
	 * @return the ogSiteName
	 */
	public String getOgSiteName();

	
	/**
	 * @return the twitterSite
	 */
	public String getTwitterSite() ;
	

	/**
	 * @return the fbAppId
	 */
	public String getFbAppId() ;

	

	/**
	 * @return the ogAlternateLocale
	 */
	public String getOgAlternateLocale() ;

	/**
	 * @return the getSPAHierarchyRootJsonExportUrl
	 */
	public String getSPAHierarchyRootJsonExportUrl();

	/**
	 * @return the isLocatorPage
	 */
	public String getIsLocatorPage();

	

}
