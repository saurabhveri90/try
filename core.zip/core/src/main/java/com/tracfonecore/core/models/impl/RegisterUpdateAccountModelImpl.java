/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;


import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.RegisterUpdateAccountModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { RegisterUpdateAccountModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/registerupdateaccount", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class RegisterUpdateAccountModelImpl implements RegisterUpdateAccountModel {

	@Self
	private SlingHttpServletRequest request;
	
	@ValueMapValue
	private String headlineCreateAccount;

	@ValueMapValue
	private String summary;

	@ValueMapValue
	private String accessibilityText;
	
	@ValueMapValue
	private String ageConsent;
	
	@ValueMapValue
	private String whyNeedThisLinkText;
	
	@ValueMapValue
	private String whyNeedThisLinkModalContent;

	@ValueMapValue
	private String whyDoINeedThisModal;
	
	@ValueMapValue
	private String learnMoreLinkText;
	
	@ValueMapValue
	private String learnMoreLinkModalContent;
	
	@ValueMapValue
	private String headlineLogin;

	@ValueMapValue
	private String loginLearnMoreLinkText;
	
	@ValueMapValue
	private String loginLearnMoreLinkModalContent;
	
	@ValueMapValue
	private String enableFacebookAuth;
	
	@ValueMapValue
	private String whyNeedThisLinkAccessibilityText;
	
	@ValueMapValue
	private String learnMoreLinkAccessibilityText;

	@ValueMapValue
	private String enableChat;
	
	@ValueMapValue
	private String enabletooltip;
	
	@ValueMapValue
	private String chatIconLink;
	
	@ValueMapValue
	private String chatButtonText;

	@ValueMapValue
	private String chatButtonLink;
	
	@ValueMapValue
	private String enableConfirmPassword;
	
	private String myAccountPagePath;
	
	@Inject
	private Page currentPage;
	
	@Inject
	private Resource resource;
	
	@Inject
	private ApplicationConfigService applicationConfigService;

	@ValueMapValue
	private String twoFAInfoLink;

	private String brand;
	
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>Fetches headlineCreateAccount for the registerupdateaccount</p>
	 * 
	 * @return String - headlineCreateAccount for the registerupdateaccount
	 */
	@Override
	public String getHeadlineCreateAccount(){
		return headlineCreateAccount;
	}

	@Override
	public String getWhyDoINeedThisModal(){
		return ApplicationUtil.getLowerCaseWithHyphen(whyDoINeedThisModal) + ApplicationConstants.HYPHEN
		+ ApplicationConstants.MODAL;
	}

	/**
	 * <p>Fetches summary</p>
	 * 
	 * @return String - summary
	 */
	@Override
	public String getSummary() {
		return summary;
	}

	/**
	 * <p>Fetches accessibilityText</p>
	 * 
	 * @return String - accessibilityText
	 */
	@Override
	public String getAccessibilityText() {
		return accessibilityText;
	}
	
	/**
	 * <p>Fetches ageConsent for the registerupdateaccount</p>
	 * 
	 * @return String - ageConsent for the registerupdateaccount
	 */
	@Override
	public String getAgeConsent(){
		return ageConsent;
	}
	
	/**
	 * <p>Fetches whyNeedThisLinkText for the registerupdateaccount</p>
	 * 
	 * @return String - whyNeedThisLinkText for the registerupdateaccount
	 */
	@Override
	public String getWhyNeedThisLinkText(){
		return whyNeedThisLinkText;
	}
	
	/**
	 * <p>Fetches whyNeedThisLinkAccessibilityText for the registerupdateaccount</p>
	 * 
	 * @return String - whyNeedThisLinkAccessibilityText for the registerupdateaccount
	 */
	@Override
	public String getWhyNeedThisLinkAccessibilityText(){
		return whyNeedThisLinkAccessibilityText;
	}
	
	/**
	 * <p>Fetches whyNeedThisLinkModalContent for the registerupdateaccount</p>
	 * 
	 * @return String - whyNeedThisLinkModalContent for the registerupdateaccount
	 */
	@Override
	public String getWhyNeedThisLinkModalContent(){
		return whyNeedThisLinkModalContent;
	}
	
	/**
	 * <p>Fetches learnMoreLinkText for the registerupdateaccount</p>
	 * 
	 * @return String - learnMoreLinkText for the registerupdateaccount
	 */
	@Override
	public String getLearnMoreLinkText(){
		return learnMoreLinkText;
	}
	
	/**
	 * <p>Fetches learnMoreLinkAccessibilityText for the registerupdateaccount</p>
	 * 
	 * @return String - learnMoreLinkAccessibilityText for the registerupdateaccount
	 */
	@Override
	public String getLearnMoreLinkAccessibilityText(){
		return learnMoreLinkAccessibilityText;
	}
	
	/**
	 * <p>Fetches learnMoreLinkModalContent for the registerupdateaccount</p>
	 * 
	 * @return String - learnMoreLinkModalContent for the registerupdateaccount
	 */
	@Override
	public String getLearnMoreLinkModalContent(){
		return learnMoreLinkModalContent;
	}
	
	/**
	 * <p>Fetches enable Facebook Auth for the registerupdateaccount</p>
	 * 
	 * @return String - enableFacebookAuth for the registerupdateaccount
	 */
	@Override
	public String getEnableFacebookAuth() {
		return enableFacebookAuth;
	}
	/**
	 * <p>Fetches My Account Path</p>
	 * 
	 * @return String - My account Page Path
	 */
	@Override
	public String getMyAccountPagePath() {
		 myAccountPagePath = ApplicationUtil.getShortUrl(resource.getResourceResolver(),
				CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(), ApplicationConstants.MY_ACCOUNT_PATH_LOGIN_REDIRECTION).toString());
		return myAccountPagePath;        
	}
	
	/**
	 * <p>
	 * Fetches home page level property from config
	 * </p>
	 * 
	 * @return int - homePageLevel
	 */
	@Override
	public int getHomePageLevel() {

		return applicationConfigService.getHomePageLevel();
	}


	/**
	 * <p>Fetches enableChat</p>
	 * 
	 * @return String - enableChat
	 */
	@Override
	public String getEnableChat() {
		return enableChat;
	}

	/**
	 * <p>Fetches enabletooltip</p>
	 * 
	 * @return String - enabletooltip
	 */
	@Override
	public String getEnabletooltip() {
		return enabletooltip;
	}

	/**
	 * <p>Fetches chatIconLink</p>
	 * @return the chatIconLink
	 */
	@Override
	public String getChatIconLink() {
		return chatIconLink;
	}

	/**
	 * <p>Fetches chatButtonText</p>
	 * @return the chatButtonText
	 */
	@Override
	public String getChatButtonText() {
		return chatButtonText;
	}

	/**
	 * <p>Fetches chatButtonLink</p>
	 * @return the chatButtonLink
	 */
	@Override
	public String getChatButtonLink() {
		return chatButtonLink;
	}

	/**
	 * <p>Fetches enableConfirmPassword</p>
	 * @return the enableConfirmPassword
	 */
	@Override
	public String getEnableConfirmPassword() {
		return enableConfirmPassword;
	}

	/**
	 * @return String - twoFAInfoLink
	 */
	@Override
	public String getTwoFAInfoLink() {
		return twoFAInfoLink;
	}

	/**
	 * @return String - brand
	 */
	@Override
	public String getBrand() {
		return CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel());
	}
}
