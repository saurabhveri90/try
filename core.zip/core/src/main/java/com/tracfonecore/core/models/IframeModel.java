package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author rajeshkumar_jha
 *
 */
public interface IframeModel extends ComponentExporter {

	/**
	 * <p>Fetches title</p>
	 * 
	 * @return String - title
	 */
	@JsonProperty("title")
	public String getTitle();

	/**
	 * <p>Fetches modal name</p>
	 * 
	 * @return String - modalName
	 */
	@JsonProperty("modalName")
	public String getModalName();

	/**
	 *<p>Fetches accessibilityLabel</p>
	 *
	 * @return the accessibilityLabel
	 */
	public String getAccessibilityLabel();

	/**
	 *<p>Fetches placementText</p>
	 *
	 * @return the gtm placement text
	 */
	@JsonProperty("placementText")
	public String getPlacementText();

	/**
	 *<p>Fetches modalId</p>
	 *
	 * @return the modalId
	 */
	public String getModalId();	
	
}
