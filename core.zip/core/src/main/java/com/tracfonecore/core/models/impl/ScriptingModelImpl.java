/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.settings.SlingSettingsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.DamConstants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.Page;
import com.google.gson.JsonObject;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.ScriptingModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = {
		ScriptingModel.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

public class ScriptingModelImpl implements ScriptingModel {
	private static final Logger LOGGER = LoggerFactory.getLogger(ScriptingModelImpl.class);
	@Inject
	private String keyList;
	@Inject
	private Page currentPage;
	@Inject
	private SlingSettingsService settingService;
	@Inject
	private QueryBuilder builder;
	@Inject
	private ApplicationConfigService applicationConfigService;
	@Self
	private SlingHttpServletRequest request;
	private ResourceResolver resolver;

	@PostConstruct
	private void initModel() {
		resolver = request.getResourceResolver();
	}

	@Override
	public Map<String, String> getScriptingMap() {
		Map<String, String> scriptingMap = new HashMap<>();
		if (StringUtils.isNotEmpty(keyList)) {
			String basePath = getCFBasePath(applicationConfigService.getScriptingContentBasePath());
			basePath = basePath.replace("{language}", getLanguage());
			String[] keyListArray = keyList.split(",");
			Map<String, String> map = new HashMap<String, String>();
            map.put("type", DamConstants.NT_DAM_ASSET);
            map.put("path", basePath);
            map.put("p.limit", "-1");
            map.put("property", "jcr:content/data/master/scriptKey");
			for (int i = 0; i < keyListArray.length; i++) {
				map.put("property."+String.valueOf(i+1)+"_value", keyListArray[i]);
			}
			Query query = builder.createQuery(PredicateGroup.create(map),
					request.getResourceResolver().adaptTo(Session.class));
			SearchResult result = query.getResult();
			
			// OOTB QueryBuilder has a leaking ResourceResolver, so the following work
			// around is required.
			ResourceResolver leakingResourceResolver = null;
			try {
				if(result != null) {
				for (Hit hit : result.getHits()) {
					try {
						if (leakingResourceResolver == null) {
							// Get a reference to QueryBuilder's leaking ResourceResolver
							leakingResourceResolver = hit.getResource().getResourceResolver();
						}
						Resource hitResource = hit.getResource();
						String key = hitResource.getChild("jcr:content/data/master").getValueMap().get("scriptKey", "");
						scriptingMap.put(key, getValueFromPath(key, hitResource.getPath()));
					} catch (RepositoryException e) {
						LOGGER.error("Exception occured while creating scripting map from ScriptingModelImpl", e);
					}
				}
			  }
			} finally {
				if (leakingResourceResolver != null) {
					// Always Close the leaking QueryBuilder resourceResolver.
					leakingResourceResolver.close();
				}
			}
		}
		return scriptingMap;

	}

	@Override
	public String getValueFromKey(String key) {
		String basePath = getCFBasePath(applicationConfigService.getScriptingContentBasePath());
		String value;
		basePath = basePath.replace("{language}", getLanguage());
		String keyPath = basePath + "/" + key.toLowerCase();
		value = getValueFromPath(key, keyPath);
		if(StringUtils.isEmpty(value)){
			value = key;
		}
		return value;
	}
	/**
	 * This method to get the scripting value from specific folder path.
	 * @path String: scripting key
	 * @param String : folder name
	 * 
	 * @return String: scripting value
	 */
	@Override
	public String getValueFromKeyInNode(String key,String node) {
		String basePath = getCFBasePath(applicationConfigService.getScriptingContentBasePath())+ApplicationConstants.SLASH+node;
		String value;
		basePath = basePath.replace("{language}", getLanguage());
		String keyPath = basePath + "/" + key.toLowerCase();
		value = getValueFromPath(key, keyPath);
		if(StringUtils.isEmpty(value)){
			value = key;
		}
		return value;
	}

	private String getValueFromPath(String key, String keyPath) {
		String value = key;
		if (resolver.getResource(keyPath) != null) {
			Resource keyResource = resolver.getResource(keyPath + "/jcr:content/data/master");
			if (keyResource != null) {
				ValueMap vm = keyResource.getValueMap();
				if (StringUtils.isNotEmpty(vm.get("scriptKey", String.class))
						&& StringUtils.isNotEmpty(vm.get("scriptValue", String.class))
						&& (vm.get("scriptKey", "").toLowerCase()).equals(key.toLowerCase())) {
					value = vm.get("scriptValue", String.class);

				}
			}
		}else if(!key.equals(getDefaultErrorCF())){
			Set runModes = settingService.getRunModes();
			if(runModes!=null && runModes.contains("prod")) {
				value = getValueFromKey(getDefaultErrorCF());
			}
		}
		return value;
	}
	
	private String getKeyFromPath(String keyPath) {
		if (resolver.getResource(keyPath) != null) {
			Resource keyResource = resolver.getResource(keyPath + "/jcr:content/data/master");
			if (keyResource != null) {
				ValueMap vm = keyResource.getValueMap();
				if (StringUtils.isNotEmpty(vm.get("scriptKey", String.class))) {
					return vm.get("scriptKey", String.class);

				}
			}
		}
		return "";
	}

	@Override
	public String getErrorScriptingJson() {
		String basePath = getCFBasePath(applicationConfigService.getScriptingContentBasePath());
		basePath = basePath.replace("{language}", getLanguage());
		String json = "";
		try {
			json = getScriptingJson(basePath, "_err_");
		} catch (RepositoryException e) {
			LOGGER.error("Repository Exception: ", e);
		}
		return json;

	}
	
	@Override
	public String getMigratedGroupScriptingJson() {
		String basePath = getCFBasePath(applicationConfigService.getScriptingContentBasePath());
		basePath = basePath.replace("{language}", getLanguage());
		String json = "";
		try {
			json = getScriptingJson(basePath, "_mgr_");
		} catch (RepositoryException e) {
			LOGGER.error("Repository Exception: ", e);
		}
		return json;

	}

	private String getScriptingJson(String basePath, String selector) throws RepositoryException {
		Map<String, String> map = new HashMap<String, String>();
		map.put("path", basePath);
		map.put("type", DamConstants.NT_DAM_ASSET);
		map.put("nodename", selector+"*");
		map.put("p.limit", "-1");
		Query query = builder.createQuery(PredicateGroup.create(map),
				request.getResourceResolver().adaptTo(Session.class));
		SearchResult result = query.getResult();
		JsonObject scriptingJson = new JsonObject();
		for (Hit hit : result.getHits()) {
			Resource hitResource = hit.getResource();
			String scriptKey = getKeyFromPath(hitResource.getPath());
			scriptingJson.addProperty(scriptKey, getValueFromPath(scriptKey, hitResource.getPath()));                          
		}
		return scriptingJson.toString();
	}

	private String getLanguage() {
		return CommerceUtil.getLanguage(currentPage, applicationConfigService.getHomePageLevel());
	}
	
	/**
	 * @return ProductSpecImagPath
	 */
	private String getDefaultErrorCF() {
		return ConfigurationUtil.getConfigValue(applicationConfigService.getDefaultErrorCF(),
				CommerceUtil.getBrandValue(currentPage, getHomePageLevel()));
	}
	
	private String getCFBasePath(String[] pathArray) {
		String brand = CommerceUtil.getBrandValue(currentPage, getHomePageLevel());
		return ConfigurationUtil.getConfigValue(pathArray, brand);
	}
	/**
	 * @return homePageLevel
	 */
	private int getHomePageLevel() {

		return applicationConfigService.getHomePageLevel();
	}
}