/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Map.Entry;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;

import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.tracfonecore.core.models.CarouselContainerModel;
import com.tracfonecore.core.utils.ItemsExporterUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CarouselContainerModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/carouselcontainer", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CarouselContainerModelImpl extends BaseComponentModelImpl  implements CarouselContainerModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(CarouselContainerModelImpl.class);
	
	// constants
		private static final String CARD_TYPE = "card";

	@Self
	private SlingHttpServletRequest request;
	
	@Inject
	private Resource resource;
	
	@Inject
	private SlingModelFilter slingModelFilter;

	@Inject
	private ModelFactory modelFactory;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL) 
	private String type;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Default(intValues = 4)
	private int noOfCards;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Default(intValues = 2)
	private int itemsCount;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Default(intValues = 2)
	private int noOfCardsPhone;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Default(intValues = 2)
	private int noOfCardsPlans;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Default(intValues = 2)
	private int noOfCardsRewards;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Default(intValues = 2)
	private int noOfCardsFeaturedApp;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Default(intValues  = 600)
	private int carouselSpeed;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Default(intValues = 1)
	private int noOfCardsRecomPlan;
		
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private boolean doNotUseFullWidth;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Default(values = "false")
	private boolean carouselBannerNarrow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Default(values = "false")
	private String multilinePlanSelection;
	@ValueMapValue
	private String plansPdpPath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String smartPayMessagePrefix;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String smartPayMessageSuffix;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String smartPayMessagelogo;

	private LinkedHashSet<Integer> totalItemsList;
	
	private HashMap<Integer,Integer> hashMap;

	private String autoScroll;
	/**
	 * <p>Fetches exported type</p>
	 * 
	 * @return String - exported type
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering initModel method");
		super.initModel();
		
		this.totalItemsList = new LinkedHashSet<Integer>();
		this.hashMap = new HashMap<Integer, Integer>();
        ArrayList<Integer> list = new ArrayList<>();
		
		resource.getChildren().forEach(res -> {
			LOGGER.debug("Resource Path => "+res.getPath());
			if(StringUtils.contains(res.getResourceType(), "/responsivegrid")) {
				res.getChildren().forEach(childRes -> {
					insertIndexInHashMap(childRes);
				});
			} else {
				insertIndexInHashMap(res);
			}
		});
			
		for (Map.Entry<Integer, Integer> entry : this.hashMap.entrySet()) {
            list.add(entry.getValue());
        }
        Collections.sort(list); 
               
        for (int num : list) {
            for (Entry<Integer, Integer> entry : this.hashMap.entrySet()) {
                if (entry.getValue().equals(num)) {
                	this.totalItemsList.add(entry.getKey());
                }
            }
        }
		
        for (int i=1; i<=this.itemsCount; i++) {
        	this.totalItemsList.add(i);
        }
        
		LOGGER.info("items ArrayList Size in carousel container: {} and size {}", this.totalItemsList, totalItemsList.size());
		this.autoScroll = "true";
		if(CARD_TYPE.equalsIgnoreCase(this.type) && (this.itemsCount == this.noOfCards)) 
			this.autoScroll = "false";			
		
		LOGGER.debug("Exiting initModel method");
	}
	
	private void insertIndexInHashMap(Resource childRes) {
		String index = Optional.ofNullable(childRes.getValueMap()).map(vm -> vm.get("orderIndex", String.class)).orElse("");
		String name = StringUtils.substring(childRes.getName(), childRes.getName().length()-1);
		LOGGER.debug("Resource :: index {}, Name {}",index,name);
		if(StringUtils.isNumeric(index) && StringUtils.isNumeric(name)) {
			this.hashMap.put(Integer.parseInt(name), Integer.parseInt(index));	
		}
	}

	/**
	 * <p>
	 * Fetches type of the carousel to define the layout
	 * </p>
	 * 
	 * @return String - type of the carousel
	 */
	@Override
	public String getType() {
		return type;
	}

	/**
	 * <p>
	 * Fetches number of slides to be displayed in carousel
	 * </p>
	 * 
	 * @return int - no. of items
	 */
	@Override
	public int getItemsCount() {
		return itemsCount;
	}

	/**
	 * <p>
	 * Fetches number of cards to be displayed by default
	 * </p>
	 * 
	 * @return int - no. of cards
	 */
	@Override
	public int getNoOfCards() {
		return noOfCards;

	}

	/**
	 * <p>
	 * Fetches totalItemsList
	 * </p>
	 *
	 * @return the totalItemsList
	 */
	@Override
	public List<Integer> getTotalItemsList() {
		return new ArrayList<>(totalItemsList);
	}

	/**
	 * <p>
	 * Fetches autoScroll value for carousel
	 * </p>
	 *
	 * @return String -  auto Scroll value for the sequential cards
	 */
	@Override
	 public String getAutoScroll() {
		return autoScroll;
	}


	/**
	  * <p>
	 * Fetches the export child items
	 * </p>
	 *
	 * 
	 * @return Map<String, ? extends ComponentExporter> - the export child items
	 */
	@Override
	public Map<String, ? extends ComponentExporter> getItems() {
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}
	/**
	 * <p>Fetches number of cards to be displayed by default on Phone card</p>
	 * 
	 * @return int - no. of cards to be displayed on Phone card
	 */
	@Override
	public int getNoOfCardsPhone() {
		return noOfCardsPhone;
	}

	/**
	 * <p>Fetches number of cards to be displayed by default on Plans card</p>
	 * 
	 * @return int - no. of cards to be displayed on Plans card
	 */@Override
	public int getNoOfCardsPlans() {
		return noOfCardsPlans;
	}
	 /**
		 * <p>Fetches number of cards to be displayed by default on Rewards</p>
		 * 
		 * @return int - no. of cards to be displayed on Rewards
		 */
	@Override
	public int getNoOfCardsRewards() {
		return noOfCardsRewards;
	}
	/**
	 * <p>Fetches number of cards to be displayed by default on Featured App</p>
	 * 
	 * @return int - no. of cards to be displayed on Featured App
	 */
	@Override
	public int getNoOfCardsFeaturedApp() {
		return noOfCardsFeaturedApp;
	}
	/**
	 * <p>Fetches Carousel speed in milliseconds</p>
	 * 
	 * @return int - carousel speed in milliseconds
	 */
	@Override
	public int getCarouselSpeed() {
		return carouselSpeed;
	}
	/**
	 * <p>Fetches number of cards to be displayed by default for Recommended Plan cards</p>
	 *
	 * @return int - no. of cards to be displayed for Recommended Plan cards
	 */
	@Override
	public int getNoOfCardsRecomPlan(){ return noOfCardsRecomPlan; }

	/**
	 *<p>Fetches doNotUseFullWidth</p>
	 *
	 * @return the doNotUseFullWidth
	 */
	@Override
	public boolean isDoNotUseFullWidth() {
		return doNotUseFullWidth;
	}

	/**
	 *<p>Fetches carouselBannerNarrow</p>
	 *
	 * @return the carouselBannerNarrow
	 */
	@Override
	public boolean isCarouselBannerNarrow() {
		return carouselBannerNarrow;
	}

	/**
	 *<p>Fetches smartPayMessagePrefix</p>
	 *
	 * @return the smartPayMessagePrefix
	 */
	@Override
	public String getSmartPayMessagePrefix() {
		return smartPayMessagePrefix;
	}

	/**
	 * <p>Fetches Carousel speed in milliseconds</p>
	 * 
	 * @return int - carousel speed in milliseconds
	 */
	@Override
	public String getSmartPayMessageSuffix() {
		return smartPayMessageSuffix;
	}

	/**
	 * <p>Fetches smartPayMessagelogo </p>
	 * 
	 * @return string - smartPayMessagelogo in milliseconds
	 */
	@Override
	public String getSmartPayMessagelogo() {
		return smartPayMessagelogo;
	}

	/**
	 *<p>Fetches multilinePlanSelection</p>
	 *
	 * @return the multilinePlanSelection
	 */
	@Override
	public String getMultilinePlanSelection() {
		return multilinePlanSelection;
	}
	@Override
	public String getPlansPdpPath() {
		return plansPdpPath;
	}
	
}
