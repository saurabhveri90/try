package com.tracfonecore.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.TrackTicketModel;
import com.tracfonecore.core.utils.ApplicationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { TrackTicketModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/trackticket", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class TrackTicketModelImpl implements TrackTicketModel {

	@Self
	private SlingHttpServletRequest request;
	
	@ValueMapValue
	private String title;
	
	@ValueMapValue
	private String statusLabel;
	
	@ValueMapValue
	private String transactionLabel;
	
	@ValueMapValue
	private String descLabel;
	
	@ValueMapValue
	private String lineLabel;
	
	@ValueMapValue
	private String lineIdentifierLabel;
	
	@ValueMapValue
	private String trackingNumberLabel;
	
	@ValueMapValue
	private String selectLinePagePath;
	
	@ValueMapValue @Default(values="5")
	private String numberOfItemsOnSinglePage;
	
	@ValueMapValue @Default(values="100")
	private String numberOfPageDisplayed;
	
	/**
	 * @return the selectLinePagePath
	 */
	@Override
	public String getSelectLinePagePath() {
		return ApplicationUtil.getShortUrl(request.getResourceResolver(), selectLinePagePath);
	}

	/**
	 * @return the selectLinePagePathWithoutDomain
	 */
	@Override
	public String getSelectLinePagePathWithoutDomain() {
		return ApplicationUtil.getUrlWithoutDomain(ApplicationUtil.getShortUrl(request.getResourceResolver(), selectLinePagePath));
	}
	
	/**
	 * @return the title
	 */
	@Override
	public String getTitle() {
		return title;
	}

	/**
	 * @return the statusLabel
	 */
	@Override
	public String getStatusLabel() {
		return statusLabel;
	}

	/**
	 * @return the transactionLabel
	 */
	@Override
	public String getTransactionLabel() {
		return transactionLabel;
	}

	/**
	 * @return the descLabel
	 */
	@Override
	public String getDescLabel() {
		return descLabel;
	}

	/**
	 * @return the lineLabel
	 */
	@Override
	public String getLineLabel() {
		return lineLabel;
	}

	/**
	 * @return the lineIdentifierLabel
	 */
	@Override
	public String getLineIdentifierLabel() {
		return lineIdentifierLabel;
	}

	/**
	 * @return the trackingNumberLabel
	 */
	@Override
	public String getTrackingNumberLabel() {
		return trackingNumberLabel;
	}

	/**
	 * @return the numberOfItemsOnSinglePage
	 */
	@Override
	public String getNumberOfItemsOnSinglePage() {
		return numberOfItemsOnSinglePage;
	}

	/**
	 * @return the numberOfPageDisplayed
	 */
	@Override
	public String getNumberOfPageDisplayed() {
		return numberOfPageDisplayed;
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

}
