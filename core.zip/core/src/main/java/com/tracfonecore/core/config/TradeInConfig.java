/**
 * 
 */
package com.tracfonecore.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

/**
 * @author vamsikrishna.jetty
 *
 */
@ObjectClassDefinition(name = "Tracfone Hyla Trade-In Configutration", description = "Trade-In Hyla API Details.")
public @interface TradeInConfig {
	
	 @AttributeDefinition(name = "Tracfone Trade-In Hyla API Base Endpoint",description = "Trade-In Hyla API Base Endpoint", type = AttributeType.STRING)
	    String apiBaseEndPoint() default "https://sit-apigateway.tracfone.com/api/sitf/hyla";
	 
	 @AttributeDefinition(name = "Tracfone Trade-In Hyla API Base Endpoint",description = "Trade-In Hyla API Base Endpoint", type = AttributeType.STRING)
	    String apiHylaCartUri() default "/order-mgmt/addHyla";

}
