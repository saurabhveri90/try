/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Payment Collection Configuration Service", description = "Payment Collection Configuration Service")
public @interface PaymentCollectionConfig {
	
	@AttributeDefinition(name = "Decryption Endpoint Url", description = "Please provide Decryption Endpoint")
	String  decryptionEndpointUrl() default "/api/utility-mgmt/data/";
	@AttributeDefinition(name = "TCetra Client ID", description = "Please provide TCetra Client ID")
	String  tCetraClientID() default "1f27ea25-e9cc-4a7a-97f1-98f48dc91644";
	@AttributeDefinition(name = "Voltage API Url", description = "Please provide Voltage API Url")
	String  voltageUrl() default "https://pie.uat.verizon.com";	
	@AttributeDefinition(name = "Encryption Js File Path in Library", description = "Please provide Encryption Js File Path in Library")
	String  voltageEncryptionJsFilePath() default "/pie/v1/encryption.js";
	@AttributeDefinition(name = "Encryption Js File Path in Library", description = "Please provide Encryption Js File Path in Library")
	String  voltageEncryptionKeyFilePath() default "/pie/v1/verizon/getkey.js";
	@AttributeDefinition(name = "Session Timeout in Minutes", description = "Please provide Session Timeout in Minutes for submit functionality on payment collection page")
	String  sessionTimeoutMinutesForIndirectChannel() default "30";
	@AttributeDefinition(name = "Country Mapping", description = "Please provide Country Mapping")
	String  countryMapping()default "{\"displayValue\":\"United States\",\"value\":\"US\"},\r\n" + 
			" {\"displayValue\":\"Guam\",\"value\":\"GU\"},\r\n" + 
			" {\"displayValue\":\" Virgin Islands\",\"value\":\"VI\"},\r\n" + 
			" {\"displayValue\":\"American Samoa\",\"value\":\"AS\"},\r\n" + 
			" {\"displayValue\":\"Mariana Islands\",\"value\":\"MP\"}";
	@AttributeDefinition(name = "Logo Image Url for web ", description = "Please provide Logo Image Url for Indirect channel")
	String  webLogoUrl() default "/content/dam/tbvz/logos/Total_Logo_Positive_RGB.png";
	@AttributeDefinition(name = "Logo Image Url for mobile", description = "Please provide Logo Image Url for Indirect channel")
	String  mobileLogoUrl() default "https://s7d1.scene7.com/is/image/tracfonestage/total_dot_logo_2x-desktop2?scl=1&fmt=webp-alpha&qlt=80,0&resMode=sharp2&op_usm=1.75,0.3,2,0";
	@AttributeDefinition(name = "Number of retries for Voltage JS scripts", description = "Please provide Number of retries for Voltage JS scripts")
	String voltageScriptRetries() default "1";

}

