/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;

/**
 * <p>Defines bean to hold </p>manage lines options
 */
/**
 * @author saurabh_kumar1
 *
 */
public class ManageLinesNotificationsBean {

    private String notificationCardType;
	private String notificationCardHeading;
	private String notificationCardSubheading;
	private String activeDeviceTutorialsSubheading;
	private String newDeviceTutorialsSubheading;
	private String enableNotification;
	private String showNotificationOnPlanTab;
	private String showNotificationOnDeviceTab;
	
	public String getNotificationCardType() {
		return notificationCardType;
	}
	public void setNotificationCardType(String notificationCardType) {
		this.notificationCardType = notificationCardType;
	}
	public String getNotificationCardHeading() {
		return notificationCardHeading;
	}
	public void setNotificationCardHeading(String notificationCardHeading) {
		this.notificationCardHeading = notificationCardHeading;
	}
	public String getNotificationCardSubheading() {
		return notificationCardSubheading;
	}
	public void setNotificationCardSubheading(String notificationCardSubheading) {
		this.notificationCardSubheading = notificationCardSubheading;
	}
	public String getEnableNotification() {
		return enableNotification;
	}
	public void setEnableNotification(String enableNotification) {
		this.enableNotification = enableNotification;
	}
	public String getShowNotificationOnPlanTab() {
		return showNotificationOnPlanTab;
	}
	public void setShowNotificationOnPlanTab(String showNotificationOnPlanTab) {
		this.showNotificationOnPlanTab = showNotificationOnPlanTab;
	}
	public String getShowNotificationOnDeviceTab() {
		return showNotificationOnDeviceTab;
	}
	public void setShowNotificationOnDeviceTab(String showNotificationOnDeviceTab) {
		this.showNotificationOnDeviceTab = showNotificationOnDeviceTab;
	}
	public String getActiveDeviceTutorialsSubheading() {
		return activeDeviceTutorialsSubheading;
	}
	public void setActiveDeviceTutorialsSubheading(String activeDeviceTutorialsSubheading) {
		this.activeDeviceTutorialsSubheading = activeDeviceTutorialsSubheading;
	}
	public String getNewDeviceTutorialsSubheading() {
		return newDeviceTutorialsSubheading;
	}
	public void setNewDeviceTutorialsSubheading(String newDeviceTutorialsSubheading) {
		this.newDeviceTutorialsSubheading = newDeviceTutorialsSubheading;
	}	
}
