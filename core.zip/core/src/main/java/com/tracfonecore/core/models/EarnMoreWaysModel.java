package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.EarnMoreWaysBean;

public interface EarnMoreWaysModel extends ComponentExporter {

    /**
	 * <p>Fetches headline for the section</p>
	 * 
	 * @return String - headline for the section
	 */
	@JsonProperty("earnMoreWaysHeadline")
	public String getEarnMoreWaysHeadline();

     /**
	 * <p>Fetches sub headline for the section</p>
	 * 
	 * @return String - sub headline for the section
	 */
	@JsonProperty("earnMoreWaysSubHeadline")
	public String getEarnMoreWaysSubHeadline();

    /**
	 * <p>Fetches cta text for the section</p>
	 * 
	 * @return String - cta text for the section
	 */
	@JsonProperty("earnMoreWaysCtaText")
	public String getEarnMoreWaysCtaText();

	 /**
	 * <p>Fetches banner path for the section</p>
	 * 
	 * @return String - banner path for the section
	 */
	@JsonProperty("earnMoreWaysBannerPath")
	public String getEarnMoreWaysBannerPath();

    /**
	 * <p>Fetches cta link for the section</p>
	 * 
	 * @return String - cta link for the section
	 */
	@JsonProperty("earnMoreWaysCtaLink")
	public String getEarnMoreWaysCtaLink();

	/**
	 * <p>Fetches cta aria label for the section</p>
	 * 
	 * @return String - cta aria label for the section
	 */
	@JsonProperty("earnMoreWaysCtaAriaLabel")
	public String getEarnMoreWaysCtaAriaLabel();

	@JsonProperty("shouldIncludeMyAccountNav")
	public Boolean getShouldIncludeMyAccountNav();

    /**
	 * <p>Fetches earn more ways card details for the section</p>
	 * 
	 * @return String - earn more ways card details for the section
	 */
	@JsonProperty("earnMoreWaysCardDetails")
	public List<EarnMoreWaysBean> getEarnMoreWaysCardDetails();

}