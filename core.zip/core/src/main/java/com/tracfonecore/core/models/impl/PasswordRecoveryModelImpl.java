/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.PasswordRecoveryModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { PasswordRecoveryModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/passwordrecovery", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class PasswordRecoveryModelImpl implements PasswordRecoveryModel {

	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headlinePwdRecovery;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String summaryPwdRecovery;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String successMessage;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accessibilityText;

	@Inject
	private Page currentPage;

	@Inject
	private Resource resource;

	@Inject
	private ApplicationConfigService applicationConfigService;

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Fetches headlinePwdRecovery for the passwordrecovery
	 * </p>
	 * 
	 * @return String - headlinePwdRecovery for the passwordrecovery
	 */
	@Override
	public String getHeadlinePwdRecovery() {
		return headlinePwdRecovery;
	}

	/**
	 * <p>
	 * Fetches summaryPwdRecovery for the passwordrecovery
	 * </p>
	 * 
	 * @return String - summaryPwdRecovery for the passwordrecovery
	 */
	@Override
	public String getSummaryPwdRecovery() {
		return summaryPwdRecovery;
	}

	/**
	 * <p>
	 * Fetches Register Success Message for the passwordrecovery
	 * </p>
	 * 
	 * @return String - Success Message for the passwordrecovery
	 */
	@Override
	public String getSuccessMessage() {
		return successMessage;
	}

	/**
	 * <p>
	 * Fetches Login Page Path
	 * </p>
	 * 
	 * @return String - Login Page Path
	 */
	@Override
	public String getLoginPagePath() {
		String loginPagePath = ApplicationUtil.getShortUrl(resource.getResourceResolver(), CommerceUtil
				.getPagePropertyValue(currentPage,getHomePageLevel(), ApplicationConstants.LOGIN_PATH_REDIRECTION)
				.toString());
		return loginPagePath;
	}

	/**
	 * <p>
	 * Fetches home page level property from config
	 * </p>
	 * 
	 * @return int - homePageLevel
	 */
	public int getHomePageLevel() {

		return applicationConfigService.getHomePageLevel();
	}

	/**
	 * <p>
	 * Fetches Accessibility Text
	 * </p>
	 * 
	 * @return String - accessibilityText
	 */
	@Override
	public String getAccessibilityText() {
		return accessibilityText;
	}
}
