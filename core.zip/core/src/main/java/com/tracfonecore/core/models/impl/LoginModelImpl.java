package com.tracfonecore.core.models.impl;

import javax.inject.Inject;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.LoginModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.BrandSpecificConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { LoginModel.class,
		ComponentExporter.class }, resourceType = {"tracfone-core/components/spa/commerce/login","tracfone-core/components/commerce/login"}, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class LoginModelImpl extends BaseComponentModelImpl implements LoginModel {
	@Self
	private SlingHttpServletRequest request;

	@Inject
	private Resource resource;

	@Inject
	private ApplicationConfigService applicationConfigService;

	@Inject
	private BrandSpecificConfigService brandSpecificConfigService;

	private String cookie;

	@Inject
	private Page currentPage;

	/**
	 * Inject screenType
	 */
	@Inject
	@Via("resource")
	private String screenType;

	/**
	 * Inject header text
	 */
	@Inject
	@Via("resource")
	private String headerText;

	/**
	 * Inject accessibility text
	 */
	@Inject
	@Via("resource")
	private String accessibilityText;

	/**
	 * Inject summary
	 */
	@Inject
	@Via("resource")
	private String summary;

	/**
	 * Inject summaryDummyUser
	 */
	@Inject
	@Via("resource")
	private String summaryDummyUser;

	@ValueMapValue
	private String enabletooltip;

	/**
	 * Inject learmMoreModalContent
	 */
	@Inject
	@Via("resource")
	private String learnMoreModalContent;

	/**
	 * Inject forgotPasswordLink
	 */
	@Inject
	@Via("resource")
	private String forgotPasswordLink;

	/**
	 * Inject disableCaptcha
	 */
	@Inject
	@Via("resource")
	private String disableCaptcha;


	/**
	 * Inject disableEnterpriseCaptcha
	 */
	@Inject
	@Via("resource")
	private String disableEnterpriseCaptcha;

	/**
	 * Inject disableFacebook
	 */
	@Inject
	@Via("resource")
	private String disableFacebook;

	/**
	 * Inject disableChat
	 */
	@Inject
	@Via("resource")
	private String disableChat;

	/**
	 * Inject chatIconLink
	 */
	@Inject
	@Via("resource")
	private String chatIconLink;

	/**
	 * Inject chatButtonText
	 */
	@Inject
	@Via("resource")
	private String chatButtonText;

	/**
	 * Inject chatButtonLink
	 */
	@Inject
	@Via("resource")
	private String chatButtonLink;

	/**
	 * Inject loginPswScreenLink
	 */
	@Inject
	@Via("resource")
	private String loginPswScreenLink;

	/**
	 * Inject accessAccountLink
	 */
	@Inject
	@Via("resource")
	private String accessAccountLink;

	/**
	 * Inject securityPinScreenLink
	 */
	@Inject
	@Via("resource")
	private String securityPinScreenLink;

	/**
	 * Inject securityQuestionScreenLink
	 */
	@Inject
	@Via("resource")
	private String securityQuestionScreenLink;

	/**
	 * Inject alreadyFbLoggedinScreenLink
	 */
	@Inject
	@Via("resource")
	private String alreadyFbLoggedinScreenLink;

	/**
	 * Inject alreadyFbLoggedinPwdScreenLink
	 */
	@Inject
	@Via("resource")
	private String alreadyFbLoggedinPwdScreenLink;

	/**
	 * Inject linkAccountPwdScreenLink
	 */
	@Inject
	@Via("resource")
	private String linkAccountPwdScreenLink;

	/**
	 * Inject selectEmailScreenLink
	 */
	@Inject
	@Via("resource")
	private String selectEmailScreenLink;

	/**
	 * Inject selectVerifyEmailScreenLink
	 */
	@Inject
	@Via("resource")
	private String selectVerifyEmailScreenLink;

	/**
	 * Inject dummyAccountVerifyEmailScreenLink
	 */
	@Inject
	@Via("resource")
	private String dummyAccountVerifyEmailScreenLink;


	/**
	 * Inject securityPinQuestionScreenLink
	 */
	@Inject
	@Via("resource")
	private String securityPinQuestionScreenLink;

	/**
	 * Inject phoneNumberScreenLink
	 */
	@Inject
	@Via("resource")
	private String phoneNumberScreenLink;

	/**
	 * Inject zipCodeScreenLink
	 */
	@Inject
	@Via("resource")
	private String zipCodeScreenLink;

	/**
	 * Inject zipCodeScreenLink
	 */
	@Inject
	@Via("resource")
	private String verificationCodeZipScreenLink;

	/**
	 * Inject registerUpdateScreenLink
	 */
	@Inject
	@Via("resource")
	private String registerUpdateScreenLink;

	/**
	 * Inject registerSuccessScreenLink
	 */
	@Inject
	@Via("resource")
	private String registerSuccessScreenLink;

	/**
	 * Inject loginOTCVerificationScreenLink
	 */
	@Inject
	@Via("resource")
	private String loginOTCVerificationScreenLink;

	/**
	 * Inject registerSuccessScreenLink
	 */
	@Inject
	@Via("resource")
	private String notEnrolledLink;

	/**
	 * Inject accountCreationWithZipCode
	 */
	@Inject
	@Via("resource")
	private String accountCreationWithZipCode;

	/**
	 * <p>
	 * Returns screenType from properties
	 * </p>
	 *
	 * @return the screenType
	 */
	@Override
	public String getNotEnrolledLink() {
		return ApplicationUtil.getShortUrl(request.getResourceResolver(), notEnrolledLink);
	}

	/**
	 * <p>
	 * Returns screenType from properties
	 * </p>
	 *
	 * @return the screenType
	 */
	@Override
	public String getScreenType() {
		return screenType;
	}

	/**
	 * <p>
	 * Returns headerText from properties
	 * </p>
	 *
	 * @return String - headerText
	 */
	@Override
	public String getHeaderText() {
		return headerText;
	}

	/**
	 * <p>
	 * Returns accessibilityText from properties
	 * </p>
	 *
	 * @return String - accessibilityText
	 */
	@Override
	public String getAccessibilityText() {
		return accessibilityText;
	}

	/**
	 * <p>
	 * Returns summary from properties
	 * </p>
	 *
	 * @return String - summary
	 */
	@Override
	public String getSummary() {
		return summary;
	}

	/**
	 * <p>
	 * Returns summaryDummyUser from properties
	 * </p>
	 *
	 * @return String - summaryDummyUser
	 */
	@Override
	public String getSummaryDummyUser() {
		return summaryDummyUser;
	}

	/**
	 * <p>
	 * Returns enabletooltip from properties
	 * </p>
	 *
	 * @return String - enabletooltip
	 */
	@Override
	public String getEnabletooltip() {
		return enabletooltip;
	}

	/**
	 * <p>
	 * Returns learnMoreModalContent from properties
	 * </p>
	 *
	 * @return the learnMoreModalContent
	 */
	@Override
	public String getLearnMoreModalContent() {
		return learnMoreModalContent;
	}

	/**
	 * <p>
	 * Returns forgotPasswordLink from properties
	 * </p>
	 *
	 * @return the forgotPasswordLink
	 */
	@Override
	public String getForgotPasswordLink() {
		return forgotPasswordLink;
	}

	/**
	 * <p>
	 * Returns disableCaptcha from properties
	 * </p>
	 * @return the disableCaptcha
	 */
	@Override
	public String getDisableCaptcha() {
		return disableCaptcha;
	}


	/**
	 * <p>
	 * Returns disableEnterpriseCaptcha from properties
	 * </p>
	 * @return the disableEnterpriseCaptcha
	 */
	@Override
	public String getDisableEnterpriseCaptcha() {
		return disableEnterpriseCaptcha;
	}

	/**
	 * <p>
	 * Returns disableFacebook from properties
	 * </p>
	 * @return String - disableFacebook
	 */
	@Override
	public String getDisableFacebook() {
		return disableFacebook;
	}

	/**
	 * <p>
	 * Returns disableChat from properties
	 * </p>
	 *
	 * @return String - disableChat
	 */
	@Override
	public String getDisableChat() {
		return disableChat;
	}

	/**
	 * <p>
	 * Returns chatIconLink from properties
	 * </p>
	 * @return the chatIconLink
	 */
	@Override
	public String getChatIconLink() {
		return chatIconLink;
	}

	/**
	 * <p>
	 * Returns chatButtonText from properties
	 * </p>
	 * @return the chatButtonText
	 */
	@Override
	public String getChatButtonText() {
		return chatButtonText;
	}

	/**
	 * <p>
	 * Returns chatButtonLink from properties
	 * </p>
	 * @return the chatButtonLink
	 */
	@Override
	public String getChatButtonLink() {
		return chatButtonLink;
	}

	/**
	 * <p>
	 * Returns loginPswScreenLink from properties
	 * </p>
	 * @return the loginPswScreenLink
	 */
	@Override
	public String getLoginPswScreenLink() {
		return loginPswScreenLink;
	}

	/**
	 * <p>
	 * Returns accessAccountLink from properties
	 * </p>
	 * @return the accessAccountLink
	 */
	@Override
	public String getAccessAccountLink() {
		return accessAccountLink;
	}

	/**
	 * <p>
	 * Returns securityPinScreenLink from properties
	 * </p>
	 * @return the securityPinScreenLink
	 */
	@Override
	public String getSecurityPinScreenLink() {
		return securityPinScreenLink;
	}

	/**
	 * <p>
	 * Returns securityQuestionScreenLink from properties
	 * </p>
	 * @return the securityQuestionScreenLink
	 */
	@Override
	public String getSecurityQuestionScreenLink() {
		return securityQuestionScreenLink;
	}

	/**
	 * <p>
	 * Returns securityPinQuestionScreenLink from properties
	 * </p>
	 * @return the securityPinQuestionScreenLink
	 */
	@Override
	public String getSecurityPinQuestionScreenLink() {
		return securityPinQuestionScreenLink;
	}

	/**
	 * <p>
	 * Returns phoneNumberScreenLink from properties
	 * </p>
	 * @return the phoneNumberScreenLink
	 */
	@Override
	public String getPhoneNumberScreenLink() {
		return phoneNumberScreenLink;
	}

	/**
	 * <p>
	 * Returns zipCodeScreenLink from properties
	 * </p>
	 * @return the zipCodeScreenLink
	 */
	@Override
	public String getZipCodeScreenLink() {
		return zipCodeScreenLink;
	}

	/**
	 * <p>
	 * Fetches ReCaptcha SiteKey property from config
	 * </p>
	 *
	 * @return String[] - reCaptchaSiteKey
	 */
	@Override
	public String getReCaptchaSiteKey() {

		return ConfigurationUtil.getConfigValue(applicationConfigService.getReCaptchaSiteKey(), CommerceUtil.getBrandValue(currentPage, getHomePageLevel()));
	}

	/**
	 * <p>
	 * Fetches ReCaptcha SiteKey property from config
	 * </p>
	 *
	 * @return String[] - reCaptchaSiteKey
	 */
	@Override
	public String getReCaptchaEnterpriseSiteKey() {

		return ConfigurationUtil.getConfigValue(applicationConfigService.getReCaptchaEnterpriseSiteKey(), CommerceUtil.getBrandValue(currentPage, getHomePageLevel()));
	}

	/**
	 * <p>
	 * Fetches  tealiumEnvName property from config
	 * </p>
	 *
	 * @return String - tealiumEnvName
	 */
	@Override
	public String getTealiumEnvName() {
		return applicationConfigService.getTealiumEnvName();
	}

	/**
	 * <p>
	 * Fetches myAccountUrl property from home page 
	 * </p>
	 * @return the myAccountUrl
	 */
	@Override
	public String getMyAccountUrl() {
		String myAccountUrl =  ApplicationUtil.getShortUrl(resource.getResourceResolver(),CommerceUtil
				.getPagePropertyValue(currentPage, getHomePageLevel(), ApplicationConstants.MY_ACCOUNT_DASHBOARD_PATH).toString());
		return myAccountUrl;
	}

	/**
	 *  <p>
	 * Fetches loginXfpath from properties
	 * </p>
	 * @return the loginXfpath
	 */
	@Override
	public String getLoginXfPath() {
		String loginXfPath = CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(), "loginEmailXfPath").toString();
		return loginXfPath;
	}

	/**
	 * <p>
	 * Fetches alreadyFbLoggedinScreenLink from properties
	 * </p>
	 * @return the alreadyFbLoggedinScreenLink
	 */
	@Override
	public String getAlreadyFbLoggedinScreenLink() {
		return alreadyFbLoggedinScreenLink;
	}

	/**
	 * <p>
	 * Fetches alreadyFbLoggedinPwdScreenLink from properties 
	 * </p>
	 * @return the alreadyFbLoggedinPwdScreenLink
	 */
	@Override
	public String getAlreadyFbLoggedinPwdScreenLink() {
		return alreadyFbLoggedinPwdScreenLink;
	}

	/**
	 * <p>
	 * Fetches linkAccountPwdScreenLink from properties
	 * </p>
	 * @return the linkAccountPwdScreenLink
	 */
	@Override
	public String getLinkAccountPwdScreenLink() {
		return linkAccountPwdScreenLink;
	}

	/**
	 * <p>
	 * Fetches selectEmailScreenLink from properties
	 * </p>
	 * @return the selectEmailScreenLink
	 */
	@Override
	public String getSelectEmailScreenLink() {
		return selectEmailScreenLink;
	}

	/**
	 * <p>
	 * Fetches selectVerifyEmailScreenLink from properties
	 * </p>
	 * @return the selectVerifyEmailScreenLink
	 */
	@Override
	public String getSelectVerifyEmailScreenLink() {
		return selectVerifyEmailScreenLink;
	}

	/**
	 * <p>
	 * Fetches dummyAccountVerifyEmailScreenLink from properties
	 * </p>
	 * @return the dummyAccountVerifyEmailScreenLink
	 */
	@Override
	public String getDummyAccountVerifyEmailScreenLink() {
		return dummyAccountVerifyEmailScreenLink;
	}


	/**
	 * <p>
	 * Fetches verificationCodeZipScreenLink from properties
	 * </p>
	 * @return the verificationCodeZipScreenLink
	 */
	@Override
	public String getVerificationCodeZipScreenLink() {
		return verificationCodeZipScreenLink;
	}

	/**
	 *  <p>
	 * Fetches registerUpdateScreenLink from properties
	 * </p>
	 * @return the registerUpdateScreenLink
	 */
	@Override
	public String getRegisterUpdateScreenLink() {
		return registerUpdateScreenLink;
	}

	/**
	 *  <p>
	 * Fetches registerSuccessScreenLink from properties
	 * </p>
	 * @return String - registerSuccessScreenLink
	 */
	@Override
	public String getRegisterSuccessScreenLink(){
		return registerSuccessScreenLink;
	}

	/**
	 *  <p>
	 * Fetches loginOTCVerificationScreenLink from properties
	 * </p>
	 * @return String - loginOTCVerificationScreenLink
	 */
	@Override
	public String getLoginOTCVerificationScreenLink(){
		return loginOTCVerificationScreenLink;
	}

	/**
	 *  <p>
	 * Fetches registerSuccessScreenLink from properties
	 * </p>
	 * @return String - registerSuccessScreenLink
	 */
	@Override
	public String getPostLogoutRedirectUrl(){
		String postLogoutRedirectUrl =  ApplicationUtil.getShortUrl(resource.getResourceResolver(),CommerceUtil
				.getPagePropertyValue(currentPage, getHomePageLevel(), ApplicationConstants.MY_ACCOUNT_LOGOUT_REDIRECT_PATH).toString());
		return postLogoutRedirectUrl;
	}

	/**
	 * <p>
	 * Fetches home page level property from config
	 * </p>
	 *
	 * @return int - homePageLevel
	 */
	@Override
	public int getHomePageLevel() {

		return applicationConfigService.getHomePageLevel();
	}

	/**
	 * <p>
	 * Returns exportertype from resource
	 * </p>
	 *
	 * @return String - exportertype
	 */
	@Override
	public String getExportedType() {

		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Returns hideSecurityQuestions config value
	 * </p>
	 *
	 * @return String - hideSecurityQuestions
	 */
	@Override
	public String getHideLoginSecurityQuestions() {
		return ConfigurationUtil.getConfigValue(brandSpecificConfigService.hideLoginSecurityQuestions(), CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}

	/**
	 * <p>
	 * Returns accountCreationWithZipCode from properties
	 * </p>
	 * @return String - accountCreationWithZipCode
	 */
	@Override
	public String getAccountCreationWithZipCode() {
		return accountCreationWithZipCode;
	}

}
