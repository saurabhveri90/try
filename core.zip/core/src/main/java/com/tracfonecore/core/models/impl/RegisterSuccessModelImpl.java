package com.tracfonecore.core.models.impl;

import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.RegisterSuccessModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { RegisterSuccessModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/registersuccess", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class RegisterSuccessModelImpl implements RegisterSuccessModel {

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private ApplicationConfigService applicationConfigService;
	
	@Inject
	private Page currentPage;
	/**
	 * Inject successMessage1
	 */
	@Inject
	@Via("resource")
	private String successMessage1;
	
	/**
	 * Inject successMessage2
	 */
	@Inject
	@Via("resource")
	private String successMessage2;
	
	/**
	 * Inject screenType
	 */
	@Inject
	@Via("resource")
	private String screenType;
	
	/**
	 * Inject accessibility text
	 */
	@Inject
	@Via("resource")
	private String accessibilityText;
	
	@Inject
	private Resource resource;
	
	private String myAccountPagePath;	
	
	
	/**
	 * <p>
	 * Fetches home page level property from config
	 * </p>
	 * 
	 * @return int - homePageLevel
	 */
	@Override
	public int getHomePageLevel() {

		return applicationConfigService.getHomePageLevel();
	}
	
	/**
	 * <p>
	 * Returns exportertype from resource
	 * </p>
	 * 
	 * @return String - exportertype
	 */
	@Override
	public String getExportedType() {

		return request.getResource().getResourceType();
	}
	
	/**
	 * <p>Fetches Register Success Message 1</p>
	 * 
	 * @return String -  Success Message 1
	 */
	@Override
	public String getSuccessMessage1(){
		return successMessage1;
	}

	/**
	 * <p>Fetches Register Success Message 2</p>
	 * 
	 * @return String -  Success Message 2
	 */
	@Override
	public String getSuccessMessage2(){
		return successMessage2;
	}	
	/**
	 * <p>Fetches My Account Path</p>
	 * 
	 * @return String - My account Page Path
	 */
	@Override
	public String getMyAccountPagePath() {
		 myAccountPagePath = ApplicationUtil.getShortUrl(resource.getResourceResolver(),
				CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(), ApplicationConstants.MY_ACCOUNT_DASHBOARD_PATH).toString());
		return myAccountPagePath;        
	}

	/**
	 * @return the screenType
	 */
	@Override
	public String getScreenType() {
		return screenType;
	}

	/**
	 * <p>Fetches Accessibility Text</p>
	 * 
	 * @return String - accessibilityText
	 */
	@Override
	public String getAccessibilityText() {
		return accessibilityText;
	}

}
