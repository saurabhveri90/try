package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Carousel} Sling Model used for the {@code /apps/tracfone-core/components/content/carouselcarditem} component.
 */
public interface CarouselCardModel extends ComponentExporter  {
	
	/**
	 * <p>Fetches title of the carousel</p>
	 * 
	 * @return String - title of the carousel
	 */
	@JsonProperty("title")
	public String getTitle();
	
	/**
	 * <p>Fetches summary of the carousel</p>
	 * 
	 * @return String - summary of the carousel
	 */
	@JsonProperty("summary")
	public String getSummary();
	
	
	/**
	 * <p>Fetches Image path</p>
	 * 
	 * @return String - image path
	 */
	@JsonProperty("mediaPath")
	public String getMediaPath();
		
	/**
	 * <p>Fetches alt text for the image</p>
	 * 
	 * @return String - alt text for the image
	 */
	@JsonProperty("imageAltText")
	public String getImageAltText();
	
	
	/**
	 * <p>Fetches accessbility label</p>
	 * 
	 * @return String - accessbility label
	 */
	@JsonProperty("accessbilityLabel")
	public String getAccessbilityLabel();

	/**
	 *<p>Fetches the path for mobile image path</p>
	 *
	 * @return String - mobile image path
	 */
	public String getMobileMediaImagePath();
	
	/**
	 *<p>Fetches the data mode</p>
	 *
	 * @return String - data mode
	 */
	public String getDataMode();
	/**
	 *  <p>
	 * Fetches break points for the image
	 * </p> 
	 * 
	 * @return String - imageProfileBreakpoints
	 */
	public String getImageProfileBreakpoints();
	
	/**
	 * <p>
	 * Method to return BreakPoints
	 * </p>
	 * 
	 * @return String
	 */
	public String getBreakPoints() ;

}