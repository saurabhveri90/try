/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl.v1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.AdvertisementCardsModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import com.tracfonecore.core.beans.AdvertisementCardBean;
import com.tracfonecore.core.beans.CardFlowMappingBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.CommerceConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { AdvertisementCardsModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/advertisementcards/v1/advertisementcards", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class AdvertisementCardsModelImpl implements AdvertisementCardsModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;

	@Inject
	private Resource resource;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    protected String componentVersion;

	private List<AdvertisementCardBean> cardsList = Collections.emptyList();

	private static final Logger LOGGER = LoggerFactory.getLogger(AdvertisementCardsModelImpl.class);

	//Constants
	private static final String CARDSLIST = "advertisementCards";
	private static final String CARD_TYPE = "cardType";
	private static final String HEADING = "title";
	private static final String SUB_HEADING = "subTitle";
	private static final String TEXT_ALIGNMENT = "textAlignment";
	private static final String IMAGE = "cardImage";
	private static final String ALT_TEXT = "cardImageAltText";
	private static final String CARD_CTA_SIZE = "cardCtaSize";
	private static final String CARD_CTA_TYPE = "cardCtaType";
	private static final String BUTTON_TEXT_ALIGNMENT = "buttonTextAlignment";
	private static final String CTA_LABEL = "cardCtaLabel";
	private static final String LINK = "cardCtaLink";
	private static final String TARGET = "linkTarget";
	private static final String DO_NOT_FOLLOW = "doNotFollowLink";
	private static final String DISABLE_CARD = "disableCard";
	private static final String FLOW_CONFIGS_LIST = "flowConfigs";
	private static final String DEVICE_TYPE = "deviceType";
	private static final String TRANSACTION_TYPE = "transactionType";
	private static final String FLOW_TYPE = "flowType";
	private static final String ENABLE_CARD = "enableCard";
	private static final String MOBILE_VERSION = "mobileVersion";
	private static final String TEXT_COLOR = "textColor";
	private static final String BG_COLOR = "bgColor";
	private static final String MOBILE_IMAGE = "mobileImagePath";
	private static final String INCLUDE_APPSTORE = "includeAppStore";
	private static final String APPSTORE = "appstore";
	private static final String APPSTORE_FILE_REFERENCE = "appstoreFileReference";
	private static final String APPSTORE_REALTEXT = "appstorealttext";
	private static final String INCLUDE_PLAYSTORE = "includePlayStore";
	private static final String PLAYSTORE = "playstore";
	private static final String PLAYSTORE_FILE_REFERENCE = "playstoreFileReference";
	private static final String PLAYSTORE_REALTEXT = "playstorealttext";

	@PostConstruct
	private void initModel() {

		cardsList = new ArrayList<AdvertisementCardBean>();

		for (Resource child : resource.getChildren()) {
			if(CARDSLIST.equals(child.getName()))
			{
				Iterator<Resource> it = child.listChildren();
				setMultiFieldItems(it, cardsList);
			}
		}

	}
	/**
	 * <p>Populates a list with all the image and text of the Cards List</p>
	 * 
	 * @param it - iterator of the parent node
	 * @param multiFieldData - list in which the images data needs to be set
	 */
	private void setMultiFieldItems(Iterator<Resource> it, List<AdvertisementCardBean> multiFieldData) {
		LOGGER.debug("Entering setMultiFieldItems method");
		String s7Path="";
		String s7MobilePath="";
		AdvertisementCardBean cardBean = null;

		while (it.hasNext()) {
			cardBean = new AdvertisementCardBean();
			Resource grandChild = it.next();

			cardBean.setDisableCard(grandChild.getValueMap().get(DISABLE_CARD,String.class));
			
			//Check if cards are not disabled, then only collect them in list
			if(cardBean.getDisableCard()!=null && cardBean.getDisableCard().toLowerCase().equalsIgnoreCase(ApplicationConstants.TRUE))
			{
				cardBean.setCardType(grandChild.getValueMap().get(CARD_TYPE, String.class));
				cardBean.setTitle(grandChild.getValueMap().get(HEADING, String.class));
				cardBean.setSubTitle(grandChild.getValueMap().get(SUB_HEADING, String.class));
				cardBean.setTextAlignment(grandChild.getValueMap().get(TEXT_ALIGNMENT, String.class));
				s7Path = DynamicMediaUtils.changeMediaPathToDMPath(grandChild.getValueMap().get(IMAGE,String.class), request.getResourceResolver());
				cardBean.setCardImage(s7Path);
				cardBean.setCardImageAltText(grandChild.getValueMap().get(ALT_TEXT,String.class));
				cardBean.setCardCtaSize(grandChild.getValueMap().get(CARD_CTA_SIZE,String.class));
				cardBean.setCardCtaType(grandChild.getValueMap().get(CARD_CTA_TYPE,String.class));
				cardBean.setCardCtaLabel(grandChild.getValueMap().get(CTA_LABEL,String.class));
				cardBean.setCardCtaLink(ApplicationUtil.getShortUrl(request.getResourceResolver(), grandChild.getValueMap().get(LINK,String.class)));
				cardBean.setLinkTarget(grandChild.getValueMap().get(TARGET,String.class));
				cardBean.setDoNotFollowLink(ApplicationUtil.getNoFollow(grandChild.getValueMap().get(DO_NOT_FOLLOW,String.class)));
				cardBean.setDisableCard(grandChild.getValueMap().get(DISABLE_CARD,String.class));
				cardBean.setButtonTextAlignment(grandChild.getValueMap().get(BUTTON_TEXT_ALIGNMENT,String.class));
				cardBean.setAssetId(ApplicationUtil.getAssetId(grandChild.getValueMap().get(IMAGE,String.class),
						request.getResourceResolver(), ApplicationConstants.IMAGE));
				cardBean.setWeberId(ApplicationUtil.getAssetMetaDataValue(grandChild.getValueMap().get(IMAGE,String.class),
						request.getResourceResolver(), ApplicationConstants.WEBER_ID));	
				cardBean.setTextColor(grandChild.getValueMap().get(TEXT_COLOR,String.class));
				cardBean.setMobileVersion(grandChild.getValueMap().get(MOBILE_VERSION,String.class));
				cardBean.setMode(grandChild.getValueMap().get(MOBILE_VERSION,String.class));
				cardBean.setMobileMediaImagePath(getMobileMediaImagePath(grandChild.getValueMap().get(IMAGE,String.class), cardBean.getMobileVersion()));
				cardBean.setImageProfileBreakPoint(getImageProfileBreakpoints(grandChild.getValueMap().get(IMAGE,String.class), cardBean.getMode()));
				cardBean.setBgColor(grandChild.getValueMap().get(BG_COLOR,String.class));
				
				s7MobilePath = DynamicMediaUtils.changeMediaPathToDMPath(grandChild.getValueMap().get(MOBILE_IMAGE,String.class), request.getResourceResolver());
				cardBean.setMobileImagePath(s7MobilePath);
				cardBean.setAppstore(grandChild.getValueMap().get(APPSTORE,String.class));
				cardBean.setAppstorealttext(grandChild.getValueMap().get(APPSTORE_REALTEXT,String.class));
				cardBean.setAppstoreFileReference(grandChild.getValueMap().get(APPSTORE_FILE_REFERENCE,String.class));
				cardBean.setIncludeAppStore(grandChild.getValueMap().get(INCLUDE_APPSTORE,String.class));
				cardBean.setPlaystore(grandChild.getValueMap().get(PLAYSTORE,String.class));
				cardBean.setPlaystorealttext(grandChild.getValueMap().get(PLAYSTORE_REALTEXT,String.class));
				cardBean.setPlaystoreFileReference(grandChild.getValueMap().get(PLAYSTORE_FILE_REFERENCE,String.class));
				cardBean.setIncludePlayStore(grandChild.getValueMap().get(INCLUDE_PLAYSTORE,String.class));

				for (Resource child : grandChild.getChildren()) {
					if(FLOW_CONFIGS_LIST.equals(child.getName()))
					{
						Iterator<Resource> childIt = child.listChildren();
						cardBean.setCardsFlowMappingList(setFieldMappingItems(childIt));
					}
				}
				
				multiFieldData.add(cardBean);
			}
			

			
		}

		LOGGER.debug("Exiting setMultiFieldItems method");
	}

	/**
	 * <p>Populates a list with all the flow-transaction mapping of the Cards List</p>
	 * 
	 * @param it - iterator of the parent node
	 * @return List<CardFlowMappingBean> - list in which the card flow-transaction mapping data needs to be set
	 */
	private List<CardFlowMappingBean> setFieldMappingItems(Iterator<Resource> it) {
		LOGGER.debug("Entering setFieldMappingItems method");

		List<CardFlowMappingBean> cardsFlowMappingList = new ArrayList<CardFlowMappingBean>();

		while (it.hasNext()) {
			CardFlowMappingBean mappingBean = new CardFlowMappingBean();
			Resource grandChild = it.next();

			mappingBean.setEnableCard(grandChild.getValueMap().get(ENABLE_CARD, String.class));
			
			//Checking if card is enabled for flow device mapping combination
			if(mappingBean.getEnableCard()!=null && mappingBean.getEnableCard().equalsIgnoreCase(ApplicationConstants.YES))
			{
				mappingBean.setDeviceType(grandChild.getValueMap().get(DEVICE_TYPE, String.class));
				mappingBean.setFlowType(grandChild.getValueMap().get(FLOW_TYPE, String.class));
				mappingBean.setTransactionType(grandChild.getValueMap().get(TRANSACTION_TYPE, String.class));
				
				/*
				 * This block is used to set the same config of pin flow for queued plan also, since we need to consider this type under activation pin only
				 */
				if(CommerceConstants.PIN_FLOW_TYPE.equals(mappingBean.getTransactionType()))
				{
					CardFlowMappingBean mappingBeanQueued = new CardFlowMappingBean();
					mappingBeanQueued.setDeviceType(mappingBean.getDeviceType());
					mappingBeanQueued.setFlowType(mappingBean.getFlowType());
					mappingBeanQueued.setTransactionType(CommerceConstants.QUEUED_FLOW_TYPE);
					mappingBeanQueued.setEnableCard(mappingBean.getEnableCard());
					cardsFlowMappingList.add(mappingBeanQueued);
				}

				cardsFlowMappingList.add(mappingBean);
			}
			
		}

		LOGGER.debug("Exiting setFieldMappingItems method ");

		return cardsFlowMappingList;
	}
	
	public String getMobileMediaImagePath(String imagePath, String mobileVersion) {
		String path = DynamicMediaUtils.getMobileDMPath(imagePath, request.getResourceResolver());
		if(!ApplicationConstants.MOBILE_IMAGE.equals(mobileVersion)) {
			path = StringUtils.EMPTY; 
		}
		return path;
	}
	
	/**
	 *  <p>
	 * Fetches break points for the image
	 * </p> 
	 * 
	 * @return String - imageProfileBreakpoints
	 */
	public String getImageProfileBreakpoints(String imagePath,String mode) {
		String path = imagePath;
		String breakPoints = "";
		if(ApplicationConstants.BG_SMART_CROP.equals(mode)) {
			breakPoints = DynamicMediaUtils.getImageProfileBreakpoints(path, request.getResourceResolver());
		}
		return breakPoints;
	}

	@Override
	public List<AdvertisementCardBean> getCardsList() {
		return new ArrayList<>(cardsList);
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
    public String getComponentVersion() {
        return StringUtils.isNotBlank(componentVersion) ?  componentVersion: "v1";
    }


}
