package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

public interface InlineCtaModel extends ComponentExporter {
    /**
	 * <p>
	 * Fetches heading
	 * </p>
	 * 
	 * @return String - heading
	 */
	@JsonProperty("heading")
	public String getHeading();
    
	/**
	 * <p>
	 * Fetches backgroundImage
	 * </p>
	 * 
	 * @return String - backgroundImage
	 */
	@JsonProperty("backgroundImage")
	public String getBackgroundImage();
}