/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;
import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
/**
 * Defines the {@code Multi-Links} Sling Model used for the {@code tracfone-core/components/spa/commerce/purchaseflowcard} component.
 */
public interface PurchaseFlowModel extends ComponentExporter {
	/**
	 * <p>Fetches subheading for the PurchaseFlow</p>
	 *
	 * @return String - subheading for the PurchaseFlow
	 */
	@JsonProperty("subheading")
	default String getSubheading(){
		return null;
	}
	/**
	 * <p>Fetches subHeadingIconPath for the PurchaseFlow</p>
	 *
	 * @return String - subHeadingIconPath for the PurchaseFlow
	 */
	@JsonProperty("subHeadingIconPath")
	default String getSubHeadingIconPath(){
		return null;
	}
	/**
	 * <p>Fetches heading for the PurchaseFlow</p>
	 *
	 * @return String - heading for the PurchaseFlow
	 */
	@JsonProperty("heading")
	default String getHeading(){
		return null;
	}
	/**
	 * <p>Fetches description for the PurchaseFlow</p>
	 *
	 * @return String - description for the PurchaseFlow
	 */
	@JsonProperty("description")
	default String getDescription(){
		return null;
	}
	/**
	 * <p>Fetches ctaLabel for the PurchaseFlow</p>
	 *
	 * @return String - ctaLabel for the PurchaseFlow
	 */
	@JsonProperty("ctaLabel")
	default String getCtaLabel(){
		return null;
	}
	/**
	 * <p>Fetches ctaLink for the PurchaseFlow</p>
	 *
	 * @return String - ctaLink for the PurchaseFlow
	 */
	@JsonProperty("ctaLink")
	default String getCtaLink(){
		return null;
	}
	/**
	 * <p>Fetches learnmoreLabel for the PurchaseFlow</p>
	 *
	 * @return String - learnmoreLabel for the PurchaseFlow
	 */
	@JsonProperty("learnmoreLabel")
	default String getLearnmoreLabel(){
		return null;
	}
	/**
	 * <p>Fetches learnmoreLink for the PurchaseFlow</p>
	 *
	 * @return String - learnmoreLink for the PurchaseFlow
	 */
	@JsonProperty("learnmoreLink")
	default String getLearnmoreLink(){
		return null;
	}
}

