/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 */
package com.tracfonecore.core.models.impl;

import java.util.Map;
import java.util.Objects;
import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.tracfonecore.core.models.ProductCarouselModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import com.tracfonecore.core.utils.ItemsExporterUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ProductCarouselModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/productcarousel", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })

public class ProductCarouselModelImpl extends BaseComponentModelImpl  implements ProductCarouselModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProductCarouselModelImpl.class);


	@Inject
	private Resource resource;
	@Self
	private SlingHttpServletRequest request;

	@Inject
	private SlingModelFilter slingModelFilter;

	@Inject
	private ModelFactory modelFactory;

	@ValueMapValue
	private String carouselalignment;

	@ValueMapValue
	private String headertext;

	@ValueMapValue
	private String headersubtitle;

	@ValueMapValue
	private String ctatext;

	@ValueMapValue
	private String ctalink;

	@ValueMapValue
	private String ctatarget;
	
	@ValueMapValue
	private String showTimer;

	@ValueMapValue
	private String selectedTimerPosition;

	@ValueMapValue
	private String ctaalttext;

	@ValueMapValue
	private String ctacolor;

	@ValueMapValue
	private String doNotFollow;
	
	@ValueMapValue
	private String textImage;
	
	@ValueMapValue
	private String textImageAltText;
	
	@ValueMapValue
	private String overlayImage;
	
	@ValueMapValue
	private String overlayImageAltText;
	
	@ValueMapValue
	private String mobileVersion;

	private String carouselType;
	public String getCarouselType() {
		carouselType = (String) Objects.requireNonNull(resource.getChild("carouselContainer")).getValueMap().get("type");
		return carouselType;
	}
	/**
	 * <p>
	 * Calls getNoFollow method of ApplicationUtil to get follow, no-follow value.
	 * 
	 * @param link - The authored link.
	 */
	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering: initModel method of ProductCarouselModelImpl");
		super.initModel();		
			if (doNotFollow != null) {
				doNotFollow = ApplicationUtil.getNoFollow(doNotFollow);
			} else {
				doNotFollow = ApplicationUtil.getNoFollow(null); }
			LOGGER.debug("Exiting: initModel method of ProductCarouselModelImpl");
		
	}

	/**
	 * <p>
	 * Method to return the exported type
	 * 
	 * @return String exportedType
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Method to return the export child items
	 * 
	 * @return Map<String, ? extends ComponentExporter>
	 */
	@Override
	public Map<String, ? extends ComponentExporter> getItems() {
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}

	/**
	 * <p>
	 * Method to return carousel alignment
	 * 
	 * @return String carouselalignment
	 */
	@Override
	public String getCarouselAlignment() {
		return carouselalignment;
	}

	/**
	 * <p>
	 * Method to return header text
	 * 
	 * @return String headertext
	 */
	@Override
	public String getHeaderText() {
		return headertext;
	}

	/**
	 * <p>
	 * Method to return header subtitle
	 * 
	 * @return Stirng headersubtitle
	 */
	@Override
	public String getHeaderSubtitle() {
		return headersubtitle;
	}

	/**
	 * <p>
	 * Method to return cta text
	 * 
	 * @return String ctatext
	 */
	@Override
	public String getCtaText() {

		return ctatext;
	}

	/**
	 * <p>
	 * Method to return cta link
	 * 
	 * @return String ctalink
	 */
	@Override
	public String getCtaLink() {
		return ApplicationUtil.getShortUrl(request.getResourceResolver(), ctalink);
	}

	/**
	 * <p>
	 * Method to return cta target
	 * 
	 * @return String ctatarget
	 */
	@Override
	public String getCtaTarget() {

		return ctatarget;
	}
	
	/**
	 * <p>
	 * Method to return showTimer
	 * 
	 * @return String showTimer
	 */
	@Override
	public String getShowTimer() {

		return showTimer;
	}

	/**
	 * 
	 * Method to return selected timer position
	 * 
	 * @return String selectedTimerPosition
	 */
	@Override
	public String getSelectedTimerPosition() {
		return selectedTimerPosition;
	}

	/**
	 * <p>
	 * Method to return cta alt text
	 * 
	 * @return String ctaalttext
	 */
	@Override
	public String getCtaAltText() {
		if (ctaalttext != null && !ctaalttext.equals(""))
			return ctaalttext;
		else
			return ctatext;

	}

	/**
	 * <p>
	 * Method to return do Not Follow link
	 * 
	 * @return String doNotFollow
	 */
	@Override
	public String getDoNotFollow() {
		return doNotFollow;
	}
	
	/**
	 * <p>
	 * Method to return text image path
	 * 
	 * @return String textImage
	 */
	@Override
	public String getTextImage() {
		return textImage;
	}
	
	/**
	 * <p>
	 * Method to return text image alt text
	 * 
	 * @return String textImageAltText
	 */
	@Override
	public String getTextImageAltText() {
		return textImageAltText;
	}
	
	/**
	 * <p>
	 * Method to return do overlay image path
	 * 
	 * @return String overlayImage
	 */
	@Override
	public String getOverlayImage() {
		return overlayImage;
	}
	
	/**
	 * <p>
	 * Method to return do overlay image alt text
	 * 
	 * @return String overlayImageAltText
	 */
	@Override
	public String getOverlayImageAltText() {
		return overlayImageAltText;
	}
	
	/**
	 * <p>Returns the data mode</p>
	 * 
	 * @return String - dataMode
	 */
	@Override
	public String getDataMode() {
		return this.mobileVersion;
	}
	/**
	 * <p>Returns the breakpoint for website from Dynamic media config</p>
	 * 
	 * @return String - breakpoints
	 */
	@Override
	public String getImageProfileBreakpoints() {
		String path = this.textImage;
		String breakPoints = "";
		if("bgsmartcrop".equals(this.getDataMode())) {
			breakPoints = DynamicMediaUtils.getImageProfileBreakpoints(path, request.getResourceResolver());
		}
		return breakPoints;
	}
	
	@Override
	public String getMobileMediaImagePath() {
		String path = DynamicMediaUtils.getMobileDMPath(this.textImage, request.getResourceResolver());
		if(!"mobileimage".equals(this.mobileVersion)) {
			path = "";
		}
		return path;
	}

}
