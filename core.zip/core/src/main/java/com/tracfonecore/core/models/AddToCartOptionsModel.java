/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.AddToCartOptBean;

/**
 * Defines the {@code Column-Control} Sling Model used for the {@code /apps/tracfone-core/components/commerce/cartoptions} component.
 */
public interface AddToCartOptionsModel extends ComponentExporter {
		
	/**
	 * <p>Fetches category type of the product</p>
	 * 
	 * @return String - category type of the product
	 */
	@JsonProperty("categoryType")
	public String getCategoryType();
	
	/**
	 * <p>Fetches CTA text of Add to cart button</p>
	 * 
	 * @return String - CTA text of Add to cart button
	 */
	@JsonProperty("ctaText")
	public String getCtaText();
	
	/**
	 * <p>Fetches CTA Alt-text of Add to cart button</p>
	 * 
	 * @return String - CTA Alt-text of Add to cart button
	 */
	@JsonProperty("ctaAltText")
	public String getCtaAltText();
	
	/**
	 * <p>Fetches CTA link of Add to cart button</p>
	 * 
	 * @return String - CTA link of Add to cart button
	 */
	@JsonProperty("ctaLink")
	public String getCtaLink();
	
	/**
	 * <p>Fetches heading text of add to cart section</p>
	 * 
	 * @return String - heading text of add to cart section
	 */
	@JsonProperty("heading")
	public String getHeading() ;

	/**
	 * <p>Fetches disclaimer text of add to cart section</p>
	 * 
	 * @return String - disclaimer text of add to cart section
	 */
	@JsonProperty("disclaimer")
	public String getDisclaimer() ;
	
	/**
	 * <p>Fetches footnote text of add to cart section</p>
	 * 
	 * @return String -  footnote text of add to cart section
	 */
	@JsonProperty("footnote")
	public String getFootNote() ;
	
	/**
	 * <p>Fetches add to cart options list</p>
	 * 
	 * @return String - list of add to cart options
	 */
	@JsonProperty("cartOption")
	public List<AddToCartOptBean> getCartOpt() ;
	
	/**
	 * <p>Fetches add to cart options list</p>
	 * 
	 * @return String - list of add to cart options
	 */
	@JsonProperty("modalheading")
	public String getModalHeading() ;
	
	/**
	 * <p>Fetches add to cart options list</p>
	 * 
	 * @return String - list of add to cart options
	 */
	@JsonProperty("modallabel")
	public String getModalLabel() ;
	
	/**
	 * <p>Fetches add to cart options list</p>
	 * 
	 * @return String - list of add to cart options
	 */
	@JsonProperty("modalctatext")
	public String getModalCtaText() ;
	
	/**
	 * <p>Fetches add to cart options list</p>
	 * 
	 * @return String - list of add to cart options
	 */
	@JsonProperty("modalctaalttext")
	public String getModalCtaAltText() ;
	
	/**
	 * <p>Fetches add to cart options list</p>
	 * 
	 * @return String - list of add to cart options
	 */
	@JsonProperty("modalctalink")
	public String getModalCtaLink() ;
	
	/**
	 * <p>Fetches add to cart options list</p>
	 * 
	 * @return String - list of add to cart options
	 */
	@JsonProperty("modalctafootertext")
	public String getModalFooterText() ;
	
	/**
	 * <p>Fetches add to cart options list</p>
	 * 
	 * @return String - list of add to cart options
	 */
	@JsonProperty("donotfollowmodallink")
	public String getDonotfollowmodallink();

	/**
	 *<p>Fetches showStepsNumber</p>
	 *
	 * @return the showStepsNumber
	 */
	public String getShowStepsNumber();

	/**
	 *<p>Fetches logoLink</p>
	 *
	 * @return the logoLink
	 */
	@JsonProperty("logoLink")
	public String getLogoLink() ;
	/**
	 *<p>Fetches logoAltText</p>
	 *
	 * @return the logoAltText
	 */
	@JsonProperty("logoAltText")
	public String getLogoAltText() ;
	/**
	 *<p>Fetches logoSubtext</p>
	 *
	 * @return the logoSubtext
	 */
	@JsonProperty("logoAltText")
	public String getLogoSubtext() ;

	/**
	 *<p>Fetches preOrderCtaText</p>
	 *
	 * @return the preOrderCtaText
	 */
	@JsonProperty("preOrderCtaText")
	public String getPreOrderCtaText() ;

	public String getEmiOrderType();

	public String[] getPurchaseFlow();

	public String getMarketIdQueryString();

	public String getUpgradeElgQueryString();

	public String getMarketingIdApiPath();

	public String getUpgradeApiPath();

	public String getApiDomain();

	public String getDeviceTypeParam();

	public String getPortInMinSetApiPath();

	public String getPortInMinEligibilityApiPath();

	public String getPortInMinOtpValidateApiPath();

	/**
	 *<p>Fetches planType</p>
	 *
	 * @return the planType
	 */
	public String getPlanType();

	/**
	 *<p>Fetches card quantity</p>
	 *
	 * @return the card quantity
	 */
	public List<Integer> getTotalItemsList();

	/**
	 *<p>Fetches headingHelpText</p>
	 *
	 * @return the headingHelpText
	 */
	@JsonProperty("headingHelpText")
	public String getHeadingHelpText();
	
	/**
	 *<p>Fetches headingHelpTextAccessibilityLabel</p>
	 *
	 * @return the headingHelpTextAccessibilityLabel
	 */
	@JsonProperty("headingHelpTextAccessibilityLabel")
	public String getHeadingHelpTextAccessibilityLabel();

	/**
	 * <p>Fetches card quantity</p>
	 *
	 * @return the card quantity
	 */
	public int getGlobalCallingCardQuantity();
	/**
	 *<p>Fetches ctaDisableText</p>
	 *
	 * @return the ctaDisableText
	 */
	@JsonProperty("ctaDisableText")
	public String getCtaDisableText();

	/**
	 * @return the offerHppTrueFacet
	 */
	public String getOfferHppTrueFacet();

	/**
	 * <p>Fetches loginNotificationModalTitle</p>
	 * 
	 * @return the loginNotificationModalTitle
	 */
	@JsonProperty("loginNotificationModalTitle")
	public String getLoginNotificationModalTitle();

	/**
	 * <p>Fetches loginNotificationModalSummary</p>
	 * 
	 * @return the loginNotificationModalSummary
	 */
	@JsonProperty("loginNotificationModalSummary")
	public String getLoginNotificationModalSummary();

	/**
	 * <p>Fetches loginNotificationModalCta1Label</p>
	 * 
	 * @return the loginNotificationModalCta1Label
	 */
	@JsonProperty("loginNotificationModalCta1Label")
	public String getLoginNotificationModalCta1Label();

	/**
	 * <p>Fetches loginNotificationModalCta2Label</p>
	 * 
	 * @return the loginNotificationModalCta2Label
	 */
	@JsonProperty("loginNotificationModalCta2Label")
	public String getLoginNotificationModalCta2Label();
	
	/**
	 * @return the config value for disableCartOptionsRadio
	 */
	public String getDisableCartOptionsRadio();

    /**
	 * @return the config value for useIncrementalQuantity
	 */
	public String getUseIncrementalQuantity();
	
	/**
	 * <p>Fetches noRefillDisclaimer text of add to cart section</p>
	 * 
	 * @return String -  noRefillDisclaimer text of add to cart section
	 */
	@JsonProperty("noRefillDisclaimer")
	public String getNoRefillDisclaimer() ;

	/**
	 * <p>
	 * Fetches privacy Policy Disclaimer text of add to cart section
	 * </p>
	 * 
	 * @return String - privacy Policy Disclaimer text of add to cart section
	 */
	@JsonProperty("privacyPolicyDisclaimer")
	public String getPrivacyPolicyDisclaimer();

	/**
	 * <p>Enable Total Wireless Protection Plan/p>
	 * 
	 * @return boolean - Enable Protection plan
	 */
	@JsonProperty("enableTWP")
	public boolean isEnableTWP();
}
