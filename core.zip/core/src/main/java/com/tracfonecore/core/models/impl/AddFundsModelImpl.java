package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.AddFundsModel;
import com.tracfonecore.core.models.KeyValuePairModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.BrandSpecificConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Model(adaptables = {SlingHttpServletRequest.class, Resource.class}, adapters = {AddFundsModel.class,
        ComponentExporter.class}, resourceType = "tracfone-core/components/commerce/addfunds", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true")})
public class AddFundsModelImpl extends BaseComponentModelImpl implements AddFundsModel {

    @Self
    private SlingHttpServletRequest request;

    @Inject
    private ApplicationConfigService applicationConfigService;

    @Inject
    BrandSpecificConfigService brandSpecificConfigService;

    @Inject
    private Page currentPage;

    @Inject
    private Resource resource;

    @ChildResource
    private List<KeyValuePairModel> authTextList;
    @ChildResource
    private List<KeyValuePairModel> authRichTextList;

    private String brand;

    private Map<String, Object> propertyValueMap;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String title;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String description;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String makePaymentChoiceLabel;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String useCCLabel;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String usePINLabel;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String addFundsInputMaxValue;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String addFundsInputMinValue;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String enterAmountLabel;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String addFundsBgImagePath;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String addFundsBgImageAltText;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String addFundsBgMobileImagePath;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String addFundsBgColor;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String enableEstimateCall;

    @ValueMapValue
    private String processPinPagePath;

    @ValueMapValue
    private String addFundsThumbnailImage;

    @ValueMapValue
    private String sharedPlanPastDueDisclaimer;

    @ValueMapValue
    private String commonPastDueDisclaimer;

    @ValueMapValue
    private String sharedPlanPastDueDisclaimerLoggedIn;

    private static final Logger LOGGER = LoggerFactory.getLogger(AddFundsModelImpl.class);

    @PostConstruct
    protected void initModel() {
        LOGGER.debug("Entering initModel method");
        super.initModel();
        String[] properties = {CommerceConstants.BRANDNAME};
        this.propertyValueMap = CommerceUtil.getMultiplePagePropertyValue(currentPage, getHomePageLevel(), properties);
        this.brand = CommerceUtil.getPropertyValue(this.propertyValueMap, CommerceConstants.BRANDNAME);
    }


    /**
     * @return String - exported Type
     */
    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

    private int getHomePageLevel() {
        return applicationConfigService.getHomePageLevel();
    }

    @Override
    public String getTitle() {
        return title;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public String getEnableEstimateCall(){
        return enableEstimateCall;
    }

    @Override
    public String getMakePaymentChoiceLabel() {
        return makePaymentChoiceLabel;
    }

    @Override
    public String getUseCCLabel() {
        return useCCLabel;
    }

    @Override
    public String getUsePINLabel() {
        return usePINLabel;
    }
    @Override
    public String getProcessPinPagePath() {
        return ApplicationUtil.getShortUrl(resource.getResourceResolver(), this.processPinPagePath);
    }

    @Override
    public String getAddFundsInputMaxValue() {
        return addFundsInputMaxValue;
    }
  @Override
    public String getAddFundsInputMinValue() {
        return addFundsInputMinValue;
    }

    @Override
    public String getEnterAmountLabel() {
        return enterAmountLabel;
    }

    @Override
    public String getAddFundsBgImagePath() {
        return DynamicMediaUtils.changeMediaPathToDMPath(addFundsBgImagePath, request.getResourceResolver());
    }

    @Override
    public String getAddFundsBgImageAltText() {
        return addFundsBgImageAltText;
    }

    @Override
    public String getAddFundsBgMobileImagePath() {
        return DynamicMediaUtils.changeMediaPathToDMPath(addFundsBgMobileImagePath, request.getResourceResolver());
    }

    @Override
    public String getAddFundsBgColor() {
        return addFundsBgColor;
    }

    @Override
    public String getAddFundsThumbnailImage() {
        return addFundsThumbnailImage;
    }


    @Override
    public String getSharedPlanPastDueDisclaimer() {
        return sharedPlanPastDueDisclaimer;
    }

    @Override
    public String getCommonPastDueDisclaimer() {
        return commonPastDueDisclaimer;
    } @Override

    public String getSharedPlanPastDueDisclaimerLoggedIn() {
        return sharedPlanPastDueDisclaimerLoggedIn;
    }

    private List<KeyValuePairModel> getConstructList(List<KeyValuePairModel> textList, List<KeyValuePairModel> richTextList) {
        List<KeyValuePairModel> listText = Optional.ofNullable(textList)
                .map(List::stream).orElseGet(Stream::empty).collect(Collectors.toList());
        List<KeyValuePairModel> listRichText = Optional.ofNullable(richTextList)
                .map(List::stream).orElseGet(Stream::empty).collect(Collectors.toList());
        listText.addAll(listRichText);
        return new ArrayList<>(listText);
    }


    @Override
    public List<KeyValuePairModel> getAuthData() {
        return getConstructList(authTextList, authRichTextList);
    }

}
