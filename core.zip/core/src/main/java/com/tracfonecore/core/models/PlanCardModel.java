/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.PhoneSpecsBean;
import com.tracfonecore.core.beans.OtherSpecsPDPBean;

/**
 * Defines the {@code PlanCardModel} Sling Model used for the
 * {@code /apps/tracfone-core/components/commerce/plancard} component.
 */

public interface PlanCardModel extends ComponentExporter {

	/**
	 * Get the brand to which the product belongs (i.e. "STRAIGHT_TALK")
	 * 
	 * @return Brand
	 */
	public String getBrand();

	/**
	 * Get ratings of the product(i.e. "0 to 5")
	 * 
	 * @return Ratings
	 */
	public String getRating();

	/**
	 * <p>
	 * Format rating and remove trailing zeros
	 * </p>
	 * 
	 * @return String - rating without trailing zero
	 * 
	 */
	public String getAccessibilityRating();

	/**
	 * Get reviews of the product
	 * 
	 * @return Reviews
	 */
	public String getReviews();

	/**
	 * Get the make to which the product belongs (e.g. "APPLE")
	 * 
	 * @return make
	 */
	public String getMake();

	/**
	 * Get the plan data for the product belongs (e.g. "25GB")
	 * 
	 * @return planData
	 */
	public String getPlanData();

	/**
	 * Get the plan talk minutes for the product belongs (e.g. "1500 minutes")
	 * 
	 * @return planTalkMinutes
	 */
	public String getPlanTalkMinutes();

	/**
	 * <p>
	 * Fetches selection of the product
	 * </p>
	 * 
	 * @return String - selection of the product
	 */
	@JsonProperty("selection")
	public String getSelection();

	/**
	 * <p>
	 * Fetches promotext of the product
	 * </p>
	 * 
	 * @return String - promotext
	 */
	@JsonProperty("promotext")
	public String getPromoText();

	/**
	 * <p>
	 * Fetches promotext of the product
	 * </p>
	 * 
	 * @return String - promotext
	 */
	@JsonProperty("alternatePromotext")
	public String getAlternatePromotext();

	/**
	 * <p>
	 * Fetches churninfo of the product
	 * </p>
	 * 
	 * @return String - promotext
	 */
	@JsonProperty("churnInfo")
	public String getChurnInfo();

	/**
     * <p>
     * Fetches promo additional text for the product
     * </p>
     *
     * @return String - promoadditionaltext
     */
    @JsonProperty("promoadditionaltext")
    public String getPromoAdditionalText();

	/**
	 * <p>
	 * Fetches plan name for the product
	 * </p>
	 * 
	 * @return String - planname
	 */
	@JsonProperty("planname")
	public String getPlanName();

	/**
	 * <p>
	 * Check to hide rating and reviews
	 * </p>
	 * 
	 * @return String - promotext
	 */
	@JsonProperty("hideRating")
	public Boolean getHideRating();

	/**
	 * <p>
	 * Check to hide  Bazaar Voice Ratings
	 * </p>
	 * 
	 * @return String - disableBazaarVoiceRatings
	 */
	@JsonProperty("disableBazaarVoiceRatings")
	public Boolean getDisableBazaarVoiceRatings();

	/**
	 * <p>
	 * Fetches price superscript for the product
	 * </p>
	 * 
	 * @return String - pricesuperscript
	 */
	@JsonProperty("pricesuperscript")
	public String getPriceSuperscript();

	/**
	 * <p>
	 * Fetches price description for the product
	 * </p>
	 * 
	 * @return String - pricedescription
	 */
	@JsonProperty("pricedescription")
	public String getPriceDescription();

	/**
	 * <p>
	 * Fetches acp discounted ar price description for the product
	 * </p>
	 * 
	 * @return String - acpDiscountedArDescription
	 */
	@JsonProperty("acpDiscountedArDescription")
	public String getAcpDiscountedArDescription();

	/**
	 * <p>
	 * Fetches acp discounted ar accessibility price description for the product
	 * </p>
	 * 
	 * @return String - acpDiscountedArAccsDescription
	 */
	@JsonProperty("acpDiscountedArAccsDescription")
	public String getAcpDiscountedArAccsDescription();

	/**
	 * <p>
	 * Fetches plan data label for the product
	 * </p>
	 * 
	 * @return String - plandatalabel
	 */
	@JsonProperty("plandatalabel")
	public String getPlanDataLabel();

	/**
	 * <p>
	 * Fetches plan data description for the product
	 * </p>
	 * 
	 * @return String - plandatadescription
	 */
	@JsonProperty("plandatadescription")
	public String getPlanDataDescription();

	/**
	 * <p>
	 * Fetches plan thumbnail image for the product
	 * </p>
	 *
	 * @return String - planthumbnailimage
	 */
	@JsonProperty("planthumbnailimage")
	public String getPlanthumbnailimage();



	/**
	 * <p>
	 * Fetches plan thumbnail image for the product
	 * </p>
	 *
	 * @return String - planthumbnailimage
	 */
	@JsonProperty("tabletPlanIcon")
	public String getTabletPlanIcon();

	/**
	 * <p>
	 * Fetches plan service days for the product
	 * </p>
	 *
	 * @return String - planservicedays
	 */
	@JsonProperty("planservicedays")
	public String getPlanservicedays();

	/**
	 * <p>
	 * Fetches queryString for the price api call
	 * </p>
	 * 
	 * @return String - queryString
	 */
	@JsonProperty("queryString")
	String getQueryString();

	/**
	 * <p>
	 * Method to return Price Api domain
	 * </p>
	 * 
	 * @return String
	 */
	public String getApiDomain();

	/**
	 * <p>
	 * Method to return Price Api Path
	 * </p>
	 * 
	 * @return String
	 */
	public String getPriceApiPath();

	/**
	 * <p>
	 * Method to return exporter type
	 * </p>
	 * 
	 * @return String
	 */
	@Override
	public String getExportedType();

	/**
	 * <p>
	 * Fetches queryString for the price api call
	 * </p>
	 *
	 * @return String - isGlobalCalling
	 */
	@JsonProperty("isGlobalCalling")
	public Boolean getIsGlobalCalling();

	/**
	 * <p>
	 * Fetches value of paypal pay checkbox value
	 * </p>
	 *
	 * @return Boolean - disablePaypalOption
	 */
	@JsonProperty("disablePaypalOption")
	public Boolean getDisablePaypalOption();

	/**
	 * <p>
	 * Fetches value of hide plan checkbox value
	 * </p>
	 *
	 * @return Boolean - hidePlanInSimPlp
	 */
	@JsonProperty("hidePlanInSimPlp")
	public Boolean getHidePlanInSimPlp();

	/**
	 * <p>
	 * Fetches planCategory for the product offering - bypart number api call
	 * </p>
	 *
	 * @return String - planCategory
	 */
	@JsonProperty("planCategory")
	public String getPlanCategory();

	/**
	 * <p>
	 * Fetches the plan purchase types from product offering - bypart number api
	 * response
	 * </p>
	 *
	 * @return String - planPurchaseType
	 */
	@JsonProperty("planPurchaseType")
	public String getPlanPurchaseType();

	/**
	 * <p>
	 * Fetches the inventoryApiPath
	 * </p>
	 *
	 * @return String - inventoryApiPath
	 */
	@JsonProperty("inventoryApiPath")
	public String getInventoryApiPath();

	/**
	 * <p>
	 * Fetches the inventoryQueryString
	 * </p>
	 *
	 * @return String - inventoryQueryString
	 */
	@JsonProperty("inventoryQueryString")
	public String getInventoryQueryString();

	/**
	 * <p>
	 * Fetches the planServiceDaysLabel
	 * </p>
	 *
	 * @return String - planServiceDaysLabel
	 */
	@JsonProperty("planServiceDaysLabel")
	default String getPlanServiceDaysLabel() {
		return null;
	}

	/**
	 * <p>
	 * Fetches the serviceDaysPopoverText
	 * </p>
	 *
	 * @return String - serviceDaysPopoverText
	 */
	@JsonProperty("serviceDaysPopoverText")
	default String getServiceDaysPopoverText() {
		return null;
	}

	/**
	 * <p>
	 * Fetches the planMinutesLabel
	 * </p>
	 *
	 * @return String - planMinutesLabel
	 */
	@JsonProperty("planMinutesLabel")
	default String getPlanMinutesLabel() {
		return null;
	}

	/**
	 * <p>
	 * Fetches the planTextLabel
	 * </p>
	 *
	 * @return String - planTextLabel
	 */
	@JsonProperty("planTextLabel")
	default String getPlanTextLabel() {
		return null;
	}

	/**
	 * <p>
	 * Fetches the planTextLabel
	 * </p>
	 *
	 * @return String - planTextLabel
	 */
	@JsonProperty("planDataLabel")
	default String getPlanDataTextLabel() {
		return null;
	}

	/**
	 * <p>
	 * Fetches the cantentryId
	 * </p>
	 *
	 * @return String - cantentryId
	 */
	@JsonProperty("cantentryId")
	public String getCantentryId();

	/**
	 * <p>
	 * Fetches the autoRefillId
	 * </p>
	 *
	 * @return String - autoRefillId
	 */
	@JsonProperty("autoRefillId")
	public String getAutoRefillId();

	/**
	 * <p>
	 * Fetches the autoRefillPrice
	 * </p>
	 *
	 * @return String - autoRefillPrice
	 */
	@JsonProperty("autoRefillPrice")
	public String getAutoRefillPrice();

	/**
	 * <p>
	 * Fetches the skuId
	 * </p>
	 *
	 * @return String - skuId
	 */
	@JsonProperty("skuId")
	public String getSkuId();

	/**
	 * <p>
	 * Fetches the thumbnailImageAssetId
	 * </p>
	 *
	 * @return String - thumbnailImageAssetId
	 */
	@JsonProperty("thumbnailImageAssetId")
	public String getThumbnailImageAssetId();

	/**
	 * <p>
	 * Fetches the thumbnailImageAssetAgencyId
	 * </p>
	 *
	 * @return String - thumbnailImageAssetAgencyId
	 */
	@JsonProperty("thumbnailImageAssetAgencyId")
	public String getThumbnailImageAssetAgencyId();

	/**
	 * <p>
	 * Fetches the allPlanType
	 * </p>
	 *
	 * @return String - allPlanType
	 */
	@JsonProperty("allPlanType")
	public String getAllPlanType();

	/**
	 * <p>
	 * Fetches the flowAsPerDeviceType
	 * </p>
	 *
	 * @return String - flowAsPerDeviceType
	 */
	@JsonProperty("flowAsPerDeviceType")
	public String getFlowAsPerDeviceType();

	/**
	 * <p>
	 * Fetches the extendedPlanEligibility
	 * </p>
	 *
	 * @return String - extendedPlanEligibility
	 */
	@JsonProperty("extendedPlanEligibility")
	public String getExtendedPlanEligibility();

	/**
	 * <p>
	 * Fetches the offerSmartPay
	 * </p>
	 *
	 * @return String - offerSmartPay
	 */
	@JsonProperty("offerSmartPay")
	public String getOfferSmartPay();

	/**
	 * <p>
	 * Fetches the offerHPPPlan
	 * </p>
	 *
	 * @return String - offerHPPPlan
	 */
	@JsonProperty("offerHPPPlan")
	public String getOfferHPPPlan();

	/**
	 * <p>
	 * Fetches the allowGuestCheckout
	 * </p>
	 *
	 * @return String - allowGuestCheckout
	 */
	@JsonProperty("allowGuestCheckout")
	public String getAllowGuestCheckout();

	/**
	 * <p>
	 * Fetches the marketingIds
	 * </p>
	 *
	 * @return String - marketingIds
	 */
	@JsonProperty("marketingIds")
	public String getMarketingIds();

	/**
	 * <p>
	 * Fetches the defaultFallbackThumbnailImage
	 * </p>
	 *
	 * @return String - defaultFallbackThumbnailImage
	 */
	@JsonProperty("defaultFallbackThumbnailImage")
	public String getDefaultFallbackThumbnailImage();

	/**
	 * <p>
	 * Fetches the planCardModel
	 * </p>
	 *
	 * @return PlanCardModel - planCardModel
	 */
	@JsonProperty("planCardModel")
	PlanCardModel getPlanCardModel();

	/**
	 * <p>
	 * Fetches the type
	 * </p>
	 *
	 * @return String - type
	 */
	@JsonProperty("type")
	String getType();

	/**
	 * Fetches the autoRefillPriceFormatted
	 * </p>
	 *
	 * @return String - autoRefillPriceFormatted
	 */
	@JsonProperty("autoRefillPriceFormatted")
	public String getAutoRefillPriceFormatted();

	/**
	 * <p>
	 * Fetches the language
	 * </p>
	 *
	 * @return String - language
	 */
	public String getLanguage();

	/**
	 * <p>
	 * Fetches the planText
	 * </p>
	 *
	 * @return String - planText
	 */
	@JsonProperty("planText")
	default String getPlanText() {
		return null;
	}

	/**
	 * <p>
	 * Fetches the planServiceDaysApi
	 * </p>
	 *
	 * @return String - planServiceDaysApi
	 */
	@JsonProperty("planServiceDaysApi")
	default String getPlanServiceDaysApi() {
		return null;
	}

	/**
	 * <p>
	 * Fetches the planPurchasePoints
	 * </p>
	 *
	 * @return String - planPurchasePoints
	 */
	@JsonProperty("planPurchasePoints")
	default String getPlanPurchasePoints() {
		return null;
	}

	/**
	 * <p>
	 * Fetches the planEarnPoints
	 * </p>
	 *
	 * @return String - planEarnPoints
	 */
	@JsonProperty("planEarnPoints")
	default String getPlanEarnPoints() {
		return null;
	}

	/**
	 * <p>
	 * Fetches the data
	 * </p>
	 *
	 * @return String - data
	 */
	@JsonProperty("data")
	default String getData() {
		return null;
	}

	/**
	 * <p>
	 * Fetches the minutes
	 * </p>
	 *
	 * @return String - minutes
	 */
	@JsonProperty("minutes")
	default String getMinutes() {
		return null;
	}

	/**
	 * <p>
	 * Returns name post converting to lower case from API response
	 * </p>
	 * 
	 * @return String - productNameForAnalytics
	 */
	@JsonProperty("productNameForAnalytics")
	public String getProductNameForAnalytics();

	/**
	 * <p>
	 * Returns product type
	 * </p>
	 * 
	 * @return String - productType
	 */
	@JsonProperty("productType")
	default String getProductType(){
		return null;
	}

	/**
	 * <p>
	 * Fetches productCardHeading
	 * </p>
	 *
	 * @return the productCardHeading
	 */
	default String getProductCardHeading() {
		return null;
	}

	/**
	 * <p>
	 * Fetches productCardDescription
	 * </p>
	 *
	 * @return the productCardDescription
	 */
	default String getProductCardDescription() {
		return null;
	}

	/**
	 * <p>
	 * Method to return buyNowRewardsHelpText
	 * </p>
	 *
	 * @return the buyNowRewardsHelpText
	 */
	default String getBuyNowRewardsHelpText() {
		return null;
	}

	/**
	 * <p>
	 * Method to return ctaLink
	 * </p>
	 *
	 * @return the ctaLink
	 */
	@JsonProperty("ctaLink")
	default String getCtaLink() {
		return null;
	}

	/**
	 * Checks if the plan card is first in carousel then return animation timing.
	 * 
	 * @return String - animation value
	 */
	public String getAnimationValue();

	/**
	 * <p>
	 * Method to check plan name value
	 * </p>
	 */
	default String getPlanNameValue() {
		return null;
	}

	/**
	 * <p>
	 * Returns Device Type mapping
	 * </p>
	 *
	 * @return String - devicesTypeMapping
	 */
	public List<String> getDevicesTypeMapping();
	
	/**
	 * @return the planCardButtonLabel
	 */
	default String  getPlanCardButtonLabel() {
		return null;
	}
	/**
	 * <p>
	 * Returns categoryApiPath from configuration
	 * </p>
	 *
	 * @return String - categoryApiPath
	 */
	public String getCategoryApiPath();

	/**
	 * String is used for part number API call
	 * @return String - fall back queryString
	 */
	public String getFallBackQueryString();

	/**
	 * <p>Fetches plan short description for the product</p>
	 * 
	 * @return String - planShortDescription
	 */
	@JsonProperty("planShortDescription")
	public String getPlanShortDescription();
	
	/**
	 * <p>Fetches plan short description for the product</p>
	 * 
	 * @return String - planShortDescription
	 */
	@JsonProperty("planDescription")
	public String getPlanDescription();

	/**
	 * @return the hidePlanThumbnailImage
	 */
	@JsonProperty("showPlanThumbnailImage")
	public String getShowPlanThumbnailImage();
	/**
	 * Get the cusg enabling check
	 *
	 * @return String - cusg enabling check
	 */
	public String getCusgEnable();
	/**
	 * <p>
	 * Method to return CUSG Logo
	 * </p>
	 *
	 * @return the CUSGLogo
	 */
	public String getCusgLogoUrl();

	/**
	 * <p>
	 * Method to return cusg promo text
	 * </p>
	 *
	 * @return the cusgPromoText
	 */
	public String getCusgPromoText();

	/**
	 * <p>
	 * Method to return cusg disclaimer text
	 * </p>
	 *
	 * @return the cusgDisclaimerText
	 */
	public String getCusgDisclaimerText();

	/**
	 * <p>
	 * Method to return cusg alt image text
	 * </p>
	 *
	 * @return the cusgImageAltText
	 */
	public String getCusgImgAltText();

	public String getName();

	public String getDescription();

	public String getInBuiltProtectionPlan();

	public default String getPlanDeviceType() {return null;}

	public default List<PhoneSpecsBean> getSingleBucketSpecsList() {return null;}

	public default String getThresholdUnit() {return null;}

	public default String getThresholdLabel() {return null;}

	public default String getSbThresholdValue() {return null;}

	public default String getSbThresholdUnit() {return null;}

	public default String getGlobalCardTitle() {return null;}

	public default String getDataCarryForwardDescription() {return null;}

	public default String getBenefitsCarryForward() {return null;}

	public default String getTextCarryForwardDescription() {return null;}

	public default String getVoiceCarryForwardDescription() {return null;}
	
	public default String getResourcePath() {return null;}
	
	public default String getAuthorPath() {return null;}
	
	public default Boolean isUseNameForSpecs() {return null;}
	
	public default List<PhoneSpecsBean> getProductSpecs() {return null;}
	
	public default List<PhoneSpecsBean> getSelectedProductSpecs() {return null;}
	
	public default String getPlanEligibleForAutoRefill() {return null;}

	public default String getBillingPlanType() {return null;}
	
	public default String getAutoRefillDiscountLabel() {return null;}
	
	/**
	 * Fetches value of isVasBundlePlan
	 * @return Boolean - isVasBundlePlan
	 */
	@JsonProperty("isVasBundlePlan")
	public Boolean getIsVasBundlePlan();

	/**
	 * Fetches value of vasProductThumbnailImage
	 * @return Boolean - vasProductThumbnailImage
	 */
	@JsonProperty("vasProductThumbnailImage")
	public String getVasProductThumbnailImage();

	/**
	 * Fetches value of vasProdImgAccessibleText
	 * @return Boolean - vasProdImgAccessibleText
	 */
	@JsonProperty("vasProdImgAccessibleText")
	public String getVasProdImgAccessibleText();

	/**
	 * Fetches value of vasProdImgSubscript
	 * @return Boolean - vasProdImgSubscript
	 */
	@JsonProperty("vasProdImgSubscript")
	public String getVasProdImgSubscript();

	/**
	 * Fetches value of vasTermsContent
	 * @return Boolean - vasTermsContent
	 */
	@JsonProperty("vasTermsContent")
	public String getVasTermsContent();

	/**
	 * Fetches value of enableButtonForProductCards
	 * @return String - enableButtonForProductCards
	 */
	@JsonProperty("enableButtonForProductCards")
	public String getEnableButtonForProductCards();


	/**
	 * <p>
	 * Method to return AddLineRibbonText
	 * </p>
	 *
	 * @return the AddLineRibbonText
	 */
	public String getAddLineRibbonText();

	/**
	 * <p>
	 * Method to return AddLineAutoRefill
	 * </p>
	 *
	 * @return the AddLineAutoRefill
	 */
	public String getAddLineAutoRefill();

	/**
	 * <p>
	 * Method to return AddLineAutoRefillPrice
	 * </p>
	 *
	 * @return the AddLineAutoRefillPrice
	 */
	public String getAddLineAutoRefillPrice();

	/**
	 * <p>
	 * Fetches showMultiLineSelector
	 * </p>
	 *
	 * @return String - showMultiLineSelector
	 */
	public Boolean getShowMultiLineSelector();

	/**
	 * <p>
	 * Method to return Number of Lines List
	 * </p>
	 *
	 * @return String
	 */
	public List<Object> getNumberOfLinesList();

    /**
	 * <p>
	 * Fetches the multilineSubheading
	 * </p>
	 *
	 * @return String - multilineSubheading
	 */
	public String getMultilineSubheading();
	
	/**
	 * <p>
	 * Checks if it is a Plan PDP
	 * </p>
	 *
	 * @return boolean - isPlanPDPPage
	 */
	public String getPlanPDPPage();
	
	/**
	 * <p>
	 * Fetches the PromoColor
	 * </p>
	 *
	 * @return String - PromoColor
	 */
	@JsonProperty("promoColor")
	public String getPromoColor();
	
	/**
	 * <p>
	 * Fetches the ActivationPlanDescription
	 * </p>
	 *
	 * @return String - ActivationPlanDescription
	 */
	@JsonProperty("activationPlanDescription")
	public String getActivationPlanDescription();
	
	/**
	 * <p>
	 * Fetches the PerTimePeriod
	 * </p>
	 *
	 * @return String - PerTimePeriod
	 */
	@JsonProperty("perTimePeriod")
	public String getPerTimePeriod();
	
	/**
	 * <p>
	 * Fetches the SavePriceAccessibilityLabel
	 * </p>
	 *
	 * @return String - SavePriceAccessibilityLabel
	 */
	@JsonProperty("savePriceAccessibilityLabel")
	public String getSavePriceAccessibilityLabel();

	/**
	 * <p>
	 * Fetches the priceAccessibilityLabel
	 * </p>
	 *
	 * @return String - priceAccessibilityLabel
	 */
	@JsonProperty("priceAccessibilityLabel")
	public String getPriceAccessibilityLabel();

	/**
	 * <p>
	 * Fetches multilineDisclaimer value
	 * </p>
	 *
	 * @return String - multilineDisclaimer value
	 */
	public default String getMultilineDisclaimer() { return null; }

	/**
	 * <p>
	 * Fetches the showRecommendedPlan
	 * </p>
	 *
	 * @return String - showRecommendedPlan
	 */
	@JsonProperty("showRecommendedPlan")
	public default String getShowRecommendedPlan() { return null; }

	/**
	 * <p>
	 * Check to hide AutoRefill Text Under Price
	 * </p>
	 * 
	 * @return Boolean - True of False
	 */
	@JsonProperty("hideAutoRefillTextUnderPrice")
	public default Boolean getHideAutoRefillTextUnderPrice() {
		return null;
	}
	
	/**
	 * <p>
	 * Fetches the alternateDataUnitForPlanCard
	 * </p>
	 *
	 * @return String - alternateDataUnitForPlanCard
	 */
	@JsonProperty("alternateDataUnitForPlanCard")
	public default String getAlternateDataUnitForPlanCard() {
		return null;
	}

	/**
	 * <p>
	 * Fetches the multilinePlanSelection
	 * </p>
	 *
	 * @return String - multilinePlanSelection
	 */
	@JsonProperty("multilinePlanSelection")
	public default String getMultilinePlanSelection(){return null;}
	/**
	 * Fetches the taxInclusive
	 * </p>
	 *
	 * @return String - taxInclusive
	 */
	@JsonProperty("taxInclusive")
	public default String getTaxInclusive() {
		return null;
	}

	/**
	 * <p>
	 * Fetches the vasTooltipContent
	 * </p>
	 *
	 * @return String - vasTooltipContent
	 */
	@JsonProperty("vasTooltipContent")
	public default String getVasTooltipContent() {
		return null;
	}

	/**
	 * <p>
	 * Fetches the vasTerms
	 * </p>
	 *
	 * @return String - vasTerms
	 */
	@JsonProperty("vasTerms")
	public default String getVasTerms() {
		return null;
	}

	@JsonProperty("otherSpecsPDP")
	public default List<OtherSpecsPDPBean> getOtherSpecsPDP()  { return null;}

	@JsonProperty("planDisclaimer")
	public default String getPlanDisclaimer() { return null;}

	@JsonProperty("planNamePDP")
	public default String getPlanNamePDP()  { return null;}

	public Boolean getHidePlanCard();
}

