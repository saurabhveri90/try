package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Carousel} Sling Model used for the {@code /apps/tracfone-core/components/content/carouselbannerItem} component.
 */
public interface CarouselBannerModel extends ComponentExporter  {

	/**
	 * <p>Fetches label of the carousel</p>
	 *
	 * @return String - label of the carousel
	 */
	@JsonProperty("label")
	public String getLabel();

	/**
	 * <p>Fetches title of the carousel</p>
	 *
	 * @return String - title of the carousel
	 */
	@JsonProperty("title")
	public String getTitle();
	
	/**
	 * <p>Fetches summary of the carousel</p>
	 * 
	 * @return String - summary of the carousel
	 */
	@JsonProperty("summary")
	public String getSummary();
	
	/**
	 * <p>Fetches flag value to include disclaimer</p>
	 *
	 * @return String - includeInlineDisclaimer
	 */
	@JsonProperty("includeInlineDisclaimer")
	public String getIncludeInlineDisclaimer();


	/**
	 * <p>Fetches media type</p>
	 *
	 * @return String - media type
	 */
	@JsonProperty("mediaType")
	public String getMediaType();

	/**
	 * <p>Fetches Image path</p>
	 * 
	 * @return String - image path
	 */
	@JsonProperty("mediaPath")
	public String getMediaPath();
		
	/**
	 * <p>Fetches alt text for the image</p>
	 * 
	 * @return String - alt text for the image
	 */
	@JsonProperty("imageAltText")
	public String getImageAltText();

	/**
	 * <p>Fetches video thumbnail image</p>
	 *
	 * @return String - video thumbnail image
	 */
	@JsonProperty("videoThumbnailImage")
	public String getVideoThumbnailImage();
	
	/**
	 * <p>Fetches accessbility label</p>
	 * 
	 * @return String - accessbility label
	 */
	@JsonProperty("accessbilityLabel")
	public String getAccessbilityLabel();
	
	/**
	 * <p>Fetches no-follow for video link</p>
	 * 
	 * @return String - no-follow value
	 */
	@JsonProperty("noFollowVideo")
	public String getDoNotFollowVideo();
	
	/**
	 *  <p>
	 * Fetches aspect ratio value
	 * </p>
	 * 
	 * @return String - aspect ratio
	 */
	public String getAspectRatio();
	
	/**
	 *  <p>
	 * Fetches break points for the image
	 * </p> 
	 * 
	 * @return String - imageProfileBreakpoints
	 */
	public String getImageProfileBreakpoints();
	
	/**
	 *<p>Fetches data type for the video</p>
	 *
	 * @return String - videoDataType
	 */
	public String getVideoDataType();
	
	/**
	 *<p>Fetches the path for mobile thumbnail</p>
	 *
	 * @return String - mobile thumbnail image path
	 */
	public String getMobileThumbnailImagePath();
	
	/**
	 *<p>Fetches the path for mobile image path</p>
	 *
	 * @return String - mobile image path
	 */
	public String getMobileMediaImagePath();
	
	/**
	 *<p>Fetches the data mode</p>
	 *
	 * @return String - data mode
	 */
	public String getDataMode();

	/**
	 *<p>Fetches the media Alignment</p>
	 *
	 * @return String - media Alignment
	 */
	String getMediaAlignment();

	 /**
	 * <p>Fetches coverage search include flag</p>
	 *
	 * @return String - includeCoverageSearch
	 */
	 @JsonProperty("includeCoverageSearch")
	public String getIncludeCoverageSearch();

	/**
	 * <p>Fetches flag value to not use background image</p>
	 *
	 * @return String - doNotUseBackgroundImage
	 */
	 @JsonProperty("doNotUseBackgroundImage")
	public String getDoNotUseBackgroundImage();
	 
	 /**
	  * <p>
	  * Fetches show timer option
	  * </p>
	  * 
	  * @return String - Show Timer
	 */
	@JsonProperty("showTimer")
	public String getShowTimer();

	 /**
	  * <p>
	  * Fetches show label left border option
	  * </p>
	  * 
	  * @return String - Show Label Left Border
	 */
	@JsonProperty("showLabelLeftBorder")
	public String getShowLabelLeftBorder();

	/**
	 * <p>
	 * Fetches the flow type
	 * </p>
	 *
	 * @return String - Flow Type
	 */
	@JsonProperty("flowType")
	public String getFlowType();

	/**
	 * <p>
	 * Fetches the image logo
	 * </p>
	 *
	 * @return String - image
	 */
	@JsonProperty("logoImage")
	public String getLogoImage();

	/**
	 * <p>
	 * Fetches the display banner value
	 * </p>
	 *
	 * @return String - displayBanner
	 */
	@JsonProperty("displayBanner")
	public String getDisplayBanner();

	/**
	 * <p>Fetches alt text for the logo</p>
	 *
	 * @return String - alt text for the logo
	 */
	@JsonProperty("logoAltText")
	public String getLogoAltText();

	/**
	 * <p>
	 * Fetches order index
	 * </p>
	 * 
	 * @return String - Order Index
	 */
	@JsonProperty("orderIndex")
	public String getOrderIndex();
    	
	/**
	 *<p>Fetches Multilinks include flag</p>
	 *
	 * @return String - includeMultiLinks
	 */
	@JsonProperty("includeMultiLinks")
	public String getIncludeMultiLinks();

	/**
	 * <p>
	 * Fetches show title as H1
	 * </p>
	 * 
	 * @return String - Show title as H1
	*/
	@JsonProperty("showTitleAsH1")
	public String getShowTitleAsH1();

	/**
	 * <p>
	 * Fetches selected timer position
	 * </p>
	 * 
	 * @return String - selected Timer position
	*/
	@JsonProperty("selectedTimerPosition")
	public String getSelectedTimerPosition();

}
