package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.settings.SlingSettingsService;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.DeEnrollmentReasonsBean;
import com.tracfonecore.core.beans.ManageLinesBean;
import com.tracfonecore.core.beans.ManageLinesNotificationsBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.ManageLinesModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ManageLinesModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/managelines", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ManageLinesModelImpl implements ManageLinesModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;
	
	@Inject
	private SlingSettingsService settingService;

	@Inject
	private Resource resource;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String positionManageLines;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String positionAccountNavigation;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String legalCopyTextForManageLines;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String newDeviceOptionsSubHeading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String attemptsToSendVerificationCode;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addMergeLineOptionsHeading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addMergeLineOptionsSubHeading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addNewLineOptionsHeading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addNewLineOptionsSubHeading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addNewDeviceOptionsSubHeading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String mergeLineStep1Heading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String mergeLineStep1Subheading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String mergeLineStep2Heading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String mergeLineStep2Subheading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String resendCodeLinkLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String firstAttemptSendCodeMessage;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String secondAttemptSendCodeMessage;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addMergeLineSuccessHeading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addMergeLineSuccessSubheading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planInReserveHeading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planInReserveSubheading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String nextPlanStartDateHeading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String redeemPlanModalHeadline;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String redeemPlanModalSubheadline;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String removeDeviceModalHeadline;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String removeDeviceModalSubheadline;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String editNickNameModalHeadline;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String editNickNameModalSubheadline;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String categoryIdPlans;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addOnPlanCardInfoText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addOnPlanName;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addOnPlanData;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addOnPlanDataLabel;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addOnPlanPartNumber;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addOnPlanPrice;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addOnPlanImage;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planAutoRefillDefaultMessage;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addOnILDText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ildPlanName;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ildPlanPrice;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ildPlanPartNumber;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ildPlanEditCartUrl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planDetailsEditCartUrl;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String nextChargeDateILDText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String nextChargeDateILDValue;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String plansPlpPagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String plpPagePathHpp;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String titleRefillWithPinForPlan;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String paragraphRefillWithPinForPlan;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String titleRefillWithPinForILD;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String paragraphRefillWithPinForILD;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String titleCancelEnrollmentForPlan;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String paragraphCancelEnrollmentForPlan;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String titleCusgDiscountAlert;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String paragraphCusgDiscountAlert;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String titleCancelEnrollmentForILD;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String paragraphCancelEnrollmentForILD;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String tutorialsPagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String transactionsPagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String activationPagePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String deviceSupportPage;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String transactionHistoryDays;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String numberOfItemsOnSinglePage;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String numberOfPageDisplayed;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppEligibilityConfigDays;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppClaimsPage;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppClaimsPageAsurion;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppClaimsPageApple;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppNotEnrolledHeadline;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppNotEnrolledStatus;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String titleCancelEnrollmentForHPP;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String paragraphCancelEnrollmentForHPP;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String titleCancelEnrollmentSuccessForHPP;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String paragraphCancelEnrollmentSuccessForHPP;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String textHowDoesItWorkModal;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String titleBenefitChangesModalForILD;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subTitleBenefitChangesModalForILD;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String titleBenefitChangesModalForPlan;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subTitleBenefitChangesModalForPlan;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String titleBenefitChangesModalForReservePlans;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subTitleBenefitChangesModalForReservePlans;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String refillLandingPagePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String autoRefillHomePagePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String refillPLPPagePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String phonesPLPPagePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String refillPLPPageSelector;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String refillBuyNowPLPPageSelector;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String refillStartDateSelector;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String checkoutDetailComponentVersion;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planServiceEndDateInfoModalContent;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String amazonEnrollmentInfoModalContent;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String zipCodeUnderlyingText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String titleCancelEnrollmentAndRefundModal;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String paragraphCancelEnrollmentAndRefundModal;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addOnPlanEditCartUrl;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enableAmazonPrime;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String showWelcomeCenterForDesktop;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hideWelcomeCenter;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String welcomeCenterHeading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String welcomeCenterDescription;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String visitWelcomeCenterButton;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String visitWelcomeCenterButtonLink;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String openVisitLinkNewTabWindow;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String welcomeCenterImagePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String activationDateDifference;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String selectAutoRefillAndSaveMessage;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String categoryIdHpp;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String editGroupNameModalHeadline;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String editGroupNameModalSubheadline;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String temporaryProtectionPlanScript;
	
	@ValueMapValue
	private String globalCallingCardPDPPagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String plansPageAddOnSection;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enablePageLevel2FA;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String enableFccLabel;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String newTabWindowForFccLabelLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enableAddlineForDODevices;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String byopPinModal;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String byopRedeemPlanHeadline;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String byopRedeemPlanSubHeadline;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String byopPinModalDcot;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String byopRedeemPlanHeadlineDcot;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String byopRedeemPlanSubHeadlineDcot;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String toggleTextComponent;
	private String restartYourPhoneText;
	private String videoStreamingText;
	private String partNumberToogle;
		
	private List<ManageLinesBean> addMergeLineOptions = Collections.emptyList();
	private List<ManageLinesBean> addNewLineOptions = Collections.emptyList();

	private List<ManageLinesBean> addNewDeviceOptions = Collections.emptyList();
	private List<ManageLinesBean> planAutoRefillMessageMapping = Collections.emptyList();
	private List<ManageLinesBean> statusPendingTransactionList = Collections.emptyList();
	private List<ManageLinesNotificationsBean> notificationCards = Collections.emptyList();
	
	private List<ManageLinesBean> benefitChangeOptionsForPlan = Collections.emptyList();
	private List<ManageLinesBean> benefitChangeOptionsForILD = Collections.emptyList();
	private List<ManageLinesBean> benefitChangeOptionsForReservePlans = Collections.emptyList();
	private List<String> welcomeCenterPartClasses =  new ArrayList<String>();
	private List<DeEnrollmentReasonsBean> deEnrollmentReasons = Collections.emptyList();
	
	@PostConstruct
	private void initModel() {
		addMergeLineOptions = new ArrayList<>();
		addNewLineOptions = new ArrayList<>();
		addNewDeviceOptions = new ArrayList<>();
		planAutoRefillMessageMapping = new ArrayList<>();
		statusPendingTransactionList = new ArrayList<>();
		notificationCards= new ArrayList<>();
		benefitChangeOptionsForPlan = new ArrayList<>();
		benefitChangeOptionsForILD = new ArrayList<>();
		benefitChangeOptionsForReservePlans = new ArrayList<>();
		deEnrollmentReasons = new ArrayList<>();
		
		if (resource != null) {
			getMultifieldResource();
		}

		if(toggleTextComponent != null){
			//get the dasboard component
			Resource referenceComponente = resource.getResourceResolver().getResource(toggleTextComponent + "/jcr:content/root/responsivegrid/accountdashboard");
			if(referenceComponente != null){
				ValueMap valueMap = referenceComponente.getValueMap();
					restartYourPhoneText = valueMap.get("restartYourPhoneText", String.class);
					videoStreamingText = valueMap.get("videoStreamingText", String.class);
					partNumberToogle = valueMap.get("partNumberToogle", String.class);
			}
		}
	}
	
	private void getMultifieldResource() {
		for (Resource child : resource.getChildren()) {
			Iterator<Resource> it = child.listChildren();
			if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.ADD_MERGE_LINE_OPTIONS.equals(child.getName())) {
				setAddMergeLineOptions(it, addMergeLineOptions);
			} else if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.ADD_NEW_LINE_OPTIONS.equals(child.getName())) {
				setNewLineOptions(it, addNewLineOptions);
			} else if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.ADD_NEW_DEVICE_OPTIONS.equals(child.getName())) {
				setNewDeviceOptions(it, addNewDeviceOptions);
			} else if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.PLAN_AUTO_REFILL_MESSAGE_MAPPING.equals(child.getName())) {
				setPlanAutoRefillMessageMapping(it, planAutoRefillMessageMapping);
			}  else if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.NOTIFICATION_CARDS.equals(child.getName())) {
				setNotificationCards(it, notificationCards);
			} 	else if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.STATUS_PENDING_TRANSACTION_LIST.equals(child.getName())) {
				setStatusPendingTransactionList(it, statusPendingTransactionList);
			}else if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.BENEFIT_CHANGE_OPTIONS_PLAN.equals(child.getName())) {
				setBenefitChangeOptions(it, benefitChangeOptionsForPlan);
			}else if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.BENEFIT_CHANGE_OPTIONS_ILD.equals(child.getName())) {
				setBenefitChangeOptions(it, benefitChangeOptionsForILD);
			}else if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.BENEFIT_CHANGE_OPTIONS_RESERVE_PLANS.equals(child.getName())) {
				setBenefitChangeOptions(it, benefitChangeOptionsForReservePlans);
			}else if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.WELCOME_CENTER_PART_CLASSESS.equals(child.getName())) {
				setApplicablePartClassesForWelcomeCenter(it, welcomeCenterPartClasses);
			} else if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.DEENROLLMENT_REASONS.equals(child.getName())) {
				setDeEnrollmentReasons(it);
			}
		}
	}
	
	private void setDeEnrollmentReasons(Iterator<Resource> it) {
		while (it.hasNext()) {
			Resource grandChild = it.next();
			DeEnrollmentReasonsBean deEnrollmentReasonsBean = new DeEnrollmentReasonsBean();
			deEnrollmentReasonsBean.setDeEnrollmentReason(grandChild.getValueMap().get(ApplicationConstants.DEENROLLMENT_REASON, String.class));
			deEnrollmentReasonsBean.setDeEnrollmentReasonText(grandChild.getValueMap().get(ApplicationConstants.DEENROLLMENT_REASON_TEXT, String.class));
			deEnrollmentReasons.add(deEnrollmentReasonsBean);
		}
	}
	
	private void setApplicablePartClassesForWelcomeCenter(Iterator<Resource> it,
			List<String> welcomeCenterPartClasses) {
		while (it.hasNext()) {
			Resource grandChild = it.next();
			welcomeCenterPartClasses.add(grandChild.getValueMap().get("welcomeCenterPartClass", String.class));
		}
	}
	
	private void setBenefitChangeOptions(Iterator<Resource> it,
			List<ManageLinesBean> benefitChangeOptions) {
		while (it.hasNext()) {
			ManageLinesBean manageLinesBean = new ManageLinesBean();
			Resource grandChild = it.next();
			manageLinesBean.setBenefitChangeOption(
					grandChild.getValueMap().get("benefitChangeOption", String.class));
			benefitChangeOptions.add(manageLinesBean);
		}
	}

	private void setNotificationCards(Iterator<Resource> it,
			List<ManageLinesNotificationsBean> notificationCards) {
		while (it.hasNext()) {
			ManageLinesNotificationsBean manageLinesNotificationsBean = new ManageLinesNotificationsBean();
			Resource grandChild = it.next();
			manageLinesNotificationsBean.setNotificationCardType(
					grandChild.getValueMap().get("notificationCardType", String.class));
			manageLinesNotificationsBean.setNotificationCardHeading(
					grandChild.getValueMap().get("notificationCardHeading", String.class));
			manageLinesNotificationsBean.setNotificationCardSubheading(
					grandChild.getValueMap().get("notificationCardSubheading", String.class));
			manageLinesNotificationsBean.setActiveDeviceTutorialsSubheading(
					grandChild.getValueMap().get("activeDeviceTutorialsSubheading", String.class));
			manageLinesNotificationsBean.setNewDeviceTutorialsSubheading(
					grandChild.getValueMap().get("newDeviceTutorialsSubheading", String.class));
			manageLinesNotificationsBean.setEnableNotification(
					grandChild.getValueMap().get("enableNotification", String.class));
			manageLinesNotificationsBean.setShowNotificationOnPlanTab(
					grandChild.getValueMap().get("showNotificationOnPlanTab", String.class));
			manageLinesNotificationsBean.setShowNotificationOnDeviceTab(
					grandChild.getValueMap().get("showNotificationOnDeviceTab", String.class));
			
			notificationCards.add(manageLinesNotificationsBean);
		}
		
	}
	
	
	private void setPlanAutoRefillMessageMapping(Iterator<Resource> it,
			List<ManageLinesBean> planAutoRefillMessageMapping) {
		while (it.hasNext()) {
			ManageLinesBean manageLinesBean = new ManageLinesBean();
			Resource grandChild = it.next();
			manageLinesBean.setPlanPartNumber(
					grandChild.getValueMap().get("planPartNumber", String.class));
			manageLinesBean.setAutoRefillMessage(
					grandChild.getValueMap().get("autoRefillMessage", String.class));
			planAutoRefillMessageMapping.add(manageLinesBean);
		}
		
	}

	private void setStatusPendingTransactionList(Iterator<Resource> it,
			List<ManageLinesBean> statusPendingTransactionList) {
		while (it.hasNext()) {
			ManageLinesBean manageLinesBean = new ManageLinesBean();
			Resource grandChild = it.next();
			manageLinesBean.setTransactionStatus(
					grandChild.getValueMap().get("transactionStatus", String.class));
			manageLinesBean.setTransactionStatusValue(
					grandChild.getValueMap().get("transactionStatusValue", String.class));
			manageLinesBean.setPhoneNumberStatusValue(
					grandChild.getValueMap().get("phoneNumberStatusValue", String.class));
			
			statusPendingTransactionList.add(manageLinesBean);
		}
		
	}

	private void setAddMergeLineOptions(Iterator<Resource> it, List<ManageLinesBean> addMergeLineOptions) {
		while (it.hasNext()) {
			ManageLinesBean manageLinesBean = new ManageLinesBean();
			Resource grandChild = it.next();
			manageLinesBean.setAddMergeLineOptionName(
					grandChild.getValueMap().get("addMergeLineOptionName", String.class));
			manageLinesBean.setAddMergeLineOptionLabel(
					grandChild.getValueMap().get("addMergeLineOptionLabel", String.class));
			addMergeLineOptions.add(manageLinesBean);
		}
	}
	
	private void setNewLineOptions(Iterator<Resource> it, List<ManageLinesBean> addNewLineOptions) {
		while (it.hasNext()) {
			ManageLinesBean manageLinesBean = new ManageLinesBean();
			Resource grandChild = it.next();
			manageLinesBean.setAddNewLineOptionName(
					grandChild.getValueMap().get("addNewLineOptionName", String.class));
			manageLinesBean.setAddNewLineOptionLabel(
					grandChild.getValueMap().get("addNewLineOptionLabel", String.class));
			String addNewLineOptionRedirectPagePath = grandChild.getValueMap().get("addNewLineOptionRedirectPagePath", String.class);
			if(StringUtils.isNotBlank(addNewLineOptionRedirectPagePath)){
				manageLinesBean.setAddNewLineOptionRedirectPagePath(getFinalPagePath(addNewLineOptionRedirectPagePath));
			}
			addNewLineOptions.add(manageLinesBean);
		}
	}

	private void setNewDeviceOptions(Iterator<Resource> it, List<ManageLinesBean> addNewDeviceOptions) {
		while (it.hasNext()) {
			ManageLinesBean manageLinesBean = new ManageLinesBean();
			Resource grandChild = it.next();
			manageLinesBean.setAddNewDeviceOptionName(
					grandChild.getValueMap().get("addNewDeviceOptionName", String.class));
			manageLinesBean.setAddNewDeviceOptionLabel(
					grandChild.getValueMap().get("addNewDeviceOptionLabel", String.class));
			String addNewDeviceOptionRedirectPagePath = grandChild.getValueMap().get("addNewDeviceOptionRedirectPagePath", String.class);
			if(StringUtils.isNotBlank(addNewDeviceOptionRedirectPagePath)){
				manageLinesBean.setAddNewDeviceOptionRedirectPagePath(getFinalPagePath(addNewDeviceOptionRedirectPagePath));
			}
			addNewDeviceOptions.add(manageLinesBean);
		}
	}

	private String getShortURL(String serverDomain, String url) {
		if(StringUtils.isNotBlank(url) && StringUtils.isNotBlank(serverDomain) && url.contains(serverDomain)) {
			url = url.split(serverDomain)[1];
		}
		return url;
	}
	
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getPositionAccountNavigation() {
		return positionAccountNavigation;
	}

	@Override
	public String getPositionManageLines() {
		return positionManageLines;
	}

	@Override
	public String getLegalCopyTextForManageLines() {
		return legalCopyTextForManageLines;
	}

	@Override
	public String getNewDeviceOptionsSubHeading() {
		return newDeviceOptionsSubHeading;
	}

	@Override
	public String getAttemptsToSendVerificationCode() {
		return attemptsToSendVerificationCode;
	}

	@Override
	public String getAddMergeLineOptionsHeading() {
		return addMergeLineOptionsHeading;
	}

	@Override
	public String getAddMergeLineOptionsSubHeading() {
		return addMergeLineOptionsSubHeading;
	}

	@Override
	public String getAddNewLineOptionsHeading() {
		return addNewLineOptionsHeading;
	}

	@Override
	public String getAddNewLineOptionsSubHeading() {
		return addNewLineOptionsSubHeading;
	}

	@Override
	public String getAddNewDeviceOptionsSubHeading() {
		return addNewDeviceOptionsSubHeading;
	}

	@Override
	public String getMergeLineStep1Heading() {
		return mergeLineStep1Heading;
	}

	@Override
	public String getMergeLineStep1Subheading() {
		return mergeLineStep1Subheading;
	}

	@Override
	public String getMergeLineStep2Heading() {
		return mergeLineStep2Heading;
	}

	@Override
	public String getMergeLineStep2Subheading() {
		return mergeLineStep2Subheading;
	}

	@Override
	public String getResendCodeLinkLabel() {
		return resendCodeLinkLabel;
	}

	@Override
	public String getFirstAttemptSendCodeMessage() {
		return firstAttemptSendCodeMessage;
	}

	@Override
	public String getSecondAttemptSendCodeMessage() {
		return secondAttemptSendCodeMessage;
	}

	@Override
	public List<ManageLinesBean> getAddMergeLineOptions() {
		return new ArrayList<>(addMergeLineOptions);
	}

	@Override
	public List<ManageLinesBean> getAddNewLineOptions() {
		return new ArrayList<>(addNewLineOptions);
	}

	@Override
	public List<ManageLinesBean> getAddNewDeviceOptions() {
		return new ArrayList<>(addNewDeviceOptions);
	}

	@Override
	public String getAddMergeLineSuccessHeading() {
		return addMergeLineSuccessHeading;
	}

	@Override
	public String getAddMergeLineSuccessSubheading() {
		return addMergeLineSuccessSubheading;
	}

	@Override
	public String getPlanInReserveHeading() {
		return planInReserveHeading;
	}

	@Override
	public String getPlanInReserveSubheading() {
		return planInReserveSubheading;
	}

	@Override
	public String getNextPlanStartDateHeading() {
		return nextPlanStartDateHeading;
	}

	@Override
	public String getRedeemPlanModalHeadline() {
		return redeemPlanModalHeadline;
	}

	@Override
	public String getRedeemPlanModalSubheadline() {
		return redeemPlanModalSubheadline;
	}

	@Override
	public String getRemoveDeviceModalHeadline() {
		return removeDeviceModalHeadline;
	}

	@Override
	public String getRemoveDeviceModalSubheadline() {
		return removeDeviceModalSubheadline;
	}

	@Override
	public String getEditNickNameModalHeadline() {
		return editNickNameModalHeadline;
	}

	@Override
	public String getEditNickNameModalSubheadline() {
		return editNickNameModalSubheadline;
	}

	@Override
	public String getCategoryIdPlans() {
		return categoryIdPlans;
	}

	@Override
	public String getAddOnPlanCardInfoText() {
		return addOnPlanCardInfoText;
	}

	@Override
	public String getAddOnPlanName() {
		return addOnPlanName;
	}

	@Override
	public String getAddOnPlanPrice() {
		return addOnPlanPrice;
	}

	@Override
	public String getAddOnPlanImage() {
		return DynamicMediaUtils.changeMediaPathToDMPath(addOnPlanImage, request.getResourceResolver());
	}

	@Override
	public String getAddOnPlanPartNumber() {
		return addOnPlanPartNumber;
	}

	@Override
	public String getPlanAutoRefillDefaultMessage() {
		return planAutoRefillDefaultMessage;
	}

	@Override
	public List<ManageLinesBean> getPlanAutoRefillMessageMapping() {
		return new ArrayList<>(planAutoRefillMessageMapping);
	}

	@Override
	public List<ManageLinesBean> getStatusPendingTransactionList() {
		return new ArrayList<>(statusPendingTransactionList);
	}
	
	@Override
	public String getAddOnILDText() {
		return addOnILDText;
	}

	@Override
	public String getIldPlanPartNumber() {
		return ildPlanPartNumber;
	}
	
	@Override
	public String getNextChargeDateILDText() {
		return nextChargeDateILDText;
	}
	
	@Override
	public String getNextChargeDateILDValue() {
		return nextChargeDateILDValue;
	}

	@Override
	public String getPlansPlpPagePath() {
		return getFinalPagePath(plansPlpPagePath);
	}

	@Override
	public String getPlpPagePathHpp() {
		return getFinalPagePath(plpPagePathHpp);
	}

	@Override
	public String getTitleRefillWithPinForILD() {
		return titleRefillWithPinForILD;
	}

	@Override
	public String getParagraphRefillWithPinForILD() {
		return paragraphRefillWithPinForILD;
	}

	@Override
	public String getTitleRefillWithPinForPlan() {
		return titleRefillWithPinForPlan;
	}

	@Override
	public String getParagraphRefillWithPinForPlan() {
		return paragraphRefillWithPinForPlan;
	}

	@Override
	public String getTitleCancelEnrollmentForPlan() {
		return titleCancelEnrollmentForPlan;
	}

	@Override
	public String getParagraphCancelEnrollmentForPlan() {
		return paragraphCancelEnrollmentForPlan;
	}

	@Override
	public String getTitleCancelEnrollmentForILD() {
		return titleCancelEnrollmentForILD;
	}

	@Override
	public String getParagraphCancelEnrollmentForILD() {
		return paragraphCancelEnrollmentForILD;
	}

	@Override
	public String getTitleCancelEnrollmentForHPP() {
		return titleCancelEnrollmentForHPP;
	}

	@Override
	public String getParagraphCancelEnrollmentForHPP() {
		return paragraphCancelEnrollmentForHPP;
	}

	@Override
	public String getTitleCancelEnrollmentSuccessForHPP() {
		return titleCancelEnrollmentSuccessForHPP;
	}

	@Override
	public String getParagraphCancelEnrollmentSuccessForHPP() {
		return paragraphCancelEnrollmentSuccessForHPP;
	}

	@Override
	public String getTextHowDoesItWorkModal() {
		return textHowDoesItWorkModal;
	}

	@Override
	public List<ManageLinesNotificationsBean> getNotificationCards() {
		return new ArrayList<>(notificationCards);
	}

	@Override
	public String getTutorialsPagePath() {
		return getFinalPagePath(tutorialsPagePath);
	}

	@Override
	public String getTransactionsPagePath() {
		return getFinalPagePath(transactionsPagePath);
	}

	@Override
	public String getActivationPagePath() {
		return getFinalPagePathWithoutExtension(activationPagePath);
	}

	@Override
	public String getDeviceSupportPage() {
		return getFinalPagePath(deviceSupportPage);
	}

	@Override
	public String getAutoRefillHomePagePath() {
		return getFinalPagePath(autoRefillHomePagePath);
	}

	@Override
	public String getTransactionHistoryDays() {
		return transactionHistoryDays;
	}

	@Override
	public String getNumberOfItemsOnSinglePage() {
		return numberOfItemsOnSinglePage;
	}

	@Override
	public String getNumberOfPageDisplayed() {
		return numberOfPageDisplayed;
	}

	@Override
	public String getHppEligibilityConfigDays() {
		return hppEligibilityConfigDays;
	}

	@Override
	public String getHppClaimsPage() {
		return getFinalPagePath(hppClaimsPage);
	}

	@Override
	public String getHppClaimsPageAsurion() {
		return getFinalPagePath(hppClaimsPageAsurion);
	}

	@Override
	public String getHppClaimsPageApple() {
		return getFinalPagePath(hppClaimsPageApple);
	}

	@Override
	public String getHppNotEnrolledHeadline() {
		return hppNotEnrolledHeadline;
	}

	@Override
	public String getHppNotEnrolledStatus() {
		return hppNotEnrolledStatus;
	}

	@Override
	public String getIldPlanName() {
		return ildPlanName;
	}

	@Override
	public String getIldPlanPrice() {
		return ildPlanPrice;
	}
	
	@Override
	public String getIldPlanEditCartUrl() {
		return ildPlanEditCartUrl;
	}

	@Override
	public String getPlanDetailsEditCartUrl() {
		return planDetailsEditCartUrl;
	}

	@Override
	public String getAddOnPlanData() {
		return addOnPlanData;
	}

	@Override
	public String getAddOnPlanDataLabel() {
		return addOnPlanDataLabel;
	}

	@Override
	public String getTitleBenefitChangesModalForILD() {
		return titleBenefitChangesModalForILD;
	}

	@Override
	public String getSubTitleBenefitChangesModalForILD() {
		return subTitleBenefitChangesModalForILD;
	}

	@Override
	public String getTitleBenefitChangesModalForPlan() {
		return titleBenefitChangesModalForPlan;
	}

	@Override
	public String getSubTitleBenefitChangesModalForPlan() {
		return subTitleBenefitChangesModalForPlan;
	}

	@Override
	public List<ManageLinesBean> getBenefitChangeOptionsForPlan() {
		return new ArrayList<>(benefitChangeOptionsForPlan);
	}

	@Override
	public List<ManageLinesBean> getBenefitChangeOptionsForILD() {
		return new ArrayList<>(benefitChangeOptionsForILD);
	}

	@Override
	public String getRefillLandingPagePath() {
		return getFinalPagePath(refillLandingPagePath);
	}

	@Override
	public String getRefillPLPPagePath() {
		return getFinalPagePathWithoutExtension(refillPLPPagePath);
	}

	@Override
	public String getPhonesPLPPagePath() {
		return getFinalPagePath(phonesPLPPagePath);
	}
	
	public String getFinalPagePath(String inputPath) {
		String finalPagePath = inputPath;
		if (StringUtils.isNotBlank(finalPagePath) &&  Boolean.TRUE.equals(ApplicationUtil.isInternalLink(finalPagePath))) {
			if (finalPagePath.indexOf(ApplicationConstants.HTML_EXTENSION) == -1) {
				finalPagePath = finalPagePath + ApplicationConstants.HTML_EXTENSION;
			}
			if (StringUtils.isNotBlank(finalPagePath)) {
				String ctaPath = request.getResourceResolver().map(finalPagePath);
				if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
					finalPagePath = ApplicationUtil
							.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
				}
			}
		}
		return finalPagePath;
	}

	public String getFinalPagePathWithoutExtension(String inputPath) {
		String finalPagePath = inputPath;
		if (StringUtils.isNotBlank(finalPagePath)) {
			String ctaPath = request.getResourceResolver().map(finalPagePath);
			if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
				finalPagePath = ApplicationUtil
						.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
			}
		}
		return finalPagePath;
	}

	@Override
	public String getTitleBenefitChangesModalForReservePlans() {
		return titleBenefitChangesModalForReservePlans;
	}

	@Override
	public String getSubTitleBenefitChangesModalForReservePlans() {
		return subTitleBenefitChangesModalForReservePlans;
	}

	@Override
	public List<ManageLinesBean> getBenefitChangeOptionsForReservePlans() {
		return new ArrayList<>(benefitChangeOptionsForReservePlans);
	}

	@Override
	public String getRefillPLPPageSelector() {
		return refillPLPPageSelector;
	}

	@Override
	public String getRefillStartDateSelector() {
		return refillStartDateSelector;
	}
	
	@Override
	public String getRefillBuyNowPLPPageSelector() {
		return refillBuyNowPLPPageSelector;
	}

	@Override
	public String getCheckoutDetailComponentVersion() {
		return StringUtils.isNotBlank(checkoutDetailComponentVersion)?checkoutDetailComponentVersion: "v1";
	}

	@Override
	public String getTitleCusgDiscountAlert() {
		return titleCusgDiscountAlert;
	}

	@Override
	public String getParagraphCusgDiscountAlert() {
		return paragraphCusgDiscountAlert;
	}

	@Override
	public String getPlanServiceEndDateInfoModalContent() {
		return planServiceEndDateInfoModalContent;
		
	}
	
	@Override
	public String getAmazonEnrollmentInfoModalContent() {
		return amazonEnrollmentInfoModalContent;
	}
	
	public String getAddOnPlanImageAssetId() {
		return ApplicationUtil.getAssetId(addOnPlanImage,
				request.getResourceResolver(), ApplicationConstants.IMAGE);
	}

	@Override
	public String getAddOnPlanImageAssetAgencyId() {
		return ApplicationUtil.getAssetMetaDataValue(addOnPlanImage,
				request.getResourceResolver(), ApplicationConstants.WEBER_ID);
	}

	@Override
	public String getZipCodeUnderlyingText() {
		return zipCodeUnderlyingText;
	}

	@Override
	public String getTitleCancelEnrollmentAndRefundModal() {
	   return titleCancelEnrollmentAndRefundModal;
	}
	@Override
	public String getParagraphCancelEnrollmentAndRefundModal() {
	   return paragraphCancelEnrollmentAndRefundModal;
	}

	@Override
	public String getAddOnPlanEditCartUrl() {
		return addOnPlanEditCartUrl;
	}

	@Override
	public Boolean getEnableAmazonPrime() {
		return StringUtils.isNotBlank(enableAmazonPrime)&& ApplicationConstants.TRUE.equalsIgnoreCase(enableAmazonPrime)?true:false;
	}
	
	@Override
	public Boolean getShowWelcomeCenterForDesktop() {
		return StringUtils.isNotBlank(showWelcomeCenterForDesktop)&& ApplicationConstants.TRUE.equalsIgnoreCase(showWelcomeCenterForDesktop)?true:false; 
	}
	
	@Override
	public String getWelcomeCenterHeading() {
		return welcomeCenterHeading;
	}

	@Override
	public String getWelcomeCenterDescription() {
		return welcomeCenterDescription;
	}

	@Override
	public String getVisitWelcomeCenterButton() {
		return visitWelcomeCenterButton;
	}

	@Override
	public String getVisitWelcomeCenterButtonLink() {
		return ApplicationUtil.getShortUrl(request.getResourceResolver(), visitWelcomeCenterButtonLink);
	}

	@Override
	public String getOpenVisitLinkNewTabWindow() {
		return openVisitLinkNewTabWindow;
	}

	@Override
	public String getWelcomeCenterImagePath() {
		return DynamicMediaUtils.changeMediaPathToDMPath(welcomeCenterImagePath, request.getResourceResolver());
	}

	@Override
	public Boolean getHideWelcomeCenter() {
		return StringUtils.isNotBlank(hideWelcomeCenter)&& ApplicationConstants.TRUE.equalsIgnoreCase(hideWelcomeCenter)?true:false;
	}
	
	@Override
	public String[] getWelcomeCenterPartClasses() {
		return welcomeCenterPartClasses.toArray(new String[welcomeCenterPartClasses.size()]); 
	}
	
	@Override
	public String getActivationDateDifference(){
		return activationDateDifference;
	}

	@Override
	public String getSelectAutoRefillAndSaveMessage() {
		return selectAutoRefillAndSaveMessage;
	}

	@Override
	public String getCategoryIdHpp() {
		return categoryIdHpp;
	}

	@Override
	public String getEditGroupNameModalHeadline() {
		return editGroupNameModalHeadline;
	}

	@Override
	public String getEditGroupNameModalSubheadline() {
		return editGroupNameModalSubheadline;
	}

	@Override
	public String getTemporaryProtectionPlanScript() {
		return temporaryProtectionPlanScript;
	}
	
	@Override
	public List<DeEnrollmentReasonsBean> getDeEnrollmentReasons() {
		return new ArrayList<DeEnrollmentReasonsBean>(deEnrollmentReasons);
	}
	
	/**
	 * @return the globalCallingCardPDPPagePath
	 */
	@Override
	public String getGlobalCallingCardPDPPagePath() {
		return ApplicationUtil.getShortUrl(request.getResourceResolver(), globalCallingCardPDPPagePath);
	}

	/**
	 * @return the plansPageAddOnSection
	 */
	@Override
	public String getPlansPageAddOnSection() {
		return plansPageAddOnSection;
	}

	@Override
	public String getEnablePageLevel2FA() {
		return enablePageLevel2FA;
	}

	@Override
	public Boolean getEnableFccLabel() {
		return Boolean.parseBoolean(enableFccLabel);
	}
	@Override
	public Boolean getNewTabWindowForFccLabelLink() {
		return Boolean.parseBoolean(newTabWindowForFccLabelLink);
	}

	@Override
	public String getEnableAddlineForDODevices() {
		return enableAddlineForDODevices;
	}

	@Override
	public String getByopPinModal() {
		return byopPinModal;
	}
	
	@Override
	public String getByopRedeemPlanHeadline() {
		return byopRedeemPlanHeadline;
	}
	@Override
	public String getByopRedeemPlanSubHeadline() {
		return byopRedeemPlanSubHeadline;
	}

	@Override
	public String getByopPinModalDcot() {
		return byopPinModalDcot;
	}

	@Override
	public String getByopRedeemPlanHeadlineDcot() {
		return byopRedeemPlanHeadlineDcot;
	}
	@Override
	public String getByopRedeemPlanSubHeadlineDcot() {
		return byopRedeemPlanSubHeadlineDcot;
	}

	@Override
	public String getRestartYourPhoneText(){
		return restartYourPhoneText;
	};

	@Override
	public String getVideoStreamingText(){
		return videoStreamingText;
	};

	@Override
	public String getPartNumberToogle(){
		return partNumberToogle;
	};

}
