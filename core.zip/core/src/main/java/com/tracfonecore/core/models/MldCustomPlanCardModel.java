package com.tracfonecore.core.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.PhoneSpecsBean;

public interface MldCustomPlanCardModel {

    @JsonProperty("showRecommendedLabel")
	public String getShowRecommendedLabel();

    @JsonProperty("recommendedLabelText")
	public String getRecommendedLabelText();

    @JsonProperty("planTitle")
	public String getPlanTitle();

    @JsonProperty("partNo")
	public String getPartNo();

    @JsonProperty("planPrice")
	public String getPlanPrice();

    @JsonProperty("planPriceSuper")
	public String getPlanPriceSuper();

    @JsonProperty("autoRefillLabel")
	public String getAutoRefillLabel();

    @JsonProperty("ctaLink")
	public String getCtaLink();

    @JsonProperty("ctaText")
	public String getCtaText();

    @JsonProperty("featureSpecs")
	public List<PhoneSpecsBean> getFeatureSpecs();

    @JsonProperty("overridePrice")
	public String getOverridePrice();

    @JsonProperty("showFccLink")
	public String getShowFccLink();

    @JsonProperty("fccLinkText")
	public String getFccLinkText();

    @JsonProperty("showPriceBreakdown")
	public String getShowPriceBreakdown();

    @JsonProperty("showFourthDisclaimer")
	public String getShowFourthDisclaimer();

    @JsonProperty("fourthDisclaimerText")
	public String getFourthDisclaimerText();

    @JsonProperty("priceBreakdownLabel")
	public String getPriceBreakdownLabel();

    @JsonProperty("backToPlanLabel")
	public String getBackToPlanLabel();

    @JsonProperty("useAutoRefillPrice")
	public String getUseAutoRefillPrice();
    
}
