/*
 *  Copyright 2021 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;

import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.PaypalBannerModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.utils.CommerceUtil;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.annotation.PostConstruct;
import javax.inject.Inject;


@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { PaypalBannerModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/paypalbanner", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR,
extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })

public class PaypalBannerModelImpl implements PaypalBannerModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;

	@Inject
	private TracfoneApiGatewayService tracfoneApiService;

	@Inject
	private ApplicationConfigService applicationConfigService;

	@Inject
	private Page currentPage;

	@ValueMapValue
	private String messageLayoutStyle;

	@ValueMapValue
	private String logoType;

	@ValueMapValue
	private String logoPosition;

	@ValueMapValue
	private String textColor;

	@ValueMapValue
	private String bgColor;

	@ValueMapValue
	private String textAlign;

	@ValueMapValue
	private String styleRatio;

	//Constants
	private static final String MESSAGE_STYLE_LAYOUT = "messageLayoutStyle";
	private static final String LOGO_TYPE = "logoType";
	private static final String LOGO_POSITION  = "logoPosition";
	private static final String TEXT_COLOR = "textColor";
	private static final String BG_COLOR  = "bgColor";
	private static final String TEXT_ALIGN = "textAlign";
	private static final String STYLE_RATIO = "styleRatio";
	private static final String SHOW_PAYPAL_BANNER = "showPaypalBanner";

	@PostConstruct
	protected void initModel() {
		fetchPagePropertiesData();
	}

	private void fetchPagePropertiesData()
	{
		Page ancestorPage = null;
		Page parentPage = currentPage.getParent();

		if(parentPage != null) {
			properties = parentPage.getProperties();
			ancestorPage = parentPage.getParent();
		}
		if (properties != null && properties.containsKey(CommerceConstants.CATEGORY_ID) && !properties.get(CommerceConstants.CATEGORY_ID, String.class).isEmpty()
				&& properties.containsKey(CommerceConstants.CATEGORY_TYPE) && !properties.get(CommerceConstants.CATEGORY_TYPE, String.class).isEmpty()){
		}else if(ancestorPage != null){
			properties = ancestorPage.getProperties();
		}
		if(properties != null)
		{
			if (StringUtils.isEmpty(messageLayoutStyle)) {
				setMessageLayoutStyle(properties.get(MESSAGE_STYLE_LAYOUT, String.class));
			}
			if (StringUtils.isEmpty(logoType)) {
				setLogoType(properties.get(LOGO_TYPE, String.class));
			}
			if (StringUtils.isEmpty(logoPosition)) {
				setLogoPosition(properties.get(LOGO_POSITION, String.class));
			}
			if (StringUtils.isEmpty(bgColor)) {
				setBgColor(properties.get(BG_COLOR, String.class));
			}
			if (StringUtils.isEmpty(textColor)) {
				setTextColor(properties.get(TEXT_COLOR, String.class));
			}
			if (StringUtils.isEmpty(textAlign)) {
				setTextAlign(properties.get(TEXT_ALIGN, String.class));
			}
			if (StringUtils.isEmpty(styleRatio)) {
				setStyleRatio(properties.get(STYLE_RATIO, String.class));
			}
		}
	}

	@Override
	public String getMessageLayoutStyle() {
		return messageLayoutStyle;
	}

	@Override
	public String getLogoType() {
		return logoType;
	}

	@Override
	public String getLogoPosition() {
		return logoPosition;
	}

	@Override
	public String getTextColor() {
		return textColor;
	}

	@Override
	public String getBgColor() {
		return bgColor;
	}

	@Override
	public String getTextAlign() {
		return textAlign;
	}

	@Override
	public String getStyleRatio() {
		return styleRatio;
	}

	@Override 
	public String getShowPaypalBanner() {
		return (String)CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(), SHOW_PAYPAL_BANNER);
	}

	/**
	 * @param messageLayoutStyle the messageLayoutStyle to set
	 */
	public void setMessageLayoutStyle(String messageLayoutStyle) {
		this.messageLayoutStyle = messageLayoutStyle;
	}

	/**
	 * @param logoType the logoType to set
	 */
	public void setLogoType(String logoType) {
		this.logoType = logoType;
	}

	/**
	 * @param logoPosition the logoPosition to set
	 */
	public void setLogoPosition(String logoPosition) {
		this.logoPosition = logoPosition;
	}

	/**
	 * @param textColor the textColor to set
	 */
	public void setTextColor(String textColor) {
		this.textColor = textColor;
	}

	/**
	 * @param bgColor the bgColor to set
	 */
	public void setBgColor(String bgColor) {
		this.bgColor = bgColor;
	}

	/**
	 * @param textAlign the textAlign to set
	 */
	public void setTextAlign(String textAlign) {
		this.textAlign = textAlign;
	}

	/**
	 * @param styleRatio the styleRatio to set
	 */
	public void setStyleRatio(String styleRatio) {
		this.styleRatio = styleRatio;
	}

	@Override
	public String getPaypalBraintreePath() {
		return tracfoneApiService.getPaypalBraintreeTokenApiPath();
	}

	/**
	 * <p>
	 * Fetches home page level property from config
	 * </p>
	 *
	 * @return int - homePageLevel
	 */
	public int getHomePageLevel() {

		return applicationConfigService.getHomePageLevel();
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
}