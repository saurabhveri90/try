/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.VoiceMailModel;
import com.tracfonecore.core.beans.VoiceMailHelpPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { VoiceMailModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/voicemail", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class VoiceMailModelImpl implements VoiceMailModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;

	@Inject
	private Resource resource;

	private List<VoiceMailHelpPageBean> voicemailOptionList = Collections.emptyList();

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String title;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String instructionsTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String resetPasswordTitle;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String selectionTitle;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String dropDownPlaceHolder;
	
	@ValueMapValue (injectionStrategy = InjectionStrategy.OPTIONAL)
	private String sumbitButtonLabel;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String helpPageTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String resetPwdSuccessMsg;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(VoiceMailModelImpl.class);

	// Constants
	private static final String VOICEMAIL_LIST = "voicemailOptions";
	private static final String BRAND_TYPE = "brand";
	private static final String INSTRUCTIONS_CONTENT = "instructionsContent";
	private static final String RESET_VOICEMAIL_CONTENT = "resetPasswordContent";

	@PostConstruct
	private void initModel() {
		LOGGER.debug("Entering initModel method");
		voicemailOptionList = new ArrayList<VoiceMailHelpPageBean>();
		for (Resource child : resource.getChildren()) {
			if (VOICEMAIL_LIST.equals(child.getName())) {
				Iterator<Resource> it = child.listChildren();
				setMultiFieldItems(it, voicemailOptionList);
			}
		}
		LOGGER.debug("Exiting initModel method");
	}

	/**
	 * <p>
	 * Populates a list with all the help page options
	 * </p>
	 * 
	 * @param it             - iterator of the parent node
	 * @param multiFieldData - list in which the images data needs to be set
	 */
	private void setMultiFieldItems(Iterator<Resource> it, List<VoiceMailHelpPageBean> multiFieldData) {
		LOGGER.debug("Entering setMultiFieldItems method");
		VoiceMailHelpPageBean voicemailBean = null;
		while (it.hasNext()) {
			voicemailBean = new VoiceMailHelpPageBean();
			Resource grandChild = it.next();
			if (grandChild.getValueMap()!=null){ 
				voicemailBean.setBrandType(grandChild.getValueMap().get(BRAND_TYPE, String.class));
				voicemailBean.setInstructionContent(grandChild.getValueMap().get(INSTRUCTIONS_CONTENT, String.class));
				voicemailBean.setResetPasswordContent(grandChild.getValueMap().get(RESET_VOICEMAIL_CONTENT, String.class));
				multiFieldData.add(voicemailBean);
			}			
		}

		LOGGER.debug("Exiting setMultiFieldItems method");
	}

	@Override
	public List<VoiceMailHelpPageBean> getVoicemailOptionList() {
		return new ArrayList<>(voicemailOptionList);
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Fetches title
	 * </p>
	 *
	 * @return the title
	 */
	@Override
	public String getTitle() {
		return title;
	}

	/**
	 * <p>
	 * Fetches instructionsTitle
	 * </p>
	 *
	 * @return the instructionsTitle
	 */
	@Override
	public String getInstructionsTitle() {
		return instructionsTitle;
	}

	/**
	 * <p>
	 * Fetches resetPasswordTitle
	 * </p>
	 *
	 * @return the resetPasswordTitle
	 */
	@Override
	public String getResetPasswordTitle() {
		return resetPasswordTitle;
	}
	/**
	 * <p>
	 * Fetches selectionTitle
	 * </p>
	 *
	 * @return the selectionTitle
	 */
	@Override
	public String getSelectionTitle() {
		return selectionTitle;
	}
	/**
	 * <p>
	 * Fetches selectionTitle
	 * </p>
	 * 
	 * @return the dropDownPlaceHolder
	 */
	@Override
	public String getDropDownPlaceHolder() {
		return dropDownPlaceHolder;
	}

	/**
	 * <p>
	 * Fetches selectionTitle
	 * </p>
	 * 
	 * @return the sumbitButtonLabel
	 */
	@Override
	public String getSumbitButtonLabel() {
		return sumbitButtonLabel;
	}

	/**
	 * <p>
	 * Fetches helpPageTitle
	 * </p>
	 *
	 * @return the helpPageTitle
	 */
	@Override
	public String getHelpPageTitle(){
		return helpPageTitle;
	}
	/**
	 * <p>
	 * Fetches resetPwdSuccessMsg
	 * </p>
	 *
	 * @return the resetPwdSuccessMsg
	 */
	@Override
	public String getResetPwdSuccessMsg(){
		return resetPwdSuccessMsg;
	}

}
