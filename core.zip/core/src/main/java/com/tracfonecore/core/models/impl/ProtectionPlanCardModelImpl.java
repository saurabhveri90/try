/*
 *  Copyright 2020 HCL Technologies Ltd.
 *
 */
package com.tracfonecore.core.models.impl;

import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.apache.sling.xss.XSSAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.day.cq.wcm.api.Page;
import com.google.gson.JsonObject;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.ProtectionPlanCardModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.ProductOfferingApiService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ItemsExporterUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ProtectionPlanCardModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/protectionplancard", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ProtectionPlanCardModelImpl implements ProtectionPlanCardModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProtectionPlanCardModelImpl.class);

	// constants
	protected static final String RESOURCE_TYPE = "tracfone-core/components/commerce/plancard";

	@Inject
	private Page currentPage;

	@Inject
	private XSSAPI xssApi;

	@Inject
	private SlingModelFilter slingModelFilter;

	@Inject
	private ModelFactory modelFactory;

	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppSelection;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppPromotext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppPlanname;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppPlanseedetails;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppPlandatalabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppPlandatadescription;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppPlanthumbnailimage;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppPlanservicedays;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppPlantermsconditions;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppEnrolltitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppEnrolldecsription;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppEnrollcondition;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String paymentText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Default(values = "false")
	private String isMonthlyPlan;
	

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hppPlantermsconditionslink;

	private JsonObject product;

	@Inject
	private TracfoneApiGatewayService tracfoneApiService;

	@Inject
	private ApplicationConfigService applicationConfigService;
	
	@Inject
	private ProductOfferingApiService productOfferingApiService;

	/**
	 * <p>
	 * Init method : Calls the product api with part number authored and sets plan
	 * data in product field.
	 * </p>
	 *
	 */
	@PostConstruct
	protected void initModel()  {
			LOGGER.debug("Entering init method of ProtectionPlanCardModelImpl");
			if (hppSelection != null && !hppSelection.isEmpty()) {
				LOGGER.debug("ProtectionPlanCardModelImpl: selection part no. {}", hppSelection);
				this.product = productOfferingApiService.getProductDetailObject(hppSelection, currentPage);
				LOGGER.debug("Product Bean "+product.toString());
			}
			LOGGER.debug("Exiting init method of ProtectionPlanCardModelImpl");
	}

	/**
	 * filter the description from output
	 * 
	 * @return String - description html
	 */
	private String safeDescription(JsonObject product) {
		String description = (product.get("detailedDescription") != null) ? product.get("detailedDescription").getAsString() : null;
		if (description == null) {
			return null;
		}
		return xssApi.filterHTML(description);
	}

	/**
	 * @return String - description
	 */
	@Override
	public String getDescription() {
		return safeDescription(product);
	}

	/**
	 * <p>
	 * Returns id from API response
	 * </p>
	 * 
	 * @return Integer - id from api response
	 */
	@Override
	public Integer getId() {
		if (product != null && product.get(CommerceConstants.ID)!=null) {
			return product.get(CommerceConstants.ID).getAsInt();
		}
		return null;
	}

	/**
	 * <p>
	 * Returns name from API response
	 * </p>
	 * 
	 * @return String - name
	 */
	@Override
	public String getName() {
		if (product != null && product.get(CommerceConstants.NAME) != null) {
			return product.get(CommerceConstants.NAME).getAsString();
		}
		return null;
	}

	/**
	 * <p>
	 * Returns promo text authored
	 * </p>
	 * 
	 * @return String - promotext
	 */
	@Override
	public String getHppPromoText() {
		return hppPromotext;
	}

	/**
	 * <p>
	 * Returns plan name authored
	 * </p>
	 * 
	 * @return String - planname
	 */
	@Override
	public String getHppPlanName() {
		return hppPlanname;
	}

	/**
	 * <p>
	 * Returns price superscript authored
	 * </p>
	 * 
	 * @return String - pricesuperscript
	 */
	@Override
	public String getHppPlanseedetails() {
		return hppPlanseedetails;
	}

	/**
	 * <p>
	 * Returns price description authored
	 * </p>
	 * 
	 * @return String - pricedescription
	 */
	@Override
	public String getHppPlanDataLabel() {
		return hppPlandatalabel;
	}

	/**
	 * <p>
	 * Returns price description authored
	 * </p>
	 *
	 * @return String - pricedescription
	 */
	@Override
	public String getHppPlanDataDescription() {
		return hppPlandatadescription;
	}

	/**
	 * @return the planthumbnailimage
	 */
	@Override
	public String getHppPlanthumbnailimage() {
		return hppPlanthumbnailimage;
	}

	/**
	 * @return the planservicedays
	 */
	@Override
	public String getHppPlanservicedays() {
		return hppPlanservicedays;
	}

	/**
	 * <p>
	 * Returns selection authored
	 * </p>
	 * 
	 * @return String - selection
	 */
	@Override
	public String getHppSelection() {
		return hppSelection;
	}

	/**
	 * <p>
	 * Returns Plan terms & conditions authored
	 * </p>
	 *
	 * @return String - hppPlantermsconditions
	 */
	@Override
	public String getHppPlantermsconditions() {
		return hppPlantermsconditions;
	}

	/**
	 * <p>
	 * Returns Plan enroll title authored
	 * </p>
	 *
	 * @return String - hppEnrolltitle
	 */
	@Override
	public String getHppEnrolltitle() {
		return hppEnrolltitle;
	}

	/**
	 * <p>
	 * Returns Plan enroll description authored
	 * </p>
	 *
	 * @return String - hppEnrolldecsription
	 */
	@Override
	public String getHppEnrolldecsription() {
		return hppEnrolldecsription;
	}

	/**
	 * <p>
	 * Returns Plan enroll accepteance condition authored
	 * </p>
	 *
	 * @return String - hppEnrollcondition
	 */
	@Override
	public String getHppEnrollcondition() {
		return hppEnrollcondition;
	}

	/**
	 * <p>
	 * Returns is Monthly Plan Value
	 * </p>
	 * @return Boolean - isMonthlyPlan
	 */
	@Override
	public String getIsMonthlyPlan() {
		return isMonthlyPlan;
	}

	/**
	 * <p>
	 * Returns Plan terms & conditions link authored
	 * </p>
	 *
	 * @return String - hppPlantermsconditionslink
	 */
	@Override
	public String getHppPlanTermsConditionsLink() {
		return hppPlantermsconditionslink;
	}
	/**
	 * <p>
	 * Returns exporter type
	 * </p>
	 * 
	 * @return String - getexportertype
	 */
	@Override
	public String getExportedType() {

		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Returns json from items
	 * </p>
	 * 
	 * @return Map - items
	 */
	public Map<String, ? extends ComponentExporter> getItems() {
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}

	/**
	 * <p>
	 * Returns apiDomain from configuration
	 * </p>
	 * 
	 * @return String - apiDomain
	 */
	public String getApiDomain() {

		return tracfoneApiService.getApiDomain();
	}

	/**
	 * <p>
	 * Returns priceApiPath from configuration
	 * </p>
	 * 
	 * @return String - priceApiPath
	 */
	public String getPriceApiPath() {

		return tracfoneApiService.getPriceApiPath();
	}

	/**
	 * <p>
	 * Returns home page level from configuration
	 * </p>
	 * 
	 * @return int - homepagelevel
	 */
	private int getHomePageLevel() {

		return applicationConfigService.getHomePageLevel();
	}

	/**
	 * <p>
	 * Returns language from util
	 * </p>
	 * 
	 * @return String - language
	 */
	@Override
	public String getLanguage() {

		return CommerceUtil.getLanguage(currentPage, getHomePageLevel());
	}

	/**
	 * @return String - queryString String is used for price API call
	 */
	@Override
	public String getQueryString() {
		StringBuilder query = new StringBuilder(CommerceConstants.BRAND).append(CommerceConstants.EQUALS_TO)
				.append(CommerceUtil.getBrandValue(currentPage, getHomePageLevel())).append(CommerceConstants.AMPERSAND)
				.append(CommerceConstants.PRODUCT_ID).append(CommerceConstants.EQUALS_TO).append(this.getId());
		return query.toString();
	}

	/**
	 * <p>
	 * Returns Payment Type text authored
	 * </p>
	 *
	 * @return String - paymentText
	 */
	@Override
	public String getPaymentText() {
		return paymentText;
	}

}
