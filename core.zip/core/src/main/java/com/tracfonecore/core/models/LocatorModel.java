package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.LocatorBean;
import com.tracfonecore.core.beans.LocatorFiltersBean;
import com.tracfonecore.core.beans.LocatorStoreImagesBean;

public interface LocatorModel extends ComponentExporter {

	/**
	 * @return the mapQuestApiDetails
	 */
	@JsonProperty("mapQuestApiDetails")
	public String getMapQuestApiDetails();

	/**
	 * @return the radiusList
	 */
	@JsonProperty("radiusList")
	public List<LocatorBean> getRadiusList();
	
	/**
	 * @return the filtersList
	 */
	@JsonProperty("filtersList")
	public List<LocatorFiltersBean> getFiltersList();
	
	/**
	 * @return the storeImagesList
	 */
	@JsonProperty("storeImagesList")
	List<LocatorStoreImagesBean> getStoreImagesList();

	/**
	 * @return the title
	 */
	@JsonProperty("title")
	public String getTitle();

	/**
	 * @return the searchText
	 */
	@JsonProperty("searchText")
	public String getSearchText();

	/**
	 * @return the mapQuestAuthoring
	 */
	@JsonProperty("mapQuestAuthoring")
	public String getMapQuestAuthoring();

	/**
	 * @return the showMapText
	 */
	@JsonProperty("showMapText")
	public String getShowMapText();

	/**
	 * @return the showListText
	 */
	@JsonProperty("showListText")
	public String getShowListText();

	/**
	 * @return the placeHolder
	 */
	@JsonProperty("placeHolder")
	public String getPlaceHolder();

	/**
	 * @return the mapViewButton
	 */
	@JsonProperty("mapViewButton")
	public String getMapViewButton();

	/**
	 * @return the trafficViewButton
	 */
	@JsonProperty("trafficViewButton")
	public String getTrafficViewButton();

	/**
	 * @return the sattleliteViewButton
	 */
	@JsonProperty("sattleliteViewButton")
	public String getSattleliteViewButton();

	/**
	 * @return the searchButtonAriaLabel
	 */
	@JsonProperty("searchButtonAriaLabel")
	public String getSearchButtonAriaLabel();
	
	/**
	 * @return the allFiltersLabel
	 */
	@JsonProperty("allFiltersLabel")
	public String getAllFiltersLabel();

	/**
	 * @return the homeDeliveryFilterLabel
	 */
	String getHomeDeliveryFilterLbl();
	
	/**
	 * @return the authorizedColor
	 */
	String getAuthorizedColor();

	/**
	 * @return the nationalColor
	 */
	String getNationalColor();
	
	/**
	 * @return the exclusiveColor
	 */
	String getExclusiveColor();
	
	/**
	 * @return the selectedColor
	 */
	String getSelectedColor();
	
	/**
	 * @return the highlightWholeResultCard
	 */
	String getHighlightWholeResultCard();

}
