package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.EarnMoreWaysBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.EarnMoreWaysModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { EarnMoreWaysModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/content/earnmoreways", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class EarnMoreWaysModelImpl implements EarnMoreWaysModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;

	@Inject
	private Resource resource;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String earnMoreWaysHeadline;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String earnMoreWaysSubHeadline;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String earnMoreWaysCtaText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String earnMoreWaysBannerPath;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String earnMoreWaysCtaLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String earnMoreWaysCtaAriaLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean shouldIncludeMyAccountNav;

	private List<EarnMoreWaysBean> earnMoreWays = Collections.emptyList();

	@PostConstruct
	private void initModel() {
		earnMoreWays = new ArrayList<>();
		if (resource != null) {
			getMultifieldResource();
		}
	}
	
	private void getMultifieldResource() {
		for (Resource child : resource.getChildren()) {
			Iterator<Resource> it = child.listChildren();
			if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.EARN_MORE_WAYS_CARD_DETAILS.equals(child.getName())) {
				setEarnMoreWays(it);
			} 
		}
	}

	private void setEarnMoreWays(Iterator<Resource> it) {
		while (it.hasNext()) {
			EarnMoreWaysBean earnMoreWaysBean = new EarnMoreWaysBean();
			Resource child = it.next();
			earnMoreWaysBean.setEarnMoreWaysCardTitle(
					child.getValueMap().get("earnMoreWaysCardTitle", String.class));
			earnMoreWaysBean.setEarnMoreWaysCardClassName(
					child.getValueMap().get("earnMoreWaysCardClassName", String.class));
			earnMoreWays.add(earnMoreWaysBean);
		}
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getEarnMoreWaysHeadline() {
		return earnMoreWaysHeadline;
	}

    @Override
	public String getEarnMoreWaysSubHeadline() {
		return earnMoreWaysSubHeadline;
	}

    @Override
	public String getEarnMoreWaysCtaText() {
		return earnMoreWaysCtaText;
	}

	@Override
	public String getEarnMoreWaysBannerPath() {
		return earnMoreWaysBannerPath;
	}

    @Override
	public String getEarnMoreWaysCtaLink() {
		return earnMoreWaysCtaLink;
	}

	@Override
	public String getEarnMoreWaysCtaAriaLabel() {
		return earnMoreWaysCtaAriaLabel;
	}

	@Override
	public Boolean getShouldIncludeMyAccountNav() {
		return shouldIncludeMyAccountNav;
	}

	@Override
	public List<EarnMoreWaysBean> getEarnMoreWaysCardDetails() {
		return new ArrayList<>(earnMoreWays);
	}

}
