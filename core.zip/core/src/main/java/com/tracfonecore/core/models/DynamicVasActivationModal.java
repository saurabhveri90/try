package com.tracfonecore.core.models;
import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.DynamicVasBean;

/**
 * Defines the {@code Multi-Links} Sling Model used for the {@code /apps/tracfone-core/components/spa/commerce/dynamicvasactivation} component.
 */
public interface DynamicVasActivationModal extends ComponentExporter {
	
    @JsonProperty("pageHeader")
    public String getPageHeader();
    
    @JsonProperty("loginBtnLabel")
    public String getLoginBtnLabel();

    @JsonProperty("defaultLoginMsg")
    public String getDefaultLoginMsg();

    @JsonProperty("noSubscriptionMsg")
    public String getNoSubscriptionMsg();

    @JsonProperty("alreadyActiveMsg")
    public String getAlreadyActiveMsg();

    @JsonProperty("manageVasBtnLabel")
    public String getManageVasBtnLabel();

    @JsonProperty("manageVasPageUrl")
    public String getManageVasPageUrl();    

    @JsonProperty("dynamicVasList")
	public List<DynamicVasBean> getDynamicVasList();

    @JsonProperty("totalApiRepeats")
    public String getTotalApiRepeats();

    @JsonProperty("vasApiInterval")
    public String getVasApiInterval(); 
    
}
