/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.RetrieveOrderNumberModel;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.utils.ApplicationUtil;
/**
 * Defines the model for Retrieve Order Number component
 */
@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { RetrieveOrderNumberModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/retrieveordernumber", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class RetrieveOrderNumberModelImpl implements RetrieveOrderNumberModel {

	@Self
	private SlingHttpServletRequest request;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String trackOrderPagePath;

	@Inject
	private TracfoneApiGatewayService tracfoneApiService;
	
	/**
	 * <p>Retrieve Order No API Path</p>
	 * 
	 * @return String - retrieveOrderNoApiPath
	 */
	@Override
	public String getTrackOrderPagePath() {
		return ApplicationUtil.getShortUrl(request.getResourceResolver(), trackOrderPagePath);
	}

	/**
	 * <p>Track Order Page Path.</p>
	 *
	 * @return String - trackOrderPagePath.
	 */
	@Override
	public String getRetrieveOrderNoApiPath() {
		return tracfoneApiService.getRetrieveOrderNoApiPath();
	}
	
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
}