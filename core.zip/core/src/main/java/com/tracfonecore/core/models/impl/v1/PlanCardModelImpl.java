/*
 *  Copyright 2020 HCL Technologies Ltd.
 *
 */
package com.tracfonecore.core.models.impl.v1;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Iterator;
import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.xss.XSSAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.PlanCardModel;
import com.tracfonecore.core.models.impl.BaseComponentModelImpl;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.ProductOfferingApiService;
import com.tracfonecore.core.services.PurchaseFlowConfigService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.services.TracfoneValueMappingConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import com.tracfonecore.core.beans.OtherSpecsPDPBean;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { PlanCardModel.class,
		ComponentExporter.class }, resourceType = {
				PlanCardModelImpl.RESOURCE_TYPE_V1 }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class PlanCardModelImpl extends BaseComponentModelImpl implements PlanCardModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(PlanCardModelImpl.class);

	// constants
	protected static final String RESOURCE_TYPE_V1 = "tracfone-core/components/commerce/plancard/v1/plancard";

	@Inject
	protected Page currentPage;

	@Inject
	private XSSAPI xssApi;

	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	protected String selection;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promotext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String alternatePromotext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String churnInfo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promoadditionaltext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planname;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean hideRating;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean disableBazaarVoiceRatings;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String pricesuperscript;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String pricedescription;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String acpDiscountedArDescription;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String acpDiscountedArAccsDescription;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String plandatalabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String plandatadescription;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	protected String planthumbnailimage;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	protected String tabletPlanIcon;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planservicedays;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean isGlobalCalling;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean disablePaypalOption;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean isVasBundlePlan;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String vasProductThumbnailImage;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String vasProdImgAccessibleText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String vasProdImgSubscript;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String vasTermsContent;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addLineRibbonText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addLineAutoRefill;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addLineAutoRefillPrice;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean hidePlanInSimPlp;

	protected String planData;

	protected String planTalkMinutes;

	protected JsonArray skusArray;

	protected String autoRefillId;

	protected String autoRefillPrice;

	protected String autoRefillPriceFormatted;

	protected String skuId;

	protected String thumbnailImageAssetId;

	protected String thumbnailImageAssetAgencyId;

	protected List<String> allPlanType = Collections.emptyList();

	protected List<String> devicesType = Collections.emptyList();

	protected List<String> devicesTypeMapping = Collections.emptyList();

	protected String flowType = StringUtils.EMPTY;

	protected String extendedPlanEligibility = "false";

	protected String offerSmartPay = "false";

	protected String offerHPPPlan = "true";

	protected String allowGuestCheckout = "";

	protected String inBuiltProtectionPlan = "";

	protected String marketingIds;

	protected String planCategory;

	protected String planPurchaseType;

	protected String addLinePlan = "";

	protected String multilineSubheading;

	protected String billingPlanType;

	protected String skuPartNumber;

	protected String productPartClass;

	protected String planEligibleForAutoRefill;

	private String planEarnPoints;

	@Inject
	protected TracfoneApiGatewayService tracfoneApiService;

	@Inject
	protected ApplicationConfigService applicationConfigService;

	@Inject
	private ProductOfferingApiService productOfferingApiService;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	protected String type;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	protected String pdpPagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean showMultiLineSelector;

	protected PlanCardModel planCardModel;

	@Inject
	protected Resource resource;

	@Inject
	protected PurchaseFlowConfigService purchaseFlowConfigService;

	@Inject
	protected TracfoneValueMappingConfigService tracfoneValueMappingConfigService;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planShortDescription;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planDescription;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String showPlanThumbnailImage;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promoColor;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String activationPlanDescription;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String perTimePeriod;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String savePriceAccessibilityLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String priceAccessibilityLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String multilineDisclaimer;

	protected JsonObject product = null;

	private Map<String, Object> brandPropertyValueMap;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private List<OtherSpecsPDPBean> otherSpecsPDP;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planDisclaimer;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planNamePDP;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean hidePlanCard;
	/**
	 * <p>
	 * Init method : Calls the product api with part number authored and sets plan
	 * data in product field.
	 * </p>
	 *
	 */
	@PostConstruct
	protected void initModel() {
		LOGGER.info("Entering init method of V1 PlanCardModelImpl");
		otherSpecsPDP = new ArrayList<OtherSpecsPDPBean>();
		for (Resource child : resource.getChildren()) {
			if(("otherSpecsPDP").equals(child.getName()))
			{
				Iterator<Resource> it = child.listChildren();
				setMultiFieldItems(it, otherSpecsPDP);
			}
		}
		try {
			String[] properties = { CommerceConstants.BRANDNAME, CommerceConstants.NUMBER_OF_LINES };
			this.brandPropertyValueMap = CommerceUtil.getMultiplePagePropertyValue(currentPage, getBrandPageLevel(),
					properties);

			if (StringUtils.isNotEmpty(type) && StringUtils.equalsIgnoreCase("dynamic", type)
					&& StringUtils.isNotEmpty(pdpPagePath)) {
				Resource planCardResource = request.getResource().getResourceResolver()
						.getResource(pdpPagePath + CommerceConstants.PLAN_DETAIL_NODE_PATH_V1);
				if (null != planCardResource)
					planCardModel = planCardResource.adaptTo(PlanCardModel.class);
			} else {
				super.initModel();
				String currentDateTime;
				/*
				 * If the current page is null for any reason then find the currentPage for the
				 * resource's containing page.
				 */
				if (currentPage == null && resource != null) {
					currentPage = resource.getResourceResolver().adaptTo(PageManager.class).getContainingPage(resource);
				}
				LOGGER.debug("selection part no. {}", selection);

				currentDateTime = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SS")
						.format(Calendar.getInstance().getTime());
				LOGGER.debug(" V1 PlanCardModelImpl: Product Offering API call starts, time: {}", currentDateTime);

				this.product = productOfferingApiService.getProductDetailObject(selection, currentPage);

				currentDateTime = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SS")
						.format(Calendar.getInstance().getTime());
				LOGGER.debug(" V1 PlanCardModelImpl: Product Offering API call ends, time: {}", currentDateTime);

				LOGGER.debug(" V1 PlanCardModelImpl: Plan card Api response {}", this.product);
				getProductCharacteristics();
				getSKUDetails();
				this.setThumbnailImageAssetId(ApplicationUtil.getAssetId(planthumbnailimage,
						resource.getResourceResolver(), ApplicationConstants.IMAGE));
				this.setThumbnailImageAssetAgencyId(ApplicationUtil.getAssetMetaDataValue(planthumbnailimage,
						resource.getResourceResolver(), ApplicationConstants.WEBER_ID));

				LOGGER.debug("Exiting init method of V1 PlanCardModelImpl");
			}
		} catch (RuntimeException re) {
			LOGGER.error("Product Offering API not available for resource", re);
		}
	}

	/**
	 * filter the description from output
	 * 
	 * @return String - description html
	 */
	protected String safeDescription(JsonObject product) {
		String description = product.get("detailedDescription").getAsString();
		if (description == null) {
			return null;
		}
		return xssApi.filterHTML(description);
	}

	/**
	 * @return String - description
	 */
	public String getDescription() {
		return safeDescription(product);
	}

	/**
	 * <p>
	 * Returns id from API response
	 * </p>
	 * 
	 * @return Integer - id from api response
	 */
	public Integer getId() {
		if (product != null && product.get(CommerceConstants.ID) != null) {
			return product.get(CommerceConstants.ID).getAsInt();
		}
		return null;
	}
	
	@Override
	public String getPlanPDPPage() {
		if(currentPage.getPath().contains("plans-and-services") && currentPage.getTemplate().getPath().contentEquals("/conf/straighttalk/settings/wcm/templates/product-plan-page")) {
			return "true";
		}
		return "false";
	}

	/**
	 * <p>
	 * Returns name from API response
	 * </p>
	 * 
	 * @return String - name
	 */
	public String getName() {
		if (product != null && product.get(CommerceConstants.NAME) != null
				&& StringUtils.isNotEmpty(product.get(CommerceConstants.NAME).getAsString())) {
			return product.get(CommerceConstants.NAME).getAsString();
		}
		return null;
	}

	/**
	 * <p>
	 * Returns name post converting to lower case from API response
	 * </p>
	 * 
	 * @return String - productNameForAnalytics
	 */
	@Override
	public String getProductNameForAnalytics() {
		if (product != null && product.get(CommerceConstants.NAME) != null
				&& StringUtils.isNotEmpty(product.get(CommerceConstants.NAME).getAsString())) {
			return ApplicationUtil.getLowerCaseWithUnderScore(product.get(CommerceConstants.NAME).getAsString());
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Checks if the plan card is first in carousel then return animation timing.
	 * 
	 * @return String - animation value
	 */
	@Override
	public String getAnimationValue() {
		String val = ApplicationConstants.POINT_SIX;

		String curentResName = resource.getName();
		if (curentResName.equals(CommerceConstants.PLAN1)) {
			val = ApplicationConstants.POINT_THREE;
		}
		return val;

	}

	/**
	 * <p>
	 * Sets plan data and plan talk minutes from product characteristics from API
	 * response
	 * </p>
	 * 
	 * @return void
	 */
	private void getProductCharacteristics() {
		LOGGER.debug("Entering getProductCharacteristics method");
		allPlanType = new ArrayList<String>();
		devicesType = new ArrayList<String>();
		devicesTypeMapping = new ArrayList<String>();
		if (product != null && product.get(CommerceConstants.PRODUCT_CHARACTERISTICS) != null
				&& product.get(CommerceConstants.PRODUCT_CHARACTERISTICS).isJsonArray()) {
			JsonArray jsonArray = product.get(CommerceConstants.PRODUCT_CHARACTERISTICS).getAsJsonArray();
			if (jsonArray.size() > 0) {
				for (int i = 0; i < jsonArray.size(); i++) {
					JsonObject jsonObject = jsonArray.get(i).getAsJsonObject();
					String key = jsonObject.get(CommerceConstants.IDENTIFIER).getAsString();
					if (key.equalsIgnoreCase(CommerceConstants.PLAN_DATA)) {

						planData = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Plan data value {}", planData);
					} else if (key.equalsIgnoreCase(CommerceConstants.PLAN_TALK_MINUTES)) {

						planTalkMinutes = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Plan talk minutes value {}", planTalkMinutes);
					} else if (key.equalsIgnoreCase(CommerceConstants.ALL_PLAN_TYPE)) {

						allPlanType.add(jsonObject.get(CommerceConstants.VALUE).getAsString()
								.trim().toLowerCase());
						LOGGER.debug("All Plan type value {}", allPlanType);
					} else if (key.equalsIgnoreCase(CommerceConstants.DEVICES_TYPE)) {
						JsonElement deviceType = jsonObject.get(CommerceConstants.VALUE);
						if (deviceType != null && !deviceType.isJsonNull() && !deviceType.getAsString().equals("0")
								&& !deviceType.getAsString().isEmpty()) {
							devicesType.add(deviceType.getAsString().trim().toLowerCase());
							flowType = getDevicesType(deviceType.getAsString().trim().toLowerCase());
							if (flowType != null)
								devicesTypeMapping.add(deviceType.getAsString().trim() + ":" + flowType);
						}
						LOGGER.debug("Devices Type value {}", devicesType);
					} else if (key.equalsIgnoreCase(CommerceConstants.EXTENTDED_PLAN_ELIGIBLE)) {

						extendedPlanEligibility = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Extended Plan Eligibility value {}", extendedPlanEligibility);
					} else if (key.equalsIgnoreCase(CommerceConstants.OFFER_SMART_PAY)) {

						offerSmartPay = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Offer SmartPay value {}", offerSmartPay);
					} else if (key.equalsIgnoreCase(CommerceConstants.OFFER_HPP_PLAN)) {

						offerHPPPlan = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Offer HPP Plan value {}", offerHPPPlan);
					} else if (key.equalsIgnoreCase(CommerceConstants.ALLOW_GUEST_CHECKOUT)) {

						allowGuestCheckout = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Allow Guest Checkout value {}", allowGuestCheckout);
					} else if (key.equalsIgnoreCase(CommerceConstants.INBUILT_PROTECTION_PLAN)) {

						inBuiltProtectionPlan = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("inBuiltProtectionPlan value {}", inBuiltProtectionPlan);
					} else if (key.equalsIgnoreCase(CommerceConstants.MARKET)) {

						marketingIds = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Marketign IDs value {}", marketingIds);
					} else if (key.equalsIgnoreCase(CommerceConstants.PLAN_CATEGORY)) {

						planCategory = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Plan category value {}", planCategory);
					} else if (key.equalsIgnoreCase(CommerceConstants.PLAN_PURCHASE_TYPE)) {

						planPurchaseType = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Plan purchase type value {}", planPurchaseType);
					} else if (key.equalsIgnoreCase(CommerceConstants.PLAN_CAMPAIGN_NAME)) {

						addLinePlan = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Add a line plan type value {}", addLinePlan);
					} else if (key.equalsIgnoreCase(CommerceConstants.BILLING_PLAN_TYPE)) {
						billingPlanType = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("billing plan type value {}", billingPlanType);
					} else if (key.equalsIgnoreCase(CommerceConstants.PLAN_ELIGIBLE_FOR_AUTOREFILL)) {
						if (!(StringUtils.isEmpty(jsonObject.get(CommerceConstants.VALUE).getAsString()))) {
							planEligibleForAutoRefill = jsonObject.get(CommerceConstants.VALUE).getAsString()
									.toLowerCase();
						}
						LOGGER.debug("Plan Eligible For AutoRefill {}", planEligibleForAutoRefill);
					} else if (key.equalsIgnoreCase(CommerceConstants.PLAN_EARN_POINTS)) {
						planEarnPoints = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Plan earn points value {}", planEarnPoints);
					}
				}
			}

			LOGGER.debug("Exiting getProductCharacteristics method");
		}
	}

	/**
	 * <p>
	 * Returns brand from API response
	 * </p>
	 * 
	 * @return String - brand
	 */
	@Override
	public String getBrand() {

		if (product != null && product.get(CommerceConstants.BRAND) != null
				&& StringUtils.isNotEmpty(product.get(CommerceConstants.BRAND).getAsString())) {
			LOGGER.debug("Query response {}", product.get(CommerceConstants.BRAND).getAsString());
			return product.get(CommerceConstants.BRAND).getAsString();
		}
		return null;
	}

	/**
	 * <p>
	 * Returns make from API response
	 * </p>
	 * 
	 * @return String - make
	 */
	@Override
	public String getMake() {
		String val = StringUtils.EMPTY;
		if (product != null && product.get(CommerceConstants.MAKE) != null
				&& StringUtils.isNotEmpty(product.get(CommerceConstants.MAKE).getAsString())) {
			val = product.get(CommerceConstants.MAKE).getAsString();
		}
		return val;
	}

	/**
	 * <p>
	 * Returns ratings from API response
	 * </p>
	 * 
	 * @return String - ratings
	 */
	@Override
	public String getRating() {

		String rating = "0.0";

		if (product != null && product.get(CommerceConstants.RATINGS) != null
				&& StringUtils.isNotBlank(product.get(CommerceConstants.RATINGS).getAsString())) {
			rating = product.get(CommerceConstants.RATINGS).getAsString();
			LOGGER.debug("Plan ratings value {}", rating);
		}
		return rating;
	}

	/**
	 * <p>
	 * Format rating and remove trailing zeros
	 * </p>
	 * 
	 * @return String - rating without trailing zero
	 * 
	 */
	@Override
	public String getAccessibilityRating() {
		DecimalFormat format = new DecimalFormat(ApplicationConstants.TRAILING_ZERO);
		String accessibilityRating = getRating();
		if (StringUtils.isNotBlank(accessibilityRating)) {
			double ratingval = Double.parseDouble(getRating());
			accessibilityRating = format.format(ratingval);
		}
		return accessibilityRating;
	}

	/**
	 * <p>
	 * Returns reviews from API response
	 * </p>
	 * 
	 * @return String - reviews
	 */
	@Override
	public String getReviews() {
		String reviews = "0";

		if (product != null && product.get(CommerceConstants.REVIEWS) != null
				&& StringUtils.isNotBlank(product.get(CommerceConstants.REVIEWS).getAsString())) {
			reviews = product.get(CommerceConstants.REVIEWS).getAsString();
			LOGGER.debug("Plan reviews value {}", reviews);
		}
		return reviews;
	}

	/**
	 * <p>
	 * Returns promo text authored
	 * </p>
	 * 
	 * @return String - promotext
	 */
	@Override
	public String getPromoText() {

		return promotext;
	}

	/**
	 * <p>
	 * Returns promo alternate text authored
	 * </p>
	 *
	 * @return String - alternatePromotext
	 */
	@Override
	public String getAlternatePromotext() {
		return alternatePromotext;
	}

	/**
	 * <p>
	 * Returns churnInfo text authored
	 * </p>
	 *
	 * @return String - churnInfo
	 */
	@Override
	public String getChurnInfo() {
		return churnInfo;
	}

	/**
	 * <p>
	 * Returns promo additional text authored
	 * </p>
	 *
	 * @return String - promoadditionaltext
	 */
	@Override
	public String getPromoAdditionalText() {

		return promoadditionaltext;
	}

	/**
	 * <p>
	 * Returns plan name authored
	 * </p>
	 * 
	 * @return String - planname
	 */
	@Override
	public String getPlanName() {
		return planname;
	}

	/**
	 * <p>
	 * Returns price superscript authored
	 * </p>
	 * 
	 * @return String - pricesuperscript
	 */
	@Override
	public String getPriceSuperscript() {
		return pricesuperscript;
	}

	/**
	 * <p>
	 * Returns price description authored
	 * </p>
	 * 
	 * @return String - pricedescription
	 */
	@Override
	public String getPriceDescription() {
		return pricedescription;
	}

	/**
	 * <p>
	 * Returns acp discounted ar price description authored
	 * </p>
	 * 
	 * @return String - acpDiscountedArDescription
	 */
	@Override
	public String getAcpDiscountedArDescription() {
		return acpDiscountedArDescription;
	}

	/**
	 * <p>
	 * Returns acp discounted ar accessibility price description authored
	 * </p>
	 * 
	 * @return String - acpDiscountedArAccsDescription
	 */
	@Override
	public String getAcpDiscountedArAccsDescription() {
		return acpDiscountedArAccsDescription;
	}

	/**
	 * <p>
	 * Returns plan Data
	 * </p>
	 * 
	 * @return String - planData
	 */
	@Override
	public String getPlanData() {
		return planData;
	}

	/**
	 * <p>
	 * Returns plan Talk Minutes
	 * </p>
	 * 
	 * @return String - planTalkMinutes
	 */
	@Override
	public String getPlanTalkMinutes() {
		return planTalkMinutes;
	}

	/**
	 * <p>
	 * Returns plan data label authored
	 * </p>
	 * 
	 * @return String - plandatalabel
	 */
	@Override
	public String getPlanDataLabel() {
		return plandatalabel;
	}

	/**
	 * <p>
	 * Returns plan data description authored
	 * </p>
	 * 
	 * @return String - plandatadescription
	 */
	@Override
	public String getPlanDataDescription() {
		return plandatadescription;
	}

	/**
	 * <p>
	 * Returns plan data description authored
	 * </p>
	 * 
	 * @return String - planthumbnailimage
	 */
	@Override
	public String getPlanthumbnailimage() {
		return DynamicMediaUtils.changeMediaPathToDMPath(planthumbnailimage, resource.getResourceResolver());
	}

	/**
	 * <p>
	 * Returns plan data description authored
	 * </p>
	 *
	 * @return String - planthumbnailimage
	 */
	@Override
	public String getTabletPlanIcon() {
		return DynamicMediaUtils.changeMediaPathToDMPath(tabletPlanIcon, resource.getResourceResolver());
	}

	/**
	 * <p>
	 * Returns plan service days authored
	 * </p>
	 * 
	 * @return String - planservicedays
	 */
	@Override
	public String getPlanservicedays() {
		return planservicedays;
	}

	/**
	 * <p>
	 * Returns selection authored
	 * </p>
	 * 
	 * @return String - selection
	 */
	@Override
	public String getSelection() {
		return selection;
	}

	/**
	 * <p>
	 * Returns exporter type
	 * </p>
	 * 
	 * @return String - getexportertype
	 */
	@Override
	public String getExportedType() {

		return resource.getResourceType();
	}

	/**
	 * <p>
	 * Returns PlanCardModel
	 * </p>
	 * 
	 * @return PlanCardModel - getPlanCardModel
	 */
	@Override
	public PlanCardModel getPlanCardModel() {
		return planCardModel;
	}

	/**
	 * <p>
	 * Returns type
	 * </p>
	 * 
	 * @return String - getType
	 */
	@Override
	public String getType() {
		return type;
	}

	/**
	 * <p>
	 * Returns hide Rating value authored
	 * </p>
	 * 
	 * @return Boolean - hideRating
	 */
	@Override
	public Boolean getHideRating() {
		return hideRating;
	}

	/**
	 * <p>
	 * Returns Bazaar Voice Ratings
	 * </p>
	 * 
	 * @return Boolean - disableBazaarVoiceRatings
	 */
	@Override
	public Boolean getDisableBazaarVoiceRatings() {
		return disableBazaarVoiceRatings;
	}

	/**
	 * <p>
	 * Returns apiDomain from configuration
	 * </p>
	 * 
	 * @return String - apiDomain
	 */
	@Override
	public String getApiDomain() {

		return tracfoneApiService.getApiDomain();
	}

	/**
	 * <p>
	 * Returns priceApiPath from configuration
	 * </p>
	 * 
	 * @return String - priceApiPath
	 */
	@Override
	public String getPriceApiPath() {

		return tracfoneApiService.getPriceApiPath();
	}

	/**
	 * <p>
	 * Returns home page level from configuration
	 * </p>
	 * 
	 * @return int - homepagelevel
	 */
	protected int getHomePageLevel() {

		return applicationConfigService.getHomePageLevel();
	}

	/**
	 * <p>
	 * Returns language from util
	 * </p>
	 * 
	 * @return String - language
	 */
	@Override
	public String getLanguage() {

		return CommerceUtil.getLanguage(currentPage, getHomePageLevel());
	}

	/**
	 * <p>
	 * Returns query string
	 * </p>
	 * 
	 * @return String - queryString String is used for price API call
	 */
	@Override
	public String getQueryString() {
		StringBuilder query = new StringBuilder(CommerceConstants.BRAND).append(CommerceConstants.EQUALS_TO)
				.append(CommerceUtil.getBrandValue(currentPage, getHomePageLevel())).append(CommerceConstants.AMPERSAND)
				.append(CommerceConstants.PRODUCT_ID).append(CommerceConstants.EQUALS_TO).append(this.getId());
		return query.toString();
	}

	/**
	 * <p>
	 * Returns Is Global Calling authored
	 * </p>
	 *
	 * @return Boolean - isGlobalCalling
	 */
	@Override
	public Boolean getIsGlobalCalling() {
		return isGlobalCalling;
	}

	/**
	 * <p>
	 * Returns the paypal paymethod checkbox value
	 * </p>
	 *
	 * @return Boolean - disablePaypalOption
	 */
	@Override
	public Boolean getDisablePaypalOption() {
		return disablePaypalOption;
	}

	/**
	 * <p>
	 * Returns the hide plan checkbox value
	 * </p>
	 *
	 * @return Boolean - hidePlanInSimPlp
	 */
	@Override
	public Boolean getHidePlanInSimPlp() {
		return hidePlanInSimPlp;
	}

	/**
	 * <p>
	 * Returns Cantentry Id
	 * </p>
	 *
	 * @return String - cantentryId
	 */
	@Override
	public String getCantentryId() {
		if (product != null && product.get(CommerceConstants.CATENTRY_ID) != null
				&& StringUtils.isNotEmpty(product.get(CommerceConstants.CATENTRY_ID).getAsString())) {
			return product.get(CommerceConstants.CATENTRY_ID).getAsString();
		}
		return null;
	}

	/**
	 * <p>
	 * Returns SKU Details
	 * </p>
	 *
	 * @return String - SKUDetails
	 */
	protected void getSKUDetails() {
		if (product != null && product.get(CommerceConstants.SKUS) != null
				&& product.get(CommerceConstants.SKUS).isJsonArray()) {
			skusArray = product.get(CommerceConstants.SKUS).getAsJsonArray();
			if (skusArray.size() > 0) {
				JsonObject element = skusArray.get(0).getAsJsonObject();
				autoRefillId = element.get(CommerceConstants.AUTO_REFILL_ID).getAsString();
				autoRefillPrice = element.get(CommerceConstants.AUTO_REFILL_PRICE).getAsString();
				skuId = element.get(CommerceConstants.ID).getAsString();
				JsonObject prodSpec = element.get(CommerceConstants.PRODUCT_SPECIFICATIONS).getAsJsonObject();
				skuPartNumber = prodSpec.get(CommerceConstants.PART_NUMBER).getAsString();
			}
		}
	}

	/**
	 * <p>
	 * Returns Auto Refill Id
	 * </p>
	 *
	 * @return String - autoRefillId
	 */
	@Override
	public String getAutoRefillId() {
		return autoRefillId;
	}

	/**
	 * <p>
	 * Returns Auto Refill Price
	 * </p>
	 *
	 * @return String - autoRefillPrice
	 */
	@Override
	public String getAutoRefillPrice() {
		return autoRefillPrice;
	}

	/**
	 * <p>
	 * Returns Auto Refill Price formatted
	 * </p>
	 *
	 * @return the autoRefillPriceFormatted
	 */
	@Override
	public String getAutoRefillPriceFormatted() {
		if (StringUtils.isNotBlank(autoRefillPrice))
			autoRefillPriceFormatted = CommerceConstants.DOLLAR + autoRefillPrice.replace(".00", "");
		return autoRefillPriceFormatted;
	}

	/**
	 * <p>
	 * Returns Sku Id
	 * </p>
	 *
	 * @return String - skuId
	 */
	@Override
	public String getSkuId() {
		return skuId;
	}

	/**
	 * <p>
	 * Returns Thumbnail Image AssetId
	 * </p>
	 *
	 * @return String - thumbnailImageAssetId
	 */
	@Override
	public String getThumbnailImageAssetId() {
		return thumbnailImageAssetId;
	}

	/**
	 * <p>
	 * Returns Thumbnail Image AssetId
	 * </p>
	 *
	 * @return String - thumbnailImageAssetId
	 */
	public void setThumbnailImageAssetId(String thumbnailImageAssetId) {
		this.thumbnailImageAssetId = thumbnailImageAssetId;
	}

	/**
	 * <p>
	 * Returns Thumbnail Image Asset AgencyId
	 * </p>
	 *
	 * @return String - thumbnailImageAssetAgencyId
	 */
	@Override
	public String getThumbnailImageAssetAgencyId() {
		return thumbnailImageAssetAgencyId;
	}

	/**
	 * <p>
	 * Set Thumbnail Image Asset AgencyId
	 * </p>
	 *
	 * @param String - thumbnailImageAssetAgencyId
	 */
	public void setThumbnailImageAssetAgencyId(String thumbnailImageAssetAgencyId) {
		this.thumbnailImageAssetAgencyId = thumbnailImageAssetAgencyId;
	}

	/**
	 * <p>
	 * Returns All plan Types
	 * </p>
	 *
	 * @return String - allplanTypes
	 */
	@Override
	public String getAllPlanType() {
		String planTypes;
		planTypes = String.join(",", allPlanType);
		if (planTypes.endsWith(",")) {
			planTypes = planTypes.substring(0, planTypes.length() - 1);
		}
		return planTypes;
	}

	/**
	 * <p>
	 * Returns Flow As Per Device Type
	 * </p>
	 *
	 * @return String - flowAsPerDeviceType
	 */
	@Override
	public String getFlowAsPerDeviceType() {
		String flowsType = StringUtils.EMPTY;
		if (flowType != null && !flowType.isEmpty()) {
			flowsType = flowType;
		}
		return flowsType;
	}

	/**
	 * <p>
	 * Returns Devices Type
	 * </p>
	 *
	 * @return String - devicesType
	 */
	protected String getDevicesType(String currentDeviceType) {
		// String productDevicesType = devicesType.trim().toLowerCase();
		String productDevicesType = currentDeviceType;
		String devicePlanType;
		ArrayList<String> languageValueList = ConfigurationUtil.getBrandConfigValueMap(
				CommerceUtil.getBrandValue(currentPage, getHomePageLevel()),
				tracfoneValueMappingConfigService.getLanguageValueMapping());
		for (String langValue : languageValueList) {
			if (StringUtils.isNotBlank(productDevicesType) && langValue.contains(ApplicationConstants.SEMICOLON)) {
				String[] value = langValue.split(ApplicationConstants.SEMICOLON);
				for (String s : value) {
					if (s.contains(ApplicationConstants.EQUAL)
							&& getLanguage().equalsIgnoreCase(s.split(ApplicationConstants.EQUAL)[0])
							&& s.split(ApplicationConstants.EQUAL)[1].trim().toLowerCase()
									.equalsIgnoreCase(productDevicesType)) {
						devicePlanType = getFlowDeviceType(value);
						return devicePlanType;
					}
				}

			}
		}
		return null;
	}

	/**
	 * <p>
	 * Returns Flow Device Type
	 * </p>
	 *
	 * @return String - flowDeviceType
	 */
	protected String getFlowDeviceType(String[] languageValueMap) {
		String type;
		String language = getLanguage();
		String[] deviceTypes = getPurchaseDevicesType();
		if (StringUtils.isNotBlank(language)) {
			for (String device : deviceTypes) {
				for (String deviceType : device.split(ApplicationConstants.SEMICOLON)) {
					if (null != deviceType && deviceType.contains(ApplicationConstants.EQUAL)
							&& language.equalsIgnoreCase(deviceType.split(ApplicationConstants.EQUAL)[0])) {
						String deviceValue = deviceType.split(ApplicationConstants.EQUAL)[1];
						if (deviceValue.contains(ApplicationConstants.COLON)) {

							String currentKey = deviceValue.split(ApplicationConstants.COLON)[0];
							String currentValue = deviceValue.split(ApplicationConstants.COLON)[1];
							for (String s : languageValueMap) {
								if (s.split(ApplicationConstants.EQUAL)[0].equalsIgnoreCase(language)) {
									if ((currentKey.trim().toLowerCase()).equalsIgnoreCase(
											s.split(ApplicationConstants.EQUAL)[1].trim().toLowerCase())) {
										type = currentValue;
										return type;
									}

								}
							}

						}

					}
				}
			}
		}
		return null;
	}

	/**
	 * <p>
	 * Returns Extended Plan Eligibility
	 * </p>
	 *
	 * @return String - extendedPlanEligibility
	 */
	@Override
	public String getExtendedPlanEligibility() {
		if (null != extendedPlanEligibility && !extendedPlanEligibility.isEmpty()) {
			if (extendedPlanEligibility.trim().toLowerCase().equalsIgnoreCase(ApplicationConstants.TRUE)) {
				extendedPlanEligibility = "true";
			}
		}
		return extendedPlanEligibility;
	}

	/**
	 * <p>
	 * Returns offer Smart Pay
	 * </p>
	 *
	 * @return String - offerSmartPay
	 */
	@Override
	public String getOfferSmartPay() {
		if (null != offerSmartPay && !offerSmartPay.isEmpty()) {
			if (offerSmartPay.trim().toLowerCase().equalsIgnoreCase(ApplicationConstants.TRUE)) {
				offerSmartPay = ApplicationConstants.TRUE;
			} else {
				offerSmartPay = ApplicationConstants.FALSE;
			}
		}
		return offerSmartPay;
	}

	/**
	 * <p>
	 * Returns Offer HPP Plan
	 * </p>
	 *
	 * @return String - offerHPPPlan
	 */
	@Override
	public String getOfferHPPPlan() {

		return offerHPPPlan.toLowerCase();
	}

	/**
	 * <p>
	 * Returns Allow Guest Checkout
	 * </p>
	 *
	 * @return String - allowGuestCheckout
	 */
	@Override
	public String getAllowGuestCheckout() {
		if (null != allowGuestCheckout && !allowGuestCheckout.isEmpty()) {
			if (allowGuestCheckout.trim().toLowerCase().equalsIgnoreCase(ApplicationConstants.TRUE)) {
				allowGuestCheckout = ApplicationConstants.TRUE;
			} else {
				allowGuestCheckout = ApplicationConstants.FALSE;
			}
		}
		return allowGuestCheckout;
	}

	public String getInBuiltProtectionPlan() {
		if (null != inBuiltProtectionPlan && !inBuiltProtectionPlan.isEmpty()) {
			if (inBuiltProtectionPlan.trim().toLowerCase().equalsIgnoreCase(ApplicationConstants.TRUE)) {
				inBuiltProtectionPlan = ApplicationConstants.TRUE;
			} else {
				inBuiltProtectionPlan = ApplicationConstants.FALSE;
			}
		}
		return inBuiltProtectionPlan;
	}

	public String getAddLinePlan() {
		if (null != addLinePlan && !addLinePlan.isEmpty()) {
			addLinePlan = ApplicationConstants.TRUE;
		} else {
			addLinePlan = ApplicationConstants.FALSE;
		}
		return addLinePlan;
	}

	/**
	 * <p>
	 * Returns Purchase Devices Type
	 * </p>
	 *
	 * @return String - purchaseDevicesType
	 */
	protected String[] getPurchaseDevicesType() {
		return purchaseFlowConfigService.getDevicesType();
	}

	/**
	 * <p>
	 * Returns Inventory Api Path
	 * </p>
	 *
	 * @return String - inventoryApiPath
	 */
	@Override
	public String getInventoryApiPath() {
		return tracfoneApiService.getInventoryApiPath();
	}

	/**
	 * <p>
	 * Returns Marketing Ids
	 * </p>
	 *
	 * @return String - marketingIds
	 */
	@Override
	public String getMarketingIds() {
		return marketingIds;
	}

	/**
	 * <p>
	 * Returns Inventory Query String
	 * </p>
	 *
	 * @return String - inventoryQueryString
	 */
	@Override
	public String getInventoryQueryString() {
		StringBuilder query = new StringBuilder(CommerceConstants.BRAND).append(CommerceConstants.EQUALS_TO)
				.append(CommerceUtil.getBrandValue(currentPage, getHomePageLevel())).append(CommerceConstants.AMPERSAND)
				.append(CommerceConstants.IDENTIFIER).append(CommerceConstants.EQUALS_TO).append(getSkuId());
		return query.toString();
	}

	/**
	 * <p>
	 * Returns Plan Category
	 * </p>
	 *
	 * @return String - planCategory
	 */
	@Override
	public String getPlanCategory() {

		return planCategory;
	}

	/**
	 * <p>
	 * Returns Default fallback thumbnail Image.
	 * </p>
	 * 
	 * @return String - defaultFallbackThumbnailImage
	 */
	@Override
	public String getDefaultFallbackThumbnailImage() {
		String image = ApplicationUtil.getPropertiesFromRootPage(currentPage.getPath(), resource.getResourceResolver(),
				ApplicationConstants.FALLBACK_THUMBNAIL_IMAGE);
		return DynamicMediaUtils.changeMediaPathToDMPath(image, resource.getResourceResolver());
	}

	/**
	 * <p>
	 * Returns Plan Purchase Type
	 * </p>
	 *
	 * @return String - planPurchaseType
	 */
	@Override
	public String getPlanPurchaseType() {
		return planPurchaseType;
	}

	/**
	 * <p>
	 * Returns Device Type mapping
	 * </p>
	 *
	 * @return String - devicesTypeMapping
	 */
	@Override
	public List<String> getDevicesTypeMapping() {
		return new ArrayList<>(devicesTypeMapping);
	}

	/**
	 * <p>
	 * Returns plan short description authored
	 * </p>
	 * 
	 * @return String - planShortDescription
	 */
	@Override
	public String getPlanShortDescription() {
		return planShortDescription;
	}

	/**
	 * <p>
	 * Returns plan description authored
	 * </p>
	 * 
	 * @return String - planDescription
	 */
	@Override
	public String getPlanDescription() {
		return planDescription;
	}

	/**
	 * <p>
	 * Returns categoryApiPath from configuration
	 * </p>
	 *
	 * @return String - categoryApiPath
	 */
	@Override
	public String getCategoryApiPath() {
		return tracfoneApiService.getCategoryApiPath();
	}

	/*
	 * <p>
	 * Returns flag to show plan thumbail image
	 * </p>
	 * 
	 * @return String - showPlanThumbnailImage
	 */
	public String getShowPlanThumbnailImage() {
		return showPlanThumbnailImage;
	}

	/*
	 * <p>
	 * Returns Query String for Fallback API
	 * </p>
	 *
	 * @return String - fall back queryString
	 */
	@Override
	public String getFallBackQueryString() {
		return CommerceUtil.getFallBackQueryString(CommerceUtil.getBrandValue(currentPage, getHomePageLevel()),
				selection);
	}

	/**
	 * Get the cusg enabling check
	 *
	 * @return String - cusg enabling check
	 */
	@Override
	public String getCusgEnable() {
		String cusgCheck = (CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
				CommerceConstants.ENABLE_CUSG) != null) ? CommerceUtil
						.getPagePropertyValue(currentPage, getHomePageLevel(), CommerceConstants.ENABLE_CUSG).toString()
						: "";
		return cusgCheck;
	}

	/**
	 * <p>
	 * Method to return CUSG Logo
	 * </p>
	 *
	 * @return the CUSGLogo
	 */
	@Override
	public String getCusgLogoUrl() {
		return (CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
				CommerceConstants.LOGO_CUSG) != null) ? CommerceUtil
						.getPagePropertyValue(currentPage, getHomePageLevel(), CommerceConstants.LOGO_CUSG).toString()
						: "";
	}

	/**
	 * <p>
	 * Method to return cusg promo text
	 * </p>
	 *
	 * @return the cusgPromoText
	 */
	@Override
	public String getCusgPromoText() {
		return (String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
				CommerceConstants.LABEL_PLAN_CUSG_DISCOUNT_TYPE);
	}

	/**
	 * <p>
	 * Method to return cusg disclaimer text
	 * </p>
	 *
	 * @return the cusgDisclaimerText
	 */
	@Override
	public String getCusgDisclaimerText() {
		return (String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
				CommerceConstants.CUSG_DISCLAIMER_TEXT);
	}

	/**
	 * <p>
	 * Method to return cusg alt image text
	 * </p>
	 *
	 * @return the cusgImageAltText
	 */
	@Override
	public String getCusgImgAltText() {
		return (String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
				CommerceConstants.LOGO_ALT_TEXT_CUSG);
	}

	/**
	 * Fetches value of isVasBundlePlan
	 * 
	 * @return Boolean - isVasBundlePlan
	 */

	public Boolean getIsVasBundlePlan() {
		return isVasBundlePlan;
	}

	/**
	 * Fetches value of vasProductThumbnailImage
	 * 
	 * @return Boolean - vasProductThumbnailImage
	 */
	public String getVasProductThumbnailImage() {
		return vasProductThumbnailImage;
	}

	/**
	 * Fetches value of vasProdImgAccessibleText
	 * 
	 * @return Boolean - vasProdImgAccessibleText
	 */
	public String getVasProdImgAccessibleText() {
		return vasProdImgAccessibleText;
	}

	/**
	 * Fetches value of vasProdImgSubscript
	 * 
	 * @return Boolean - vasProdImgSubscript
	 */
	public String getVasProdImgSubscript() {
		return vasProdImgSubscript;
	}

	/**
	 * Fetches value of vasTermsContent
	 * 
	 * @return Boolean - vasTermsContent
	 */
	public String getVasTermsContent() {
		return vasTermsContent;
	}

	/**
	 * Fetches value of enableButtonForProductCards
	 * 
	 * @return Boolean - enableButtonForProductCards
	 */
	@Override
	public String getEnableButtonForProductCards() {
		return (String) CommerceUtil.getPropertiesFromRootPage(currentPage,
				CommerceConstants.ENABLE_BUTTON_FOR_CAROUSEL_PRODUCT_CARD);
	}

	/**
	 * <p>
	 * Returns addLineRibbonText authored
	 * </p>
	 * 
	 * @return String - addLineRibbonText
	 */
	@Override
	public String getAddLineRibbonText() {
		return addLineRibbonText;
	}

	/**
	 * <p>
	 * Returns addLineAutoRefill authored
	 * </p>
	 * 
	 * @return String - addLineAutoRefill
	 */
	@Override
	public String getAddLineAutoRefill() {
		return addLineAutoRefill;
	}

	/**
	 * <p>
	 * Returns addLineAutoRefillPrice authored
	 * </p>
	 * 
	 * @return String - addLineAutoRefillPrice
	 */
	@Override
	public String getAddLineAutoRefillPrice() {
		return addLineAutoRefillPrice;
	}

	/**
	 * <p>
	 * Fetches showMultiLineSelector value
	 * </p>
	 * 
	 * @return String - showMultiLineSelector
	 */
	@Override
	public Boolean getShowMultiLineSelector() {
		return showMultiLineSelector;
	}

	/**
	 * <p>
	 * Fetches brand page level property from config
	 * </p>
	 * 
	 * @return int - brand page level
	 */
	private int getBrandPageLevel() {
		return applicationConfigService.getBrandPageLevel();
	}

	/**
	 * <p>
	 * Method to return numberOfLinesList
	 *
	 * @return List numberOfLinesList
	 */
	@Override
	public List<Object> getNumberOfLinesList() {
		int numOfLines = StringUtils.isNotBlank(
				CommerceUtil.getPropertyValue(this.brandPropertyValueMap, CommerceConstants.NUMBER_OF_LINES))
						? Integer.parseInt(CommerceUtil.getPropertyValue(this.brandPropertyValueMap,
								CommerceConstants.NUMBER_OF_LINES))
						: 0;
		List<Object> list = new ArrayList<>(numOfLines);
		for (int i = 0; i < numOfLines; i++) {
			list.add("");
		}
		return list;
	}

	/**
	 * <p>
	 * Fetches multilineSubheading from page properties
	 * </p>
	 *
	 * @return the multilineSubheading
	 */
	@Override
	public String getMultilineSubheading() {
		Page parentPage = currentPage.getParent();
		Page ancestorPage = parentPage.getParent();
		ValueMap pageProperties = null;
		if (CommerceUtil.checkCategoryValues(parentPage.getProperties())) {
			pageProperties = parentPage.getProperties();
		} else if (ancestorPage != null && CommerceUtil.checkCategoryValues(ancestorPage.getProperties())) {
			pageProperties = ancestorPage.getProperties();
		}
		return (pageProperties != null ? pageProperties.get(CommerceConstants.MULTILINE_SUBHEADING, String.class)
				: null);

	}

	/**
	 * <p>
	 * Fetches promoColor
	 * </p>
	 *
	 * @return the promoColor
	 */
	@Override
	public String getPromoColor() {
		return promoColor;
	}

	/**
	 * <p>
	 * Fetches billingPlanType
	 * </p>
	 *
	 * @return the billingPlanType
	 */
	@Override
	public String getBillingPlanType() {
		return billingPlanType;
	}

	/**
	 * <p>
	 * Fetches skuPartNumber
	 * </p>
	 *
	 * @return the skuPartNumber
	 */
	public String getSkuPartNumber() {
		return skuPartNumber;
	}

	/**
	 * <p>
	 * Fetches productPartClass
	 * </p>
	 *
	 * @return the productPartClass
	 */
	public String getProductPartClass() {
		if (product != null && product.get(CommerceConstants.PRODUCT_SPECIFICATIONS) != null) {
			JsonObject prodSpec = product.get(CommerceConstants.PRODUCT_SPECIFICATIONS).getAsJsonObject();
			if (prodSpec != null && prodSpec.get(CommerceConstants.PART_CLASS) != null)
				productPartClass = prodSpec.get(CommerceConstants.PART_CLASS).getAsString();
		}
		return productPartClass;
	}

	/**
	 * <p>
	 * Fetches productType
	 * </p>
	 *
	 * @return the productType
	 */
	@Override
	public String getProductType() {
		Page parentPage = currentPage.getParent();
		Page ancestorPage = parentPage.getParent();
		ValueMap pageProperties = null;
		if (CommerceUtil.checkCategoryValues(parentPage.getProperties())) {
			pageProperties = parentPage.getProperties();
		} else if (ancestorPage != null && CommerceUtil.checkCategoryValues(ancestorPage.getProperties())) {
			pageProperties = ancestorPage.getProperties();
		}
		return (pageProperties != null ? pageProperties.get(CommerceConstants.CATEGORY_TYPE, String.class) : null);
	}

	/**
	 * <p>
	 * Fetches activationPlanDescription
	 * </p>
	 *
	 * @return the activationPlanDescription
	 */
	@Override
	public String getActivationPlanDescription() {
		return activationPlanDescription;
	}

	/**
	 * <p>
	 * Fetches perTimePeriod
	 * </p>
	 *
	 * @return the perTimePeriod
	 */
	@Override
	public String getPerTimePeriod() {
		return perTimePeriod;
	}

	/**
	 * <p>
	 * Fetches savePriceAccessibilityLabel
	 * </p>
	 *
	 * @return the savePriceAccessibilityLabel
	 */
	@Override
	public String getSavePriceAccessibilityLabel() {
		return savePriceAccessibilityLabel;
	}

	/**
	 * <p>
	 * Fetches priceAccessibilityLabel
	 * </p>
	 *
	 * @return the priceAccessibilityLabel
	 */
	@Override
	public String getPriceAccessibilityLabel() {
		return priceAccessibilityLabel;
	}

	/**
	 * <p>
	 * Fetches planEligibleForAutoRefill
	 * </p>
	 *
	 * @return the planEligibleForAutoRefill
	 */
	@Override
	public String getPlanEligibleForAutoRefill() {
		return planEligibleForAutoRefill;
	}

	/**
	 * <p>
	 * Returns plan Earn Points
	 * </p>
	 * 
	 * @return the planEarnPoints
	 */
	@Override
	public String getPlanEarnPoints() {
		return planEarnPoints;
	}

	/**
	 * @return the multilineDisclaimer
	 */
	@Override
	public String getMultilineDisclaimer() {
		return multilineDisclaimer;
	}

	@Override
	public List<OtherSpecsPDPBean> getOtherSpecsPDP() {
		return new ArrayList<>(otherSpecsPDP);
	}
	/**
	 * @return the otherSpecsPDP
	 */
	private void setMultiFieldItems(Iterator<Resource> it, List<OtherSpecsPDPBean> multiFieldData) {
		LOGGER.debug("Entering setMultiFieldItems OtherSpecsPDPBean method");
		while (it.hasNext()) {
			OtherSpecsPDPBean otherSpecsPDP= new OtherSpecsPDPBean();
			Resource grandChild = it.next();
			otherSpecsPDP.setIconPathPDP(grandChild.getValueMap().get("iconPathPDP", String.class));
			otherSpecsPDP.setBadgePDP(grandChild.getValueMap().get("badgePDP",String.class));
			otherSpecsPDP.setValuePDP(grandChild.getValueMap().get("valuePDP",String.class));
			otherSpecsPDP.setDescriptionPDP(grandChild.getValueMap().get("descriptionPDP",String.class));
			otherSpecsPDP.setAccessibilityTextPDP(grandChild.getValueMap().get("accessTextPDP",String.class));
			otherSpecsPDP.setIdentifierPDP(grandChild.getValueMap().get("identifierPDP",String.class));
			multiFieldData.add(otherSpecsPDP);
		}
		LOGGER.debug("Exiting setMultiFieldItems method ");
	}

	@Override
	public String getPlanDisclaimer() {
		return planDisclaimer;
	}

	@Override
	public String getPlanNamePDP() { return planNamePDP;}

	@Override
	public Boolean getHidePlanCard() {
		return hidePlanCard;
	}
}
