/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Bazaar Voice Config Service", description = "Bazaar Voice Config Service")
public @interface BazaarVoiceConfig {

	@AttributeDefinition(name = "Client Name",description = "Client Name")
	String[] clientName() default {"STRAIGHT_TALK:straighttalk","TRACFONE:tracfone-wireless","TOTAL_WIRELESS:totalwireless"};

	@AttributeDefinition(name = "Site ID", description = "Site ID")
	String[] siteId() default {"STRAIGHT_TALK:main_site","TRACFONE:main_site"};

	@AttributeDefinition(name = "Environment", description = "Environment")
	String environment() default "staging";

	@AttributeDefinition(name = "Locale", description = "Locale")
	String locale() default "en_US";

}

