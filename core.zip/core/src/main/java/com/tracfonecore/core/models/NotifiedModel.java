/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Notify Me} Sling Model used for the {@code /apps/tracfone-core/components/commerce/notifymodal} component.
 */
public interface NotifiedModel extends ComponentExporter {


    /**
     * <p>Fetches RTE text for the rich text editor</p>
     *
     * @return String - notifyTitle
     */
    @JsonProperty("getNotifyTitle")
    public String getNotifyTitle();
    /**
     * <p>Fetches RTE text for the rich text editor</p>
     *
     * @return String - notifyText
     */
    @JsonProperty("getNotifyText")
    public String getNotifyText();

    /**
     * <p>Fetches RTE text for the rich text editor</p>
     *
     * @return String - notifiedBtn
     */
    @JsonProperty("notifyBtn")
    public String getNotifyBtn();

    /**
     * <p>Fetches RTE text for the rich text editor</p>
     *
     * @return String - preTextNotifyBtn
     */
    @JsonProperty("preTextNotifyBtn")
    public String getPreTextNotifyMeBtn();

    /**
     * <p>Fetches RTE text for the rich text editor</p>
     *
     * @return String - successText
     */
    @JsonProperty("successText")
    public String getSuccessText();

    /**
     * <p>Fetches RTE text for the rich text editor</p>
     *
     * @return String - emailLabel
     */
    @JsonProperty("emailLabel")
    public String getEmailLabel();
    /**
     * @return String - language
     */
    public String getBrand();
    /**
     * @return int - homePageLevel
     */
    public int getHomePageLevel();
    /**
     * @return String -  clientID
     */
     public String getClientID(); 
     
     /**
      * @return String - apiDomain
      */
     public String getApiDomain();

     /**
      * @return String -  notifyApiPath
      */
      public String getNotifyApiPath();
}
