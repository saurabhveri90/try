/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;
import org.apache.sling.api.resource.Resource;

import com.adobe.cq.export.json.ComponentExporter;

/**
 * 
 * @author HCL
 * Defines the {@code Dropdown Navigation } Sling Model used for the {@code /apps/tracfone-core/components/commerce/dropdownNavigation} component.
 *
 */

public interface DropdownNavigationModel extends ComponentExporter {

	/**
	 * Get the heading
	 * 
	 * @return String - heading
	 */
	public String getHeading();

	/**
	 * Get the navigationList
	 * 
	 * @return String - navigationList
	 */
	public Resource getNavigationList();
	
	/**
	 * Get the accessibilityLabel
	 * 
	 * @return String - accessibilityLabel
	 */
	public String getAccessibilityLabel();

	/**
	 * @return the analyticsLabel
	 */
	public String getAnalyticsLabel();

}
