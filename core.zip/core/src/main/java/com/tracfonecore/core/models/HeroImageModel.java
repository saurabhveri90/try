package com.tracfonecore.core.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public interface HeroImageModel {

	/**
     * <p>
     * Fetches the classList
     * </p>
     *
     * @return String - classList
     */
    @JsonProperty("classList")
	public String getClassList();
	
    /**
     * <p>
     * Fetches the imageSrc
     * </p>
     *
     * @return String - imageSrc
     */
    @JsonProperty("imageSrc")
	public String getImageSrc();
	
}
