/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.settings.SlingSettingsService;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.UnsubscribeCommunicationsCategoriesModel;
import com.tracfonecore.core.models.UnsubscribeCommunicationsCategoryModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { UnsubscribeCommunicationsCategoriesModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/unsubscribecommunications", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class UnsubscribeCommunicationsCategoriesModelImpl implements UnsubscribeCommunicationsCategoriesModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;
	
	@Inject
	private SlingSettingsService settingService;
	
	@Inject
	private Resource resource;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String helloTxt;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String emailLabel;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subscriptionsLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String helpTxt;
	
	@ChildResource
    private List<UnsubscribeCommunicationsCategoryModel> communicationCategories;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String unsubscribeallLabel;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String yesLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String noLabel;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String unsubscribeallheadingTxt;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String managecommunicationsTxt;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headerTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String loginLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String privacyTxt;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String disclaimerTxt;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String unsubscribebtnLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String correctTick;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String unsubemailtitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String unsubemailsubtext;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String unsubemailctalabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ccpaTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ccpasubmitreqTxt;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ccpasubmitctaLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ccpastatusreqTxt;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ccpacheckstatusctaLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String brandLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String brandlogoaltTxt;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String unsubemailerrortext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String unsuballemailsubtext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String unsubemailinvaliderrortext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String unsubemailerrorsuffixtext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String unsubemailerrorlogintext;
		
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getHelloTxt() {
		return helloTxt;
	}

	@Override
	public String getEmailLabel() {
		return emailLabel;
	}

	@Override
	public String getSubscriptionsLabel() {
		return subscriptionsLabel;
	}

	@Override
	public String getHelpTxt() {
		return helpTxt;
	}

	@Override
    public List<UnsubscribeCommunicationsCategoryModel> getCommunicationCategories() {
        List<UnsubscribeCommunicationsCategoryModel> list = Optional.ofNullable(communicationCategories).map(List::stream).orElseGet(Stream::empty)
                .collect(Collectors.toList());
        return new ArrayList<>(list);
    }

	@Override
	public String getUnsubscribeallLabel() {
		return unsubscribeallLabel;
	}

	@Override
	public String getYesLabel() {
		return yesLabel;
	}

	@Override
	public String getNoLabel() {
		return noLabel;
	}

	@Override
	public String getUnsubscribeallheadingTxt() {
		return unsubscribeallheadingTxt;
	}

	@Override
	public String getManagecommunicationsTxt() {
		return managecommunicationsTxt;
	}

	@Override
	public String getHeaderTitle() {
		return headerTitle;
	}

	@Override
	public String getLoginLink() {
		return loginLink;
	}

	@Override
	public String getPrivacyTxt() {
		return privacyTxt;
	}

	@Override
	public String getDisclaimerTxt() {
		return disclaimerTxt;
	}

	@Override
	public String getUnsubscribebtnLabel() {
		return unsubscribebtnLabel;
	}

	@Override
	public String getCorrectTick() {
		return DynamicMediaUtils.changeMediaPathToDMPath(correctTick, request.getResourceResolver());
	}

	@Override
	public String getUnsubemailtitle() {
		return unsubemailtitle;
	}

	@Override
	public String getUnsubemailsubtext() {
		return unsubemailsubtext;
	}

	@Override
	public String getUnsubemailctalabel() {
		return unsubemailctalabel;
	}

	@Override
	public String getCcpaTitle() {
		return ccpaTitle;
	}

	@Override
	public String getCcpasubmitreqTxt() {
		return ccpasubmitreqTxt;
	}

	@Override
	public String getCcpasubmitctaLbl() {
		return ccpasubmitctaLbl;
	}

	@Override
	public String getCcpastatusreqTxt() {
		return ccpastatusreqTxt;
	}

	@Override
	public String getCcpacheckstatusctaLbl() {
		return ccpacheckstatusctaLbl;
	}

	@Override
	public String getBrandLogo() {
		return DynamicMediaUtils.changeMediaPathToDMPath(brandLogo, request.getResourceResolver());
	}
	
	@Override
	public String getBrandlogoaltTxt() {
		return brandlogoaltTxt;
	}

	@Override
	public String getUnsubemailerrortext() {
		return unsubemailerrortext;
	}

	@Override
	public String getUnsuballemailsubtext() {
		return unsuballemailsubtext;
	}

	@Override
	public String getUnsubemailerrorlogintext() {
		return unsubemailerrorlogintext;
	}

	@Override
	public String getUnsubemailinvaliderrortext() {
		return unsubemailinvaliderrortext;
	}

	@Override
	public String getUnsubemailerrorsuffixtext() {
		return unsubemailerrorsuffixtext;
	}
}
