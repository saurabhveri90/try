package com.tracfonecore.core.models.impl;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.PhoneSpecsBean;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.MldCustomPlanCardModel;
import com.tracfonecore.core.utils.ApplicationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { MldCustomPlanCardModel.class},
    resourceType = "tracfone-core/components/commerce/mldcustomplancard", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
    @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
    @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class MldCustomPlanCardModeImpl implements MldCustomPlanCardModel {

    //Constants
    private static final String FEATURE_SPECS = "featureSpecs";

    @Inject
	private Resource resource;

    @Self
	private SlingHttpServletRequest request;

    @ValueMapValue
	private String showRecommendedLabel;

    @ValueMapValue
	private String recommendedLabelText;

    @ValueMapValue
	private String planTitle;

    @ValueMapValue
	private String partNo;

    @ValueMapValue
	private String planPrice;

    @ValueMapValue
	private String planPriceSuper;

    @ValueMapValue
	private String autoRefillLabel;

    @ValueMapValue
	private String ctaLink;

    @ValueMapValue
	private String ctaText;

    @ValueMapValue
	private String showFourthDisclaimer;

    @ValueMapValue
	private String fourthDisclaimerText;

    @ValueMapValue
	private String priceBreakdownLabel;

    @ValueMapValue
	private String backToPlanLabel;

    @ValueMapValue
	private String useAutoRefillPrice;

    private String overridePrice;
    private String showFccLink;
    private String fccLinkText;
    private String showPriceBreakdown;

    private List<PhoneSpecsBean> specsList = Collections.emptyList();

    @PostConstruct
	protected void initModel() {
		specsList = new ArrayList<PhoneSpecsBean>();
        for (Resource child : resource.getChildren()) {
			if(FEATURE_SPECS.equals(child.getName())) {
				Iterator<Resource> it = child.listChildren();
				setMultiFieldItems(it, specsList);
			}
		}
        setValuesFromParentContainer();
	}

    /**
     * <p>Populates a list with all the features</p>
     *
     * @param it             - iterator of the parent node
     * @param multiFieldData - list in which the features data needs to be set
     */
    private void setMultiFieldItems(Iterator<Resource> it, List<PhoneSpecsBean> multiFieldData) {
        while (it.hasNext()) {
            PhoneSpecsBean phoneSpecsBean = new PhoneSpecsBean();
            Resource grandChild = it.next();
            ValueMap vm = grandChild.getValueMap();
            phoneSpecsBean.setName(vm.get(CommerceConstants.IDENTIFIER, String.class));
            phoneSpecsBean.setIdentifier(vm.get(CommerceConstants.IDENTIFIER, String.class));
            phoneSpecsBean.setValue(vm.get(CommerceConstants.VALUE, String.class));
            phoneSpecsBean.setDescription(vm.get(CommerceConstants.DESCRIPTION, String.class));
            if (vm.get(CommerceConstants.ACCESS_TEXT, String.class) != null && vm.get(CommerceConstants.ACCESS_TEXT, String.class) != "") {
                phoneSpecsBean.setAccessibilityText(vm.get(CommerceConstants.ACCESS_TEXT, String.class));
            } else {
                if (phoneSpecsBean.getValue() != null && phoneSpecsBean.getValue() != "") {
                    phoneSpecsBean.setAccessibilityText(phoneSpecsBean.getValue());
                }
            }
            multiFieldData.add(phoneSpecsBean);
        }
    }

    private void setValuesFromParentContainer() {
        if (resource != null && resource.getParent() != null && resource.getParent().getParent() != null && resource.getParent().getParent().isResourceType("tracfone-core/components/commerce/mldcardscontainer")) {
			Resource mldCardsContainer = resource.getParent().getParent();
			overridePrice = mldCardsContainer.getValueMap().get("overridePrice", String.class);
			showFccLink = mldCardsContainer.getValueMap().get("showFccLink", String.class);
			fccLinkText = mldCardsContainer.getValueMap().get("fccLinkText", String.class);
			showPriceBreakdown = mldCardsContainer.getValueMap().get("showPriceBreakdown", String.class);
		} 
    }

    @Override
    public String getShowRecommendedLabel() {
        return showRecommendedLabel;
    }

    @Override
    public String getRecommendedLabelText() {
        return recommendedLabelText;
    }

    @Override
    public String getPlanTitle() {
        return planTitle;
    }

    @Override
    public String getPartNo() {
        return partNo;
    }

    @Override
    public String getPlanPrice() {
        return planPrice;
    }

    @Override
    public String getPlanPriceSuper() {
        return planPriceSuper;
    }

    @Override
    public String getAutoRefillLabel() {
        return autoRefillLabel;
    }

    @Override
    public String getCtaLink() {
        return ApplicationUtil.getShortUrl(request.getResourceResolver(), StringUtils.defaultString(ctaLink));
    }

    @Override
    public String getCtaText() {
        return ctaText;
    }

    @Override
    public List<PhoneSpecsBean> getFeatureSpecs() {
        return new ArrayList<>(specsList);
    }

    @Override
    public String getOverridePrice() {
        return overridePrice;
    }

    @Override
    public String getShowFccLink() {
        return showFccLink;
    }

    @Override
    public String getFccLinkText() {
        return fccLinkText;
    }

    @Override
    public String getShowPriceBreakdown() {
        return showPriceBreakdown;
    }

    @Override
    public String getShowFourthDisclaimer() {
        return showFourthDisclaimer;
    }

    @Override
    public String getFourthDisclaimerText() {
        return fourthDisclaimerText;
    }

    @Override
    public String getPriceBreakdownLabel() {
        return priceBreakdownLabel;
    }

    @Override
    public String getBackToPlanLabel() {
        return backToPlanLabel;
    }

    @Override
    public String getUseAutoRefillPrice() {
        return useAutoRefillPrice;
    }
    
}
