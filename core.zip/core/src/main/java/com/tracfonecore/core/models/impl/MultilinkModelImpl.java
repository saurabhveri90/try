/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.MultilinkModel;
import com.tracfonecore.core.beans.LinkBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import com.tracfonecore.core.constants.ApplicationConstants;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { MultilinkModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/multilinks", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class MultilinkModelImpl implements MultilinkModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;

	@Inject
	private Resource resource;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String heading;


	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String fontSize;

	private List<LinkBean> multilinks = Collections.emptyList();

	private static final Logger LOGGER = LoggerFactory.getLogger(MultilinkModelImpl.class);



	@PostConstruct
	private void initModel() {

		multilinks = new ArrayList<LinkBean>();

		for (Resource child : resource.getChildren()) {
			if(ApplicationConstants.MULTI_LINKS.equals(child.getName()))
			{
				Iterator<Resource> it = child.listChildren();
				setMultiFieldItems(it, multilinks);
			}
		}

	}
	/**
	 * <p>Populates a list with all the multi-links</p>
	 * 
	 * @param it - iterator of the parent node
	 * @param multiFieldData - list in which the multi links data needs to be set
	 */
	private void setMultiFieldItems(Iterator<Resource> it, List<LinkBean> multiFieldData) {
		LOGGER.debug("Entering setMultiFieldItems method");
		try {
			while (it.hasNext()) {
				LinkBean linkBean = new LinkBean();
				Resource grandChild = it.next();

				linkBean.setLinkText(grandChild.getValueMap().get(ApplicationConstants.LINK_TEXT, String.class));
				linkBean.setLinkAltText(grandChild.getValueMap().get(ApplicationConstants.LINK_ALT_TEXT,String.class));

			String iconPath = grandChild.getValueMap().get(ApplicationConstants.ICON, String.class);
				linkBean.setLinkIcon(DynamicMediaUtils.changeMediaPathToDMPathWithQueryParam(iconPath, resource.getResourceResolver()));

				setLinkURL(grandChild,linkBean);
				setTargetValue(grandChild,linkBean);
				linkBean.setDoNotFollowLink(ApplicationUtil.getNoFollow(grandChild.getValueMap().get(ApplicationConstants.DO_NOT_FOLLOW_LINK,String.class)));
				linkBean.setShowLinkText(grandChild.getValueMap().get(ApplicationConstants.SHOW_LINK_TEXT, String.class));
				linkBean.setShowLinkTextAndIconSameLine(grandChild.getValueMap().get(ApplicationConstants.SHOW_LINK_TEXT_ICON_SAME_LINE, String.class));
				linkBean.setLinkDescription(grandChild.getValueMap().get(ApplicationConstants.LINK_DESCRIPTION, String.class));
				linkBean.setCtaType(grandChild.getValueMap().get(ApplicationConstants.CTA_TYPE, String.class));
				linkBean.setEventName(grandChild.getValueMap().get(ApplicationConstants.EVENT_NAME, String.class));
				multiFieldData.add(linkBean);
			}
		} catch (RepositoryException re) {
			LOGGER.error("Repository Exception occurred while setting multifield items data {}", re);
		}

		LOGGER.debug("Exiting setMultiFieldItems method ");
	}
	/**
	 * <p>Set link URL after fetching from the node </p>
	 * @param grandChild
	 * @param linkBean
	 * @throws ValueFormatException
	 * @throws PathNotFoundException
	 * @throws RepositoryException
	 */
	private void setLinkURL(Resource grandChild,LinkBean linkBean ) throws ValueFormatException, PathNotFoundException, RepositoryException
	{
		LOGGER.debug("Entering setLinkURL method ");

		String url = grandChild.getValueMap().get(ApplicationConstants.LINK_URL,String.class);
		linkBean.setLinkUrl(ApplicationUtil.getShortUrl(request.getResourceResolver(), url));
		LOGGER.debug("Exiting setLinkURL method ");
	}


	/**
	 * <p>Set target value after fetching from the node </p>
	 * @param grandChild
	 * @param linkBean
	 * @throws PathNotFoundException
	 * @throws ValueFormatException
	 * @throws RepositoryException
	 */
	private void setTargetValue(Resource grandChild,LinkBean linkBean) throws PathNotFoundException, ValueFormatException, RepositoryException
	{
		LOGGER.debug("Entering setTargetValue method ");
		String target = grandChild.getValueMap().get(ApplicationConstants.LINK_URL_TARGET,String.class);
		if(target != null && !target.equals(""))
			linkBean.setNewWindow(target);
		else
		{
			linkBean.setNewWindow(ApplicationConstants.FALSE);
		}
		LOGGER.debug("Exiting setTargetValue method ");
	}
	@Override
	public String getHeading() {
		return heading;
	}	


	@Override
	public String getFontSize() {
		return fontSize;
	}

	@Override
	public List<LinkBean> getMultilinks() {
		return new ArrayList<>(multilinks);
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

}
