/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.tracfonecore.core.models.DeviceTypeModel;
import com.tracfonecore.core.utils.ItemsExporterUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { DeviceTypeModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/deviceType", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })

public class DeviceTypeModelImpl  extends BaseComponentModelImpl  implements DeviceTypeModel {

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private SlingModelFilter slingModelFilter;

	@Inject
	private ModelFactory modelFactory;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String title;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String deviceCategoryTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Default(intValues = 1)
	private int itemsCount;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String backgroundImagePath;


	private static final Logger LOGGER = LoggerFactory.getLogger(DeviceTypeModelImpl.class);

	private List<Integer> totalItemsList = Collections.emptyList();

	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering initModel method");
		super.initModel();
		if (itemsCount > 0) {
			totalItemsList = new ArrayList<>();
			for (int i = 0; i < itemsCount; i++)
				totalItemsList.add(i + 1);
			LOGGER.info("items ArrayList Size in Device type card: {}", totalItemsList.size());
		}

	}

	/**
	 * <p>
	 * Fetches title for Device Type
	 * </p>
	 * 
	 * @return String - title for Device Type
	 */
	@Override
	public String getTitle() {
		return title;
	}

	/**
	 * <p>
	 * Fetches sub title for Device Type
	 * </p>
	 * 
	 * @return String - sub title for Device Type
	 */
	@Override
	public String getSubTitle() {
		return subTitle;
	}

	/**
	 * <p>
	 * Fetches device Category Title for Device Type
	 * </p>
	 * 
	 * @return String - device Category Title for Device Type
	 */
	@Override
	public String getDeviceCategoryTitle() {
		return deviceCategoryTitle;
	}

	/**
	 * <p>
	 * Fetches items Count for Device Type
	 * </p>
	 * 
	 * @return String - items Count for Device Type
	 */
	@Override
	public int getItemsCount() {
		return itemsCount;
	}

	
	/**
	 * <p>
	 * Fetches totalItemsList
	 * </p>
	 *
	 * @return the totalItemsList
	 */
	@Override
	public List<Integer> getTotalItemsList() {
		return new ArrayList<>(totalItemsList);
	}

	/**
	 * @return String - exportedType
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Fetches the export child items
	 * </p>
	 *
	 * 
	 * @return Map<String, ? extends ComponentExporter> - the export child items
	 */
	@Override
	public Map<String, ? extends ComponentExporter> getItems() {
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}

	@Override
	public String getBackgroundImagePath() {
		String s7Path = StringUtils.EMPTY;
		if (StringUtils.isNotEmpty(backgroundImagePath)) {
			 s7Path = DynamicMediaUtils.changeMediaPathToDMPath(backgroundImagePath, request.getResourceResolver());
		}
		return s7Path;
	}

}