package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.DeEnrollmentReasonsBean;
import com.tracfonecore.core.beans.ManageLinesBean;
import com.tracfonecore.core.beans.ManageLinesNotificationsBean;

public interface ManageAutoRefillModel extends ComponentExporter {
	
	@JsonProperty("manageAutoRefillTitle")
	public String getManageAutoRefillTitle();
	
	@JsonProperty("manageAutoRefillDescriptionText")
	public String getManageAutoRefillDescriptionText();

	@JsonProperty("errorMessageForInactiveDevices")
	public String getErrorMessageForInactiveDevices();
	
	@JsonProperty("categoryIdPlans")
	public String getCategoryIdPlans();
	
	@JsonProperty("plansPlpPagePath")
	public String getPlansPlpPagePath();

	@JsonProperty("planDetailsEditCartUrl")
	public String getPlanDetailsEditCartUrl();
	
	@JsonProperty("titleDeEnrollmentForPlan")
	public String getTitleDeEnrollmentForPlan();
	
	@JsonProperty("paragraphDeEnrollmentForPlan")
	public String getParagraphDeEnrollmentForPlan();
	
	@JsonProperty("deEnrollmentReasons")
	public List<DeEnrollmentReasonsBean> getDeEnrollmentReasons();
	
	@JsonProperty("notificationCards")
	public List<ManageLinesNotificationsBean> getNotificationCards();
	
	@JsonProperty("statusPendingTransactionList")
	public List<ManageLinesBean> getStatusPendingTransactionList();
	
	@JsonProperty("refillLandingPagePath")
	public String getRefillLandingPagePath();
	
	@JsonProperty("autoRefillHomePagePath")
	public String getAutoRefillHomePagePath();
	
	@JsonProperty("refillPLPPagePath")
	public String getRefillPLPPagePath();
	
	@JsonProperty("refillPLPPageSelector")
	public String getRefillPLPPageSelector();
	
	@JsonProperty("refillStartDateSelector")
	public String getRefillStartDateSelector();
	
	@JsonProperty("phonesPLPPagePath")
	public String getPhonesPLPPagePath();
	
	@JsonProperty("refillBuyNowPLPPageSelector")
	public String getRefillBuyNowPLPPageSelector();

	@JsonProperty("checkoutDetailComponentVersion")
	public String getCheckoutDetailComponentVersion();
	
	@JsonProperty("planServiceEndDateInfoModalContent")
	public String getPlanServiceEndDateInfoModalContent();
	
	@JsonProperty("notificationCardHeading")
	public String getNotificationCardHeading();
	
	@JsonProperty("notificationCardSubheading")
	public String getNotificationCardSubheading();
	
	@JsonProperty("enableNotification")
	public String getEnableNotification();
	
	@JsonProperty("enrollAutoRefillTermsAndConditionsText")
	public String getEnrollAutoRefillTermsAndConditionsText();

	@JsonProperty("notAllowAutoRefillDescriptionText")
	public String getNotAllowAutoRefillDescriptionText();

	@JsonProperty("alreadyARByopText")
	public String getAlreadyARByopText();

	@JsonProperty("dcotDeEnrollModalTitleText")
	public String getDcotDeEnrollModalTitleText();

	@JsonProperty("dcotDeEnrollModalDescriptionText")
	public String getDcotDeEnrollModalDescriptionText();

	@JsonProperty("dcotDeEnrollModalYesButtonLabel")
	public String getDcotDeEnrollModalYesButtonLabel();

	@JsonProperty("dcotDeEnrollModalNoButtonLabel")
	public String getDcotDeEnrollModalNoButtonLabel();

}