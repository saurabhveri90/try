/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.ActivationFlowWrapperModel;
import com.tracfonecore.core.services.ActivationFlowConfigService;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.BrandSpecificConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.annotation.PostConstruct;
import javax.inject.Inject;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ActivationFlowWrapperModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/activationflowwrapper", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ActivationFlowWrapperModelImpl implements ActivationFlowWrapperModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(ActivationFlowWrapperModelImpl.class);

	@ScriptVariable
	private ValueMap properties;

	/**
	 * Inject cartPath
	 */
	@ValueMapValue
	private String cartPath;

	/**
	 * Inject confirmationPath
	 */
	@ValueMapValue
	private String confirmationPath;

	/**
	 * Inject loginPath
	 */
	@ValueMapValue
	private String loginPath;

	/**
	 * Inject hot flash modal name
	 */
	@ValueMapValue
	private String hotFlashModalId;

	/**
	 * Inject cold flash modal name
	 */
	@ValueMapValue
	private String coldFlashModalId;

	/**
	 * Inject address Validation modal name
	 */
	@ValueMapValue
	private String addressValidationModalId;

	/**
	 * Shipping Address Path
	 */
	@ValueMapValue
	private String shippingAddressPath;

	/**
	 * Inject Sim Not Needed modal name
	 */
	@ValueMapValue
	private String simNotNeededModalId;
	
	/**
	 * Inject Byop Sim Eligible for offer Modal
	 */
	@ValueMapValue
	private String byopSimEligibleModalId;

	/**
	 * Inject Guest Line Locked Modal Name
	 */
	@ValueMapValue
	private String guestLineLockedModalId;

	/**
	 * Inject Guest Line Unlocked Modal Name
	 */
	@ValueMapValue
	private String guestLineUnlockedModalId;

		/**
	 * Inject Auth Line Locked Modal Name
	 */
	@ValueMapValue
	private String authLineLockedModalId;

	/**
	 * Inject Auth Line Unlocked Modal Name
	 */
	@ValueMapValue
	private String authLineUnlockedModalId;

	/**
	 * Inject Line Locked Internal Flow Modal Name
	 */
	@ValueMapValue
	private String lineLockedInternalFlowModalId;

	

	/**
	 * Inject Byop Eligible Success modal name
	 */
	@ValueMapValue
	private String byopEligibleSuccessModalId;

	/**
	 * Inject sim purchase required modal name
	 */
	@ValueMapValue
	private String simPurchaseRequiredModalId;

	/**
	 * Inject Error Can't Continue modal name
	 */
	@ValueMapValue
	private String errorCantContinueModalId;

	/**
	 * Inject Device Agreement Modal Name
	 */
	@ValueMapValue
	private String deviceAgreementModalId;

	@ValueMapValue
	private String imeiNotEligibleModalId;

	@ValueMapValue
	private String imeiNotEligibleForATTModalId;

	@ValueMapValue
	private String esnIsActiveModalId;

	@ValueMapValue
	private String vzwPhoneSimPdpPath;

	@ValueMapValue
	private String tmoPhoneSimPdpPath;

	@ValueMapValue
	private String vzwTabletSimPdpPath;

	@ValueMapValue
	private String tmoTabletSimPdpPath;

	@ValueMapValue
	private String redirectToBYOPFlowModalId;

	@ValueMapValue
	private String deviceNotEligibleForProgram25offeModalId;

	@ValueMapValue
	private String bundleKitCannotBeUsed25offerModalId;

	@ValueMapValue
	private String updatebyop25offerModalId;

	@ValueMapValue
	private String updatebranded25offerModalId;

	@ValueMapValue
	private String paymentCardRedeemMsgRichText;

	@ValueMapValue
	private String invalidSimStatusModalId;

	@ValueMapValue
	private String incompatibleSIMModalValueBrands;
	
	@ValueMapValue
	private String upgradedcotpromotionModalId;
	
	@ValueMapValue
	private String incompatibleDeviceModalId;
	
	@Inject
	private ActivationFlowConfigService activationFlowConfigService;

	@Inject
	private ApplicationConfigService applicationConfigService;

	@Inject
	private BrandSpecificConfigService brandSpecificConfigService;

	@Inject
	private Page currentPage;

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private Resource resource;

	private String selectors;

	private String flowType;

	private String skipDeviceTypeScreen;

	/**
	 * Inject hot flash modal name
	 */
	@ValueMapValue
	private String riskAssesmentModalId;

	@PostConstruct
	private void initModel() {
		String[] pathSelectors = request.getRequestPathInfo().getSelectors();
		selectors = String.join(".", pathSelectors);
		if (pathSelectors.length >= 1) {
			flowType = pathSelectors[0];
		}
		LOGGER.debug("Inside Activation Flow Wrapper");
	}

	/**
	 * <p>
	 * Returns activatePrimaryFlowSteps from activationFlowConfig
	 * </p>
	 * 
	 * @return String - activatePrimaryFlowSteps
	 */
	@Override
	public String getPrimaryFlowSteps() {
		return activationFlowConfigService.getActivatePrimaryFlowSteps(selectors);
	}

	/**
	 * <p>
	 * Returns secondaryFlowSteps from activationFlowConfig
	 * </p>
	 * 
	 * @return String - secondaryFlowSteps
	 */
	@Override
	public String getSecondaryFlowSteps() {
		return activationFlowConfigService.getSecondaryFlowSteps(selectors);
	}

	/**
	 * <p>
	 * Returns puchaseFlowSteps from activationFlowConfig
	 * </p>
	 * 
	 * @return String - puchaseFlowSteps
	 */
	@Override
	public String getPurchaseFlowSteps() {
		return activationFlowConfigService.getPurchaseFlowSteps();
	}

	@Override
	public String getByopRegistrationFlowSteps() {
		return activationFlowConfigService.getBYOPRegistrationFlowSteps();
	}

	@Override
	public String getByotRegistrationFlowSteps() {
		return activationFlowConfigService.getBYOTRegistrationFlowSteps();
	}

	/**
	 * <p>
	 * Returns the specific experience fragments paths string for current step
	 * </p>
	 * 
	 * @return String - xfPath
	 */
	private String getXfPath(Resource multiResource) {
		String xfPaths = "";
		for (Resource resource : multiResource.getChildren()) {
			xfPaths = xfPaths + "," + resource.getValueMap().get("xfPath", "").toString();
		}
		if (xfPaths.startsWith(",")) {
			xfPaths = xfPaths.replaceFirst(",", "");
		}
		return xfPaths;
	}

	/**
	 * <p>
	 * Returns string for all experience fragments paths
	 * </p>
	 * 
	 * @return String - allXfPaths
	 */
	@Override
	public String getAllXfPaths() {
		String value = "";
		for (Resource childResource : resource.getChildren()) {
			if (childResource.getName().startsWith("prop")) {
				value = value + ";" + childResource.getName().replace("prop", "") + ":" + getXfPath(childResource);
			}
		}
		value = value.replaceFirst(";", "");
		return value;

	}

	/**
	 * <p>
	 * Returns cartPath from properties
	 * </p>
	 * 
	 * @return String - cartPath
	 */
	@Override
	public String getCartPath() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), this.cartPath);
	}

	/**
	 * <p>
	 * Returns loginPath from properties
	 * </p>
	 * 
	 * @return String - loginPath
	 */
	@Override
	public String getLoginPath() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), this.loginPath);
	}

	/**
	 * <p>
	 * Returns confirmationPath from properties
	 * </p>
	 * 
	 * @return String - confirmationPath
	 */
	@Override
	public String getConfirmationPath() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), this.confirmationPath);
	}

	/**
	 * <p>
	 * Returns errorCodeUnqualifiedHPP from activationFlowConfig
	 * </p>
	 * 
	 * @return String - errorCodeUnqualifiedHPP
	 */
	@Override
	public String getErrorCodeUnqualifiedHPP() {
		return activationFlowConfigService.getErrorCodeUnqualifiedHPP();
	}

	/**
	 * <p>
	 * Returns hotFlashModalId from properties
	 * </p>
	 * 
	 * @return String - hotFlashModalId
	 */
	@Override
	public String getHotFlashModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(hotFlashModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * <p>
	 * Returns coldFlashModalId from properties
	 * </p>
	 * 
	 * @return String - coldFlashModalId
	 */
	@Override
	public String getColdFlashModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(coldFlashModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * <p>
	 * Returns resourceMgmtProjection from activationFlowConfig
	 * </p>
	 * 
	 * @return String - resourceMgmtProjection
	 */
	@Override
	public String getResourceMgmtProjection() {
		return activationFlowConfigService.getActivationResourceMgmtProjection();
	}

	/**
	 * Returns esnActivatedStatusCode from activationFlowConfig
	 * 
	 * @return String - esnActivatedStatusCode
	 */
	@Override
	public String getEsnActivatedStatusCode() {
		return activationFlowConfigService.getEsnActivatedStatusCode();
	}

	/**
	 * <p>
	 * Returns esnStolenStatusCode from activationFlowConfig
	 * </p>
	 * 
	 * @return String - esnStolenStatusCode
	 */
	@Override
	public String getEsnStolenStatusCode() {
		return activationFlowConfigService.getEsnStolenStatusCode();
	}

	/**
	 * <p>
	 * Returns esnRiskCheckStatusCode from activationFlowConfig
	 * </p>
	 * 
	 * @return String - esnRiskCheckStatusCode
	 */
	@Override
	public String getEsnRiskCheckStatusCode() {
		return activationFlowConfigService.getEsnRiskCheckStatusCode();
	}

	/**
	 * <p>
	 * Returns esnUsedLineStatusCode from activationFlowConfig
	 * </p>
	 * 
	 * @return String - esnUsedLineStatusCode
	 */
	@Override
	public String getEsnUsedLineStatusCode() {
		return activationFlowConfigService.getEsnUsedLineStatusCode();
	}

	/**
	 * <p>
	 * Returns esnPastDueStatusCode from activationFlowConfig
	 * </p>
	 * 
	 * @return String - esnPastDueStatusCode
	 */
	@Override
	public String getEsnPastDueStatusCode() {
		return activationFlowConfigService.getEsnPastDueStatusCode();
	}

	/**
	 * <p>
	 * Returns esnActivatedRedirectLink from home page properties
	 * </p>
	 * 
	 * @return String - esnActivatedRedirectLink
	 */
	@Override
	public String getEsnActivatedRedirectLink() {
		String esnActivatedRedirectLink = ApplicationUtil.getShortUrl(resource.getResourceResolver(),
				CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(), "refillPagePath").toString());
		return esnActivatedRedirectLink;
	}

	/**
	 * <p>
	 * Fetches home page level property from config
	 * </p>
	 * 
	 * @return int - homePageLevel
	 */
	private int getHomePageLevel() {

		return applicationConfigService.getHomePageLevel();
	}

	/**
	 * <p>
	 * Returns getexportertype from resource
	 * </p>
	 * 
	 * @return String - getexportertype
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * @return the imeiNotEligibleModalId
	 */
	@Override
	public String getImeiNotEligibleModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(imeiNotEligibleModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * @return the imeiNotEligibleForATTModalId
	 */
	@Override
	public String getImeiNotEligibleForATTModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(imeiNotEligibleForATTModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * <p>
	 * Returns ZipHardCoded from activationFlowConfig
	 * </p>
	 * 
	 * @return String - zipHardCoded
	 */
	@Override
	public String getZipHardCoded() {
		return activationFlowConfigService.getZipHardCoded();
	}

	/**
	 * Get the Address Validation Modal Id
	 * 
	 * @return String - getAddressValidationModalId
	 */
	public String getAddressValidationModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(addressValidationModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * <p>
	 * Returns getPromoEligibility25PartNumber from activationFlowConfig
	 * </p>
	 * 
	 * @return String - getPromoEligibility25PartNumber
	 */
	@Override
	public String getPromoEligibility25PartNumber() {
		return activationFlowConfigService.getPromoEligibility25PartNumber();
	}

    /**
	 * <p>
	 * Returns esnNewStatusCode from activationFlowConfig
	 * </p>
	 * 
	 * @return String - esnNewStatusCode
	 */
	@Override
	public String getEsnNewStatusCode() {
		return activationFlowConfigService.getEsnNewStatusCode();
	}

	/**
	 * <p>
	 * Returns esnRefurbishedStatusCode from activationFlowConfig
	 * </p>
	 * 
	 * @return String - esnRefurbishedStatusCode
	 */
	@Override
	public String getEsnRefurbishedStatusCode() {
		return activationFlowConfigService.getEsnRefurbishedStatusCode();
	}

	/**
	 * <p>
	 * Returns byopRegistrationResourceMgmtProjection from activationFlowConfig
	 * </p>
	 * 
	 * @return String - byopResourceMgmtProjection
	 */
	@Override
	public String getByopResourceMgmtProjection() {
		return activationFlowConfigService.getByopRegistrationResourceMgmtProjection();
	}

	/**
	 * <p>
	 * Returns byotRegistrationResourceMgmtProjection from activationFlowConfig
	 * </p>
	 *
	 * @return String - byotResourceMgmtProjection
	 */
	@Override
	public String getByotResourceMgmtProjection() {
		return activationFlowConfigService.getByotRegistrationResourceMgmtProjection();
	}

	/**
	 * <p>
	 * Returns shippingAddressPath from properties
	 * </p>
	 * 
	 * @return String - shippingAddressPath
	 */
	@Override
	public String getShippingAddressPath() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), this.shippingAddressPath);
	}

	/**
	 * Get the Sim Not Needed Modal Id
	 *
	 * @return String - getSimNotNeededModalId
	 */
	public String getSimNotNeededModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(simNotNeededModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}
	
	/**
	 * Get the Byop Sim Eligible for offer Modal Id
	 *
	 * @return String - getByopSimEligibleModalId
	 */
	public String getByopSimEligibleModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(byopSimEligibleModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}


	/**
	 * Get the Guest Line Locked Modal Id
	 *
	 * @return String - getGuestLineLockedModalId
	 */
	public String getGuestLineLockedModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(guestLineLockedModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * Get the Guest Line Unlocked Modal Id
	 *
	 * @return String - getGuestLineUnlockedModalId
	 */
	public String getGuestLineUnlockedModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(guestLineUnlockedModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * Get the Guest Line Locked Modal Id
	 *
	 * @return String - getAuthLineLockedModalId
	 */
	public String getAuthLineLockedModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(authLineLockedModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * Get the Guest Line Unlocked Modal Id
	 *
	 * @return String - getAuthLineUnlockedModalId
	 */
	public String getAuthLineUnlockedModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(authLineUnlockedModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * Get the Line Locked Modal Id in Internal Flow
	 *
	 * @return String - getLineLockedInternalFlowModalId
	 */
	public String getLineLockedInternalFlowModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(lineLockedInternalFlowModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * Get the Byop Eligible Success Modal Id
	 *
	 * @return String - getByopEligibleSuccessModalId
	 */
	public String getByopEligibleSuccessModalId() {
		if (StringUtils.isNotEmpty(ApplicationUtil.getLowerCaseWithHyphen(byopEligibleSuccessModalId))) {
			return ApplicationUtil.getLowerCaseWithHyphen(byopEligibleSuccessModalId) + ApplicationConstants.HYPHEN
					+ ApplicationConstants.MODAL;
		}
		return null;
	}

	/**
	 * Get the Error, Can't Continue Modal Id
	 *
	 * @return String - getErrorCantContinueModalId
	 */
	public String getErrorCantContinueModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(errorCantContinueModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * <p>
	 * Returns UpgradeSuccessScenarios from activationFlowConfig
	 * </p>
	 * 
	 * @return String - UpgradeSuccessScenarios
	 */
	@Override
	public String getUpgradeSuccessScenarios() {
		return String.join(ApplicationConstants.COMMA, activationFlowConfigService.getUpgradeSuccessScenarios());
	}

	/**
	 * <p>
	 * Returns UpgradeCheckObjScenarios from activationFlowConfig
	 * </p>
	 * 
	 * @return String - UpgradeCheckObjScenarios
	 */
	@Override
	public String getUpgradeCheckObjScenarios() {
		return String.join(ApplicationConstants.COMMA, activationFlowConfigService.getUpgradeCheckObjScenarios());
	}

	/**
	 * <p>
	 * Returns UpgradeErrorScenarios from activationFlowConfig
	 * </p>
	 * 
	 * @return String - UpgradeErrorScenarios
	 */
	@Override
	public String getUpgradeErrorScenarios() {
		return String.join(ApplicationConstants.COMMA, activationFlowConfigService.getUpgradeErrorScenarios());
	}

	/**
	 * <p>
	 * Returns Progress bar title for current flow type from properties
	 * </p>
	 * 
	 * @return String - progressBarTitle
	 */
	@Override
	public String getProgressBarTitle() {
		return properties.get("pbtitle" + flowType, "");
	}

	/**
	 * <p>
	 * Returns BYOP Standalone Registration Step from config
	 * </p>
	 * 
	 * @return String - byopStandaloneRegStep
	 */
	@Override
	public String getByopStandaloneRegStep() {
		return activationFlowConfigService.getByopStandaloneRegStep();
	}

	/**
	 * <p>
	 * Returns BYOT Standalone Registration Step from config
	 * </p>
	 *
	 * @return String - byotStandaloneRegStep
	 */
	@Override
	public String getByotStandaloneRegStep() {
		return activationFlowConfigService.getByotStandaloneRegStep();
	}

	/**
	 * Get the Active Device Agreement Modal Id
	 *
	 * @return String - getErrorCantContinueModalId
	 */
	public String getActiveDeviceAgreementModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(deviceAgreementModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * Get the cusg enabling check
	 *
	 * @return String - cusg enabling check
	 */
	public String getCusgEnable() {
		String cusgCheck = (CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
				CommerceConstants.ENABLE_CUSG) != null) ? CommerceUtil
				.getPagePropertyValue(currentPage, getHomePageLevel(), CommerceConstants.ENABLE_CUSG).toString()
				: "";
		return cusgCheck;
	}

	/**
	 * <p>
	 * Returns skip Device type screen flag from config
	 * </p>
	 * 
	 * @return String - skipDeviceTypeScreen
	 */
	@Override
	public String getSkipDeviceTypeScreen() {
		return ConfigurationUtil.getConfigValue(activationFlowConfigService.getSkipDeviceTypeScreen(),
				CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}

	/**
	 * <p>
	 * Returns skip select validate
	 * </p>
	 * 
	 * @return String - skipSelectValidate
	 */
	@Override
	public String getSkipSelectValidate() {
		return ConfigurationUtil.getConfigValue(activationFlowConfigService.skipSelectValidate(),
				CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}

	/**
	 * <p>
	 * Returns skip collect code provider
	 * </p>
	 *
	 * @return String - skipCollectCodeProvider
	 */
	@Override
	public String getSkipCollectCodeProvider() {
		return ConfigurationUtil.getConfigValue(activationFlowConfigService.skipCollectCodeProvider(),
				CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}
	

	/**
	 * <p>
	 * Returns true or false from activationFlowConfig
	 * </p>
	 * 
	 * @return String - EnableEsim
	 */
	@Override
	public String getEnableEsim() {
		return ConfigurationUtil.getConfigValue(activationFlowConfigService.getEnableEsim(),
				CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}

	/**
	 * <p>
	 * Returns fetch user trouble ticket
	 * </p>
	 * 
	 * @return String - fetchUserTroubleTickets
	 */
	@Override
	public String getFetchUserTroubleTickets() {
		return ConfigurationUtil.getConfigValue(activationFlowConfigService.fetchUserTroubleTickets(),
				CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}

	/**
	 * <p>
	 * Returns Check Eligibility Call Type
	 * </p>
	 * 
	 * @return String - checkEligibilityCallType
	 */
	@Override
	public String getCheckEligibilityCallType() {
		return ConfigurationUtil.getConfigValue(activationFlowConfigService.getCheckEligibilityCallType(),
				CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}

	/**
	 * <p>
	 * Returns errorCodeInvalidPin from activationFlowConfig
	 * </p>
	 * 
	 * @return String - errorCodeInvalidPin
	 */
	@Override
	public String getErrorCodeInvalidPin() {
		return activationFlowConfigService.getErrorCodeInvalidPin();
	}

	/**
	 * <p>
	 * Returns Default Service provider for BYOP
	 * </p>
	 * 
	 * @return String - defaultServiceProvider
	 */
	@Override
	public String getDefaultServiceProvider() {
		return ConfigurationUtil.getConfigValue(activationFlowConfigService.getDefaultServiceProvider(),
				CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}

	/**
	 * <p>
	 * Returns true or false from activationFlowConfig
	 * </p>
	 * 
	 * @return String - EnableEsim
	 */
	@Override
	public String getEnableEsimExternalPorts() {
		return ConfigurationUtil.getConfigValue(activationFlowConfigService.getEnableEsimExternalPorts(),
				CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}

	/**
	 * <p>
	 * Returns sim purchase required model id
	 * </p>
	 * 
	 * @return String - simPurchaseRequiredModalId
	 */
	@Override
	public String getSimPurchaseRequiredModalId() {
		if (StringUtils.isNotEmpty(ApplicationUtil.getLowerCaseWithHyphen(simPurchaseRequiredModalId))) {
			return ApplicationUtil.getLowerCaseWithHyphen(simPurchaseRequiredModalId) + ApplicationConstants.HYPHEN
					+ ApplicationConstants.MODAL;
		}
		return null;
	}

	/*
	 * @return String - redirecttoBYOPflow modal id
	 */
	@Override
	public String getRedirectToBYOPFlowModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(redirectToBYOPFlowModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}


	/*
	 * @return String - deviceNotEligibleForProgram25offer modal id
	 */
	@Override
	public String getDeviceNotEligibleForProgram25offeModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(deviceNotEligibleForProgram25offeModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}


	/*
	 * @return String - deviceNotEligibleForProgram25offer modal id
	 */
	@Override
	public String getBundleKitCannotBeUsed25offerModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(bundleKitCannotBeUsed25offerModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}
	
	

	/**
	 * <p>
	 * Returns true or false from activationFlowConfig
	 * </p>
	 * 
	 * @return String - DisableBrandedSimSelection
	 */
	@Override
	public String getDisableBrandedSimSelection() {
		return ConfigurationUtil.getConfigValue(activationFlowConfigService.getDisableBrandedSimSelection(),
				CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}

	/**
	 * <p>
	 * Returns esnIsActiveModalId from resource
	 * </p>
	 * 
	 * @return String - esnIsActiveModalId
	 */
	@Override
	public String getEsnIsActiveModalId() {
		if (StringUtils.isNotEmpty(ApplicationUtil.getLowerCaseWithHyphen(esnIsActiveModalId))) {
			return ApplicationUtil.getLowerCaseWithHyphen(esnIsActiveModalId) + ApplicationConstants.HYPHEN
					+ ApplicationConstants.MODAL;
		}
		return null;
	}

	@Override
	public String getVzwPhoneSimPdpPath() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), this.vzwPhoneSimPdpPath);
	}

	@Override
	public String getTmoPhoneSimPdpPath() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), this.tmoPhoneSimPdpPath);
	}

	@Override
	public String getVzwTabletSimPdpPath() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), this.vzwTabletSimPdpPath);
	}

	@Override
	public String getTmoTabletSimPdpPath() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), this.tmoTabletSimPdpPath);
	}

	@Override
	public String enableVZWFirst() {
		return ConfigurationUtil.getConfigValue(activationFlowConfigService.enableVZWFirst(),
				CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}

	/**
	 * <p>
	 * Fetches portInScreenChanges value from config
	 * </p>
	 *
	 * @return String - portInScreenChanges
	 */
	@Override
	public String getPortInScreenChanges() {
		return ConfigurationUtil.getConfigValue(brandSpecificConfigService.portInScreenChanges(),
		CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}

	/**
	 * <p>
	 * Returns riskAssesmentModalId from properties
	 * </p>
	 * 
	 * @return String - riskAssesmentModalId
	 */
	@Override
	public String getRiskAssesmentModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(riskAssesmentModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * <p>
	 * Returns true or false from activationFlowConfig
	 * </p>
	 * 
	 * @return String - enableByopDualImei
	 */
	@Override
	public String getEnableByopDualImei() {
		return ConfigurationUtil.getConfigValue(activationFlowConfigService.getEnableByopDualImei(),
				CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}


	/**
	 * <p>
	 * Returns true or false from activationFlowConfig
	 * </p>
	 * 
	 * @return String - enablePromoEligibility
	 */
	@Override
	public String getEnablePromoEligibility() {
		return ConfigurationUtil.getConfigValue(activationFlowConfigService.getEnablePromoEligibility(),
				CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}

	/*
	 * @return String - deviceNotEligibleForProgram25offer modal id
	 */
	@Override
	public String getUpdatebyop25offerModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(updatebyop25offerModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}
	
	/*
	 * @return String - deviceNotEligibleForProgram25offer modal id
	 */
	@Override
	public String getUpdatebranded25offerModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(updatebranded25offerModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}
	
	/**
	 * <p>
	 * Returns true or false from root page page properties
	 * </p>
	 * 
	 * @return String - disablePromoEligibility
	 */
	@Override
	public String getDisablePromoEligibilityFlag() {
		return CommerceUtil.getPropertiesFromRootPage(currentPage, CommerceConstants.DISABLE_PROMO_ELIGIBILITY_CALL);
	}
	
	/*
	 * @return String - EligibleForDCOT Upgrade for 45,55 and 65 modal id
	 */
	@Override
	public String getUpgradedcotpromotionModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(upgradedcotpromotionModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * <p>
	 * Returns msg for paymentCardRedeemMsgRichText
	 * </p>
	 * 
	 * @return String - Returns msg for paymentCardRedeemMsgRichText
	 */
	@Override
	public String getPaymentCardRedeemMsgRichText() {
		return paymentCardRedeemMsgRichText;
	}
	
	/** 
	 * @return String - Returns msg for getIncompatibleDeviceModalId
	 */
	@Override
	public String getIncompatibleDeviceModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(incompatibleDeviceModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * <p>
	 * Returns msg for invalidSimStatusModalId
	 * </p>
	 * 
	 * @return String - Returns msg for invalidSimStatusModalId
	 */
	@Override
	public String getInvalidSimStatusModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(invalidSimStatusModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/*
	 * @return String - getIncompatibleSIMModalValueBrands modal id
	 */
	@Override
	public String getIncompatibleSIMModalValueBrands() {
		return ApplicationUtil.getLowerCaseWithHyphen(incompatibleSIMModalValueBrands) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}
}
