package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.DiscountCardsBean;

public interface DiscountsAndBundlesModel extends ComponentExporter{
    /**
	 * <p>Fetches heading</p>
	 * 
	 * @return String - heading
	 */
	@JsonProperty("heading")
	public String getHeading();
	/**
	 * <p>Fetches subheading</p>
	 * 
	 * @return String - subheading
	 */
	@JsonProperty("subheading")
	public String getSubheading();
    /**
	 * <p>Fetches footer text</p>
	 * 
	 * @return String - footerText
	 */
	@JsonProperty("footerText")
	public String getFooterText();
    /**
	 * <p>Fetches cards list</p>
	 * 
	 * @return String - cardsList
	 */
	@JsonProperty("cardsList")
	public List<DiscountCardsBean> getCardsList();

}