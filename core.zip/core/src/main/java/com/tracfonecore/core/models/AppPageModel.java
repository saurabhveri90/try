/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public interface AppPageModel {


	/**
	 * <p>Fetches client name</p>
	 *
	 * @return String - client name
	 */
	@JsonProperty("clientName")
	public String getClientName();

	/**
	 * <p>Fetches site ID</p>
	 *
	 * @return String - site ID
	 */
	@JsonProperty("siteId")
	public String getSiteId();

	/**
	 * <p>Fetches environment</p>
	 *
	 * @return String - environment
	 */
	@JsonProperty("environment")
	public String getEnvironment();

	/**
	 * <p>Fetches locale</p>
	 *
	 * @return String - locale
	 */
	@JsonProperty("locale")
	public String getLocale();
}