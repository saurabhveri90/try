/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.SimExchangeConfirmationModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = {
		SimExchangeConfirmationModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/simexchangeconfirmation", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class SimExchangeConfirmationModelImpl implements SimExchangeConfirmationModel {

	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headerTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String orderConfirmationMessage1;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String orderConfirmationMessage2;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ticketNumberMessage1;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ticketNumberMessage2;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ticketNumberLabel;

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Fetches header title
	 * </p>
	 * 
	 * @return String - headerTitle
	 */
	@Override
	public String getHeaderTitle() {
		return headerTitle;
	}

	/**
	 * <p>
	 * Fetches Order Confirmation Message1
	 * </p>
	 * 
	 * @return String - orderConfirmationMessage1
	 */
	@Override
	public String getOrderConfirmationMessage1() {
		return orderConfirmationMessage1;
	}

	/**
	 * <p>
	 * Fetches Order Confirmation Message2
	 * </p>
	 * 
	 * @return String - orderConfirmationMessage2
	 */
	@Override
	public String getOrderConfirmationMessage2() {
		return orderConfirmationMessage2;
	}

	/**
	 * <p>
	 * Fetches Ticket Number Message1
	 * </p>
	 * 
	 * @return String - ticketNumberMessage1
	 */
	@Override
	public String getTicketNumberMessage1() {
		return ticketNumberMessage1;
	}

	/**
	 * <p>
	 * Fetches Ticket Number Message2
	 * </p>
	 * 
	 * @return String - ticketNumberMessage2
	 */
	@Override
	public String getTicketNumberMessage2() {
		return ticketNumberMessage2;
	}

	/**
	 * <p>
	 * Fetches Ticket Number Label
	 * </p>
	 * 
	 * @return String - ticketNumberLabel
	 */
	@Override
	public String getTicketNumberLabel() {
		return ticketNumberLabel;
	}

}
