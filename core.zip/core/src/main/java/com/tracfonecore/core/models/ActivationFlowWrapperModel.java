/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code ActivationFlowWrapperModel} Sling Model used for the
 * {@code /apps/tracfone-core/components/commerce/activationflowwrapper}
 * component.
 */
public interface ActivationFlowWrapperModel extends ComponentExporter {

	/**
	 * <p>
	 * get Primary Activation flow
	 * </p>
	 *
	 * @return String - primaryFlow
	 */
	public String getPrimaryFlowSteps();

	/**
	 * <p>
	 * get Activation Secondary flow
	 * </p>
	 *
	 * @return String - secondaryFlow
	 */
	public String getSecondaryFlowSteps();

	/**
	 * <p>
	 * get activation flow
	 * </p>
	 *
	 * @return String - xf path
	 */
	public String getAllXfPaths();

	public String getCartPath();

	public String getPurchaseFlowSteps();

	/**
	 * Get BYOP Registration Flow Steps
	 *
	 * @return String - byopRegistrationFlowSteps
	 */
	public String getByopRegistrationFlowSteps();

	/**
	 * Get BYOT Registration Flow Steps
	 *
	 * @return String - byotRegistrationFlowSteps
	 */
	public String getByotRegistrationFlowSteps();

	public String getLoginPath();

	public String getConfirmationPath();

	public String getErrorCodeUnqualifiedHPP();

	/**
	 * Get the hotFlashModalId
	 * 
	 * @return String - hotFlashModalId
	 */
	public String getHotFlashModalId();

	/**
	 * Get the coldFlashModalId
	 * 
	 * @return String - coldFlashModalId
	 */
	public String getColdFlashModalId();

	/**
	 * Get the resource Mgmt Projection
	 * 
	 * @return String - resourceMgmtProjection
	 */
	public String getResourceMgmtProjection();

	/**
	 * Get the esnActivatedStatusCode
	 * 
	 * @return String - esnActivatedStatusCode
	 */
	public String getEsnActivatedStatusCode();

	/**
	 * Get the esnStolenStatusCode
	 * 
	 * @return String - esnStolenStatusCode
	 */
	public String getEsnStolenStatusCode();

	/**
	 * Get the esnRiskCheckStatusCode
	 * 
	 * @return esnRiskCheckStatusCode
	 */
	public String getEsnRiskCheckStatusCode();

	/**
	 * Get the esnActivatedRedirectLink
	 * 
	 * @return String - esnActivatedRedirectLink
	 */
	public String getEsnActivatedRedirectLink();

	/**
	 * Get the esnUsedLineStatusCode
	 * 
	 * @return String - esnUsedLineStatusCode
	 */
	public String getEsnUsedLineStatusCode();

	/**
	 * Get the esnPastDueStatusCode
	 * 
	 * @return String - esnPastDueStatusCode
	 */
	public String getEsnPastDueStatusCode();

	/**
	 * Get the ZipHardCoded
	 * 
	 * @return String - ZipHardCoded
	 */
	public String getZipHardCoded();

	/**
	 * Get the Address Validation Modal Id
	 * 
	 * @return String - addressValidationModalId
	 */
	public String getAddressValidationModalId();

	/**
	 * Get the EsnNewStatusCode
	 * 
	 * @return String - EsnNewStatusCode
	 */
	public String getEsnNewStatusCode();

	/**
	 * Get the EsnRefurbishedStatusCode
	 * 
	 * @return String - EsnRefurbishedStatusCode
	 */
	public String getEsnRefurbishedStatusCode();

	/**
	 * Get the Sim Not Needed Modal Id
	 *
	 * @return String - getSimNotNeededModalId
	 */
	public String getSimNotNeededModalId();
	
	/**
	 * Get the Byop Sim Eligible for offer Modal Id
	 *
	 * @return String - getByopSimEligibleModalId
	 */
	public String getByopSimEligibleModalId();
	

	/**
	 * Get the Guest Line Locked Modal Id
	 *
	 * @return String - getGuestLineLockedModalId
	 */
    public String getGuestLineLockedModalId();

	/**
	 * Get the Guest Line Unlocked Modal Id
	 *
	 * @return String - getGuestLineUnlockedModalId
	 */
    public String getGuestLineUnlockedModalId();

	/**
	 * Get the Auth Line Locked Modal Id
	 *
	 * @return String - getAuthLineLockedModalId
	 */
    public String getAuthLineLockedModalId();

	/**
	 * Get the Auth Line Unlocked Modal Id
	 *
	 * @return String - getAuthLineUnlockedModalId
	 */
     public String getAuthLineUnlockedModalId();   

	/**
	 * Get the Line Locked Modal Id in Internal Flow
	 *
	 * @return String - getLineLockedInternalFlowModalId
	 */
     public String getLineLockedInternalFlowModalId();

	/**
	 * Get the Error, Can't Continue Modal Id
	 *
	 * @return String - getErrorCantContinueModalId
	 */
	public String getErrorCantContinueModalId();

	/**
	 * Get the resource Mgmt Projection for BYOP
	 * 
	 * @return String - byopResourceMgmtProjection
	 */
	public String getByopResourceMgmtProjection();

	/**
	 * Get the resource Mgmt Projection for BYOT
	 *
	 * @return String - byotResourceMgmtProjection
	 */
	public String getByotResourceMgmtProjection();

	/**
	 * Get Shipping Address page path
	 * 
	 * @return String - shippingAddressPath
	 */
	public String getShippingAddressPath();

	/**
	 * Get Upgrade Success Scenarios
	 * 
	 * @return String - upgradeSuccessScenarios
	 */
	public String getUpgradeSuccessScenarios();

	/**
	 * Get Upgrade Check Obj Scenarios
	 * 
	 * @return String - upgradeCheckObjScenarios
	 */
	public String getUpgradeCheckObjScenarios();

	/**
	 * Get Upgrade Error Scenarios
	 * 
	 * @return String - upgradeErrorScenarios
	 */
	public String getUpgradeErrorScenarios();

	/**
	 * Get Progress Bar Title
	 */
	public String getProgressBarTitle();

	/**
	 * Get BYOP Standalone Registration Step
	 */
	public String getByopStandaloneRegStep();

	/**
	 * Get BYOT Standalone Registration Step
	 */
	public String getByotStandaloneRegStep();

	/**
	 * Get Active Device Agreement Modal ID
	 */
	public String getActiveDeviceAgreementModalId();

	/**
	 * @return the imeiNotEligibleModalId
	 */
	public String getImeiNotEligibleModalId();

	/**
	 * @return the cusg enable check
	 */
	public String getCusgEnable();

	/**
	 * @return the skip device type screen flag
	 */
	public String getSkipDeviceTypeScreen();

	/**
	 * @return the skip for select validate
	 */
	public String getSkipSelectValidate();

	/**
	 * @return the skip for select validate
	 */
	public String getSkipCollectCodeProvider();
	

	/**
	 * @return the imeiNotEligibleForATTModalId
	 */
	public String getImeiNotEligibleForATTModalId();

	/**
	 * 
	 * @return String - true or false
	 */
	public String getEnableEsim();

	/**
	 * @return the fetch user ticket
	 */
	public String getFetchUserTroubleTickets();

	/**
	 * @return the Check Eligibility Call Type
	 */
	public String getCheckEligibilityCallType();

	/**
	 * Get the Byop Eligible Success Modal Id
	 *
	 * @return String - getByopEligibleSuccessModalId
	 */
	public String getByopEligibleSuccessModalId();

	/**
	 * 
	 * @return String - error code for invalid PIN
	 */
	public String getErrorCodeInvalidPin();

	/**
	 * Get the Byop default service provider
	 *
	 * @return String - getDefaultServiceProvider
	 */
	public String getDefaultServiceProvider();

	/**
	 * 
	 * @return String - true or false
	 */
	public String getEnableEsimExternalPorts();

	/**
	 * Get the sim purchase required Modal Id
	 *
	 * @return String - getsimPurchaseRequiredModalId
	 */
	public String getSimPurchaseRequiredModalId();

	/**
	 * Get the modal id
	 * 
	 * @return String - esnIsActiveModalId
	 */
	public String getEsnIsActiveModalId();

	/**
	 * Get VZW-Sim PDP Page Path
	 *
	 * @return String - getVzwPhoneSimPdpPath
	 */
	public String getVzwTabletSimPdpPath();

	/**
	 * Get VZW Sim PDP Page Path
	 *
	 * @return String - getTmoPhoneSimPdpPath
	 */
	public String getTmoTabletSimPdpPath();

	/**
	 * Get VZW Sim PDP Page Path
	 *
	 * @return String - getVzwPhoneSimPdpPath
	 */
	public String getVzwPhoneSimPdpPath();

	/**
	 * Get VZW Sim PDP Page Path
	 *
	 * @return String - getTmoPhoneSimPdpPath
	 */
	public String getTmoPhoneSimPdpPath();

	/**
	 * Get flag for alternate carrier BYOP check
	 *
	 * @return String - enableVZWFirst
	 */
	public String enableVZWFirst();


	/**
	 * 
	 * @return String - modalid
	 */
	public String getRedirectToBYOPFlowModalId();
    

	/**
	 * 
	 * @return String - modalid
	 */
	public String getDeviceNotEligibleForProgram25offeModalId();


	/**
	 * 
	 * @return String - modalid
	 */
	public String getBundleKitCannotBeUsed25offerModalId();


	/**
	 * 
	 * @return String - true or false
	 */
	public String getDisableBrandedSimSelection();

	/**
	 * @return portInScreenChanges
	 */
	public String getPortInScreenChanges();


	/**
	 * Get the riskAssesmentModalId
	 * 
	 * @return String - riskAssesmentModalId
	 */
	public String getRiskAssesmentModalId();

	/**
	 * 
	 * @return String - true or false
	 */
	public String getEnableByopDualImei();


	/**
	 * 
	 * @return String - true or false
	 */
	public String getEnablePromoEligibility();


	/**
	 * 
	 * @return String - modalid
	 */
	public String getUpdatebyop25offerModalId();


	/**
	 * 
	 * @return String - modalid
	 */
	public String getUpdatebranded25offerModalId();


	/**
	 * 
	 * @return String - modalid
	 */
	public String getPromoEligibility25PartNumber();

	/**
	 * <p>
	 * Returns true or false from root page page properties
	 * </p>
	 * 
	 * @return String - disablePromoEligibility
	 */
	public String getDisablePromoEligibilityFlag();

	/**
	 * <p>
	 * Returns msg for paymentCardRedeemMsgRichText
	 * </p>
	 * 
	 * @return String - paymentCardRedeemMsgRichText
	 */
	public String getPaymentCardRedeemMsgRichText();
	
	/**
	 * <p>
	 * Returns modal id byopNotCompatibilityModal
	 * </p>
	 * 
	 * @return String - byopNotCompatibilityModal
	 */
	public String getIncompatibleDeviceModalId();
	
    /**
	 * 
	 * @return String - modalid
	 */
	public String getUpgradedcotpromotionModalId();

	/**
	 * 
	 * @return String - incompatibleSIMModalValueBrands
	 */
	public String getIncompatibleSIMModalValueBrands();

	/**
	 * <p>
	 * Returns modal id InvalidSimStatusModalId
	 * </p>
	 * 
	 * @return String - InvalidSimStatusModalId
	 */
	public String getInvalidSimStatusModalId();
}
