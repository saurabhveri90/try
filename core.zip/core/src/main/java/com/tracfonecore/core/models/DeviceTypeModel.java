/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;


import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Map;

/**
 * Defines the {@code New Line} Sling Model used for the {@code /apps/tracfone-core/components/commerce/deviceType} component.
 */
public interface DeviceTypeModel extends ComponentExporter {

	
	/**
	 * <p>Fetches title for Device Type</p>
	 * 
	 * @return String - title for Device Type
	 */
	@JsonProperty("title")
	public String getTitle();
	
	/**
	 * <p>Fetches subtitle for Device Type</p>
	 * 
	 * @return String - subtitle for Device Type
	 */
	@JsonProperty("subTitle")
	public String getSubTitle();

	/**
	 * <p>Fetches device Category Title for Device Type</p>
	 * 
	 * @return String - device Category Title for Device Type
	 */
	@JsonProperty("deviceCategoryTitle")
	public String getDeviceCategoryTitle();
	
	/**
	 * <p>Fetches items Count for Device Type</p>
	 * 
	 * @return int - items Count for Device Type
	 */
	@JsonProperty("itemsCount")
	public int getItemsCount();
		
	/**
	  * <p>
	 * Fetches the export child items
	 * </p>
	 *
	 * 
	 * @return Map<String, ? extends ComponentExporter> - the export child items
	 */
	public Map<String, ? extends ComponentExporter> getItems();
	/**
	 * <p>
	 * Fetches totalItemsList
	 * </p>
	 *
	 * @return the totalItemsList
	 */
	public List<Integer> getTotalItemsList();

	/**
	 * <p>Fetches Background image Path for Device Type</p>
	 * 
	 * @return String - Background image Path for Device Type
	 */
	@JsonProperty("backgroundImagePath")
	public String getBackgroundImagePath();
		
}
