/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

public interface CommunicationPreferencesModel extends ComponentExporter {

	@JsonProperty("positionCommunicationPreferences")
	public String getPositionCommunicationPreferences();
	
	@JsonProperty("positionAccountNavigation")
	public String getPositionAccountNavigation();
	
	@JsonProperty("declarationText")
	public String getDeclarationText();
	
	@JsonProperty("submitRequestLink")
	public String getSubmitRequestLink();

	@JsonProperty("yourPrivacyChoicesLink")
	public String getYourPrivacyChoicesLink();
	
	@JsonProperty("checkStatusLink")
	public String getCheckStatusLink();
	
	@JsonProperty("openNewTabSubmitRequestLink")
	public String getOpenNewTabSubmitRequestLink();

	@JsonProperty("openNewTabYourPrivacyChoicesLink")
	public String getOpenNewTabYourPrivacyChoicesLink();
	
	@JsonProperty("openNewTabCheckStatusLink")
	public String getOpenNewTabCheckStatusLink();
	
}
