package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.DeEnrollmentReasonsBean;

public interface CheckBalanceModel extends ComponentExporter {

	@JsonProperty("plansPlpPagePath")
	public String getPlansPlpPagePath();

	/**
	 * @return the categoryIdPlans
	 */
	@JsonProperty("categoryIdPlans")
	public String getCategoryIdPlans();

	/**
	 * @return the nextChargeDateILDValue
	 */
	@JsonProperty("nextChargeDateILDValue")
	public String getNextChargeDateILDValue();

	/**
	 * @return the nextChargeDateILDText
	 */
	@JsonProperty("nextChargeDateILDText")
	public String getNextChargeDateILDText();

	/**
	 * @return the addOnILDText
	 */
	@JsonProperty("addOnILDText")
	public String getAddOnILDText();

	/**
	 * @return the planDetailHeading
	 */
	@JsonProperty("planDetailHeading")
	public String getPlanDetailHeading();

	/**
	 * @return the serviceEndDateText
	 */
	@JsonProperty("serviceEndDateText")
	public String getServiceEndDateText();

	/**
	 * @return the joinAutoRefilText
	 */
	@JsonProperty("joinAutoRefilText")
	public String getJoinAutoRefilText();

	/**
	 * @return the refillNowText
	 */
	@JsonProperty("refillNowText")
	public String getRefillNowText();

	/**
	 * @return the dropDownPlaceHolder
	 */
	@JsonProperty("dropDownPlaceHolder")
	public String getDropDownPlaceHolder();

	/**
	 * @return the switchButtonILDText
	 */
	@JsonProperty("switchButtonILDText")
	public String getSwitchButtonILDText();

	/**
	 * @return the heading
	 */
	@JsonProperty("heading")
	public String getHeading();

	/**
	 * @return the autoRefillHomePagePath
	 */
	@JsonProperty("autoRefillHomePagePath")
	public String getAutoRefillHomePagePath();

	/**
	 * @return the refillHomePagePath
	 */
	@JsonProperty("refillHomePagePath")
	public String getRefillHomePagePath();

	/**
	 * @return the globalCallingCardPDPPagePath
	 */
	@JsonProperty("globalCallingCardPDPPagePath")
	public String getGlobalCallingCardPDPPagePath();

	/**
	 * @return the planAutoRefillMessageMapping
	 */
	@JsonProperty("planAutoRefillMessageMapping")
	public List<CheckBalanceOptionsModel> getPlanAutoRefillMessageMapping();

	/**
	 * @return the planAutoRefillDefaultMessage
	 */
	@JsonProperty("planAutoRefillDefaultMessage")
	public String getPlanAutoRefillDefaultMessage();

	/**
	 * @return the titleRefillWithPinForPlan
	 */
	@JsonProperty("titleRefillWithPinForPlan")
	public String getTitleRefillWithPinForPlan();

	/**
	 * @return the paragraphRefillWithPinForPlan
	 */
	@JsonProperty("paragraphRefillWithPinForPlan")
	public String getParagraphRefillWithPinForPlan();

	/**
	 * @return the titleCancelEnrollmentForPlan
	 */
	@JsonProperty("titleCancelEnrollmentForPlan")
	public String getTitleCancelEnrollmentForPlan();

	/**
	 * @return the paragraphCancelEnrollmentForPlan
	 */
	@JsonProperty("paragraphCancelEnrollmentForPlan")
	public String getParagraphCancelEnrollmentForPlan();

	/**
	 * @return the titleRefillWithPinForILD
	 */
	@JsonProperty("titleRefillWithPinForILD")
	public String getTitleRefillWithPinForILD();

	/**
	 * @return the paragraphRefillWithPinForILD
	 */
	@JsonProperty("paragraphRefillWithPinForILD")
	public String getParagraphRefillWithPinForILD();

	/**
	 * @return the titleCancelEnrollmentForILD
	 */
	@JsonProperty("titleCancelEnrollmentForILD")
	public String getTitleCancelEnrollmentForILD();

	/**
	 * @return the paragraphCancelEnrollmentForILD
	 */
	@JsonProperty("paragraphCancelEnrollmentForILD")
	public String getParagraphCancelEnrollmentForILD();

	/**
	 * @return the ildPlanName
	 */
	@JsonProperty("ildPlanName")
	public String getIldPlanName();


	/**
	 * @return the ildPlanPrice
	 */
	@JsonProperty("ildPlanPrice")
	public String getIldPlanPrice();


		/**
	 * @return the ildPlanPartNumber
	 */
	@JsonProperty("ildPlanPartNumber")
	public String getIldPlanPartNumber();

	/**
	 * @return the ildPlanEditCartUrl
	 */
	@JsonProperty("ildPlanEditCartUrl")
	public String getIldPlanEditCartUrl();

	/**
	 * @return the textHowDoesItWorkModal
	 */
	@JsonProperty("textHowDoesItWorkModal")
	public String getTextHowDoesItWorkModal();

	/**
	 * @return the planDetailsEditCartUrl
	 */
	@JsonProperty("planDetailsEditCartUrl")
	public String getPlanDetailsEditCartUrl();

	/**
	 * @return the refillPLPPagePath
	 */
	@JsonProperty("refillPLPPagePath")
	public String getRefillPLPPagePath();

	/**
	 * @return the refillStartDateSelector
	 */
	@JsonProperty("refillStartDateSelector")
	public String getRefillStartDateSelector();

	/**
	 * @return the benefitChangeOptionsForPlan
	 */
	@JsonProperty("benefitChangeOptionsForPlan")
	public List<CheckBalanceOptionsModel> getBenefitChangeOptionsForPlan();

	/**
	 * @return the benefitChangeOptionsForILD
	 */
	@JsonProperty("benefitChangeOptionsForILD")
	public List<CheckBalanceOptionsModel> getBenefitChangeOptionsForILD();

	/**
	 * @return the refillPLPPageSelector
	 */
	@JsonProperty("refillPLPPageSelector")
	public String getRefillPLPPageSelector();
	
	/**
	 * @return the refillBuyNowPLPPageSelector
	 */
	@JsonProperty("refillBuyNowPLPPageSelector")
	public String getRefillBuyNowPLPPageSelector();

	/**
	 * @return the titleBenefitChangesModalForILD
	 */
	@JsonProperty("titleBenefitChangesModalForILD")
	public String getTitleBenefitChangesModalForILD();

	/**
	 * @return the subTitleBenefitChangesModalForILD
	 */
	@JsonProperty("subTitleBenefitChangesModalForILD")
	public String getSubTitleBenefitChangesModalForILD();

	/**
	 * @return the titleBenefitChangesModalForPlan
	 */
	@JsonProperty("titleBenefitChangesModalForPlan")
	public String getTitleBenefitChangesModalForPlan();

	/**
	 * @return the subTitleBenefitChangesModalForPlan
	 */
	@JsonProperty("subTitleBenefitChangesModalForPlan")
	public String getSubTitleBenefitChangesModalForPlan();

	/**
	 * @return the redeemPlanModalHeadline
	 */
	@JsonProperty("redeemPlanModalHeadline")
	public String getRedeemPlanModalHeadline();

	/**
	 * @return the redeemPlanModalSubheadline
	 */
	@JsonProperty("redeemPlanModalSubheadline")
	public String getRedeemPlanModalSubheadline();
	
	@JsonProperty("selectAutoRefillAndSaveMessage")
	public String getSelectAutoRefillAndSaveMessage();
	
	@JsonProperty("enableAmazonPrime")
	public Boolean getEnableAmazonPrime();
	
	@JsonProperty("amazonEnrollmentInfoModalContent")
	public String getAmazonEnrollmentInfoModalContent();
	
	@JsonProperty("planServiceEndDateInfoModalContent")
	public String getPlanServiceEndDateInfoModalContent();
	
	@JsonProperty("titleCusgDiscountAlert")
	public String getTitleCusgDiscountAlert();
	
	@JsonProperty("paragraphCusgDiscountAlert")
	public String getParagraphCusgDiscountAlert();
	
	@JsonProperty("editGroupNameModalHeadline")
	public String getEditGroupNameModalHeadline();
	
	@JsonProperty("editGroupNameModalSubheadline")
	public String getEditGroupNameModalSubheadline();
	
	@JsonProperty("addOnPlanCardInfoText")
	public String getAddOnPlanCardInfoTextt();
	
	@JsonProperty("addOnPlanImage")
	public String getAddOnPlanImage();
	
	@JsonProperty("addOnPlanEditCartUrl")
	public String getAddOnPlanEditCartUrl();
	
	@JsonProperty("deEnrollmentReasons")
	public List<DeEnrollmentReasonsBean> getDeEnrollmentReasons();

	@JsonProperty("enableLoginWithVerificationCode")
	public String getEnableLoginWithVerificationCode();
	
}
