/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;


import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface LearnMoreModel extends ComponentExporter {

	/**
	 * <p>Fetches dispalyType</p>
	 * 
	 * @return String - dispalyType
	 */
	@JsonProperty("displayType")
	public String getDisplayType();

	/**
	 * <p>Fetches title</p>
	 * 
	 * @return String - title
	 */
	@JsonProperty("title")
	public String getTitle();

	/**
	 * <p>Fetches description in default view</p>
	 * 
	 * @return String - description
	 */
	@JsonProperty("description")
	public String getDescription();
	
	/**
	 * <p>Fetches description in error view</p>
	 * 
	 * @return String - error description 
	 */
	@JsonProperty("errorDescription")
	public String getErrorDescription();
	/**
	 * <p>Fetches modal name</p>
	 * 
	 * @return String - modalName
	 */
	@JsonProperty("modalName")
	public String getModalName();
	
	/**
	 * <p>Fetches doNotUseReference</p>
	 * 
	 * @return String - doNotUseReference
	 */
	@JsonProperty("doNotUseReference")
	public String getDoNotUseReference();
	/**
	 *<p>Fetches modalId</p>
	 *
	 * @return the modalId
	 */
	public String getModalId();
	/**
	 *<p>Fetches accessibilityLabel</p>
	 *
	 * @return the accessibilityLabel
	 */
	public String getAccessibilityLabel();
	/**
	 * <p>Fetches addImage</p>
	 *
	 * @return Boolean - addImage
	 */
	@JsonProperty("addImage")
	public String getAddImage();
	
	/**
	  * <p>
	 * Fetches the export child items
	 * </p>
	 *
	 * 
	 * @return Map<String, ? extends ComponentExporter> - the export child items
	 */
	public Map<String, ? extends ComponentExporter> getItems();

	/**
	 * <p>Fetches doNotUseGenericModelClass</p>
	 *
	 * @return boolean - doNotUseGenericModelClass
	 */
	@JsonProperty("doNotUseGenericModelClass")
	default boolean isDoNotUseGenericModelClass() {
		return false;
	}
	
	/**
	 *<p>Fetches ctaType</p>
	 *
	 * @return the ctaType
	 */
	@JsonProperty("ctaType")
	default String getCtaType() {
		return null;
	}
	
	/**
	 *<p>Fetches placementText</p>
	 *
	 * @return the gtm placement text
	 */
	@JsonProperty("placementText")
	public String getPlacementText();
	/**
	 *<p>Fetches accessibility Text</p>
	 *
	 * @return the accessibility text
	 */
	@JsonProperty("accessibilityText")
	public String getAccessibilityText();	
	
	/**
	 * <p>Fetches button type for suggested shipping address</p>
	 * 
	 * @return String - buttonType
	 */
	@JsonProperty("buttonType")
	public String getButtonType();
	
	/**
	 * <p>Fetches hideClose</p>
	 *
	 * @return boolean - hideClose
	 */
	@JsonProperty("hideClose")
	default boolean getHideClose() {
		return false;
	}

	/**
	 * <p>Fetches displayCTAsInNewLine</p>
	 *
	 * @return boolean - displayCTAsInNewLine
	 */
	@JsonProperty("displayCTAsInNewLine")
	default boolean getDisplayCTAsInNewLine() {
		return false;
	}

	/**
	 * <p>
	 * Fetches doNotUseBaseStructureClass
	 * </p>
	 *
	 * @return boolean - doNotUseBaseStructureClass
	 */
	@JsonProperty("doNotUseBaseStructureClass")
	default boolean isDoNotUseBaseStructureClass() {
		return false;
	}

	/**
	 * <p>Fetches Accessibility heading</p>
	 * 
	 * @return String - heading
	 */
	@JsonProperty("accessibilityHeading")
	public String getHeading();

}