/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;

/**
 * <p>Defines bean to hold payment options</p>
 */
/**
 * @author saurabh_kumar1
 *
 */
public class PaymentOptionBean {

	private String paymentOptionId;
	private String paymentOptionName;
	private String paymentOptionLogo;
	private String paymentOptionLogoAltText;

	/**
	 * <p>Fetches id of paymentOption</p>
	 * 
	 * @return String - paymentOptionId
	 */
	public String getPaymentOptionId() {
		return paymentOptionId;
	}

	/**
	 * <p>Sets id of payment option</p>
	 * 
	 * @param paymentOptionId - id of payment option
	 */
	public void setPaymentOptionId(String paymentOptionId) {
		this.paymentOptionId = paymentOptionId;
	}
	
	/**
	 * <p>Fetches name of payment option</p>
	 * 
	 * @return String - paymentOptionName
	 */
	public String getPaymentOptionName() {
		return paymentOptionName;
	}

	/**
	 * <p>Sets Payment Option Name </p>
	 * 
	 * @param paymentOptionName - Payment Option Name 
	 */
	public void setPaymentOptionName(String paymentOptionName) {
		this.paymentOptionName = paymentOptionName;
	}
	
	/**
	 * <p>Fetches Payment Option Name </p>
	 * 
	 * @return String - paymentOptionLogo
	 */
	public String getPaymentOptionLogo() {
		return paymentOptionLogo;
	}
	
	/**
	 * <p>Sets paymentOptionLogo</p>
	 * 
	 * @param paymentOptionLogo - Payment Option Logo  
	 */
	public void setPaymentOptionLogo(String paymentOptionLogo) {
		this.paymentOptionLogo = paymentOptionLogo;
	}
	
	/**
	 * <p>Fetches paymentOptionLogoAltText </p>
	 * 
	 * @return String - paymentOptionLogoAltText
	 */
	public String getPaymentOptionLogoAltText() {
		return paymentOptionLogoAltText;
	}
	
	/**
	 * <p>Sets  paymentOptionLogoAltText</p>
	 * 
	 * @param paymentOptionLogoAltText - Payment Option Logo Alt Text 
	 */
	public void setPaymentOptionLogoAltText(String paymentOptionLogoAltText) {
		this.paymentOptionLogoAltText = paymentOptionLogoAltText;
	}

	
}
