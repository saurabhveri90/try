/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;


import javax.annotation.PostConstruct;

import com.tracfonecore.core.constants.ApplicationConstants;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.AppDownloadModel;
import com.tracfonecore.core.utils.ApplicationUtil;


@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { AppDownloadModel.class,ComponentExporter.class }, 
resourceType = "tracfone-core/components/content/appdownload", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, 
extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = { 
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class AppDownloadModelImpl implements AppDownloadModel {

	@Self
	private SlingHttpServletRequest request;
	
	@ValueMapValue
	private String fileReference;
	
	@ValueMapValue
	private String heading;
	
	@ValueMapValue
	private String altText;
	
	@ValueMapValue
	private String appstore;
	
	@ValueMapValue
	private String appstorealttext;
	
	@ValueMapValue
	private String donotfollowappstore;
	
	@ValueMapValue
	private String playstore;
	
	@ValueMapValue
	private String playstorealttext;
	
	@ValueMapValue
	private String donotfollowplaystore;
	
	@ValueMapValue
	private String appstoreFileReference;
	
	@ValueMapValue
	private String playstoreFileReference;
	
    @ValueMapValue  
    private String description;
    
    @ValueMapValue  
    private Boolean enableSeeDetails;
    
    @ValueMapValue  
    private String seeDetailsText;
    
    @ValueMapValue  
    private String hideDetailsText;
    
    @ValueMapValue  
    private String seeDetailsDescription;
    
    @ValueMapValue  
    private Boolean enableCtaButton;
    
    @ValueMapValue  
    private Boolean enableAppAndCtaButton;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AppDownloadModelImpl.class);
	
	@PostConstruct
	protected void initModel() {
		LOGGER.debug(" Entering initModel method");
		this.setDonotfollowappstore(ApplicationUtil.getNoFollow(donotfollowappstore));
		this.setDonotfollowplaystore(ApplicationUtil.getNoFollow(donotfollowplaystore));
		LOGGER.debug(" Exiting initModel method");
	}

	@Override
	public String getFileReference() {
		return fileReference;
	}

	@Override
	public String getAltText() {
		return altText;
	}
	@Override
	public String getHeading() {
		return heading;
	}
	@Override
	public String getAppstore() {
		return appstore;
	}
	@Override
	public String getAppstorealttext() {
		return appstorealttext;
	}
	@Override
	public String getDonotfollowappstore() {
		return donotfollowappstore;
	}
	@Override
	public String getPlaystore() {
		return playstore;
	}
	@Override
	public String getPlaystorealttext() {
		return playstorealttext;
	}
	@Override
	public String getDonotfollowplaystore() {
		return donotfollowplaystore;
	}
	@Override
	public String getAppstoreFileReference() {
		return appstoreFileReference;
	}
	@Override
	public String getPlaystoreFileReference() {
		return playstoreFileReference;
	}
	@Override
	public String getAppstoreLogoPathAssetId() {
		return ApplicationUtil.getAssetId(appstoreFileReference,
				request.getResourceResolver(), ApplicationConstants.IMAGE);
	}

	@Override
	public String getAppstoreLogoPathAssetAgencyId() {
		return ApplicationUtil.getAssetMetaDataValue(appstoreFileReference,
				request.getResourceResolver(), ApplicationConstants.WEBER_ID);
	}
	@Override
	public String getPlaystoreLogoPathAssetId() {
		return ApplicationUtil.getAssetId(playstoreFileReference,
				request.getResourceResolver(), ApplicationConstants.IMAGE);
	}

	@Override
	public String getPlaystoreLogoPathAssetAgencyId() {
		return ApplicationUtil.getAssetMetaDataValue(playstoreFileReference,
				request.getResourceResolver(), ApplicationConstants.WEBER_ID);
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	public void setDonotfollowappstore(String donotfollowappstore) {
		this.donotfollowappstore = donotfollowappstore;
	}

	public void setDonotfollowplaystore(String donotfollowplaystore) {
		this.donotfollowplaystore = donotfollowplaystore;
	}

    @Override
    public String getDescription() {
        return description;
    }
    
    @Override
    public boolean getEnableSeeDetails() {
        return enableSeeDetails;
    }
    
    @Override
    public String getSeeDetailsText() {
        return seeDetailsText;
    }
    
    @Override
    public String getHideDetailsText() {
        return hideDetailsText;
    }
    
    @Override
    public String getSeeDetailsDescription() {
        return seeDetailsDescription;
    }
    
    @Override
    public boolean getEnableCtaButton() {
        return enableCtaButton;
    }
    
    @Override
    public boolean getEnableAppAndCtaButton() {
        return enableAppAndCtaButton;
    }

}