package com.tracfonecore.core.constants;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public final class FccMapConstants {

    private static final Map<String, String> FCC_LABEL_API_FIELD_MAPPING = new TreeMap<>();
    
    private static final Map<String, String> FCC_CONSTANTS_PROPERTIES = new TreeMap<>();

    private static final Map<String, String> FCC_CONSTANTS_PROPERTIES_ES = new TreeMap<>();

    private static final Map<String, String[]> FCC_KEYS_MAP = new LinkedHashMap<>();

	private static final List<String> PROPERTIES_TEMPLATE_LEVEL = new ArrayList<>();

	
	static {
		FCC_LABEL_API_FIELD_MAPPING.put("brand", "brandHeading");
		FCC_LABEL_API_FIELD_MAPPING.put("partClass", "clfyPartClass");
		FCC_LABEL_API_FIELD_MAPPING.put("planIds", "planId");
		FCC_LABEL_API_FIELD_MAPPING.put("isAcpEligible", "participatesInTheAcpValue");
		FCC_LABEL_API_FIELD_MAPPING.put("monthlyPrice", "monthlyPlanPriceValue");
		FCC_LABEL_API_FIELD_MAPPING.put("partNumber", "clfyPartNumber");
		FCC_LABEL_API_FIELD_MAPPING.put("broadBandPlanType", "broadbandType");
		FCC_LABEL_API_FIELD_MAPPING.put("planDescription", "apiPlanDescription");
		FCC_LABEL_API_FIELD_MAPPING.put("providerMonthlyFeeOtherAmt", "providerMonthlyFeesValue");
		FCC_LABEL_API_FIELD_MAPPING.put("providerMonthlyFeeFusf", "fusfValue");
		FCC_LABEL_API_FIELD_MAPPING.put("frcr", "frcrValue");
		FCC_LABEL_API_FIELD_MAPPING.put("massachusetts911", "massachusetts911Value");
		FCC_LABEL_API_FIELD_MAPPING.put("newMexicoMsf", "newMexicoUsfValue");
		FCC_LABEL_API_FIELD_MAPPING.put("related911Fees", "relatedFeesValue");
		FCC_LABEL_API_FIELD_MAPPING.put("onetimeFeeTermination", "earlyTerminationFeeValue");
		FCC_LABEL_API_FIELD_MAPPING.put("governmnentTaxes", "governmentTaxesValue");
		FCC_LABEL_API_FIELD_MAPPING.put("chargesForAdditionalDataUsage", "chargesForAdditionalDataUsageValue");
		FCC_LABEL_API_FIELD_MAPPING.put("uniquePlanIdentifier", "uniqueId");
		FCC_LABEL_API_FIELD_MAPPING.put("activationFee", "activationFeesValue");
		
		FCC_CONSTANTS_PROPERTIES.put("discountHeading", "Discounts & Bundles");
		FCC_CONSTANTS_PROPERTIES.put("networkManagementHeading", "Network Management");
		FCC_CONSTANTS_PROPERTIES.put("networkManagementInfoLabel", "Read our Policy");
		FCC_CONSTANTS_PROPERTIES.put("frcrLabel", "Regulatory Cost Recovery");
		FCC_CONSTANTS_PROPERTIES.put("learnMoreDescription", "Learn more about the terms used on this label by visiting the Federal Communications Commission's Consumer Resource Center.");
		FCC_CONSTANTS_PROPERTIES.put("participatesInTheAcpLabel", "Participates in the ACP");
		FCC_CONSTANTS_PROPERTIES.put("typicalUploadSpeedLabel", "Typical Upload Speed");
		FCC_CONSTANTS_PROPERTIES.put("providerMonthlyFeesLabel", "Provider Monthly Fees");
		FCC_CONSTANTS_PROPERTIES.put("chargesForAdditionalDataUsageLabel", "Charges for additional Data Usage");
		FCC_CONSTANTS_PROPERTIES.put("fccHeading", "Broadband Facts");
		FCC_CONSTANTS_PROPERTIES.put("typicalLatencyLabel", "Typical Latency");
		FCC_CONSTANTS_PROPERTIES.put("typicalLatency4gLabel", "Typical Latency");
		FCC_CONSTANTS_PROPERTIES.put("additionalChargesHeading", "Additional Charges & Terms");
		FCC_CONSTANTS_PROPERTIES.put("planDescription", "Broadband Consumer Disclosure");
		FCC_CONSTANTS_PROPERTIES.put("oneTimeFeesSubHeading", "One-Time Fees at the Time of Purchase");
		FCC_CONSTANTS_PROPERTIES.put("privacyHeading", "Privacy");
		FCC_CONSTANTS_PROPERTIES.put("privacyInfoLabel", "Read our Policy");
		FCC_CONSTANTS_PROPERTIES.put("governmentTaxesLabel", "Government Taxes");
		FCC_CONSTANTS_PROPERTIES.put("fusfLabel", "Federal Universal Service Fund");
		FCC_CONSTANTS_PROPERTIES.put("gNationwideNetworkSubheading", "5G");
		FCC_CONSTANTS_PROPERTIES.put("gLteSubheading", "4G LTE");
		FCC_CONSTANTS_PROPERTIES.put("earlyTerminationFeeLabel", "Early Termination Fee");
		FCC_CONSTANTS_PROPERTIES.put("speedsProvidedWithPlanHeading", "Speeds Provided with Plan");
		FCC_CONSTANTS_PROPERTIES.put("customerSupportHeading", "Customer Support");
		FCC_CONSTANTS_PROPERTIES.put("customerSupportInfoLabel", "Contact Us: ");
		FCC_CONSTANTS_PROPERTIES.put("typicalUploadSpeed4gLabel", "Typical Upload Speed");
		FCC_CONSTANTS_PROPERTIES.put("typicalDownloadSpeed4gLabel", "Typical Download Speed");
		FCC_CONSTANTS_PROPERTIES.put("acpHeading", "Affordable Connectivity Program (ACP)");
		FCC_CONSTANTS_PROPERTIES.put("typicalDownloadSpeedLabel", "Typical Download Speed");
		FCC_CONSTANTS_PROPERTIES.put("monthlyPlanPriceLabel", "Monthly Price");
		FCC_CONSTANTS_PROPERTIES.put("linkToFccLabel", "fcc.gov/consumer");
		FCC_CONSTANTS_PROPERTIES.put("activationFeesLabel", "Activation Fee");
		FCC_CONSTANTS_PROPERTIES.put("5gUltrawideNetworkSubheading", "5G Ultra Wideband");
		FCC_CONSTANTS_PROPERTIES.put("typicalDownloadSpeed5GUltraLabel", "Typical Download Speed");
		FCC_CONSTANTS_PROPERTIES.put("typicalLatency5GUltraLabel", "Typical Latency");
		FCC_CONSTANTS_PROPERTIES.put("typicalUploadSpeed5GUltraLabel", "Typical Upload Speed");

		FCC_CONSTANTS_PROPERTIES_ES.put("discountHeading", "Descuentos y paquetes");
		FCC_CONSTANTS_PROPERTIES_ES.put("networkManagementHeading", "Administración de Redes");
		FCC_CONSTANTS_PROPERTIES_ES.put("networkManagementInfoLabel", "Lea Nuestra Política");
		FCC_CONSTANTS_PROPERTIES_ES.put("frcrLabel", "Recuperación de Cargos Regulatorios");
		FCC_CONSTANTS_PROPERTIES_ES.put("learnMoreDescription", "Obtenga más información sobre los términos utilizados en esta etiqueta visitando el Centro de recursos para el consumidor de la Comisión Federal de Comunicaciones.");
		FCC_CONSTANTS_PROPERTIES_ES.put("participatesInTheAcpLabel", "Participa en el ACP");
		FCC_CONSTANTS_PROPERTIES_ES.put("typicalUploadSpeedLabel", "Velocidad de Carga Típica");
		FCC_CONSTANTS_PROPERTIES_ES.put("providerMonthlyFeesLabel", "Tarifas Mensuales del Proveedor");
		FCC_CONSTANTS_PROPERTIES_ES.put("chargesForAdditionalDataUsageLabel", "Cargos por uso de datos adicionales");
		FCC_CONSTANTS_PROPERTIES_ES.put("fccHeading", "Datos de Banda Ancha");
		FCC_CONSTANTS_PROPERTIES_ES.put("typicalLatencyLabel", "Latencia Típica");
		FCC_CONSTANTS_PROPERTIES_ES.put("typicalLatency4gLabel", "Latencia Típica");
		FCC_CONSTANTS_PROPERTIES_ES.put("additionalChargesHeading", "Cargos y Tarifas Adicionales");
		FCC_CONSTANTS_PROPERTIES_ES.put("planDescription", "Divulgación al Consumidor de Banda Ancha");
		FCC_CONSTANTS_PROPERTIES_ES.put("oneTimeFeesSubHeading", "Tarifas únicas al momento de la compra");
		FCC_CONSTANTS_PROPERTIES_ES.put("privacyHeading", "Privacidad");
		FCC_CONSTANTS_PROPERTIES_ES.put("privacyInfoLabel", "Lea Nuestra Política");
		FCC_CONSTANTS_PROPERTIES_ES.put("governmentTaxesLabel", "Impuestos Gubernamentales");
		FCC_CONSTANTS_PROPERTIES_ES.put("fusfLabel", "Fondo del Servicio Universal Federal");
		FCC_CONSTANTS_PROPERTIES_ES.put("gNationwideNetworkSubheading", "5G");
		FCC_CONSTANTS_PROPERTIES_ES.put("gLteSubheading", "4G LTE");
		FCC_CONSTANTS_PROPERTIES_ES.put("earlyTerminationFeeLabel", "Cargo por Cancelación Anticipada");
		FCC_CONSTANTS_PROPERTIES_ES.put("speedsProvidedWithPlanHeading", "Velocidades Proporcionadas con el Plan");
		FCC_CONSTANTS_PROPERTIES_ES.put("customerSupportHeading", "Atención al cliente");
		FCC_CONSTANTS_PROPERTIES_ES.put("customerSupportInfoLabel", "Contacta Con Nosotros: ");
		FCC_CONSTANTS_PROPERTIES_ES.put("typicalUploadSpeed4gLabel", "Velocidad de Carga Típica");
		FCC_CONSTANTS_PROPERTIES_ES.put("typicalDownloadSpeed4gLabel", "Velocidad de Descarga Típica");
		FCC_CONSTANTS_PROPERTIES_ES.put("acpHeading", "Programa de Conectividad Asequible (ACP)");
		FCC_CONSTANTS_PROPERTIES_ES.put("typicalDownloadSpeedLabel", "Velocidad de Descarga Típica");
		FCC_CONSTANTS_PROPERTIES_ES.put("monthlyPlanPriceLabel", "Precio Mensual");
		FCC_CONSTANTS_PROPERTIES_ES.put("linkToFccLabel", "fcc.gov/consumer");
		FCC_CONSTANTS_PROPERTIES_ES.put("activationFeesLabel", "Cargo por Activación");
		FCC_CONSTANTS_PROPERTIES_ES.put("5gUltrawideNetworkSubheading", "Banda ultraancha 5G");
		FCC_CONSTANTS_PROPERTIES_ES.put("typicalDownloadSpeed5GUltraLabel", "Velocidad de Descarga Típica");
		FCC_CONSTANTS_PROPERTIES_ES.put("typicalLatency5GUltraLabel", "Latencia Típica");
		FCC_CONSTANTS_PROPERTIES_ES.put("typicalUploadSpeed5GUltraLabel", "Velocidad de Carga Típica");

		FCC_KEYS_MAP.put("planDescription", new String[] { "planHeading","planDescription", "broadbandType", "monthlyPlanPriceLabel", "monthlyPlanPriceValue", "monthlyIntroductoryPart","monthlyIntroductoryDescription","planSubheading"});
		FCC_KEYS_MAP.put("speeds" ,new String[]   {"speedsProvidedWithPlanHeading"});
		FCC_KEYS_MAP.put("4g" ,new String[]   {"gLteSubheading", "typicalLatency4gLabel", "typicalLatency4gValue", "typicalDownloadSpeed4gValue","typicalDownloadSpeed4gLabel", "typicalUploadSpeed4gLabel","typicalUploadSpeed4gValue"});
		FCC_KEYS_MAP.put("5g" ,new String[]   {"gNationwideNetworkSubheading", "typicalLatencyLabel", "typicalLatencyValue", "typicalUploadSpeedLabel", "typicalUploadSpeedValue", "typicalDownloadSpeedLabel", "typicalDownloadSpeedValue"});
		FCC_KEYS_MAP.put("5gUltrawide", new String[] {"5gUltrawideNetworkSubheading", "typicalLatency5GUltraLabel", "typicalLatency5GUltraValue", "typicalUploadSpeed5GUltraLabel", "typicalUploadSpeed5GUltraValue","typicalDownloadSpeed5GUltraLabel", "typicalDownloadSpeed5GUltraValue" });
		FCC_KEYS_MAP.put("dataIncluded" ,new String[]   {"dataIncludedWithMonthlyPriceLabel","dataIncludedWithMonthlyPriceValue", "chargesForAdditionalDataUsageLabel","chargesForAdditionalDataUsageValue"});
		FCC_KEYS_MAP.put("networkPrivacy" ,new String[]   {"networkManagementHeading","networkManagementInfoValue", "networkManagementInfoLabel","privacyHeading", "privacyInfoLabel", "privacyInfoValue"});
		FCC_KEYS_MAP.put("customerSupport" ,new String[]   {"customerSupportHeading", "customerSupportInfoLabel","customerSupportInfoValue", "customerSupportNumber"});
		FCC_KEYS_MAP.put("learnMore" ,new String[]   {"learnMoreDescription","linkToFcc","linkToFccLabel"});
		FCC_KEYS_MAP.put("discountAffordable" ,new String[]   {"discountHeading","discountDescription","acpHeading","acpDescription","participatesInTheAcpLabel","participatesInTheAcpValue"});
		FCC_KEYS_MAP.put("additionalCharges" ,new String[]   {"additionalChargesHeading","providerMonthlyFeesLabel","providerMonthlyFeesValue","earlyTerminationFeeLabel", "earlyTerminationFeeValue","governmentTaxesLabel","governmentTaxesValue","activationFeesLabel","activationFeesValue"
		});
		FCC_KEYS_MAP.put("oneFeesSubHeading" ,new String[]   {"oneTimeFeesSubHeading","frcrLabel","frcrValue","fusfLabel","fusfValue"});

		PROPERTIES_TEMPLATE_LEVEL.add("acpDescription");
		PROPERTIES_TEMPLATE_LEVEL.add("discountDescription");
		PROPERTIES_TEMPLATE_LEVEL.add("typicalDownloadSpeed4gValue");
		PROPERTIES_TEMPLATE_LEVEL.add("typicalLatency4gValue");
		PROPERTIES_TEMPLATE_LEVEL.add("typicalUploadSpeed4gValue");
		PROPERTIES_TEMPLATE_LEVEL.add("typicalDownloadSpeedValue");
		PROPERTIES_TEMPLATE_LEVEL.add("typicalLatencyValue");
		PROPERTIES_TEMPLATE_LEVEL.add("typicalUploadSpeedValue");
		PROPERTIES_TEMPLATE_LEVEL.add("dataIncludedWithMonthlyPriceLabel");
		PROPERTIES_TEMPLATE_LEVEL.add("networkManagementInfoValue");
		PROPERTIES_TEMPLATE_LEVEL.add("privacyInfoValue");
		PROPERTIES_TEMPLATE_LEVEL.add("customerSupportInfoValue");
		PROPERTIES_TEMPLATE_LEVEL.add("linkToFcc");
		PROPERTIES_TEMPLATE_LEVEL.add("monthlyIntroductoryDescription");
		PROPERTIES_TEMPLATE_LEVEL.add("monthlyIntroductoryPart");
		PROPERTIES_TEMPLATE_LEVEL.add("governmentTaxesValue");
	}




    public static Map<String, String> getFccLabelApiFieldMapping() {
        return new TreeMap<String,String>(FCC_LABEL_API_FIELD_MAPPING);
    }

	 public static Map<String, String> getFccContantsProperties() {
        return new TreeMap<>(FCC_CONSTANTS_PROPERTIES);
    }

	 public static Map<String, String> getFccContantsPropertiesEs() {
        return new TreeMap<>(FCC_CONSTANTS_PROPERTIES_ES);
    }

	 public static Map<String, String[]> getFccKeysMap() {
        return new LinkedHashMap<>(FCC_KEYS_MAP);
    }

	public static List<String> getPropertiesTemplateLevel() {
        return new ArrayList<>(PROPERTIES_TEMPLATE_LEVEL);
    }
	 
	 public static final String FCC_HEADING= "fccHeading"; 
	 public static final String BRAND_HEADING= "brandHeading"; 
	 public static final String IS_LEGACY= "isLegacy"; 
	 public static final String CHANNELS= "channels"; 
	 public static final String CHANNEL_WEB= "WEB"; 
	 public static final String PLAN_DESCRIPTION= "planDescription"; 
	 public static final String PLAN_HEADING= "planHeading";
	 public static final String PLAN_SUB_HEADING= "planSubheading"; 
	 public static final String MONTHLY_PLAN_PRICE_VALUE= "monthlyPlanPriceValue"; 
	 public static final String PLAN_PRICE_DESCRIPTION= "planPriceDescription"; 
	 public static final String ADDITIONAL_CHARGES= "additionalCharges"; 
	 public static final String PROVIDER_MONTHLY_FEES_VALUE= "providerMonthlyFeesValue"; 
	 public static final String ONE_FEES_SUB_HEADING= "oneFeesSubHeading"; 
	 public static final String FUSF_VALUE= "fusfValue"; 
	 public static final String FRCR_VALUE= "frcrValue"; 
	 public static final String MASSACHUSSETS_911_VALUE= "massachusetts911Value"; 
	 public static final String NEW_MEXICO_USF_VALUE= "newMexicoUsfValue"; 
	 public static final String RELATED_FEES_VALUE= "relatedFeesValue";
	 public static final String EARLY_TERMINATION_FEES_VALUE= "earlyTerminationFeeValue";
	 public static final String GOVERNMENT_TAXES_VALUE= "governmentTaxesValue"; 
	 public static final String DISCOUNT_AFFORDABLE= "discountAffordable"; 
	 public static final String DISCOUNT_DESCRIPTION= "discountDescription"; 
	 public static final String ACP_DESCRIPTION= "acpDescription"; 
	 public static final String PARTICIPATION_IN_ACP_VALUE= "participatesInTheAcpValue"; 
	 public static final String SPEEDS= "speeds"; 
	 public static final String SPEEDS_4G= "4g"; 
	 public static final String SPEEDS_5G= "5g"; 
	 public static final String TYPICAL_UPLOAD_SPEEDS_4G= "typicalUploadSpeed4gValue"; 
	 public static final String TYPICAL_DOWNLOAD_SPEEDS_4G= "typicalDownloadSpeed4gValue"; 
	 public static final String TYPICAL_LATENCY_4G= "typicalLatency4gValue"; 
	 public static final String TYPICAL_UPLOAD_SPEEDS_5G= "typicalUploadSpeedValue"; 
	 public static final String TYPICAL_DOWNLOAD_SPEEDS_5G= "typicalDownloadSpeedValue"; 
	 public static final String TYPICAL_LATENCY_5G= "typicalLatencyValue"; 
	 public static final String DATA_INCLUDED= "dataIncluded"; 
	 public static final String DATA_INCLUDED_WITH_MONTHLY_PRICE_VALUE= "dataIncludedWithMonthlyPriceValue"; 
	 public static final String CHARGES_FOR_ADDITIONAL_DATA_USAGE_VALUE= "chargesForAdditionalDataUsageValue";
	 public static final String NETWORK_PRIVACY= "networkPrivacy";
	 public static final String NETWORK_MANAGEMENT_INFO_VALUE= "networkManagementInfoValue";
	 public static final String PRIVACY_INFO_VALUE= "privacyInfoValue";
	 public static final String CUSTOMER_SUPPORT= "customerSupport";
	 public static final String CUSTOMER_SUPPORT_INFO_VALUE= "customerSupportInfoValue";
	 public static final String CUSTOMER_SUPPORT_NUMBER= "customerSupportNumber";
	 public static final String LEARN_MORE= "learnMore";
	 public static final String LEARN_MORE_DESCRIPTION= "learnMoreDescription";
	 public static final String LINK_TO_FCC= "linkToFcc";
	 public static final String PRODUCT_ID = "clfyPartNumber";
	 public static final String PLAN_CODE = "planCode";
	 public static final String ERROR = "ERROR";
	 public static final String ERRORCODE = "code";
	 public static final String TYPE = "type";
	 public static final String IS_SAFELINK = "isSafelinkEligible";
	 public static final String IS_PRODUCT_OFFERING = "isProductOffering";
	 public static final String STRAIGHTALK_BRAND_NAME = "straighttalk";
	 public static final String TRACFONE_BRAND_NAME = "tracfone";
	 public static final String TBV_BRAND_NAME = "tbv";
	 public static final String WFM_BRAND_NAME = "wfm";
	 public static final String NET10_BRAND_NAME = "net10";
	 public static final String SM_BRAND_NAME = "simple-mobile";
	 public static final String GOSMART_BRAND_NAME = "go-smart";
	 public static final String SAFELINK_BRAND_NAME = "safelink";
	 public static final String ST_BRAND = "stbrand";
	 public static final String TF_BRAND = "tfbrand";
	 public static final String TBV_BRAND = "tbvbrand";
	 public static final String WFM_BRAND = "wfmbrand";
	 public static final String NET10_BRAND = "net10brand";
	 public static final String SM_BRAND = "smbrand";
	 public static final String GOSMART_BRAND = "gosmartbrand";
	 public static final String ST_CAT_NO = "stcatno";
	 public static final String TF_CAT_NO = "tfcatno";
	 public static final String TBV_CAT_NO = "tbvcatno";
	 public static final String wfm_CAT_NO = "wfmcatno";
	 public static final String PRICE = "price";
	 public static final String PLAN_ID = "planId";
	 
	 
    
}
