/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;

/**
 * Defines the {@code PurchaseFlowWrapperModel} Sling Model used for the {@code /apps/tracfone-core/components/commerce/purchaseflowwrapper} component.
 */
public interface PurchaseFlowWrapperModel extends ComponentExporter {

	/**
	 * <p>get purchase flow</p>
	 *
	 * @return String - xf path
	 */
	public String getPurchaseFlowSteps();
	
	/**
	 * <p>get purchase flow</p>
	 *
	 * @return String - xf path
	 */
	public String getCartStickySteps();

	/**
	 * <p>get purchase flow</p>
	 *
	 * @return String - xf path
	 */
	public String getCurrentPurchaseFlowSteps();

	public String getAllXfPaths();
	
	/**
     * <p>Fetches queryString for the price api call</p>
     * 
      * @return String - queryString 
      */
     public String getQueryString();
     /**
     * <p> Method to return Price Api domain</p>
     * 
      * @return String
     */
     public String getApiDomain();

     /**
	 * <p> Method to return Smart Pay Plan Facet</p>
	 *
	 * @return String
	 */
	 public String getSmartPayPlanFacet();
     
     /**
     * <p>Fetches Category Api Path</p>
     * 
      * @return String - Category Api Path
     */
     public String getCategoryApiPath();

     /**
      * <p>Fetches checkout Path</p>
      * 
       * @return String - checkout Path
      */
	 public String getCartPath();
	 /**
	 * @return String -  UpgradeEligibilityApiPath
	 */
	public String getUpgradeApiPath();
	
	 /**
	 * @return String -  emiOrderType
	 */
	public String getEmiOrderType();
	
	/**
	 * <p> This method is used to generate query string for marketing id call
	 * @return -String : Query String
	 */
	public String getUpgradeElgQueryString();

	public String getEditPlanPath();

	/**
	 * <p>get login page path</p>
	 *
	 * @return String - loginPath
	 */
	public String getLoginPath();

	/**
	 * <p>get hide sticky cart flows</p>
	 *
	 * @return String - hideStickyCart
	 */
	public String getHideStickyCart();

	/**
	 * <p>allow HPP for reorder devices</p>
	 *
	 * @return String - preorderHPPDefaultValue
	 */
	public String getPreorderHPPDefaultValue();
	/**
	 * Get the cusg enabling check
	 *
	 * @return String - cusg enabling check
	 */
	public String getCusgEnable();
	
	/**
	 * Get the disable HPP check
	 *
	 * @return String - disable HPP check
	 */
	public String getDisableHpp();

    /**
     * @return String[] - Language value mapping
     */
    public String[] getLanguageValueMapping();

	/**
	 *
	 * @return String[] - purchaseDevicesType
	 */
	public String[] getPurchaseDevicesType();
	
	/**
	 * Get the manage Auto Refill Page Path
	 *
	 * @return String - manage Auto Refill Page Path
	 */
	public String getManageAutoRefillPagePath();

}
