package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

public interface CusgPromoBannerModel extends ComponentExporter {

	@JsonProperty("componentVersion")
	public String getComponentVersion();
	
	@JsonProperty("headlineText")
	public String getHeadlineText();
	
	@JsonProperty("subHeadlineText")
	public String getSubHeadlineText();
	
	@JsonProperty("exclusiveOfferLabel")
	public String getExclusiveOfferLabel();
	
	@JsonProperty("firstImageForBanner")
	public String getFirstImageForBanner();
	
	@JsonProperty("firstImageAltTextForBanner")
	public String getFirstImageAltTextForBanner();

	@JsonProperty("secondImageForBanner")
	public String getSecondImageForBanner();

	@JsonProperty("secondImageAltTextForBanner")
	public String getSecondImageAltTextForBanner();
	
}

