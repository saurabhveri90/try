package com.tracfonecore.core.beans;

import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class TilesDataBean{

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private Resource resource;
	
	/**
	 * Inject Image
	 */
	@ValueMapValue
	private String image;

	/**
	 * Inject Heading
	 */
	@ValueMapValue
	private String heading;
	
	/**
	 * Inject Eyebrow Label Text for List Detail
	 */
	@ValueMapValue
	private String listDetailEyebrowLabelText;

	/**
	 * Inject Sub Heading
	 */
	@ValueMapValue
	private String subHeading;

	/**
	 * Inject CTA Label
	 */
	@ValueMapValue
	private String ctaLabel;
	
	/**
	 * Inject CTA Accessibilty Label
	 */
	@ValueMapValue
	private String accessibiltyCtaLabel;

	/**
	 * Inject CTA Link
	 */
	@ValueMapValue
	private String ctaLink;
	
	/**
	 * Inject newtab
	 */
	@ValueMapValue
	private String newtab;

	/**
	 * Inject newtab
	 */
	@ValueMapValue
	private String donotfollowlink;
	
	/**
	 * Inject imageAltText
	 */
	@ValueMapValue
	private String imageAltText;

	/**
	 * Inject useOriginalImages
	 */
	@ValueMapValue
	private String useOriginalImages;
	
	/**
	 * <p>
	 * Returns image from properties
	 * </p>
	 * 
	 * @return String - image
	 */
	public String getImage() {
		if((ApplicationConstants.TRUE).equals(useOriginalImages)){
			return image;
		}
		else{
			return DynamicMediaUtils.changeMediaPathToDMPath(image, resource.getResourceResolver());
		}
	}

	/**
	 * <p>
	 * Returns image from properties
	 * </p>
	 * 
	 * @return String - image
	 */
	public String getUseOriginalImages() {
		return useOriginalImages;
	}

	/**
	 * <p>
	 * Returns listDetailEyebrowLabelText from properties
	 * </p>
	 * 
	 * @return String - listDetailEyebrowLabelText
	 */
	public String getListDetailEyebrowLabelText() {
		return listDetailEyebrowLabelText;
	}
	
	/**
	 * <p>
	 * Returns heading from properties
	 * </p>
	 * 
	 * @return String - heading
	 */
	public String getHeading() {
		return heading;
	}

	/**
	 * <p>
	 * Returns subHeading from properties
	 * </p>
	 * 
	 * @return String - subHeading
	 */
	public String getSubHeading() {
		return subHeading;
	}
	
	/**
	 * <p>
	 * Returns ctaLabel from properties
	 * </p>
	 * 
	 * @return String - ctaLabel
	 */
	public String getCtaLabel() {
		return ctaLabel;
	}

	/**
	 * @return the accessibiltyCtaLabel
	 */
	public String getAccessibiltyCtaLabel() {
		return accessibiltyCtaLabel;
	}

	/**
	 * <p>
	 * Returns ctaLink from properties
	 * </p>
	 * 
	 * @return String - ctaLink
	 */
	public String getCtaLink() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), ctaLink);
	}

	/**
	 * <p>
	 * Returns newtab from properties
	 * </p>
	 * 
	 * @return the newtab
	 */
	public String getNewtab() {
		return newtab;
	}

	/**
	 * <p>
	 * Returns donotfollowlink from properties
	 * </p>
	 * 
	 * @return the donotfollowlink
	 */
	public String getDonotfollowlink() {
		return donotfollowlink;
	}
	
	
	/**
	 * <p>
	 * Returns imageAltText from properties
	 * </p>
	 * 
	 * @return the imageAltText
	 */
	public String getImageAltText() {
		return imageAltText;
	}

	/**
	 * <p>
	 * Returns unchanged image from properties
	 * </p>
	 * 
	 * @return String - image
	 */
	public String getImagePath() {
		return image;
	}

}
