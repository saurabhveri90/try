/**
 * 
 */
package com.tracfonecore.core.models;

import org.osgi.annotation.versioning.ConsumerType;

import com.adobe.cq.wcm.core.components.models.ListItem;
import com.drew.lang.annotations.Nullable;
/**
 * @author vijaykumar.tripathi
 *
 */
@ConsumerType
public interface ListModelItem extends ListItem{

       /**
     * Returns the name of this {@code ListItem}.
     *
     * @return the list item name or {@code null}
     */
    @Nullable
    default String getIconPath() {
        throw new UnsupportedOperationException();
    }
    /**
     * Returns the name of this {@code thumbnailurl}.
     *
     * @return the thumbnailurl name or {@code null}
     */
    @Nullable
	String getS7thumbnailurl();
}

