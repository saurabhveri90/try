/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl.v1;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.tracfonecore.core.models.PromoNoticationModel;
import com.tracfonecore.core.models.PromoNotification;
import com.tracfonecore.core.utils.ItemsExporterUtil;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { PromoNoticationModel.class,
		ComponentExporter.class }, resourceType = PromoNotificationModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class PromoNotificationModelImpl extends com.tracfonecore.core.models.impl.BaseComponentModelImpl implements PromoNoticationModel {
	private static final Logger LOGGER = LoggerFactory.getLogger(PromoNotificationModelImpl.class);

	public static final String RESOURCE_TYPE = "tracfone-core/components/commerce/promoNotification/v1/promonotication";


	@Self
	private SlingHttpServletRequest request;

	@Inject
	private SlingModelFilter slingModelFilter;

	@Inject
	private ModelFactory modelFactory;

	@ValueMapValue
	private String promoNotificationType;

	@ValueMapValue
	private String generalPromoText;

	@ValueMapValue
	private String notificationIcon;

	@ChildResource
	private List<PromoNotification> propautorefill;

	@ChildResource
	private List<PromoNotification> propplan;

	/**
	 *
	 * @return generalPromoText
	 */
	@Override
	public String getGeneralPromoText() {
		return generalPromoText;
	}

	/**
	 *
	 * @return notificationIcon
	 */
	@Override
	public String getNotificationIcon() {
		return notificationIcon;
	}

	/**
	 *
	 * @return autorefillplans
	 */
	@Override
	public List<PromoNotification> getPropautorefill() {
		List<PromoNotification> list = Optional.ofNullable(propautorefill)
				.map(List::stream).orElseGet(Stream::empty).collect(Collectors.toList());
		return new ArrayList<>(list);
	}

	/**
	 *
	 * @return promoplans
	 */

	@Override
	public List<PromoNotification> getPropplan() {
		List<PromoNotification> list = Optional.ofNullable(propplan)
				.map(List::stream).orElseGet(Stream::empty).collect(Collectors.toList());
		return new ArrayList<>(list);
	}

	@Override
	public String getExportedType() {
		return RESOURCE_TYPE;
	}
	@Override
	public String getPromoNotificationType() {
		return promoNotificationType;
	}

	/**
	 * <p>
	 * Fetches the export child items
	 * </p>
	 *
	 *
	 * @return Map<String, ? extends ComponentExporter> - the export child items
	 */
	@Override
	public Map<String, ? extends ComponentExporter> getItems() {
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}
}