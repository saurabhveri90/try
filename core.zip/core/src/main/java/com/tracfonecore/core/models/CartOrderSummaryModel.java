/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Multi-Links} Sling Model used for the {@code tracfone-core/components/spa/commerce/cartordersummary} component.
 */
public interface CartOrderSummaryModel extends ComponentExporter {

	@JsonProperty("positionCartSummary")
	public String getPositionCartSummary();
	
	@JsonProperty("positionOrderSummary")
	public String getPositionOrderSummary();
	
	@JsonProperty("cartDetailComponentVersion")
	public String getCartDetailComponentVersion();
	
	@JsonProperty("enableEstimateOrder")
	public String getEnableEstimateOrder();
	
	@JsonProperty("smartPaySummaryText")
	public String getSmartPaySummaryText();
	
	@JsonProperty("smartPayLeasedFrom")
	public String getSmartPayLeasedFrom();

	@JsonProperty("stByop25EnrollInReawardsLink")
	public String getStByop25EnrollInReawardsLink();

	@JsonProperty("moreAboutStraightTalkLink")
	public String getMoreAboutStraightTalkLink();
	
}
