/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.tracfonecore.core.beans.LinkBean;

import java.util.List;
import java.util.Map;

/**
 * Defines the {@code Header} Sling Model used for the {@code /apps/tracfone-core/components/structure/header} component.
 */
public interface HeaderModel extends ComponentExporter {

	/**
	 * <p>Fetches file reference for the logo</p>
	 *
	 * @return String - file reference for the logo
	 */
	@JsonProperty("fileReference")
	public String getFileReference();

	/**
	 * <p>Fetches Desktop Small file reference for the logo</p>
	 *
	 * @return String - file reference for the logo
	 */
	@JsonProperty("fileReferenceDeskSm")
	public String getFileReferenceDeskSm();


	/**
	 * <p>Fetches Mobile Small file reference for the logo</p>
	 *
	 * @return String - file reference for the logo
	 */
	@JsonProperty("fileReferenceMobile")
	public String getFileReferenceMobile();

	/**
	 * <p>Fetches alt text for Desktop logo</p>
	 *
	 * @return String - alt text for desktop logo
	 */
	@JsonProperty("logoAltTextDesktop")
	public String getLogoAltTextDesktop();

	/**
	 * <p>Fetches alt text for Mobile logo</p>
	 *
	 * @return String - alt text for mobile logo
	 */
	@JsonProperty("logoAltTextMobile")
	public String getLogoAltTextMobile();

	/**
	 * <p>Fetches destination link for the logo</p>
	 *
	 * @return String - destination link for the logo
	 */
	@JsonProperty("logoTargetURL")
	public String getLogoTargetURL();

	/**
	 * <p>Fetches all the multi-links</p>
	 *
	 * @return String - all the multi-links
	 */
	@JsonProperty("links")
	public List<LinkBean> getMultilinks();

	/**
	 * <p>Fetches no-follow value for link</p>
	 *
	 * @return String -  no-follow value
	 */
	@JsonProperty("doNotFollow")
	public String getDoNotFollow();
	/**
	 * <p> Fetches the export child items</p>
	 *
	 *
	 * @return Map<String, ? extends ComponentExporter> - the export child items
	 */
	public Map<String, ? extends ComponentExporter> getItems();
	/**
	 * <p>Fetches no-follow value for link</p>
	 *
	 * @return String -  no-follow value
	 */
	@JsonProperty("cartIconUrl")
	public String getCartIconUrl();
	/**
	 * <p>Fetches redirection message for logo link/p>
	 *
	 * @return String -  logoRedirectionMessage value
	 */
	@JsonProperty("logoRedirectionMessage")
	public String getLogoRedirectionMessage();

	/**
	 * <p>Fetches target of the logo link</p>
	 *
	 * @return String - target of the logo link
	 */
	@JsonProperty("logoNewWindow")
	public String getLogoNewWindow();

	/**
	 * <p>Fetches Trim Header Text</p>
	 *
	 * @return String - Trim Header Text
	 */
	@JsonProperty("trimHeaderText")
	public String getTrimHeaderText();

	@JsonProperty("searchAutoCompleteApiDomain")
	public String getSearchAutoCompleteApiDomain();

	@JsonProperty("searchAutoCompleteApiPath")
	public String getSearchAutoCompleteApiPath();

	@JsonProperty("searchAutoCompleteApiEngineId")
	public String getSearchAutoCompleteApiEngineId();

	@JsonProperty("durationInDays")
	public String getDurationInDays();

	@JsonProperty("countOfTopKeywords")
	public String getCountOfTopKeywords();

	@JsonProperty("typeaheadMaxCount")
	public String getTypeaheadMaxCount();

	@JsonProperty("searchIconUrl")
	public String getSearchIconUrl();

	@JsonProperty("skipToMainContent")
	public String getSkipToMainContent();
	/**
	 * Fetches the brand name
	 */
	public String getBrandName() ;
	/**
	 * Get Page template Name
	 */
	public String getTemplateName();

	@JsonProperty("mediaType")
	public String getMediaType();

	@JsonProperty("theme")
	public String getTheme();

	@JsonProperty("showBackgroundImage")
	public String getShowBackgroundImage();

	/**
	 * <p>Fetches Image path</p>
	 *
	 * @return String - image path
	 */
	@JsonProperty("mediaPath")
	public String getMediaPath();

	/**
	 *  <p>
	 * Fetches break points for the image
	 * </p>
	 *
	 * @return String - imageProfileBreakpoints
	 */
	public String getImageProfileBreakpoints();

	/**
	 *<p>Fetches data type for the video</p>
	 *
	 * @return String - videoDataType
	 */
	public String getVideoDataType();

	/**
	 *<p>Fetches the path for mobile thumbnail</p>
	 *
	 * @return String - mobile thumbnail image path
	 */
	public String getMobileThumbnailImagePath();

	/**
	 *<p>Fetches the path for mobile image path</p>
	 *
	 * @return String - mobile image path
	 */
	public String getMobileMediaImagePath();

	/**
	 *<p>Fetches the data mode</p>
	 *
	 * @return String - data mode
	 */
	public String getDataMode();

	/**
	 *<p>Fetches the media Alignment</p>
	 *
	 * @return String - media Alignment
	 */

	/**
     * <p>Fetches all the User-Icon links</p>
     *
     * @return String - all the usericon-links
     */
    @JsonProperty("userIconlinks")
    public List<LinkBean> getUserIconLinks();
}