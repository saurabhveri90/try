/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Analytics Configuration Service", description = "Analytics Configuration Service")
public @interface AnalyticsConfig {
	
	@AttributeDefinition(name = "GTM ID", description = "Please provide GTM id to track")
	String[]  gtmId() default {"STRAIGHT_TALK:GTM-WRH7BJ","TRACFONE:GTM-KH46TX"};
	
	@AttributeDefinition(name = "Adobe Launch Script", description = "Please provide Adobe Launch Script")
	String[]  launchScript() default {"STRAIGHT_TALK://assets.adobedtm.com/launch-ENf0cba3fbe234440685be2e0029f413d4-development.min.js","TRACFONE://assets.adobedtm.com/launch-ENf0cba3fbe234440685be2e0029f413d4-development.min.js"};

	@AttributeDefinition(name = "Dynatrace Script", description = "Please provide Dynatrace Script Src")
	String[]  dynatraceScript() default {"STRAIGHT_TALK:js-cdn.dynatrace.com/jstag/16ab023090d/bf62185vir/46ea6fb412fad73_complete.js","TRACFONE:js-cdn.dynatrace.com/jstag/16ab023090d/bf62185vir/46ea6fb412fad73_complete.js"};

}

