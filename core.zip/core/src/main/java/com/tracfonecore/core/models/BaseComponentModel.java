/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

public interface  BaseComponentModel {


	/**
	 * <p>
	 * Fetches Root Brand Folder
	 * </p>
	 * 
	 * @return String -Root Brand Folder
	 */
	public String getRootBrandFolder();

    String getButterBarXFPath();
}