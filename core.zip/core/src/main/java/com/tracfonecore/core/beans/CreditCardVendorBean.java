/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;

/**
 * <p>Defines bean to hold credit card vendors</p>
 */
/**
 * @author saurabh_kumar1
 *
 */
public class CreditCardVendorBean {

	private String creditCardVendorName;
	private String creditCardVendorLogo;
	private String creditCardVendorLogoAltText;
	
	/**
	 * <p>Fetches creditCardVendorName</p>
	 * 
	 * @return String - creditCardVendorName
	 */
	public String getCreditCardVendorName() {
		return creditCardVendorName;
	}
	
	/**
	 * <p>Sets creditCardVendorName</p>
	 * 
	 * @param creditCardVendorName - Name of vendor
	 */
	public void setCreditCardVendorName(String creditCardVendorName) {
		this.creditCardVendorName = creditCardVendorName;
	}
	
	/**
	 * <p>Fetches creditCardVendorLogo</p>
	 * 
	 * @return String - creditCardVendorLogo
	 */
	public String getCreditCardVendorLogo() {
		return creditCardVendorLogo;
	}
	
	/**
	 * <p>Sets creditCardVendorLogo</p>
	 * 
	 * @param creditCardVendorLogo - vendor logo
	 */
	public void setCreditCardVendorLogo(String creditCardVendorLogo) {
		this.creditCardVendorLogo = creditCardVendorLogo;
	}
	
	/**
	 * <p>Fetches creditCardVendorLogoAltText</p>
	 * 
	 * @return String - creditCardVendorLogoAltText
	 */
	public String getCreditCardVendorLogoAltText() {
		return creditCardVendorLogoAltText;
	}
	
	/**
	 * <p>Sets creditCardVendorLogoAltText</p>
	 * 
	 * @param creditCardVendorLogoAltText - Alt Text of vendor logo
	 */
	public void setCreditCardVendorLogoAltText(String creditCardVendorLogoAltText) {
		this.creditCardVendorLogoAltText = creditCardVendorLogoAltText;
	}	
}
