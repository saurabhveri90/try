/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingException;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.ImageBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.ModalImageTextModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ModalImageTextModel.class,
		ComponentExporter.class }, resourceType = ModalImageTextModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ModalImageTextModelImpl implements ModalImageTextModel {
	private static final String IMAGE_ALT_TEXT = "imageAltText";

	private static final String IMAGE_PATH = "imagePath";

	private static final String LABEL_TEXT = "labelText";

	private static final Logger LOGGER = LoggerFactory.getLogger(ModalImageTextModelImpl.class);
	
	protected static final String RESOURCE_TYPE = "tracfone-core/components/content/imagetextmodal";

	@Self
	private SlingHttpServletRequest request;

	@Inject @Via("resource")
	private String title;

	 @Inject @Via("resource")
	@Default(values = "Image Text")
	private String modalName;
		
	 @Inject @Via("resource")
	private Resource imageMultifield;
	 
	 @Inject @Via("resource")
	private String placementText;

	private String modalId;
	
	
	private String accessibilityLabel;

	ResourceResolver resourceResolver;
	
	@Inject @Via("resource")
	@Default(values  = "3")
	private String layoutSize;
	
	@Inject @Via("resource")
	@Default(values =  "1")
	private String mobileLayoutSize;
	
	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering initModel method");
			resourceResolver = request.getResourceResolver();
			String modal_Name=ApplicationUtil.getLowerCaseWithHyphen(modalName);
			this.setModalId(modal_Name+ ApplicationConstants.HYPHEN + ApplicationConstants.MODAL);
			this.setAccessibilityLabel(modalName);
		LOGGER.debug("Exiting initModel method");
	}

	/**
	 *<p>Fetches title</p>
	 *
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}


	/**
	 *<p>Fetches modalName</p>
	 *
	 * @return the modalName
	 */
	public String getModalName() {
		return modalName;
	}

	/**
	 *<p>Fetches modalId</p>
	 *
	 * @return the modalId
	 */
	public String getModalId() {
		return modalId;
	}

	/**
	 * <p>Sets modalId</p>
	 *
	 *@param modalId - the modalId to set
	 */
	public void setModalId(String modalId) {
		this.modalId = modalId;
	}	

	/**
	 *<p>Fetches accessibilityLabel</p>
	 *
	 * @return the accessibilityLabel
	 */
	public String getAccessibilityLabel() {
		return accessibilityLabel;
	}

	/**
	 * <p>Sets accessibilityLabel</p>
	 *
	 *@param accessibilityLabel - the accessibilityLabel to set
	 */
	public void setAccessibilityLabel(String accessibilityLabel) {
		this.accessibilityLabel = accessibilityLabel;
	}

	/**
	 * <p>Populates a list with all the multifield items</p>
	 *
	 */
	@Override
	public List<ImageBean> getImageMultiFieldItems() {

		List<ImageBean> imgList =new ArrayList<>();
		Iterator<Resource> itr =imageMultifield.listChildren();
		
		try {
			
			while (itr.hasNext()) {
				ImageBean imageBean = new ImageBean();
				Resource res =itr.next();
				String imagePath = res.getValueMap().get(IMAGE_PATH, "");
				if (StringUtils.isNotBlank(res.getValueMap().get(IMAGE_PATH, ""))){
					imageBean.setImagePath(DynamicMediaUtils.changeMediaPathToDMPath(res.getValueMap().get(IMAGE_PATH, ""), resourceResolver));
				}

				if (StringUtils.isNotBlank(res.getValueMap().get(LABEL_TEXT,""))) {
					imageBean.setText(res.getValueMap().get(LABEL_TEXT,""));
				}

				if (StringUtils.isNotBlank(res.getValueMap().get(IMAGE_ALT_TEXT, ""))) {
					imageBean.setAltText(res.getValueMap().get(IMAGE_ALT_TEXT, ""));
				}

				if (StringUtils.isNotEmpty(imagePath)) {

					imageBean.setAssetId(
							ApplicationUtil.getAssetId(imagePath, resourceResolver, ApplicationConstants.IMAGE));
					imageBean.setWeberId(ApplicationUtil.getAssetMetaDataValue(imagePath,
							resourceResolver, ApplicationConstants.WEBER_ID));

				}
				
				imgList.add(imageBean);
				
			}
		} catch (SlingException | IllegalStateException e) {
			LOGGER.error(" Exception occurred while fetching multi details details {}", e);
		}
		return imgList;
	}
	
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>Fetches number of columns for Image Text items</p>
	 *
	 * @return String - number of columns for Image Text items
	 */
	@Override
	public String getLayoutSize() {
		return layoutSize;
	}

	/**
	 * <p>Fetches number of columns for Image Text items for mobile</p>
	 *
	 * @return String - number of columns for Image Text items for Mobile
	 */
	@Override
	public String getMobileLayoutSize() {
		return mobileLayoutSize;
	}

	/**
	 * <p>Fetches style class to display number of columns for image text for desktop</p>
	 *
	 * @return String - number of columns for image text items for Desktop
	 */
	@Override
	public String getDesktopStyleClass() {
		return ApplicationUtil.getStyleClass(getLayoutSize(), ApplicationConstants.ROW_COLS_LG);
	}

	/**
	 * <p>Fetches style class to display number of columns for image text for mobie</p>
	 *
	 * @return String - number of columns for image text items for Mobile
	 */
	@Override
	public String getMobileStyleClass() {
		return ApplicationUtil.getStyleClass(getMobileLayoutSize(), ApplicationConstants.ROW_COLS);	
	}
	
	@Override
	public String getPlacementText() {
		return placementText;
	}

}