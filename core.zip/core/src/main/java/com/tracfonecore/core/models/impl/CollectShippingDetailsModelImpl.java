/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.CollectShippingDetailsModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CollectShippingDetailsModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/collectShippingDetails", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CollectShippingDetailsModelImpl implements CollectShippingDetailsModel {

	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String shippingTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String shippingSummary;

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Fetches shipping title
	 * </p>
	 * 
	 * @return String - shippingTitle
	 */
	@Override
	public String getShippingTitle() {
		return shippingTitle;
	}

	/**
	 * <p>
	 * Fetches shipping summary
	 * </p>
	 * 
	 * @return String - shippingSummary
	 */
	@Override
	public String getShippingSummary() {
		return shippingSummary;
	}

}
