package com.tracfonecore.core.beans;
/**
 * <p>Defines bean to hold link detail</p>
 */
public class WatchCardBean {
    /*
     *  Copyright 2019 HCL Technologies Ltd.
     *
     *
     */

    private String mediaPath;
    private String skusSelection;
    private String color;


    /**
     *<p>Fetches mediaPath</p>
     *
     * @return String: the mediaPath
     */
    public String getMediaPath() {
        return mediaPath;
    }
    /**
     * <p>Sets mediaPath</p>
     *
     *@param mediaPath - the mediaPath to set
     */
    public void setMediaPath(String mediaPath) {
        this.mediaPath = mediaPath;
    }

    /**
     * <p>Gets skusSelection</p>
     *
     */

    public String getSkusSelection() {
        return skusSelection;
    }

    /**
     * <p>Sets skusSelection</p>
     *
     * @param skusSelection - the skusSelection to set
     */
    public void setSkusSelection(String skusSelection) {
        this.skusSelection = skusSelection;
    }
    
    
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
    
}
