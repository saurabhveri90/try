package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.OneStepActivationModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.constants.ApplicationConstants;

import javax.inject.Inject;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { OneStepActivationModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/onestepactivation", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class OneStepActivationModelImpl implements OneStepActivationModel {
	
	@Self
	private SlingHttpServletRequest request;
	
	@ValueMapValue
	private String imagePath;

	@ValueMapValue
	private String heading;
	
	@ValueMapValue
	private String subheadingone;

	@ValueMapValue
	private String subheadingtwo;

	@ValueMapValue
	private String inputFieldPlaceholder;

	@ValueMapValue
	private String inputFieldLastFourDigits;
	
	@ValueMapValue
	private String inputOtpPlaceholder;

	@ValueMapValue
	private String videolink;

	@ValueMapValue
	private String needHelpModalId;

	@ValueMapValue
	private String tncText;

	@ValueMapValue
	private String buttonLabel;

	@ValueMapValue
	private String buttonLink;

	@ValueMapValue
	private String buttonSecondaryLinkCodes;

	@ValueMapValue
	private String oopsErrorCodes;

	@ValueMapValue
	private String phoneOfferErrorCodes;

	@ValueMapValue
	private String simOfferCodes;

	@ValueMapValue
	private String inputVerifyDevice;

	@ValueMapValue
	private String inputVerifySim;

	@ValueMapValue
	private String almostThereErrorCodes;

	@ValueMapValue
	private String perfectCodes;

	@ValueMapValue
	private String helptext;

	@ValueMapValue
	private String helpTextAriaLabel;

	@ValueMapValue
	private String buttonAriaLabel;

	@ValueMapValue
	private String summary;

	@ValueMapValue
	private String pageType;

	@ValueMapValue
	private String guestLineLockedModalId;

	@ValueMapValue
	private String guestLineUnlockedModalId;

	@ValueMapValue
	private String authLineLockedModalId;

	@ValueMapValue
	private String authLineUnlockedModalId;
	
	@Inject
	private Resource resource;

	/**
     * @return String - exported Type
     */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
	/**
     * @return String - imagePath
     */
	@Override
	public String getImagePath() {
		return imagePath;
	}

	/**
     * @return String - heading
     */
	@Override
	public String getHeading() {
		return heading;
	}
	
	/**
     * @return String - getSubheadingone
     */
	@Override
	public String getSubheadingone() {
		return subheadingone;
	}

	/**
     * @return String - getSubheadingtwo
     */
	@Override
	public String getSubheadingtwo() {
		return subheadingtwo;
	}

	/**
     * @return String - inputFieldPlaceholder
     */
	@Override
	public String getInputFieldPlaceholder() {
		return inputFieldPlaceholder;
	}

	/**	
	 * @return String - inputFieldLastFourDigits
	 */
	@Override
	public String getInputFieldLastFourDigits() {
		return inputFieldLastFourDigits;
	}

	/**	
	 * @return String - inputOtpPlaceholder
	 */
	@Override
	public String getInputOtpPlaceholder() {
		return inputOtpPlaceholder;
	}

	/**
	 * @return String - videolink
	 */
	@Override
	public String getVideolink() {
		return videolink;
	}

	/**
	 * @return String - needHelpModalId
	 */
	@Override
	public String getNeedHelpModalId() {
		return needHelpModalId;
	}

	/**
     * @return String - tncText
     */
	@Override
	public String getTncText() {
		return tncText;
	}

	/**
     * @return String - buttonLabel
     */
	@Override
	public String getButtonLabel() {
		return buttonLabel;
	}

	/**
     * @return String - buttonLink
     */
	@Override
	public String getButtonLink() {
		return buttonLink;
	}

	/**
     * @return String - buttonSecondaryLinkCodes
     */
	@Override
	public String getButtonSecondaryLinkCodes() {
		return buttonSecondaryLinkCodes;
	}

	/**
     * @return String - oopsErrorCodes
     */
	@Override
	public String getOopsErrorCodes() {
		return oopsErrorCodes;
	}

	/**
     * @return String - phoneOfferErrorCodes
     */
	@Override
	public String getPhoneOfferErrorCodes() {
		return phoneOfferErrorCodes;
	}

	/**
     * @return String - simOfferCodes
     */
	@Override
	public String getSimOfferCodes() {
		return simOfferCodes;
	}

	/**
     * @return String - inputVerifyDevice
     */
	@Override
	public String getInputVerifyDevice() {
		return inputVerifyDevice;
	}

	
	/**
     * @return String - inputVerifySim
     */
	@Override
	public String getInputVerifySim() {
		return inputVerifySim;
	}

	/**
     * @return String - almostThereErrorCodes
     */
	@Override
	public String getAlmostThereErrorCodes() {
		return almostThereErrorCodes;
	}

	/**
     * @return String - perfectCodes
     */
	@Override
	public String getPerfectCodes() {
		return perfectCodes;
	}

	/**
     * @return String - helptext
     */
	@Override
	public String getHelptext() {
		return helptext;
	}

	/**
	 * @return helpTextAriaLabel
	 */
	@Override
	public String getHelpTextAriaLabel() {
		return helpTextAriaLabel;
	};

	/**
	 * @return buttonAriaLabel
	 */
	@Override
	public String getButtonAriaLabel() {
		return buttonAriaLabel;
	};

	/**
     * @return String - summary
     */
	@Override
	public String getSummary() {
		return summary;
	}

	/**
     * @return String - pageType
     */
	@Override
	public String getPageType() {
		return pageType;
	}

	/**
	 * Get the Guest Line Locked Modal Id
	 *
	 * @return String - getGuestLineLockedModalId
	 */
	public String getGuestLineLockedModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(guestLineLockedModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * Get the Guest Line Unlocked Modal Id
	 *
	 * @return String - getGuestLineUnlockedModalId
	 */
	public String getGuestLineUnlockedModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(guestLineUnlockedModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * Get the Guest Line Locked Modal Id
	 *
	 * @return String - getAuthLineLockedModalId
	 */
	public String getAuthLineLockedModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(authLineLockedModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * Get the Guest Line Unlocked Modal Id
	 *
	 * @return String - getAuthLineUnlockedModalId
	 */
	public String getAuthLineUnlockedModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(authLineUnlockedModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

}
