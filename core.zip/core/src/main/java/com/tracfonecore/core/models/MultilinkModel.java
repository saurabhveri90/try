/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.LinkBean;

/**
 * Defines the {@code Multi-Links} Sling Model used for the {@code /apps/tracfone-core/components/content/multilinks} component.
 */
public interface MultilinkModel extends ComponentExporter {

	/**
	 * <p>Fetches heading for the multi-links</p>
	 * 
	 * @return String - heading for the multi-links
	 */
	@JsonProperty("heading")
	public String getHeading();
	
	/**
	 * <p>Fetches font size for the multi-links text</p>
	 * 
	 * @return String - alignment for the multi-links
	 */
	@JsonProperty("fontSize")
	public String getFontSize();
	
	
	/**
	 * <p>Fetches all the multi-links</p>
	 * 
	 * @return String - all the multi-links
	 */
	@JsonProperty("links")
	public List<LinkBean> getMultilinks();
}
