package com.tracfonecore.core.models;
import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
/**
 * Defines the {@code Multi-Links} Sling Model used for the {@code /apps/tracfone-core/components/spa/commerce/userauthentication/v1/userauthentication} component.
 */
public interface PwdRecoveryFRModel extends ComponentExporter {
    
    /**
     * <p>Fetches checkoutPagePath for the userauthentication</p>
     * 
     * @return String - labelText
     */
    @JsonProperty("testPwdText")
    public String getTestPwdText();
    
}