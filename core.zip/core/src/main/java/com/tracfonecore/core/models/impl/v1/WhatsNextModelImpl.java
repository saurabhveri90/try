/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl.v1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.tracfonecore.core.utils.ApplicationUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.PaymentOptionBean;
import com.tracfonecore.core.beans.PurchaseScenarioBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.WhatsNextModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { WhatsNextModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/content/whatsnext/v1/whatsnext", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class WhatsNextModelImpl implements WhatsNextModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;

	@Inject
	private Resource resource;

	@Inject
	@Default(values = "phone")
	private String flowType;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headlineWhatsNext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subHeadlineWhatsNext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String freePhoneSubHeadlineWhatsNext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String freePhoneHeadlineActivationTips;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String freePhoneSubHeadlineActivationTips;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String freeSimSubHeadlineWhatsNext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String freeSimHeadlineActivationTips;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String freeSimSubHeadlineActivationTips;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headlineActivationTips;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String protectingYourMobileIdentityLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subHeadlineActivationTips;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String productLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String productLogoAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String marketPlaceHeadlineWhatsNext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String marketPlaceSubHeadlineWhatsNext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String marketPlaceHeadlineActivationTips;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String marketPlaceSubHeadlineActivationTips;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String componentVersion;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String homeInternetHeadlineWhatsNext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String homeInternetSubHeadlineWhatsNext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String homeInternetHeadlineActivationTips;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String homeInternetSubHeadlineActivationTips;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stByop25HeadingWhatsNext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stByop25SubHeadlineWhatsNext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stByop25WhatsNextActivationTips;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stByop25HeadlineActivationTips;

	private List<PurchaseScenarioBean> purchaseScenarios = Collections.emptyList();

	private List<PurchaseScenarioBean> stpurchaseScenarios = Collections.emptyList();

	@PostConstruct
	private void initModel() {
		purchaseScenarios = new ArrayList<>();
		stpurchaseScenarios = new ArrayList<>();
		if (resource != null) {
			getMultifieldResource();
			getSTMultifieldResource();
		}
	}

	private void getMultifieldResource() {
		for (Resource child : resource.getChildren()) {
			Iterator<Resource> it = child.listChildren();
			if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.PURCHASE_SCENARIOS.equals(child.getName())) {
				while (it.hasNext()) {
					PurchaseScenarioBean purchaseScenarioBean = new PurchaseScenarioBean();
					Resource grandChild = it.next();
					purchaseScenarioBean
							.setPurchaseScenario(grandChild.getValueMap().get("purchaseScenario", String.class));

					purchaseScenarioBean.setWhatsNextHeadlineForSelectedScenario(
							grandChild.getValueMap().get("whatsNextHeadlineForSelectedScenario", String.class));

					purchaseScenarioBean.setWhatsNextSubheadlineForSelectedScenario(
							grandChild.getValueMap().get("whatsNextSubheadlineForSelectedScenario", String.class));

					purchaseScenarioBean.setActivationTipsHeadlineForSelectedScenario(
							grandChild.getValueMap().get("activationTipsHeadlineForSelectedScenario", String.class));

					purchaseScenarioBean.setActivationTipsSubheadlineForSelectedScenario(
							grandChild.getValueMap().get("activationTipsSubheadlineForSelectedScenario", String.class));

					purchaseScenarioBean.setActivationTipsProductLogoForSelectedScenario(
							grandChild.getValueMap().get("activationTipsProductLogoForSelectedScenario", String.class));

					purchaseScenarioBean.setActivationTipsProductLogoAltTextForSelectedScenario(grandChild.getValueMap()
							.get("activationTipsProductLogoAltTextForSelectedScenario", String.class));

					purchaseScenarios.add(purchaseScenarioBean);
				}
			}
		}
	}

	private void getSTMultifieldResource() {
		for (Resource child : resource.getChildren()) {
			Iterator<Resource> it = child.listChildren();
			if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.ST_PURCHASE_SCENARIOS.equals(child.getName())) {
				while (it.hasNext()) {
					PurchaseScenarioBean purchaseScenarioBean = new PurchaseScenarioBean();
					Resource grandChild = it.next();
					purchaseScenarioBean
							.setSTPurchaseScenario(grandChild.getValueMap().get("stpurchaseScenario", String.class));

					purchaseScenarioBean.setSTWhatsNextHeadlineForSelectedScenario(
							grandChild.getValueMap().get("stwhatsNextHeadlineForSelectedScenario", String.class));

					purchaseScenarioBean.setSTWhatsNextSubheadlineForSelectedScenario(
							grandChild.getValueMap().get("stwhatsNextSubheadlineForSelectedScenario", String.class));

					purchaseScenarioBean.setSTActivationTipsHeadlineForSelectedScenario(
							grandChild.getValueMap().get("stactivationTipsHeadlineForSelectedScenario", String.class));

					purchaseScenarioBean.setSTActivationTipsSubheadlineForSelectedScenario(
							grandChild.getValueMap().get("stactivationTipsSubheadlineForSelectedScenario", String.class));

					purchaseScenarioBean.setSTActivationTipsProductLogoForSelectedScenario(
							grandChild.getValueMap().get("stactivationTipsProductLogoForSelectedScenario", String.class));

					purchaseScenarioBean.setSTActivationTipsProductLogoAltTextForSelectedScenario(grandChild.getValueMap()
							.get("stactivationTipsProductLogoAltTextForSelectedScenario", String.class));

					stpurchaseScenarios.add(purchaseScenarioBean);
				}
			}
		}
	}

	@Override
	public String getComponentVersion() {
		return StringUtils.isNotBlank(componentVersion) ? componentVersion : "v1";
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getHeadlineWhatsNext() {
		return headlineWhatsNext;
	}

	@Override
	public String getSubHeadlineWhatsNext() {
		return subHeadlineWhatsNext;
	}

	@Override
	public String getFlowType() {
		return flowType;
	}

	@Override
	public String getFreePhoneSubHeadlineWhatsNext() {
		return freePhoneSubHeadlineWhatsNext;
	}

	@Override
	public String getFreePhoneHeadlineActivationTips() {
		return freePhoneHeadlineActivationTips;
	}

	@Override
	public String getFreePhoneSubHeadlineActivationTips() {
		return freePhoneSubHeadlineActivationTips;
	}

	@Override
	public String getFreeSimSubHeadlineWhatsNext() {
		return freeSimSubHeadlineWhatsNext;
	}

	@Override
	public String getFreeSimHeadlineActivationTips() {
		return freeSimHeadlineActivationTips;
	}

	@Override
	public String getFreeSimSubHeadlineActivationTips() {
		return freeSimSubHeadlineActivationTips;
	}

	@Override
	public String getHeadlineActivationTips() {
		return headlineActivationTips;
	}

	@Override
	public String getProtectingYourMobileIdentityLink() {
		return protectingYourMobileIdentityLink;
	}

	@Override
	public String getSubHeadlineActivationTips() {
		return subHeadlineActivationTips;
	}

	@Override
	public String getProductLogo() {
		return productLogo;
	}

	@Override
	public String getProductLogoAltText() {
		return productLogoAltText;
	}

	@Override
	public String getMarketPlaceHeadlineWhatsNext() {
		return marketPlaceHeadlineWhatsNext;
	}

	@Override
	public String getMarketPlaceSubHeadlineWhatsNext() {
		return marketPlaceSubHeadlineWhatsNext;
	}

	@Override
	public String getMarketPlaceHeadlineActivationTips() {
		return marketPlaceHeadlineActivationTips;
	}

	@Override
	public String getMarketPlaceSubHeadlineActivationTips() {
		return marketPlaceSubHeadlineActivationTips;
	}

	@Override
	public String getProductLogoAssetId() {
		return ApplicationUtil.getAssetId(productLogo,
				request.getResourceResolver(), ApplicationConstants.IMAGE);
	}

	@Override
	public String getProductLogoAssetAgencyId() {
		return ApplicationUtil.getAssetMetaDataValue(productLogo,
				request.getResourceResolver(), ApplicationConstants.WEBER_ID);
	}

	@Override
	public List<PurchaseScenarioBean> getPurchaseScenarios() {
		return new ArrayList<>(purchaseScenarios);
	}

	@Override
	public List<PurchaseScenarioBean> getSTPurchaseScenarios() {
		return new ArrayList<>(stpurchaseScenarios);
	}

	@Override
	public String getHomeInternetHeadlineWhatsNext() {
		return homeInternetHeadlineWhatsNext;
	}

	@Override
	public String getHomeInternetSubHeadlineWhatsNext() {
		return homeInternetSubHeadlineWhatsNext;
	}

	@Override
	public String getHomeInternetHeadlineActivationTips() {
		return homeInternetHeadlineActivationTips;
	}

	@Override
	public String getHomeInternetSubHeadlineActivationTips() {
		return homeInternetSubHeadlineActivationTips;
	}

	@Override
	public String getByop25HeadlineWhatsNext() {
		return stByop25HeadingWhatsNext;
	}

	@Override
	public String getByop25SubHeadlineWhatsNext() {
		return stByop25SubHeadlineWhatsNext;
	}

	@Override
	public String getByop25HeadlineActivationTips() {
		return stByop25WhatsNextActivationTips;
	}

	@Override
	public String getByop25SubHeadlineActivationTips() {
		return stByop25HeadlineActivationTips;
	}
}