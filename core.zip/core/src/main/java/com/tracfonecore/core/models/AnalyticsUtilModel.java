/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

public interface  AnalyticsUtilModel {


	/**
	 * <p>
	 * Fetches assetId of the asset
	 * </p>
	 *
	 * @return String - - assetId 
	 */
	public String getAssetId();

	/**
	 * <p>
	 * Fetches ctaAnalyticText
	 * </p>
	 *
	 * @return String - ctaAnalyticText
	 */
	public String getCtaAnalyticText();
	/**
	 * <p>
	 * Fetches placementText
	 * </p>
	 *
	 * @return String - placementText
	 */
	public String getPlacementText();
	/**
	 * <p>
	 * Fetches videoAssetId
	 * </p>
	 *
	 * @return String - videoAssetId
	 */
	public String getVideoAssetId();

	/**
	 *<p>Fetches imageWeberId</p>
	 *
	 * @return the imageWeberId
	 */
	public String getImageWeberId();
	/**
	 *<p>Fetches videoWeberId</p>
	 *
	 * @return the videoWeberId
	 */
	public String getVideoWeberId();
	
}