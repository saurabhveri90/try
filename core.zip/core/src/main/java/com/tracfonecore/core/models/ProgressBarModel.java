/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Multi-Links} Sling Model used for the {@code /apps/tracfone-core/components/spa/commerce/progressbar} component.
 */
public interface ProgressBarModel extends ComponentExporter {
	/**
	 * <p>Fetches text to be displayed in the progress bar component</p>
	 * 
	 * @return String - progressText for the progress bar component
	 */
	@JsonProperty("progressText")
	public String getProgressText();
	
}
