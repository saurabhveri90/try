package com.tracfonecore.core.beans;

public class DynamicVasBean{

	private String dynamicVasPartNumber;	
    private String dynamicVasPlanName;
    private String dynamicVasVendorUrl;
    private String openVendorUrlNewTab;
	private String vendorUrlAccessibleText;
    private String dynamicVasIcon;
    private String dynamicVasIconAltText;
	private String changePartNumber;
	private String changePlanName;
	private String autoEnrollBtnLabel;
    private String autoEnrollBtnAccessibleText;
    private String cancelEnrollBtnLabel;
    private String cancelEnrollBtnAccessibleText;
	private String suspendedResumeBtnLabel;
	private String suspendedResumeBtnAccessibleText;
	private String vendorActionMsg;
	private String expandBtnAccLabel;
	private String resumeCancelledMsg;
	private String resumeSuspendMsg;
	private String cancelledResumeBtnLabel;
	private String cancelledResumeBtnAccessibleText;
	private String activationPageTitle;
	private String activationInfoHeader;
	private String vendorName;
	private String activationPageDescription;
	private String activationPageBtnAcceLabel;
	private String vendorActivationdesc;
	private String vendorActivationdisclaimer;
	private String vendorActivationBtnLabel;
	private String vendorActivationBtnAccLabel;
	public String getDynamicVasPartNumber() {
		return dynamicVasPartNumber;
	}
	public void setDynamicVasPartNumber(String dynamicVasPartNumber) {
		this.dynamicVasPartNumber = dynamicVasPartNumber;
	}
	public String getDynamicVasPlanName() {
		return dynamicVasPlanName;
	}
	public void setDynamicVasPlanName(String dynamicVasPlanName) {
		this.dynamicVasPlanName = dynamicVasPlanName;
	}
	public String getDynamicVasVendorUrl() {
		return dynamicVasVendorUrl;
	}
	public void setDynamicVasVendorUrl(String dynamicVasVendorUrl) {
		this.dynamicVasVendorUrl = dynamicVasVendorUrl;
	}
	public String getOpenVendorUrlNewTab() {
		return openVendorUrlNewTab;
	}
	public void setOpenVendorUrlNewTab(String openVendorUrlNewTab) {
		this.openVendorUrlNewTab = openVendorUrlNewTab;
	}
	public String getVendorUrlAccessibleText() {
		return vendorUrlAccessibleText;
	}
	public void setVendorUrlAccessibleText(String vendorUrlAccessibleText) {
		this.vendorUrlAccessibleText = vendorUrlAccessibleText;
	}
	public String getDynamicVasIcon() {
		return dynamicVasIcon;
	}
	public void setDynamicVasIcon(String dynamicVasIcon) {
		this.dynamicVasIcon = dynamicVasIcon;
	}
	public String getDynamicVasIconAltText() {
		return dynamicVasIconAltText;
	}
	public void setDynamicVasIconAltText(String dynamicVasIconAltText) {
		this.dynamicVasIconAltText = dynamicVasIconAltText;
	}
	public String getChangePartNumber() {
		return changePartNumber;
	}
	public void setChangePartNumber(String changePartNumber) {
		this.changePartNumber = changePartNumber;
	}
	public String getChangePlanName() {
		return changePlanName;
	}
	public void setChangePlanName(String changePlanName) {
		this.changePlanName = changePlanName;
	}
	public String getAutoEnrollBtnLabel() {
		return autoEnrollBtnLabel;
	}
	public void setAutoEnrollBtnLabel(String autoEnrollBtnLabel) {
		this.autoEnrollBtnLabel = autoEnrollBtnLabel;
	}
	public String getAutoEnrollBtnAccessibleText() {
		return autoEnrollBtnAccessibleText;
	}
	public void setAutoEnrollBtnAccessibleText(String autoEnrollBtnAccessibleText) {
		this.autoEnrollBtnAccessibleText = autoEnrollBtnAccessibleText;
	}
	public String getCancelEnrollBtnLabel() {
		return cancelEnrollBtnLabel;
	}
	public void setCancelEnrollBtnLabel(String cancelEnrollBtnLabel) {
		this.cancelEnrollBtnLabel = cancelEnrollBtnLabel;
	}
	public String getCancelEnrollBtnAccessibleText() {
		return cancelEnrollBtnAccessibleText;
	}
	public void setCancelEnrollBtnAccessibleText(
			String cancelEnrollBtnAccessibleText) {
		this.cancelEnrollBtnAccessibleText = cancelEnrollBtnAccessibleText;
	}
	public String getSuspendedResumeBtnLabel() {
		return suspendedResumeBtnLabel;
	}
	public void setSuspendedResumeBtnLabel(String suspendedResumeBtnLabel) {
		this.suspendedResumeBtnLabel = suspendedResumeBtnLabel;
	}
	public String getSuspendedResumeBtnAccessibleText() {
		return suspendedResumeBtnAccessibleText;
	}
	public void setSuspendedResumeBtnAccessibleText(
			String suspendedResumeBtnAccessibleText) {
		this.suspendedResumeBtnAccessibleText = suspendedResumeBtnAccessibleText;
	}
	public String getVendorActionMsg() {
		return vendorActionMsg;
	}
	public void setVendorActionMsg(String vendorActionMsg) {
		this.vendorActionMsg = vendorActionMsg;
	}
	public String getExpandBtnAccLabel() {
		return expandBtnAccLabel;
	}
	public void setExpandBtnAccLabel(String expandBtnAccLabel) {
		this.expandBtnAccLabel = expandBtnAccLabel;
	}
	public String getResumeCancelledMsg() {
		return resumeCancelledMsg;
	}
	public void setResumeCancelledMsg(String resumeCancelledMsg) {
		this.resumeCancelledMsg = resumeCancelledMsg;
	}
	public String getResumeSuspendMsg() {
		return resumeSuspendMsg;
	}
	public void setResumeSuspendMsg(String resumeSuspendMsg) {
		this.resumeSuspendMsg = resumeSuspendMsg;
	}
	public String getCancelledResumeBtnLabel() {
		return cancelledResumeBtnLabel;
	}
	public void setCancelledResumeBtnLabel(String cancelledResumeBtnLabel) {
		this.cancelledResumeBtnLabel = cancelledResumeBtnLabel;
	}
	public String getCancelledResumeBtnAccessibleText() {
		return cancelledResumeBtnAccessibleText;
	}
	public void setCancelledResumeBtnAccessibleText(
			String cancelledResumeBtnAccessibleText) {
		this.cancelledResumeBtnAccessibleText = cancelledResumeBtnAccessibleText;
	}
	public String getActivationPageTitle() {
		return activationPageTitle;
	}
	public void setActivationPageTitle(String activationPageTitle) {
		this.activationPageTitle = activationPageTitle;
	}
	public String getActivationInfoHeader() {
		return activationInfoHeader;
	}
	public void setActivationInfoHeader(String activationInfoHeader) {
		this.activationInfoHeader = activationInfoHeader;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getActivationPageDescription() {
		return activationPageDescription;
	}
	public void setActivationPageDescription(String activationPageDescription) {
		this.activationPageDescription = activationPageDescription;
	}
	public String getActivationPageBtnAcceLabel() {
		return activationPageBtnAcceLabel;
	}
	public void setActivationPageBtnAcceLabel(String activationPageBtnAcceLabel) {
		this.activationPageBtnAcceLabel = activationPageBtnAcceLabel;
	}
	public String getVendorActivationdesc() {
		return vendorActivationdesc;
	}
	public void setVendorActivationdesc(String vendorActivationdesc) {
		this.vendorActivationdesc = vendorActivationdesc;
	}
	public String getVendorActivationdisclaimer() {
		return vendorActivationdisclaimer;
	}
	public void setVendorActivationdisclaimer(String vendorActivationdisclaimer) {
		this.vendorActivationdisclaimer = vendorActivationdisclaimer;
	}	
	public String getVendorActivationBtnLabel() {
		return vendorActivationBtnLabel;
	}
	public void setVendorActivationBtnLabel(String vendorActivationBtnLabel) {
		this.vendorActivationBtnLabel = vendorActivationBtnLabel;
	}
	public String getVendorActivationBtnAccLabel() {
		return vendorActivationBtnAccLabel;
	}
	public void setVendorActivationBtnAccLabel(String vendorActivationBtnAccLabel) {
		this.vendorActivationBtnAccLabel = vendorActivationBtnAccLabel;
	}

}

