package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

public interface LocationFinderModel extends ComponentExporter {

	/**
	 * <p>
	 * Fetches backgroundImage
	 * </p>
	 * 
	 * @return String - backgroundImage
	 */
	@JsonProperty("backgroundImage")
	public String getBackgroundImage();
}
