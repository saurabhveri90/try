/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.settings.SlingSettingsService;
import javax.inject.Inject;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.AccountDashboardModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.constants.ApplicationConstants;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { AccountDashboardModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/content/accountdashboard", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class AccountDashboardModelImpl implements AccountDashboardModel {

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private SlingSettingsService settingService;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accountProfileImagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accountProfileMobileImagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accountProfileImageAltText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String refillNotifyMinDays;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ccExpiryNotifyMinMonth;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String activationDateDifference;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String noOfRetryForServicePlanApi;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String initialTimeIntervalForRetry;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String diffInTimeIntervalBy;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String maxMinutes;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String maxMessage;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String maxData;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String maxDataTMOCarrier;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String deviceTypeRegexForMyUsageTalk;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String deviceTypeRegexForMyUsageText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String deviceTypeRegexToShowMyUsageTalkText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String activationPagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String refillPLPPageSelector;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String refillPLPPagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String refillLandingPagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ildPlanPartNumber;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ildPlanEditCartUrl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String categoryIdPlans;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String refillBuyNowPLPPageSelector;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enableClosestStoreComponent;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String disableEstimateCallForAccBal;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accBalanceAutoPayOnDueMsg;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String notificationCardHeading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String notificationCardSubheading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enableNotification;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String checkoutDetailComponentVersion;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String disableFetchMyUsagePlanDetail;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String refillStartDateSelector;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String myBalanceServicePeriodNote;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String myBalanceExpirationDateNote;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String maxNumberOfClosestStores;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String maxRadiusForClosestStores;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String activationCardHeading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String activationCardCardSubheading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enableActivationNotification;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String restartYourPhoneText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String videoStreamingText;

	@ValueMapValue
	private String purchaseSubheading;
	@ValueMapValue
	private String purchaseSubHeadingIconPath;
	@ValueMapValue
	private String purchaseHeading;
	@ValueMapValue
	private String purchaseDescription;
	@ValueMapValue
	private String purchaseCtaLabel;
	@ValueMapValue
	private String purchaseCtaLink;
	@ValueMapValue
	private String purchaseLearnmoreLabel;
	@ValueMapValue
	private String purchaseLearnmoreLink;
	@Override
	public String getPurchaseSubheading() {
		return purchaseSubheading;
	}
	@Override
	public String getPurchaseSubHeadingIconPath() {
		return purchaseSubHeadingIconPath;
	}
	@Override
	public String getPurchaseHeading() {
		return purchaseHeading;
	}
	@Override
	public String getPurchaseDescription() {
		return purchaseDescription;
	}
	@Override
	public String getPurchaseCtaLabel() {
		return purchaseCtaLabel;
	}
	@Override
	public String getPurchaseCtaLink() {
		return ApplicationUtil.getUrlWithoutDomain(ApplicationUtil.getShortUrl(request.getResourceResolver(), purchaseCtaLink));
	}
	@Override
	public String getPurchaseLearnmoreLabel() {
		return purchaseLearnmoreLabel;
	}
	@Override
	public String getPurchaseLearnmoreLink() {
		return ApplicationUtil.getUrlWithoutDomain(ApplicationUtil.getShortUrl(request.getResourceResolver(), purchaseLearnmoreLink));
	}

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String partNumberToogle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String walmartActivationPagePath;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String walmartImagePath;

	@Override
	public String getAccountProfileImageAltText() {
		return accountProfileImageAltText;
	}

    @Override
	public String getAccountProfileImagePath() {
	     return DynamicMediaUtils.changeMediaPathToDMPath(accountProfileImagePath, request.getResourceResolver());
	}

	@Override
	public String getAccountProfileMobileImagePath() {
	     return DynamicMediaUtils.changeMediaPathToDMPath(accountProfileMobileImagePath, request.getResourceResolver());
	}
	
	@Override
	public String getRefillNotifyMinDays() {
		return refillNotifyMinDays;
	}
	
	@Override
	public String getCcExpiryNotifyMinMonth() {
		return ccExpiryNotifyMinMonth;
	}
	
	@Override
	public String getActivationDateDifference() {
		return activationDateDifference;
	}


    @Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getNoOfRetryForServicePlanApi() {
		return noOfRetryForServicePlanApi;
	}

	@Override
	public String getInitialTimeIntervalForRetry() {
		return initialTimeIntervalForRetry;
	}

	@Override
	public String getDiffInTimeIntervalBy() {
		return diffInTimeIntervalBy;
	}

	@Override
	public String getMaxMinutes() {
		return maxMinutes;
	}

	@Override
	public String getMaxMessage() {
		return maxMessage;
	}

	@Override
	public String getMaxData() {
		return maxData;
	}

	@Override
	public String getMaxDataTMOCarrier() {
		return maxDataTMOCarrier;
	}

	@Override
	public String getDeviceTypeRegexForMyUsageTalk() {
		return deviceTypeRegexForMyUsageTalk;
	}

	@Override
	public String getDeviceTypeRegexForMyUsageText() {
		return deviceTypeRegexForMyUsageText;
	}

	@Override
	public String getDeviceTypeRegexToShowMyUsageTalkText() {
		return deviceTypeRegexToShowMyUsageTalkText;
	}

	@Override
	public String getActivationPagePath() {
		return getFinalPagePathWithoutExtension(activationPagePath);
	}

	@Override
	public String getRefillPLPPageSelector() {
		return refillPLPPageSelector;
	}

	@Override
	public String getRefillPLPPagePath() {
		return getFinalPagePathWithoutExtension(refillPLPPagePath);
	}

	@Override
	public String getRefillLandingPagePath() {
		return getFinalPagePath(refillLandingPagePath);
	}

	@Override
	public String getCategoryIdPlans() {
		return categoryIdPlans;
	}

	@Override
	public String getIldPlanPartNumber() {
		return ildPlanPartNumber;
	}

	@Override
	public String getIldPlanEditCartUrl() {
		return ildPlanEditCartUrl;
	}

	@Override
	public String getRefillBuyNowPLPPageSelector() {
		return refillBuyNowPLPPageSelector;
	}

	@Override
	public String getRefillStartDateSelector() {
		return refillStartDateSelector;
	}

	public String getFinalPagePathWithoutExtension(String inputPath) {
		String finalPagePath = inputPath;
		if (StringUtils.isNotBlank(finalPagePath)) {
			String ctaPath = request.getResourceResolver().map(finalPagePath);
			if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
				finalPagePath = ApplicationUtil
						.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
			}
		}
		return finalPagePath;
	}

	private String getShortURL(String serverDomain, String url) {
		if(StringUtils.isNotBlank(url) && StringUtils.isNotBlank(serverDomain) && url.contains(serverDomain)) {
			url = url.split(serverDomain)[1];
		}
		return url;
	}

	public String getFinalPagePath(String inputPath) {
		String finalPagePath = inputPath;
		if (StringUtils.isNotBlank(finalPagePath) &&  Boolean.TRUE.equals(ApplicationUtil.isInternalLink(finalPagePath))) {
			if (finalPagePath.indexOf(ApplicationConstants.HTML_EXTENSION) == -1) {
				finalPagePath = finalPagePath + ApplicationConstants.HTML_EXTENSION;
			}
			if (StringUtils.isNotBlank(finalPagePath)) {
				String ctaPath = request.getResourceResolver().map(finalPagePath);
				if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
					finalPagePath = ApplicationUtil
							.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
				}
			}
		}
		return finalPagePath;
	}

	@Override
	public String getNotificationCardHeading() {
		return notificationCardHeading;
	}

	@Override
	public String getNotificationCardSubheading() {
		return notificationCardSubheading;
	}

	@Override
	public String getEnableNotification() {
		return enableNotification;
	}

	@Override
	public String getCheckoutDetailComponentVersion() {
		return StringUtils.isNotBlank(checkoutDetailComponentVersion)? checkoutDetailComponentVersion:"v1";
	}

	@Override
	public Boolean getFetchMyUsagePlanDetail() {
		Boolean fetchMyUsagePlanDetail= true;
		if(StringUtils.isBlank(disableFetchMyUsagePlanDetail)||"false".equalsIgnoreCase(disableFetchMyUsagePlanDetail)){
			fetchMyUsagePlanDetail = true;
		}else{
			fetchMyUsagePlanDetail = false;
		}
		return fetchMyUsagePlanDetail;
	}

	@Override
	public Boolean getEnableClosestStoreComponent() {
		Boolean enableClosestStore = true;
		if(StringUtils.isBlank(enableClosestStoreComponent)||"false".equalsIgnoreCase(enableClosestStoreComponent)){
			enableClosestStore = false;
		}else{
			enableClosestStore = true;
		}
		return enableClosestStore;
	}

	@Override
	public String getMyBalanceServicePeriodNote() {
		return myBalanceServicePeriodNote;
	}

	@Override
	public String getMyBalanceExpirationDateNote() {
		return myBalanceExpirationDateNote;
	}

	@Override
	public String getMaxNumberOfClosestStores() {
		return maxNumberOfClosestStores;
	}

	@Override
	public String getMaxRadiusForClosestStores() {
		return maxRadiusForClosestStores;
	}

	@Override
	public String getActivationCardHeading() {
		return activationCardHeading;
	}

	@Override
	public String getActivationCardCardSubheading() {
		return activationCardCardSubheading;
	}

	@Override
	public Boolean getEnableActivationNotification() {
		if(StringUtils.isBlank(enableActivationNotification)||"true".equalsIgnoreCase(enableActivationNotification)){
			return true;
		}else{
			return false;
		}
	}

	@Override
	public Boolean getDisableEstimateCallForAccBal() {
		if(StringUtils.isBlank(disableEstimateCallForAccBal)||"false".equalsIgnoreCase(disableEstimateCallForAccBal)){
			return false;
		}else{
			return true;
		}
	}

	@Override
	public String getAccBalanceAutoPayOnDueMsg() {
		return accBalanceAutoPayOnDueMsg;
	}

	@Override
	public String getRestartYourPhoneText(){
		return restartYourPhoneText;
	};

	@Override
	public String getVideoStreamingText(){
		return videoStreamingText;
	};

	@Override
	public String getPartNumberToogle(){
		return partNumberToogle;
	};
	
	@Override
    public String getWalmartActivationPagePath() {
        return getFinalPagePathWithoutExtension(walmartActivationPagePath);
    }

	@Override
    public String getWalmartImagePath() {
        return  walmartImagePath;
    }

}
