package com.tracfonecore.core.models;

import java.util.Collection;
import java.util.Collections;

import javax.inject.Named;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = {Resource.class}, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class IconListBannerModel {

	@ValueMapValue
	private String heading;

	@ValueMapValue
	private String description;

	@ChildResource
	@Named("iconlist")
	private Collection<IconListModel> iconlist;

	public String getHeading() {
		return heading;
	}

	public String getDescription() {
		return description;
	}

	public Collection<IconListModel> getIconlist() {
		return Collections.unmodifiableCollection(iconlist);
	}

}