/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl.v1;


import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.models.AutoRefillSignupModel;
import com.tracfonecore.core.models.impl.BaseComponentModelImpl;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { AutoRefillSignupModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/autorefillsignup/v1/autorefillsignup", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class AutoRefillSignupModelImpl extends BaseComponentModelImpl implements AutoRefillSignupModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(AutoRefillSignupModelImpl.class);
	
	@Self
	private SlingHttpServletRequest request;
	
	@Inject
	private TracfoneApiGatewayService tracfoneApiService;
	
	@Inject
	private Page currentPage;
	
	@Inject
	private ApplicationConfigService applicationConfigService;
	
	private String categoryID;
	
	private String planPDPServletPath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String purchasePagePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planThumbImgPath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String title;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String description;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String currentplanicon;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String currentplanheading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String currentplandesc;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String infoCtaText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String infoCtaAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String infoCtaModalId;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String diffplanicon;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String diffplanheading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String diffplandesc;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String loginButtonLabel;

	@Inject
	private Resource resource;
	
	
	@PostConstruct
	protected void initModel() {
		super.initModel();

		LOGGER.debug("Inside AutoRefillSignupModelImpl");
		
		String planPDPPath = tracfoneApiService.getPlanPDPServletPath();
		this.planPDPServletPath = planPDPPath.replace("{language}", getLanguage());
		String planPlpPath = StringUtils.substringBefore(planPDPServletPath, ".");
		Page planPlpPage = request.getResourceResolver().getResource(planPlpPath).adaptTo(Page.class);

		if (planPlpPage != null) {
			this.categoryID = planPlpPage.getContentResource().getValueMap().get("categoryId", String.class);
		} else {
			LOGGER.error("ExtendedPlansModelImpl: Check PlanPDPServletPath in TracfoneApiGatewayService. Path: {}", this.planPDPServletPath);
		}
	}

	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public String getCurrentPlanIcon() {
		return currentplanicon;
	}

	@Override
	public String getCurrentPlanHeading() {
		return currentplanheading;
	}

	@Override
	public String getCurrentPlanDesc() {
		return currentplandesc;
	}

	@Override
	public String getInfoCtaText() {
		return infoCtaText;
	}

	@Override
	public String getInfoCtaAltText() {
		return infoCtaAltText;
	}

	@Override
	public String getInfoCtaModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(infoCtaModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	@Override
	public String getDiffPlanIcon() {
		return diffplanicon;
	}

	@Override
	public String getDiffPlanHeading() {
		return diffplanheading;
	}

	@Override
	public String getDiffPlanDesc() {
		return diffplandesc;
	}
	
	@Override
	public String getLoginButtonLabel() {
		return loginButtonLabel;
	}
	
	/**
	 * <p>
	 * Returns categoryid from the configured Plans category page.
	 * </p>
	 * 
	 * @return String - categoryID
	 */
	@Override
	public String getCategoryID() {

		return this.categoryID;
	}
	
	/**
	 * <p>
	 * Returns home page level from configuration
	 * </p>
	 * 
	 * @return int - homepagelevel
	 */
	private int getHomePageLevel() {

		return applicationConfigService.getHomePageLevel();
	}
	
	/**
	 * <p>
	 * Returns language from util
	 * </p>
	 * 
	 * @return String - language
	 */
	@Override
	public String getLanguage() {

		return CommerceUtil.getLanguage(currentPage, getHomePageLevel());
	}
	
	@Override
	public String getPurchasePagePath() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), purchasePagePath);
	}
	
	@Override
	public String getPlanThumbImgPath() {		
		return DynamicMediaUtils.changeMediaPathToDMPath(planThumbImgPath, request.getResourceResolver());
	}
	
	/**
	 * <p>
	 * Returns plan pdp json servlet path
	 * </p>
	 * 
	 * @return String - planPDPServletPath
	 */
	@Override
	public String getPlanPDPServletPath() {
		return this.planPDPServletPath;
	}
	
	/**
	 * @return the refillPlanTypeFacet
	 */
	@Override
	public String getRefillPlanTypeFacet() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getRefillPlanTypeFacet(), getBrand());
	}
	
	/**
	 * <p>
	 * Fetches ReCaptcha SiteKey property from config
	 * </p>
	 *
	 * @return String[] - reCaptchaSiteKey
	 */
	@Override
	public String getReCaptchaSiteKey() {

		return ConfigurationUtil.getConfigValue(applicationConfigService.getReCaptchaSiteKey(), getBrand());
	}
	
	private String getBrand() {

		return CommerceUtil.getBrandValue(currentPage, getHomePageLevel());
	}
	
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

}