package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Header} Sling Model used for the {@code /apps/tracfone-core/components/spa/content/questions} component.
 */
public interface QuestionsModel extends ComponentExporter {

    @JsonProperty("componentVersion")
    public String getComponentVersion();

    /**
     * <p>Fetches headlineText for Questions Component</p>
     *
     * @return String - headlineText for Questions Component
     */
    @JsonProperty("headlineText")
    public String getHeadlineText();

    /**
     * <p>Fetches faqLinkTitle for Questions Component</p>
     *
     * @return String - faqLinkTitle for Questions Component
     */
    @JsonProperty("faqLinkTitle")
    public String getFaqLinkTitle();

    /**
     * <p>Fetches faqLinkUrl for Questions Component</p>
     *
     * @return String - faqLinkUrl for Questions Component
     */
    @JsonProperty("faqLinkUrl")
    public String getFaqLinkUrl();

    /**
     * <p>Fetches faqNewWindow for Questions Component</p>
     *
     * @return String - faqNewWindow for Questions Component
     */
    @JsonProperty("faqNewWindow")
    public String getFaqNewWindow();

    /**
     * <p>Fetches contactUsLinkTitle for Questions Component</p>
     *
     * @return String - contactUsLinkTitle for Questions Component
     */
    @JsonProperty("contactUsLinkTitle")
    public String getContactUsLinkTitle();

    /**
     * <p>Fetches contactUsLinkUrl for Questions Component</p>
     *
     * @return String - contactUsLinkUrl for Questions Component
     */
    @JsonProperty("contactUsLinkUrl")
    public String getContactUsLinkUrl();

    /**
     * <p>Fetches contactUsNewWindow for Questions Component</p>
     *
     * @return String - contactUsNewWindow for Questions Component
     */
    @JsonProperty("contactUsNewWindow")
    public String getContactUsNewWindow();

    /**
     * <p>Fetches phoneNumber for Questions Component</p>
     *
     * @return String - phoneNumber for Questions Component
     */
    @JsonProperty("phoneNumber")
    public String getPhoneNumber();

    /**
     * <p>Fetches timeAndDaysAvailable for Questions Component</p>
     *
     * @return String - timeAndDaysAvailable for Questions Component
     */
    @JsonProperty("timeAndDaysAvailable")
    public String getTimeAndDaysAvailable();

}
