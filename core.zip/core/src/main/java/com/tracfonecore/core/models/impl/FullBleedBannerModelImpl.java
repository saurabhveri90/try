/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.FullBleedBannerModel;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { FullBleedBannerModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/full-bleed-banner", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class FullBleedBannerModelImpl extends BaseComponentModelImpl
		implements FullBleedBannerModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(FullBleedBannerModelImpl.class);
	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue
	private String heading;

	@ValueMapValue
	private String subHeading;

	@ValueMapValue
	private String fullBleedImage;

	@ValueMapValue
	private String fullBleedImageMobile;

	@ValueMapValue
	private String fullBleedImageTablet;

	@ValueMapValue
	private String imageAlign;

	@ValueMapValue
	private String tooltipLogo;

	@ValueMapValue
	private String tooltipMsg;



	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}	

	@Override
	public String getHeadingTooltip() {		

		return heading.replaceAll("\\<[^>]*>","");
	}

	@Override
	public String getHeading() {

		//card1heading = card1heading.replace("card1TooltipIdentifier", card1TooltipMsg);

		return heading;
	}

	@Override
	public String getSubHeading() {

		return subHeading;
	}

	@Override
	public String getFullBleedImage() {
		return DynamicMediaUtils.changeMediaPathToDMPath(fullBleedImage, request.getResourceResolver());
	}

	@Override
	public String getFullBleedImageMobile() {
		return DynamicMediaUtils.changeMediaPathToDMPath(fullBleedImageMobile, request.getResourceResolver());
	}

	@Override
	public String getFullBleedImageTablet() {
		return DynamicMediaUtils.changeMediaPathToDMPath(fullBleedImageTablet, request.getResourceResolver());
	}

	@Override
	public String getImageAlign() {
		return imageAlign;
	}

	@Override
	public String getTooltipLogo() {
		return tooltipLogo;
	}

	@Override
	public String getTooltipMsg() {
		return tooltipMsg;
	}

}
