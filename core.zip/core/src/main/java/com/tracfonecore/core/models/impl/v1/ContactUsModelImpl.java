package com.tracfonecore.core.models.impl.v1;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.ContactUsModel;
import com.tracfonecore.core.models.impl.BaseComponentModelImpl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ContactUsModel.class,
        ComponentExporter.class }, resourceType = "tracfone-core/components/content/contactus/v1/contactus", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ContactUsModelImpl extends BaseComponentModelImpl implements ContactUsModel {

    private static final Logger LOGGER = LoggerFactory.getLogger(ContactUsModelImpl.class);

    @Self
    private SlingHttpServletRequest request;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String title;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String summary;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String addressArea;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String contactsListHeading;

    @Inject
    @Via("resource")
    private Resource contactsListItems;

    @PostConstruct
    protected void initModel() {
    	super.initModel();
        LOGGER.debug("Entering initModel method: Contact-Us Component");
    }

    @Override
    public String getTitle() {
        return this.title;
    }

    @Override
    public String getSummary() {
        return this.summary;
    }

    @Override
    public String getAddressArea() {
        return this.addressArea;
    }

    @Override
    public String getContactsListHeading() {
        return this.contactsListHeading;
    }

    @Override
    public Resource getContactsListItems() {
        return this.contactsListItems;
    }

    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }
}
