/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.FullWidthTeaserModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.ItemsExporterUtil;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.Map;


@Model(adaptables = {
        SlingHttpServletRequest.class,
        Resource.class
}, adapters = {
        FullWidthTeaserModel.class,
        ComponentExporter.class
},
        resourceType = "tracfone-core/components/content/fullwidthteaser", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true")
})
public class FullWidthTeaserModelImpl extends BaseComponentModelImpl implements FullWidthTeaserModel {

    @ScriptVariable
    private ValueMap properties;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String title;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String summary;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String mediaType;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String imageAndVideo;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String imageAltText;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String videoThumbnailReference;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String doNotFollow;
     @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String mobileVersion;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String videoThMobileVersion;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private boolean useTwoColumnLayout;
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean includeInlineDisclaimer;

	private static final Logger LOGGER = LoggerFactory.getLogger(FullWidthTeaserModelImpl.class);
	
	//Constants
	public static final String FW_MEDIA_IMAGE ="fwMediaImage";
	public static final String FW_MEDIA_VIDEO ="fwMediaVideo";

	@Self
	private SlingHttpServletRequest request;

    @Inject
    private SlingModelFilter slingModelFilter;
    @Inject
    private ModelFactory modelFactory;

    @PostConstruct
	protected void initModel() {
        LOGGER.debug("Inside Full Width Teaser model init method");
        	super.initModel();
            if (doNotFollow != null)
                doNotFollow = ApplicationUtil.getNoFollow(doNotFollow);
            else
                doNotFollow = ApplicationUtil.getNoFollow(null);
    }

    /**
     * <p>
     * Fetches title of the teaser
     * </p>
     *
     * @return String - title of the teaser
     */
    @Override
    public String getTitle() {
        return title;
    }

    /**
     * <p>
     * Fetches summary of the teaser
     * </p>
     *
     * @return String - summary of the teaser
     */
    @Override
    public String getSummary() {
        return summary;
    }

    /**
     * <p>
     * Fetches media type of the teaser
     * </p>
     *
     * @return String - media type of the teaser
     */
    @Override
    public String getMediaType() {
        return mediaType;
    }

    /**
     * <p>
     * Fetches media path of the teaser
     * </p>
     *
     * @return String - media path of the teaser
     */
    @Override
    public String getImageAndVideo() {
        String s7Path = DynamicMediaUtils.changeMediaPathToDMPath(imageAndVideo, request.getResourceResolver());
        LOGGER.debug("Fullwidth Teaser Image/Video Path: {}", s7Path);
        return s7Path;
    }

    /**
     * <p>
     * Fetches image alt text of the teaser
     * </p>
     *
     * @return String - image alt text of the teaser
     */
    @Override
    public String getImageAltText() {
        return imageAltText;
    }

    /**
     * <p>
     * Fetches video thumbnail image of the teaser
     * </p>
     *
     * @return String - video thumbnail image of the teaser
     */
    @Override
    public String getVideoThumbnailImage() {
        String s7Path = DynamicMediaUtils.changeMediaPathToDMPath(videoThumbnailReference, request.getResourceResolver());
        LOGGER.debug("Fullwidth Teaser Video thumbnail Path: {}", s7Path);
        return s7Path;
    }

    /**
     * <p>
     * Fetches video thumbnail image of the teaser
     * </p>
     *
     * @return String - video thumbnail image of the teaser
     */
    @Override
    public String getDoNotFollow() {
        return doNotFollow;
    }

    /**
     * @return getexportertype
     */
    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

    @Override
    public Map<String, ? extends ComponentExporter> getItems() {
        return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
    }
    /**
	 *  <p>
	 * Fetches break points for the image
	 * </p> 
	 * 
	 * @return String - imageProfileBreakpoints
	 */
    @Override
	public String getImageProfileBreakpoints() {
		String path = this.imageAndVideo;
		String breakPoints = "";
		if(FW_MEDIA_VIDEO.equals(this.mediaType)) {
			path = this.videoThumbnailReference;
		}
		if(ApplicationConstants.BG_SMART_CROP.equals(this.getDataMode())) {
			breakPoints = DynamicMediaUtils.getImageProfileBreakpoints(path, request.getResourceResolver());
		}
		return breakPoints;
	}
	/**
	 *<p>Fetches the path for mobile thumbnail</p>
	 *
	 * @return String - mobile thumbnail image path
	 */
    @Override
	public String getMobileThumbnailImagePath() {
		String path = DynamicMediaUtils.getMobileDMPath(this.videoThumbnailReference, request.getResourceResolver());
		if(!FW_MEDIA_VIDEO.equals(this.mediaType) && !ApplicationConstants.MOBILE_IMAGE.equals(this.videoThMobileVersion)) {
			path =  StringUtils.EMPTY;
		}
		return path;
	}
	/**
	 *<p>Fetches the path for mobile image path</p>
	 *
	 * @return String - mobile image path
	 */
    @Override
	public String getMobileMediaImagePath() {
		String path = DynamicMediaUtils.getMobileDMPath(this.imageAndVideo, request.getResourceResolver());
		if(!FW_MEDIA_IMAGE.equals(this.mediaType) && !ApplicationConstants.MOBILE_IMAGE.equals(this.mobileVersion)) {
			path = StringUtils.EMPTY; 
		}
		return path;
	}
	/**
	 *<p>Fetches the data mode</p>
	 *
	 * @return String - data mode
	 */
    @Override
	public String getDataMode() {
		String mode = this.videoThMobileVersion;
		if(FW_MEDIA_IMAGE.equals(this.mediaType)) {
			mode = this.mobileVersion;
		}
		return mode;
	}
    
	/**
	 * <p>Fetches useTwoColumnLayout</p>
	 * 
	 * @return boolean - useTwoColumnLayout
	 */
	@Override
	public boolean isUseTwoColumnLayout() {
		return useTwoColumnLayout;
	}

    /**
	 * <p>Fetches includeInlineDisclaimer</p>
	 * 
	 * @return boolean - includeInlineDisclaimer
	 */
    @Override
	public Boolean getIncludeInlineDisclaimer(){
		return includeInlineDisclaimer;
	}
}