package com.tracfonecore.core.models;

import java.util.Map;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code ProductCarousel} Sling Model used for the
 * {@code /apps/tracfone-core/components/content/productcarousel} component.
 */
public interface ProductCarouselModel extends ComponentExporter {

	/**
	 * <p>
	 * Fetches alignment of the carousel to define the layout
	 * </p>
	 * 
	 * @return String - alignment of the carousel
	 */
	@JsonProperty("carouselalignment")
	public String getCarouselAlignment();

	/**
	 * <p>
	 * Fetches header Text
	 * </p>
	 * 
	 * @return String - header Text
	 */
	@JsonProperty("headerText")
	public String getHeaderText();

	/**
	 * <p>
	 * Fetches header subtitle to be displayed
	 * </p>
	 * 
	 * @return String - header Subtitle
	 */
	@JsonProperty("headerSubtitle")
	public String getHeaderSubtitle();

	/**
	 * <p>
	 * Fetches text for the button
	 * </p>
	 * 
	 * @return String - text for the button
	 */
	@JsonProperty("ctaText")
	public String getCtaText();

	/**
	 * <p>
	 * Fetches link for the button
	 * </p>
	 * 
	 * @return String - link for the button
	 */
	@JsonProperty("ctaLink")
	public String getCtaLink();

	/**
	 * <p>
	 * Fetches Alt Text for the button
	 * </p>
	 * 
	 * @return String - Alt Text for the button
	 */
	@JsonProperty("ctaAltText")
	public String getCtaAltText();

	/**
	 * <p>
	 * Fetches target link for the button
	 * </p>
	 * 
	 * @return String - target link for the button (open link in same or different
	 *         tab/window)
	 */
	@JsonProperty("ctaTarget")
	public String getCtaTarget();
	
	/**
	 * <p>
	 * Fetches show timer option
	 * </p>
	 * 
	 * @return String - Show Timer
	 */
	@JsonProperty("showTimer")
	public String getShowTimer();

	/**
	 * <p>
	 * Fetches selected timer position
	 * </p>
	 * 
	 * @return String - selected Timer position
	*/
	@JsonProperty("selectedTimerPosition")
	public String getSelectedTimerPosition();
	
	/**
	 * <p>Fetches no-follow value for link</p>
	 *
	 * @return String - link no-follow value
	 */
	@JsonProperty("doNotFollow")
	public String getDoNotFollow();
	
	/**
	 * <p>
	 * Method to return the export child items
	 * 
	 * @return Map<String, ? extends ComponentExporter>
	 */
	public Map<String, ? extends ComponentExporter> getItems();
	
	/**
	 * <p>
	 * Fetches text Image
	 * </p>
	 * 
	 * @return String - text image path
	 */
	@JsonProperty("textImage")
	public String getTextImage();
	
	/**
	 * <p>
	 * Fetches text Image alt text
	 * </p>
	 * 
	 * @return String - text image alt text
	 */
	@JsonProperty("textImageAltText")
	public String getTextImageAltText();
	
	/**
	 * <p>
	 * Fetches overlay image
	 * </p>
	 * 
	 * @return String - overlay image path
	 */
	@JsonProperty("overlayImage")
	public String getOverlayImage();
	
	/**
	 * <p>
	 * Fetches overlay image alt text
	 * </p>
	 * 
	 * @return String - overlay image alt text
	 */
	@JsonProperty("overlayImageAltText")
	public String getOverlayImageAltText();
	
	/**
	 * <p>Fetches the image data mode</p>
	 *
	 * @return String - data mode
	 */
	@JsonProperty("dataMode")
	public String getDataMode();
	
	/**
	 * <p>Fetches image profile breakpoint</p>
	 *
	 * @return String - image profile breakpoint
	 */
	@JsonProperty("imageProfileBreakpoints")
	public String getImageProfileBreakpoints();
	
	/**
	 * <p>Fetches path for mobile image</p>
	 *
	 * @return String - mobile media image path
	 */
	@JsonProperty("mobileMediaImagePath")
	public String getMobileMediaImagePath();

}