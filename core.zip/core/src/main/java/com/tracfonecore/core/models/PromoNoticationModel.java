package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonGetter;

import java.util.List;
import java.util.Map;

public interface PromoNoticationModel extends ComponentExporter {

    @JsonGetter("generalPromoText")
    public String getGeneralPromoText();
    
    @JsonGetter("notificationIcon")
    public String getNotificationIcon();
    
    @JsonGetter("propautorefill")
    public List<PromoNotification> getPropautorefill();


    @JsonGetter("propplan")
    List<PromoNotification> getPropplan();

    String getPromoNotificationType();

    Map<String, ? extends ComponentExporter> getItems();
}
