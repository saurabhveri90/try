/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.DeviceTypeCardModel;
import com.tracfonecore.core.utils.DynamicMediaUtils;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.annotation.PostConstruct;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { DeviceTypeCardModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/deviceTypeCard", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class DeviceTypeCardModeImpl extends BaseComponentModelImpl implements DeviceTypeCardModel {


	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String title;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String summary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String imagePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String imageAltText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accessibilityLabel;	
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String progressbarTitle;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String deviceType;
	
	@ValueMapValue @Default(values="")
	private String phoneSubType;
	
	@ValueMapValue @Default(values="")
	private String byopSubType;

	@ValueMapValue @Default(values="")
	private String byotSubType;

	@ValueMapValue @Default(values="")
	private String deviceSubType;

	@ValueMapValue @Default(values="")
	private String tabletSubType;
	
	private String subType;
	
	private static final String PHONES = "phones";
	private static final String BYOP = "byop";
	private static final String DEVICE = "device";
	private static final String TABLETS = "tablets";
	private static final String BYOT = "byot";
	
	@Self
	private SlingHttpServletRequest request;

	@PostConstruct
	protected void initModel() {		
		super.initModel();
		if(StringUtils.isNotBlank(deviceType)) {
			switch(deviceType) 
	        { 
	            case PHONES: 
	            	this.subType = phoneSubType; 
	                break; 
	            case BYOP: 
	            	this.subType = byopSubType;
	                break; 
	            case DEVICE: 
	            	this.subType = deviceSubType;
	                break;
				case TABLETS:
					this.subType = tabletSubType;
					break;
				case BYOT:
					this.subType = byotSubType;
					break;
	            default:
	            	this.subType = "";
	        }
		}
	}	

	/**
	 * <p>
	 * Fetches title for Device Type
	 * </p>
	 * 
	 * @return String - title for Device Type
	 */
	@Override
	public String getTitle() {
		return title;
	}
	/**
	 * <p>Fetches summary for Device Type Card</p>
	 * 
	 * @return String - summary for Device Type Card
	 */
	@Override
	public String getSummary() {
		return summary;
	}

	/**
	 * <p>Fetches image Path for Device Type Card</p>
	 * 
	 * @return String - image Path for Device Type Card
	 */
	@Override
	public String getImagePath() {
		String s7Path = StringUtils.EMPTY;
		if (StringUtils.isNotEmpty(imagePath)) {
			 s7Path = DynamicMediaUtils.changeMediaPathToDMPath(imagePath, request.getResourceResolver());
		}
		return s7Path;
	}
	
	/**
	 * <p>Fetches image Alt Text for Device Type Card</p>
	 * 
	 * @return String - image Alt Text for Device Type Card
	 */
	@Override
	public String getImageAltText() {
		return imageAltText;
	}
	
	/**
	 * <p>Fetches accessbility Label for Device Type Card</p>
	 * 
	 * @return String - accessbility Label for Device Type Card
	 */
	@Override
	public String getAccessibilityLabel() {
		return accessibilityLabel;
	}
	

	/**
	 * @return String - exportedType
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
	/**
	 * <p>Fetches progressbarTitle for Activation flow</p>
	 * 
	 * @return String - progressbar Title for Activation flow
	 */
	@Override
	public String getProgressbarTitle() {
		return progressbarTitle;
	}
	
	/**
	 * <p>Fetches deviceType for Activation flow</p>
	 * 
	 * @return String - deviceType for Activation flow
	 */
	@Override
	public String getDeviceType(){
		return deviceType;
	}

	/**
	 * @return the subType
	 */
	@Override
	public String getSubType() {
		return subType;
	}
	

}