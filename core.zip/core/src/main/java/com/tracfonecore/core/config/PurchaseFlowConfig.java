package com.tracfonecore.core.config;


import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Purchase Flow Configuration", description = "Purchase Flow Configuration")
public @interface PurchaseFlowConfig {
	
	@AttributeDefinition(name = "Purchase Flow",description = "Purchase Flow")
	String[] purchaseFlow() default {""};

	@AttributeDefinition(name = "Devices Type Mapping",description = "Set devices type mapping in the format <Devices Type Key>:<devicesTypeValue>")
	String[] devicesType() default {""};

	@AttributeDefinition(name = "EMI Option Order Item Type",description = "Set the order item type value for EMI options")
	String emiOrderItemType() default "";

	@AttributeDefinition(name = "Hide Sticky Cart",description = "Enter flow types for which sticky cart needs to be hidden")
	String[] hideStickyCart() default {"refill"};

	@AttributeDefinition(name = "Allow Handset Protection for Preorder Purchase",description = "Set value to allow handset protection for Preorder Purchases")
	String[] preorderHPPDefaultValue() default {"STRAIGHT_TALK:FALSE","TRACFONE:TRUE"};

    @AttributeDefinition(name = "Edit Plan Purchase Path Selector", description = "Please provide selector value for editing plan (which goes after purchase path)")
	String planEditPathSelector() default ".phone.newcust.plan";

	@AttributeDefinition(name = "Device Hotspot Part Class", description = "Please provide part class of hotspot device type")
	String hotspotPartClass() default "";
}
