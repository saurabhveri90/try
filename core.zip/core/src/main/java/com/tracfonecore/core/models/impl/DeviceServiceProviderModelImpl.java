package com.tracfonecore.core.models.impl;

import java.util.Iterator;

import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import javax.json.JsonException;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.DeviceServiceProviderModel;
import com.tracfonecore.core.utils.ApplicationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { DeviceServiceProviderModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/deviceIdentification", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class DeviceServiceProviderModelImpl implements DeviceServiceProviderModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(DeviceServiceProviderModelImpl.class);
	@Self
	private SlingHttpServletRequest request;

	/**
	 * Inject headerText - textbox
	 */
	@Inject
	@Via("resource")
	private String headerText;

	/**
	 * Inject summary - textbox
	 */
	@Inject
	@Via("resource")
	private String summary;

	/**
	 * Inject radioOptions - multifield
	 */
	@Inject
	@Via("resource")
	private Resource radioOptions;

	/**
	 * Inject privacyPolicy - textbox
	 */
	@Inject
	@Via("resource")
	private String privacyPolicy;

	/**
	 * Inject buttonLabel - textbox
	 */
	@Inject
	@Via("resource")
	private String buttonLabel;
	
	/**
	 * Inject defaultServProvider - textbox
	 */
	@Inject
	@Via("resource")
	private String defaultServProvider;

	/**
	 * Inject cspInputFieldPlaceholder - textbox
	 */
	@Inject
	@Via("resource")
	private String cspInputFieldPlaceholder;
	
	/**
	 * Inject hot flash modal name
	 */
	@Inject
	@Via("resource")
	private String hotFlashModalId;

	/**
	 * Inject cold flash modal name
	 */
	@Inject
	@Via("resource")
	private String tmoModalId;


	/**
	 * Inject cold flash modal name
	 */
	@Inject
	@Via("resource")
	private String deviceType;
	/**
	 * Inject cspFieldDescription - textbox
	 */
	@Inject
	@Via("resource")
	private String cspFieldDescription;

	/**
	 * Inject helpLinkLabel - textbox
	 */
	@Inject
	@Via("resource")
	private String helpLinkLabel;

	/**
	 * Inject helpLinkModalId - textbox
	 */
	@Inject
	@Via("resource")
	private String helpLinkModalId;

	/**
	 * Inject zipInputFieldPlaceholder - textbox
	 */
	@Inject
	@Via("resource")
	private String zipInputFieldPlaceholder;

	/**
	 * Inject zipInputFieldDescription - textbox
	 */
	@Inject
	@Via("resource")
	private String zipInputFieldDescription;

	/**
	 * Inject serviceProviderMapping - multifield
	 */
	@Inject
	@Via("resource")
	private Resource serviceProviderMapping;
	
	/**
	 * Inject gsmUnlockedPhoneRedirectUrl -pathfield
	 */
	@Inject
	@Via("resource")
	private String gsmUnlockedPhoneRedirectUrl;
	
	/**
	 * Inject gsmUnlockedTabRedirectUrl -pathfield
	 */
	@Inject
	@Via("resource")
	private String gsmUnlockedTabRedirectUrl;
	
	private String serviceProviderMappingJson;
	
	/**
	 * <p>
	 * Returns headerText from properties
	 * </p>
	 * 
	 * @return String - headerText
	 */
	@Override
	public String getHeaderText() {
		return headerText;
	}

	/**
	 * <p>
	 * Returns summary from properties
	 * </p>
	 * 
	 * @return String - summary
	 */
	@Override
	public String getSummary() {
		return summary;
	}

	/**
	 * <p>
	 * Returns radioOptions from properties
	 * </p>
	 * 
	 * @return String - radioOptions
	 */
	@Override
	public Resource getRadioOptions() {
		return radioOptions;
	}

	/**
	 * <p>
	 * Returns privacyPolicy from properties
	 * </p>
	 *
	@return privacyPolicy
     */
	@Override
	public String getPrivacyPolicy() {
		return privacyPolicy;
	}

	/**
	 * <p>
	 * Returns buttonLabel from properties
	 * </p>
	 * 
	 * @return String - buttonLabel
	 */
	@Override
	public String getButtonLabel() {
		return buttonLabel;
	}
	
	/**
	 * <p>
	 * Returns cspInputFieldPlaceholder from properties
	 * </p>
	 * 
	 * @return String - cspInputFieldPlaceholder
	 */
	@Override
	public String getCspInputFieldPlaceholder() {
		return cspInputFieldPlaceholder;
	}

	/**
	 * <p>
	 * Returns cspFieldDescription from properties
	 * </p>
	 * 
	 * @return String - cspFieldDescription
	 */
	@Override
	public String getCspFieldDescription() {
		return cspFieldDescription;
	}

	/**
	 * <p>
	 * Returns helpLinkLabel from properties
	 * </p>
	 * 
	 * @return String - helpLinkLabel
	 */
	@Override
	public String getHelpLinkLabel() {
		return helpLinkLabel;
	}

	/**
	 * <p>
	 * Returns helpLinkModalId from properties
	 * </p>
	 * 
	 * @return String - helpLinkModalId
	 */
	@Override
	public String getHelpLinkModalId() {
		return helpLinkModalId;
	}

	/**
	 * <p>
	 * Returns zipInputFieldPlaceholder from properties
	 * </p>
	 * 
	 * @return String - zipInputFieldPlaceholder
	 */
	@Override
	public String getZipInputFieldPlaceholder() {
		return zipInputFieldPlaceholder;
	}

	/**
	 * <p>
	 * Returns zipInputFieldDescription from properties
	 * </p>
	 * 
	 * @return String - zipInputFieldDescription
	 */
	@Override
	public String getZipInputFieldDescription() {
		return zipInputFieldDescription;
	}

	/**
	 * <p>
	 * Returns Service Provider Mapping Json
	 * </p>
	 * @return String - serviceProviderMappingJson
	 */
	@Override
	public String getServiceProviderMappingJson() {

		JsonArray arr = new JsonArray();
		JsonObject jsonObj = new JsonObject();
		Iterator<Resource> spIterator = serviceProviderMapping.listChildren();
		try {
			while (spIterator.hasNext()) {
				Resource spItems = spIterator.next();
				String sp = spItems.getValueMap().get("serviceProvider").toString();
				String phoneRedirectUrl = spItems.getValueMap().get("phoneRedirectUrl").toString();
				String tabRedirectUrl = spItems.getValueMap().get("tabRedirectUrl").toString();
				JsonObject obj = new JsonObject();
				obj.addProperty("type", sp);
				obj.addProperty("phoneRedirectUrl", ApplicationUtil.getShortUrl(request.getResourceResolver(), phoneRedirectUrl));
				obj.addProperty("tabRedirectUrl", ApplicationUtil.getShortUrl(request.getResourceResolver(), tabRedirectUrl));
				arr.add(obj);
			}
			// gsm unlock values
			JsonObject obj = new JsonObject();
			obj.addProperty("type", "gsmUnlocked");
			obj.addProperty("phoneRedirectUrl",  ApplicationUtil.getShortUrl(request.getResourceResolver(),gsmUnlockedPhoneRedirectUrl));
			obj.addProperty("tabRedirectUrl",  ApplicationUtil.getShortUrl(request.getResourceResolver(),gsmUnlockedTabRedirectUrl));
			arr.add(obj);
			jsonObj.add("serviceProviderMapping", arr);
			serviceProviderMappingJson = jsonObj.toString();
		} catch (JsonException e) {
			LOGGER.error("JSON Exception occurred in getServiceProviderMappingJson{}", e);
		}
		return serviceProviderMappingJson;
	}

	/**
	 * <p>
	 * Returns getexportertype from resource
	 * </p>
	 * 
	 * @return String - getexportertype
	 */
	@Override
	public String getExportedType() {

		return request.getResource().getResourceType();
	}
	/**
	 * <p>
	 * Returns hotFlashModalId from properties
	 * </p>
	 * 
	 * @return String - hotFlashModalId
	 */
	@Override
	public String getHotFlashModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(hotFlashModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * <p>
	 * Returns tmoModalId from properties
	 * </p>
	 * 
	 * @return String - tmoModalId
	 */
	@Override
	public String getTmoModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(tmoModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}
	
	/**
     * @return String - deviceType
     */
	@Override
	public String getDeviceType() {
		return deviceType;
	}


}
