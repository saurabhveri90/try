package com.tracfonecore.core.models.impl;

import javax.inject.Inject;

import com.adobe.cq.export.json.ComponentExporter;
import com.tracfonecore.core.models.YextSearchResultsModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.YextSearchConfigService;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.utils.CommerceUtil;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;


@Model(adaptables = {SlingHttpServletRequest.class, Resource.class },adapters = {YextSearchResultsModel.class,ComponentExporter.class},
        resourceType = {"tracfone-core/components/content/yextsearchresults"},defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
    @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
    @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class YextSearchResultsModelImpl implements YextSearchResultsModel {

    private static final Logger LOGGER = LoggerFactory.getLogger(YextSearchResultsModelImpl.class);


    @Self
	private SlingHttpServletRequest request;

    @Inject
    private YextSearchConfigService yextSearchConfig;
    
    @Inject
    private Page currentPage;

    @Inject
    private ApplicationConfigService applicationConfigService;
    
    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }
 
    private int getHomePageLevel() {
        return applicationConfigService.getHomePageLevel();
    }

    @Override
    public String getYextAnswersIframeUrl() {

       return  getValueByBrandAndLanguage(yextSearchConfig.getSearchResultsIframeURL());
        
    }

    /**
	 * <p>
	 * Returns language from util
	 * </p>
	 * 
	 * @return String - language
	 */
	@Override
	public String getLanguage() {

		return CommerceUtil.getLanguage(currentPage, getHomePageLevel());
	}


    private String getValueByBrandAndLanguage(String[] valueArray) {
        String retValue="";
        String brandName = CommerceUtil.getBrandValue(currentPage, getHomePageLevel());
        if (StringUtils.isNotBlank(brandName) && valueArray != null) {
            for (String configValue : valueArray) {
                if (StringUtils.isNotBlank(configValue)&& configValue.indexOf(ApplicationConstants.COLON)!=-1) {
                    String[] valuesArray = configValue.split(ApplicationConstants.COLON);
                    if(null != valuesArray &&  valuesArray.length == 3){
                        String configKey = configValue.substring(0,configValue.indexOf(ApplicationConstants.COLON));
                        String configVal = configValue.substring(configValue.indexOf(ApplicationConstants.COLON)+1,configValue.length());
                        if(StringUtils.isNotBlank(configKey) && StringUtils.isNotBlank(configVal) &&StringUtils.equalsIgnoreCase(brandName,configKey) ) {
                            retValue = configVal;
                        }
                    }
                }
            }   
        }
        return retValue;
    }
}
