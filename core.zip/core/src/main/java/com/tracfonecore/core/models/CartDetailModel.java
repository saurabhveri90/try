/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Multi-Links} Sling Model used for the {@code tracfone-core/components/spa/commerce/cartdetail} component.
 */
public interface CartDetailModel extends ComponentExporter {

	/**
	 * <p>Fetches positionCartListing for the cartdetail</p>
	 * 
	 * @return String - positionCartListing for the cart detail
	 */
	@JsonProperty("positionCartListing")
	public String getPositionCartListing();
	
	/**
	 * <p>Fetches positionOrderSummary for the cartdetail</p>
	 * 
	 * @return String - positionOrderSummary for the cart detail
	 */
	@JsonProperty("positionOrderSummary")
	public String getPositionOrderSummary();
	
	/**
	 * <p>Fetches phonesImagePath for the cartdetail</p>
	 * 
	 * @return String - phonesImagePath for the cart detail
	 */
	@JsonProperty("phonesImagePath")
	public String getPhonesImagePath();
	
	/**
	 * <p>Fetches phonesLink for the cartdetail</p>
	 * 
	 * @return String - phonesLink for the cart detail
	 */
	@JsonProperty("phonesLink")
	public String getPhonesLink();
	
	/**
	 * <p>Fetches simsImagePath for the cartdetail</p>
	 * 
	 * @return String - simsImagePath for the cart detail
	 */
	@JsonProperty("simsImagePath")
	public String getSimsImagePath();
	
	/**
	 * <p>Fetches simsLink for the cartdetail</p>
	 * 
	 * @return String - simsLink for the cart detail
	 */
	@JsonProperty("simsLink")
	public String getSimsLink();
	
	/**
	 * <p>Fetches dealsImagePath for the cartdetail</p>
	 * 
	 * @return String - dealsImagePath for the cart detail
	 */
	@JsonProperty("dealsImagePath")
	public String getDealsImagePath();
	
	/**
	 * <p>Fetches dealsLink for the cartdetail</p>
	 * 
	 * @return String - dealsLink for the cart detail
	 */
	@JsonProperty("dealsLink") 
	public String getDealsLink();

	/**
	 * <p>Fetches termsAndConditionPagePathForRewardSummary for the cartdetail</p>
	 *
	 * @return String - termsAndConditionPagePathForRewardSummary for the cart detail
	 */
	@JsonProperty("termsAndConditionPagePathForRewardSummary")
	public String getTermsAndConditionPagePathForRewardSummary();

	/**
	 * <p>Fetches enableTracSize for the cartdetail</p>
	 *
	 * @return Boolean - enableTracSize for the cart detail
	 */
	@JsonProperty("enableTracSize")
	default Boolean getEnableTracSize(){
		return null;
	}

	/**
	 * <p>Fetches tracSizeHeading for the cartdetail</p>
	 *
	 * @return String - tracSizeHeading for the cart detail
	 */
	@JsonProperty("tracSizeHeading")
	default String getTracSizeHeading(){
		return null;
	}

	/**
	 * <p>Fetches tracSizeSubHeading for the cartdetail</p>
	 *
	 * @return String - tracSizeSubHeading for the cart detail
	 */
	@JsonProperty("tracSizeSubHeading")
	default String getTracSizeSubHeading(){
		return null;
	}

	/**
	 * <p>Fetches tracSizeCategoryId for the cartdetail</p>
	 *
	 * @return String - tracSizeCategoryId for the cart detail
	 */
	@JsonProperty("tracSizeCategoryId")
	default String getTracSizeCategoryId(){
		return null;
	}

	/**
	 * <p>Fetches specialOfferThumbnailImage for cartdetail Component</p>
	 *
	 * @return String - specialOfferThumbnailImage for cartdetail Component
	 */
	@JsonProperty("specialOfferThumbnailImage")
	default String getSpecialOfferThumbnailImage(){
		return null;
	}


	/**
	 * <p>Fetches componentVersion for the cartdetail</p>
	 *
	 * @return String - componentVersion for the cart detail
	 */
	@JsonProperty("componentVersion")
	public String getComponentVersion();
	
	/**
	 * <p>Fetches maxNumberAllowedPlan for the cartdetail</p>
	 *
	 * @return String - maxNumberAllowedPlan for the cart detail
	 */
	@JsonProperty("maxNumberAllowedPlan")
	default String getMaxNumberAllowedPlan(){
		return null;
	}
	
	/**
	 * <p>Fetches enableMultiplePlans for the cartdetail</p>
	 *
	 * @return Boolean - enableMultiplePlans for the cart detail
	 */
	@JsonProperty("enableMultiplePlans")
	default Boolean getEnableMultiplePlans(){
		return null;
	}
	
	/**
	 * <p>Fetches parentPathForSimPLPPage for the cartdetail</p>
	 *
	 * @return String - parentPathForSimPLPPage for the cart detail
	 */
	@JsonProperty("parentPathForSimPLPPage")
	public String getParentPathForSimPLPPage();
	
	/**
	 * <p>Fetches simPlanEditURL for the cartdetail</p>
	 *
	 * @return String - simPlanEditURL for the cart detail
	 */
	@JsonProperty("simPlanEditURL")
	public String getSimPlanEditURL();

	
	/**
	 * <p>Fetches disableCaptcha </p>
	 *
	 * @return String - disableCaptcha
	 */
	@JsonProperty("disableCaptcha")
	public String getDisableCaptcha();
	
	
	/**
     * <p>Fetches editCartPath for the cartdetail</p>
     *
     * @return String - editCartPath for the cart detail
     */
    @JsonProperty("editCartPath")
    default String getEditCartPath(){
        return null;
    }

    @JsonProperty("rewardsSummaryTermsAndConditionRichText")
    default String getRewardsSummaryTermsAndConditionRichText(){
        return null;
    }
	
	/**
     * <p>Fetches planOnlyBundleHeading for the cartdetail</p>
     *
     * @return String - planOnlyBundleHeading for the cart detail
     */
    @JsonProperty("planOnlyBundleHeading")
    default String getPlanOnlyBundleHeading(){
        return null;
    }
    
    /**
     * <p>Fetches planOnlyBundleSubHeading for the cartdetail</p>
     *
     * @return String - planOnlyBundleSubHeading for the cart detail
     */
    @JsonProperty("planOnlyBundleSubHeading")
    default String getPlanOnlyBundleSubHeading(){
        return null;
    }
    
    /**
     * <p>Fetches purchaseNewPhoneButtonLabel for the cartdetail</p>
     *
     * @return String - purchaseNewPhoneButtonLabel for the cart detail
     */
    @JsonProperty("purchaseNewPhoneButtonLabel")
    default String getPurchaseNewPhoneButtonLabel(){
        return null;
    }

    /**
     * <p>Fetches purchaseNewPhoneLink for the cartdetail</p>
     *
     * @return String - purchaseNewPhoneLink for the cart detail
     */
    @JsonProperty("purchaseNewPhoneLink")
    default String getPurchaseNewPhoneLink(){
        return null;
    }
	
	/**
	 * <p>Fetches selectorForPurchaseNewPhoneLink for the cartdetail</p>
	 *
	 * @return String - selectorForPurchaseNewPhoneLink for the cart detail
	 */
	@JsonProperty("selectorForPurchaseNewPhoneLink")
	default String getSelectorForPurchaseNewPhoneLink(){
		return null;
	}

	/**
	 * <p>Fetches purchaseNewTabletButtonLabel for the cartdetail</p>
	 *
	 * @return String - purchaseNewTabletButtonLabel for the cart detail
	 */
	@JsonProperty("purchaseNewTabletButtonLabel")
	default String getPurchaseNewTabletButtonLabel(){
		return null;
	}

	/**
	 * <p>Fetches purchaseNewTabletLink for the cartdetail</p>
	 *
	 * @return String - purchaseNewTabletLink for the cart detail
	 */
	@JsonProperty("purchaseNewTabletLink")
	default String getPurchaseNewTabletLink(){
		return null;
	}

	/**
	 * <p>Fetches selectorForPurchaseNewTabletLink for the cartdetail</p>
	 *
	 * @return String - selectorForPurchaseNewTabletLink for the cart detail
	 */
	@JsonProperty("selectorForPurchaseNewTabletLink")
	default String getSelectorForPurchaseNewTabletLink(){
		return null;
	}

	/**
	 * <p>Fetches bringYourOwnPhoneButtonLabel for the cartdetail</p>
	 *
	 * @return String - bringYourOwnPhoneButtonLabel for the cart detail
	 */
	@JsonProperty("bringYourOwnPhoneButtonLabel")
	default String getBringYourOwnPhoneButtonLabel(){
		return null;
	}
	
	/**
	 * <p>Fetches bringYourOwnPhoneLink for the cartdetail</p>
	 *
	 * @return String - bringYourOwnPhoneLink for the cart detail
	 */
	@JsonProperty("bringYourOwnPhoneLink")
	default String getBringYourOwnPhoneLink(){
		return null;
	}
	
	/**
     * <p>Fetches pickDeviceButtonLabel for the cartdetail</p>
     *
     * @return String - pickDeviceButtonLabel for the cart detail
     */
    @JsonProperty("pickDeviceButtonLabel")
    default String getPickDeviceButtonLabel(){
        return null;
    }

    /**
     * <p>Fetches pickDeviceButtonLink for the cartdetail</p>
     *
     * @return String - pickDeviceButtonLink for the cart detail
     */
    @JsonProperty("pickDeviceButtonLink")
    default String getPickDeviceButtonLink(){
        return null;
    }
    
    /**
     * <p>Fetches pickDeviceButtonLinkSelector for the cartdetail</p>
     *
     * @return String - pickDeviceButtonLinkSelector for the cart detail
     */
    @JsonProperty("pickDeviceButtonLinkSelector")
    default String getPickDeviceButtonLinkSelector(){
        return null;
    }
	
	/**
     * <p>Fetches addLineButtonLink for the cartdetail</p>
     *
     * @return String - addLineButtonLink for the cart detail
     */
    @JsonProperty("addLineButtonLink")
    default String getAddLineButtonLink(){
        return null;
    }
    
    /**
     * <p>Fetches addLineButtonLinkSelector for the cartdetail</p>
     *
     * @return String - addLineButtonLinkSelector for the cart detail
     */
    @JsonProperty("addLineButtonLinkSelector")
    default String getAddLineButtonLinkSelector(){
        return null;
    }
    
    /**
     * <p>Fetches addLineButtonDisclaimerText for the cartdetail</p>
     *
     * @return String - addLineButtonDisclaimerText for the cart detail
     */
    @JsonProperty("addLineButtonDisclaimerText")
    default String getAddLineButtonDisclaimerText(){
        return null;
    }

	/**
	 * <p>Fetches enablePurchaseToRefillLink for the cartdetail</p>
	 *
	 * @return Boolean - enablePurchaseToRefillLink for the cart detail
	 */
	@JsonProperty("enablePurchaseToRefillLink")
	default Boolean getEnablePurchaseToRefillLink(){
	    return null;
	}

	/**
	 * <p>Fetches purchaseToRefillLinkLabel for the cartdetail</p>
	 *
	 * @return Boolean - purchaseToRefillLinkLabel for the cart detail
	 */
	@JsonProperty("purchaseToRefillLinkLabel")
	default String getPurchaseToRefillLinkLabel(){
	    return null;
	}
	
	/**
	 * <p>Fetches disableTooltip for the cartdetail</p>
	 *
	 * @return Boolean - disableTooltip for the cart detail
	 */
	@JsonProperty("disableTooltip")
	default Boolean getDisableTooltip(){
		return null;
	}
	
	/**
	 * <p>Fetches tooltipText for the cartdetail</p>
	 *
	 * @return String - tooltipText for the cart detail
	 */
	@JsonProperty("tooltipText")
	default String getTooltipText(){
		return null;
	}

	/**
	 * <p>Fetches planOnlyDisclaimerRichText for the cartdetail</p>
	 *
	 * @return String - planOnlyDisclaimerRichText for the cart detail
	 */
	@JsonProperty("planOnlyDisclaimerRichText")
	default String getPlanOnlyDisclaimerRichText(){
		return null;
	}
	
	/**
     * <p>Fetches hideCheckoutForPlanFirst for the cartdetail</p>
     *
     * @return Boolean - hideCheckoutForPlanFirst for the cart detail
     */
    @JsonProperty("hideCheckoutForPlanFirst")
    default Boolean getHideCheckoutForPlanFirst(){
        return false;
    }
    
    /**
     * <p>Fetches noDeviceImage for the cartdetail</p>
     *
     * @return String - noDeviceImage for the cart detail
     */
    @JsonProperty("noDeviceImage")
    default String getNoDeviceImage(){
        return null;
    }
    
	/**
	 * @return the twoFAInfoLink
	 */
	@JsonProperty("twoFAInfoLink")
	public String getTwoFAInfoLink();

		/**
	 * <p>Fetches enableAcpLineWithFreePlanButton for the cartdetail</p>
	 *
	 * @return Boolean - enableAcpLineWithFreePlanButton for the cart detail
	 */
	@JsonProperty("enableAcpCheckout")
	default Boolean getEnableAcpCheckout(){
	    return null;
	}

	/**
	 * <p>Fetches acpLineWithFreePlanDisclaimerRichText for the cartdetail</p>
	 *
	 * @return String - acpLineWithFreePlanDisclaimerRichText for the cart detail
	 */
	@JsonProperty("acpDisclaimerRichText")
	default String getAcpDisclaimerRichText(){
		return null;
	}

	   /**
     * <p>Fetches acpLineWithFreePlanButtonLabel for the cartdetail</p>
     *
     * @return String - acpLineWithFreePlanButtonLabel for the cart detail
     */
    @JsonProperty("acpButtonLabel")
    default String getAcpButtonLabel(){
        return null;
    }

	/**
	 * <p>Fetches removeAcpDisclaimer for the cartdetail</p>
	 *
	 * @return String - removeAcpDisclaimer for the cart detail
	 */
	@JsonProperty("removeAcpDisclaimer")
	default String getRemoveAcpDisclaimer() {
		return null;
	}

	/**
	 * <p>Fetches removeAcpCTALabel for the cartdetail</p>
	 *
	 * @return String - removeAcpCTALabel for the cart detail
	 */
	@JsonProperty("removeAcpCTALabel")
	default String getRemoveAcpCTALabel() {
		return null;
	}

	/**
	 * <p>Fetches disableAutoRefillCheckboxValidation for the cartdetail</p>
	 *
	 * @return String - disableAutoRefillCheckboxValidation for the cart detail
	 */
	@JsonProperty("disableAutoRefillCheckboxValidation")
	default Boolean getDisableAutoRefillCheckboxValidation() {
		return null;
	}

	/**
	 * <p>Fetches autoRefillCheckboxValidationText for the cartdetail</p>
	 *
	 * @return String - autoRefillCheckboxValidationText for the cart detail
	 */
	@JsonProperty("autoRefillCheckboxValidationText")
	default String getAutoRefillCheckboxValidationText() {
		return null;
	}

	/**
	 * <p>Fetches smartpayPurchaseAmount for the cartdetail</p>
	 *
	 * @return String - smartpayPurchaseAmount for the cart detail
	 */
	@JsonProperty("smartpayPurchaseAmount")
	default String getSmartpayPurchaseAmount(){
		return null;
	}

	/**
	 * <p>Fetches dcotPromoModelTxt for the cartdetail</p>
	 *
	 * @return String - dcotPromoModelTxt for the cart detail
	 */
	@JsonProperty("dcotPromoModelTxt")
	default String getDcotPromoModelTxt(){
		return null;
	}
	/**
	 * <p>Fetches stBYOPModelTxt for the cartdetail</p>
	 *
	 * @return String - stBYOPModelTxt for the cart detail
	 */
	@JsonProperty("stBYOPModelTxt")
	default String getStBYOPModelTxt(){
		return null;
	}
	/**
	 * <p>Fetches byopSimKitPath for the cartdetail</p>
	 *
	 * @return String - byopSimKitPath for the cart detail
	 */
	@JsonProperty("byopSimKitPath")
	default String getByopSimKitPath (){ 
		return null;
	}

	/**
	 * <p>Fetches paymentCardTermsAndConditionRichText for the cartdetail</p>
	 *
	 * @return String - paymentCardTermsAndConditionRichText for the cart detail
	 */

	@JsonProperty("paymentCardTermsAndConditionRichText")
    default String getPaymentCardTermsAndConditionRichText(){
        return null;
    }

	/**
	 * <p>Fetches dcotArModalHeading for the cartdetail</p>
	 *
	 * @return String - dcotArModalHeading for the cart detail
	 */
	@JsonProperty("dcotArModalHeading")
	default String getDcotArModalHeading(){
		return null;
	}

	/**
	 * <p>Fetches dcotArModalBody for the cartdetail</p>
	 *
	 * @return String - dcotArModalBody for the cart detail
	 */
	@JsonProperty("dcotArModalBody")
	default String getDcotArModalBody(){
		return null;
	}

	/**
	 * <p>Fetches dcotArModalEnrollBtn for the cartdetail</p>
	 *
	 * @return String - dcotArModalEnrollBtn for the cart detail
	 */
	@JsonProperty("dcotArModalEnrollBtn")
	default String getDcotArModalEnrollBtn(){
		return null;
	}
	
	/**
	 * <p>Fetches dcotArModalEnrollBtnAriaLabel for the cartdetail</p>
	 *
	 * @return String - dcotArModalEnrollBtnAriaLabel for the cart detail
	 */
	@JsonProperty("dcotArModalEnrollBtnAriaLabel")
	default String getDcotArModalEnrollBtnAriaLabel(){
		return null;
	}

	/**
	 * <p>Fetches dcotArModalDisenrollBtn for the cartdetail</p>
	 *
	 * @return String - dcotArModalDisenrollBtn for the cart detail
	 */
	@JsonProperty("dcotArModalDisenrollBtn")
	default String getDcotArModalDisenrollBtn(){
		return null;
	}

	/**
	 * <p>Fetches dcotArModalDisenrollBtnAriaLabel for the cartdetail</p>
	 *
	 * @return String - dcotArModalDisenrollBtnAriaLabel for the cart detail
	 */
	@JsonProperty("dcotArModalDisenrollBtnAriaLabel")
	default String getDcotArModalDisenrollBtnAriaLabel(){ return null; }

	/**
	 * <p>Fetches stBYOPAutorefillModelTxt for the cartdetail</p>
	 *
	 * @return String - stBYOPAutorefillModelTxt for the cart detail
	 */
	@JsonProperty("stBYOPSimswapTxt")
	default String getStBYOPSimswapTxt(){
		return null;
	}
	/**
	 * <p>Fetches uteTaxSurchargeInd for the cartdetail</p>
	 *
	 * @return String - uteTaxSurchargeInd for the cart detail
	 */
	@JsonProperty("uteTaxSurchargeInd")
	default String getUteTaxSurchargeInd (){ 
		return null;
	}

   /**
	 * <p>Fetches uteOtherTax for the cartdetail</p>
	 *
	 * @return String - uteOtherTax for the cart detail
	 */
	@JsonProperty("uteOtherTax")
	public String getUteOtherTax();
	
	/**
	 * <p>Fetches uteMandatoryTax for the cartdetail</p>
	 *
	 * @return String - uteMandatoryTax for the cart detail
	 */
	@JsonProperty("uteMandatoryTax")
	public String getUteMandatoryTax();

	/**
	 * <p>Fetches tabletHeading for the cartdetail</p>
	 *
	 * @return String - tabletHeading for the cart detail
	 */
	@JsonProperty("tabletHeading")
	default String getTabletHeading(){
		return null;
	}

	/**
	 * <p>Fetches tabletDescription for the cartdetail</p>
	 *
	 * @return String - tabletDescription for the cart detail
	 */
	@JsonProperty("tabletDescription")
	default String getTabletDescription(){
		return null;
	}

	/**
	 * <p>Fetches tabletShopBtn for the cartdetail</p>
	 *
	 * @return String - tabletShopBtn for the cart detail
	 */
	@JsonProperty("tabletShopBtn")
	default String getTabletShopBtn(){
		return null;
	}

	/**
	 * <p>Fetches tabletShopBtnAriaLabel for the cartdetail</p>
	 *
	 * @return String - tabletShopBtnAriaLabel for the cart detail
	 */
	@JsonProperty("tabletShopBtnAriaLabel")
	default String getTabletShopBtnAriaLabel(){
		return null;
	}

	/**
	 * <p>Fetches tabletShopCta for the cartdetail</p>
	 *
	 * @return String - tabletShopCta for the cart detail
	 */
	@JsonProperty("tabletShopCta")
	default String getTabletShopCta(){
		return null;
	}

	/**
	 * <p>Fetches tabletBuySimBtn for the cartdetail</p>
	 *
	 * @return String - tabletBuySimBtn for the cart detail
	 */
	@JsonProperty("tabletBuySimBtn")
	default String getTabletBuySimBtn(){ return null; }

	/**
	 * <p>Fetches tabletBuySimBtnAriaLabel for the cartdetail</p>
	 *
	 * @return String - tabletBuySimBtnAriaLabel for the cart detail
	 */
	@JsonProperty("tabletBuySimBtnAriaLabel")
	default String getTabletBuySimBtnAriaLabel(){
		return null;
	}

	/**
	 * <p>Fetches tabletBuySimCta for the cartdetail</p>
	 *
	 * @return String - tabletBuySimCta for the cart detail
	 */
	@JsonProperty("tabletBuySimCta")
	default String getTabletBuySimCta(){
		return null;
	}

}
