package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;


public interface LtoPreApprovalModel extends ComponentExporter  {

    
	@JsonProperty("smartPayConsentLink")
	public String getSmartPayConsentLink();

	@JsonProperty("smartPayTcpaConsentLink")
	public String getSmartPayTcpaConsentLink();
	
	@JsonProperty("shopPhonesLink")
	public String getShopPhonesLink();

	/**
	 * <p>
	 * Fetches showPreApprovalSection option
	 * </p>
	 * 
	 * @return String - Show Pre Approval Section
	 */
	@JsonProperty("linesPerAccountPath")
	public String getLinesPerAccountPath();

	@JsonProperty("smartPayFooterDisclaimer")
	public String getSmartPayFooterDisclaimer();

}
