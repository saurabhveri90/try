package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;

import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface LoginOrCreateAccountModel extends ComponentExporter {
    /**
     * Get the headerText
     * 
     * @return String - headerText
     */
    public String getHeaderText();

    /**
     * Get the summary
     * 
     * @return String - summary
     */
    public String getSummary();

    /**
     * Get the enabletooltip
     * 
     * @return String - enabletooltip
     */
    public String getEnabletooltip();

    /**
     * Get the learnMoreModalContent
     * 
     * @return String - learnMoreModalContent
     */
    public String getLearnMoreModalContent();

    /**
     * Get the forgotPasswordLink
     * 
     * @return String - forgotPasswordLink
     */
    public String getForgotPasswordLink();

    /**
     * Get the disableCaptcha
     * 
     * @return String - disableCaptcha
     */
    public String getDisableCaptcha();

    /**
     * Get the ReCaptchaSiteKey
     * 
     * @return String - ReCaptchaSiteKey
     */
    public String getReCaptchaSiteKey();

    /**
     * Get the forgotPasswordSuccessMessage
     * 
     * @return String - forgotPasswordSuccessMessage
     */
    public String getForgotPasswordSuccessMessage();

    /**
     * Get the forgotPasswordSuccessTitle
     * 
     * @return String - forgotPasswordSuccessTitle
     */
    public String getForgotPasswordSuccessTitle();

    /**
     * Get the forgotPasswordSuccessTitle
     * 
     * @return String - forgotPasswordSuccessTitle
     */
    public String getEnableFacebookLogin();

    /**
     * @return String return the Phone Plp page path
     */
    public String getPhonesPagePath();

}
