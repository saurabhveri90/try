package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

public interface OneStepActivationModel extends ComponentExporter {
	
	/**
	 * @return imagePath
	 */
	@JsonProperty("imagePath")
	public String getImagePath();

	/**
	 * @return heading
	 */
	@JsonProperty("heading")
	public String getHeading();
	
	/**
	 * @return getSubheadingone
	 */
	@JsonProperty("getSubheadingone")
	public String getSubheadingone();

	/**
	 * @return getSubheadingtwo
	 */
	@JsonProperty("getSubheadingtwo")
	public String getSubheadingtwo();

	/**
	 * @return inputFieldLastFourDigits
	 */
	@JsonProperty("inputFieldLastFourDigits")
	public String getInputFieldLastFourDigits();

	/**
	 * @return inputOtpPlaceholder
	 */
	@JsonProperty("inputOtpPlaceholder")
	public String getInputOtpPlaceholder();

	/**
	 * @return videolink
	 */
	@JsonProperty("videolink")
	public String getVideolink();

	/**
	 * @return needHelpModalId
	 */
	@JsonProperty("needHelpModalId")
	public String getNeedHelpModalId();

    /**
	 * @return helptext
	 */
	@JsonProperty("helptext")
	public String getHelptext();

	/**
	 * @return helpTextAriaLabel
	 */
	@JsonProperty("helpTextAriaLabel")
	public String getHelpTextAriaLabel();

	/**
	 * @return buttonAriaLabel
	 */
	@JsonProperty("buttonAriaLabel")
	public String getButtonAriaLabel();

    /**
	 * @return summary
	 */
	@JsonProperty("summary")
	public String getSummary();

	/**
	 * @return pageType
	 */
	@JsonProperty("pageType")
	public String getPageType();

	/**
	 * @return guestLineLockedModalId
	 */
	@JsonProperty("guestLineLockedModalId")
	public String getGuestLineLockedModalId();

    /**
	 * @return guestLineUnlockedModalId
	 */
	@JsonProperty("guestLineUnlockedModalId")
	public String getGuestLineUnlockedModalId();

	/**
	 * @return authLineLockedModalId
	 */
	@JsonProperty("authLineLockedModalId")
	public String getAuthLineLockedModalId();

    /**
	 * @return authLineUnlockedModalId
	 */
	@JsonProperty("authLineUnlockedModalId")
	public String getAuthLineUnlockedModalId();



	/**
     * Get the input Field Placeholder
     * @return String - inputFieldPlaceholder
     */
    public String getInputFieldPlaceholder();  
    
    /**
     * Get the tncText
     * @return String - tncText
     */
    public String getTncText();  
    
    /**
     * Get the button Label
     * @return String - buttonLabel
     */
    public String getButtonLabel();

	/**
     * Get the button link
     * @return String - buttonLink
     */
    public String getButtonLink();

	/**
     * Get the button secondary link
     * @return String - buttonSecondaryLinkCodes
     */
    public String getButtonSecondaryLinkCodes();

	/**
     * Get the oopsErrorCodes
     * @return String - oopsErrorCodes
     */
    public String getOopsErrorCodes();

	/**
     * Get the phoneOfferErrorCodes
     * @return String - phoneOfferErrorCodes
     */
    public String getPhoneOfferErrorCodes();

	/**
     * Get the simOfferCodes
     * @return String - simOfferCodes
     */
    public String getSimOfferCodes();

    /**
     * Get the inputVerifyDevice
     * @return String - inputVerifyDevice
     */
    public String getInputVerifyDevice();

	/**
     * Get the inputVerifySim
     * @return String - inputVerifySim
     */
    public String getInputVerifySim();

	/**
     * Get the almostThereErrorCodes
     * @return String - almostThereErrorCodes
     */
    public String getAlmostThereErrorCodes();

	/**
     * Get the perfectCodes
     * @return String - perfectCodes
     */
    public String getPerfectCodes();
	
}
