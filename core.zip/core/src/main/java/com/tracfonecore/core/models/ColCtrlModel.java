/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import java.util.List;
import java.util.Map;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.ColumnBean;

/**
 * Defines the {@code Column-Control} Sling Model used for the {@code /apps/tracfone-core/components/content/columncontrol} component.
 */
public interface ColCtrlModel extends ComponentExporter {
	
	/**
	 * <p>Fetches detail for all the columns</p>
	 * 
	 * @return String - detail for all the columns
	 */
	@JsonProperty("columnList")
	public List<ColumnBean> getColumnList();
	
	/**
	 * <p>Fetches display type for the columns</p>
	 * 
	 * @return String - display type of the columns
	 */
	@JsonProperty("displayType")
	public String getDisplayType();

	/**
	 * <p>Fetches name of the section for which column control is used</p>
	 * 
	 * @return String - name of the section for which column control is used
	 */
	@JsonProperty("sectionName")
	public String getSectionname();

	public Map<String, ? extends ComponentExporter> getItems();

	/**
	 * @return the isContainerFluid
	 */
	public boolean getIsContainerFluid();


}
