/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;

/**
 * <p>Defines bean to hold link detail</p>
 */
public class CompatibilityButtonBean {


	private String buttonlabel;

	private String buttonlink;

	private String checkevent;

	

	

	/**
	 * @return the buttonlabel
	 */
	public String getButtonlabel() {
		return buttonlabel;
	}
	/**
	 * @param buttonlabel the buttonlabel to set
	 */
	public void setButtonlabel(String buttonlabel) {
		this.buttonlabel = buttonlabel;
	}


	/**
	 * @return the buttonlink
	 */
	public String getButtonlink() {
		return buttonlink;
	}
	/**
	 * @param buttonlink the buttonlink to set
	 */
	public void setButtonlink(String buttonlink) {
		this.buttonlink = buttonlink;
	}


	
	
	/**
	 * @return the checkevent
	 */
	public String getCheckevent() {
		return checkevent;
	}
	/**
	 * @param checkevent the checkevent to set
	 */
	public void setCheckevent(String checkevent) {
		this.checkevent = checkevent;
	}
	
}
