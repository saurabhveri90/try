/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
 package com.tracfonecore.core.models;


import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.osgi.annotation.versioning.ProviderType;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@ProviderType
public interface MultiTeaserModel extends ComponentExporter {

	/**
	 * <p>Fetches type of teaser</p>
	 * 
	 * @return String - type of teaser
	 */
	@JsonProperty("teaserType")
	public String getTeaserType();

	/**
	 * <p>Fetches count of multi teaser</p>
	 *
	 * @return String - count of multi teaser
	 */
	@JsonProperty("count")
	public Integer getCount();

	/**
	 * <p>Fetches count in array format</p>
	 *
	 * @return List<Integer> - count in array format
	 */
	@JsonProperty("countArray")
	public List<Integer> getCountArray();
	
	/**
	 * <p>Fetches column in integer</p>
	 *
	 * @return Integer - count 
	 */
	@JsonProperty("column")
	public Integer getColumn();
	
	
	/**
	 * <p>Fetches child items json</p>
	 *
	 * @return Map<String, ? extends ComponentExporter> - items
	 */
	@JsonProperty("items")
	public Map<String, ? extends ComponentExporter> getItems();

}