/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.CurrentServiceProviderModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.BrandSpecificConfigService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;

import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CurrentServiceProviderModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/currentServiceProvider", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CurrentServiceProviderModelImpl implements CurrentServiceProviderModel {

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private Page currentPage;

	@Inject
	private BrandSpecificConfigService brandSpecificConfigService;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Default(values = ApplicationConstants.LEARN_MORE)
	private String modalName;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String heading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String summary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String phoneTypeLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String phoneTypePlaceholderText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceProviderLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceProviderPlaceholderText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String zipCodeLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String zipCodePlaceholderText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String modalLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String buttontext;

	private String modalId;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accountHeading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accountSummary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accountModalLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accountModalName;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accountInfoLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accountNoPlaceholderText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accountKeyPlaceholderText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String contactInfoLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String firstNamePlaceholderText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String lastNamePlaceholderText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String phoneNoPlaceholderText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addressInfoLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String address1PlaceholderText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String address2PlaceholderText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String cityPlaceholderText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accountZipCodePlaceholderText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String statePlaceholderText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ctaButton;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accountMinPlaceholderText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accountCurrentEsnPlaceholderText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accountVKeyPlaceholderText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String accountLast4SSNPlaceholderText;

	@ValueMapValue
	private String unlockSummary;

	@ValueMapValue
	private String unlockButtonText;

	private String accountModalId;
	
	private String countryStateMapping;

	@Inject
	private ApplicationConfigService applicationConfigService;

	@Inject
	private TracfoneApiGatewayService tracfoneApiService;

	private static final Logger LOGGER = LoggerFactory.getLogger(CurrentServiceProviderModel.class);

	/**
	 * <p>
	 * Initialization method of modal
	 * </p>
	 *
	 */

	@PostConstruct
	private void initModel() {
		LOGGER.debug("Entering initModel method");
		
		this.setModalId(ApplicationUtil.getLowerCaseWithHyphen(modalName) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL);
		this.setAccountModalId(ApplicationUtil.getLowerCaseWithHyphen(accountModalName) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL);
		LOGGER.debug("Exiting initModel method");
	}

	/**
	 * <p> Fetches Resource type </p>
	 * 
	 * @return String - exportedType
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p> Fetches modalName </p>
	 *
	 * @return the modalName
	 */
	@Override
	public String getModalName() {
		return modalName;
	}

	/**
	 * <p> Fetches modalId </p>
	 *
	 * @return the modalId
	 */
	@Override
	public String getModalId() {
		return modalId;
	}

	/**
	 * <p> Sets modalId </p>
	 *
	 * @param modalId - the modalId to set
	 */
	public void setModalId(String modalId) {
		this.modalId = modalId;
	}

	/**
	 * <p> Fetches heading </p>
	 *
	 * @return String - heading
	 */
	@Override
	public String getHeading() {
		return heading;
	}

	/**
	 * <p> Fetches summary </p>
	 *
	 * @return String - summary
	 */
	@Override
	public String getSummary() {
		return summary;
	}

	/**
	 * <p> Fetches button text </p>
	 *
	 * @return String - button text
	 */
	@Override
	public String getButtontext() {
		return buttontext;
	}

	/**
	 * <p> Fetches label for Phone Type </p>
	 *
	 * @return List - Phone Type Label
	 */
	@Override
	public String getPhoneTypeLabel() {
		return phoneTypeLabel;
	}

	/**
	 * <p> Fetches Placeholder text for Phone Type </p>
	 *
	 * @return List - Phone Type Placeholder Text
	 */
	@Override
	public String getPhoneTypePlaceholderText() {
		return phoneTypePlaceholderText;
	}

	/**
	 * <p> Fetches label for Current Service Provider </p>
	 *
	 * @return List - Service Provider Label
	 */
	@Override
	public String getServiceProviderLabel() {
		return serviceProviderLabel;
	}

	/**
	 * <p> Fetches Placeholder text for Service Provider </p>
	 *
	 * @return List - Service Provider Placeholder Text
	 */
	@Override
	public String getServiceProviderPlaceholderText() {
		return serviceProviderPlaceholderText;
	}

	/**
	 * <p> Fetches label for Zip code </p>
	 *
	 * @return List - Zip Code Label
	 */
	@Override
	public String getZipCodeLabel() {
		return zipCodeLabel;
	}

	/**
	 * <p> Fetches Placeholder text for Zip Code </p>
	 *
	 * @return List - Zip Code Placeholder Text
	 */
	@Override
	public String getZipCodePlaceholderText() {
		return zipCodePlaceholderText;
	}

	/**
	 * <p> Fetches label for Learn More Modal </p>
	 *
	 * @return String - modal label
	 */
	@Override
	public String getModalLabel() {
		return modalLabel;
	}

	/**
	 * <p> Fetches heading for Account detail section </p>
	 * 
	 * @return the accountHeading
	 */
	@Override
	public String getAccountHeading() {
		return accountHeading;
	}

	/**
	 * <p> Fetches summary for Account detail section </p>
	 * 
	 * @return the accountSummary
	 */
	@Override
	public String getAccountSummary() {
		return accountSummary;
	}

	/**
	 * <p> Fetches label for Account modal</p>
	 * 
	 * @return the accountModalLabel
	 */
	@Override
	public String getAccountModalLabel() {
		return accountModalLabel;
	}

	/**
	 * <p> Fetches label for Account section modal name</p>
	 * 
	 * @return the accountModalName
	 */
	@Override
	public String getAccountModalName() {
		return accountModalName;
	}

	/**
	 * <p> Fetches label for Account info</p>
	 * 
	 * @return the accountInfoLabel
	 */
	@Override
	public String getAccountInfoLabel() {
		return accountInfoLabel;
	}

	/**
	 * <p> Fetches placeholder text for Account number</p>
	 * 
	 * @return the accountNoPlaceholderText
	 */
	@Override
	public String getAccountNoPlaceholderText() {
		return accountNoPlaceholderText;
	}

	/**
	 * <p> Fetches placeholder text for Account key</p>
	 * 
	 * @return the accountKeyPlaceholderText
	 */
	@Override
	public String getAccountKeyPlaceholderText() {
		return accountKeyPlaceholderText;
	}

	/**
	 * <p> Fetches label for contact info</p>
	 * 
	 * @return the contactInfoLabel
	 */
	@Override
	public String getContactInfoLabel() {
		return contactInfoLabel;
	}

	/**
	 * <p> Fetches placeholder text for first name</p>
	 * 
	 * @return the firstNamePlaceholderText
	 */
	@Override
	public String getFirstNamePlaceholderText() {
		return firstNamePlaceholderText;
	}

	/**
	 * <p> Fetches placeholder text for last name </p>
	 * 
	 * @return the lastNamePlaceholderText
	 */
	@Override
	public String getLastNamePlaceholderText() {
		return lastNamePlaceholderText;
	}

	/**
	 * <p> Fetches placeholder text for phone no.</p>
	 * 
	 * @return the phoneNoPlaceholderText
	 */
	@Override
	public String getPhoneNoPlaceholderText() {
		return phoneNoPlaceholderText;
	}

	/**
	 * <p> Fetches label for Address info</p>
	 * 
	 * @return the addressInfoLabel
	 */
	@Override
	public String getAddressInfoLabel() {
		return addressInfoLabel;
	}

	/**
	 * <p> Fetches placeholder text for Address line 1</p>
	 * 
	 * @return the address1PlaceholderText
	 */
	@Override
	public String getAddress1PlaceholderText() {
		return address1PlaceholderText;
	}

	/**
	 * <p> Fetches placeholder text for Address line 2 </p>
	 * 
	 * @return the address2PlaceholderText
	 */
	@Override
	public String getAddress2PlaceholderText() {
		return address2PlaceholderText;
	}

	/**
	 * <p> Fetches placeholder text for city field </p>
	 * 
	 * @return the cityPlaceholderText
	 */
	@Override
	public String getCityPlaceholderText() {
		return cityPlaceholderText;
	}

	/**
	 * <p> Fetches placeholder text for zipcode field </p>
	 * 
	 * @return the accountZipCodePlaceholderText
	 */
	@Override
	public String getAccountZipCodePlaceholderText() {
		return accountZipCodePlaceholderText;
	}

	/**
	 * <p> Fetches placeholder text for state field </p>
	 * 
	 * @return the statePlaceholderText
	 */
	@Override
	public String getStatePlaceholderText() {
		return statePlaceholderText;
	}

	/**
	 * <p> Fetches label for cta button</p>
	 * 
	 * @return the ctaButton
	 */
	@Override
	public String getCtaButton() {
		return ctaButton;
	}

	/**
	 * <p> Fetches accountModalId </p>
	 *
	 * @return the accountModalId
	 */
	@Override
	public String getAccountModalId() {
		return accountModalId;
	}

	/**
	 * <p> Sets accountModalId </p>
	 *
	 * @param accountModalId - the accountModalId to set
	 */
	public void setAccountModalId(String accountModalId) {
		this.accountModalId = accountModalId;
	}
	
	/**
	 * @return the countryStateMapping
	 */
	public String getCountryStateMapping() {
		GsonBuilder builder = new GsonBuilder().setPrettyPrinting().serializeNulls();
		Gson gson = builder.create();
		String[] countryStateArray = applicationConfigService.getCountryStateMapping();
		
		if (countryStateArray != null) {
			Map<String, String> countryStateMap = ConfigurationUtil.getConfigMap(countryStateArray);
			countryStateMapping= gson.toJson(countryStateMap);
		}
		return countryStateMapping;
	}

	/**
	 * <p> Fetches placeholder text for MIN field </p>
	 * 
	 * @return the accountMinPlaceholderText
	 */
	@Override
	public String getAccountMinPlaceholderText() {
		return accountMinPlaceholderText;
	}

	/**
	 * <p> Fetches placeholder text for Current ESN field </p>
	 * 
	 * @return the accountCurrentEsnPlaceholderText
	 */
	@Override
	public String getAccountCurrentEsnPlaceholderText() {
		return accountCurrentEsnPlaceholderText;
	}

	/**
	 * <p> Fetches placeholder text for VKey field </p>
	 * 
	 * @return the accountVKeyPlaceholderText
	 */
	@Override
	public String getAccountVKeyPlaceholderText() {
		return accountVKeyPlaceholderText;
	}

	/**
	 * <p> Fetches placeholder text for Last 4 SSN field </p>
	 * 
	 * @return the accountLast4SSNPlaceholderText
	 */
	@Override
	public String getAccountLast4SSNPlaceholderText() {
		return accountLast4SSNPlaceholderText;
	}

	/**
	 * @return String - apiUrl
	 */
	public String getTroubleTicketApiPath() {

		return tracfoneApiService.getTroubleTicketApiPath();
	}

	/**
	 * <p> Fetches unlock summary </p>
	 *
	 * @return String - unlockSummary
	 */
	@Override
	public String getUnlockSummary() {
		return unlockSummary;
	}

	/**
	 * <p> Fetches unlockButtonText </p>
	 *
	 * @return String - unlockButtonText
	 */
	@Override
	public String getUnlockButtonText() {
		return unlockButtonText;
	}

	/**
	 * <p>
	 * Fetches portInScreenChanges value from config
	 * </p>
	 *
	 * @return String - portInScreenChanges
	 */
	@Override
	public String getPortInScreenChanges() {
		return ConfigurationUtil.getConfigValue(brandSpecificConfigService.portInScreenChanges(),
		CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}
}
