package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

public interface PromoCodesModel extends ComponentExporter {

	/**
	 * <p>Fetches headlinePromoCodes for the cartdetail</p>
	 * 
	 * @return String - headlinePromoCodes for the cart detail
	 */
	@JsonProperty("headlinePromoCodes")
	public String getHeadlinePromoCodes();
	
	/**
	 * <p>Fetches subheadlinePromoCodes for the promocodes</p>
	 * 
	 * @return String - subheadlinePromoCodes for the cart detail
	 */
	@JsonProperty("subheadlinePromoCodes")
	public String getSubheadlinePromoCodes();
	
	/**
	 * <p>Fetches carouselSpeedPromoCodes for the pr</p>
	 * 
	 * @return String - carouselSpeedPromoCodes for the cart detail
	 */
	@JsonProperty("carouselSpeedPromoCodes")
	public String getCarouselSpeedPromoCodes();
	
	/**
	 * <p>Fetches dotNavigationLengthPromoCodes for the promocodes</p>
	 * 
	 * @return String - dotNavigationLengthPromoCodes for the promocodes
	 */
	@JsonProperty("dotNavigationLengthPromoCodes")
	public String getDotNavigationLengthPromoCodes();
	
	/**
	 * <p>Fetches seeAllPromoCodesLink for the pr</p>
	 * 
	 * @return String - seeAllPromoCodesLink for the promocodes
	 */
	@JsonProperty("seeAllPromoCodesLink")
	public String getSeeAllPromoCodesLink();

}