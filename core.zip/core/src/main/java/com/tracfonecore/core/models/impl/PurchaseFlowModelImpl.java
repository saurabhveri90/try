/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl.v1;
import com.tracfonecore.core.beans.DeEnrollmentReasonsBean;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.*;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.PurchaseFlowModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import javax.annotation.PostConstruct;
import javax.inject.Named;
import java.util.ArrayList;
@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { PurchaseFlowModel.class,
        ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/purchaseflowcard", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class PurchaseFlowModelImpl implements PurchaseFlowModel {
    @Self
    protected SlingHttpServletRequest request;
    @ScriptVariable
    private ValueMap properties;
    @ValueMapValue
    private String subheading;
    @ValueMapValue
    private String subHeadingIconPath;
    @ValueMapValue
    private String heading;
    @ValueMapValue
    private String description;
    @ValueMapValue
    private String ctaLabel;
    @ValueMapValue
    private String ctaLink;
    @ValueMapValue
    private String learnmoreLabel;
    @ValueMapValue
    private String learnmoreLink;
    @Override
    public String getSubheading() {
        return subheading;
    }
    @Override
    public String getSubHeadingIconPath() {
        return subHeadingIconPath;
    }
    @Override
    public String getHeading() {
        return heading;
    }
    @Override
    public String getDescription() {
        return description;
    }
    @Override
    public String getCtaLabel() {
        return ctaLabel;
    }
    @Override
    public String getCtaLink() {
        return ApplicationUtil.getUrlWithoutDomain(ApplicationUtil.getShortUrl(request.getResourceResolver(), ctaLink));
    }
    @Override
    public String getLearnmoreLabel() {
        return learnmoreLabel;
    }
    @Override
    public String getLearnmoreLink() {
        return ApplicationUtil.getUrlWithoutDomain(ApplicationUtil.getShortUrl(request.getResourceResolver(), learnmoreLink));
    }
    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }
}

