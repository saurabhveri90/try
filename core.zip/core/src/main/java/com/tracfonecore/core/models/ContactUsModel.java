package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.sling.api.resource.Resource;

/**
 * Defines the {@code Contact-Us} Sling Model used for the {@code /apps/tracfone-core/components/content/contactus} component.
 */
public interface ContactUsModel extends ComponentExporter  {

    /**
     * <p>Fetches title of the contact-us</p>
     *
     * @return String - title of the contact us
     */
    @JsonProperty("title")
    public String getTitle();

    /**
     * <p>Fetches summary of the contact-us</p>
     *
     * @return String - summary of the contact us
     */
    @JsonProperty("summary")
    public String getSummary();

    /**
     * <p>Fetches the address section of contact us</p>
     *
     * @return String - address section of the contact us
     */
    @JsonProperty("addressArea")
    public String getAddressArea();

    /**
     * <p>Fetches title of the contacts list</p>
     *
     * @return String - title of the contacts list
     */
    @JsonProperty("contactsListHeading")
    public String getContactsListHeading();

    /**
     * <p>Fetches title of the contacts list items</p>
     *
     * @return Resource - title of the contacts list items
     */
    @JsonProperty("contactsListItems")
    public Resource getContactsListItems();
    
    /**
     * <p>Fetches onlineChatArea of contact us</p>
     *
     * @return String - onlineChatArea of the contact us
     */
    @JsonProperty("onlineChatArea")
    public default String getOnlineChatArea() {
    	return null;
    }
    
    /**
     * <p>Fetches callUsArea of contact us</p>
     *
     * @return String - callUsArea of the contact us
     */
    @JsonProperty("callUsArea")
    public default String getCallUsArea() {
    	return null;
    }
    
    /**
     * <p>Fetches includeImageandText of contact us</p>
     *
     * @return Boolean - includeImageandText of the contact us
     */
    @JsonProperty("includeImageandText")
    public default Boolean getIncludeImageandText() {
    	return null;
    }

    /**
     * <p>Fetches includeBtnCol1 of contact us</p>
     *
     * @return Boolean - includeBtnCol1 of the contact us
     */
    @JsonProperty("includeBtnCol1")
    public default Boolean getIncludeBtnCol1() {
    	return null;
    }

    /**
     * <p>Fetches includeBtnCol2 of contact us</p>
     *
     * @return Boolean - includeBtnCol2 of the contact us
     */
    @JsonProperty("includeBtnCol2")
    public default Boolean getIncludeBtnCol2() {
    	return null;
    }

    /**
     * <p>Fetches includeBtnCol3 of contact us</p>
     *
     * @return Boolean - includeBtnCol3 of the contact us
     */
    @JsonProperty("includeBtnCol3")
    public default Boolean getIncludeBtnCol3() {
    	return null;
    }
}
