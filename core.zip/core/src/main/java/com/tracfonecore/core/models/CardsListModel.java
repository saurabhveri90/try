/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.ImageBean;

/**
 * Defines the {@code Multi-image} Sling Model used for the {@code /apps/tracfone-core/components/content/cardslist} component.
 */
public interface CardsListModel extends ComponentExporter {

	/**
	 * <p>Fetches heading for the Cards List</p>
	 * 
	 * @return String - heading for the Cards List
	 */
	@JsonProperty("heading")
	public String getHeading();
	
	/**
	 * <p>Fetches font note for the Cards List</p>
	 * 
	 * @return String - foot-note for the Cards List
	 */
	@JsonProperty("footNote")
	public String getFootNote();
	
	
	/**
	 * <p>Fetches all the image text list</p>
	 * 
	 * @return String - all the image text list
	 */
	@JsonProperty("imagelist")
	public List<ImageBean> getImageList();
}
