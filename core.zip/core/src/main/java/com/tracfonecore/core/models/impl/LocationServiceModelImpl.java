/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.models.LocationServiceModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.MapQuestApiGatewayService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;

@Model(adaptables = {
		SlingHttpServletRequest.class,
		Resource.class
},
		adapters = {
				LocationServiceModel.class,
				ComponentExporter.class
		},
		resourceType = "tracfone-core/components/structure/locationservices", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true")
})
public class LocationServiceModelImpl implements LocationServiceModel {

	@Self
	private SlingHttpServletRequest request;
	
	@Inject
	private Page currentPage;
	
	@Inject
	protected ApplicationConfigService applicationConfigService;
	
	@Inject
	private MapQuestApiGatewayService mapQuestApiService;

	/**
	 *  Inject the MapQuestApi Service
	 */
	@Inject
	private MapQuestApiGatewayService mapquestApiService;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String locationLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String locationDesc;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String locationText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String errorMsg;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String doNotFollow;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String privacyPolicyInfo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String noZipErrorMsg;

	private static final Logger LOGGER = LoggerFactory.getLogger(LocationServiceModelImpl.class);

	@PostConstruct
	private void initModel() {
		LOGGER.debug("Inside Location Service model init method");

			if (doNotFollow != null) {
				doNotFollow = ApplicationUtil.getNoFollow(doNotFollow);
			} else doNotFollow = ApplicationUtil.getNoFollow(null);

		}
	/**
	 * <p>Fetches location text to be displayed</p>
	 *
	 * @return String - location text of the location box
	 */
	@Override
	public String getLocationText() {
		return locationText;
	}
	/**
	 * <p>Fetches location description to be displayed</p>
	 *
	 * @return String - location description of the location box
	 */
	@Override
	public String getLocationDesc() {
		return locationDesc;
	}
	/**
	 * <p>Fetches location label to be displayed</p>
	 *
	 * @return String - location label of the location box
	 */
	@Override
	public String getLocationLabel() {
		return locationLabel;
	}
	/**
	 * <p>Fetches error message to be displayed</p>
	 *
	 * @return String - error message of the location box
	 */
	@Override
	public String getErrorMsg() {
		return errorMsg;
	}
	/**
	 * <p>Fetches no-follow for Link</p>
	 *
	 * @return String - no-follow value
	 */
	@Override
	public String getDoNotFollow() {
		return doNotFollow;
	}
	/**
	 *
	 * @return privacyPolicyInfo
	 */
	@Override
	public String getPrivacyPolicyInfo() {
		return privacyPolicyInfo;
	}
	/**
	 * @return getexportertype
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * @return apiDomain
	 */
	@Override
	public String getApiDomain() {

		return mapquestApiService.getApiDomain();
	}
	/**
	 * @return ReversePath
	 */
	@Override
	public String getReversePath() {

		return mapquestApiService.getReversePath();
	}
	/**
	 * @return apiDomain
	 */
	@Override
	public String getPath() {

		return mapquestApiService.getPath();
	}
	/**
	 * @return ReversePath
	 */
	@Override
	public String getApiKey() {
		String brand = CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel());
		return ConfigurationUtil.getConfigValue(mapQuestApiService.getApiKey(),brand) != null ? ConfigurationUtil.getConfigValue(mapQuestApiService.getApiKey(),brand):null;
	}
	/**
	 * @return CookieTimeout
	 */
	@Override
	public int getCookieTimeout() {

		return mapquestApiService.getCookieTimeout();
	}
	@Override
	public String getNoZipErrorMsg() {
		return noZipErrorMsg;
	}

}