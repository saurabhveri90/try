package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.PromotionalCardBean;
import com.tracfonecore.core.beans.ScenarioBasedPromotionalCardBean;

public interface PromotionalCardsModel extends ComponentExporter {

	@JsonProperty("componentVersion")
	public String getComponentVersion();
	
	@JsonProperty("headlineText")
	public String getHeadlineText();
	
	@JsonProperty("subHeadlineText")
	public String getSubHeadlineText();
	
	@JsonProperty("includeCardImage")
	public String getIncludeCardImage();
	
	@JsonProperty("cardImage")
	public String getCardImage();
	
	@JsonProperty("cardImageAltText")
	public String getCardImageAltText();

	@JsonProperty("cardImageAssetId")
	public String getCardImageAssetId();

	@JsonProperty("cardImageAssetAgencyId")
	public String getCardImageAssetAgencyId();
	
	@JsonProperty("includeCardCta")
	public String getIncludeCardCta();
	
	@JsonProperty("cardCtaLabel")
	public String getCardCtaLabel();
	
	@JsonProperty("cardCtaLink")
	public String getCardCtaLink();
	
	@JsonProperty("includeAppStore")
	public String getIncludeAppStore();
	
	@JsonProperty("appstoreFileReference")
	public String getAppstoreFileReference();
	
	@JsonProperty("appstore")
	public String getAppstore();
	
	@JsonProperty("appstorealttext")
	public String getAppstorealttext();
	
	@JsonProperty("includePlayStore")
	public String getIncludePlayStore();
	
	@JsonProperty("playstoreFileReference")
	public String getPlaystoreFileReference();
	
	@JsonProperty("playstore")
	public String getPlaystore();
	
	@JsonProperty("playstorealttext")
	public String getPlaystorealttext();
	
	@JsonProperty("promotionalCards")
	public List<PromotionalCardBean> getPromotionalCards();

	@JsonProperty("appstoreLogoPathAssetId")
	public String getAppstoreLogoPathAssetId();

	@JsonProperty("appstoreLogoPathAssetAgencyId")
	public String getAppstoreLogoPathAssetAgencyId();

	@JsonProperty("playstoreLogoPathAssetId")
	public String getPlaystoreLogoPathAssetId();

	@JsonProperty("playstoreLogoPathAssetAgencyId")
	public String getPlaystoreLogoPathAssetAgencyId();

	@JsonProperty("scenarioBasedPromotionalCards")
	public List<ScenarioBasedPromotionalCardBean> getScenarioBasedPromotionalCards();
}

