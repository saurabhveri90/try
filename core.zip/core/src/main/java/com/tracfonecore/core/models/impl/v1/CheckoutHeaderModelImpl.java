/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl.v1;

import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.CheckoutHeaderModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import org.apache.sling.settings.SlingSettingsService;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CheckoutHeaderModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/structure/checkoutheader/v1/checkoutheader", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CheckoutHeaderModelImpl implements CheckoutHeaderModel {

	@ScriptVariable
	private ValueMap properties;

	@Inject
	private SlingSettingsService settingService;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String fileReference;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String fileReferenceDeskSm;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String fileReferenceMobile;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String logoAltTextDesktop;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String logoAltTextMobile;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String logoTargetURL;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String doNotFollow;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String logoRedirectionMessage;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String logoNewWindow;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String cartIconPageUrl;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String cartUrlTarget;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String placementTextGTM;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String dataGTMCTALogoDesktop;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String dataGTMCTALogoMobile;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String dataGTMCTACart;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String isNationalRetailerPage;
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String isAcpMigration;

	@Self
	private SlingHttpServletRequest request;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String componentVersion;

    @Override
    public String getComponentVersion() {
        return StringUtils.isNotBlank(componentVersion) ?  componentVersion: "v1";
    }

	@Override
	public String getFileReference() {
		return fileReference;
	}

	@Override
	public String getFileReferenceDeskSm() {
		return fileReferenceDeskSm;
	}

	@Override
	public String getFileReferenceDeskSmAssetId() {
		return ApplicationUtil.getAssetId(fileReferenceDeskSm,
				request.getResourceResolver(), ApplicationConstants.IMAGE);
	}

	@Override
	public String getFileReferenceDeskSmAssetAgencyId() {
		return ApplicationUtil.getAssetMetaDataValue(fileReferenceDeskSm,
				request.getResourceResolver(), ApplicationConstants.WEBER_ID);
	}

	@Override
	public String getFileReferenceMobile() {
		return fileReferenceMobile;
	}

	@Override
	public String getFileReferenceMobileAssetId() {
		return ApplicationUtil.getAssetId(fileReferenceMobile,
				request.getResourceResolver(), ApplicationConstants.IMAGE);
	}

	@Override
	public String getFileReferenceMobileAssetAgencyId() {
		return ApplicationUtil.getAssetMetaDataValue(fileReferenceMobile,
				request.getResourceResolver(), ApplicationConstants.WEBER_ID);
	}

	@Override
	public String getLogoAltTextDesktop() {
		return logoAltTextDesktop;
	}

	@Override
	public String getLogoAltTextMobile() {
		return logoAltTextMobile;
	}

	@Override
	public String getLogoTargetURL() {
		String finalLogoTargetURL = logoTargetURL;
		if (StringUtils.isNotBlank(finalLogoTargetURL) &&  Boolean.TRUE.equals(ApplicationUtil.isInternalLink(finalLogoTargetURL))) {
			if (finalLogoTargetURL.indexOf(ApplicationConstants.HTML_EXTENSION) == -1) {
				finalLogoTargetURL = finalLogoTargetURL + ApplicationConstants.HTML_EXTENSION;
			}
			if (StringUtils.isNotBlank(finalLogoTargetURL)) {
				String ctaPath = request.getResourceResolver().map(finalLogoTargetURL);
				if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
					finalLogoTargetURL = ApplicationUtil
							.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
				}
			}
		}
		return finalLogoTargetURL;
	}

	private String getShortURL(String serverDomain, String url) {
		if (StringUtils.isNotBlank(url) && StringUtils.isNotBlank(serverDomain) && url.contains(serverDomain)) {
			url = url.split(serverDomain)[1];
		}
		return url;
	}

	@Override
	public String getDoNotFollow() {
		return ApplicationUtil.getNoFollow(doNotFollow);
	}

	@Override
	public String getLogoNewWindow() {
		return logoNewWindow;
	}

	@Override
	public String getLogoRedirectionMessage() {
		return logoRedirectionMessage;
	}

	@Override
	public String getCartIconPageUrl() {
		String finalCartIconTargetUrl = cartIconPageUrl;
		if (StringUtils.isNotBlank(finalCartIconTargetUrl) &&  Boolean.TRUE.equals(ApplicationUtil.isInternalLink(finalCartIconTargetUrl))) {
			if (finalCartIconTargetUrl.indexOf(ApplicationConstants.HTML_EXTENSION) == -1) {
				finalCartIconTargetUrl = finalCartIconTargetUrl + ApplicationConstants.HTML_EXTENSION;
			}
			if (StringUtils.isNotBlank(finalCartIconTargetUrl)) {
				String ctaPath = request.getResourceResolver().map(finalCartIconTargetUrl);
				if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
					finalCartIconTargetUrl = ApplicationUtil
							.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
				}
			}
		}
		return finalCartIconTargetUrl;
	}

	@Override
	public String getCartUrlTarget() {
		return cartUrlTarget;
	}

	@Override
	public String getPlacementTextGTM() {
		return placementTextGTM;
	}

	@Override
	public String getDataGTMCTALogoDesktop() {
		return dataGTMCTALogoDesktop;
	}

	@Override
	public String getDataGTMCTALogoMobile() {
		return dataGTMCTALogoMobile;
	}

	@Override
	public String getDataGTMCTACart() {
		return dataGTMCTACart;
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public Boolean getIsNationalRetailerPage(){
		return Boolean.parseBoolean(isNationalRetailerPage);
	}

	@Override
	public Boolean getIsAcpMigration(){
		return Boolean.parseBoolean(isAcpMigration);
	}
}