/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Header} Sling Model used for the {@code /apps/tracfone-core/components/commerce/compareproducts} component.
 */
public interface CompareProductModel extends ComponentExporter {
	
	@JsonProperty("specsHeading")
	public String getSpecsHeading() ;

	@JsonProperty("addnSpecsHeading")
	public String getAddnSpecsHeading() ;

	@JsonProperty("ctaText")
	public String getCtaText() ;
	
	@JsonProperty("flowType")
	public String getFlowType();
	
	@JsonProperty("addProductPagePath")
	public String getAddProductPagePath();
	
	@JsonProperty("addProductCtaAcc")
	public String getAddProductCtaAcc();
	
	@JsonProperty("addproductdonotfollowlink")
	public String getAddproductdonotfollowlink();
	
	@JsonProperty("addProductCtaText")
	public String getAddProductCtaText();
	
	@JsonProperty("ctaAccessibility")
	public String getCtaAccessibility();

	/**
	 * @return the isPlanCompare
	 */
	@JsonProperty("isPlanCompare")
	public String getIsPlanCompare();

	
}
