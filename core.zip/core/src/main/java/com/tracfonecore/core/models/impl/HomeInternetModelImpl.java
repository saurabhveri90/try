/*
 *  Copyright 2022 SUNERA Technologies PVT Ltd.  
 */
package com.tracfonecore.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.HomeInternetModel;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { HomeInternetModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/fixedWireless", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class HomeInternetModelImpl implements HomeInternetModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String brandLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String brandLogoAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String headerTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String landingScreenTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String landingScreenSummary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String landingScreenLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String landingLogoAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String pnpText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String helpText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String helpDescription;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String checkAvailabilityBtnTxt;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String whatsNxtHeaderTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String whatsNxtSummary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String firstLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String firstLogoAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String secondLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String secondLogoAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String whatsNxtInstructionsText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String whatsNxtCtnBtnTxt;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String changeAddressLinkLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String registerHeaderTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String blackLineLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String blackLineLogoAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String disabledSecondLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String disabledSecondLogoAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String registerDescriptionText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String registerBtntxt;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String successLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String successLogoAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String greenLineLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String greenLineLogoAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String imeiHeaderTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String imeiSummary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String findImeiLinkTxt;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String imeiBarcodeLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String imeiBarcodeLogoAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String imeiConfirmDeviceBtntxt;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String imeiErrorTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String imeiErrorDescription;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String congratsHeaderTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String activateLinkTxt;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String congratsMsgTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String congratsMsgSummary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String expireLabelTxt;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String nextStepText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String calendarLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String calendarLogoAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String signupHeaderTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String signupSummary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String locationLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String locationLogoAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String signupPnpText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String signupBtnLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String cancelBtnLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String signupThanksHeaderTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String signupThanksSummary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String signupThanksChangeAddressBtnTxt;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String signupCancelHeaderTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String signupCancelSummary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String signupCancelNote;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String closebtnText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String tobeUsedText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String nextStep;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartBrandLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartBrandLogoAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartWhatsNextTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartStepOneText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartStepTwoText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartStepThreeText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartSeeDetailsBtnText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartStepOneLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartStepOneLogoAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartStepTwoLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartStepTwoLogoAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartStepThreeLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartStepThreeLogoAltText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String lteDataNotification;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartNoServiceTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartNoServiceSummary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addressInvalidTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addressInvalidSummary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartGreyColourLine;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartGreyColourLineAltText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String availabilityDescription;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String chkAailabilityHeading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String chkAailabilityDescription;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String formStreetAddressLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String formAptLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String formEmailLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String formEmailNotificationDesc;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String formPHNoLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String formFirstNameLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String formLastNameLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String formCntBtnLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String formPrivacyPolicyDesc;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceAvailablePopupTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceAvailablePopupDesc;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceAvailablePopupQuestionLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceAvailablePopupBtnOneLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceAvailablePopupBtnTwoLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceNotAvailablePopupTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceNotAvailablePopupDesc;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String fwaSupportedBrand;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String skipToMainContent;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String welcomeScreenTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String welcomeScreenSubTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String welcomeScreenSubContent;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String welcomeScreenAddressLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String welcomeScreenUnitLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String typeIMEI;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String activationTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String activationSubTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addCalender;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String spotText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String activateHomeInternetDevice;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String activateBtnText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String imeiFoundText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String submitIMEI;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String reservationConfirmTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String reservationConfirmSubTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String reservationConfirmWhtNext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String reservationConfirmStep1;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String reservationConfirmStep2;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String reservationConfirmStep2SubText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String reservationConfirmStep3;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String paidBtnText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceConfirmTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceConfirmWhtNext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceConfirmStep1;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceConfirmStep2;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceConfirmStep3;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String scanBtnText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String typeYourIMEI;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String privacyLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String reservationSet;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String activateDevice;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String reservationWithLTE;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String whatsNext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String inactiveStatusPageTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String inactiveStatusPageContent1;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String inactiveStatusPageContent2;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String inactiveStatusPageBtnLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean hideScanQR;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enterYourIMEI;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceConfirmWithNonQR;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String activationSet;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String activateLabel;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailPrivcayText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String activateDeviceLinkURL;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceNotAvailableTitle;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceNotAvailableSubTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String agreeSignUp;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String submitEmail;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String signupSuccessText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String signupSuccessSubTitle;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String checkAnotherAddress;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String importantActiveInfo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String deviceIMEILogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String chkAailabilityDescriptionForSR;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String signupPhoneLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String signupEmailLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String homeInternetTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean showSignUpScreen;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceUnavailableHeader;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceUnavailableContent;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceUnavailableChangeAddress;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceUnavailableHotspot;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hotspotRedirectURL;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String caAddressLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String caStateLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String caEmailLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceUnavailableContentForWalmart;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceUnavailableHeaderForWalmart;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promoAddress;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promoEmail;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promoMobileNumber;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promoRegistration;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promoPrivacyLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promoUnit;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promoCloseBtn;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promoURLString;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promoHomeURL;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promoHeader;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promoSubContent;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promoSignUpCTA;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promoErrorContent;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promoDescription;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promoCustomerInfo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailSignupPhoneLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailSignupEmailLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailAgreeSignUp;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailPrivacyLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailSubmitSignUp;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailCheckAnotherAddress;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailServiceNotAvailableTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailServiceNotAvailableSubTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailServiceNotAvailableSubContent;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailSignupSuccessText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailSignupSuccessEmailLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailSignupSuccessPhoneLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailSignupSuccessLocationLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String showSignUpSection;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String fwVZSignupSucess;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailEditLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailEditAddressLabelSR;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailExpolreOther;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailEditEmailLabelSR;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailEditPhoneLabelSR;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean retailShowSignUpScreen;

	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmServiceAvailableFormTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmServiceAvailableFormSubTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmServiceAvailableFormSubContent;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartShippingText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmServiceAvailableTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmServiceAvailableSubTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmServiceAvailableFormLogo;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmFormAddressLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmFormUnitLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmFormEmailLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartSeeDetailsBtnSRText;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartCACTAText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartMarketingPageUrl;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartPDPPageUrl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartDefaultPageUrl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String walmartBrandLogoSRText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailPhoneNumberHelpText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmSignupPhoneLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmSignupEmailLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmServiceNotAvailableTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmServiceNotAvailableSubTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmServiceNotAvailableSubContent;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmSignupSuccessText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmSignupSuccessEmailLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmSignupSuccessPhoneLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmSignupSuccessLocationLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmSignupPhoneNumberHelpText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean wmShowSignUpScreen;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmSignupNotificationText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmSignupThanksText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmAgreeSignUp;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmPrivacyLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmSubmitSignUp;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmCheckAnotherAddress;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmEditLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmEditAddressLabelSR;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmExpolreOther;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmEditEmailLabelSR;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmEditPhoneLabelSR;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stSignupEmailLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stSignupPhoneLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stSignupPhoneNumberHelpText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stAgreeSignUp;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stPrivacyLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stSubmitSignUp;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stCheckAnotherAddress;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stServiceNotAvailableTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stServiceNotAvailableSubTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stServiceNotAvailableSubContent;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stSignupSuccessText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stSignupSuccessEmailLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stSignupSuccessPhoneLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stSignupSuccessLocationLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stEditLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stEditAddressLabelSR;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stExpolreOther;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stEditEmailLabelSR;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stEditPhoneLabelSR;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stSignupNotificationText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stSignupThanksText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stFormAddressLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stFormUnitLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stFormEmailLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailSignupThanksText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailSignupNotificationText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stServiceAvailableFormSubContent;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stheaderstyle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stExpolreDevicesURL;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stSignupConfirmEmailLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String stSignupNotMatchError;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmSignupConfirmEmailLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmSignupNotMatchError;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String wmPnpText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailSignupConfirmEmailLbl;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String retailNotMatchErrorMsg;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String formCntBtnDisableLbl;

	@Override
	public String getBrandLogo() {
		return DynamicMediaUtils.changeMediaPathToDMPath(brandLogo, request.getResourceResolver());
	}

	@Override
	public String getBrandLogoAltText() {
		return brandLogoAltText;
	}

	@Override
	public String getHeaderTitle() {
		return headerTitle;
	}

	@Override
	public String getLandingScreenTitle() {
		return landingScreenTitle;
	}

	@Override
	public String getLandingScreenSummary() {
		return landingScreenSummary;
	}

	@Override
	public String getLandingScreenLogo() {
		return DynamicMediaUtils.changeMediaPathToDMPath(landingScreenLogo, request.getResourceResolver());
	}

	@Override
	public String getLandingLogoAltText() {
		return landingLogoAltText;
	}

	@Override
	public String getPnpText() {
		return pnpText;
	}

	@Override
	public String getHelpText() {
		return helpText;
	}

	@Override
	public String getHelpDescription() {
		return helpDescription;
	}

	@Override
	public String getCheckAvailabilityBtnTxt() {
		return checkAvailabilityBtnTxt;
	}

	@Override
	public String getWhatsNxtHeaderTitle() {
		return whatsNxtHeaderTitle;
	}

	@Override
	public String getWhatsNxtSummary() {
		return whatsNxtSummary;
	}

	@Override
	public String getFirstLogo() {
		return DynamicMediaUtils.changeMediaPathToDMPath(firstLogo, request.getResourceResolver());
	}

	@Override
	public String getFirstLogoAltText() {
		return firstLogoAltText;
	}

	@Override
	public String getSecondLogo() {
		return DynamicMediaUtils.changeMediaPathToDMPath(secondLogo, request.getResourceResolver());
	}

	@Override
	public String getSecondLogoAltText() {
		return secondLogoAltText;
	}

	@Override
	public String getWhatsNxtInstructionsText() {
		return whatsNxtInstructionsText;
	}

	@Override
	public String getWhatsNxtCtnBtnTxt() {
		return whatsNxtCtnBtnTxt;
	}

	@Override
	public String getChangeAddressLinkLabel() {
		return changeAddressLinkLabel;
	}

	@Override
	public String getRegisterHeaderTitle() {
		return registerHeaderTitle;
	}

	@Override
	public String getBlackLineLogo() {
		return DynamicMediaUtils.changeMediaPathToDMPath(blackLineLogo, request.getResourceResolver());
	}

	@Override
	public String getBlackLineLogoAltText() {
		return blackLineLogoAltText;
	}

	@Override
	public String getDisabledSecondLogo() {
		return DynamicMediaUtils.changeMediaPathToDMPath(disabledSecondLogo, request.getResourceResolver());
	}

	@Override
	public String getDisabledSecondLogoAltText() {
		return disabledSecondLogoAltText;
	}

	@Override
	public String getRegisterDescriptionText() {
		return registerDescriptionText;
	}

	@Override
	public String getRegisterBtntxt() {
		return registerBtntxt;
	}

	@Override
	public String getSuccessLogo() {
		return DynamicMediaUtils.changeMediaPathToDMPath(successLogo, request.getResourceResolver());
	}

	@Override
	public String getSuccessLogoAltText() {
		return successLogoAltText;
	}

	@Override
	public String getGreenLineLogo() {
		return DynamicMediaUtils.changeMediaPathToDMPath(greenLineLogo, request.getResourceResolver());
	}

	@Override
	public String getGreenLineLogoAltText() {
		return greenLineLogoAltText;
	}

	@Override
	public String getImeiHeaderTitle() {
		return imeiHeaderTitle;
	}

	@Override
	public String getImeiSummary() {
		return imeiSummary;
	}

	@Override
	public String getFindImeiLinkTxt() {
		return findImeiLinkTxt;
	}

	@Override
	public String getImeiBarcodeLogo() {
		return DynamicMediaUtils.changeMediaPathToDMPath(imeiBarcodeLogo, request.getResourceResolver());
	}

	@Override
	public String getImeiBarcodeLogoAltText() {
		return imeiBarcodeLogoAltText;
	}

	@Override
	public String getImeiConfirmDeviceBtntxt() {
		return imeiConfirmDeviceBtntxt;
	}

	@Override
	public String getImeiErrorTitle() {
		return imeiErrorTitle;
	}

	@Override
	public String getImeiErrorDescription() {
		return imeiErrorDescription;
	}

	@Override
	public String getCongratsHeaderTitle() {
		return congratsHeaderTitle;
	}

	@Override
	public String getActivateLinkTxt() {
		return activateLinkTxt;
	}

	@Override
	public String getCongratsMsgTitle() {
		return congratsMsgTitle;
	}

	@Override
	public String getCongratsMsgSummary() {
		return congratsMsgSummary;
	}

	@Override
	public String getExpireLabelTxt() {
		return expireLabelTxt;
	}

	@Override
	public String getNextStepText() {
		return nextStepText;
	}

	@Override
	public String getCalendarLogo() {
		return DynamicMediaUtils.changeMediaPathToDMPath(calendarLogo, request.getResourceResolver());
	}

	@Override
	public String getCalendarLogoAltText() {
		return calendarLogoAltText;
	}

	@Override
	public String getSignupHeaderTitle() {
		return signupHeaderTitle;
	}

	@Override
	public String getSignupSummary() {
		return signupSummary;
	}

	@Override
	public String getLocationLogo() {
		return DynamicMediaUtils.changeMediaPathToDMPath(locationLogo, request.getResourceResolver());
	}

	@Override
	public String getLocationLogoAltText() {
		return locationLogoAltText;
	}

	@Override
	public String getSignupPnpText() {
		return signupPnpText;
	}

	@Override
	public String getSignupBtnLabel() {
		return signupBtnLabel;
	}

	@Override
	public String getCancelBtnLabel() {
		return cancelBtnLabel;
	}

	@Override
	public String getSignupThanksHeaderTitle() {
		return signupThanksHeaderTitle;
	}

	@Override
	public String getSignupThanksSummary() {
		return signupThanksSummary;
	}

	@Override
	public String getSignupThanksChangeAddressBtnTxt() {
		return signupThanksChangeAddressBtnTxt;
	}

	@Override
	public String getSignupCancelHeaderTitle() {
		return signupCancelHeaderTitle;
	}

	@Override
	public String getSignupCancelSummary() {
		return signupCancelSummary;
	}

	@Override
	public String getSignupCancelNote() {
		return signupCancelNote;
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getClosebtnText() {
		return closebtnText;
	}

	@Override
	public String getTobeUsedText() {
		return tobeUsedText;
	}

	@Override
	public String getNextStep() {
		return nextStep;
	}

	@Override
	public String getWalmartBrandLogo() {
		return walmartBrandLogo;
	}

	@Override
	public String getWalmartBrandLogoAltText() {
		return walmartBrandLogoAltText;
	}

	@Override
	public String getWalmartWhatsNextTitle() {
		return walmartWhatsNextTitle;
	}

	@Override
	public String getWalmartStepOneText() {
		return walmartStepOneText;
	}

	@Override
	public String getWalmartStepTwoText() {
		return walmartStepTwoText;
	}

	@Override
	public String getWalmartStepThreeText() {
		return walmartStepThreeText;
	}

	@Override
	public String getWalmartSeeDetailsBtnText() {
		return walmartSeeDetailsBtnText;
	}

	@Override
	public String getWalmartStepOneLogo() {
		return walmartStepOneLogo;
	}

	@Override
	public String getWalmartStepOneLogoAltText() {
		return walmartStepOneLogoAltText;
	}

	@Override
	public String getWalmartStepTwoLogo() {
		return walmartStepTwoLogo;
	}

	@Override
	public String getWalmartStepTwoLogoAltText() {
		return walmartStepTwoLogoAltText;
	}

	@Override
	public String getWalmartStepThreeLogo() {
		return walmartStepThreeLogo;
	}

	@Override
	public String getWalmartStepThreeLogoAltText() {
		return walmartStepThreeLogoAltText;
	}

	@Override
	public String getLteDataNotification() {
		return lteDataNotification;
	}

	@Override
	public String getWalmartNoServiceTitle() {
		return walmartNoServiceTitle;
	}

	@Override
	public String getWalmartNoServiceSummary() {
		return walmartNoServiceSummary;
	}

	@Override
	public String getAddressInvalidTitle() {
		return addressInvalidTitle;
	}

	@Override
	public String getAddressInvalidSummary() {
		return addressInvalidSummary;
	}

	@Override
	public String getWalmartGreyColourLine() {
		return walmartGreyColourLine;
	}

	@Override
	public String getWalmartGreyColourLineAltText() {
		return walmartGreyColourLineAltText;
	}
	
	@Override
	public String getAvailabilityDescription() {
		return availabilityDescription;
	}

	@Override
	public String getChkAailabilityHeading() {
		return chkAailabilityHeading;
	}

	@Override
	public String getChkAailabilityDescription() {
		return chkAailabilityDescription;
	}

	@Override
	public String getFormStreetAddressLbl() {
		return formStreetAddressLbl;
	}

	@Override
	public String getFormAptLbl() {
		return formAptLbl;
	}

	@Override
	public String getFormEmailLbl() {
		return formEmailLbl;
	}

	@Override
	public String getFormEmailNotificationDesc() {
		return formEmailNotificationDesc;
	}

	@Override
	public String getFormPHNoLbl() {
		return formPHNoLbl;
	}


	@Override
	public String getFormFirstNameLbl() {
		return formFirstNameLbl;
	}

	@Override
	public String getFormLastNameLbl() {
		return formLastNameLbl;
	}

	@Override
	public String getFormCntBtnLbl() {
		return formCntBtnLbl;
	}

	@Override
	public String getFormPrivacyPolicyDesc() {
		return formPrivacyPolicyDesc;
	}

	@Override
	public String getServiceAvailablePopupTitle() {
		return serviceAvailablePopupTitle;
	}

	@Override
	public String getServiceAvailablePopupDesc() {
		return serviceAvailablePopupDesc;
	}

	@Override
	public String getServiceAvailablePopupQuestionLbl() {
		return serviceAvailablePopupQuestionLbl;
	}

	@Override
	public String getServiceAvailablePopupBtnOneLbl() {
		return serviceAvailablePopupBtnOneLbl;
	}

	@Override
	public String getServiceAvailablePopupBtnTwoLbl() {
		return serviceAvailablePopupBtnTwoLbl;
	}

	@Override
	public String getServiceNotAvailablePopupTitle() {
		return serviceNotAvailablePopupTitle;
	}

	@Override
	public String getServiceNotAvailablePopupDesc() {
		return serviceNotAvailablePopupDesc;
	}

	@Override
	public String getFwaSupportedBrand() {
		return fwaSupportedBrand;
	}

	@Override
	public String getSkipToMainContent() {
		return skipToMainContent;
	}
	
	@Override
	public String getWelcomeScreenTitle() {
		return welcomeScreenTitle;
	}
	
	@Override
	public String getWelcomeScreenSubTitle() {
		return welcomeScreenSubTitle;
	}
	
	@Override
	public String getWelcomeScreenSubContent() {
		return welcomeScreenSubContent;
	}
	
	@Override
	public String getWelcomeScreenAddressLabel() {
		return welcomeScreenAddressLabel;
	}
	
	@Override
	public String getWelcomeScreenUnitLabel() {
		return welcomeScreenUnitLabel;
	}
	
	@Override
	public String getTypeIMEI() {
		return typeIMEI;
	}
	
	@Override
	public String getActivationTitle() {
		return activationTitle;
	}
	
	@Override
	public String getActivationSubTitle() {
		return activationSubTitle;
	}
	
	@Override
	public String getAddCalender() {
		return addCalender;
	}
	
	@Override
	public String getSpotText() {
		return spotText;
	}
	
	@Override
	public String getActivateHomeInternetDevice() {
		return activateHomeInternetDevice;
	}
	
	@Override
	public String getActivateBtnText() {
		return activateBtnText;
	}
	
	@Override
	public String getImeiFoundText() {
		return imeiFoundText;
	}
	
	@Override
	public String getSubmitIMEI() {
		return submitIMEI;
	}
	
	@Override
	public String getReservationConfirmTitle() {
		return reservationConfirmTitle;
	}
	
	@Override
	public String getReservationConfirmSubTitle() {
		return reservationConfirmSubTitle;
	}
	
	@Override
	public String getReservationConfirmWhtNext() {
		return reservationConfirmWhtNext;
	}
	
	@Override
	public String getReservationConfirmStep1() {
		return reservationConfirmStep1;
	}
	
	@Override
	public String getReservationConfirmStep2() {
		return reservationConfirmStep2;
	}
	
	@Override
	public String getReservationConfirmStep2SubText() {
		return reservationConfirmStep2SubText;
	}
	
	@Override
	public String getReservationConfirmStep3() {
		return reservationConfirmStep3;
	}
	
	@Override
	public String getPaidBtnText() {
		return paidBtnText;
	}
	
	@Override
	public String getServiceConfirmTitle() {
		return serviceConfirmTitle;
	}
	
	@Override
	public String getServiceConfirmWhtNext() {
		return serviceConfirmWhtNext;
	}
	
	@Override
	public String getServiceConfirmStep1() {
		return serviceConfirmStep1;
	}
	
	@Override
	public String getServiceConfirmStep2() {
		return serviceConfirmStep2;
	}
	
	@Override
	public String getServiceConfirmStep3() {
		return serviceConfirmStep3;
	}
	
	@Override
	public String getScanBtnText() {
		return scanBtnText;
	}
	
	@Override
	public String getTypeYourIMEI() {
		return typeYourIMEI;
	}
	
	@Override
	public String getPrivacyLink() {
		return privacyLink;
	}
	
	@Override
	public String getReservationSet() {
		return reservationSet;
	}
	
	@Override
	public String getActivateDevice() {
		return activateDevice;
	}
	
	@Override
	public String getReservationWithLTE() {
		return reservationWithLTE;
	}
	
	@Override
	public String getWhatsNext() {
		return whatsNext;
	}
	
	@Override
	public String getInactiveStatusPageTitle() {
		return inactiveStatusPageTitle;
	}
	
	@Override
	public String getInactiveStatusPageContent1() {
		return inactiveStatusPageContent1;
	}
	
	@Override
	public String getInactiveStatusPageContent2() {
		return inactiveStatusPageContent2;
	}
	
	@Override
	public String getInactiveStatusPageBtnLbl() {
		return inactiveStatusPageBtnLbl;
	}
	@Override
	public Boolean getHideScanQR() {
		return hideScanQR;
	}
	@Override
	public String getEnterYourIMEI() {
		return enterYourIMEI;
	}
	@Override
	public String getServiceConfirmWithNonQR() {
		return serviceConfirmWithNonQR;
	}
	@Override
	public String getActivationSet() {
		return activationSet;
	}
	@Override
	public String getActivateLabel() {
		return activateLabel;
	}
	@Override
	public String getRetailPrivcayText() {
		return retailPrivcayText;
	}
	@Override
	public String getActivateDeviceLinkURL() {
		return activateDeviceLinkURL;
	}
	
	@Override
	public String getServiceNotAvailableTitle() {
		return serviceNotAvailableTitle;
	}
	
	@Override
	public String getServiceNotAvailableSubTitle() {
		return serviceNotAvailableSubTitle;
	}
	
	@Override
	public String getAgreeSignUp() {
		return agreeSignUp;
	}
	
	@Override
	public String getSubmitEmail() {
		return submitEmail;
	}
	
	@Override
	public String getSignupSuccessText() {
		return signupSuccessText;
	}
	@Override
	public String getSignupSuccessSubTitle() {
		return signupSuccessSubTitle;
	}
	@Override
	public String getCheckAnotherAddress() {
		return checkAnotherAddress;
	}
	@Override
	public String getImportantActiveInfo() {
		return importantActiveInfo;
	}

	@Override
	public String getDeviceIMEILogo() {
		return deviceIMEILogo;
	}

	@Override
	public String getChkAailabilityDescriptionForSR() {
		return chkAailabilityDescriptionForSR;
	}

	@Override
	public String getSignupPhoneLbl() {
		return signupPhoneLbl;
	}

	@Override
	public String getSignupEmailLbl() {
		return signupEmailLbl;
	}
	
	@Override
	public String getHomeInternetTitle() {
		return homeInternetTitle;
	}

	@Override
	public Boolean getShowSignUpScreen() {
		return showSignUpScreen;
	}
	
	@Override
	public String getServiceUnavailableHeader() {
		return serviceUnavailableHeader;
	}

	@Override
	public String getServiceUnavailableContent() {
		return serviceUnavailableContent;
	}

	@Override
	public String getServiceUnavailableChangeAddress() {
		return serviceUnavailableChangeAddress;
	}

	@Override
	public String getServiceUnavailableHotspot() {
		return serviceUnavailableHotspot;
	}

	@Override
	public String getHotspotRedirectURL() {
		return hotspotRedirectURL;
	}

	@Override
	public String getCaAddressLabel() {
		return caAddressLabel;
	}

	@Override
	public String getCaStateLabel() {
		return caStateLabel;
	}

	@Override
	public String getCaEmailLabel() {
		return caEmailLabel;
	}

	
	@Override
	public String getServiceUnavailableHeaderForWalmart() {
		return serviceUnavailableHeaderForWalmart;
	}

	@Override
	public String getServiceUnavailableContentForWalmart() {
		return serviceUnavailableContentForWalmart;
	}

	@Override
	public String getPromoAddress() {
		return promoAddress;
	}

	@Override
	public String getPromoEmail() {
		return promoEmail;
	}

	@Override
	public String getPromoMobileNumber() {
		return promoMobileNumber;
	}

	@Override
	public String getPromoRegistration() {
		return promoRegistration;
	}

	@Override
	public String getPromoPrivacyLink() {
		return promoPrivacyLink;
	}
	
	@Override
	public String getPromoUnit() {
		return promoUnit;
	}

	@Override
	public String getPromoCloseBtn() {
		return promoCloseBtn;
	}

	@Override
	public String getPromoURLString() {
		return promoURLString;
	}

	@Override
	public String getPromoHomeURL() {
		return promoHomeURL;
	}

	@Override
	public String getPromoHeader() {
		return promoHeader;
	}

	@Override
	public String getPromoSubContent() {
		return promoSubContent;
	}

	@Override
	public String getPromoSignUpCTA() {
		return promoSignUpCTA;
	}

	@Override
	public String getPromoErrorContent() {
		return promoErrorContent;
	}

	@Override
	public String getPromoDescription() {
		return promoDescription;
	}

	@Override
	public String getPromoCustomerInfo() {
		return promoCustomerInfo;
	}

	@Override
	public String getRetailSignupPhoneLbl() {
		return retailSignupPhoneLbl;
	}

	@Override
	public String getRetailSignupEmailLbl() {
		return retailSignupEmailLbl;
	}

	@Override
	public String getRetailAgreeSignUp() {
		return retailAgreeSignUp;
	}

	@Override
	public String getRetailPrivacyLink() {
		return retailPrivacyLink;
	}

	@Override
	public String getRetailSubmitSignUp() {
		return retailSubmitSignUp;
	}

	@Override
	public String getRetailCheckAnotherAddress() {
		return retailCheckAnotherAddress;
	}

	@Override
	public String getRetailServiceNotAvailableTitle() {
		return retailServiceNotAvailableTitle;
	}

	@Override
	public String getRetailServiceNotAvailableSubTitle() {
		return retailServiceNotAvailableSubTitle;
	}

	@Override
	public String getRetailServiceNotAvailableSubContent() {
		return retailServiceNotAvailableSubContent;
	}

	@Override
	public String getRetailSignupSuccessText() {
		return retailSignupSuccessText;
	}

	@Override
	public String getRetailSignupSuccessEmailLbl() {
		return retailSignupSuccessEmailLbl;
	}

	@Override
	public String getRetailSignupSuccessPhoneLbl() {
		return retailSignupSuccessPhoneLbl;
	}

	@Override
	public String getRetailSignupSuccessLocationLbl() {
		return retailSignupSuccessLocationLbl;
	}

	@Override
	public String getShowSignUpSection() {
		return showSignUpSection;
	}

	@Override
	public String getFwVZSignupSucess() {
		return fwVZSignupSucess;
	}

	@Override
	public String getRetailEditLabel() {
		return retailEditLabel;
	}

	@Override
	public String getRetailEditAddressLabelSR() {
		return retailEditAddressLabelSR;
	}

	@Override
	public String getRetailExpolreOther() {
		return retailExpolreOther;
	}

	@Override
	public String getRetailEditEmailLabelSR() {
		return retailEditEmailLabelSR;
	}

	@Override
	public String getRetailEditPhoneLabelSR() {
		return retailEditPhoneLabelSR;
	}

	@Override
	public Boolean getRetailShowSignUpScreen() {
		return retailShowSignUpScreen;
	}

	@Override
	public String getWmServiceAvailableFormTitle() {
		return wmServiceAvailableFormTitle;
	}

	@Override
	public String getWmServiceAvailableFormSubTitle() {
		return wmServiceAvailableFormSubTitle;
	}

	@Override
	public String getWmServiceAvailableFormSubContent() {
		return wmServiceAvailableFormSubContent;
	}

	@Override
	public String getWalmartShippingText() {
		return walmartShippingText;
	}

	@Override
	public String getWmServiceAvailableTitle() {
		return wmServiceAvailableTitle;
	}

	@Override
	public String getWmServiceAvailableSubTitle() {
		return wmServiceAvailableSubTitle;
	}

	@Override
	public String getWmServiceAvailableFormLogo() {
		return wmServiceAvailableFormLogo;
	}

	@Override
	public String getWmFormAddressLbl() {
		return wmFormAddressLbl;
	}

	@Override
	public String getWmFormUnitLbl() {
		return wmFormUnitLbl;
	}

	@Override
	public String getWmFormEmailLbl() {
		return wmFormEmailLbl;
	}

	@Override
	public String getWalmartSeeDetailsBtnSRText() {
		return walmartSeeDetailsBtnSRText;
	}

	@Override
	public String getWalmartCACTAText() {
		return walmartCACTAText;
	}

	@Override
	public String getRetailPhoneNumberHelpText() {
		return retailPhoneNumberHelpText;
	}

	@Override
	public String getWalmartMarketingPageUrl() {
		return walmartMarketingPageUrl;
	}

	@Override
	public String getWalmartPDPPageUrl() {
		return walmartPDPPageUrl;
	}

	@Override
	public String getWalmartDefaultPageUrl() {
		return walmartDefaultPageUrl;
	}

	@Override
	public String getWalmartBrandLogoSRText() {
		return walmartBrandLogoSRText;
	}
	
	@Override
	public String getWmSignupPhoneLbl() {
		return wmSignupPhoneLbl;
	}
	
	@Override
	public String getWmSignupEmailLbl() {
		return wmSignupEmailLbl;
	}
	
	@Override
	public String getWmServiceNotAvailableTitle() {
		return wmServiceNotAvailableTitle;
	}
	
	@Override
	public String getWmServiceNotAvailableSubTitle() {
		return wmServiceNotAvailableSubTitle;
	}
	
	@Override
	public String getWmServiceNotAvailableSubContent() {
		return wmServiceNotAvailableSubContent;
	}
	
	@Override
	public String getWmSignupSuccessText() {
		return wmSignupSuccessText;
	}
	
	@Override
	public String getWmSignupSuccessEmailLbl() {
		return wmSignupSuccessEmailLbl;
	}

	@Override
	public String getWmSignupSuccessPhoneLbl() {
		return wmSignupSuccessPhoneLbl;
	}
	
	@Override
	public String getWmSignupSuccessLocationLbl() {
		return wmSignupSuccessLocationLbl;
	}

	@Override
	public String getWmSignupPhoneNumberHelpText() {
		return wmSignupPhoneNumberHelpText;
	}

	@Override
	public Boolean getWmShowSignUpScreen() {
		return wmShowSignUpScreen;
	}

	@Override
	public String getWmSignupNotificationText() {
		return wmSignupNotificationText;
	}

	@Override
	public String getWmSignupThanksText() {
		return wmSignupThanksText;
	}

	@Override
	public String getWmAgreeSignUp() {
		return wmAgreeSignUp;
	}

	@Override
	public String getWmPrivacyLink() {
		return wmPrivacyLink;
	}

	@Override
	public String getWmSubmitSignUp() {
		return wmSubmitSignUp;
	}

	@Override
	public String getWmCheckAnotherAddress() {
		return wmCheckAnotherAddress;
	}

	@Override
	public String getWmEditLabel() {
		return wmEditLabel;
	}

	@Override
	public String getWmEditAddressLabelSR() {
		return wmEditAddressLabelSR;
	}

	@Override
	public String getWmExpolreOther() {
		return wmExpolreOther;
	}

	@Override
	public String getWmEditEmailLabelSR() {
		return wmEditEmailLabelSR;
	}

	@Override
	public String getWmEditPhoneLabelSR() {
		return wmEditPhoneLabelSR;
	}

	@Override
	public String getStSignupEmailLbl() {
		return stSignupEmailLbl;
	}

	@Override
	public String getStSignupPhoneLbl() {
		return stSignupPhoneLbl;
	}

	@Override
	public String getStSignupPhoneNumberHelpText() {
		return stSignupPhoneNumberHelpText;
	}

	@Override
	public String getStAgreeSignUp() {
		return stAgreeSignUp;
	}

	@Override
	public String getStPrivacyLink() {
		return stPrivacyLink;
	}

	@Override
	public String getStSubmitSignUp() {
		return stSubmitSignUp;
	}

	@Override
	public String getStCheckAnotherAddress() {
		return stCheckAnotherAddress;
	}

	@Override
	public String getStServiceNotAvailableTitle() {
		return stServiceNotAvailableTitle;
	}

	@Override
	public String getStServiceNotAvailableSubTitle() {
		return stServiceNotAvailableSubTitle;
	}


	@Override
	public String getStServiceNotAvailableSubContent() {
		return stServiceNotAvailableSubContent;
	}

	@Override
	public String getStSignSignupSuccessText() {
		return stSignupSuccessText;
	}

	@Override
	public String getStSignupSuccessEmailLbl() {
		return stSignupSuccessEmailLbl;
	}

	@Override
	public String getStSignupSuccessPhoneLbl() {
		return stSignupSuccessPhoneLbl;
	}

	@Override
	public String getStSignupSuccessLocationLbl() {
		return stSignupSuccessLocationLbl;
	}

	@Override
	public String getStEditLabel() {
		return stEditLabel;
	}

	@Override
	public String getStEditAddressLabelSR() {
		return stEditAddressLabelSR;
	}

	@Override
	public String getStExpolreOther() {
		return stExpolreOther;
	}

	@Override
	public String getStEditEmailLabelSR() {
		return stEditEmailLabelSR;
	}

	@Override
	public String getStEditPhoneLabelSR() {
		return stEditPhoneLabelSR;
	}
	
	@Override
	public String getStSignupNotificationText() {
		return stSignupNotificationText;
	}

	@Override
	public String getStSignupThanksText() {
		return stSignupThanksText;
	}

	@Override
	public String getStFormAddressLbl() {
		return stFormAddressLbl;
	}

	@Override
	public String getStFormUnitLbl() {
		return stFormUnitLbl;
	}

	@Override
	public String getStFormEmailLbl() {
		return stFormEmailLbl;
	}

	@Override
	public String getStServiceAvailableFormSubContent() {
		return stServiceAvailableFormSubContent;
	}

	@Override
	public String getStheaderstyle() {
		return stheaderstyle;
	}
	
	@Override
	public String getRetailSignupThanksText() {
		return retailSignupThanksText;
	}

	@Override
	public String getRetailSignupNotificationText() {
		return retailSignupNotificationText;
	}

	@Override
	public String getStExpolreDevicesURL() {
		return stExpolreDevicesURL;
	}

	@Override
	public String getStSignupConfirmEmailLbl() {
		return stSignupConfirmEmailLbl;
	}

	@Override
	public String getStSignupNotMatchError() {
		return stSignupNotMatchError;
	}

	@Override
	public String getWmSignupConfirmEmailLbl() {
		return wmSignupConfirmEmailLbl;
	}

	@Override
	public String getWmSignupNotMatchError() {
		return wmSignupNotMatchError;
	}

	@Override
	public String getWmPnpText() {
		return wmPnpText;
	}

	@Override
	public String getRetailSignupConfirmEmailLbl() {
		return retailSignupConfirmEmailLbl;
	}
	
	@Override
	public String getRetailNotMatchErrorMsg() {
		return retailNotMatchErrorMsg;
	}
	
	@Override
	public String getFormCntBtnDisableLbl() {
		return formCntBtnDisableLbl;
	}
}
