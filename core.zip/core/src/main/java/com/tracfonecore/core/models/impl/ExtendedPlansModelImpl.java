/**
 *  Copyright 2020 HCL Technologies Ltd.
 */
package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.models.ExtendedPlansModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.ExtendedPlansService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.utils.CommerceUtil;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ExtendedPlansModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/extendedplans", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ExtendedPlansModelImpl implements ExtendedPlansModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExtendedPlansModelImpl.class);

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private Page currentPage;

	@Inject
	private ApplicationConfigService applicationConfigService;

	@Inject
	private TracfoneApiGatewayService tracfoneApiService;

	@Inject
	private ExtendedPlansService extendedPlansService;

	private String categoryID;
	@ValueMapValue
	private String disclaimer;

	private String planPDPServletPath;

	@PostConstruct
	private void initModel() {
		LOGGER.debug("Inside Extended Plans Model Impl");

		String planPDPPath = tracfoneApiService.getPlanPDPServletPath();
		this.planPDPServletPath = planPDPPath.replace("{language}", getLanguage());
		String planPlpPath = StringUtils.substringBefore(planPDPServletPath, ".");
		Page planPlpPage = request.getResourceResolver().getResource(planPlpPath).adaptTo(Page.class);
		if (planPlpPage != null) {
			this.categoryID = planPlpPage.getContentResource().getValueMap().get("categoryId", String.class);
		} else {
			LOGGER.error("ExtendedPlansModelImpl: Check PlanPDPServletPath in TracfoneApiGatewayService. Path: {}", this.planPDPServletPath);
		}

	}

	/**
	 * <p>
	 * Returns apiDomain from configuration
	 * </p>
	 * 
	 * @return String - apiDomain
	 */
	@Override
	public String getApiDomain() {
		return tracfoneApiService.getApiDomain();
	}

	/**
	 * String is used for category API call
	 * 
	 * @return String - queryString
	 */
	@Override
	public String getQueryString() {
		if(getLanguage() != null && getLanguage().equalsIgnoreCase("es")) {
			return extendedPlansService.getExtPlanQueryESFacet();
		}
		return extendedPlansService.getExtPlanQuery();
	}

	/**
	 * <p>
	 * Returns categoryid from the configured Plans category page.
	 * </p>
	 * 
	 * @return String - categoryID
	 */
	@Override
	public String getCategoryID() {

		return this.categoryID;
	}

	/**
	 * <p>
	 * Returns categoryApiPath from configuration
	 * </p>
	 * 
	 * @return String - categoryApiPath
	 */
	@Override
	public String getExtendedPlansApiPath() {
		return tracfoneApiService.getExtendedPlansAPIPath();
	}

	/**
	 * <p>
	 * Returns plan pdp json servlet path
	 * </p>
	 * 
	 * @return String - planPDPServletPath
	 */
	@Override
	public String getPlanPDPServletPath() {
		return this.planPDPServletPath;
	}

	/**
	 * <p>
	 * Returns home page level from configuration
	 * </p>
	 * 
	 * @return int - homepagelevel
	 */
	private int getHomePageLevel() {

		return applicationConfigService.getHomePageLevel();
	}

	/**
	 * @return brandName
	 */
	@Override
	public String getBrandName() {
		int homePageLavel = applicationConfigService.getHomePageLevel();
		return CommerceUtil.getBrandValue(currentPage, homePageLavel);
	}

	/**
	 * <p>
	 * Returns language from util
	 * </p>
	 * 
	 * @return String - language
	 */
	@Override
	public String getLanguage() {

		return CommerceUtil.getLanguage(currentPage, getHomePageLevel());
	}

	/**
	 * @return String - exportedType
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Returns disclaimer
	 * </p>
	 *
	 * @return String - disclaimer
	 */
    @Override
	public String getDisclaimer() {
		return disclaimer;
	}

}