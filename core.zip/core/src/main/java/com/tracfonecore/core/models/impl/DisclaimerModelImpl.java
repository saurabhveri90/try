package com.tracfonecore.core.models.impl;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.DisclaimerModel;
import com.tracfonecore.core.utils.ApplicationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { DisclaimerModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/disclaimer", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class DisclaimerModelImpl implements DisclaimerModel {
	private static final Logger LOGGER = LoggerFactory.getLogger(DisclaimerModelImpl.class);
	@Inject
	@Source("sling-object")
	private ResourceResolver resourceResolver;
	
	@Self
	private SlingHttpServletRequest request;
	
	/**
	 * Inject cfPath
	 */
	@ValueMapValue
	private String cfPath; 
	
	/**
	 * Inject disclaimerName
	 */
	@ValueMapValue
	private String disclaimerName; 
	
	/**
	 * Inject disclaimerType
	 */
	@ValueMapValue
	private String disclaimerType; 
	
	/**
	 * Inject ariaLabel
	 */
	@ValueMapValue
	private String ariaLabel; 
	
	private String disclaimerText;
	
	private String disclaimerId;
	
	private static final String CF_MASTER_VAR_PATH =  "/jcr:content/data/master";
	
	@PostConstruct
	private void initModel() {
		LOGGER.debug("Entering initModel method");
		String modCfPath = cfPath + CF_MASTER_VAR_PATH;
		Resource fragmentResource = resourceResolver.getResource(modCfPath);
		
		if (fragmentResource != null) {
			disclaimerText = fragmentResource.getValueMap().get("text", String.class);
			String disclaimer_Name=ApplicationUtil.getLowerCaseWithHyphen(disclaimerName);
			this.setDisclaimerId(disclaimer_Name+ ApplicationConstants.HYPHEN + ApplicationConstants.MODAL);
		}
		LOGGER.debug("Exiting initModel method");
	}	

	/**
	 * <p>
	 * Returns getexportertype from resource
	 * </p>
	 * 
	 * @return String - getexportertype
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Returns cfPath from properties
	 * </p>
	 * 
	 * @return String - cfPath
	 */
	@Override
	public String getCfPath() {
		return cfPath;
	}

	/**
	 * <p>
	 * Returns disclaimerType from properties
	 * </p>
	 * 
	 * @return String - disclaimerType
	 */
	@Override
	public String getDisclaimerType() {
		return disclaimerType;
	}
	

	/**
	 * <p>
	 * Returns disclaimerName from properties 
	 * </p>
	 * 
	 * @return String - disclaimerName
	 */
	@Override
	public String getDisclaimerName() {
		return disclaimerName;
	}
	
	/**
	 * <p>Sets disclaimerId</p>
	 *
	 *@param disclaimerId - the disclaimerId to set
	 */
	public void setDisclaimerId(String disclaimerId) {
		this.disclaimerId = disclaimerId;
	}
	
	/**
	 *<p>
	 *Fetches disclaimerId from properties</p>
	 *
	 * @return the disclaimerId
	 */
	public String getDisclaimerId() {
		return disclaimerId;
	}	
	
	/**
	 * <p>
	 * Returns ariLabel from properties 
	 * </p>
	 * 
	 * @return String - ariLabel
	 */
	@Override
	public String getAriaLabel() {
		return ariaLabel;
	}
	/**
	 *<p>
	 *Fetches disclaimerText from Content Fragment
	 *</p>
	 *
	 * @return the disclaimerText
	 */
	@Override
	public String getDisclaimerText() {
		return disclaimerText;
	}

}
