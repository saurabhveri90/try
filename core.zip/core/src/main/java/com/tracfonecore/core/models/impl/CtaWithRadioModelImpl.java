package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.PostConstruct;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.CtaWithRadioModel;
import com.tracfonecore.core.models.CtaWithRadioOptionsModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CtaWithRadioModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/byopdevicetype", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CtaWithRadioModelImpl implements CtaWithRadioModel {
	
	@Self
	private SlingHttpServletRequest request;
	
	@ValueMapValue @Default(values="")
	private String flowType;

	@ValueMapValue
	private String heading;
	
	@ValueMapValue
	private String subheading;
	
	@ChildResource
	private List<CtaWithRadioOptionsModel> deviceType;
	
	@ChildResource
	private List<CtaWithRadioOptionsModel> deviceStatus;
	
	@ChildResource
	private List<CtaWithRadioOptionsModel> simConfirmation;
	
	private List<CtaWithRadioOptionsModel> options;
	
	private static final String DEVICE_TYPE = "deviceType";
	private static final String DEVICE_STATUS = "deviceStatus";
	private static final String SIM_CONFIRMATION = "simConfirmation";
	
	/**
	 * <p>
	 * Populates a list with all the multi-options
	 * </p>
	 */
	@PostConstruct
	private void initModel() {
		switch(flowType) 
        { 
            case DEVICE_TYPE: 
            	this.options = deviceType; 
                break; 
            case DEVICE_STATUS: 
            	this.options = deviceStatus;
                break; 
            case SIM_CONFIRMATION: 
            	this.options = simConfirmation;
                break;
            default:
            	this.options = Collections.emptyList();
        }
	}
		
	/**
     * @return String - exported Type
     */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
	/**
     * @return String - flowType
     */
	@Override
	public String getFlowType() {
		return flowType;
	}
	
	/**
     * @return String - heading
     */
	@Override
	public String getHeading() {
		return heading;
	}
	
	/**
     * @return String - subheading
     */
	@Override
	public String getSubheading() {
		return subheading;
	}

	/**
	 * @return the options
	 */
	@Override
	public List<CtaWithRadioOptionsModel> getOptions() {		
		return new ArrayList<>(options);
	}

}
