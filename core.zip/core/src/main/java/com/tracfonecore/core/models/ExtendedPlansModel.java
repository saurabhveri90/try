/**
 *  Copyright 2020 HCL Technologies Ltd. 
 */
package com.tracfonecore.core.models;


import com.adobe.cq.export.json.ComponentExporter;

/**
 * Defines the {@code New Line} Sling Model used for the {@code /apps/tracfone-core/components/commerce/extendedplans} component.
 */
public interface ExtendedPlansModel extends ComponentExporter {

	/**
	 * <p> Returns apiDomain from configuration</p>
	 * 
	  * @return String - apiDomain
	 */
	String getApiDomain();

	/**
	 * String is used for category API call
	 * 
	  * @return String - queryString
	 */
	String getQueryString();

	/**
	 *  <p>Returns categoryApiPath from configuration</p>
	 *  
	  * @return String - categoryApiPath
	 */
	String getExtendedPlansApiPath();

	/**
	 * <p>
	 * Returns language from util
	 * </p>
	 * 
	 * @return String - language
	 */
	String getLanguage();

	/**
	 * @return brandName
	 */
	String getBrandName();

	/**
	  *  <p>Returns categoryid from the configured Plans category page.</p>
	  *  
	   * @return String - categoryID
	  */
	String getCategoryID();

	/**
	  *  <p>Returns plan pdp json servlet path</p>
	  *  
	   * @return String - planPDPServletPath
	  */
	String getPlanPDPServletPath();

	/**
	 *  <p>Returns disclaimer </p>
	 *
	 * @return String - disclaimer
	 */
	public String getDisclaimer();
}
