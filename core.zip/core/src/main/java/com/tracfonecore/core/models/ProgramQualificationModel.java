package com.tracfonecore.core.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.tracfonecore.core.constants.ApplicationConstants;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ProgramQualificationModel {
    @ValueMapValue(name="serviceKey")
    private String serviceKey;

    @ValueMapValue(name="visibleText")
    private String visibleText;

    @ValueMapValue(name="showAsHighlighted")
    @Default(booleanValues = false)
    private Boolean showAsHighlighted;

    @ValueMapValue(name="applicableStates")
    private String applicableStates;

    @ValueMapValue(name="programType")
    private String programType;

    public String getServiceKey(){
        return  serviceKey;
    }
    public String getVisibleText(){
        return visibleText;
    }

    public Boolean isShowAsHighlighted(){
        return showAsHighlighted;
    }
    public String getApplicableStates(){
        return applicableStates;
    }
    public String getProgramType(){
        return programType;
    }

}
