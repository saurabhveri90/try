package com.tracfonecore.core.beans;

public class TestimonialBean {
    private String image;
    private String altText;
    private String feedback;
    private String name;
    private String location;
    private Float delay;

    /**
     * <p>Fetches image of the testimonial</p>
     *
     * @return String - image of the testimonial
     */
    public String getImage() {
        return image;
    }

    /**
     * <p>Sets image of the testimonial</p>
     *
     * @param image - image of the testimonial
     */
    public void setImage(String image) {
        this.image = image;
    }

    /**
     * <p>Fetches alt text of image</p>
     *
     * @return String - alt text of image
     */
    public String getAltText() {
        return altText;
    }

    /**
     * <p>Sets alt text of image</p>
     *
     * @param altText - alt text of image
     */
    public void setAltText(String altText) {
        this.altText = altText;
    }

    /**
     * <p>Fetches feedback of the testimonial</p>
     *
     * @return String - feedback of the testimonial
     */
    public String getFeedback() {
        return feedback;
    }

    /**
     * <p>Sets feedback of the testimonial</p>
     *
     * @param feedback - feedback of the testimonial
     */
    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    /**
     * <p>Fetches name of the testimonial</p>
     *
     * @return String - name of the testimonial
     */
    public String getName() {
        return name;
    }

    /**
     * <p>Sets name of the testimonial</p>
     *
     * @param name - name of the testimonial
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * <p>Fetches location of the testimonial</p>
     *
     * @return String - location of the testimonial
     */
    public String getLocation() {
        return location;
    }

    /**
     * <p>Sets location of the testimonial</p>
     *
     * @param location - location of the testimonial
     */
    public void setLocation(String location) {
        this.location = location;
    }

    /**
     * <p>Fetches delay of the testimonial</p>
     *
     * @return String - delay of the testimonial
     */
    public Float getDelay() {
        return delay;
    }

    /**
     * <p>Sets delay of the testimonial</p>
     *
     * @param delay - delay of the testimonial
     */
    public void setDelay(Float delay) {
        this.delay = delay;
    }
}
