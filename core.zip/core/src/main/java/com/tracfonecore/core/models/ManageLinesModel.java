package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.DeEnrollmentReasonsBean;
import com.tracfonecore.core.beans.ManageLinesBean;
import com.tracfonecore.core.beans.ManageLinesNotificationsBean;

public interface ManageLinesModel extends ComponentExporter {

	@JsonProperty("positionManageLines")
	public String getPositionManageLines();

	@JsonProperty("positionAccountNavigation")
	public String getPositionAccountNavigation();

	@JsonProperty("legalCopyTextForManageLines")
	public String getLegalCopyTextForManageLines();

	@JsonProperty("newDeviceOptionsSubHeading")
	public String getNewDeviceOptionsSubHeading();
	@JsonProperty("attemptsToSendVerificationCode")
	public String getAttemptsToSendVerificationCode();

	@JsonProperty("addMergeLineOptionsHeading")
	public String getAddMergeLineOptionsHeading();

	@JsonProperty("addMergeLineOptionsSubHeading")
	public String getAddMergeLineOptionsSubHeading();

	@JsonProperty("addNewLineOptionsHeading")
	public String getAddNewLineOptionsHeading();

	@JsonProperty("addNewLineOptionsSubHeading")
	public String getAddNewLineOptionsSubHeading();

	@JsonProperty("addNewDeviceOptionsSubHeading")
	public String getAddNewDeviceOptionsSubHeading();

	@JsonProperty("mergeLineStep1Heading")
	public String getMergeLineStep1Heading();

	@JsonProperty("mergeLineStep1Subheading")
	public String getMergeLineStep1Subheading();

	@JsonProperty("mergeLineStep2Heading")
	public String getMergeLineStep2Heading();

	@JsonProperty("mergeLineStep2Subheading")
	public String getMergeLineStep2Subheading();

	@JsonProperty("resendCodeLinkLabel")
	public String getResendCodeLinkLabel();

	@JsonProperty("firstAttemptSendCodeMessage")
	public String getFirstAttemptSendCodeMessage();

	@JsonProperty("secondAttemptSendCodeMessage")
	public String getSecondAttemptSendCodeMessage();

	@JsonProperty("addMergeLineSuccessHeading")
	public String getAddMergeLineSuccessHeading();

	@JsonProperty("addMergeLineSuccessSubheading")
	public String getAddMergeLineSuccessSubheading();

	@JsonProperty("planInReserveHeading")
	public String getPlanInReserveHeading();

	@JsonProperty("planInReserveSubheading")
	public String getPlanInReserveSubheading();

	@JsonProperty("nextPlanStartDateHeading")
	public String getNextPlanStartDateHeading();

	@JsonProperty("redeemPlanModalHeadline")
	public String getRedeemPlanModalHeadline();

	@JsonProperty("redeemPlanModalSubheadline")
	public String getRedeemPlanModalSubheadline();

	@JsonProperty("removeDeviceModalHeadline")
	public String getRemoveDeviceModalHeadline();

	@JsonProperty("removeDeviceModalSubheadline")
	public String getRemoveDeviceModalSubheadline();

	@JsonProperty("editNickNameModalHeadline")
	public String getEditNickNameModalHeadline();

	@JsonProperty("editNickNameModalSubheadline")
	public String getEditNickNameModalSubheadline();

	@JsonProperty("categoryIdPlans")
	public String getCategoryIdPlans();

	@JsonProperty("addOnPlanCardInfoText")
	public String getAddOnPlanCardInfoText();

	@JsonProperty("addOnPlanPartNumber")
	public String getAddOnPlanPartNumber();

	@JsonProperty("addOnPlanName")
	public String getAddOnPlanName();

	@JsonProperty("addOnPlanData")
	public String getAddOnPlanData();

	@JsonProperty("addOnPlanDataLabel")
	public String getAddOnPlanDataLabel();

	@JsonProperty("addOnPlanPrice")
	public String getAddOnPlanPrice();

	@JsonProperty("addOnPlanImage")
	public String getAddOnPlanImage();

	@JsonProperty("addOnPlanImageAssetId")
	public String getAddOnPlanImageAssetId();

	@JsonProperty("addOnPlanImageAssetAgencyId")
	public String getAddOnPlanImageAssetAgencyId();

	@JsonProperty("planAutoRefillDefaultMessage")
	public String getPlanAutoRefillDefaultMessage();

	@JsonProperty("plansPlpPagePath")
	public String getPlansPlpPagePath();

	@JsonProperty("addOnILDText")
	public String getAddOnILDText();

	@JsonProperty("ildPlanName")
	public String getIldPlanName();

	@JsonProperty("ildPlanPrice")
	public String getIldPlanPrice();

	@JsonProperty("ildPlanPartNumber")
	public String getIldPlanPartNumber();

	@JsonProperty("ildPlanEditCartUrl")
	public String getIldPlanEditCartUrl();

	@JsonProperty("planDetailsEditCartUrl")
	public String getPlanDetailsEditCartUrl();

	@JsonProperty("nextChargeDateILDText")
	public String getNextChargeDateILDText();

	@JsonProperty("nextChargeDateILDValue")
	public String getNextChargeDateILDValue();

	@JsonProperty("titleRefillWithPinForILD")
	public String getTitleRefillWithPinForILD();

	@JsonProperty("paragraphRefillWithPinForILD")
	public String getParagraphRefillWithPinForILD();

	@JsonProperty("titleRefillWithPinForPlan")
	public String getTitleRefillWithPinForPlan();

	@JsonProperty("paragraphRefillWithPinForPlan")
	public String getParagraphRefillWithPinForPlan();

	@JsonProperty("titleCancelEnrollmentForPlan")
	public String getTitleCancelEnrollmentForPlan();

	@JsonProperty("paragraphCancelEnrollmentForPlan")
	public String getParagraphCancelEnrollmentForPlan();

	@JsonProperty("titleCusgDiscountAlert")
	public String getTitleCusgDiscountAlert();

	@JsonProperty("paragraphCusgDiscountAlert")
	public String getParagraphCusgDiscountAlert();

	@JsonProperty("titleCancelEnrollmentForILD")
	public String getTitleCancelEnrollmentForILD();

	@JsonProperty("paragraphCancelEnrollmentForILD")
	public String getParagraphCancelEnrollmentForILD();

	@JsonProperty("tutorialsPagePath")
	public String getTutorialsPagePath();

	@JsonProperty("transactionsPagePath")
	public String getTransactionsPagePath();

	@JsonProperty("activationPagePath")
	public String getActivationPagePath();

	@JsonProperty("deviceSupportPage")
	public String getDeviceSupportPage();

	@JsonProperty("transactionHistoryDays")
	public String getTransactionHistoryDays();

	@JsonProperty("numberOfItemsOnSinglePage")
	public String getNumberOfItemsOnSinglePage();

	@JsonProperty("numberOfPageDisplayed")
	public String getNumberOfPageDisplayed();

	@JsonProperty("hppEligibilityConfigDays")
	public String getHppEligibilityConfigDays();

	@JsonProperty("hppClaimsPage")
	public String getHppClaimsPage();

	@JsonProperty("hppClaimsPageAsurion")
	public String getHppClaimsPageAsurion();

	@JsonProperty("hppClaimsPageApple")
	public String getHppClaimsPageApple();

	@JsonProperty("hppNotEnrolledHeadline")
	public String getHppNotEnrolledHeadline();

	@JsonProperty("hppNotEnrolledStatus")
	public String getHppNotEnrolledStatus();

	@JsonProperty("titleCancelEnrollmentForHPP")
	public String getTitleCancelEnrollmentForHPP();

	@JsonProperty("paragraphCancelEnrollmentForHPP")
	public String getParagraphCancelEnrollmentForHPP();

	@JsonProperty("titleCancelEnrollmentSuccessForHPP")
	public String getTitleCancelEnrollmentSuccessForHPP();

	@JsonProperty("paragraphCancelEnrollmentSuccessForHPP")
	public String getParagraphCancelEnrollmentSuccessForHPP();

	@JsonProperty("textHowDoesItWorkModal")
	public String getTextHowDoesItWorkModal();

	@JsonProperty("addMergeLineOptions")
	public List<ManageLinesBean> getAddMergeLineOptions();

	@JsonProperty("addNewLineOptions")
	public List<ManageLinesBean> getAddNewLineOptions();

	@JsonProperty("addNewDeviceOptions")
	public List<ManageLinesBean> getAddNewDeviceOptions();

	@JsonProperty("planAutoRefillMessageMapping")
	public List<ManageLinesBean> getPlanAutoRefillMessageMapping();

	@JsonProperty("notificationCards")
	public List<ManageLinesNotificationsBean> getNotificationCards();

	@JsonProperty("statusPendingTransactionList")
	public List<ManageLinesBean> getStatusPendingTransactionList();

	@JsonProperty("plpPagePathHpp")
	public String getPlpPagePathHpp();

	@JsonProperty("titleBenefitChangesModalForILD")
	public String getTitleBenefitChangesModalForILD();

	@JsonProperty("subTitleBenefitChangesModalForILD")
	public String getSubTitleBenefitChangesModalForILD();

	@JsonProperty("titleBenefitChangesModalForPlan")
	public String getTitleBenefitChangesModalForPlan();

	@JsonProperty("subTitleBenefitChangesModalForPlan")
	public String getSubTitleBenefitChangesModalForPlan();

	@JsonProperty("titleBenefitChangesModalForReservePlans")
	public String getTitleBenefitChangesModalForReservePlans();

	@JsonProperty("subTitleBenefitChangesModalForReservePlans")
	public String getSubTitleBenefitChangesModalForReservePlans();

	@JsonProperty("benefitChangeOptionsForPlan")
	public List<ManageLinesBean> getBenefitChangeOptionsForPlan();

	@JsonProperty("benefitChangeOptionsForILD")
	public List<ManageLinesBean> getBenefitChangeOptionsForILD();

	@JsonProperty("benefitChangeOptionsForReservePlans")
	public List<ManageLinesBean> getBenefitChangeOptionsForReservePlans();

	@JsonProperty("refillLandingPagePath")
	public String getRefillLandingPagePath();

	@JsonProperty("autoRefillHomePagePath")
	public String getAutoRefillHomePagePath();

	@JsonProperty("refillPLPPagePath")
	public String getRefillPLPPagePath();

	@JsonProperty("refillPLPPageSelector")
	public String getRefillPLPPageSelector();

	@JsonProperty("refillStartDateSelector")
	public String getRefillStartDateSelector();

	@JsonProperty("phonesPLPPagePath")
	public String getPhonesPLPPagePath();

	@JsonProperty("refillBuyNowPLPPageSelector")
	public String getRefillBuyNowPLPPageSelector();

	@JsonProperty("checkoutDetailComponentVersion")
	public String getCheckoutDetailComponentVersion();

	@JsonProperty("planServiceEndDateInfoModalContent")
	public String getPlanServiceEndDateInfoModalContent();

	@JsonProperty("zipCodeUnderlyingText")
	public String getZipCodeUnderlyingText();

	@JsonProperty("amazonEnrollmentInfoModalContent")
	public String getAmazonEnrollmentInfoModalContent();

	@JsonProperty("titleCancelEnrollmentAndRefundModal")
	public String getTitleCancelEnrollmentAndRefundModal();

	@JsonProperty("paragraphCancelEnrollmentAndRefundModal")
	public String getParagraphCancelEnrollmentAndRefundModal();

	@JsonProperty("addOnPlanEditCartUrl")
	public String getAddOnPlanEditCartUrl();

	@JsonProperty("enableAmazonPrime")
	public Boolean getEnableAmazonPrime();

	@JsonProperty("showWelcomeCenterForDesktop")
	public Boolean getShowWelcomeCenterForDesktop();

	@JsonProperty("hideWelcomeCenter")
	public Boolean getHideWelcomeCenter();

	@JsonProperty("welcomeCenterHeading")
	public String getWelcomeCenterHeading();

	@JsonProperty("welcomeCenterDescription")
	public String getWelcomeCenterDescription();

	@JsonProperty("visitWelcomeCenterButton")
	public String getVisitWelcomeCenterButton();

	@JsonProperty("visitWelcomeCenterButtonLink")
	public String getVisitWelcomeCenterButtonLink();

	@JsonProperty("openVisitLinkNewTabWindow")
	public String getOpenVisitLinkNewTabWindow();

	@JsonProperty("welcomeCenterImagePath")
	public String getWelcomeCenterImagePath();

	@JsonProperty("activationDateDifference")
	public String getActivationDateDifference();

	@JsonProperty("welcomeCenterPartClasses")
	public String[] getWelcomeCenterPartClasses();

	@JsonProperty("selectAutoRefillAndSaveMessage")
	public String getSelectAutoRefillAndSaveMessage();

	@JsonProperty("categoryIdHpp")
	public String getCategoryIdHpp();

	@JsonProperty("editGroupNameModalHeadline")
	public String getEditGroupNameModalHeadline();

	@JsonProperty("editGroupNameModalSubheadline")
	public String getEditGroupNameModalSubheadline();

	@JsonProperty("temporaryProtectionPlanScript")
	public String getTemporaryProtectionPlanScript();

	@JsonProperty("deEnrollmentReasons")
	public List<DeEnrollmentReasonsBean> getDeEnrollmentReasons();

	@JsonProperty("globalCallingCardPDPPagePath")
	public String getGlobalCallingCardPDPPagePath();

	@JsonProperty("plansPageAddOnSection")
	public String getPlansPageAddOnSection();

	@JsonProperty("enablePageLevel2FA")
	public String getEnablePageLevel2FA();

	@JsonProperty("enableFccLabel")
	public Boolean getEnableFccLabel();

	@JsonProperty("newTabWindowForFccLabelLink")
	public Boolean getNewTabWindowForFccLabelLink();

	@JsonProperty("enableAddlineForDODevices")
	public String getEnableAddlineForDODevices();

	@JsonProperty("byopPinModal")
	public String getByopPinModal();

	@JsonProperty("byopRedeemPlanHeadline")
	public String getByopRedeemPlanHeadline();

	@JsonProperty("byopRedeemPlanSubHeadline")
	public String getByopRedeemPlanSubHeadline();

	@JsonProperty("byopPinModalDcot")
	public String getByopPinModalDcot();

	@JsonProperty("byopRedeemPlanHeadlineDcot")
	public String getByopRedeemPlanHeadlineDcot();

	@JsonProperty("byopRedeemPlanSubHeadlineDcot")
	public String getByopRedeemPlanSubHeadlineDcot();

	@JsonProperty("restartYourPhoneText")
	public String getRestartYourPhoneText();

	@JsonProperty("videoStreamingText")
	public String getVideoStreamingText();

	@JsonProperty("partNumberToogle")
	public String getPartNumberToogle();
}