package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Header} Sling Model used for the {@code /apps/tracfone-core/components/spa/content/appdownload} component.
 */
public interface AppDownloadSpaModel extends ComponentExporter {

    @JsonProperty("componentVersion")
    public String getComponentVersion();

    /**
     * <p>Fetches headlineText for AppDownload Component</p>
     *
     * @return String - headlineText for AppDownload Component
     */
    @JsonProperty("headlineText")
    public String getHeadlineText();

    /**
     * <p>Fetches subHeadlineText for AppDownload Component</p>
     *
     * @return String - subHeadlineText for AppDownload Component
     */
    @JsonProperty("subHeadlineText")
    public String getSubHeadlineText();

    /**
     * <p>Fetches appstoreFile for AppDownload Component</p>
     *
     * @return String - appstoreFile for AppDownload Component
     */
    @JsonProperty("appstoreFileReference")
    public String getAppstoreFileReference();

    /**
     * <p>Fetches appstore for AppDownload Component</p>
     *
     * @return String - appstore for AppDownload Component
     */
    @JsonProperty("appstore")
    public String getAppstore();

    /**
     * <p>Fetches appStoreNewWindow for AppDownload Component</p>
     *
     * @return String - appStoreNewWindow for AppDownload Component
     */
    @JsonProperty("appStoreNewWindow")
    public String getAppStoreNewWindow();

    /**
     * <p>Fetches appstorealttext for AppDownload Component</p>
     *
     * @return String - appstorealttext for AppDownload Component
     */
    @JsonProperty("appstorealttext")
    public String getAppstorealttext();

    /**
     * <p>Fetches donotfollowappstore for AppDownload Component</p>
     *
     * @return String - donotfollowappstore for AppDownload Component
     */
    @JsonProperty("donotfollowappstore")
    public String getDonotfollowappstore();

    /**
     * <p>Fetches playstorefile for AppDownload Component</p>
     *
     * @return String - playstorefile for AppDownload Component
     */
    @JsonProperty("playstoreFileReference")
    public String getPlaystoreFileReference();

    /**
     * <p>Fetches playstore for AppDownload Component</p>
     *
     * @return String - playstore for AppDownload Component
     */
    @JsonProperty("playstore")
    public String getPlaystore();

    /**
     * <p>Fetches playStoreNewWindow for AppDownload Component</p>
     *
     * @return String - playStoreNewWindow for AppDownload Component
     */
    @JsonProperty("playStoreNewWindow")
    public String getPlayStoreNewWindow();

    /**
     * <p>Fetches playstorealttext for AppDownload Component</p>
     *
     * @return String - playstorealttext for AppDownload Component
     */
    @JsonProperty("playstorealttext")
    public String getPlaystorealttext();

    /**
     * <p>Fetches donotfollowplaystore for AppDownload Component</p>
     *
     * @return String - donotfollowplaystore for AppDownload Component
     */
    @JsonProperty("donotfollowplaystore")
    public String getDonotfollowplaystore();

}
