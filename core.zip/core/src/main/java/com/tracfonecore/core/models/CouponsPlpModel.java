/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * Defines the {@code Multi-Links} Sling Model used for the {@code /apps/tracfone-core/components/spa/commerce/couponsplp} component.
 */
public interface CouponsPlpModel extends ComponentExporter {
	
	
	/**
	 * <p>Fetches headerTitle for CouponsPlp Component</p>
	 * 
	 * @return String - headerTitle for CouponsPlp Component
	 */
	@JsonProperty("headerTitle")
	public String getHeaderTitle();
	
	/**
	 * <p>Fetches plpHeading for CouponsPlp Component</p>
	 * 
	 * @return String - plpHeading for CouponsPlp Component
	 */
	@JsonProperty("plpHeading")
	public String getPlpHeading();
	
	/**
	 * <p>Fetches availablePointsText for CouponsPlp Component</p>
	 * 
	 * @return String - availablePointsText for CouponsPlp Component
	 */
	@JsonProperty("availablePointsText")
	public String getAvailablePointsText();
	
	/**
	 * <p>Fetches firstCtaLink for CouponsPlp Component</p>
	 * 
	 * @return String - firstCtaLink for CouponsPlp Component
	 */
	@JsonProperty("firstCtaLink")
	public String getFirstCtaLink();
	
	/**
	 * <p>Fetches firstCtaLabel for CouponsPlp Component</p>
	 * 
	 * @return String - firstCtaLabel for CouponsPlp Component
	 */
	@JsonProperty("firstCtaLabel")
	public String getfirstCtaLabel();
	
	/**
	 * <p>First CTA link target value for CouponsPlp Component.</p>
	 *
	 * @return String - firstCtaNewWindow for CouponsPlp Component.
	 */
	@JsonProperty("firstCtaNewWindow")
	public String getFirstCtaNewWindow();
	
	/**
	 * <p>Fetches secondCtaLink for CouponsPlp Component</p>
	 * 
	 * @return String - secondCtaLink for CouponsPlp Component
	 */
	@JsonProperty("secondCtaLink")
	public String getSecondCtaLink();
	
	/**
	 * <p>Fetches secondCtaLabel for CouponsPlp Component</p>
	 * 
	 * @return String - secondCtaLabel for CouponsPlp Component
	 */
	@JsonProperty("secondCtaLabel")
	public String getSecondCtaLabel();
	
	/**
	 * <p>Second CTA link target value for CouponsPlp Component.</p>
	 *
	 * @return String - secondCtaNewWindow for CouponsPlp Component.
	 */
	@JsonProperty("secondCtaNewWindow")
	public String getSecondCtaNewWindow();
}
