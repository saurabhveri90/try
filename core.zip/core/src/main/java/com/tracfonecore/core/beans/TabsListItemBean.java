package com.tracfonecore.core.beans;

public class TabsListItemBean {
    private String title;
    private String accessibilityLabel;
    private String name;

    /**
     * <p>Fetches title of the Tabs item</p>
     *
     * @return String - title of the Tabs item
     */
    public String getTitle() {
        return title;
    }

    /**
     * <p>Sets title of the Tabs item</p>
     *
     * @param title - title of the Tabs item
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * <p>Fetches accessibilityLabel of the Tabs item</p>
     *
     * @return String - accessibilityLabel of the Tabs item
     */
    public String getAccessibilityLabel() {
        return accessibilityLabel;
    }

    /**
     * <p>Sets accessibilityLabel of the Tabs item</p>
     *
     * @param accessibilityLabel - accessibilityLabel of the Tabs item
     */
    public void setAccessibilityLabel(String accessibilityLabel) {
        this.accessibilityLabel = accessibilityLabel;
    }

    /**
     * <p>Fetches name of the Tabs item</p>
     *
     * @return String - name of the Tabs item
     */
    public String getName() {
        return name;
    }

    /**
     * <p>Sets name of the Tabs item</p>
     *
     * @param name - name of the Tabs item
     */
    public void setName(String name) {
        this.name = name;
    }
}
