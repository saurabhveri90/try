/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;

/**
 * <p>Defines bean to hold </p>manage lines options
 */
/**
 * @author saurabh_kumar1
 *
 */
public class ManageLinesBean {

    private String addMergeLineOptionName;
	private String addMergeLineOptionLabel;
	private String addNewLineOptionName;
	private String addNewLineOptionLabel;
	private String addNewLineOptionRedirectPagePath;
	private String addNewDeviceOptionName;
	private String addNewDeviceOptionLabel;
	private String addNewDeviceOptionRedirectPagePath;
	private String planPartNumber;
	private String autoRefillMessage;
	private String transactionStatus;
	private String transactionStatusValue;
	private String phoneNumberStatusValue;
	private String benefitChangeOption;
	
	public String getAddMergeLineOptionName() {
		return addMergeLineOptionName;
	}
	public void setAddMergeLineOptionName(String addMergeLineOptionName) {
		this.addMergeLineOptionName = addMergeLineOptionName;
	}
	public String getAddMergeLineOptionLabel() {
		return addMergeLineOptionLabel;
	}
	public void setAddMergeLineOptionLabel(String addMergeLineOptionLabel) {
		this.addMergeLineOptionLabel = addMergeLineOptionLabel;
	}
	public String getAddNewLineOptionName() {
		return addNewLineOptionName;
	}
	public void setAddNewLineOptionName(String addNewLineOptionName) {
		this.addNewLineOptionName = addNewLineOptionName;
	}
	public String getAddNewLineOptionLabel() {
		return addNewLineOptionLabel;
	}
	public void setAddNewLineOptionLabel(String addNewLineOptionLabel) {
		this.addNewLineOptionLabel = addNewLineOptionLabel;
	}
	public String getAddNewLineOptionRedirectPagePath() {
		return addNewLineOptionRedirectPagePath;
	}
	public void setAddNewLineOptionRedirectPagePath(String addNewLineOptionRedirectPagePath) {
		this.addNewLineOptionRedirectPagePath = addNewLineOptionRedirectPagePath;
	}

	public String getAddNewDeviceOptionName() {
		return addNewDeviceOptionName;
	}

	public void setAddNewDeviceOptionName(String addNewDeviceOptionName) {
		this.addNewDeviceOptionName = addNewDeviceOptionName;
	}

	public String getAddNewDeviceOptionLabel() {
		return addNewDeviceOptionLabel;
	}

	public void setAddNewDeviceOptionLabel(String addNewDeviceOptionLabel) {
		this.addNewDeviceOptionLabel = addNewDeviceOptionLabel;
	}

	public String getAddNewDeviceOptionRedirectPagePath() {
		return addNewDeviceOptionRedirectPagePath;
	}

	public void setAddNewDeviceOptionRedirectPagePath(String addNewDeviceOptionRedirectPagePath) {
		this.addNewDeviceOptionRedirectPagePath = addNewDeviceOptionRedirectPagePath;
	}

	public String getPlanPartNumber() {
		return planPartNumber;
	}
	public void setPlanPartNumber(String planPartNumber) {
		this.planPartNumber = planPartNumber;
	}
	public String getAutoRefillMessage() {
		return autoRefillMessage;
	}
	public void setAutoRefillMessage(String autoRefillMessage) {
		this.autoRefillMessage = autoRefillMessage;
	}
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	public String getTransactionStatusValue() {
		return transactionStatusValue;
	}
	public void setTransactionStatusValue(String transactionStatusValue) {
		this.transactionStatusValue = transactionStatusValue;
	}
	public String getPhoneNumberStatusValue() {
		return phoneNumberStatusValue;
	}
	public void setPhoneNumberStatusValue(String phoneNumberStatusValue) {
		this.phoneNumberStatusValue = phoneNumberStatusValue;
	}
	public String getBenefitChangeOption() {
		return benefitChangeOption;
	}
	public void setBenefitChangeOption(String benefitChangeOption) {
		this.benefitChangeOption = benefitChangeOption;
	}
}
