/*
 *  Copyright 2022 SUNERA Technologies PVT Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Multi-Links} Sling Model used for the
 * {@code tracfone-core/components/spa/commerce/fixedWireless} component.
 */
public interface HomeInternetModel extends ComponentExporter {

	/**
	 * <p>
	 * Fetches brandLogo
	 * </p>
	 * 
	 * @return String - brandLogo
	 */
	@JsonProperty("brandLogo")
	public String getBrandLogo();

	/**
	 * <p>
	 * Fetches brandLogoAltText
	 * </p>
	 * 
	 * @return String - brandLogoAltText
	 */
	@JsonProperty("brandLogoAltText")
	public String getBrandLogoAltText();

	/**
	 * <p>
	 * Fetches headerTitle for homeinternet
	 * </p>
	 * 
	 * @return String - headerTitle for homeinternet
	 */
	@JsonProperty("headerTitle")
	public String getHeaderTitle();

	/**
	 * <p>
	 * Fetches landingScreenTitle for homeinternet
	 * </p>
	 * 
	 * @return String - landingScreenTitle for homeinternet
	 */
	@JsonProperty("landingScreenTitle")
	public String getLandingScreenTitle();

	/**
	 * <p>
	 * Fetches landingScreenSummary for homeinternet
	 * </p>
	 * 
	 * @return String - landingScreenSummary for homeinternet
	 */
	@JsonProperty("landingScreenSummary")
	public String getLandingScreenSummary();

	/**
	 * <p>
	 * Fetches landingScreenLogo for homeinternet
	 * </p>
	 * 
	 * @return String - landingScreenLogo for homeinternet
	 */
	@JsonProperty("landingScreenLogo")
	public String getLandingScreenLogo();

	/**
	 * <p>
	 * Fetches landingLogoAltText for homeinternet
	 * </p>
	 * 
	 * @return String - landingLogoAltText for homeinternet
	 */
	@JsonProperty("landingLogoAltText")
	public String getLandingLogoAltText();

	/**
	 * <p>
	 * Fetches pnpText for homeinternet
	 * </p>
	 * 
	 * @return String - pnpText for homeinternet
	 */
	@JsonProperty("pnpText")
	public String getPnpText();

	/**
	 * <p>
	 * Fetches helpText for homeinternet
	 * </p>
	 * 
	 * @return String - helpText for homeinternet
	 */
	@JsonProperty("helpText")
	public String getHelpText();

	/**
	 * <p>
	 * Fetches helpDescription for homeinternet
	 * </p>
	 * 
	 * @return String - helpDescription for homeinternet
	 */
	@JsonProperty("helpDescription")
	public String getHelpDescription();

	/**
	 * <p>
	 * Fetches checkAvailabilityBtnTxt for homeinternet
	 * </p>
	 * 
	 * @return String - checkAvailabilityBtnTxt for homeinternet
	 */
	@JsonProperty("checkAvailabilityBtnTxt")
	public String getCheckAvailabilityBtnTxt();

	/**
	 * <p>
	 * Fetches whatsNxtHeaderTitle for homeinternet
	 * </p>
	 * 
	 * @return String - whatsNxtHeaderTitle for homeinternet
	 */
	@JsonProperty("whatsNxtHeaderTitle")
	public String getWhatsNxtHeaderTitle();

	/**
	 * <p>
	 * Fetches whatsNxtSummary for homeinternet
	 * </p>
	 * 
	 * @return String - whatsNxtSummary for homeinternet
	 */
	@JsonProperty("whatsNxtSummary")
	public String getWhatsNxtSummary();

	/**
	 * <p>
	 * Fetches firstLogo for homeinternet
	 * </p>
	 * 
	 * @return String - firstLogo for homeinternet
	 */
	@JsonProperty("firstLogo")
	public String getFirstLogo();

	/**
	 * <p>
	 * Fetches firstLogoAltText for homeinternet
	 * </p>
	 * 
	 * @return String - firstLogoAltText for homeinternet
	 */
	@JsonProperty("firstLogoAltText")
	public String getFirstLogoAltText();

	/**
	 * <p>
	 * Fetches secondLogo for homeinternet
	 * </p>
	 * 
	 * @return String - secondLogo for homeinternet
	 */
	@JsonProperty("secondLogo")
	public String getSecondLogo();

	/**
	 * <p>
	 * Fetches secondLogoAltText for homeinternet
	 * </p>
	 * 
	 * @return String - secondLogoAltText for homeinternet
	 */
	@JsonProperty("secondLogoAltText")
	public String getSecondLogoAltText();

	/**
	 * <p>
	 * Fetches whatsNxtInstructionsText for homeinternet
	 * </p>
	 * 
	 * @return String - whatsNxtInstructionsText for homeinternet
	 */
	@JsonProperty("whatsNxtInstructionsText")
	public String getWhatsNxtInstructionsText();

	/**
	 * <p>
	 * Fetches whatsNxtCtnBtnTxt for homeinternet
	 * </p>
	 * 
	 * @return String - whatsNxtCtnBtnTxt for homeinternet
	 */
	@JsonProperty("whatsNxtCtnBtnTxt")
	public String getWhatsNxtCtnBtnTxt();

	/**
	 * <p>
	 * Fetches changeAddressLinkLabel for homeinternet
	 * </p>
	 * 
	 * @return String - changeAddressLinkLabel for homeinternet
	 */
	@JsonProperty("changeAddressLinkLabel")
	public String getChangeAddressLinkLabel();

	/**
	 * <p>
	 * Fetches registerHeaderTitle for homeinternet
	 * </p>
	 * 
	 * @return String - registerHeaderTitle for homeinternet
	 */
	@JsonProperty("registerHeaderTitle")
	public String getRegisterHeaderTitle();

	/**
	 * <p>
	 * Fetches blackLineLogo for homeinternet
	 * </p>
	 * 
	 * @return String - blackLineLogo for homeinternet
	 */
	@JsonProperty("blackLineLogo")
	public String getBlackLineLogo();

	/**
	 * <p>
	 * Fetches blackLineLogoAltText for homeinternet
	 * </p>
	 * 
	 * @return String - blackLineLogoAltText for homeinternet
	 */
	@JsonProperty("blackLineLogoAltText")
	public String getBlackLineLogoAltText();

	/**
	 * <p>
	 * Fetches disabledSecondLogo for homeinternet
	 * </p>
	 * 
	 * @return String - disabledSecondLogo for homeinternet
	 */
	@JsonProperty("disabledSecondLogo")
	public String getDisabledSecondLogo();

	/**
	 * <p>
	 * Fetches disabledSecondLogoAltText for homeinternet
	 * </p>
	 * 
	 * @return String - disabledSecondLogoAltText for homeinternet
	 */
	@JsonProperty("disabledSecondLogoAltText")
	public String getDisabledSecondLogoAltText();

	/**
	 * <p>
	 * Fetches registerDescriptionText for homeinternet
	 * </p>
	 * 
	 * @return String - registerDescriptionText for homeinternet
	 */
	@JsonProperty("registerDescriptionText")
	public String getRegisterDescriptionText();

	/**
	 * <p>
	 * Fetches registerBtntxt for homeinternet
	 * </p>
	 * 
	 * @return String - registerBtntxt for homeinternet
	 */
	@JsonProperty("registerBtntxt")
	public String getRegisterBtntxt();

	/**
	 * <p>
	 * Fetches successLogo for homeinternet
	 * </p>
	 * 
	 * @return String - successLogo for homeinternet
	 */
	@JsonProperty("successLogo")
	public String getSuccessLogo();

	/**
	 * <p>
	 * Fetches successLogoAltText for homeinternet
	 * </p>
	 * 
	 * @return String - successLogoAltText for homeinternet
	 */
	@JsonProperty("successLogoAltText")
	public String getSuccessLogoAltText();

	/**
	 * <p>
	 * Fetches greenLineLogo for homeinternet
	 * </p>
	 * 
	 * @return String - greenLineLogo for homeinternet
	 */
	@JsonProperty("greenLineLogo")
	public String getGreenLineLogo();

	/**
	 * <p>
	 * Fetches greenLineLogoAltText for homeinternet
	 * </p>
	 * 
	 * @return String - greenLineLogoAltText for homeinternet
	 */
	@JsonProperty("greenLineLogoAltText")
	public String getGreenLineLogoAltText();

	/**
	 * <p>
	 * Fetches imeiHeaderTitle for homeinternet
	 * </p>
	 * 
	 * @return String - imeiHeaderTitle for homeinternet
	 */
	@JsonProperty("imeiHeaderTitle")
	public String getImeiHeaderTitle();

	/**
	 * <p>
	 * Fetches imeiSummary for homeinternet
	 * </p>
	 * 
	 * @return String - imeiSummary for homeinternet
	 */
	@JsonProperty("imeiSummary")
	public String getImeiSummary();

	/**
	 * <p>
	 * Fetches findImeiLinkTxt for homeinternet
	 * </p>
	 * 
	 * @return String - findImeiLinkTxt for homeinternet
	 */
	@JsonProperty("findImeiLinkTxt")
	public String getFindImeiLinkTxt();

	/**
	 * <p>
	 * Fetches imeiBarcodeLogo for homeinternet
	 * </p>
	 * 
	 * @return String - imeiBarcodeLogo for homeinternet
	 */
	@JsonProperty("imeiBarcodeLogo")
	public String getImeiBarcodeLogo();

	/**
	 * <p>
	 * Fetches imeiBarcodeLogoAltText for homeinternet
	 * </p>
	 * 
	 * @return String - imeiBarcodeLogoAltText for homeinternet
	 */
	@JsonProperty("imeiBarcodeLogoAltText")
	public String getImeiBarcodeLogoAltText();

	/**
	 * <p>
	 * Fetches imeiConfirmDeviceBtntxt for homeinternet
	 * </p>
	 * 
	 * @return String - imeiConfirmDeviceBtntxt for homeinternet
	 */
	@JsonProperty("imeiConfirmDeviceBtntxt")
	public String getImeiConfirmDeviceBtntxt();

	/**
	 * <p>
	 * Fetches imeiErrorTitle for homeinternet
	 * </p>
	 * 
	 * @return String - imeiErrorTitle for homeinternet
	 */
	@JsonProperty("imeiErrorTitle")
	public String getImeiErrorTitle();

	/**
	 * <p>
	 * Fetches imeiErrorDescription for homeinternet
	 * </p>
	 * 
	 * @return String - imeiErrorDescription for homeinternet
	 */
	@JsonProperty("imeiErrorDescription")
	public String getImeiErrorDescription();

	/**
	 * <p>
	 * Fetches congratsHeaderTitle for homeinternet
	 * </p>
	 * 
	 * @return String - congratsHeaderTitle for homeinternet
	 */
	@JsonProperty("congratsHeaderTitle")
	public String getCongratsHeaderTitle();

	/**
	 * <p>
	 * Fetches activateLinkTxt for homeinternet
	 * </p>
	 * 
	 * @return String - activateLinkTxt for homeinternet
	 */
	@JsonProperty("activateLinkTxt")
	public String getActivateLinkTxt();

	/**
	 * <p>
	 * Fetches congratsMsgTitle for homeinternet
	 * </p>
	 * 
	 * @return String - congratsMsgTitle for homeinternet
	 */
	@JsonProperty("congratsMsgTitle")
	public String getCongratsMsgTitle();

	/**
	 * <p>
	 * Fetches congratsMsgSummary for homeinternet
	 * </p>
	 * 
	 * @return String - congratsMsgSummary for homeinternet
	 */
	@JsonProperty("congratsMsgSummary")
	public String getCongratsMsgSummary();

	/**
	 * <p>
	 * Fetches expireLabelTxt for homeinternet
	 * </p>
	 * 
	 * @return String - expireLabelTxt for homeinternet
	 */
	@JsonProperty("expireLabelTxt")
	public String getExpireLabelTxt();

	/**
	 * <p>
	 * Fetches nextStepText for homeinternet
	 * </p>
	 * 
	 * @return String - nextStepText for homeinternet
	 */
	@JsonProperty("nextStepText")
	public String getNextStepText();

	/**
	 * <p>
	 * Fetches calendarLogo for homeinternet
	 * </p>
	 * 
	 * @return String - calendarLogo for homeinternet
	 */
	@JsonProperty("calendarLogo")
	public String getCalendarLogo();

	/**
	 * <p>
	 * Fetches calendarLogoAltText for homeinternet
	 * </p>
	 * 
	 * @return String - calendarLogoAltText for homeinternet
	 */
	@JsonProperty("calendarLogoAltText")
	public String getCalendarLogoAltText();

	/**
	 * <p>
	 * Fetches signupHeaderTitle for homeinternet
	 * </p>
	 * 
	 * @return String - signupHeaderTitle for homeinternet
	 */
	@JsonProperty("signupHeaderTitle")
	public String getSignupHeaderTitle();

	/**
	 * <p>
	 * Fetches signupSummary for homeinternet
	 * </p>
	 * 
	 * @return String - signupSummary for homeinternet
	 */
	@JsonProperty("signupSummary")
	public String getSignupSummary();

	/**
	 * <p>
	 * Fetches locationLogo for homeinternet
	 * </p>
	 * 
	 * @return String - locationLogo for homeinternet
	 */
	@JsonProperty("locationLogo")
	public String getLocationLogo();

	/**
	 * <p>
	 * Fetches locationLogoAltText for homeinternet
	 * </p>
	 * 
	 * @return String - locationLogoAltText for homeinternet
	 */
	@JsonProperty("locationLogoAltText")
	public String getLocationLogoAltText();

	/**
	 * <p>
	 * Fetches signupPnpText for homeinternet
	 * </p>
	 * 
	 * @return String - signupPnpText for homeinternet
	 */
	@JsonProperty("signupPnpText")
	public String getSignupPnpText();

	/**
	 * <p>
	 * Fetches signupBtnLabel for homeinternet
	 * </p>
	 * 
	 * @return String - signupBtnLabel for homeinternet
	 */
	@JsonProperty("signupBtnLabel")
	public String getSignupBtnLabel();

	/**
	 * <p>
	 * Fetches cancelBtnLabel for homeinternet
	 * </p>
	 * 
	 * @return String - cancelBtnLabel for homeinternet
	 */
	@JsonProperty("cancelBtnLabel")
	public String getCancelBtnLabel();

	/**
	 * <p>
	 * Fetches signupThanksHeaderTitle for homeinternet
	 * </p>
	 * 
	 * @return String - signupThanksHeaderTitle for homeinternet
	 */
	@JsonProperty("signupThanksHeaderTitle")
	public String getSignupThanksHeaderTitle();

	/**
	 * <p>
	 * Fetches signupThanksSummary for homeinternet
	 * </p>
	 * 
	 * @return String - signupThanksSummary for homeinternet
	 */
	@JsonProperty("signupThanksSummary")
	public String getSignupThanksSummary();

	/**
	 * <p>
	 * Fetches signupThanksChangeAddressBtnTxt for homeinternet
	 * </p>
	 * 
	 * @return String - signupThanksChangeAddressBtnTxt for homeinternet
	 */
	@JsonProperty("signupThanksChangeAddressBtnTxt")
	public String getSignupThanksChangeAddressBtnTxt();

	/**
	 * <p>
	 * Fetches signupCancelHeaderTitle for homeinternet
	 * </p>
	 * 
	 * @return String - signupCancelHeaderTitle for homeinternet
	 */
	@JsonProperty("signupCancelHeaderTitle")
	public String getSignupCancelHeaderTitle();

	/**
	 * <p>
	 * Fetches signupCancelSummary for homeinternet
	 * </p>
	 * 
	 * @return String - signupCancelSummary for homeinternet
	 */
	@JsonProperty("signupCancelSummary")
	public String getSignupCancelSummary();

	/**
	 * <p>
	 * Fetches signupCancelNote for homeinternet
	 * </p>
	 * 
	 * @return String - signupCancelNote for homeinternet
	 */
	@JsonProperty("signupCancelNote")
	public String getSignupCancelNote();

	/**
	 * <p>
	 * Fetches closebtnText for homeinternet
	 * </p>
	 * 
	 * @return String - closebtnText for homeinternet
	 */
	@JsonProperty("closebtnText")
	public String getClosebtnText();

	/**
	 * <p>
	 * Fetches tobeUsedText for homeinternet
	 * </p>
	 * 
	 * @return String - tobeUsedText for homeinternet
	 */
	@JsonProperty("tobeUsedText")
	public String getTobeUsedText();

	/**
	 * <p>
	 * Fetches nextStep for homeinternet
	 * </p>
	 * 
	 * @return String - nextStep for homeinternet
	 */
	@JsonProperty("nextStep")
	public String getNextStep();

	/**
	 * <p>
	 * Fetches walmartBrandLogo for homeinternet
	 * </p>
	 * 
	 * @return String - walmartBrandLogo for homeinternet
	 */
	@JsonProperty("walmartBrandLogo")
	public String getWalmartBrandLogo();

	/**
	 * <p>
	 * Fetches walmartBrandLogoAltText for homeinternet
	 * </p>
	 * 
	 * @return String - walmartBrandLogoAltText for homeinternet
	 */
	@JsonProperty("walmartBrandLogoAltText")
	public String getWalmartBrandLogoAltText();

	/**
	 * <p>
	 * Fetches walmartWhatsNextTitle for homeinternet
	 * </p>
	 * 
	 * @return String - walmartWhatsNextTitle for homeinternet
	 */
	@JsonProperty("walmartWhatsNextTitle")
	public String getWalmartWhatsNextTitle();

	/**
	 * <p>
	 * Fetches walmartStepOneText for homeinternet
	 * </p>
	 * 
	 * @return String - walmartStepOneText for homeinternet
	 */
	@JsonProperty("walmartStepOneText")
	public String getWalmartStepOneText();

	/**
	 * <p>
	 * Fetches walmartStepTwoText for homeinternet
	 * </p>
	 * 
	 * @return String - walmartStepTwoText for homeinternet
	 */
	@JsonProperty("walmartStepTwoText")
	public String getWalmartStepTwoText();

	/**
	 * <p>
	 * Fetches walmartStepThreeText for homeinternet
	 * </p>
	 * 
	 * @return String - walmartStepThreeText for homeinternet
	 */
	@JsonProperty("walmartStepThreeText")
	public String getWalmartStepThreeText();

	/**
	 * <p>
	 * Fetches walmartSeeDetailsBtnText for homeinternet
	 * </p>
	 * 
	 * @return String - walmartSeeDetailsBtnText for homeinternet
	 */
	@JsonProperty("walmartSeeDetailsBtnText")
	public String getWalmartSeeDetailsBtnText();

	/**
	 * <p>
	 * Fetches walmartStepOneLogo for homeinternet
	 * </p>
	 * 
	 * @return String - walmartStepOneLogo for homeinternet
	 */
	@JsonProperty("walmartStepOneLogo")
	public String getWalmartStepOneLogo();

	/**
	 * <p>
	 * Fetches walmartStepOneLogoAltText for homeinternet
	 * </p>
	 * 
	 * @return String - walmartStepOneLogoAltText for homeinternet
	 */
	@JsonProperty("walmartStepOneLogoAltText")
	public String getWalmartStepOneLogoAltText();

	/**
	 * <p>
	 * Fetches walmartStepTwoLogo for homeinternet
	 * </p>
	 * 
	 * @return String - walmartStepTwoLogo for homeinternet
	 */
	@JsonProperty("walmartStepTwoLogo")
	public String getWalmartStepTwoLogo();

	/**
	 * <p>
	 * Fetches walmartStepTwoLogoAltText for homeinternet
	 * </p>
	 * 
	 * @return String - walmartStepTwoLogoAltText for homeinternet
	 */
	@JsonProperty("walmartStepTwoLogoAltText")
	public String getWalmartStepTwoLogoAltText();

	/**
	 * <p>
	 * Fetches walmartStepThreeLogo for homeinternet
	 * </p>
	 * 
	 * @return String - walmartStepThreeLogo for homeinternet
	 */
	@JsonProperty("walmartStepThreeLogo")
	public String getWalmartStepThreeLogo();

	/**
	 * <p>
	 * Fetches walmartStepThreeLogoAltText for homeinternet
	 * </p>
	 * 
	 * @return String - walmartStepThreeLogoAltText for homeinternet
	 */
	@JsonProperty("walmartStepThreeLogoAltText")
	public String getWalmartStepThreeLogoAltText();

	/**
	 * <p>
	 * Fetches lteDataNotification for homeinternet
	 * </p>
	 * 
	 * @return String - lteDataNotification for homeinternet
	 */
	@JsonProperty("lteDataNotification")
	public String getLteDataNotification();

	/**
	 * <p>
	 * Fetches walmartNoServiceTitle for homeinternet
	 * </p>
	 * 
	 * @return String - walmartNoServiceTitle for homeinternet
	 */
	@JsonProperty("walmartNoServiceTitle")
	public String getWalmartNoServiceTitle();

	/**
	 * <p>
	 * Fetches walmartNoServiceSummary for homeinternet
	 * </p>
	 * 
	 * @return String - walmartNoServiceSummary for homeinternet
	 */
	@JsonProperty("walmartNoServiceSummary")
	public String getWalmartNoServiceSummary();

	/**
	 * <p>
	 * Fetches addressInvalidTitle for homeinternet
	 * </p>
	 * 
	 * @return String - addressInvalidTitle for homeinternet
	 */
	@JsonProperty("addressInvalidTitle")
	public String getAddressInvalidTitle();

	/**
	 * <p>
	 * Fetches addressInvalidSummary for homeinternet
	 * </p>
	 * 
	 * @return String - addressInvalidSummary for homeinternet
	 */
	@JsonProperty("addressInvalidSummary")
	public String getAddressInvalidSummary();

	/**
	 * <p>
	 * Fetches walmartGreyColourLine for homeinternet
	 * </p>
	 * 
	 * @return String - walmartGreyColourLine for homeinternet
	 */
	@JsonProperty("walmartGreyColourLine")
	public String getWalmartGreyColourLine();

	/**
	 * <p>
	 * Fetches walmartGreyColourLineAltText for homeinternet
	 * </p>
	 * 
	 * @return String - walmartGreyColourLineAltText for homeinternet
	 */
	@JsonProperty("walmartGreyColourLineAltText")
	public String getWalmartGreyColourLineAltText();
	
	/**
	 * <p>
	 * Fetches availabilityDescription for homeinternet
	 * </p>
	 * 
	 * @return String - availabilityDescription for homeinternet
	 */
	@JsonProperty("availabilityDescription")
	public String getAvailabilityDescription();

	/**
	 * <p>
	 * Fetches chkAailabilityHeading for homeinternet
	 * </p>
	 * 
	 * @return String - chkAailabilityHeading for homeinternet
	 */
	@JsonProperty("chkAailabilityHeading")
	public String getChkAailabilityHeading();

	/**
	 * <p>
	 * Fetches chkAailabilityDescription for homeinternet
	 * </p>
	 * 
	 * @return String - chkAailabilityDescription for homeinternet
	 */
	@JsonProperty("chkAailabilityDescription")
	public String getChkAailabilityDescription();

	/**
	 * <p>
	 * Fetches formStreetAddressLbl for homeinternet
	 * </p>
	 * 
	 * @return String - formStreetAddressLbl for homeinternet
	 */
	@JsonProperty("formStreetAddressLbl")
	public String getFormStreetAddressLbl();

	/**
	 * <p>
	 * Fetches formAptLbl for homeinternet
	 * </p>
	 * 
	 * @return String - formAptLbl for homeinternet
	 */
	@JsonProperty("formAptLbl")
	public String getFormAptLbl();

	/**
	 * <p>
	 * Fetches formEmailLbl for homeinternet
	 * </p>
	 * 
	 * @return String - formEmailLbl for homeinternet
	 */
	@JsonProperty("formEmailLbl")
	public String getFormEmailLbl();

	/**
	 * <p>
	 * Fetches formEmailNotificationDesc for homeinternet
	 * </p>
	 * 
	 * @return String - formEmailNotificationDesc for homeinternet
	 */
	@JsonProperty("formEmailNotificationDesc")
	public String getFormEmailNotificationDesc();

	/**
	 * <p>
	 * Fetches formPHNoLbl for homeinternet
	 * </p>
	 * 
	 * @return String - formPHNoLbl for homeinternet
	 */
	@JsonProperty("formPHNoLbl")
	public String getFormPHNoLbl();

	/**
	 * <p>
	 * Fetches formFirstNameLbl for homeinternet
	 * </p>
	 * 
	 * @return String - formFirstNameLbl for homeinternet
	 */
	@JsonProperty("formFirstNameLbl")
	public String getFormFirstNameLbl();

	/**
	 * <p>
	 * Fetches formLastNameLbl for homeinternet
	 * </p>
	 * 
	 * @return String - formLastNameLbl for homeinternet
	 */
	@JsonProperty("formLastNameLbl")
	public String getFormLastNameLbl();

	/**
	 * <p>
	 * Fetches formCntBtnLbl for homeinternet
	 * </p>
	 * 
	 * @return String - formCntBtnLbl for homeinternet
	 */
	@JsonProperty("formCntBtnLbl")
	public String getFormCntBtnLbl();

	/**
	 * <p>
	 * Fetches formPrivacyPolicyDesc for homeinternet
	 * </p>
	 * 
	 * @return String - formPrivacyPolicyDesc for homeinternet
	 */
	@JsonProperty("formPrivacyPolicyDesc")
	public String getFormPrivacyPolicyDesc();

	/**
	 * <p>
	 * Fetches serviceAvailablePopupTitle for homeinternet
	 * </p>
	 * 
	 * @return String - serviceAvailablePopupTitle for homeinternet
	 */
	@JsonProperty("serviceAvailablePopupTitle")
	public String getServiceAvailablePopupTitle();

	/**
	 * <p>
	 * Fetches serviceAvailablePopupDesc for homeinternet
	 * </p>
	 * 
	 * @return String - serviceAvailablePopupDesc for homeinternet
	 */
	@JsonProperty("serviceAvailablePopupDesc")
	public String getServiceAvailablePopupDesc();
	
	/**
	 * <p>
	 * Fetches serviceAvailablePopupQuestionLbl for homeinternet
	 * </p>
	 * 
	 * @return String - serviceAvailablePopupQuestionLbl for homeinternet
	 */
	@JsonProperty("serviceAvailablePopupQuestionLbl")
	public String getServiceAvailablePopupQuestionLbl();

	/**
	 * <p>
	 * Fetches serviceAvailablePopupBtnOneLbl for homeinternet
	 * </p>
	 * 
	 * @return String - serviceAvailablePopupBtnOneLbl for homeinternet
	 */
	@JsonProperty("serviceAvailablePopupBtnOneLbl")
	public String getServiceAvailablePopupBtnOneLbl();

	/**
	 * <p>
	 * Fetches serviceAvailablePopupBtnTwoLbl for homeinternet
	 * </p>
	 * 
	 * @return String - serviceAvailablePopupBtnTwoLbl for homeinternet
	 */
	@JsonProperty("serviceAvailablePopupBtnTwoLbl")
	public String getServiceAvailablePopupBtnTwoLbl();

	/**
	 * <p>
	 * Fetches serviceNotAvailablePopupTitle for homeinternet
	 * </p>
	 * 
	 * @return String - serviceNotAvailablePopupTitle for homeinternet
	 */
	@JsonProperty("serviceNotAvailablePopupTitle")
	public String getServiceNotAvailablePopupTitle();

	/**
	 * <p>
	 * Fetches serviceNotAvailablePopupDesc for homeinternet
	 * </p>
	 * 
	 * @return String - serviceNotAvailablePopupDesc for homeinternet
	 */
	@JsonProperty("serviceNotAvailablePopupDesc")
	public String getServiceNotAvailablePopupDesc();

	/**
	 * <p>
	 * Fetches fwaSupportedBrand for homeinternet
	 * </p>
	 * 
	 * @return String - fwaSupportedBrand for homeinternet
	 */
	@JsonProperty("fwaSupportedBrand")
	public String getFwaSupportedBrand();

	/**
	 * <p>
	 * Fetches skipToMainContent for homeinternet
	 * </p>
	 * 
	 * @return String - skipToMainContent for homeinternet
	 */
	@JsonProperty("skipToMainContent")
	public String getSkipToMainContent();

	/**
	 * <p>
	 * Fetches welcomeScreenTitle for homeinternet
	 * </p>
	 * 
	 * @return String - welcomeScreenTitle for homeinternet
	 */
	@JsonProperty("welcomeScreenTitle")
	public String getWelcomeScreenTitle();
	/**
	 * <p>
	 * Fetches welcomeScreenSubTitle for homeinternet
	 * </p>
	 * 
	 * @return String - welcomeScreenSubTitle for homeinternet
	 */
	@JsonProperty("welcomeScreenSubTitle")
	public String getWelcomeScreenSubTitle();
	/**
	 * <p>
	 * Fetches welcomeScreenSubContent for homeinternet
	 * </p>
	 * 
	 * @return String - welcomeScreenSubContent for homeinternet
	 */
	@JsonProperty("welcomeScreenSubContent")
	public String getWelcomeScreenSubContent();
	/**
	 * <p>
	 * Fetches welcomeScreenUnitLabel for homeinternet
	 * </p>
	 * 
	 * @return String - welcomeScreenUnitLabel for homeinternet
	 */
	@JsonProperty("welcomeScreenUnitLabel")
	public String getWelcomeScreenUnitLabel();
	/**
	 * <p>
	 * Fetches welcomeScreenAddressLabel for homeinternet
	 * </p>
	 * 
	 * @return String - welcomeScreenAddressLabel for homeinternet
	 */
	@JsonProperty("welcomeScreenAddressLabel")
	public String getWelcomeScreenAddressLabel();
	/**
	 * <p>
	 * Fetches typeIMEI for homeinternet
	 * </p>
	 * 
	 * @return String - typeIMEI for homeinternet
	 */
	@JsonProperty("typeIMEI")
	public String getTypeIMEI();
	/**
	 * <p>
	 * Fetches activationTitle for homeinternet
	 * </p>
	 * 
	 * @return String - activationTitle for homeinternet
	 */
	@JsonProperty("activationTitle")
	public String getActivationTitle();
	/**
	 * <p>
	 * Fetches activationSubTitle for homeinternet
	 * </p>
	 * 
	 * @return String - activationSubTitle for homeinternet
	 */
	@JsonProperty("activationSubTitle")
	public String getActivationSubTitle();
	/**
	 * <p>
	 * Fetches addCalender for homeinternet
	 * </p>
	 * 
	 * @return String - addCalender for homeinternet
	 */
	@JsonProperty("addCalender")
	public String getAddCalender();
	/**
	 * <p>
	 * Fetches spotText for homeinternet
	 * </p>
	 * 
	 * @return String - spotText for homeinternet
	 */
	@JsonProperty("spotText")
	public String getSpotText();
	/**
	 * <p>
	 * Fetches activateHomeInternetDevice for homeinternet
	 * </p>
	 * 
	 * @return String - activateHomeInternetDevice for homeinternet
	 */
	@JsonProperty("activateHomeInternetDevice")
	public String getActivateHomeInternetDevice();
	/**
	 * <p>
	 * Fetches activateBtnText for homeinternet
	 * </p>
	 * 
	 * @return String - activateBtnText for homeinternet
	 */
	@JsonProperty("activateBtnText")
	public String getActivateBtnText();
	/**
	 * <p>
	 * Fetches imeiFoundText for homeinternet
	 * </p>
	 * 
	 * @return String - imeiFoundText for homeinternet
	 */
	@JsonProperty("imeiFoundText")
	public String getImeiFoundText();
	/**
	 * <p>
	 * Fetches submitIMEI for homeinternet
	 * </p>
	 * 
	 * @return String - submitIMEI for homeinternet
	 */
	@JsonProperty("submitIMEI")
	public String getSubmitIMEI();
	/**
	 * <p>
	 * Fetches reservationConfirmTitle for homeinternet
	 * </p>
	 * 
	 * @return String - reservationConfirmTitle for homeinternet
	 */
	@JsonProperty("reservationConfirmTitle")
	public String getReservationConfirmTitle();
	/**
	 * <p>
	 * Fetches reservationConfirmSubTitle for homeinternet
	 * </p>
	 * 
	 * @return String - reservationConfirmSubTitle for homeinternet
	 */
	@JsonProperty("reservationConfirmSubTitle")
	public String getReservationConfirmSubTitle();
	/**
	 * <p>
	 * Fetches reservationConfirmWhtNext for homeinternet
	 * </p>
	 * 
	 * @return String - reservationConfirmWhtNext for homeinternet
	 */
	@JsonProperty("reservationConfirmWhtNext")
	public String getReservationConfirmWhtNext();
	/**
	 * <p>
	 * Fetches reservationConfirmStep1 for homeinternet
	 * </p>
	 * 
	 * @return String - reservationConfirmStep1 for homeinternet
	 */
	@JsonProperty("reservationConfirmStep1")
	public String getReservationConfirmStep1();
	/**
	 * <p>
	 * Fetches reservationConfirmStep2 for homeinternet
	 * </p>
	 * 
	 * @return String - reservationConfirmStep2 for homeinternet
	 */
	@JsonProperty("reservationConfirmStep2")
	public String getReservationConfirmStep2();
	/**
	 * <p>
	 * Fetches reservationConfirmStep2SubText for homeinternet
	 * </p>
	 * 
	 * @return String - reservationConfirmStep2SubText for homeinternet
	 */
	@JsonProperty("reservationConfirmStep2SubText")
	public String getReservationConfirmStep2SubText();
	/**
	 * <p>
	 * Fetches reservationConfirmStep3 for homeinternet
	 * </p>
	 * 
	 * @return String - reservationConfirmStep3 for homeinternet
	 */
	@JsonProperty("reservationConfirmStep3")
	public String getReservationConfirmStep3();
	/**
	 * <p>
	 * Fetches paidBtnText for homeinternet
	 * </p>
	 * 
	 * @return String - paidBtnText for homeinternet
	 */
	@JsonProperty("paidBtnText")
	public String getPaidBtnText();
	/**
	 * <p>
	 * Fetches serviceConfirmTitle for homeinternet
	 * </p>
	 * 
	 * @return String - serviceConfirmTitle for homeinternet
	 */
	@JsonProperty("serviceConfirmTitle")
	public String getServiceConfirmTitle();
	/**
	 * <p>
	 * Fetches serviceConfirmWhtNext for homeinternet
	 * </p>
	 * 
	 * @return String - serviceConfirmWhtNext for homeinternet
	 */
	@JsonProperty("serviceConfirmWhtNext")
	public String getServiceConfirmWhtNext();
	/**
	 * <p>
	 * Fetches serviceConfirmStep1 for homeinternet
	 * </p>
	 * 
	 * @return String - serviceConfirmStep1 for homeinternet
	 */
	@JsonProperty("serviceConfirmStep1")
	public String getServiceConfirmStep1();
	/**
	 * <p>
	 * Fetches serviceConfirmStep2 for homeinternet
	 * </p>
	 * 
	 * @return String - serviceConfirmStep2 for homeinternet
	 */
	@JsonProperty("serviceConfirmStep2")
	public String getServiceConfirmStep2();
	/**
	 * <p>
	 * Fetches serviceConfirmStep3 for homeinternet
	 * </p>
	 * 
	 * @return String - serviceConfirmStep3 for homeinternet
	 */
	@JsonProperty("serviceConfirmStep3")
	public String getServiceConfirmStep3();
	/**
	 * <p>
	 * Fetches scanBtnText for homeinternet
	 * </p>
	 * 
	 * @return String - scanBtnText for homeinternet
	 */
	@JsonProperty("scanBtnText")
	public String getScanBtnText();
	/**
	 * <p>
	 * Fetches typeYourIMEI for homeinternet
	 * </p>
	 * 
	 * @return String - typeYourIMEI for homeinternet
	 */
	@JsonProperty("typeYourIMEI")
	public String getTypeYourIMEI();
	/**
	 * <p>
	 * Fetches privacyLink for homeinternet
	 * </p>
	 * 
	 * @return String - privacyLink for homeinternet
	 */
	@JsonProperty("privacyLink")
	public String getPrivacyLink();
	/**
	 * <p>
	 * Fetches reservationSet for homeinternet
	 * </p>
	 * 
	 * @return String - reservationSet for homeinternet
	 */
	@JsonProperty("reservationSet")
	public String getReservationSet();
	
	/**
	 * <p>
	 * Fetches activateDevice for homeinternet
	 * </p>
	 * 
	 * @return String - activateDevice for homeinternet
	 */
	@JsonProperty("activateDevice")
	public String getActivateDevice();
	
	/**
	 * <p>
	 * Fetches reservationWithLTE for homeinternet
	 * </p>
	 * 
	 * @return String - reservationWithLTE for homeinternet
	 */
	@JsonProperty("reservationWithLTE")
	public String getReservationWithLTE();
	
	/**
	 * <p>
	 * Fetches whatsNext for homeinternet
	 * </p>
	 * 
	 * @return String - whatsNext for homeinternet
	 */
	@JsonProperty("whatsNext")
	public String getWhatsNext();
	
	/**
	 * <p>
	 * Fetches inactiveStatusPageTitle for homeinternet
	 * </p>
	 * 
	 * @return String - inactiveStatusPageTitle for homeinternet
	 */
	@JsonProperty("inactiveStatusPageTitle")
	public String getInactiveStatusPageTitle();
	
	/**
	 * <p>
	 * Fetches inactiveStatusPageContent1 for homeinternet
	 * </p>
	 * 
	 * @return String - inactiveStatusPageContent1 for homeinternet
	 */
	@JsonProperty("inactiveStatusPageContent1")
	public String getInactiveStatusPageContent1();
	
	/**
	 * <p>
	 * Fetches inactiveStatusPageContent2 for homeinternet
	 * </p>
	 * 
	 * @return String - inactiveStatusPageContent2 for homeinternet
	 */
	@JsonProperty("inactiveStatusPageContent2")
	public String getInactiveStatusPageContent2();
	
	/**
	 * <p>
	 * Fetches inactiveStatusPageBtnLbl for homeinternet
	 * </p>
	 * 
	 * @return String - inactiveStatusPageBtnLbl for homeinternet
	 */
	@JsonProperty("inactiveStatusPageBtnLbl")
	public String getInactiveStatusPageBtnLbl();
	/**
	 * <p>
	 * Fetches hideScanQR for homeinternet
	 * </p>
	 * 
	 * @return String - hideScanQR for homeinternet
	 */
	@JsonProperty("hideScanQR")
	public Boolean getHideScanQR();
	/**
	 * <p>
	 * Fetches enterYourIMEI for homeinternet
	 * </p>
	 * 
	 * @return String - enterYourIMEI for homeinternet
	 */
	@JsonProperty("enterYourIMEI")
	public String getEnterYourIMEI();
	/**
	 * <p>
	 * Fetches serviceConfirmWithNonQR for homeinternet
	 * </p>
	 * 
	 * @return String - serviceConfirmWithNonQR for homeinternet
	 */
	@JsonProperty("serviceConfirmWithNonQR")
	public String getServiceConfirmWithNonQR();
	/**
	 * <p>
	 * Fetches activationSet for homeinternet
	 * </p>
	 * 
	 * @return String - activationSet for homeinternet
	 */
	@JsonProperty("activationSet")
	public String getActivationSet();
	/**
	 * <p>
	 * Fetches activateLabel for homeinternet
	 * </p>
	 * 
	 * @return String - activateLabel for homeinternet
	 */
	@JsonProperty("activateLabel")
	public String getActivateLabel();
	/**
	 * <p>
	 * Fetches retailPrivcayText for homeinternet
	 * </p>
	 * 
	 * @return String - retailPrivcayText for homeinternet
	 */
	@JsonProperty("retailPrivcayText")
	public String getRetailPrivcayText();
	/**
	 * <p>
	 * Fetches activateDeviceLinkURL for homeinternet
	 * </p>
	 * 
	 * @return String - activateDeviceLinkURL for homeinternet
	 */
	@JsonProperty("activateDeviceLinkURL")
	public String getActivateDeviceLinkURL();
	/**
	 * <p>
	 * Fetches serviceNotAvailableTitle for homeinternet
	 * </p>
	 * 
	 * @return String - serviceNotAvailableTitle for homeinternet
	 */
	@JsonProperty("serviceNotAvailableTitle")
	public String getServiceNotAvailableTitle();
	/**
	 * <p>
	 * Fetches serviceNotAvailableSubTitle for homeinternet
	 * </p>
	 * 
	 * @return String - serviceNotAvailableSubTitle for homeinternet
	 */
	@JsonProperty("serviceNotAvailableSubTitle")
	public String getServiceNotAvailableSubTitle();
	/**
	 * <p>
	 * Fetches agreeSignUp for homeinternet
	 * </p>
	 * 
	 * @return String - agreeSignUp for homeinternet
	 */
	@JsonProperty("agreeSignUp")
	public String getAgreeSignUp();
	/**
	 * <p>
	 * Fetches submitEmail for homeinternet
	 * </p>
	 * 
	 * @return String - submitEmail for homeinternet
	 */
	@JsonProperty("submitEmail")
	public String getSubmitEmail();
	/**
	 * <p>
	 * Fetches signupSuccessText for homeinternet
	 * </p>
	 * 
	 * @return String - signupSuccessText for homeinternet
	 */
	@JsonProperty("signupSuccessText")
	public String getSignupSuccessText();
	/**
	 * <p>
	 * Fetches signupSuccessSubTitle for homeinternet
	 * </p>
	 * 
	 * @return String - signupSuccessSubTitle for homeinternet
	 */
	@JsonProperty("signupSuccessSubTitle")
	public String getSignupSuccessSubTitle();
	/**
	 * <p>
	 * Fetches checkAnotherAddress for homeinternet
	 * </p>
	 * 
	 * @return String - checkAnotherAddress for homeinternet
	 */
	@JsonProperty("checkAnotherAddress")
	public String getCheckAnotherAddress();
	/**
	 * <p>
	 * Fetches importantActiveInfo for homeinternet
	 * </p>
	 * 
	 * @return String - importantActiveInfo for homeinternet
	 */
	@JsonProperty("importantActiveInfo")
	public String getImportantActiveInfo();

	/**
	 * <p>
	 * Fetches brandLogo
	 * </p>
	 * 
	 * @return String - brandLogo
	 */
	@JsonProperty("deviceIMEILogo")
	public String getDeviceIMEILogo();

	/**
	 * <p>
	 * Fetches chkAailabilityDescriptionForSR for homeinternet
	 * </p>
	 * 
	 * @return String - chkAailabilityDescriptionForSR for homeinternet
	 */
	@JsonProperty("chkAailabilityDescriptionForSR")
	public String getChkAailabilityDescriptionForSR();
	/**
	 * <p>
	 * Fetches signupPhoneLbl for homeinternet
	 * </p>
	 * 
	 * @return String - signupPhoneLbl for homeinternet
	 */
	@JsonProperty("signupPhoneLbl")
	public String getSignupPhoneLbl();
	/**
	 * <p>
	 * Fetches signupEmailLbl for homeinternet
	 * </p>
	 * 
	 * @return String - signupEmailLbl for homeinternet
	 */
	@JsonProperty("signupEmailLbl")
	public String getSignupEmailLbl();
	/**
	 * <p>
	 * Fetches homeInternetTitle for homeinternet
	 * </p>
	 * 
	 * @return String - homeInternetTitle for homeinternet
	 */
	@JsonProperty("homeInternetTitle")
	public String getHomeInternetTitle();

	/**
	 * <p>
	 * Fetches showSignUpScreen for homeinternet
	 * </p>
	 * 
	 * @return String - showSignUpScreen for homeinternet
	 */
	@JsonProperty("showSignUpScreen")
	public Boolean getShowSignUpScreen();

	/**
	 * <p>
	 * Fetches serviceUnavailableHeader for homeinternet
	 * </p>
	 * 
	 * @return String - serviceUnavailableHeader for homeinternet
	 */
	@JsonProperty("serviceUnavailableHeader")
	public String getServiceUnavailableHeader();

	/**
	 * <p>
	 * Fetches serviceUnavailableContent for homeinternet
	 * </p>
	 * 
	 * @return String - serviceUnavailableContent for homeinternet
	 */
	@JsonProperty("serviceUnavailableContent")
	public String getServiceUnavailableContent();

	/**
	 * <p>
	 * Fetches serviceUnavailableChangeAddress for homeinternet
	 * </p>
	 * 
	 * @return String - serviceUnavailableChangeAddress for homeinternet
	 */
	@JsonProperty("serviceUnavailableChangeAddress")
	public String getServiceUnavailableChangeAddress();

	/**
	 * <p>
	 * Fetches serviceUnavailableHotspot for homeinternet
	 * </p>
	 * 
	 * @return String - serviceUnavailableHotspot for homeinternet
	 */
	@JsonProperty("serviceUnavailableHotspot")
	public String getServiceUnavailableHotspot();

	/**
	 * <p>
	 * Fetches hotspotRedirectURL for homeinternet
	 * </p>
	 * 
	 * @return String - hotspotRedirectURL for homeinternet
	 */
	@JsonProperty("hotspotRedirectURL")
	public String getHotspotRedirectURL();

	/**
	 * <p>
	 * Fetches caAddressLabel for homeinternet
	 * </p>
	 * 
	 * @return String - caAddressLabel for homeinternet
	 */
	@JsonProperty("caAddressLabel")
	public String getCaAddressLabel();

	/**
	 * <p>
	 * Fetches caStateLabel for homeinternet
	 * </p>
	 * 
	 * @return String - caStateLabel for homeinternet
	 */
	@JsonProperty("caStateLabel")
	public String getCaStateLabel();

	/**
	 * <p>
	 * Fetches caEmailLabel for homeinternet
	 * </p>
	 * 
	 * @return String - caEmailLabel for homeinternet
	 */
	@JsonProperty("caEmailLabel")
	public String getCaEmailLabel();

	/**
	 * <p>
	 * Fetches serviceUnavailableContentForWalmart for homeinternet
	 * </p>
	 * 
	 * @return String - serviceUnavailableContentForWalmart for homeinternet
	 */
	@JsonProperty("serviceUnavailableContentForWalmart")
	public String getServiceUnavailableContentForWalmart();

	/**
	 * <p>
	 * Fetches serviceUnavailableHeaderForWalmart for homeinternet
	 * </p>
	 * 
	 * @return String - serviceUnavailableHeaderForWalmart for homeinternet
	 */
	@JsonProperty("serviceUnavailableHeaderForWalmart")
	public String getServiceUnavailableHeaderForWalmart();

		/**
	 * <p>
	 * Fetches promoAddress for NASCAR Promo
	 * </p>
	 * 
	 * @return String - promoAddress for NASCAR Promo
	 */
	@JsonProperty("promoAddress")
	public String getPromoAddress();

	/**
	 * <p>
	 * Fetches promoEmail for NASCAR Promo
	 * </p>
	 * 
	 * @return String - promoEmail for NASCAR Promo
	 */
	@JsonProperty("promoEmail")
	public String getPromoEmail();

	/**
	 * <p>
	 * Fetches promoMobileNumber for NASCAR Promo
	 * </p>
	 * 
	 * @return String - promoMobileNumber for NASCAR Promo
	 */
	@JsonProperty("promoMobileNumber")
	public String getPromoMobileNumber();

	/**
	 * <p>
	 * Fetches promoRegistration for NASCAR Promo
	 * </p>
	 * 
	 * @return String - promoRegistration for NASCAR Promo
	 */
	@JsonProperty("promoRegistration")
	public String getPromoRegistration();

	/**
	 * <p>
	 * Fetches promoPrivacyLink for NASCAR Promo
	 * </p>
	 * 
	 * @return String - promoPrivacyLink for NASCAR Promo
	 */
	@JsonProperty("promoPrivacyLink")
	public String getPromoPrivacyLink();

	/**
	 * <p>
	 * Fetches promoUnit for NASCAR Promo
	 * </p>
	 * 
	 * @return String - promoUnit for NASCAR Promo
	 */
	@JsonProperty("promoUnit")
	public String getPromoUnit();

	/**
	 * <p>
	 * Fetches promoCloseBtn for NASCAR Promo
	 * </p>
	 * 
	 * @return String - promoCloseBtn for NASCAR Promo
	 */
	@JsonProperty("promoCloseBtn")
	public String getPromoCloseBtn();

	/**
	 * <p>
	 * Fetches promoURLString for NASCAR Promo
	 * </p>
	 * 
	 * @return String - promoURLString for NASCAR Promo
	 */
	@JsonProperty("promoURLString")
	public String getPromoURLString();

	/**
	 * <p>
	 * Fetches promoHomeURL for NASCAR Promo
	 * </p>
	 * 
	 * @return String - promoHomeURL for NASCAR Promo
	 */
	@JsonProperty("promoHomeURL")
	public String getPromoHomeURL();

	/**
	 * <p>
	 * Fetches promoHeader for NASCAR Promo
	 * </p>
	 * 
	 * @return String - promoHeader for NASCAR Promo
	 */
	@JsonProperty("promoHeader")
	public String getPromoHeader();

	/**
	 * <p>
	 * Fetches promoSubContent for NASCAR Promo
	 * </p>
	 * 
	 * @return String - promoSubContent for NASCAR Promo
	 */
	@JsonProperty("promoSubContent")
	public String getPromoSubContent();

	/**
	 * <p>
	 * Fetches promoSignUpCTA for NASCAR Promo
	 * </p>
	 * 
	 * @return String - promoSignUpCTA for NASCAR Promo
	 */
	@JsonProperty("promoSignUpCTA")
	public String getPromoSignUpCTA();

	/**
	 * <p>
	 * Fetches promoErrorContent for NASCAR Promo
	 * </p>
	 * 
	 * @return String - promoErrorContent for NASCAR Promo
	 */
	@JsonProperty("promoErrorContent")
	public String getPromoErrorContent();

	/**
	 * <p>
	 * Fetches promoDescription for NASCAR Promo
	 * </p>
	 * 
	 * @return String - promoDescription for NASCAR Promo
	 */
	@JsonProperty("promoDescription")
	public String getPromoDescription();

	/**
	 * <p>
	 * Fetches promoCustomerInfo for NASCAR Promo
	 * </p>
	 * 
	 * @return String - promoCustomerInfo for NASCAR Promo
	 */
	@JsonProperty("promoCustomerInfo")
	public String getPromoCustomerInfo();

	/**
	 * <p>
	 * Fetches retailSignupPhoneLbl for homeinternet
	 * </p>
	 * 
	 * @return String - retailSignupPhoneLbl for homeinternet
	 */
	@JsonProperty("retailSignupPhoneLbl")
	public String getRetailSignupPhoneLbl();

	/**
	 * <p>
	 * Fetches retailSignupEmailLbl for homeinternet
	 * </p>
	 * 
	 * @return String - retailSignupEmailLbl for homeinternet
	 */
	@JsonProperty("retailSignupEmailLbl")
	public String getRetailSignupEmailLbl();

	/**
	 * <p>
	 * Fetches retailAgreeSignUp for homeinternet
	 * </p>
	 * 
	 * @return String - retailAgreeSignUp for homeinternet
	 */
	@JsonProperty("retailAgreeSignUp")
	public String getRetailAgreeSignUp();

	/**
	 * <p>
	 * Fetches retailPrivacyLink for homeinternet
	 * </p>
	 * 
	 * @return String - retailPrivacyLink for homeinternet
	 */
	@JsonProperty("retailPrivacyLink")
	public String getRetailPrivacyLink();

	/**
	 * <p>
	 * Fetches retailSubmitSignUp for homeinternet
	 * </p>
	 * 
	 * @return String - retailSubmitSignUp for homeinternet
	 */
	@JsonProperty("retailSubmitSignUp")
	public String getRetailSubmitSignUp();

	/**
	 * <p>
	 * Fetches retailCheckAnotherAddress for homeinternet
	 * </p>
	 * 
	 * @return String - retailCheckAnotherAddress for homeinternet
	 */
	@JsonProperty("retailCheckAnotherAddress")
	public String getRetailCheckAnotherAddress();

	/**
	 * <p>
	 * Fetches retailServiceNotAvailableTitle for homeinternet
	 * </p>
	 * 
	 * @return String - retailServiceNotAvailableTitle for homeinternet
	 */
	@JsonProperty("retailServiceNotAvailableTitle")
	public String getRetailServiceNotAvailableTitle();

	/**
	 * <p>
	 * Fetches retailServiceNotAvailableSubTitle for homeinternet
	 * </p>
	 * 
	 * @return String - retailServiceNotAvailableSubTitle for homeinternet
	 */
	@JsonProperty("retailServiceNotAvailableSubTitle")
	public String getRetailServiceNotAvailableSubTitle();

	/**
	 * <p>
	 * Fetches retailServiceNotAvailableSubContent for homeinternet
	 * </p>
	 * 
	 * @return String - retailServiceNotAvailableSubContent for homeinternet
	 */
	@JsonProperty("retailServiceNotAvailableSubContent")
	public String getRetailServiceNotAvailableSubContent();

	/**
	 * <p>
	 * Fetches retailSignupSuccessText for homeinternet
	 * </p>
	 * 
	 * @return String - retailSignupSuccessText for homeinternet
	 */
	@JsonProperty("retailSignupSuccessText")
	public String getRetailSignupSuccessText();

	/**
	 * <p>
	 * Fetches retailSignupSuccessEmailLbl for homeinternet
	 * </p>
	 * 
	 * @return String - retailSignupSuccessEmailLbl for homeinternet
	 */
	@JsonProperty("retailSignupSuccessEmailLbl")
	public String getRetailSignupSuccessEmailLbl();

	/**
	 * <p>
	 * Fetches retailSignupSuccessPhoneLbl for homeinternet
	 * </p>
	 * 
	 * @return String - retailSignupSuccessPhoneLbl for homeinternet
	 */
	@JsonProperty("retailSignupSuccessPhoneLbl")
	public String getRetailSignupSuccessPhoneLbl();

	/**
	 * <p>
	 * Fetches retailSignupSuccessLocationLbl for homeinternet
	 * </p>
	 * 
	 * @return String - retailSignupSuccessLocationLbl for homeinternet
	 */
	@JsonProperty("retailSignupSuccessLocationLbl")
	public String getRetailSignupSuccessLocationLbl();

	/**
	 * <p>
	 * Fetches showSignUpSection for homeinternet
	 * </p>
	 * 
	 * @return String - showSignUpSection for homeinternet
	 */
	@JsonProperty("showSignUpSection")
	public String getShowSignUpSection();

	/**
	 * <p>
	 * Fetches fwVZSignupSucess for homeinternet
	 * </p>
	 * 
	 * @return String - fwVZSignupSucess for homeinternet
	 */
	@JsonProperty("fwVZSignupSucess")
	public String getFwVZSignupSucess();

	/**
	 * <p>
	 * Fetches retailEditLabel for homeinternet
	 * </p>
	 * 
	 * @return String - retailEditLabel for homeinternet
	 */
	@JsonProperty("retailEditLabel")
	public String getRetailEditLabel();

	/**
	 * <p>
	 * Fetches retailEditAddressLabelSR for homeinternet
	 * </p>
	 * 
	 * @return String - retailEditAddressLabelSR for homeinternet
	 */
	@JsonProperty("retailEditAddressLabelSR")
	public String getRetailEditAddressLabelSR();

	/**
	 * <p>
	 * Fetches retailExpolreOther for homeinternet
	 * </p>
	 * 
	 * @return String - retailExpolreOther for homeinternet
	 */
	@JsonProperty("retailExpolreOther")
	public String getRetailExpolreOther();

	/**
	 * <p>
	 * Fetches retailEditEmailLabelSR for homeinternet
	 * </p>
	 * 
	 * @return String - retailEditEmailLabelSR for homeinternet
	 */
	@JsonProperty("retailEditEmailLabelSR")
	public String getRetailEditEmailLabelSR();

	/**
	 * <p>
	 * Fetches retailEditPhoneLabelSR for homeinternet
	 * </p>
	 * 
	 * @return String - retailEditPhoneLabelSR for homeinternet
	 */
	@JsonProperty("retailEditPhoneLabelSR")
	public String getRetailEditPhoneLabelSR();

	/**
	 * <p>
	 * Fetches retailShowSignUpScreen for homeinternet
	 * </p>
	 * 
	 * @return String - retailShowSignUpScreen for homeinternet
	 */
	@JsonProperty("retailShowSignUpScreen")
	public Boolean getRetailShowSignUpScreen();

	/**
	 * <p>
	 * Fetches wmServiceAvailableFormTitle for homeinternet
	 * </p>
	 * 
	 * @return String - wmServiceAvailableFormTitle for homeinternet
	 */
	@JsonProperty("wmServiceAvailableFormTitle")
	public String getWmServiceAvailableFormTitle();

	/**
	 * <p>
	 * Fetches wmServiceAvailableFormSubTitle for homeinternet
	 * </p>
	 * 
	 * @return String - wmServiceAvailableFormSubTitle for homeinternet
	 */
	@JsonProperty("wmServiceAvailableFormSubTitle")
	public String getWmServiceAvailableFormSubTitle();

	/**
	 * <p>
	 * Fetches wmServiceAvailableFormSubContent for homeinternet
	 * </p>
	 * 
	 * @return String - wmServiceAvailableFormSubContent for homeinternet
	 */
	@JsonProperty("wmServiceAvailableFormSubContent")
	public String getWmServiceAvailableFormSubContent();

	/**
	 * <p>
	 * Fetches walmartShippingText for homeinternet
	 * </p>
	 * 
	 * @return String - walmartShippingText for homeinternet
	 */
	@JsonProperty("walmartShippingText")
	public String getWalmartShippingText();

	/**
	 * <p>
	 * Fetches wmServiceAvailableTitle for homeinternet
	 * </p>
	 * 
	 * @return String - wmServiceAvailableTitle for homeinternet
	 */
	@JsonProperty("wmServiceAvailableTitle")
	public String getWmServiceAvailableTitle();

	/**
	 * <p>
	 * Fetches wmServiceAvailableSubTitle for homeinternet
	 * </p>
	 * 
	 * @return String - wmServiceAvailableSubTitle for homeinternet
	 */
	@JsonProperty("wmServiceAvailableSubTitle")
	public String getWmServiceAvailableSubTitle();

	/**
	 * <p>
	 * Fetches wmServiceAvailableFormLogo for homeinternet
	 * </p>
	 * 
	 * @return String - wmServiceAvailableFormLogo for homeinternet
	 */
	@JsonProperty("wmServiceAvailableFormLogo")
	public String getWmServiceAvailableFormLogo();

	/**
	 * <p>
	 * Fetches wmFormAddressLbl for homeinternet
	 * </p>
	 * 
	 * @return String - wmFormAddressLbl for homeinternet
	 */
	@JsonProperty("wmFormAddressLbl")
	public String getWmFormAddressLbl();

	/**
	 * <p>
	 * Fetches wmFormUnitLbl for homeinternet
	 * </p>
	 * 
	 * @return String - wmFormUnitLbl for homeinternet
	 */
	@JsonProperty("wmFormUnitLbl")
	public String getWmFormUnitLbl();

	/**
	 * <p>
	 * Fetches wmFormEmailLbl for homeinternet
	 * </p>
	 * 
	 * @return String - wmFormEmailLbl for homeinternet
	 */
	@JsonProperty("wmFormEmailLbl")
	public String getWmFormEmailLbl();

	/**
	 * <p>
	 * Fetches walmartSeeDetailsBtnSRText for homeinternet
	 * </p>
	 * 
	 * @return String - walmartSeeDetailsBtnSRText for homeinternet
	 */
	@JsonProperty("walmartSeeDetailsBtnSRText")
	public String getWalmartSeeDetailsBtnSRText();

	/**
	 * <p>
	 * Fetches walmartCACTAText for homeinternet
	 * </p>
	 * 
	 * @return String - walmartCACTAText for homeinternet
	 */
	@JsonProperty("walmartCACTAText")
	public String getWalmartCACTAText();

	/**
	 * <p>
	 * Fetches retailPhoneNumberHelpText for homeinternet
	 * </p>
	 * 
	 * @return String - retailPhoneNumberHelpText for homeinternet
	 */
	@JsonProperty("retailPhoneNumberHelpText")
	public String getRetailPhoneNumberHelpText();

	 /**
	 * <p>
	 * Fetches walmartMarketingPageUrl for homeinternet
	 * </p>
	 * 
	 * @return String - walmartMarketingPageUrl for homeinternet
	 */
	@JsonProperty("walmartMarketingPageUrl")
	public String getWalmartMarketingPageUrl();

	/**
	 * <p>
	 * Fetches walmartPDPPageUrl for homeinternet
	 * </p>
	 * 
	 * @return String - walmartPDPPageUrl for homeinternet
	 */
	@JsonProperty("walmartPDPPageUrl")
	public String getWalmartPDPPageUrl();

	/**
	 * <p>
	 * Fetches walmartDefaultPageUrl for homeinternet
	 * </p>
	 * 
	 * @return String - walmartDefaultPageUrl for homeinternet
	 */
	@JsonProperty("walmartDefaultPageUrl")
	public String getWalmartDefaultPageUrl();

	/**
	 * <p>
	 * Fetches walmartBrandLogoSRText for homeinternet
	 * </p>
	 * 
	 * @return String - walmartBrandLogoSRText for homeinternet
	 */
	@JsonProperty("walmartBrandLogoSRText")
	public String getWalmartBrandLogoSRText();

	/**
	 * Fetches wmSignupPhoneLbl for homeinternet
	 * </p>
	 * 
	 * @return String - wmSignupPhoneLbl for homeinternet
	 */
	@JsonProperty("wmSignupPhoneLbl")
	public String getWmSignupPhoneLbl();

	/**
	 * <p>
	 * Fetches wmSignupEmailLbl for homeinternet
	 * </p>
	 * 
	 * @return String - wmSignupEmailLbl for homeinternet
	 */
	@JsonProperty("wmSignupEmailLbl")
	public String getWmSignupEmailLbl();

	/**
	 * <p>
	 * Fetches wmServiceNotAvailableTitle for homeinternet
	 * </p>
	 * 
	 * @return String - wmServiceNotAvailableTitle for homeinternet
	 */
	@JsonProperty("wmServiceNotAvailableTitle")
	public String getWmServiceNotAvailableTitle();

	/**
	 * <p>
	 * Fetches wmServiceNotAvailableSubTitle for homeinternet
	 * </p>
	 * 
	 * @return String - wmServiceNotAvailableSubTitle for homeinternet
	 */
	@JsonProperty("wmServiceNotAvailableSubTitle")
	public String getWmServiceNotAvailableSubTitle();

	/**
	 * <p>
	 * Fetches wmServiceNotAvailableSubContent for homeinternet
	 * </p>
	 * 
	 * @return String - wmServiceNotAvailableSubContent for homeinternet
	 */
	@JsonProperty("wmServiceNotAvailableSubContent")
	public String getWmServiceNotAvailableSubContent();

	/**
	 * <p>
	 * Fetches wmSignupSuccessText for homeinternet
	 * </p>
	 * 
	 * @return String - wmSignupSuccessText for homeinternet
	 */
	@JsonProperty("wmSignupSuccessText")
	public String getWmSignupSuccessText();

	/**
	 * <p>
	 * Fetches wmSignupSuccessEmailLbl for homeinternet
	 * </p>
	 * 
	 * @return String - wmSignupSuccessEmailLbl for homeinternet
	 */
	@JsonProperty("wmSignupSuccessEmailLbl")
	public String getWmSignupSuccessEmailLbl();

	/**
	 * <p>
	 * Fetches wmSignupSuccessPhoneLbl for homeinternet
	 * </p>
	 * 
	 * @return String - wmSignupSuccessPhoneLbl for homeinternet
	 */
	@JsonProperty("wmSignupSuccessPhoneLbl")
	public String getWmSignupSuccessPhoneLbl();

	/**
	 * <p>
	 * Fetches wmSignupSuccessLocationLbl for homeinternet
	 * </p>
	 * 
	 * @return String - wmSignupSuccessLocationLbl for homeinternet
	 */
	@JsonProperty("wmSignupSuccessLocationLbl")
	public String getWmSignupSuccessLocationLbl();

	/**
	 * <p>
	 * Fetches wmSignupPhoneNumberHelpText for homeinternet
	 * </p>
	 * 
	 * @return String - wmSignupPhoneNumberHelpText for homeinternet
	 */
	@JsonProperty("wmSignupPhoneNumberHelpText")
	public String getWmSignupPhoneNumberHelpText();

	/**
	 * <p>
	 * Fetches wmShowSignUpScreen for homeinternet
	 * </p>
	 * 
	 * @return String - wmShowSignUpScreen for homeinternet
	 */
	@JsonProperty("wmShowSignUpScreen")
	public Boolean getWmShowSignUpScreen();

	/**
	 * <p>
	 * Fetches wmSignupNotificationText for homeinternet
	 * </p>
	 * 
	 * @return String - wmSignupNotificationText for homeinternet
	 */
	@JsonProperty("wmSignupNotificationText")
	public String getWmSignupNotificationText();

	/**
	 * <p>
	 * Fetches wmSignupThanksText for homeinternet
	 * </p>
	 * 
	 * @return String - wmSignupThanksText for homeinternet
	 */
	@JsonProperty("wmSignupThanksText")
	public String getWmSignupThanksText();

	/**
	 * <p>
	 * Fetches wmAgreeSignUp for homeinternet
	 * </p>
	 * 
	 * @return String - wmAgreeSignUp for homeinternet
	 */
	@JsonProperty("wmAgreeSignUp")
	public String getWmAgreeSignUp();

	/**
	 * <p>
	 * Fetches wmPrivacyLink for homeinternet
	 * </p>
	 * 
	 * @return String - wmPrivacyLink for homeinternet
	 */
	@JsonProperty("wmPrivacyLink")
	public String getWmPrivacyLink();

	/**
	 * <p>
	 * Fetches wmSubmitSignUp for homeinternet
	 * </p>
	 * 
	 * @return String - wmSubmitSignUp for homeinternet
	 */
	@JsonProperty("wmSubmitSignUp")
	public String getWmSubmitSignUp();

	/**
	 * <p>
	 * Fetches wmCheckAnotherAddress for homeinternet
	 * </p>
	 * 
	 * @return String - wmCheckAnotherAddress for homeinternet
	 */
	@JsonProperty("wmCheckAnotherAddress")
	public String getWmCheckAnotherAddress();

	/**
	 * <p>
	 * Fetches wmEditLabel for homeinternet
	 * </p>
	 * 
	 * @return String - wmEditLabel for homeinternet
	 */
	@JsonProperty("wmEditLabel")
	public String getWmEditLabel();

	/**
	 * <p>
	 * Fetches wmEditAddressLabelSR for homeinternet
	 * </p>
	 * 
	 * @return String - wmEditAddressLabelSR for homeinternet
	 */
	@JsonProperty("wmEditAddressLabelSR")
	public String getWmEditAddressLabelSR();

	/**
	 * <p>
	 * Fetches wmExpolreOther for homeinternet
	 * </p>
	 * 
	 * @return String - wmExpolreOther for homeinternet
	 */
	@JsonProperty("wmExpolreOther")
	public String getWmExpolreOther();

	/**
	 * <p>
	 * Fetches wmEditEmailLabelSR for homeinternet
	 * </p>
	 * 
	 * @return String - wmEditEmailLabelSR for homeinternet
	 */
	@JsonProperty("wmEditEmailLabelSR")
	public String getWmEditEmailLabelSR();

	/**
	 * <p>
	 * Fetches wmEditPhoneLabelSR for homeinternet
	 * </p>
	 * 
	 * @return String - wmEditPhoneLabelSR for homeinternet
	 */
	@JsonProperty("wmEditPhoneLabelSR")
	public String getWmEditPhoneLabelSR();

	/**
	 * <p>
	 * Fetches stSignupEmailLbl for homeinternet
	 * </p>
	 * 
	 * @return String - stSignupEmailLbl for homeinternet
	 */
	@JsonProperty("stSignupEmailLbl")
	public String getStSignupEmailLbl();

	/**
	 * <p>
	 * Fetches stSignupPhoneLbl for homeinternet
	 * </p>
	 * 
	 * @return String - stSignupPhoneLbl for homeinternet
	 */
	@JsonProperty("stSignupPhoneLbl")
	public String getStSignupPhoneLbl();

	/**
	 * <p>
	 * Fetches stSignupPhoneNumberHelpText for homeinternet
	 * </p>
	 * 
	 * @return String - stSignupPhoneNumberHelpText for homeinternet
	 */
	@JsonProperty("stSignupPhoneNumberHelpText")
	public String getStSignupPhoneNumberHelpText();

	/**
	 * <p>
	 * Fetches stAgreeSignUp for homeinternet
	 * </p>
	 * 
	 * @return String - stAgreeSignUp for homeinternet
	 */
	@JsonProperty("stAgreeSignUp")
	public String getStAgreeSignUp();

	/**
	 * <p>
	 * Fetches stPrivacyLink for homeinternet
	 * </p>
	 * 
	 * @return String - stPrivacyLink for homeinternet
	 */
	@JsonProperty("stPrivacyLink")
	public String getStPrivacyLink();

	/**
	 * <p>
	 * Fetches stSubmitSignUp for homeinternet
	 * </p>
	 * 
	 * @return String - stSubmitSignUp for homeinternet
	 */
	@JsonProperty("stSubmitSignUp")
	public String getStSubmitSignUp();

	/**
	 * <p>
	 * Fetches stCheckAnotherAddress for homeinternet
	 * </p>
	 * 
	 * @return String - stCheckAnotherAddress for homeinternet
	 */
	@JsonProperty("stCheckAnotherAddress")
	public String getStCheckAnotherAddress();

	/**
	 * <p>
	 * Fetches stServiceNotAvailableTitle for homeinternet
	 * </p>
	 * 
	 * @return String - stServiceNotAvailableTitle for homeinternet
	 */
	@JsonProperty("stServiceNotAvailableTitle")
	public String getStServiceNotAvailableTitle();

	/**
	 * <p>
	 * Fetches stServiceNotAvailableSubTitle for homeinternet
	 * </p>
	 * 
	 * @return String - stServiceNotAvailableSubTitle for homeinternet
	 */
	@JsonProperty("stServiceNotAvailableSubTitle")
	public String getStServiceNotAvailableSubTitle();

	/**
	 * <p>
	 * Fetches stServiceNotAvailableSubContent for homeinternet
	 * </p>
	 * 
	 * @return String - stServiceNotAvailableSubContent for homeinternet
	 */
	@JsonProperty("stServiceNotAvailableSubContent")
	public String getStServiceNotAvailableSubContent();

	/**
	 * <p>
	 * Fetches stSignupSuccessText for homeinternet
	 * </p>
	 * 
	 * @return String - stSignupSuccessText for homeinternet
	 */
	@JsonProperty("stSignupSuccessText")
	public String getStSignSignupSuccessText();

	/**
	 * <p>
	 * Fetches stSignupSuccessEmailLbl for homeinternet
	 * </p>
	 * 
	 * @return String - stSignupSuccessEmailLbl for homeinternet
	 */
	@JsonProperty("stSignupSuccessEmailLbl")
	public String getStSignupSuccessEmailLbl();

	/**
	 * <p>
	 * Fetches stSignupSuccessPhoneLbl for homeinternet
	 * </p>
	 * 
	 * @return String - stSignupSuccessPhoneLbl for homeinternet
	 */
	@JsonProperty("stSignupSuccessPhoneLbl")
	public String getStSignupSuccessPhoneLbl();

	/**
	 * <p>
	 * Fetches stSignupSuccessLocationLbl for homeinternet
	 * </p>
	 * 
	 * @return String - stSignupSuccessLocationLbl for homeinternet
	 */
	@JsonProperty("stSignupSuccessLocationLbl")
	public String getStSignupSuccessLocationLbl();

	/**
	 * <p>
	 * Fetches stEditLabel for homeinternet
	 * </p>
	 * 
	 * @return String - stEditLabel for homeinternet
	 */
	@JsonProperty("stEditLabel")
	public String getStEditLabel();

	/**
	 * <p>
	 * Fetches stEditAddressLabelSR for homeinternet
	 * </p>
	 * 
	 * @return String - stEditAddressLabelSR for homeinternet
	 */
	@JsonProperty("stEditAddressLabelSR")
	public String getStEditAddressLabelSR();

	/**
	 * <p>
	 * Fetches stExpolreOther for homeinternet
	 * </p>
	 * 
	 * @return String - stExpolreOther for homeinternet
	 */
	@JsonProperty("stExpolreOther")
	public String getStExpolreOther();

	/**
	 * <p>
	 * Fetches stEditEmailLabelSR for homeinternet
	 * </p>
	 * 
	 * @return String - stEditEmailLabelSR for homeinternet
	 */
	@JsonProperty("stEditEmailLabelSR")
	public String getStEditEmailLabelSR();

	/**
	 * <p>
	 * Fetches stEditPhoneLabelSR for homeinternet
	 * </p>
	 * 
	 * @return String - stEditPhoneLabelSR for homeinternet
	 */
	@JsonProperty("stEditPhoneLabelSR")
	public String getStEditPhoneLabelSR();

	/**
	 * <p>
	 * Fetches stSignupNotificationText for homeinternet
	 * </p>
	 * 
	 * @return String - stSignupNotificationText for homeinternet
	 */
	@JsonProperty("stSignupNotificationText")
	public String getStSignupNotificationText();

	/**
	 * <p>
	 * Fetches stSignupThanksText for homeinternet
	 * </p>
	 * 
	 * @return String - stSignupThanksText for homeinternet
	 */
	@JsonProperty("stSignupThanksText")
	public String getStSignupThanksText();

	/**
	 * <p>
	 * Fetches stFormAddressLbl for homeinternet
	 * </p>
	 * 
	 * @return String - stFormAddressLbl for homeinternet
	 */
	@JsonProperty("stFormAddressLbl")
	public String getStFormAddressLbl();

	/**
	 * <p>
	 * Fetches stFormUnitLbl for homeinternet
	 * </p>
	 * 
	 * @return String - stFormUnitLbl for homeinternet
	 */
	@JsonProperty("stFormUnitLbl")
	public String getStFormUnitLbl();

	/**
	 * <p>
	 * Fetches stFormEmailLbl for homeinternet
	 * </p>
	 * 
	 * @return String - stFormEmailLbl for homeinternet
	 */
	@JsonProperty("stFormEmailLbl")
	public String getStFormEmailLbl();
	/**
	 * <p>
	 * Fetches retailSignupThanksText for homeinternet
	 * </p>
	 * 
	 * @return String - retailSignupThanksText for homeinternet
	 */
	@JsonProperty("retailSignupThanksText")
	public String getRetailSignupThanksText();

	/**
	 * <p>
	 * Fetches retailSignupNotificationText for homeinternet
	 * </p>
	 * 
	 * @return String - retailSignupNotificationText for homeinternet
	 */
	@JsonProperty("retailSignupNotificationText")
	public String getRetailSignupNotificationText();

	 /* Fetches stServiceAvailableFormSubContent for homeinternet
	 * </p>
	 * 
	 * @return String - stServiceAvailableFormSubContent for homeinternet
	 */
	@JsonProperty("stServiceAvailableFormSubContent")
	public String getStServiceAvailableFormSubContent();
	
	/**
	 * <p>
	 * Fetches stheaderstyle for homeinternet
	 * </p>
	 * 
	 * @return String - stheaderstyle for homeinternet
	 */
	@JsonProperty("stheaderstyle")
	public String getStheaderstyle();

	/**
	 * <p>
	 * Fetches stExpolreDevicesURL for homeinternet
	 * </p>
	 * 
	 * @return String - stExpolreDevicesURL for homeinternet
	 */
	@JsonProperty("stExpolreDevicesURL")
	public String getStExpolreDevicesURL();

	/**
	 * <p>
	 * Fetches stSignupConfirmEmailLbl for homeinternet
	 * </p>
	 * 
	 * @return String - stSignupConfirmEmailLbl for homeinternet
	 */
	@JsonProperty("stSignupConfirmEmailLbl")
	public String getStSignupConfirmEmailLbl();
	/**
	 * <p>
	 * Fetches stSignupNotMatchError for homeinternet
	 * </p>
	 * 
	 * @return String - stSignupNotMatchError for homeinternet
	 */
	@JsonProperty("stSignupNotMatchError")
	public String getStSignupNotMatchError();
	/**
	 * <p>
	 * Fetches wmSignupConfirmEmailLbl for homeinternet
	 * </p>
	 * 
	 * @return String - wmSignupConfirmEmailLbl for homeinternet
	 */
	@JsonProperty("wmSignupConfirmEmailLbl")
	public String getWmSignupConfirmEmailLbl();
	/**
	 * <p>
	 * Fetches wmSignupNotMatchError for homeinternet
	 * </p>
	 * 
	 * @return String - wmSignupNotMatchError for homeinternet
	 */
	@JsonProperty("wmSignupNotMatchError")
	public String getWmSignupNotMatchError();
	/**
	 * <p>
	 * Fetches wmPnpText for homeinternet
	 * </p>
	 * 
	 * @return String - wmPnpText for homeinternet
	 */
	@JsonProperty("wmPnpText")
	public String getWmPnpText();

	/**
	 * <p>
	 * Fetches retailSignupConfirmEmailLbl for homeinternet
	 * </p>
	 * 
	 * @return String - retailSignupConfirmEmailLbl for homeinternet
	 */
	@JsonProperty("retailSignupConfirmEmailLbl")
	public String getRetailSignupConfirmEmailLbl();
	
	/**
	 * <p>
	 * Fetches retailNotMatchErrorMsg for homeinternet
	 * </p>
	 * 
	 * @return String - retailNotMatchErrorMsg for homeinternet
	 */
	@JsonProperty("retailNotMatchErrorMsg")
	public String getRetailNotMatchErrorMsg();
	
	/** 
	 * <p>
	 *  Fetches formCntBtnDisableLbl
	 * </p>
	 * 
	 * @return String - formCntBtnDisableLbl
	 */
	@JsonProperty("formCntBtnDisableLbl")
	public String getFormCntBtnDisableLbl();

}
