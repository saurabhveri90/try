/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;


import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Defines the {@code New Line} Sling Model used for the {@code /apps/tracfone-core/components/commerce/autorefill} component.
 */
public interface AutoRefillModel extends ComponentExporter {

	
	/**
	 * <p>Fetches title for Auto Refill</p>
	 * 
	 * @return String - title for Auto Refill
	 */
	@JsonProperty("title")
	public String getTitle();

	/**
	 * <p>Fetches description for Auto Refill</p>
	 *
	 * @return String - description for Auto Refill
	 */
	@JsonProperty("description")
	public String getDescription();

	/**
	 * <p>Fetches all the multi-options</p>
	 *
	 * @return List - all the multi-options
	 */
	@JsonProperty("options")
	public List<String> getOptions();
	
	/**
	 * <p>Fetches disable guest checkout flag value</p>
	 *
	 * @return String - disable guest checkout flag
	 */
	@JsonProperty("getDisableGuestCheckout")
	public String getDisableGuestCheckout();
	/**
	 * <p>Fetches label when discount price is less than and equals to 0 dollar</p>
	 *
	 * @return String - No discount price label
	 */
	@JsonProperty("noDiscountPriceLabel")
	public String getNoDiscountPriceLabel();
	/**
	 * <p>Fetches label when discount price is greater than 0 dollar</p>
	 *
	 * @return String - discount price label
	 */
	@JsonProperty("discountPriceLabel")
	public String getDiscountPriceLabel();
	/**
	 * <p>Fetches CUSG Logo</p>
	 *
	 * @return String - CUSG Logo path
	 */
	public String getCusgLogo();
	/**
	 * <p>Fetches CUSG Discount Label</p>
	 *
	 * @return String - CUSG discount label
	 */
	public String getCusgLabel();
	/**
	 * <p>Fetches to check if CUSG is enable</p>
	 *
	 * @return String -CUSG enable flag
	 */
	public String getEnableCusg() ;
	/**
	 * <p>Fetches CUSG Logo Alt text</p>
	 *
	 * @return String - CUSG Logo alternate text
	 */
	public String getCusgLogoAltText() ;
	/**
	 * <p>Fetches the heading</p>
	 *
	 * @return String -Heading
	 */
	@JsonProperty("heading")
	public String getHeading();

	/**
	 * <p>Fetches the showHeadingAsH1</p>
	 *
	 * @return String -showHeadingAsH1
	 */
	@JsonProperty("showHeadingAsH1")
	public String getShowHeadingAsH1();

	/**
	 * <p>Fetches the summary</p>
	 *
	 * @return String -Summary
	 */
	@JsonProperty("summary")
	public String getSummary();
	/**
	 * <p>Fetches the planMessage</p>
	 *
	 * @return String -Plan Message
	 */

	@JsonProperty("planMessage")
	public String getPlanMessage();
	/**
	 * <p>Fetches the disclaimer</p>
	 *
	 * @return String -Disclaimer
	 */
	@JsonProperty("disclaimer")
	public String getDisclaimer();
	/**
	 * <p>
	 * Fetches modalName
	 * </p>
	 *
	 * @return the modalName
	 */
	@JsonProperty("modalName")
	public String getModalName();
	
	/**
	 * <p>
	 * Fetches flowType
	 * </p>
	 *
	 * @return the flowType
	 */
	@JsonProperty("flowType")
	public String getFlowType();
		
	/**
	 * <p>Fetches the ILD Message</p>
	 *
	 * @return ILD Message
	 */
	@JsonProperty("ildMessage")
	public String getIldMessage();


	/**
	 * <p>Fetches disable price section on Auto-Refill page</p>
	 *
	 * @return String - disable disable price section flag
	 */
	@JsonProperty("getDisablePriceSection")
	public String getDisablePriceSection();

	/**
	 * <p>Fetches ild Disclaimer</p>
	 *
	 * @return String - ild Disclaimer
	 */
	@JsonProperty("ildDisclaimer")
	public String getIldDisclaimer();

	/**
	 * <p>Fetches dcotPromoDesc </p>
	 *
	 * @return String - dcotPromoDesc
	 */
	@JsonProperty("dcotPromoDesc")
	public String getDcotPromoDesc();

	}
