package com.tracfonecore.core.models;

import java.util.Map;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code ImageAndTextModel} Sling Model used for the
 * {@code /apps/tracfone-core/components/content/imageAndText} component.
 */
public interface ImageAndTextModel extends ComponentExporter {

	/**
	 * <p>
	 * Fetches alignment of the image to define the layout
	 * </p>
	 * 
	 * @return String - alignment of the image
	 */
	@JsonProperty("imageAlignment")
	public String getImageAlignment();

	/**
	 * <p>
	 * Fetches column1Width
	 * </p>
	 * 
	 * @return String - column1Width
	 */
	@JsonProperty("column1Width")
	public String getColumn1Width();

	/**
	 * <p>
	 * Fetches column2 Width
	 * </p>
	 * 
	 * @return String - column2 Width
	 */
	@JsonProperty("column2Width")
	public String getColumn2Width();

	/**
	 * <p>
	 * Fetches image path from the dam
	 * </p>
	 * 
	 * @return String - image Path
	 */
	@JsonProperty("imagePath")
	public String getImagePath();

	/**
	 * <p>
	 * Fetches alt text of the image
	 * </p>
	 * 
	 * @return String - alt text of the image
	 */
	@JsonProperty("imageAltText")
	public String getImageAltText();

	/**
	 * <p>
	 * Fetches text
	 * </p>
	 * 
	 * @return String - text
	 */
	@JsonProperty("text")
	public String getText();	
				
	/**
	 * <p>
	 * Fetches includeinlineDisclaimer
	 * </p>
	 * 
	 * @return String - includeinlineDisclaimer
	 */
	@JsonProperty("includeinlineDisclaimer")
	public String getIncludeInlineDisclaimer();
			
	/**
	 * <p>
	 * Method to return the export child items
	 * 
	 * @return Map<String, ? extends ComponentExporter>
	 */
	public Map<String, ? extends ComponentExporter> getItems();
	
	/**
	 *  <p>
	 * Fetches break points for the image
	 * </p> 
	 * 
	 * @return String - imageProfileBreakpoints
	 */
	public String getImageProfileBreakpoints();
		
	/**
	 *<p>Fetches the path for mobile image path</p>
	 *
	 * @return String - mobile image path
	 */
	public String getMobileMediaImagePath();
	
	/**
	 *<p>Fetches the data mode</p>
	 *
	 * @return String - data mode
	 */
	public String getDataMode();
	
	/**
	 * <p>
	 * Fetches if default padding required for column 2 
	 * </p>
	 * 
	 * @return String - useCol2DefaultPadding
	 */
	@JsonProperty("useCol2DefaultPadding")
	public String getUseCol2DefaultPadding();
	
	/**
	 * <p>
	 * Fetches if default padding required for column 1 
	 * </p>
	 * 
	 * @return String - useCol1DefaultPadding
	 */
	@JsonProperty("useCol1DefaultPadding")
	public String getUseCol1DefaultPadding();
	
	/**
	 *<p>Fetches column1Class</p>
	 *
	 * @return the column1Class
	 */
	public String getColumn1Class() ;
	/**
	 *<p>Fetches column2Class</p>
	 *
	 * @return the column2Class
	 */
	public String getColumn2Class() ;

	/**
	 * <p>Fetches stack View in Mobile</p>
	 * 
	 * @return boolean - use stack View in Mobile
	 */
	@JsonProperty("useStackViewInMobile")
	default boolean isUseStackViewInMobile() {
		return false;
	}

	/**
	 * <p>Fetches useRowDefaultPadding</p>
	 * 
	 * @return boolean - useRowDefaultPadding
	 */
	@JsonProperty("useRowDefaultPadding")
	default boolean isUseRowDefaultPadding() {
		return false;
	}

	/**
	 * <p>Fetches useImageBorder</p>
	 * 
	 * @return String - useImageBorder
	 */
	@JsonProperty("useImageBorder")
	default String isUseImageBorder() {
		return null;
	}

	/**
	 * <p>Fetches video thumbnail image</p>
	 *
	 * @return String - video thumbnail image
	 */
	@JsonProperty("videoThumbnailImage")
	default String getVideoThumbnailImage() {
		return null;
	}

	/**
	 * <p>Fetches media type</p>
	 *
	 * @return String - media type
	 */
	@JsonProperty("mediaType")
	default String getMediaType() {
		return null;
	}

	/**
	 *<p>Fetches the path for mobile thumbnail</p>
	 *
	 * @return String - mobile thumbnail image path
	 */
	default String getMobileThumbnailImagePath() {
		return null;
	}

	/**
	 *<p>Fetches data type for the video</p>
	 *
	 * @return String - videoDataType
	 */
	default String getVideoDataType() {
		return null;
	}
	
	/**
	  * <p>
	  * Fetches show timer option
	  * </p>
	  * 
	  * @return String - Show Timer
	 */
	@JsonProperty("showTimer")
	default String getShowTimer() {
		return null;
	}
	
	/**
	 *<p>Fetches useOppImageAlignInMobile</p>
	 *
	 * @return the useOppImageAlignInMobile
	 */
	@JsonProperty("useOppImageAlignInMobile")
	default boolean isUseOppImageAlignInMobile() {
		return false;
	}

	/**
	 *<p>Fetches declarationText</p>
	 *
	 * @return the declarationText
	 */
	@JsonProperty("disclaimerText")
	default String getDisclaimerText() {
		return null;
	}

	/**
	 * <p> Fetches selected timer position </p>
	 * 
	 * @return String - selected Timer position
	*/
	@JsonProperty("selectedTimerPosition")
	default String getSelectedTimerPosition(){
		return null;
	}
}
