package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.PromoCardsBean;

public interface PromoCardsModel extends ComponentExporter {

	@JsonProperty("promoCards")
	public List<PromoCardsBean> getPromoCards();

}