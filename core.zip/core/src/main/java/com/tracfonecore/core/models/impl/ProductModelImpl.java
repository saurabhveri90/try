/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;


import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.tracfonecore.core.models.ProductModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.BrandSpecificConfigService;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;
import com.tracfonecore.core.utils.ItemsExporterUtil;


@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ProductModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/product/v1/product", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ProductModelImpl extends BaseComponentModelImpl implements ProductModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;

	@Inject
	private SlingModelFilter slingModelFilter;

	@Inject
	private ModelFactory modelFactory;

	@Inject
	private Resource resource;

	private String categoryType;

	private String layoutSize;
	
	private String useBazaarVoiceRatings;
	
	private String mobileLayoutSize;
	
	private String planType;

	private String selection;
	
	private String disclaimerText;
	
	private String priceBreakDownLabel;
	
	private String notifyBtn;

	private String stockTitle;
	
	private String preTextNotifyMeBtn;

	private String hideRatings;

	@Inject
	private Page currentPage;

	@Inject
	ApplicationConfigService applicationConfigService;
	
	@Inject
	BrandSpecificConfigService brandSpecificConfigService;

	private Object pageProperties;

	private static final Logger LOGGER = LoggerFactory.getLogger(ProductModelImpl.class);

	//Constants
	private static final String CATEGORY_TYPE = "categorytype";

	private static final String LAYOUT_SIZE = "layoutSize";
	
	private static final String MOBILE_LAYOUT_SIZE = "mobileLayoutSize";


	@PostConstruct
	protected void initModel() {
		super.initModel();
		readPageProperties();
		setStockProperties();
	}
	private void readPageProperties()
	{
		LOGGER.info("Entering ProductModelImpl.getPartNoFromPageProp");
		PageManager pm = resource.getResourceResolver().adaptTo(PageManager.class);
		LOGGER.info("Page path {}",resource.getPath());
		Page currentPage = pm.getContainingPage(resource);		
		Page parentPage = currentPage.getParent();
		Page ancestorPage = parentPage.getParent();
		selection = currentPage.getContentResource().getValueMap().get("partNo", String.class);
		properties = parentPage.getProperties();
		if(properties != null && properties.containsKey(CATEGORY_TYPE) && properties.containsKey(CommerceConstants.CATEGORY_ID)){
			categoryType = properties.get(CATEGORY_TYPE, String.class);
			layoutSize = properties.get(LAYOUT_SIZE, String.class);
			mobileLayoutSize = properties.get(MOBILE_LAYOUT_SIZE, String.class);
			disclaimerText = properties.get(CommerceConstants.MULTILINE_DISCLAIMER_TEXT, String.class);
			priceBreakDownLabel = properties.get(CommerceConstants.PRICE_BREAKDOWN_LABEL, String.class);
		}else {
			properties = ancestorPage.getProperties();
			if (properties != null && properties.containsKey(CATEGORY_TYPE) && properties.containsKey(CommerceConstants.CATEGORY_ID)) {
				categoryType = properties.get(CATEGORY_TYPE, String.class);
				layoutSize = properties.get(LAYOUT_SIZE, String.class);
				mobileLayoutSize = properties.get(MOBILE_LAYOUT_SIZE, String.class);
				disclaimerText = properties.get(CommerceConstants.MULTILINE_DISCLAIMER_TEXT, String.class);
				priceBreakDownLabel = properties.get(CommerceConstants.PRICE_BREAKDOWN_LABEL, String.class);
			}
		}
		if (checkCategoryValues(parentPage.getProperties())) {
			pageProperties = parentPage.getProperties();
		} else if (checkCategoryValues(ancestorPage.getProperties())) {
			pageProperties = ancestorPage.getProperties();
		}

		if (pageProperties != null) {
			useBazaarVoiceRatings = ((ValueMap) pageProperties).get(CommerceConstants.USE_BAZAAR_VOICE_RATINGS, String.class);
		}

		if (categoryType != null && categoryType.equals(CommerceConstants.PLAN)) {
			planType = currentPage.getProperties().get(CommerceConstants.PLAN_TYPE, String.class);
		}
		checkForHideRatings();
		LOGGER.info("Exiting ProductModelImpl.getPartNoFromPageProp");
	}
	private Boolean checkCategoryValues(ValueMap properties) {

		if (properties != null && properties.containsKey(CommerceConstants.CATEGORY_ID)
				&& !properties.get(CommerceConstants.CATEGORY_ID, String.class).isEmpty()
				&& properties.containsKey(CommerceConstants.CATEGORY_TYPE)
				&& !properties.get(CommerceConstants.CATEGORY_TYPE, String.class).isEmpty()) {
			return true;
		}

		return false;
	}
   
	private void setStockProperties(){
		Page parentPage = currentPage.getParent();
		Page ancestorPage = parentPage.getParent();

		properties = parentPage.getProperties();
		if (properties != null && properties.containsKey(CommerceConstants.NOTIFY_ME_BUTTON) && !properties.get(CommerceConstants.NOTIFY_ME_BUTTON, String.class).isEmpty()) {
			LOGGER.debug("Entering setStockProperties method - Phone Detail Model: parent Page");
		} else {
			properties = ancestorPage.getProperties();
			if (properties != null && properties.containsKey(CommerceConstants.NOTIFY_ME_BUTTON) && !properties.get(CommerceConstants.NOTIFY_ME_BUTTON, String.class).isEmpty()) {
				LOGGER.debug("Entering setStockProperties method - Phone detail Model: Ancestor Page");
			}
		}

		if (properties != null && ((properties.containsKey(CommerceConstants.NOTIFY_ME_BUTTON) && !properties.get(CommerceConstants.NOTIFY_ME_BUTTON, String.class).isEmpty())
		        || ((properties.containsKey(CommerceConstants.STOCK_POPOVER_TITLE) && !properties.get(CommerceConstants.STOCK_POPOVER_TITLE, String.class).isEmpty()))
				|| ((properties.containsKey(CommerceConstants.PRE_TEXT_NOTIFY_ME_BUTTON) && !properties.get(CommerceConstants.PRE_TEXT_NOTIFY_ME_BUTTON, String.class).isEmpty()))
				)){
			    setStockTitle(properties.get(CommerceConstants.STOCK_POPOVER_TITLE, String.class));
				setNotifyBtn(properties.get(CommerceConstants.NOTIFY_ME_BUTTON, String.class));
				setPreTextNotifyMeBtn(properties.get(CommerceConstants.PRE_TEXT_NOTIFY_ME_BUTTON, String.class));
		}
	}

	/**
	 * Get hideRatings from plan card and set its value
	 */
	private void checkForHideRatings() {
		Resource planCard = resource.getChild("plancard");
		if (planCard != null && planCard.getValueMap()!= null) {
			setHideRatings(StringUtils.defaultString(planCard.getValueMap().get("hideRating", String.class)));
		}
	}

	@Override
	public String getCategoryType() {
		return categoryType;
	}	

	/**
	 * @param categoryType the categoryType to set
	 */
	public void setCategoryType(String categoryType) {
		this.categoryType = categoryType;
	}
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	* @return String - the getStockTitle 
	*/
	@Override
	public String getStockTitle() {
		return stockTitle;
	}
	public void setStockTitle(String stockTitle) {
		this.stockTitle = stockTitle;
	}

	/**
	* @return String - the preTextNotifyMeBtn 
	*/
	@Override
	public String getPreTextNotifyMeBtn() {
		return preTextNotifyMeBtn;
	}
	public void setPreTextNotifyMeBtn(String preTextNotifyMeBtn) {
		this.preTextNotifyMeBtn = preTextNotifyMeBtn;
	}

	/**
	* @return String - the getNotifyBtn 
	*/
	@Override
	public String getNotifyBtn() {
		return notifyBtn;
	}
	public void setNotifyBtn(String notifyBtn) {
		this.notifyBtn = notifyBtn;
	}
		
	/**
	 * <p>
	 * Returns json from items
	 * </p>
	 * 
	 * @return Map - items
	 */
	public Map<String, ? extends ComponentExporter> getItems() {
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}

	@Override
	public String getLayoutSize() {
		return layoutSize;
	}
	
	
	/**
	 * <p>Fetches number of columns for product specification for mobile</p>
	 *
	 * @return String - number of columns for product specification for Mobile
	 */
	@Override
	public String getMobileLayoutSize() {
		return mobileLayoutSize;
	}
	/**
	 * <p>Set number of columns for product specification foe mobile</p>
	 *
	 * @param String - number of columns for product specification for Mobile
	 */
	public void setMobileLayoutSize(String mobileLayoutSize) {
		this.mobileLayoutSize = mobileLayoutSize;
	}
	public void setLayoutSize(String layoutSize) {
		this.layoutSize = layoutSize;
	}
	/**
	 * <p>Fetches style class to display number of columns for product specification for desktop</p>
	 *
	 * @return String - number of columns for product specification for Mobile
	 */
	public String getStyleClass() {
		String styleClass = StringUtils.EMPTY;
		if(StringUtils.isNotBlank(getLayoutSize()) && Integer.parseInt(getLayoutSize()) != 0) {
			if(Integer.parseInt(getLayoutSize()) == 3) {
				styleClass = ApplicationConstants.ROW_COLS_LG+"3";
			}else if(Integer.parseInt(getLayoutSize()) == 4){
				styleClass = ApplicationConstants.ROW_COLS_LG+"4";
			}else if(Integer.parseInt(getLayoutSize()) == 5){
				styleClass = ApplicationConstants.ROW_COLS_LG+"5";
			}else if(Integer.parseInt(getLayoutSize()) == 6){
				styleClass = ApplicationConstants.ROW_COLS_LG+"6";
			}
		}
		return styleClass;
	}
	/**
	 * <p>Fetches style class to display number of columns for product specification for mobile</p>
	 *
	 * @return String - number of columns for product specification for Mobile
	 */
	public String getMobileStyleClass() {
		String styleClass = StringUtils.EMPTY;
		if(StringUtils.isNotBlank(getMobileLayoutSize()) && Integer.parseInt(getMobileLayoutSize()) != 0) {
			if(Integer.parseInt(getMobileLayoutSize()) == 1) {
				styleClass = ApplicationConstants.ROW_COLS+"1";
			}else if(Integer.parseInt(getMobileLayoutSize()) == 2){
				styleClass = ApplicationConstants.ROW_COLS+"2";
			}
		}
		return styleClass;
	}
	
	/**
	 * <p>Fetches planType from pdp page properties</p>
	 *
	 * @return String - planType
	 */
	@Override
	public String getPlanType() {
		return planType;
	}
	
	/**
	 * <p>Fetches enableMultilinePlan value from config</p>
	 *
	 * @return String - enableMultilinePlan
	 */
	@Override
	public String getEnableMultilinePlan() {
		PageManager pm = resource.getResourceResolver().adaptTo(PageManager.class);
		Page currentPage = pm.getContainingPage(resource);
		return ConfigurationUtil.getConfigValue(brandSpecificConfigService.enableMultilinePlans(), CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
	}
	
	/**
     * <p>
     * Method to return disclaimerText
     *
     * @return String disclaimerText
     */
	@Override
	public String getDisclaimerText() {
		return disclaimerText;
	}
	
	/**
     * <p>
     * Method to return priceBreakDownLabel
     *
     * @return String priceBreakDownLabel
     */
	@Override
	public String getPriceBreakDownLabel() {
		return priceBreakDownLabel;
	}


    /**
     * <p>
     * Method to return selection
     *
     * @return String selection
     */
    @Override
    public String getSelection() {
        return selection;
    }

	/**
     * <p>
     * Method to return Bazaar Voice Ratings
     *
     * @return  Ratings
     */
	@Override
	public String getUseBazaarVoiceRatings() {
		return useBazaarVoiceRatings;
	}

	/**
	 * @param hideRatings the hideRatings to set
	 */
	public void setHideRatings(String hideRatings) {
		this.hideRatings = hideRatings;
	}
	/**
     * <p>
     * Method to return hideRatings
     *
     * @return  hideRatings
     */
	@Override
	public String getHideRatings() {
		return hideRatings;
	}
	
	@Override
	public String getPlanPDPPage() {
		if(currentPage.getPath().contains("plans-and-services") && currentPage.getTemplate().getPath().contentEquals("/conf/straighttalk/settings/wcm/templates/product-plan-page")) {
			return "true";
		}
		return "false";
	}

}
