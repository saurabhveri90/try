package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.DealCardBean;

public interface DealsAndCouponsModel extends ComponentExporter {

	@JsonProperty("positionDealsAndCoupons")
	public String getPositionDealsAndCoupons();
	
	@JsonProperty("positionAccountNavigation")
	public String getPositionAccountNavigation();
	
	@JsonProperty("subHeadlineDealsAndCoupons")
	public String getSubHeadlineDealsAndCoupons();
	
	@JsonProperty("legalCopyTextForDealsAndCoupons")
	public String getLegalCopyTextForDealsAndCoupons();

	@JsonProperty("headlineDeals")
	public String getHeadlineDeals();
	
	@JsonProperty("subHeadlineDeals")
	public String getSubHeadlineDeals();
		
	@JsonProperty("carouselSpeedDeals")
	public String getCarouselSpeedDeals();
	
	@JsonProperty("dotNavigationLengthDeals")
	public String getDotNavigationLengthDeals();
	
	@JsonProperty("headlineCoupons")
	public String getHeadlineCoupons();
	
	@JsonProperty("subHeadlineCoupons")
	public String getSubHeadlineCoupons() ;
	
	@JsonProperty("seeMoreCouponButtonLink")
	public String getSeeMoreCouponButtonLink();
	
	@JsonProperty("carouselSpeedCoupons")
	public String getCarouselSpeedCoupons();
	
	@JsonProperty("dotNavigationLengthCoupons")
	public String getDotNavigationLengthCoupons();

	@JsonProperty("seeMoreDealsCtaLink")
	public String getSeeMoreDealsCtaLink();

	@JsonProperty("seeMoreDealsCtaText")
	public String getSeeMoreDealsCtaText();
	
	@JsonProperty("dealCards")
	public List<DealCardBean> getDealCards();
}