/*
 *  Copyright 2021 Sunera Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.LinkBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.SimTypeSelectionModel;
import com.tracfonecore.core.services.ActivationFlowConfigService;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.tracfonecore.core.utils.ApplicationUtil;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { SimTypeSelectionModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/simselection", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class SimTypeSelectionModelImpl implements SimTypeSelectionModel {

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private ActivationFlowConfigService activationFlowConfigService;

	@Inject
	private Resource resource;

	@ScriptVariable
	private ValueMap properties;

	private List<LinkBean> options = Collections.emptyList();
	LinkBean linkBean;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Default(values = "Learn More")
	private String modalName;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String flowType;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String heading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String summary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String helptext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String buttontext;

	private String modalId;

	private static final Logger LOGGER = LoggerFactory.getLogger(SimTypeSelectionModelImpl.class);

	@PostConstruct
	private void initModel() {
        //LOGGER.debug("SIM TYPE MODEL CALLED");
		// options = new ArrayList<>();
		options = new ArrayList<LinkBean>();
		for (Resource child : resource.getChildren()) {
			if (ApplicationConstants.OPTIONS.equals(child.getName())) {
				Iterator<Resource> it = child.listChildren();
				setMultiFieldItems(it, options);
			}
		}
		this.setModalId(ApplicationUtil.getLowerCaseWithHyphen(modalName) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL);

	}

	/**
	 * <p>
	 * Populates a list with all the multi-options
	 * </p>
	 *
	 * @param it             - iterator of the parent node
	 * @param multiFieldData - list in which the multi options data needs to be set
	 */

	private void setMultiFieldItems(Iterator<Resource> it, List<LinkBean> multiFieldData) {
		LOGGER.debug("Entering setMultiFieldItems method");
		while (it.hasNext()) {
			linkBean = new LinkBean();
			Resource grandChild = it.next();
			// String option = grandChild.getValueMap().get("option", String.class);
			linkBean.setHeading(grandChild.getValueMap().get("option", String.class));
			linkBean.setLinkText(grandChild.getValueMap().get("placeholder", String.class));
			linkBean.setLinkAltText(grandChild.getValueMap().get("description", String.class));
			linkBean.setLinkIcon(grandChild.getValueMap().get("targetURL", String.class));

			multiFieldData.add(linkBean);

		}

		LOGGER.debug("Exiting setMultiFieldItems method ");
	}

	/**
	 * <p>
	 * Fetches all the multi-options
	 * </p>
	 *
	 * @return List - all the multi-options
	 */
	@Override
	public List<LinkBean> getOptions() {
		return new ArrayList<LinkBean>(options);
	}

	/**
	 * @return String - exportedType
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Fetches modalName
	 * </p>
	 *
	 * @return the modalName
	 */
	@Override
	public String getModalName() {
		return modalName;
	}

	/**
	 * <p>
	 * Fetches modalId
	 * </p>
	 *
	 * @return the modalId
	 */
	public String getModalId() {
		return modalId;
	}

	/**
	 * <p>
	 * Sets modalId
	 * </p>
	 *
	 * @param modalId - the modalId to set
	 */
	public void setModalId(String modalId) {
		this.modalId = modalId;
	}

	@Override
	public String getFlowType() {
		return flowType;
	}

	@Override
	public String getHeading() {
		return heading;
	}

	@Override
	public String getSummary() {
		return summary;
	}

	@Override
	public String getHelptext() {
		return helptext;
	}

	@Override
	public String getButtontext() {
		return buttontext;
	}

	/**
	 * @return the resourceMgmtProjection
	 */
	@Override
	public String getResourceMgmtProjection() {
		return activationFlowConfigService.getActivationResourceMgmtBasicProjection();
	}

	/**
	 * Get the esnUsedStatusCode
	 * 
	 * @return esnUsedStatusCode
	 */
	@Override
	public String getEsnUsedStatusCode() {
		// return activationFlowConfigService.getActivationResourceMgmtProjection();
		return "51";
	}

	/**
	 * Get the esnPastDueStatusCode
	 * 
	 * @return esnPastDueStatusCode
	 */
	@Override
	public String getEsnPastDueStatusCode() {
		// return activationFlowConfigService.getActivationResourceMgmtProjection();
		return "54";
	}

}