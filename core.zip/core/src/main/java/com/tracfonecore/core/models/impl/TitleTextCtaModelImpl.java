package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.TitleTextCtaModel;

import javax.annotation.PostConstruct;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.models.annotations.ExporterOption;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { TitleTextCtaModel.class,
    ComponentExporter.class }, resourceType = "tracfone-core/components/content/titletextcta", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
    @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
    @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class TitleTextCtaModelImpl extends BaseComponentModelImpl implements TitleTextCtaModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(TitleTextCtaModelImpl.class);

    @Self
    private SlingHttpServletRequest request;

    @ValueMapValue
    private String title;

    @ValueMapValue
    private String description;
    
    @ValueMapValue
    private String iconPath;

    @ValueMapValue
		private String showTitleAsH2;

    @ValueMapValue
		private String removeTitleFromImgTag;

    /** 
	 * @return String - exportedType
	 */
    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

    /** 
	 * @return String - title
	 */
    @Override
    public String getTitle() {
        return title;
    }

    /** 
	 * @return String - description
	 */
    @Override
    public String getDescription() {
        return description;
    }
	

    /**
	 * @return the iconPath
	 */
    @Override
	public String getIconPath() {
		return iconPath;
	}

  /**
	 * <p>
	 * Method to return show Title As H2
	 * </p>
	 * @return String showTitleAsH2
	 */
	@Override
	public String getShowTitleAsH2() {
		return showTitleAsH2;
	}

  /**
	 * <p>
	 * Method to return remove title from img tag
	 * </p>
	 * @return String removeTitleFromImgTag
	 */
	@Override
	public String getRemoveTitleFromImgTag() {
		return removeTitleFromImgTag;
	}

	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering initModel method");
			super.initModel();			
		LOGGER.debug("Exiting initModel method");
	}
    
}
