package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.NotifiedModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;
import com.tracfonecore.core.utils.ItemsExporterUtil;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.Map;


@Model(adaptables = {SlingHttpServletRequest.class, Resource.class}, adapters = {NotifiedModel.class,
        ComponentExporter.class}, resourceType = NotifiedModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true")})
public class NotifiedModelImpl implements NotifiedModel {

    private static final Logger LOGGER = LoggerFactory.getLogger(NotifiedModelImpl.class);
    protected static final String RESOURCE_TYPE = "tracfone-core/components/commerce/notifymodal";

    @Inject
    private Page currentPage;

    @Self
    private SlingHttpServletRequest request;

    @ScriptVariable
    private ValueMap properties;

    private ResourceResolver resolver;

    @Inject
    private SlingModelFilter slingModelFilter;

    @Inject
    private ModelFactory modelFactory;

    @Inject
    private Resource resource;

    private String notifyTitle;
    private String notifyBtn;
    private String notifyText;
    private String successText;
    private String emailLabel;
    private String preTextNotifyBtn;

    @Inject
    private TracfoneApiGatewayService tracfoneApiService;

    @Inject
    private ApplicationConfigService applicationConfigService;

    @PostConstruct
    protected void initModel() {
    		fetchPagePropertiesData();

    }

    private void fetchPagePropertiesData() {
        LOGGER.debug("Entering fetchPagePropertiesData method - Notified Model");

            resolver = resource.getResourceResolver();
            PageManager pm = resolver.adaptTo(PageManager.class);
            Page currentPage = pm.getContainingPage(resource);
            Page parentPage = currentPage.getParent();
            Page ancestorPage = (null != parentPage)? parentPage.getParent() : null;
            //Page rendingPage;

            properties = currentPage.getProperties();
            if (properties != null && properties.containsKey(CommerceConstants.NOTIFY_BUTTON) && !properties.get(CommerceConstants.NOTIFY_BUTTON, String.class).isEmpty()) {
                LOGGER.debug("Entering fetchPagePropertiesData method - Notified Model: current Page");
            } else if (null != parentPage) {
                properties = parentPage.getProperties();
                if (properties != null && properties.containsKey(CommerceConstants.NOTIFY_BUTTON) && !properties.get(CommerceConstants.NOTIFY_BUTTON, String.class).isEmpty()) {
                    LOGGER.debug("Entering fetchPagePropertiesData method - Notified Model: Parent Page");
                } else if (null != ancestorPage) {
                    properties = ancestorPage.getProperties();
                    LOGGER.debug("Entering fetchPagePropertiesData method - Notified Model: Ancestor Page");
                }
            }
            if (properties != null && ((properties.containsKey(CommerceConstants.NOTIFY_BUTTON) && !properties.get(CommerceConstants.NOTIFY_BUTTON, String.class).isEmpty())
                    || (properties.containsKey(CommerceConstants.NOTIFY_TEXT) && !properties.get(CommerceConstants.NOTIFY_TEXT, String.class).isEmpty())
                    || (properties.containsKey(CommerceConstants.SUCCESS_TEXT) && !properties.get(CommerceConstants.SUCCESS_TEXT, String.class).isEmpty())
                    || (properties.containsKey(CommerceConstants.NOTIFY_TITLE) && !properties.get(CommerceConstants.NOTIFY_TITLE, String.class).isEmpty())
                    || (properties.containsKey(CommerceConstants.EMAIL_LABEL) && !properties.get(CommerceConstants.EMAIL_LABEL, String.class).isEmpty()))) {

                setNotifyBtn(properties.get(CommerceConstants.NOTIFY_BUTTON, String.class));
                setNotifyText(properties.get(CommerceConstants.NOTIFY_TEXT, String.class));
                setSuccessText(properties.get(CommerceConstants.SUCCESS_TEXT, String.class));
                setNotifyTitle(properties.get(CommerceConstants.NOTIFY_TITLE, String.class));
                setEmailLabel(properties.get(CommerceConstants.EMAIL_LABEL, String.class));
            }
    }

    /**
     * @return int - homePageLevel
     */
    @Override
    public int getHomePageLevel() {

        return applicationConfigService.getHomePageLevel();
    }

    /**
     * @return String - language
     */
    public String getLanguage() {

        return CommerceUtil.getLanguage(currentPage, getHomePageLevel());
    }

    /**
     * @return String - language
     */
    @Override
    public String getBrand() {

        return CommerceUtil.getBrandValue(currentPage, getHomePageLevel());
    }

    /**
     * @return String -  clientID
     */
    @Override
    public String getClientID() {
    	 return ConfigurationUtil.getConfigValue(tracfoneApiService.getApiClientId(),
				CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
    }

    /**
     * @return String - apiDomain
     */
    @Override
    public String getApiDomain() {
        return tracfoneApiService.getApiDomain();
    }

    /**
     * @return String -  notifyApiPath
     */
    @Override
    public String getNotifyApiPath() {
        return tracfoneApiService.getNotifyApiPath();
    }


    private void setNotifyTitle(String notifyTitle) {
        this.notifyTitle = notifyTitle;
    }

    public void setNotifyBtn(String notifyBtn) {
        this.notifyBtn = notifyBtn;
    }

    public void setNotifyText(String notifyText) {
        this.notifyText = notifyText;
    }

    public void setSuccessText(String successText) {
        this.successText = successText;
    }

    public void setEmailLabel(String emailLabel) {
        this.emailLabel = emailLabel;
    }

    @Override
    public String getNotifyText() {
        return notifyText;
    }

    @Override
    public String getNotifyBtn() {
        return notifyBtn;
    }

    @Override
    public String getPreTextNotifyMeBtn() {
        return preTextNotifyBtn;
    }

    @Override
    public String getSuccessText() {
        return successText;
    }

    @Override
    public String getNotifyTitle() {
        return notifyTitle;
    }

    @Override
    public String getEmailLabel() {
        return emailLabel;
    }

    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

    /**
     * @return
     */
    public Map<String, ? extends ComponentExporter> getItems() {
        return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
    }
}
