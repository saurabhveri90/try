package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.DiscountCardAccordionBean;
import com.tracfonecore.core.beans.DiscountCardsBean;
import com.tracfonecore.core.models.DiscountsAndBundlesModel;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { DiscountsAndBundlesModel.class,
    ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/discountsandbundles", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
    @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
    @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class DiscountsAndBundlesModelImpl implements DiscountsAndBundlesModel {

    private String CARDS_MULTIFIELD = "cardsList";
    private String ACCORDION_MULTIFIELD = "accordionList";

    @Self
	private SlingHttpServletRequest request;

    @Inject
	private Resource resource;

    @ValueMapValue
	private String heading;

    @ValueMapValue
	private String subheading;

    @ValueMapValue
	private String footerText;

	private List<DiscountCardsBean> cardsList = Collections.emptyList();

    @PostConstruct
	private void initModel() {
		cardsList = new ArrayList<>();
		if (resource != null) {
			Iterator<Resource> it = getMultifieldResource(resource, CARDS_MULTIFIELD);
            if (it != null) {
                setCardsList(it);
            }
		}
	}
	
    /**
     * Get the multifield node
     * @param parentResource - resource to check for multifield node in children
     * @param nodeName - name of multifield node to check for
     * @return - iterator for the multifield
     */
	private Iterator<Resource> getMultifieldResource(Resource parentResource, String nodeName) {
        Iterator<Resource> finalIterator = null;
		for (Resource child : parentResource.getChildren()) {
			Iterator<Resource> it = child.listChildren();
			if (StringUtils.isNotBlank(child.getName()) && nodeName != null && nodeName.equals(child.getName())) {
                finalIterator = it;
                break;
            }
		}
        return finalIterator;
	}

    /**
     * Set the cards list from multifield iterator
     * @param it - multifield iterator
     */
	private void setCardsList(Iterator<Resource> it) {
		while (it.hasNext()) {
			DiscountCardsBean discountCardsBean = new DiscountCardsBean();
			Resource child = it.next();
            ValueMap childVM = child.getValueMap();
			discountCardsBean.setCardTitle(childVM.get("cardTitle", String.class));
			discountCardsBean.setCardIcon(childVM.get("cardIcon", String.class));
            discountCardsBean.setCardSummary(childVM.get("cardSummary", String.class));
			discountCardsBean.setCardDisclaimers(childVM.get("cardDisclaimers", String.class));
            Iterator<Resource> accordionIterator = getMultifieldResource(child, ACCORDION_MULTIFIELD);
            if (accordionIterator != null) {
                setAccordionList(accordionIterator, discountCardsBean);
            }
            cardsList.add(discountCardsBean);
		}
	}

    /**
     * Set Accordion multifield within card bean
     * @param it - accordion multifield iterator
     * @param discountCardsBean - discount card bean
     */
    private void setAccordionList(Iterator<Resource> it, DiscountCardsBean discountCardsBean) {
        List<DiscountCardAccordionBean> accordionList = new ArrayList<DiscountCardAccordionBean>();
        while (it.hasNext()) {
            DiscountCardAccordionBean accordionBean = new DiscountCardAccordionBean();
            Resource child = it.next();
            ValueMap childVM = child.getValueMap();
            accordionBean.setAccordionTitle(childVM.get("accordionTitle", String.class));
            accordionBean.setAccordionText(childVM.get("accordionText", String.class));
            accordionList.add(accordionBean);
        }
        if (!accordionList.isEmpty()) {
            discountCardsBean.setAccordionList(accordionList);
        }
    }

    /**
	 * Fetches exported type
	 * @return exported type
	 */
    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

    /**
	 * Fetches heading
	 * @return heading
	 */
    @Override
    public String getHeading() {
        return heading;
    }

    /**
	 * Fetches subheading
	 * @return subheading
	 */
    @Override
    public String getSubheading() {
        return subheading;
    }

    /**
	 * Fetches footerText
	 * @return footerText
	 */
    @Override
    public String getFooterText() {
        return footerText;
    }
    
    /**
	 * Fetches cardsList
	 * @return cardsList
	 */
    @Override
    public List<DiscountCardsBean> getCardsList() {
        return new ArrayList<DiscountCardsBean>(cardsList);
    }
    
}