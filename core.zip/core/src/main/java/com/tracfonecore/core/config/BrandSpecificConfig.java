package com.tracfonecore.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Brand Specific Config Service", description = "Brand Specific Config Service")
public @interface BrandSpecificConfig {

	@AttributeDefinition(name = "Hide Login Security Questions", description = "Please provide true/false value to hide/show login security questions")
	String[] hideLoginSecurityQuestions() default { "STRAIGHT_TALK:false", "TRACFONE:false", "TOTAL_WIRELESS:true" };

	@AttributeDefinition(name = "Disable Add-On Plan Radio Selection For 1 Cart Option", description = "Disables radio buttons for add-on plans when only 1 option exists")
	String[] disableCartOptionsRadio() default { "STRAIGHT_TALK:false", "TRACFONE:false", "TOTAL_WIRELESS:true" };

	@AttributeDefinition(name = "Enable Multiline Plans", description = "Enables the use of multiline plan for the brand")
	String[] enableMultilinePlans() default { "STRAIGHT_TALK:false", "TRACFONE:false", "TOTAL_WIRELESS:true" };

	@AttributeDefinition(name = "Disable HPP", description = "Disable HPP for the brand")
	String[] disableHpp() default { "STRAIGHT_TALK:false", "TRACFONE:false", "TOTAL_WIRELESS:false" };

	@AttributeDefinition(name = "Enable Add Device To Account in Reactivation", description = "Enable Add Device To Account call in Reactivation flow")
	String[] enableAddDeviceToAccountInReactivation() default { "STRAIGHT_TALK:false", "TRACFONE:false",
			"TOTAL_WIRELESS:true" };

	@AttributeDefinition(name = "Use Incremental Quantity", description = "Enables the use of incremental quantity for the brand")
	String[] useIncrementalQuantity() default { "STRAIGHT_TALK:false", "TRACFONE:false", "TOTAL_WIRELESS:true" };

	@AttributeDefinition(name = "Disable SSO Authentication", description = "Disable SSO")
	String[] disableSSOAuthentication() default { "STRAIGHT_TALK:false", "TRACFONE:false", "TOTAL_WIRELESS:true" };

	@AttributeDefinition(name = "Check Account Level AutoRefill", description = "Check Account Level AutoRefill in resource-mgmt response for shop flow")
	String[] checkAccountLevelAutoRefill() default { "STRAIGHT_TALK:true", "TRACFONE:false", "TOTAL_WIRELESS:false" };

	@AttributeDefinition(name = "Enable Account Capacity Check", description = "Enable account capacity check for purchase, refill, and activation.")
	String[] enableAccountCapacityCheck() default { "STRAIGHT_TALK:true", "TRACFONE:false", "TOTAL_WIRELESS:true" };

	@AttributeDefinition(name = "Enable Multiple Refill In Purchase", description = "Enable refill for multiple lines at once.")
	String[] enableMultipleRefillInPurchase() default { "STRAIGHT_TALK:true", "TRACFONE:false", "TOTAL_WIRELESS:true" };

	@AttributeDefinition(name = "Enable Refill Flow Proposals", description = "Enable refill flow proposals.")
	String[] enableRefillFlowProposals() default { "STRAIGHT_TALK:true", "TRACFONE:false", "TOTAL_WIRELESS:false" };

	@AttributeDefinition(name = "Enable Second Pin Api", description = "Enable second pin Api.")
	String[] enableSecondPinApi() default { "STRAIGHT_TALK:true", "TRACFONE:false", "TOTAL_WIRELESS:false" };

	@AttributeDefinition(name = "Hpp MicroService Product Offering", description = "Call Hpp MicroService Product Offering")
	String[] callHppMicroServiceProductOffering() default { "STRAIGHT_TALK:true", "TRACFONE:false",
			"TOTAL_WIRELESS:true" };

	@AttributeDefinition(name = "Claw Back Instructions For Offers", description = "Claw Back Instructions for different types of Offers(Add all offer type separeted with | symbol)")
	String[] clawBackInstrForOffers() default { "TOTAL_WIRELESS:PORT_IN" };

	@AttributeDefinition(name = "Port In Screen changes", description = "Port In screen changes for elements realignment and addition of new fields")
	String[] portInScreenChanges() default { "STRAIGHT_TALK:false", "TRACFONE:false", "TOTAL_WIRELESS:true" };

	@AttributeDefinition(name = "Promotional offer type list for sort", description = "Promotional phone offer type list for sort(Add all offer type separeted with | symbol)")
	String[] promotionalOfferTypeForSort() default { "STRAIGHT_TALK:VERIFF_ONLY|PORT_IN_ONLY|ACTIVATION_ONLY",
			"TRACFONE:VERIFF_ONLY|PORT_IN_ONLY|ACTIVATION_ONLY",
			"TOTAL_WIRELESS:VERIFF_ONLY|PORT_IN_ONLY|ACTIVATION_ONLY" };
}
