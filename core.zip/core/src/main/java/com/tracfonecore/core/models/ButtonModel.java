/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;


import com.adobe.cq.wcm.core.components.models.Button;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface ButtonModel extends Button {

	/**
	 * <p>Fetches link target</p>
	 * 
	 * @return String - link target
	 */
	@JsonProperty("target")
	public String getTarget();

	/**
	 * <p>Fetches link no-follow</p>
	 * 
	 * @return String - link no-follow
	 */
	@JsonProperty("donotfollowlink")
	public String getDonotfollowlink();

	/**
	 * <p>Fetches placement text</p>
	 * 
	 * @return String - placement text
	 */
	@JsonProperty("placementText")
	public String getPlacementText();
	
	/**
	 * <p>Fetches btnPlacement text</p>
	 * 
	 * @return String - btn placement text
	 */
	@JsonProperty("btnPlacementText")
	public String getBtnPlacementText();
	
	/**
	 * <p>Fetches CTA Type</p>
	 * 
	 * @return String - CTA Type
	 */
	@JsonProperty("ctaType")
	public String getCtaType();
	
	/**
	 * <p>Fetches Modal ID</p>
	 * 
	 * @return String - Modal ID
	 */
	@JsonProperty("modalID")
	public String getModalID();
	
	/**
	 * <p>Fetches Event Name</p>
	 * 
	 * @return String - Event Name
	 */
	@JsonProperty("eventName")
	public String getEventName();
	/**
	 *<p>Fetches eventLink</p>
	 *
	 * @return the eventLink
	 */
	@JsonProperty("eventLink")
	public String getEventLink();

	/**
	 * @return the useAsHyperlink
	 */
	@JsonProperty("useAsHyperlink")
	public Boolean getUseAsHyperlink();

	/**
	 * @return the chatnowContainerId
	 */
	@JsonProperty("chatnowContainerId")
	public String getChatnowContainerId();

	/**
	 * <p>Fetches link multiPlanSelection</p>
	 * 
	 * @return String - link multiPlanSelection
	 */
	@JsonProperty("multiPlanSelection")
	public String getMultiPlanSelection();
	

}