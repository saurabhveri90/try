  /**
 * Copyright 2020 HCL Technologies Ltd.
 */
package com.tracfonecore.core.models.impl;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;

import javax.inject.Inject;

import com.day.cq.wcm.api.Page;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.UserGroupsInfoModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.utils.CommerceUtil;

/**
 * User Groups Model Implementation
 *
 */
@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { UserGroupsInfoModel.class,
		ComponentExporter.class }, resourceType = UserGroupsInfoModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class UserGroupsInfoModelImpl implements UserGroupsInfoModel {

	protected static final String RESOURCE_TYPE = "tracfone-core/components/commerce/usergroups";
	
	@Inject
	protected Page currentPage;

	@Inject
	private ApplicationConfigService applicationConfigService;
	
	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue
	private String heading;
		
	@ValueMapValue
	private String summary;

	@ValueMapValue
	private String devices;

	@ValueMapValue
	private String image;

	@ValueMapValue
	private String imageAltText;

	@ValueMapValue
	private String servicedaystext;

	@ValueMapValue
	private String plandatatext;

	@ValueMapValue
	private String enddate;

	@ValueMapValue
	private String accessibilityLabel;

	@ValueMapValue
	private String radiobutton;

	@ValueMapValue
	private String usedLinesText;
		
	@ValueMapValue
	private String buttontext;

	/**
	 * <p>Fetches heading</p>
	 * 
	 * @return String - heading
	 */
	@Override
	public String getHeading() {
		return this.heading;
	}

	/**
	 * <p>Fetches summary</p>
	 * 
	 * @return String - summary
	 */
	@Override
	public String getSummary() {
		return this.summary;
	}

	/**
	 * <p>Fetches image</p>
	 * 
	 * @return String - image
	 */
	@Override
	public String getImage() {
		return this.image;
	}

	/**
	 * <p>Fetches imageAltText</p>
	 * 
	 * @return String - imageAltText
	 */
	@Override
	public String getImageAltText() {
		return this.imageAltText;
	}

	/**
	 * <p>Fetches servicedaystext</p>
	 * 
	 * @return String - servicedaystext
	 */
	@Override
	public String getServicedaystext() {
		return this.servicedaystext;
	}

	/**
	 * <p>Fetches devices</p>
	 * 
	 * @return String - devices
	 */
	@Override
	public String getDevices() {
		return this.devices;
	}

	/**
	 * <p>Fetches accessibilityLabel</p>
	 * 
	 * @return String - accessibilityLabel
	 */
	@Override
	public String getAccessibilityLabel() {
		return this.accessibilityLabel;
	}

	/**
	 * <p>Fetches plandatatext</p>
	 * 
	 * @return String - plandatatext
	 */
	@Override
	public String getPlandatatext() {
		return this.plandatatext;
	}

	/**
	 * <p>Fetches radiobutton</p>
	 * 
	 * @return String - radiobutton
	 */
	@Override
	public String getRadiobutton() {
		return this.radiobutton;
	}

	/**
	 * <p>Fetches enddate</p>
	 * 
	 * @return String - enddate
	 */
	@Override
	public String getEnddate() {
		return this.enddate;
	}
	
	/**
	 * <p>Fetches usedLinesText</p>
	 * 
	 * @return String - usedLinesText
	 */
	@Override
	public String getUsedLinesText() {
		return this.usedLinesText;
	}

	/**
	 * <p>Fetches buttontext</p>
	 * 
	 * @return String - buttontext
	 */
	@Override
	public String getButtontext() {
		return this.buttontext;
	}
	
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getQueryString(){
		String query = StringUtils.EMPTY;
		String plpPagePath = CommerceUtil.getPagePropertyValue(currentPage, applicationConfigService.getHomePageLevel(), CommerceConstants.PLANS_PAGE_PATH).toString();
		ResourceResolver resourceResolver = request.getResourceResolver();
		if(resourceResolver.getResource(plpPagePath) != null){
			Page plpPage = resourceResolver.getResource(plpPagePath).adaptTo(Page.class);
			if(plpPage != null){
				String categoryId = plpPage.getContentResource().getValueMap().get(CommerceConstants.CATEGORY_ID, String.class);
				if(categoryId != null){
					query = new StringBuilder(CommerceConstants.SEARCH_KEY_WORD).append(CommerceConstants.AMPERSAND)
					.append(CommerceConstants.CATEGORY_ID).append(CommerceConstants.EQUALS_TO).append(categoryId).toString();
				}
			}	
		}
		return query;
	}
}

 