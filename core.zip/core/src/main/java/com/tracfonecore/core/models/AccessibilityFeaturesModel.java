package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.sling.api.resource.Resource;

/**
 * Defines the {@code accessibilityfeatures} Sling Model used for the {@code /apps/tracfone-core/components/content/accessibilityfeatures} component.
 */
public interface AccessibilityFeaturesModel extends ComponentExporter {

    /**
     * <p>Fetches label of the Accessibility Features Component</p>
     *
     * @return String - label of the accessibility features
     */
    @JsonProperty("label")
    public String getLabel();

    /**
     * <p>Fetches Accessibility Phone Features List</p>
     *
     * @return Resource - Accessibility Phone Features List
     */
    @JsonProperty("accPhoneFeatures")
    public Resource getAccPhoneFeatures();

    /**
     * <p>Fetches summary Accessibility Devices based on operating systems.</p>
     *
     * @return String - summary of the accessibility devices.
     */
    @JsonProperty("accDevicesSummary")
    public String getAccDevicesSummary();

    /**
     * <p>Fetches sub summary Accessibility Devices based on operating systems.</p>
     *
     * @return String - sub summary of the accessibility devices.
     */
    @JsonProperty("accDevicesSummarySub")
    public String getAccDevicesSummarySub();

    /**
     * <p>Fetches sub summary link Accessibility Devices based on operating systems.</p>
     *
     * @return String - sub summary link of the accessibility devices.
     */
    @JsonProperty("accDevicesSummarySubLink")
    public String getAccDevicesSummarySubLink();

    /**
     * <p>Fetches sub summary link label Accessibility Devices based on operating systems.</p>
     *
     * @return String - sub summary link label of the accessibility devices.
     */
    @JsonProperty("accDevicesSummarySubLinkLabel")
    public String getAccDevicesSummarySubLinkLabel();

    /**
     * <p>Fetches no-follow value for sub summary link</p>
     *
     * @return String - sub summary link no-follow value
     */
    @JsonProperty("doNotFollow")
    public String getDoNotFollow();

    /**
     * <p>Fetches Accessibility Device Info links</p>
     *
     * @return Resource - Accessibility Device Info Links
     */
    @JsonProperty("accDeviceInfoLinks")
    public Resource getAccDeviceInfoLinks();

}
