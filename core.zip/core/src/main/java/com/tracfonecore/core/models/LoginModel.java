package com.tracfonecore.core.models;

import org.osgi.annotation.versioning.ProviderType;

import com.adobe.cq.export.json.ComponentExporter;

/**
 *
 * @author HCL
 * Defines the {@code Login} Sling Model used for the {@code /apps/tracfone-core/components/commerce/login} component.
 *
 */

@ProviderType
public interface LoginModel extends ComponentExporter {

    /**
     * Get the screenType
     * @return String - screenType
     */
    public String getScreenType();

    /**
     * Get the headerText
     * @return String - headerText
     */
    public String getHeaderText();

    /**
     * Get the accessibilityText
     * @return String - accessibilityText
     */
    public String getAccessibilityText();

    /**
     * Get the summary
     * @return String - summary
     */
    public String getSummary();

    /**
     * Get the enabletooltip
     * @return String - enabletooltip
     */
    public String getEnabletooltip();

    /**
     * Get the learnMoreModalContent
     * @return String - learnMoreModalContent
     */
    public String getLearnMoreModalContent();

    /**
     * Get the forgotPasswordLink
     * @return String - forgotPasswordLink
     */
    public String getForgotPasswordLink();

    /**
     * Get the disableCaptcha
     * @return String - disableCaptcha
     */
    public String getDisableCaptcha();

    /**
     * Get the disableEnterpriseCaptcha
     * @return String - disableEnterpriseCaptcha
     */
    public String getDisableEnterpriseCaptcha();

    /**
     * Get the disableFacebook
     * @return String - disableFacebook
     */
    public String getDisableFacebook();

    /**
     * Get the disableChat
     * @return String - disableChat
     */
    public String getDisableChat();

    /**
     * Get the chatIconLink
     * @return String - chatIconLink
     */
    public String getChatIconLink();

    /**
     * Get the chatButtonText
     * @return String - chatButtonText
     */
    public String getChatButtonText();

    /**
     * Get the chatButtonLink
     * @return String - chatButtonLink
     */
    public String getChatButtonLink();

    /**
     * Get the loginPswScreenLink
     * @return String - loginPswScreenLink
     */
    public String getLoginPswScreenLink();

    /**
     * Get the accessAccountLink
     * @return String - accessAccountLink
     */
    public String getAccessAccountLink();

    /**
     * Get the securityPinScreenLink
     * @return String - securityPinScreenLink
     */
    public String getSecurityPinScreenLink();

    /**
     * Get the securityQuestionScreenLink
     * @return String - securityQuestionScreenLink
     */
    public String getSecurityQuestionScreenLink();

    /**
     * Get the securityPinQuestionScreenLink
     * @return String - securityPinQuestionScreenLink
     */
    public String getSecurityPinQuestionScreenLink();

    /**
     * Get the phoneNumberScreenLink
     * @return String - phoneNumberScreenLink
     */
    public String getPhoneNumberScreenLink();

    /**
     * Get the zipCodeScreenLink
     * @return String - zipCodeScreenLink
     */
    public String getZipCodeScreenLink();

    /**
     * Get the myAccountUrl
     * @return String - myAccountUrl
     */
    public String getMyAccountUrl();

    /**
     * Get the loginXfpath
     * @return String - loginXfpath
     */
    public String getLoginXfPath();
    /**
     * Get the reCaptchaSiteKey
     * @return String - reCaptchaSiteKey
     */
    public String getReCaptchaSiteKey();

    /**
     * Get the reCaptchaSiteKey
     * @return String - reCaptchaSiteKey
     */
    public String getReCaptchaEnterpriseSiteKey();

    /**
     * Get the tealiumEnvNam
     * @return String - tealiumEnvNam
     */
    public String getTealiumEnvName();

    /**
     * Get the homePageLevel
     * @return String - homePageLevel
     */
    public int getHomePageLevel();

    /**
     * @return the alreadyFbLoggedinScreenLink
     */
    public String getAlreadyFbLoggedinScreenLink();

    /**
     * @return the alreadyFbLoggedinPwdScreenLink
     */
    public String getAlreadyFbLoggedinPwdScreenLink();

    /**
     * @return the linkAccountPwdScreenLink
     */
    public String getLinkAccountPwdScreenLink();

    /**
     * @return the selectEmailScreenLink
     */
    public String getSelectEmailScreenLink();

    /**
     * @return the selectVerifyEmailScreenLink
     */
    public String getSelectVerifyEmailScreenLink();


    /**
     * @return the dummyAccountVerifyEmailScreenLink
     */
    public String getDummyAccountVerifyEmailScreenLink();

    /**
     * @return the verificationCodeZipScreenLink
     */
    public String getVerificationCodeZipScreenLink();

    /**
     * @return the registerUpdateScreenLink
     */
    public String getRegisterUpdateScreenLink();

    /**
     * Get the registerSuccessScreenLink
     * @return String - registerSuccessScreenLink
     */
    public String getRegisterSuccessScreenLink();

    /**
     * Get the loginOTCVerificationScreenLink
     * @return String - loginOTCVerificationScreenLink
     */
    public String getLoginOTCVerificationScreenLink();

    /**
     * Get the notEnrolledLink
     * @return String - notEnrolledLink
     */
    public String getNotEnrolledLink();

    /**
     * Get the postLogoutRedirectUrl
     * @return String - postLogoutRedirectUrl
     */
    public String getPostLogoutRedirectUrl();

    /**
     * Get the hideLoginSecurityQuestions value from config
     * @return String - hideLoginSecurityQuestions
     */
    public String getHideLoginSecurityQuestions();

    /**
     * Get the accountCreationWithZipCode
     * @return String - accountCreationWithZipCode
     */
    public String getAccountCreationWithZipCode();

    /**
     * Get the summaryDummyUser
     * @return String - summaryDummyUser
     */
    public String getSummaryDummyUser();

}
