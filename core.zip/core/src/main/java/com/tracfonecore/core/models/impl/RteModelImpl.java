/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;



import javax.annotation.PostConstruct;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.RteModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { RteModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/rte", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class RteModelImpl extends BaseComponentModelImpl implements RteModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(RteModelImpl.class);

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;

	@ValueMapValue
	private String cssWrapperClass;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String rteText;
		
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String includeInlineDisclaimer;
	
	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering initModel method");
		super.initModel();	
		LOGGER.debug("Exiting initModel method");
	}

	@Override
	public String getRteText() {
		return rteText;
	}
		
	@Override
	public String getIncludeInlineDisclaimer() {
		return includeInlineDisclaimer;
	}

	@Override
	public String getCssWrapperClass() {
		return cssWrapperClass;
	}
	
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
}