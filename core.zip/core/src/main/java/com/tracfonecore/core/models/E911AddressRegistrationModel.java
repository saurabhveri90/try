package com.tracfonecore.core.models;

import org.osgi.annotation.versioning.ProviderType;
import com.adobe.cq.export.json.ComponentExporter;

/**
 * 
 * @author HCL
 * Defines the {@code E911 Address Registration} Sling Model used for the {@code /apps/tracfone-core/components/commerce/e911addressregistration} component.
 *
 */

@ProviderType
public interface E911AddressRegistrationModel extends ComponentExporter {
    
    /**
     * Get the E911Title
     * @return String - e911Title
     */
    public String getE911Title();  
 
    /**
     * Get the e911Description
     * @return String - e911Description
     */
    public String getE911Description();  
    
    /**
     * Get the e911AddressLabel
     * @return String - e911AddressLabel
     */
    public String getE911AddressLabel();  
    
     /**
     * Get the e911AddressAccessibleText
     * @return String - e911AddressAccessibleText
     */
    public String getE911AddressAccessibleText();  
    

    /**
     * Get the aptUnitSuitAccessibleText
     * @return String - aptUnitSuitAccessibleText
     */
    public String getAptUnitSuitAccessibleText();  

    /**
     * Get the aptUnitSuitlabel
     * @return String - aptUnitSuitlabel
     */
    public String getAptUnitSuitlabel();  

    
    /**
     * Get the buttonlabel
     * @return String - buttonlabel
     */
    public String getButtonlabel();

    /**
     * Get the buttonaccessibletext
     * @return String - buttonAccessibleText
     */
    public String getButtonAccessibleText();
    
    
}
