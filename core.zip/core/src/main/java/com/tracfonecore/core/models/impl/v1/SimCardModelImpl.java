/*
 *  Copyright 2020 HCL Technologies Ltd.
 *
 */
package com.tracfonecore.core.models.impl.v1;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.xss.XSSAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.SimCardModel;
import com.tracfonecore.core.models.impl.BaseComponentModelImpl;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.DynamicMediaConfigService;
import com.tracfonecore.core.services.ProductOfferingApiService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.services.TracfoneValueMappingConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { SimCardModel.class,
		ComponentExporter.class }, resourceType = {SimCardModelImpl.RESOURCE_TYPE_V1}, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class SimCardModelImpl extends BaseComponentModelImpl implements SimCardModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(SimCardModelImpl.class);

	// constants
	protected static final String RESOURCE_TYPE_V1 = "tracfone-core/components/commerce/simcard/v1/simcard";

	@Inject
	private Page currentPage;

	@Inject
	private XSSAPI xssApi;

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private DynamicMediaConfigService dynamicMediaConfig;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	protected String selection;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String promotext;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String simname;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean hideRating;

	@ValueMapValue
	@Default(booleanValues = false)
	private Boolean isTabletSim;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String pricedescription;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	protected String simthumbnailimage;

	protected JsonArray skusArray;
	
	protected String skuId;

	protected String thumbnailImageAssetId;

	protected String thumbnailImageAssetAgencyId;

	protected String allowGuestCheckout = "";

	protected String marketingIds;

	@Inject
	protected TracfoneApiGatewayService tracfoneApiService;

	@Inject
	protected ApplicationConfigService applicationConfigService;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	protected String type;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	protected String pdpPagePath;

	protected SimCardModel simCardModel;
	
	@Inject
	protected Resource resource;

	@Inject
	protected TracfoneValueMappingConfigService tracfoneValueMappingConfigService;
	
	@Inject
	protected ProductOfferingApiService productOfferingApiService;
	
	protected JsonObject product = null;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hidePriceSimCardDetails;

    @ValueMapValue
    private String iconPath;

	/**
	 * <p>
	 * Init method : Calls the product api with part number authored and sets sim
	 * data in product field.
	 * </p>
	 *
	 */
	@PostConstruct
	protected void initModel() {
		LOGGER.info("Entering init method of SimCardModelImpl");
		
		if (StringUtils.isNotEmpty(type) && StringUtils.equalsIgnoreCase("dynamic", type)
				&& StringUtils.isNotEmpty(pdpPagePath)) {
			Resource simCardResource = request.getResource().getResourceResolver().getResource(pdpPagePath+CommerceConstants.SIM_DETAIL_NODE_PATH_V1);
			simCardModel = simCardResource.adaptTo(SimCardModel.class);
		}else {
			super.initModel();
			String currentDateTime;
				/*
					* If the current page is null for any reason then find the currentPage for the
					* resource's containing page.
					*/
				if (currentPage == null && resource != null) {
					currentPage = resource.getResourceResolver().adaptTo(PageManager.class).getContainingPage(resource);
				}
				LOGGER.debug("SimCardModelImpl: selection part no. {}", selection);
				currentDateTime = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SS")
						.format(Calendar.getInstance().getTime());
				LOGGER.debug("SimCardModelImpl: Product Offering API call starts, time: {}", currentDateTime);

				this.product = productOfferingApiService.getProductDetailObject(selection, currentPage);
				
				currentDateTime = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SS")
						.format(Calendar.getInstance().getTime());
				LOGGER.debug("SimCardModelImpl: Product Offering API call ends, time: {}", currentDateTime);			
				
				getProductCharacteristics();
				getSKUDetails();
				this.setThumbnailImageAssetId(ApplicationUtil.getAssetId(simthumbnailimage,
					resource.getResourceResolver(), ApplicationConstants.IMAGE));
				this.setThumbnailImageAssetAgencyId(ApplicationUtil.getAssetMetaDataValue(simthumbnailimage,
					resource.getResourceResolver(), ApplicationConstants.WEBER_ID));
				
				LOGGER.debug("Exiting init method of SimCardModelImpl");
		}
	}

	/**
	 * filter the description from output
	 * 
	 * @return String - description html
	 */
	protected String safeDescription(JsonObject product) {
		if (product != null && product.get("detailedDescription")!=null) {
			String description = product.get("detailedDescription").getAsString();
			if (description == null) {
				return null;
			}
			return xssApi.filterHTML(description);
		}
		return null;
	}

	/**
	 * @return String - description
	 */
	public String getDescription() {
		return safeDescription(product);
	}

	/**
	 * <p>
	 * Returns id from API response
	 * </p>
	 * 
	 * @return Integer - id from api response
	 */
	public Integer getId() {
		if (product != null && product.get(CommerceConstants.ID)!=null) {
			return product.get(CommerceConstants.ID).getAsInt();
		}
		return null;
	}

	/**
	 * <p>
	 * Returns name from API response
	 * </p>
	 * 
	 * @return String - name
	 */
	@Override
	public String getName() {
		if (product != null && product.get(CommerceConstants.NAME)!=null) {
			return product.get(CommerceConstants.NAME).getAsString();
		}
		return null;
	}
	
	/**
	 * <p>
	 * Returns name post converting to lower case from API response
	 * </p>
	 * 
	 * @return String - productNameForAnalytics
	 */
	@Override
	public String getProductNameForAnalytics() {	
		if (product != null && product.get(CommerceConstants.NAME)!=null) {
			return ApplicationUtil.getLowerCaseWithUnderScore(product.get(CommerceConstants.NAME).getAsString());
		}
		return StringUtils.EMPTY;	
	}

	/**
	 * <p>
	 * Sets sim data from product characteristics from API
	 * response
	 * </p>
	 * 
	 * @return void
	 */
	private void getProductCharacteristics() {
		LOGGER.debug("Entering getProductCharacteristics method");
		if (product != null && product.get(CommerceConstants.PRODUCT_CHARACTERISTICS)!=null &&product.get(CommerceConstants.PRODUCT_CHARACTERISTICS).isJsonArray()) {
			JsonArray jsonArray = product.get(CommerceConstants.PRODUCT_CHARACTERISTICS).getAsJsonArray();
			if (jsonArray.size() > 0) {
				for (int i = 0; i < jsonArray.size(); i++) {
					String key = jsonArray.get(i).getAsJsonObject().get(CommerceConstants.IDENTIFIER).getAsString();
					if (key.equalsIgnoreCase(CommerceConstants.ALLOW_GUEST_CHECKOUT)) {

						allowGuestCheckout = jsonArray.get(i).getAsJsonObject().get(CommerceConstants.VALUE)
								.getAsString();
						LOGGER.debug("Allow Guest Checkout value {}", allowGuestCheckout);
					} else if (key.equalsIgnoreCase(CommerceConstants.MARKET)) {

						marketingIds = jsonArray.get(i).getAsJsonObject().get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Marketign IDs value {}", marketingIds);
					}
				}
			}

			LOGGER.debug("Exiting getProductCharacteristics method");
		}
	}

	/**
	 * <p>
	 * Returns brand from API response
	 * </p>
	 * 
	 * @return String - brand
	 */
	@Override
	public String getBrand() {

		if (product != null && product.get(CommerceConstants.BRAND) != null) {
			LOGGER.debug("Query response {}", product.get(CommerceConstants.BRAND).getAsString());
			return product.get(CommerceConstants.BRAND).getAsString();
		}
		return null;
	}

	/**
	 * <p>
	 * Returns make from API response
	 * </p>
	 * 
	 * @return String - make
	 */
	@Override
	public String getMake() {
		String val = StringUtils.EMPTY;
		if (product != null && product.get(CommerceConstants.MAKE) != null) {
			val = product.get(CommerceConstants.MAKE).getAsString();
		}
		return val;
	}

	/**
	 * <p>
	 * Returns ratings from API response
	 * </p>
	 * 
	 * @return String - ratings
	 */
	@Override
	public String getRating() {

		String rating = "0.0";

		if (product != null && product.get(CommerceConstants.RATINGS) != null && StringUtils.isNotBlank(product.get(CommerceConstants.RATINGS).getAsString())) {
			rating = product.get(CommerceConstants.RATINGS).getAsString();
			LOGGER.debug("Sim ratings value {}", rating);
		}
		return rating;
	}

	/**
	 * <p>
	 * Format rating and remove trailing zeros
	 * </p>
	 * 
	 * @return String - rating without trailing zero
	 * 
	 */
	@Override
	public String getAccessibilityRating() {
		DecimalFormat format = new DecimalFormat(ApplicationConstants.TRAILING_ZERO);
		String accessibilityRating = getRating();
		if (StringUtils.isNotBlank(accessibilityRating)) {
			double ratingval = Double.parseDouble(getRating());
			accessibilityRating = format.format(ratingval);
		}
		return accessibilityRating;
	}

	/**
	 * <p>
	 * Returns reviews from API response
	 * </p>
	 * 
	 * @return String - reviews
	 */
	@Override
	public String getReviews() {
		String reviews = "0";

		if (product != null && product.get(CommerceConstants.REVIEWS) != null && StringUtils.isNotBlank(product.get(CommerceConstants.REVIEWS).getAsString())) {
			reviews = product.get(CommerceConstants.REVIEWS).getAsString();
			LOGGER.debug("Sim reviews value {}", reviews);
		}
		return reviews;
	}

	/**
	 * <p>
	 * Returns promo text authored
	 * </p>
	 * 
	 * @return String - promotext
	 */
	@Override
	public String getPromoText() {

		return promotext;
	}

	/**
	 * <p>
	 * Returns the value of isTabletSim checkbox
	 * </p>
	 *
	 * @return true if isTabletSim is checked, false otherwise
	 */
	@Override
	public boolean isTabletSim() {
		return isTabletSim;
	}

	/**
	 * <p>
	 * Returns Sim name authored
	 * </p>
	 * 
	 * @return String - simname
	 */
	@Override
	public String getSimName() {
		return simname;
	}

	/**
	 * <p>
	 * Returns price description authored
	 * </p>
	 * 
	 * @return String - pricedescription
	 */
	@Override
	public String getPriceDescription() {
		return pricedescription;
	}

	/**
	 * <p>
	 * Returns sim data description authored
	 * </p>
	 * 
	 * @return String - simthumbnailimage
	 */
	@Override
	public String getSimthumbnailimage() {
		return DynamicMediaUtils.changeMediaPathToDMPath(simthumbnailimage, resource.getResourceResolver());
	}

	/**
	 * <p>
	 * Returns selection authored
	 * </p>
	 * 
	 * @return String - selection
	 */
	@Override
	public String getSelection() {
		return selection;
	}

	/**
	 * <p>
	 * Returns exporter type
	 * </p>
	 * 
	 * @return String - getexportertype
	 */
	@Override
	public String getExportedType() {

		return resource.getResourceType();
	}

	/**
	 * <p>
	 * Returns SimCardModel
	 * </p>
	 * 
	 * @return SimCardModel - getSimCardModel
	 */
	@Override
	public SimCardModel getSimCardModel() {
		return simCardModel;
	}

	/**
	 * <p>
	 * Returns hide Rating value authored
	 * </p>
	 * 
	 * @return Boolean - hideRating
	 */
	@Override
	public Boolean getHideRating() {
		return hideRating;
	}

	/**
	 * <p>
	 * Returns apiDomain from configuration
	 * </p>
	 * 
	 * @return String - apiDomain
	 */
	@Override
	public String getApiDomain() {

		return tracfoneApiService.getApiDomain();
	}

	/**
	 * <p>
	 * Returns priceApiPath from configuration
	 * </p>
	 * 
	 * @return String - priceApiPath
	 */
	@Override
	public String getPriceApiPath() {

		return tracfoneApiService.getPriceApiPath();
	}

	/**
	 * <p>
	 * Returns home page level from configuration
	 * </p>
	 * 
	 * @return int - homepagelevel
	 */
	protected int getHomePageLevel() {

		return applicationConfigService.getHomePageLevel();
	}

	/**
	 * <p>
	 * Returns language from util
	 * </p>
	 * 
	 * @return String - language
	 */
	@Override
	public String getLanguage() {

		return CommerceUtil.getLanguage(currentPage, getHomePageLevel());
	}

	/**
	 * <p>
	 * Returns query string
	 * </p>
	 * 
	 * @return String - queryString String is used for price API call
	 */
	@Override
	public String getQueryString() {
		StringBuilder query = new StringBuilder(CommerceConstants.BRAND).append(CommerceConstants.EQUALS_TO)
				.append(CommerceUtil.getBrandValue(currentPage, getHomePageLevel())).append(CommerceConstants.AMPERSAND)
				.append(CommerceConstants.PRODUCT_ID).append(CommerceConstants.EQUALS_TO).append(this.getId());
		return query.toString();
	}

	/**
	 * <p>
	 * Returns SKU Details
	 * </p>
	 *
	 * @return String - SKUDetails
	 */
	protected void getSKUDetails() {
		if(product != null && product.get(CommerceConstants.SKUS) != null && product.get(CommerceConstants.SKUS).isJsonArray()) {
			skusArray = product.get(CommerceConstants.SKUS).getAsJsonArray();
			if (skusArray.size() > 0) {
				JsonObject element = skusArray.get(0).getAsJsonObject();
				skuId = element.get(CommerceConstants.ID).getAsString();
			}
		}
	}

	/**
	 * <p>
	 * Returns Sku Id
	 * </p>
	 *
	 * @return String - skuId
	 */
	@Override
	public String getSkuId() {
		return skuId;
	}

	/**
	 * <p>
	 * Returns Thumbnail Image AssetId
	 * </p>
	 *
	 * @return String - thumbnailImageAssetId
	 */
	@Override
	public String getThumbnailImageAssetId() {
		return thumbnailImageAssetId;
	}

	/**
	 * <p>
	 * Returns Thumbnail Image AssetId
	 * </p>
	 *
	 * @return String - thumbnailImageAssetId
	 */
	public void setThumbnailImageAssetId(String thumbnailImageAssetId) {
		this.thumbnailImageAssetId = thumbnailImageAssetId;
	}

	/**
	 * <p>
	 * Returns Thumbnail Image Asset AgencyId
	 * </p>
	 *
	 * @return String - thumbnailImageAssetAgencyId
	 */
	@Override
	public String getThumbnailImageAssetAgencyId() {
		return thumbnailImageAssetAgencyId;
	}

	/**
	 * <p>
	 * Set Thumbnail Image Asset AgencyId
	 * </p>
	 *
	 * @param String - thumbnailImageAssetAgencyId
	 */
	public void setThumbnailImageAssetAgencyId(String thumbnailImageAssetAgencyId) {
		this.thumbnailImageAssetAgencyId = thumbnailImageAssetAgencyId;
	}

	/**
	 * <p>
	 * Returns Allow Guest Checkout
	 * </p>
	 *
	 * @return String - allowGuestCheckout
	 */
	@Override
	public String getAllowGuestCheckout() {
		if (null != allowGuestCheckout && !allowGuestCheckout.isEmpty()) {
			if (allowGuestCheckout.trim().toLowerCase().equalsIgnoreCase(ApplicationConstants.TRUE)) {
				allowGuestCheckout = ApplicationConstants.TRUE;
			} else {
				allowGuestCheckout = ApplicationConstants.FALSE;
			}
		}
		return allowGuestCheckout;
	}

	/**
	 * <p>
	 * Returns Inventory Api Path
	 * </p>
	 *
	 * @return String - inventoryApiPath
	 */
	@Override
	public String getInventoryApiPath() {
		return tracfoneApiService.getInventoryApiPath();
	}

	/**
	 * <p>
	 * Returns Marketing Ids
	 * </p>
	 *
	 * @return String - marketingIds
	 */
	@Override
	public String getMarketingIds() {
		return marketingIds;
	}

	/**
	 * <p>
	 * Returns Inventory Query String
	 * </p>
	 *
	 * @return String - inventoryQueryString
	 */
	@Override
	public String getInventoryQueryString() {
		StringBuilder query = new StringBuilder(CommerceConstants.BRAND).append(CommerceConstants.EQUALS_TO)
				.append(CommerceUtil.getBrandValue(currentPage, getHomePageLevel())).append(CommerceConstants.AMPERSAND)
				.append(CommerceConstants.IDENTIFIER).append(CommerceConstants.EQUALS_TO).append(getSkuId());
		return query.toString();
	}

	/**
	 * <p>
	 * Returns Default fallback thumbnail Image.
	 * </p>
	 * 
	 * @return String - defaultFallbackThumbnailImage
	 */
	@Override
	public String getDefaultFallbackThumbnailImage() {
		String image = ApplicationUtil.getPropertiesFromRootPage(currentPage.getPath(), resource.getResourceResolver(),
				ApplicationConstants.FALLBACK_THUMBNAIL_IMAGE);
		return DynamicMediaUtils.changeMediaPathToDMPath(image, resource.getResourceResolver());
	}

	/**
	 * <p>
	 * Method to return path of phone image related to first SKU only
	 * </p>
	 *
	 * @return String thumbnailPath
	 */
	@Override
	public String getImagePath() {
		return simthumbnailimage;
	}

	public String getBreakPoints() {
		return dynamicMediaConfig.getBreakPoint();
	}
	
	/**
	 * <p>
	 * Returns Cantentry Id
	 * </p>
	 *
	 * @return String - cantentryId
	 */
	@Override
	public String getCantentryId() {
		if (product != null && product.get(CommerceConstants.CATENTRY_ID) != null) {
			return product.get(CommerceConstants.CATENTRY_ID).getAsString();
		}
		return null;
	}

	/**
	 * <p>
	 * Returns categoryApiPath from configuration
	 * </p>
	 *
	 * @return String - categoryApiPath
	 */
	@Override
	public String getCategoryApiPath() {
		return tracfoneApiService.getCategoryApiPath();
	}

	/**
	 * <p>
	 * Returns Query String for Fallback API
	 * </p>
	 *
	 * @return String - fall back queryString
	 */
	@Override
	public String getFallBackQueryString() {
		return CommerceUtil.getFallBackQueryString(CommerceUtil.getBrandValue(currentPage, getHomePageLevel()),selection);
	}

	/**
     * <p>
     * Method to return hidePriceSimCardDetails
     *
     * @return String hidePriceSimCardDetails
     */
    @Override
    public String getHidePriceSimCardDetails() {
        return hidePriceSimCardDetails;
    }

	    /**
	 * @return the iconPath
	 */
    @Override
	public String getIconPath() {
		return iconPath;
	}

}
