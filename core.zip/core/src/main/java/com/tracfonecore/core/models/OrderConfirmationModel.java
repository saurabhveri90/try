/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.OrderConfirmationVasModel;

/**
 * Defines the {@code Multi-Links} Sling Model used for the
 * {@code tracfone-core/components/spa/commerce/orderconfirmation} component.
 */
public interface OrderConfirmationModel extends ComponentExporter {

	/**
	 * <p>
	 * Fetches headerTitle for the orderconfirmation
	 * </p>
	 * 
	 * @return String - headerTitle for the orderconfirmation
	 */
	@JsonProperty("headerTitle")
	public String getHeaderTitle();

	/**
	 * <p>
	 * Fetches orderConfirmationMessage1 for the orderconfirmation
	 * </p>
	 * 
	 * @return String - orderConfirmationMessage1 for the orderconfirmation
	 */
	@JsonProperty("orderConfirmationMessage1")
	public String getOrderConfirmationMessage1();

	/**
	 * <p>
	 * Fetches orderConfirmationMessage2 for the orderconfirmation
	 * </p>
	 * 
	 * @return String - orderConfirmationMessage2 for the orderconfirmation
	 */
	@JsonProperty("orderConfirmationMessage2")
	public String getOrderConfirmationMessage2();

	/**
	 * <p>
	 * Fetches productLogo for the orderconfirmation
	 * </p>
	 * 
	 * @return String - productLogo for the orderconfirmation
	 */
	@JsonProperty("productLogo")
	public String getProductLogo();

	/**
	 * <p>Fetches positionOrderSummary for the cartdetail</p>
	 *
	 * @return String - positionOrderSummary for the cart detail
	 */
	@JsonProperty("positionOrderConfirmation")
	public String getPositionOrderConfirmation();

	/**
	 * <p>
	 * Fetches productLogoAltText for the orderconfirmation
	 * </p>
	 * 
	 * @return String - productLogoAltText for the orderconfirmation
	 */
	@JsonProperty("productLogoAltText")
	public String getProductLogoAltText();

	/**
	 * <p>
	 * Fetches byop25Logo for the orderconfirmation
	 * </p>
	 * 
	 * @return String - byop25Logo for the orderconfirmation
	 */
	@JsonProperty("byop25Logo")
	public String getByopProductLogo();

	/**
	 * <p>
	 * Fetches byop25LogoAltText for the orderconfirmation
	 * </p>
	 * 
	 * @return String - byop25LogoAltText for the orderconfirmation
	 */
	@JsonProperty("byop25LogoAltText")
	public String getByopProductLogoAltText();	

	/**
	 * <p>
	 * Fetches defaultHeaderTitleAct for the orderconfirmation
	 * </p>
	 * 
	 * @return String - defaultHeaderTitleAct for the orderconfirmation
	 */
	@JsonProperty("defaultHeaderTitleAct")
	public String getDefaultHeaderTitleAct();

	/**
	 * <p>
	 * Fetches defaultOrderConfirmationMessageAct for the orderconfirmation
	 * </p>
	 * 
	 * @return String - defaultOrderConfirmationMessageAct for the orderconfirmation
	 */
	@JsonProperty("defaultOrderConfirmationMessageAct")
	public String getDefaultOrderConfirmationMessageAct();

	/**
	 * <p>
	 * Fetches tutorialTitleAct for the orderconfirmation
	 * </p>
	 * 
	 * @return String - tutorialTitleAct for the orderconfirmation
	 */
	@JsonProperty("tutorialTitleAct")
	public String getTutorialTitleAct();

	/**
	 * <p>
	 * Fetches tutorialTitleActFWAFlow for the orderconfirmation
	 * </p>
	 * 
	 * @return String - tutorialTitleActFWAFlow for the orderconfirmation
	 */
	@JsonProperty("tutorialTitleActFWAFlow")
	public String getTutorialTitleActFWAFlow();

	/**
	 * <p>
	 * Fetches tutorialLinkAct for the orderconfirmation
	 * </p>
	 * 
	 * @return String - tutorialLinkAct for the orderconfirmation
	 */
	@JsonProperty("tutorialLinkAct")
	public String getTutorialLinkAct();

	/**
	 * <p>
	 * Fetches defaultProductLogoAct for the orderconfirmation
	 * </p>
	 * 
	 * @return String - defaultProductLogoAct for the orderconfirmation
	 */
	@JsonProperty("defaultProductLogoAct")
	public String getDefaultProductLogoAct();

	/**
	 * <p>
	 * Fetches productLogoAltTextAct for the orderconfirmation
	 * </p>
	 * 
	 * @return String - productLogoAltTextAct for the orderconfirmation
	 */
	@JsonProperty("productLogoAltTextAct")
	public String getProductLogoAltTextAct();

	/**
	 * <p>
	 * Fetches planTitleMappings for the orderconfirmation
	 * </p>
	 * 
	 * @return String - planTitleMappings for the orderconfirmation
	 */
	@JsonProperty("planTitleMappings")
	public String getPlanTitleMappings();

	/**
	 * <p>
	 * Fetches planDetailsTitle for the orderconfirmation
	 * </p>
	 * 
	 * @return String - planDetailsTitle for the orderconfirmation
	 */
	@JsonProperty("planDetailsTitle")
	public String getPlanDetailsTitle();

	/**
	 * <p>
	 * Fetches planDetailsSubtitle for the orderconfirmation
	 * </p>
	 * 
	 * @return String - planDetailsSubtitle for the orderconfirmation
	 */
	@JsonProperty("planDetailsSubtitle")
	public String getPlanDetailsSubtitle();

	/**
	 * <p>
	 * Fetches phonesBasePath for the orderconfirmation
	 * </p>
	 * 
	 * @return String - phonesBasePath for the orderconfirmation
	 */
	@JsonProperty("phonesBasePath")
	public String getPhonesBasePath();

	/**
	 * <p>
	 * Fetches plansBasePath for the orderconfirmation
	 * </p>
	 * 
	 * @return String - plansBasePath for the orderconfirmation
	 */
	@JsonProperty("plansBasePath")
	public String getPlansBasePath();

	/**
	 * <p>
	 * Fetches headerTitleForPromoCodeFlow for the orderconfirmation
	 * </p>
	 * 
	 * @return String - headerTitleForPromoCodeFlow for the orderconfirmation
	 */
	@JsonProperty("headerTitleForPromoCodeFlow")
	public String getHeaderTitleForPromoCodeFlow();

	/**
	 * <p>
	 * Fetches messageOneForPromoCodeFlow for the orderconfirmation
	 * </p>
	 * 
	 * @return String - messageOneForPromoCodeFlow for the orderconfirmation
	 */
	@JsonProperty("messageOneForPromoCodeFlow")
	public String getMessageOneForPromoCodeFlow();

	/**
	 * <p>
	 * Fetches messageTwoForPromoCodeFlow for the orderconfirmation
	 * </p>
	 * 
	 * @return String - messageTwoForPromoCodeFlow for the orderconfirmation
	 */
	@JsonProperty("messageTwoForPromoCodeFlow")
	public String getMessageTwoForPromoCodeFlow();

	/**
	 * <p>
	 * Fetches productLogoForPromoCodeFlow for the orderconfirmation
	 * </p>
	 * 
	 * @return String - productLogoForPromoCodeFlow for the orderconfirmation
	 */
	@JsonProperty("productLogoForPromoCodeFlow")
	public String getProductLogoForPromoCodeFlow();

	/**
	 * <p>
	 * Fetches productLogoForPromoCodeFlowAltText for the orderconfirmation
	 * </p>
	 * 
	 * @return String - productLogoForPromoCodeFlowAltText for the orderconfirmation
	 */
	@JsonProperty("productLogoForPromoCodeFlowAltText")
	public String getProductLogoForPromoCodeFlowAltText();

	/**
	 * <p>
	 * Fetches headerTitleForServicePlanFlow for the orderconfirmation
	 * </p>
	 * 
	 * @return String - headerTitleForServicePlanFlow for the orderconfirmation
	 */
	@JsonProperty("headerTitleForServicePlanFlow")
	public String getHeaderTitleForServicePlanFlow();

	/**
	 * <p>
	 * Fetches messageOneForServicePlanFlow for the orderconfirmation
	 * </p>
	 * 
	 * @return String - messageOneForServicePlanFlow for the orderconfirmation
	 */
	@JsonProperty("messageOneForServicePlanFlow")
	public String getMessageOneForServicePlanFlow();

	/**
	 * <p>
	 * Fetches messageTwoForServicePlanFlow for the orderconfirmation
	 * </p>
	 * 
	 * @return String - messageTwoForServicePlanFlow for the orderconfirmation
	 */
	@JsonProperty("messageTwoForServicePlanFlow")
	public String getMessageTwoForServicePlanFlow();

	/**
	 * <p>
	 * Fetches productLogoForServicePlanFlow for the orderconfirmation
	 * </p>
	 * 
	 * @return String - productLogoForServicePlanFlow for the orderconfirmation
	 */
	@JsonProperty("productLogoForServicePlanFlow")
	public String getProductLogoForServicePlanFlow();

	/**
	 * <p>
	 * Fetches productLogoForServicePlanFlowAltText for the orderconfirmation
	 * </p>
	 * 
	 * @return String - productLogoForServicePlanFlowAltText for the
	 *         orderconfirmation
	 */
	@JsonProperty("productLogoForServicePlanFlowAltText")
	public String getProductLogoForServicePlanFlowAltText();

	/**
	 * <p>
	 * Fetches checkStatusLink for the orderconfirmation
	 * </p>
	 * 
	 * @return String - checkStatusLink for the orderconfirmation
	 */
	@JsonProperty("checkStatusLink")
	public String getCheckStatusLink();

	/**
	 * Get Sim Image Path
	 * 
	 * @return String - simImagePath
	 */
	@JsonProperty("simImagePath")
	public String getSimImagePath();

	/**
	 * Get eSim Image Path
	 * 
	 * @return String - esimImagePath
	 */
	@JsonProperty("esimImagePath")
	public String getEsimImagePath();

	/**
	 * <p>
	 * Fetches headerTitleForRefillWithPinFlow for the orderconfirmation
	 * </p>
	 * 
	 * @return String - headerTitleForRefillWithPinFlow for the orderconfirmation
	 */
	@JsonProperty("headerTitleForRefillWithPinFlow")
	public String getHeaderTitleForRefillWithPinFlow();

	/**
	 * <p>
	 * Fetches messageOneForRefillWithPinFlow for the orderconfirmation
	 * </p>
	 * 
	 * @return String - messageOneForRefillWithPinFlow for the orderconfirmation
	 */
	@JsonProperty("messageOneForRefillWithPinFlow")
	public String getMessageOneForRefillWithPinFlow();

	/**
	 * <p>
	 * Fetches messageTwoForRefillWithPinFlow for the orderconfirmation
	 * </p>
	 * 
	 * @return String - messageTwoForRefillWithPinFlow for the orderconfirmation
	 */
	@JsonProperty("messageTwoForRefillWithPinFlow")
	public String getMessageTwoForRefillWithPinFlow();

	/**
	 * <p>
	 * Fetches messageOneForRefillWithPinAddNowFlow for the orderconfirmation
	 * </p>
	 * 
	 * @return String - messageOneForRefillWithPinAddNowFlow for the
	 *         orderconfirmation
	 */
	@JsonProperty("messageOneForRefillWithPinAddNowFlow")
	public String getMessageOneForRefillWithPinAddNowFlow();

	/**
	 * <p>
	 * Fetches messageTwoForRefillWithPinAddNowFlow for the orderconfirmation
	 * </p>
	 * 
	 * @return String - messageTwoForRefillWithPinAddNowFlow for the
	 *         orderconfirmation
	 */
	@JsonProperty("messageTwoForRefillWithPinAddNowFlow")
	public String getMessageTwoForRefillWithPinAddNowFlow();

	/**
	 * <p>
	 * Fetches myAccountLink for the orderconfirmation
	 * </p>
	 * 
	 * @return String - myAccountLink for the orderconfirmation
	 */
	@JsonProperty("myAccountLink")
	public String getMyAccountLink();

	/**
	 * <p>
	 * Fetches servicePlanReserveMessage for the orderconfirmation
	 * </p>
	 * 
	 * @return String - servicePlanReserveMessage for the orderconfirmation
	 */
	@JsonProperty("servicePlanReserveMessage")
	public String getServicePlanReserveMessage();

	/**
	 * <p>
	 * Fetches reserveDisclaimerText for the orderconfirmation
	 * </p>
	 * 
	 * @return String - reserveDisclaimerText for the orderconfirmation
	 */
	@JsonProperty("reserveDisclaimerText")
	public String getReserveDisclaimerText();

	/**
	 * <p>
	 * Fetches headerTitleForRefillWithCCFlow for the orderconfirmation
	 * </p>
	 * 
	 * @return String - headerTitleForRefillWithCCFlow for the orderconfirmation
	 */
	@JsonProperty("headerTitleForRefillWithCCFlow")
	public String getHeaderTitleForRefillWithCCFlow();

	/**
	 * <p>
	 * Fetches messageOneForRefillWithCCFlow for the orderconfirmation
	 * </p>
	 * 
	 * @return String - messageOneForRefillWithCCFlow for the orderconfirmation
	 */
	@JsonProperty("messageOneForRefillWithCCFlow")
	public String getMessageOneForRefillWithCCFlow();

	/**
	 * <p>
	 * Fetches messageTwoForRefillWithCCFlow for the orderconfirmation
	 * </p>
	 * 
	 * @return String - messageTwoForRefillWithCCFlow for the orderconfirmation
	 */
	@JsonProperty("messageTwoForRefillWithCCFlow")
	public String getMessageTwoForRefillWithCCFlow();

	/**
	 * <p>
	 * Fetches productLogoForRefillWithCCFlow for the orderconfirmation
	 * </p>
	 * 
	 * @return String - productLogoForRefillWithCCFlow for the orderconfirmation
	 */
	@JsonProperty("productLogoForRefillWithCCFlow")
	public String getProductLogoForRefillWithCCFlow();

	/**
	 * <p>
	 * Fetches productLogoForRefillWithCCFlowAltText for the orderconfirmation
	 * </p>
	 * 
	 * @return String - productLogoForRefillWithCCFlowAltText for the
	 *         orderconfirmation
	 */
	@JsonProperty("productLogoForRefillWithCCFlowAltText")
	public String getProductLogoForRefillWithCCFlowAltText();

	/**
	 * <p>
	 * Fetches byopOrderConfirmationMessageAct for the orderconfirmation
	 * </p>
	 * 
	 * @return String - byopOrderConfirmationMessageAct for the orderconfirmation
	 */
	@JsonProperty("byopPortOrderConfirmationMessageAct")
	public String getByopPortOrderConfirmationMessageAct();

	/**
	 * <p>
	 * Fetches byopHeaderTitleAct for the orderconfirmation
	 * </p>
	 * 
	 * @return String - byopHeaderTitleAct for the orderconfirmation
	 */
	@JsonProperty("byopActivateOrderConfirmationMessageAct")
	public String getByopActivateOrderConfirmationMessageAct();

	/**
	 * <p>
	 * Fetches byopUpgradeOrderConfirmationMessageAct for the orderconfirmation
	 * </p>
	 * 
	 * @return String - byopUpgradeOrderConfirmationMessageAct for the
	 *         orderconfirmation
	 */
	@JsonProperty("byopUpgradeOrderConfirmationMessageAct")
	public String getByopUpgradeOrderConfirmationMessageAct();

	/**
	 * <p>
	 * Fetches portOrderConfirmationMessageAct for the orderconfirmation
	 * </p>
	 * 
	 * @return String - portOrderConfirmationMessageAct for the orderconfirmation
	 */
	@JsonProperty("portOrderConfirmationMessageAct")
	public String getPortOrderConfirmationMessageAct();

	/**
	 * <p>
	 * Fetches activateOrderConfirmationMessageAct for the orderconfirmation
	 * </p>
	 * 
	 * @return String - activateOrderConfirmationMessageAct for the
	 *         orderconfirmation
	 */
	@JsonProperty("activateOrderConfirmationMessageAct")
	public String getActivateOrderConfirmationMessageAct();

	/**
	 * <p>
	 * Fetches upgradeOrderConfirmationMessageAct for the orderconfirmation
	 * </p>
	 * 
	 * @return String - upgradeOrderConfirmationMessageAct for the orderconfirmation
	 */
	@JsonProperty("upgradeOrderConfirmationMessageAct")
	public String getUpgradeOrderConfirmationMessageAct();

	/**
	 * <p>
	 * Fetches secondLinePinHeading for the orderconfirmation
	 * </p>
	 * 
	 * @return String - secondLinePinHeading for the orderconfirmation
	 */
	@JsonProperty("secondLinePinHeading")
	public String getSecondLinePinHeading();

	/**
	 * <p>
	 * Fetches componentVersion for the orderconfirmation
	 * </p>
	 *
	 * @return String - componentVersion for the orderconfirmation
	 */
	@JsonProperty("componentVersion")
	public String getComponentVersion();

	/**
	 * <p>
	 * Fetches positionCartSummary for the orderconfirmation
	 * </p>
	 *
	 * @return String - positionCartSummary for the orderconfirmation
	 */
	@JsonProperty("positionCartSummary")
	public String getPositionCartSummary();

	/**
	 * <p>
	 * Fetches positionOrderSummary for the orderconfirmation
	 * </p>
	 *
	 * @return String - positionOrderSummary for the orderconfirmation
	 */
	@JsonProperty("positionOrderSummary")
	public String getPositionOrderSummary();

	/**
	 * <p>
	 * Fetches cartDetailComponentVersion for the orderconfirmation
	 * </p>
	 *
	 * @return String - cartDetailComponentVersion for the orderconfirmation
	 */

	@JsonProperty("cartDetailComponentVersion")
	public String getCartDetailComponentVersion();

	/**
	 * <p>
	 * Fetches enableEstimateOrder for the orderconfirmation
	 * </p>
	 *
	 * @return String - enableEstimateOrder for the orderconfirmation
	 */
	@JsonProperty("enableEstimateOrder")
	public String getEnableEstimateOrder();

	/**
	 * <p>
	 * Fetches smartPaySummaryText for the orderconfirmation
	 * </p>
	 *
	 * @return String - smartPaySummaryText for the orderconfirmation
	 */
	@JsonProperty("smartPaySummaryText")
	public String getSmartPaySummaryText();

	/**
	 * <p>
	 * Fetches smartPayLeasedFrom for the orderconfirmation
	 * </p>
	 *
	 * @return String - smartPayLeasedFrom for the orderconfirmation
	 */
	@JsonProperty("smartPayLeasedFrom")
	public String getSmartPayLeasedFrom();

	/**
	 * <p>
	 * Fetches stByop25EnrollInReawardsLink for the orderconfirmation
	 * </p>
	 * 
	 * @return String - stByop25EnrollInReawardsLink for the orderconfirmation
	 */
	@JsonProperty("stByop25EnrollInReawardsLink")
	public String getStByop25EnrollInReawardsLink();

	/**
	 * <p>
	 * Fetches moreAboutStraightTalkLink for the orderconfirmation
	 * </p>
	 * 
	 * @return String - moreAboutStraightTalkLink for the orderconfirmation
	 */
	@JsonProperty("moreAboutStraightTalkLink")
	public String getMoreAboutStraightTalkLink();
	
	/**
	 * <p>
	 * Fetches useResourceManagementValues for the orderconfirmation
	 * </p>
	 *
	 * @return Boolean - useResourceManagementValues for the orderconfirmation
	 */
	@JsonProperty("useResourceManagementValues")
	default Boolean getUseResourceManagementValues() {
		return null;
	}

	/**
	 * <p>
	 * Fetches categoryIdPlans for the orderconfirmation
	 * </p>
	 *
	 * @return Boolean - categoryIdPlans for the orderconfirmation
	 */
	@JsonProperty("planCategoryId")
	default String getPlanCategoryId() {
		return null;
	}

	@JsonProperty("vasCategoryId")
	public String getVasCategoryId();

	@JsonProperty("vasProducts")
	public List<OrderConfirmationVasModel> getVasProducts();

	/**
	 * <p>
	 * Fetches homeInternetActivateOrderConfirmationMessageAct for the
	 * orderconfirmation
	 * </p>
	 * 
	 * @return String - homeInternetActivateOrderConfirmationMessageAct for the
	 *         orderconfirmation
	 */
	@JsonProperty("homeInternetActivateOrderConfirmationMessageAct")
	public String getHomeInternetActivateOrderConfirmationMessageAct();

	/**
	 * Get Home Internet Image Path
	 * 
	 * @return String - homeInternetImagePath
	 */
	@JsonProperty("homeInternetImagePath")
	public String getHomeInternetImagePath();

	/**
	 * Get Home Internet Plan Title
	 * 
	 * @return String - homeInternetPlanTitle
	 */
	@JsonProperty("homeInternetPlanTitle")
	public String getHomeInternetPlanTitle();

	/**
	 * Get Home Internet Plan Instructions
	 * 
	 * @return String - homeInternetPlanInstructions
	 */
	@JsonProperty("homeInternetPlanInstructions")
	public String getHomeInternetPlanInstructions();

	/**
	 * Get Home Internet Image For Refill Flow
	 * 
	 * @return String - homeInternetImageForRefillPath
	 */
	@JsonProperty("homeInternetImageForRefillPath")
	public String getHomeInternetImageForRefillPath();

	/**
	 * Get Home Internet Image Alt Text For Refill Flow
	 * 
	 * @return String - homeInternetImageForRefillPathAltText
	 */
	@JsonProperty("homeInternetImageForRefillPathAltText")
	public String getHomeInternetImageForRefillPathAltText();

	/**
	 * <p>
	 * Fetches dummyCurrentPlanMultilineInstructions for the orderconfirmation
	 * </p>
	 * 
	 * @return String - dummyCurrentPlanMultilineInstructions for the
	 *         orderconfirmation
	 */
	@JsonProperty("dummyCurrentPlanMultilineInstructions")
	public String getDummyCurrentPlanMultilineInstructions();

	/**
	 * <p>
	 * Fetches dummyCurrentPlanMultilinePinRedeemBy for the orderconfirmation
	 * </p>
	 * 
	 * @return String - dummyCurrentPlanMultilinePinRedeemBy for the
	 *         orderconfirmation
	 */
	@JsonProperty("dummyCurrentPlanMultilinePinRedeemBy")
	public String getDummyCurrentPlanMultilinePinRedeemBy();

	/**
	 * <p>
	 * Fetches noOfRetryForMultilinePinApi for the orderconfirmation
	 * </p>
	 *
	 * @return String - noOfRetryForMultilinePinApi for the
	 *         orderconfirmation
	 */
	@JsonProperty("noOfRetryForMultilinePinApi")
	public String getNoOfRetryForMultilinePinApi();

	/**
	 * <p>
	 * Fetches initialTimeIntervalForPinRetry for the orderconfirmation
	 * </p>
	 *
	 * @return String - initialTimeIntervalForPinRetry for the
	 *         orderconfirmation
	 */
	@JsonProperty("initialTimeIntervalForPinRetry")
	public String getInitialTimeIntervalForPinRetry();

	/**
	 * <p>
	 * Fetches diffInTimeIntervalByForPin for the orderconfirmation
	 * </p>
	 *
	 * @return String - diffInTimeIntervalByForPin for the
	 *         orderconfirmation
	 */
	@JsonProperty("diffInTimeIntervalByForPin")
	public String getDiffInTimeIntervalByForPin();

	/**
	 * <p>
	 * Fetches rafClickHereLink for the orderconfirmation
	 * </p>
	 * 
	 * @return String - rafClickHereLink for the orderconfirmation
	 */
	@JsonProperty("rafClickHereLink")
	public String getRafClickHereLink();
	
	@JsonProperty("welcomeToStraighttalk")
	public String getWelcomeStraightTalk();

	@JsonProperty("getYourPhone")
	public String getYourPhone();

	@JsonProperty("bubbleFooterText")
	public String getBubbleFooterText();

	@JsonProperty("bubbleRafCodePageInfo")
	public String getBubbleRafCodePageInfo();

	@JsonProperty("yourPhoneNumberMsg")
	public String getYourPhoneNumberMsg();
	
	@JsonProperty("needHelp")
	public String getNeedHelp();

	@JsonProperty("someConcerns")
	public String getSomeConcerns();

	@JsonProperty("youCanJust")
	public String getYouCanJust();

	@JsonProperty("textHelp")
	public String getTextHelp();

	@JsonProperty("callUs")
	public String getCallUs();

	@JsonProperty("keepYourService")
	public String getKeepYourService();

	@JsonProperty("serviceRenewal")
	public String getServiceRenewal();

	@JsonProperty("serviceRenewalAutoRefill")
	public String getServiceRenewalAutoRefill();

	@JsonProperty("nextPayment")
	public String getNextPayment();

	@JsonProperty("automaticPayment")
	public String getAutomaticPayment();

	@JsonProperty("plan")
	public String getPlan();

	@JsonProperty("straightSavings")
	public String getStraightSavings();

	@JsonProperty("autoRefillPayMessage")
	public String getAutoRefillPayMessage();

	@JsonProperty("payForService")
	public String getPayForService();

	@JsonProperty("payAt")
	public String getPayAt();
	@JsonProperty("walmart")
	public String getWalmart();

	@JsonProperty("payOnline")
	public String getPayOnline();

	@JsonProperty("straightTalkSite")
	public String getStraightTalkSite();

	@JsonProperty("enroll")
	public String getEnroll();

	@JsonProperty("autoRefill")
	public String getAutoRefill();

	@JsonProperty("deductPayment")
	public String getDeductPayment();

	@JsonProperty("enrollInAutoRefill")
	public String getEnrollInAutoRefill();

	@JsonProperty("freeService")
	public String getFreeService();

	@JsonProperty("letsEnroll")
	public String getLetsEnroll();

	@JsonProperty("yourPlan")
	public String getYourPlan();

	@JsonProperty("straight")
	public String getStraight();

	@JsonProperty("savingsForYou")
	public String getSavingsForYou();

	@JsonProperty("greatPlan")
	public String getGreatPlan();

	@JsonProperty("realUnlimited")
	public String getRealUnlimited();

	@JsonProperty("planActiveForYear")
	public String getPlanActiveForYear();

	@JsonProperty("bonusCredit")
	public String getBonusCredit();

	@JsonProperty("newDevice")
	public String getNewDevice();

	@JsonProperty("freeRewardsProgram")
	public String getFreeRewardsProgram();

	@JsonProperty("yourAccount")
	public String getYourAccount();

	@JsonProperty("keepUpdated")
	public String getKeepUpdated();

	@JsonProperty("paymentSuccessful")
	public String getPaymentSuccessful();

	@JsonProperty("phoneNumber")
	public String getPhoneNumber();

	@JsonProperty("visitYourAccount")
	public String getVisitYourAccount();

	@JsonProperty("signupForRewards")
	public String getSignupForRewards();	

	@JsonProperty("purchaseAdditionalDataText")
	public String getPurchaseAdditionalDataText();
    
    @JsonProperty("uteTaxSurchargeInd")
	public String getUteTaxSurchargeInd();

	@JsonProperty("uteOtherTax")
	public String getUteOtherTax();
	
	@JsonProperty("uteMandatoryTax")
	public String getUteMandatoryTax();

	@JsonProperty("powerCycleMessage")
	public String getPowerCycleMessage();

}
