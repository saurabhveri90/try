package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfonecore.core.models.ScriptingModel;
import com.tracfonecore.core.models.ShippingAddressModel;
import com.tracfonecore.core.models.ZipCodeModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.utils.ConfigurationUtil;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.Self;

import javax.inject.Inject;
import java.util.Map;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ShippingAddressModel.class,
        ComponentExporter.class }, resourceType = ShippingAddressModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ShippingAddressModelImpl implements ShippingAddressModel {

    protected static final String RESOURCE_TYPE = "tracfone-core/components/commerce/shippingAddress";

    @Self
    private SlingHttpServletRequest request;

    @Inject
    private ApplicationConfigService applicationConfigService;

    /**
     * Inject heading text
     */
    @Inject
    @Via("resource")
    private String heading;

    /**
     * Inject summary
     */
    @Inject
    @Via("resource")
    private String summary;

    /**
     * Inject shipping info label
     */
    @Inject
    @Via("resource")
    private String shippingInfoLabel;

    /**
     * Inject cta button
     */
    @Inject
    @Via("resource")
    private String ctaButton;

    private String countryStateMapping;

    /**
     * @return String - heading
     */
    @Override
    public String getHeading(){ return heading; }

    /**
     * @return String - summary Text
     */
    @Override
    public String getSummary() { return summary; }

    /**
     * @return String - shipping info label Text
     */
    @Override
    public String getShippingInfoLabel() { return shippingInfoLabel; }

    /**
     * @return the countryStateMapping
     */
    public String getCountryStateMapping() {
        GsonBuilder builder = new GsonBuilder().setPrettyPrinting().serializeNulls();
        Gson gson = builder.create();
        String[] countryStateArray = applicationConfigService.getCountryStateMapping();

        if (countryStateArray != null) {
            Map<String, String> countryStateMap = ConfigurationUtil.getConfigMap(countryStateArray);
            countryStateMapping= gson.toJson(countryStateMap);
        }
        return countryStateMapping;
    }

    /**
     * <p> Method to return exporter type </p>
     *
     * @return String - exportedType
     */
    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

}
