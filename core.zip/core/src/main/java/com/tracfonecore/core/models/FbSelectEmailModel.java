package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;

public interface FbSelectEmailModel extends ComponentExporter {

	/**
	 * <p>
	 * Returns headerText from properties
	 * </p>
	 * 
	 * @return String - headerText
	 */
	public String getHeaderText();

	/**
	 * <p>
	 * Returns summary from properties
	 * </p>
	 * 
	 * @return String - summary
	 */
	public String getSummary();

	/**
	 * <p>
	 * Returns accessibilityText
	 * </p>
	 * 
	 * @return String - accessibilityText
	 */
	public String getAccessibilityText();
}
