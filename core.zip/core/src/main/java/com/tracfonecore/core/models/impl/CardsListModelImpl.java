/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.CardsListModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import com.tracfonecore.core.beans.ImageBean;
import com.tracfonecore.core.constants.ApplicationConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CardsListModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/cardslist", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CardsListModelImpl implements CardsListModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;

	@Inject
	private Resource resource;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String heading;


	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String footNote;

	private List<ImageBean> imageList = Collections.emptyList();

	private static final Logger LOGGER = LoggerFactory.getLogger(CardsListModelImpl.class);


	//Constants
	private static final String COLUMNS = "columns";
	private static final String TITLE = "title";
	private static final String FILE_REFERENCE = "fileReference";
	private static final String ALT_TEXT = "altText";

	@PostConstruct
	private void initModel() {

		imageList = new ArrayList<ImageBean>();

		for (Resource child : resource.getChildren()) {
			if(COLUMNS.equals(child.getName()))
			{
				Iterator<Resource> it = child.listChildren();
				setMultiFieldItems(it, imageList);
			}
		}

	}
	/**
	 * <p>Populates a list with all the image and text of the Cards List</p>
	 * 
	 * @param it - iterator of the parent node
	 * @param multiFieldData - list in which the images data needs to be set
	 */
	private void setMultiFieldItems(Iterator<Resource> it, List<ImageBean> multiFieldData) {
		LOGGER.debug("Entering setMultiFieldItems method");
		String s7Path="";
		while (it.hasNext()) {
			ImageBean imageBean = new ImageBean();
			Resource grandChild = it.next();

			imageBean.setText(grandChild.getValueMap().get(TITLE, String.class));
			s7Path = DynamicMediaUtils.changeMediaPathToDMPath(grandChild.getValueMap().get(FILE_REFERENCE,String.class), request.getResourceResolver());
			imageBean.setImagePath(s7Path);
			imageBean.setAltText(grandChild.getValueMap().get(ALT_TEXT,String.class));
			imageBean.setAssetId(ApplicationUtil.getAssetId(grandChild.getValueMap().get(FILE_REFERENCE,String.class),
					request.getResourceResolver(), ApplicationConstants.IMAGE));
			imageBean.setWeberId(ApplicationUtil.getAssetMetaDataValue(grandChild.getValueMap().get(FILE_REFERENCE,String.class),
					request.getResourceResolver(), ApplicationConstants.WEBER_ID));

			multiFieldData.add(imageBean);
		}

		LOGGER.debug("Exiting setMultiFieldItems method ");
	}

	@Override
	public String getHeading() {
		return heading;
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	@Override
	public String getFootNote() {
		return footNote;
	}
	@Override
	public List<ImageBean> getImageList() {
		return new ArrayList<>(imageList);
	}

}
