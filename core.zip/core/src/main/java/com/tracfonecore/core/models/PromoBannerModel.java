package com.tracfonecore.core.models;

public interface PromoBannerModel {
    String getBannerBackground();
    String getBannerHeader();
    String getBannerDescription();
    String getBannerCtaLabel();
    String getBannerCtaLink();
}
