package com.tracfonecore.core.beans;

public class OtherSpecsPDPBean {
    private String iconPathPDP;
    private String descriptionPDP;
    private String valuePDP;
    private String identifierPDP ;
    private String accessibilityTextPDP;
    private String badgePDP;
    private int count;
    public OtherSpecsPDPBean() {
    }

    public OtherSpecsPDPBean(String iconPathPDP, String descriptionPDP, String valuePDP, String identifierPDP, String accessibilityTextPDP, String badgePDP) {
        this.iconPathPDP = iconPathPDP;
        this.descriptionPDP = descriptionPDP;
        this.valuePDP = valuePDP;
        this.identifierPDP = identifierPDP;
        this.accessibilityTextPDP = accessibilityTextPDP;
        this.badgePDP= badgePDP;
    }

    public String getIconPathPDP() {
        return iconPathPDP;
    }

    public void setIconPathPDP(String iconPathPDP) {
        this.iconPathPDP = iconPathPDP;
    }

    public String getDescriptionPDP() {
        return descriptionPDP;
    }

    public void setDescriptionPDP(String descriptionPDP) {
        this.descriptionPDP = descriptionPDP;
    }

    public String getValuePDP() {
        return valuePDP;
    }

    public void setValuePDP(String valuePDP) {
        this.valuePDP = valuePDP;
    }

    public String getIdentifierPDP() {
        return identifierPDP;
    }

    public void setIdentifierPDP(String identifierPDP) {
        this.identifierPDP = identifierPDP;
    }

    public String getAccessibilityTextPDP() {
        return accessibilityTextPDP;
    }

    public void setAccessibilityTextPDP(String accessibilityTextPDP) {
        this.accessibilityTextPDP = accessibilityTextPDP;
    }

    public String getBadgePDP() {
        return badgePDP;
    }
    public void setBadgePDP(String badgePDP) {
        this.badgePDP = badgePDP;
    }
    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}