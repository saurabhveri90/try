/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl.v1;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.AppDownloadSpaModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { AppDownloadSpaModel.class,
        ComponentExporter.class }, resourceType = "tracfone-core/components/spa/content/appdownload/v1/appdownload", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class AppDownloadSpaModelImpl implements AppDownloadSpaModel {

    @Self
    private SlingHttpServletRequest request;

    @ScriptVariable
    private ValueMap properties;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String componentVersion;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String headlineText;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String subHeadlineText;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String appstoreFileReference;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String appstore;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String appStoreNewWindow;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String appstorealttext;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String donotfollowappstore;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String playstoreFileReference;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String playstore;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String playStoreNewWindow;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String playstorealttext;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String donotfollowplaystore;

    @Override
    public String getComponentVersion() {
        return StringUtils.isNotBlank(componentVersion) ? componentVersion : "v1";
    }

    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

    @Override
    public String getHeadlineText() {
        return headlineText;
    }

    @Override
    public String getSubHeadlineText() {
        return subHeadlineText;
    }
    
    @Override
    public String getAppstore() {
        return appstore;
    }

    @Override
    public String getAppStoreNewWindow() {
        return appStoreNewWindow;
    }

    @Override
    public String getAppstorealttext() {
        return appstorealttext;
    }

    @Override
    public String getDonotfollowappstore() {
        return donotfollowappstore;
    }
    
    @Override
    public String getPlaystore() {
        return playstore;
    }

    @Override
    public String getPlayStoreNewWindow() {
        return playStoreNewWindow;
    }

    @Override
    public String getPlaystorealttext() {
        return playstorealttext;
    }

    @Override
    public String getDonotfollowplaystore() {
        return donotfollowplaystore;
    }

	@Override
	public String getAppstoreFileReference() {
		return appstoreFileReference;
	}

	@Override
	public String getPlaystoreFileReference() {
		return playstoreFileReference;
	}


}
