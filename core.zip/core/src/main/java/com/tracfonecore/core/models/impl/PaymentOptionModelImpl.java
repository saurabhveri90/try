/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;

import com.tracfonecore.core.constants.CommerceConstants;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.tracfonecore.core.beans.AddToCartOptBean;
import com.tracfonecore.core.models.PaymentOptionsModel;
import com.tracfonecore.core.utils.ApplicationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { PaymentOptionsModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/paymentoptions", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class PaymentOptionModelImpl extends BaseComponentModelImpl implements PaymentOptionsModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;
	private ValueMap currentPageProperties;

	private ResourceResolver resolver;

	@Inject
	private Resource resource;
	private String categoryType;
	private String paymentOptionsLabel;
	private String paymentCtaText;
	private String paymentCtaAltText;
	private String paymentCtaLink;
	private String logoLink;
	private String logoAltText;
	private String donotfollowlink;
	private String showStepsNumber;
	private List<AddToCartOptBean> paymentOptions;
	private String enablePromotionalOffers;
	private String promoCtaText;
	private String promoCtaAltText;
	private String promoPortInCtaLink;
	private String promoActivationCtaLink;
	private String promoDoNotFollowLink;
	private String otherPayOptionsCtaText;
	private String otherPayOptionsCtaAltText;
	private String enablePromotionalOfferModal;
	private String promoVeriffCtaLink;
	private String hideOtherOptionDropDown;
	private String inEligiblePlanMsg;
	private String eligiblePlanPLPLink;
	private String showEligiblePlanLink;
	private String promoDcotCtaLink;
	private String promoDcotChrunCtaLink;
	private String enableDcotPromoOffers;
	private String dcotPromoTextPopupPDP;
	private String dcotPromoTextPopupHeadingPDP;
	private String dcotPromoPlantextonPDP;

	private String dcotFullpricePromoTextPDP;
	private String veriffPromoTextPopupPDP;
	private String veriffPromoTextPopupHeadingPDP;
	private String veriffPromoPlantextonPDP;
	private String portInPromoTextPopupPDP;
	private String portInPromoTextPopupHeadingPDP;
	private String portInPromoPlantextonPDP;
	private String activationPromoPopupPDP;
	private String activationPromoPopupHeadingPDP;
	private String activationPromoPlantextonPDP;

	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentOptionModelImpl.class);

	@PostConstruct
	protected void initModel() {
		super.initModel();
		fetchPagePropertiesData();
	}

	/**
	 * Method to values from page properties
	 */
	private void fetchPagePropertiesData() {
		try {
			paymentOptions = new ArrayList<AddToCartOptBean>();
			resolver = resource.getResourceResolver();
			PageManager pm = resolver.adaptTo(PageManager.class);
			Page currentPage = pm.getContainingPage(resource);
			Page rendingPage = null;
			if (currentPage != null) {
				Page parentPage = currentPage.getParent();
				Page ancestorPage = parentPage.getParent();
				properties = parentPage.getProperties();
				currentPageProperties = currentPage.getProperties();
				if (properties != null && properties.containsKey(CommerceConstants.CATEGORY_ID)
						&& !properties.get(CommerceConstants.CATEGORY_ID, String.class).isEmpty()
						&& properties.containsKey(CommerceConstants.CATEGORY_TYPE)
						&& !properties.get(CommerceConstants.CATEGORY_TYPE, String.class).isEmpty()) {
					rendingPage = parentPage;
				} else {
					properties = ancestorPage.getProperties();
					rendingPage = ancestorPage;
				}
				setEnablePromotionalOffers(ApplicationUtil.getPropertiesFromRootPage(rendingPage.getPath(), resolver,
						CommerceConstants.ENABLE_PROMOTIONAL_OFFER));
				setEnablePromotionalOfferModal((currentPage.getProperties()
						.get(CommerceConstants.ENABLE_PROMOTIONAL_PHONE_OFFER_MODAL, String.class)));
				setEnableDcotPromoOffers(ApplicationUtil.getPropertiesFromRootPage(ancestorPage.getPath(), resolver,
						CommerceConstants.ENABLE_DCOT_PROMOTIONAL_OFFER));
			}

			if (properties != null) {
				categoryType = properties.get(CommerceConstants.CATEGORY_TYPE, String.class);
				this.setCategoryType(categoryType);

				if (categoryType != null) {
					setPaymentOptionsLabel(properties.get(CommerceConstants.PAYMENT_OPTION_LABEL, String.class));
					setPaymentCtaText(properties.get(CommerceConstants.PAYMENT_CTA_TEXT, String.class));
					setPaymentCtaAltText(properties.get(CommerceConstants.PAYMENT_CTA_ALTTEXT, String.class));
					setPaymentCtaLink(properties.get(CommerceConstants.PAYMENT_CTA_LINK, String.class));
					setLogoLink(properties.get(CommerceConstants.LOGO_LINK, String.class));
					setLogoAltText(properties.get(CommerceConstants.LOGO_ALT_TEXT, String.class));
					setInEligiblePlanMsg(properties.get(CommerceConstants.INELIGIBLE_PLAN_MESSAGE, String.class));
					setEligiblePlanPLPLink(properties.get(CommerceConstants.ELIGIBLE_PLAN_PLP_LINK, String.class));
					if (null != properties.get(CommerceConstants.SHOW_STEPS_NUMBER))
						setShowStepsNumber(properties.get(CommerceConstants.SHOW_STEPS_NUMBER, String.class));
					if (properties.get(CommerceConstants.DO_NOT_FOLLOW_LINK, String.class) != null)
						setDonotfollowlink(ApplicationUtil
								.getNoFollow(properties.get(CommerceConstants.DO_NOT_FOLLOW_LINK, String.class)));
					setPromoCtaText(properties.get(CommerceConstants.PROMO_CTA_TEXT, String.class));
					setPromoCtaAltText(properties.get(CommerceConstants.PROMO_CTA_ALTTEXT, String.class));
					setPromoActivationCtaLink(
							properties.get(CommerceConstants.PROMO_ACTIVATION_CTA_LINK, String.class));
					setPromoPortInCtaLink(properties.get(CommerceConstants.PROMO_PORT_IN_CTA_LINK, String.class));
					setPromoVeriffCtaLink(properties.get(CommerceConstants.PROMO_VERIFF_CTA_LINK, String.class));
					if (properties.get(CommerceConstants.PROMO_DO_NOT_FOLLOW_LINK, String.class) != null)
						setPromoDoNotFollowLink(ApplicationUtil
								.getNoFollow(properties.get(CommerceConstants.PROMO_DO_NOT_FOLLOW_LINK, String.class)));
					setOtherPayOptionsCtaText(
							properties.get(CommerceConstants.OTHER_PAYMENT_OPTIONS_CTA_TEXT, String.class));
					setOtherPayOptionsCtaAltText(
							properties.get(CommerceConstants.OTHER_PAYMENT_OPTIONS_CTA_ALT_TEXT, String.class));
					setHideOtherOptionDropDown((properties.get(CommerceConstants.HIDE_OTHER_PAYMENT_OPTIONS_CTA,
							String.class)));
					setShowEligiblePlanLink((properties.get(CommerceConstants.SHOW_ELIGIBLE_PLAN_LINK,
							String.class)));
					setPromoDcotCtaLink(properties.get(CommerceConstants.PROMO_DCOT_CTA_LINK, String.class));
					setPromoDcotChrunCtaLink(properties.get(CommerceConstants.PROMO_DCOT_CHURN_CTA_LINK, String.class));

					if(null != currentPageProperties.get(CommerceConstants.DCOT_PROMO_TEXT_POPUP_DESC_PDP))
						setDcotPromoTextPopupPDP(currentPageProperties.get(CommerceConstants.DCOT_PROMO_TEXT_POPUP_DESC_PDP , String.class));
					if(null != currentPageProperties.get(CommerceConstants.DCOT_PROMO_TEXT_POPUP_HEADING_PDP))
						setDcotPromoTextPopupHeadingPDP(currentPageProperties.get(CommerceConstants.DCOT_PROMO_TEXT_POPUP_HEADING_PDP , String.class));
					if(null != currentPageProperties.get(CommerceConstants.DCOT_PROMO_PLAN_TEXT_ON_PDP))
						setDcotPromoPlantextonPDP(currentPageProperties.get(CommerceConstants.DCOT_PROMO_PLAN_TEXT_ON_PDP , String.class));
					if(null != currentPageProperties.get(CommerceConstants.DCOT_FULL_PRICE_PROMO_PLAN_TEXT_ON_PDP))
						setDcotFullpricePromoTextPDP(currentPageProperties.get(CommerceConstants.DCOT_FULL_PRICE_PROMO_PLAN_TEXT_ON_PDP , String.class));


					if(null != currentPageProperties.get(CommerceConstants.VERIFF_PROMO_TEXT_POPUP_DESC_PDP))
						setVeriffPromoTextPopupPDP(currentPageProperties.get(CommerceConstants.VERIFF_PROMO_TEXT_POPUP_DESC_PDP , String.class));
					if(null != currentPageProperties.get(CommerceConstants.VERIFF_PROMO_TEXT_POPUP_HEADING_PDP))
						setVeriffPromoTextPopupHeadingPDP(currentPageProperties.get(CommerceConstants.VERIFF_PROMO_TEXT_POPUP_HEADING_PDP , String.class));
					if(null != currentPageProperties.get(CommerceConstants.VERIFF_PROMO_PLAN_TEXT_ON_PDP))
						setVeriffPromoPlantextonPDP(currentPageProperties.get(CommerceConstants.VERIFF_PROMO_PLAN_TEXT_ON_PDP , String.class));


					if(null != currentPageProperties.get(CommerceConstants.PORTIN_PROMO_TEXT_POPUP_DESC_PDP))
						setPortInPromoTextPopupPDP(currentPageProperties.get(CommerceConstants.PORTIN_PROMO_TEXT_POPUP_DESC_PDP , String.class));
					if(null != currentPageProperties.get(CommerceConstants.PORTIN_PROMO_TEXT_POPUP_HEADING_PDP))
						setPortInPromoTextPopupHeadingPDP(currentPageProperties.get(CommerceConstants.PORTIN_PROMO_TEXT_POPUP_HEADING_PDP , String.class));
					if(null != currentPageProperties.get(CommerceConstants.PORTIN_PROMO_PLAN_TEXT_ON_PDP))
						setPortInPromoPlantextonPDP(currentPageProperties.get(CommerceConstants.PORTIN_PROMO_PLAN_TEXT_ON_PDP , String.class));


					if(null != currentPageProperties.get(CommerceConstants.ACTIVATION_PROMO_TEXT_POPUP_DESC_PDP))
						setActivationPromoPopupPDP(currentPageProperties.get(CommerceConstants.ACTIVATION_PROMO_TEXT_POPUP_DESC_PDP , String.class));
					if(null != currentPageProperties.get(CommerceConstants.ACTIVATION_PROMO_TEXT_POPUP_HEADING_PDP))
						setActivationPromoPopupHeadingPDP(currentPageProperties.get(CommerceConstants.ACTIVATION_PROMO_TEXT_POPUP_HEADING_PDP , String.class));
					if(null != currentPageProperties.get(CommerceConstants.ACTIVATION_PROMO_PLAN_TEXT_ON_PDP))
						setActivationPromoPlantextonPDP(currentPageProperties.get(CommerceConstants.ACTIVATION_PROMO_PLAN_TEXT_ON_PDP , String.class));



					if (rendingPage != null) {
						Resource renderingResource = rendingPage.getContentResource();
						Node currentNode = renderingResource.adaptTo(Node.class);
						Node child = currentNode.getNode(CommerceConstants.PAYMENT_OPTIONS);
						NodeIterator ni = child.getNodes();
						setMultiFieldItems(ni, paymentOptions, currentPage);
					}
				}

			}
		} catch (RepositoryException re) {
			LOGGER.error("Repository Exception occurred while fetching multi link details {}", re);
		}

	}

	private void setMultiFieldItems(NodeIterator ni, List<AddToCartOptBean> multiFieldData, Page currentPage) throws RepositoryException {

		currentPageProperties = currentPage.getProperties();

		while (ni.hasNext()) {
			AddToCartOptBean optionsBean = new AddToCartOptBean();
			Node grandChild = (Node) ni.nextNode();
			boolean promotype = false;
			if ((grandChild.hasProperty(CommerceConstants.PAYMENT_TYPE))) {
				optionsBean.setPaymentType(grandChild.getProperty(CommerceConstants.PAYMENT_TYPE).getString());
				if(optionsBean.getPaymentType().equalsIgnoreCase(CommerceConstants.PROMO_OFFER_TYPE)){
					promotype = true;
				}
			}

			if(promotype && StringUtils.isNotBlank(currentPageProperties.get(CommerceConstants.PROMO_PAYMENT_PRICE_PREFIX_LABEL, StringUtils.EMPTY)) ){
				optionsBean.setPrefixLabel(currentPageProperties.get(CommerceConstants.PROMO_PAYMENT_PRICE_PREFIX_LABEL, StringUtils.EMPTY));
			} else if ((grandChild.hasProperty(CommerceConstants.PAYMENT_PRICE_PREFIX_LABEL))) {
				optionsBean.setPrefixLabel(
						grandChild.getProperty(CommerceConstants.PAYMENT_PRICE_PREFIX_LABEL).getString());
			}

			if(promotype && StringUtils.isNotBlank(currentPageProperties.get(CommerceConstants.PROMO_PAYMENT_PRICE_SUFFIX_LABEL, StringUtils.EMPTY)) ){
				optionsBean.setSuffixLabel(currentPageProperties.get(CommerceConstants.PROMO_PAYMENT_PRICE_SUFFIX_LABEL, StringUtils.EMPTY));
			} else if ((grandChild.hasProperty(CommerceConstants.PAYMENT_PRICE_SUFFIX_LABEL))) {
				optionsBean.setSuffixLabel(
						grandChild.getProperty(CommerceConstants.PAYMENT_PRICE_SUFFIX_LABEL).getString());
			}

			if(promotype && StringUtils.isNotBlank(currentPageProperties.get(CommerceConstants.PROMO_PAYMENT_LABEL, StringUtils.EMPTY)) ){
				optionsBean.setLabel(currentPageProperties.get(CommerceConstants.PROMO_PAYMENT_LABEL, StringUtils.EMPTY));
			} else if ((grandChild.hasProperty(CommerceConstants.PAYMENT_LABEL))) {
				optionsBean.setLabel(grandChild.getProperty(CommerceConstants.PAYMENT_LABEL).getString());
			}

			if(promotype && StringUtils.isNotBlank(currentPageProperties.get(CommerceConstants.PROMO_PAYMENT_SUMMARY, StringUtils.EMPTY)) ){
				optionsBean.setSummary(currentPageProperties.get(CommerceConstants.PROMO_PAYMENT_SUMMARY, StringUtils.EMPTY));
			} else if ((grandChild.hasProperty(CommerceConstants.PAYMENT_SUMMARY))) {
				optionsBean.setSummary(grandChild.getProperty(CommerceConstants.PAYMENT_SUMMARY).getString());
			}

			multiFieldData.add(optionsBean);
		}

	}

	/**
	 * <p>
	 * Fetches category type of the product
	 * </p>
	 *
	 * @return String - category type of the product
	 */
	@Override
	public String getCategoryType() {
		return categoryType;
	}

	/**
	 * <p>
	 * Fetches payment option text
	 * </p>
	 *
	 * @return String - payment option text
	 */
	@Override
	public String getPaymentOptionsLabel() {
		return paymentOptionsLabel;
	}

	/**
	 * <p>
	 * Fetches CTA text of EMI payment option link/p>
	 *
	 * @return String - CTA text of EMI Payment option
	 */
	@Override
	public String getPaymentCtaText() {
		return paymentCtaText;
	}

	/**
	 * <p>
	 * Fetches CTA Alt-text of EMI payment option
	 * </p>
	 *
	 * @return String - CTA Alt-text of EMI payment option
	 */
	@Override
	public String getPaymentCtaAltText() {
		return paymentCtaAltText;
	}

	/**
	 * <p>
	 * Fetches CTA link of EMI payment option
	 * </p>
	 *
	 * @return String - CTA link of EMI payment option
	 */
	@Override
	public String getPaymentCtaLink() {
		return paymentCtaLink;
	}

	/**
	 * <p>
	 * Fetches payment options list
	 * </p>
	 *
	 * @return String - list of payment options
	 */

	@Override
	public List<AddToCartOptBean> getPaymentOptions() {
		List<AddToCartOptBean> optBeans = paymentOptions;
		return optBeans;
	}

	/**
	 * <p>
	 * Sets paymentOptionsLabel
	 * </p>
	 *
	 * @param paymentOptionsLabel - the paymentOptionsLabel to set
	 */
	public void setPaymentOptionsLabel(String paymentOptionsLabel) {
		this.paymentOptionsLabel = paymentOptionsLabel;
	}

	/**
	 * <p>
	 * Sets paymentCtaText
	 * </p>
	 *
	 * @param paymentCtaText - the paymentCtaText to set
	 */
	public void setPaymentCtaText(String paymentCtaText) {
		this.paymentCtaText = paymentCtaText;
	}

	/**
	 * <p>
	 * Sets paymentCtaAltText
	 * </p>
	 *
	 * @param paymentCtaAltText - the paymentCtaAltText to set
	 */
	public void setPaymentCtaAltText(String paymentCtaAltText) {
		this.paymentCtaAltText = paymentCtaAltText;
	}

	/**
	 * <p>
	 * Sets paymentCtaLink
	 * </p>
	 *
	 * @param paymentCtaLink - the paymentCtaLink to set
	 */
	public void setPaymentCtaLink(String paymentCtaLink) {
		this.paymentCtaLink = paymentCtaLink;
	}

	/**
	 * <p>
	 * Sets categoryType
	 * </p>
	 *
	 * @param categoryType - the categoryType to set
	 */
	public void setCategoryType(String categoryType) {
		this.categoryType = categoryType;
	}

	/**
	 * <p>
	 * Fetches logoLink
	 * </p>
	 *
	 * @return the logoLink
	 */
	@Override
	public String getLogoLink() {
		return logoLink;
	}

	/**
	 * <p>
	 * Sets logoLink
	 * </p>
	 *
	 * @param logoLink - the logoLink to set
	 */
	public void setLogoLink(String logoLink) {
		this.logoLink = logoLink;
	}

	/**
	 * <p>
	 * Fetches showStepsNumber
	 * </p>
	 *
	 * @return the showStepsNumber
	 */
	@Override
	public String getShowStepsNumber() {
		return showStepsNumber;
	}

	/**
	 * <p>
	 * Sets setShowStepsNumber
	 * </p>
	 *
	 * @param showStepsNumber - the showStepsNumber to set
	 */
	public void setShowStepsNumber(String showStepsNumber) {
		this.showStepsNumber = showStepsNumber;
	}

	/**
	 * <p>
	 * Fetches logoAltText
	 * </p>
	 *
	 * @return the logoAltText
	 */
	@Override
	public String getLogoAltText() {
		return logoAltText;
	}

	/**
	 * <p>
	 * Sets logoAltText
	 * </p>
	 *
	 * @param logoAltText - the logoAltText to set
	 */
	public void setLogoAltText(String logoAltText) {
		this.logoAltText = logoAltText;
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Fetches donotfollowlink
	 * </p>
	 *
	 * @return the donotfollowlink
	 */
	@Override
	public String getDonotfollowlink() {
		return donotfollowlink;
	}

	/**
	 * <p>
	 * Sets donotfollowlink
	 * </p>
	 *
	 * @param donotfollowlink - the donotfollowlink to set
	 */
	public void setDonotfollowlink(String donotfollowlink) {
		this.donotfollowlink = donotfollowlink;
	}

	/**
	 * <p>
	 * Fetches enablePromotionalOffers
	 * </p>
	 *
	 * @return the enablePromotionalOffers
	 */
	public String getEnablePromotionalOffers() {
		return enablePromotionalOffers;
	}

	/**
	 * <p>
	 * Sets enablePromotionalOffers
	 * </p>
	 *
	 * @param enablePromotionalOffers - the enablePromotionalOffers to set
	 */
	public void setEnablePromotionalOffers(String enablePromotionalOffers) {
		this.enablePromotionalOffers = enablePromotionalOffers;
	}

	/**
	 * @return String return the promoCtaText
	 */
	public String getPromoCtaText() {
		return promoCtaText;
	}

	/**
	 * @param promoCtaText the promoCtaText to set
	 */
	public void setPromoCtaText(String promoCtaText) {
		this.promoCtaText = promoCtaText;
	}

	/**
	 * @return String return the promoCtaAltText
	 */
	public String getPromoCtaAltText() {
		return promoCtaAltText;
	}

	/**
	 * @param promoCtaAltText the promoCtaAltText to set
	 */
	public void setPromoCtaAltText(String promoCtaAltText) {
		this.promoCtaAltText = promoCtaAltText;
	}

	/**
	 * @return String return the promoPortInCtaLink
	 */
	public String getPromoPortInCtaLink() {
		return promoPortInCtaLink;
	}

	/**
	 * @param promoPortInCtaLink the promoPortInCtaLink to set
	 */
	public void setPromoPortInCtaLink(String promoPortInCtaLink) {
		this.promoPortInCtaLink = promoPortInCtaLink;
	}

	/**
	 * @return String return the promoActivationCtaLink
	 */
	public String getPromoActivationCtaLink() {
		return promoActivationCtaLink;
	}

	/**
	 * @param promoActivationCtaLink the promoActivationCtaLink to set
	 */
	public void setPromoActivationCtaLink(String promoActivationCtaLink) {
		this.promoActivationCtaLink = promoActivationCtaLink;
	}

	/**
	 * @return String return the promoDoNotFollowLink
	 */
	public String getPromoDoNotFollowLink() {
		return promoDoNotFollowLink;
	}

	/**
	 * @param promoDoNotFollowLink the promoDoNotFollowLink to set
	 */
	public void setPromoDoNotFollowLink(String promoDoNotFollowLink) {
		this.promoDoNotFollowLink = promoDoNotFollowLink;
	}

	/**
	 * @return String return the otherPayOptionsCtaAltText
	 */
	public String getOtherPayOptionsCtaAltText() {
		return otherPayOptionsCtaAltText;
	}

	/**
	 * @param otherPayOptionsCtaAltText the otherPayOptionsCtaAltText to set
	 */
	public void setOtherPayOptionsCtaAltText(String otherPayOptionsCtaAltText) {
		this.otherPayOptionsCtaAltText = otherPayOptionsCtaAltText;
	}

	/**
	 * @return String return the otherPayOptionsCtaText
	 */
	public String getOtherPayOptionsCtaText() {
		return otherPayOptionsCtaText;
	}

	/**
	 * @param otherPayOptionsCtaText the otherPayOptionsCtaText to set
	 */
	public void setOtherPayOptionsCtaText(String otherPayOptionsCtaText) {
		this.otherPayOptionsCtaText = otherPayOptionsCtaText;
	}

	/**
	 * @return String return the enablePromotionalOfferModal
	 */
	@Override
	public String getEnablePromotionalOfferModal() {
		return enablePromotionalOfferModal;
	}

	/**
	 * @param otherPayOptionsCtaText the enablePromotionalOfferModal to set
	 */
	public void setEnablePromotionalOfferModal(String enablePromotionalOfferModal) {
		this.enablePromotionalOfferModal = enablePromotionalOfferModal;
	}

	/**
	 * <p>
	 * Fetches CTA link of Veriff Offers
	 * </p>
	 *
	 * @return String - CTA link of Veriff offer details
	 */
	@Override
	public String getPromoVeriffCtaLink() {
		return promoVeriffCtaLink;
	}

	/**
	 * @param promoVeriffCtaLink the promoVeriffCtaLink to set
	 */
	public void setPromoVeriffCtaLink(String promoVeriffCtaLink) {
		this.promoVeriffCtaLink = promoVeriffCtaLink;
	}

	/**
	 * @return String return the hideOtherOptionDropDown
	 */
	@Override
	public String getHideOtherOptionDropDown() {
		return hideOtherOptionDropDown;
	}

	/**
	 * @param hideOtherOptionDropDown the hideOtherOptionDropDown to set
	 */
	public void setHideOtherOptionDropDown(String hideOtherOptionDropDown) {
		this.hideOtherOptionDropDown = hideOtherOptionDropDown;
	}

	/**
	 * @return String return the showEligiblePlanLink
	 */
	@Override
	public String getShowEligiblePlanLink() {
		return showEligiblePlanLink;
	}

	/**
	 * @param showEligiblePlanLink the showEligiblePlanLink to set
	 */
	public void setShowEligiblePlanLink(String showEligiblePlanLink) {
		this.showEligiblePlanLink = showEligiblePlanLink;
	}

	/**
	 * @return String return the inEligiblePlanMsg
	 */
	@Override
	public String getInEligiblePlanMsg() {
		return inEligiblePlanMsg;
	}

	/**
	 * @param inEligiblePlanMsg the inEligiblePlanMsg to set
	 */
	public void setInEligiblePlanMsg(String inEligiblePlanMsg) {
		this.inEligiblePlanMsg = inEligiblePlanMsg;
	}

	/**
	 * @return String return the eligiblePlanPLPLink
	 */
	@Override
	public String getEligiblePlanPLPLink() {
		return eligiblePlanPLPLink;
	}

	/**
	 * @param eligiblePlanPLPLink the eligiblePlanPLPLink to set
	 */
	public void setEligiblePlanPLPLink(String eligiblePlanPLPLink) {
		this.eligiblePlanPLPLink = eligiblePlanPLPLink;
	}

	/**
	 * @return String return the promoDcotCtaLink
	 */
	@Override
	public String getPromoDcotCtaLink() {
		return promoDcotCtaLink;
	}

	/**
	 * @return String return the promoDcotChrunCtaLink
	 */
	@Override
	public String getPromoDcotChrunCtaLink() {
		return promoDcotChrunCtaLink;
	}


	/**
	 * @param promoDcotCtaLink the promoDcotCtaLink to set
	 */
	public void setPromoDcotCtaLink(String promoDcotCtaLink) {
		this.promoDcotCtaLink = promoDcotCtaLink;
	}
	/**
	 * @param promoDcotChrunCtaLink the promoDcotChrunCtaLink to set
	 */
	public void setPromoDcotChrunCtaLink(String promoDcotChrunCtaLink) {
		this.promoDcotChrunCtaLink = promoDcotChrunCtaLink;
	}


	/**
	 * <p>
	 * Fetches enablePromotionalOffers
	 * </p>
	 *
	 * @return the enablePromotionalOffers
	 */
	@Override
	public String getEnableDcotPromoOffers() {
		return enableDcotPromoOffers;
	}

	/**
	 * <p>
	 * Sets enableDcotPromoOffers
	 * </p>
	 *
	 * @param enableDcotPromoOffers - the enableDcotPromoOffers to set
	 */
	public void setEnableDcotPromoOffers(String enableDcotPromoOffers) {
		this.enableDcotPromoOffers = enableDcotPromoOffers;
	}

	/**
	 * <p>
	 * Fetches dcotPromoTextPopupPDP
	 * </p>
	 *
	 * @return the dcotPromoTextPopupPDP
	 */
	@Override
	public String getDcotPromoTextPopupPDP(){
		return dcotPromoTextPopupPDP;
	}

	/**
	 * <p>
	 * Sets dcotPromoTextPopupPDP
	 * </p>
	 *
	 * @param dcotPromoTextPopupPDP - the dcotPromoTextPopupPDP to set
	 */
	public void setDcotPromoTextPopupPDP(String dcotPromoTextPopupPDP) {
		this.dcotPromoTextPopupPDP = dcotPromoTextPopupPDP;
	}

	/**
	 * <p>
	 * Fetches dcotPromoTextPopupHeadingPDP
	 * </p>
	 *
	 * @return the dcotPromoTextPopupHeadingPDP
	 */
	@Override
	public String getDcotPromoTextPopupHeadingPDP(){
		return dcotPromoTextPopupHeadingPDP;
	}

	/**
	 * <p>
	 * Sets dcotPromoTextPopupHeadingPDP
	 * </p>
	 *
	 * @param dcotPromoTextPopupHeadingPDP - the dcotPromoTextPopupHeadingPDP to set
	 */
	public void setDcotPromoTextPopupHeadingPDP(String dcotPromoTextPopupHeadingPDP) {
		this.dcotPromoTextPopupHeadingPDP = dcotPromoTextPopupHeadingPDP;
	}

	/**
	 * <p>
	 * Fetches dcotPromoPlantextonPDP
	 * </p>
	 *
	 * @return the dcotPromoPlantextonPDP
	 */
	@Override
	public String getDcotPromoPlantextonPDP(){
		return dcotPromoPlantextonPDP;
	}

	/**
	 * <p>
	 * Sets dcotPromoPlantextonPDP
	 * </p>
	 *
	 * @param dcotPromoPlantextonPDP - the dcotPromoPlantextonPDP to set
	 */
	public void setDcotPromoPlantextonPDP(String dcotPromoPlantextonPDP) {
		this.dcotPromoPlantextonPDP = dcotPromoPlantextonPDP;
	}

	/**
	 * <p>
	 * Sets dcotFullpricePromoTextPDP
	 * </p>
	 *
	 * @param dcotFullpricePromoTextPDP - the dcotFullpricePromoTextPDP to set
	 */
	public void setDcotFullpricePromoTextPDP(String dcotFullpricePromoTextPDP) {
		this.dcotFullpricePromoTextPDP = dcotFullpricePromoTextPDP;
	}

	/**
	 * <p>
	 * Fetches dcotFullpricePromoTextPDP
	 * </p>
	 *
	 * @return the dcotFullpricePromoTextPDP
	 */
	@Override
	public String getDcotFullpricePromoTextPDP(){
		return dcotFullpricePromoTextPDP;
	}


	/**
	 * <p>
	 * Fetches veriffPromoTextPopupPDP
	 * </p>
	 *
	 * @return the veriffPromoTextPopupPDP
	 */
	@Override
	public String getVeriffPromoTextPopupPDP(){
		return veriffPromoTextPopupPDP;
	}

	/**
	 * <p>
	 * Sets veriffPromoTextPopupPDP
	 * </p>
	 *
	 * @param veriffPromoTextPopupPDP - the veriffPromoTextPopupPDP to set
	 */
	public void setVeriffPromoTextPopupPDP(String veriffPromoTextPopupPDP) {
		this.veriffPromoTextPopupPDP = veriffPromoTextPopupPDP;
	}

	/**
	 * <p>
	 * Fetches veriffPromoTextPopupHeadingPDP
	 * </p>
	 *
	 * @return the veriffPromoTextPopupHeadingPDP
	 */
	@Override
	public String getVeriffPromoTextPopupHeadingPDP(){
		return veriffPromoTextPopupHeadingPDP;
	}

	/**
	 * <p>
	 * Sets veriffPromoTextPopupHeadingPDP
	 * </p>
	 *
	 * @param veriffPromoTextPopupHeadingPDP - the veriffPromoTextPopupHeadingPDP to set
	 */
	public void setVeriffPromoTextPopupHeadingPDP(String veriffPromoTextPopupHeadingPDP) {
		this.veriffPromoTextPopupHeadingPDP = veriffPromoTextPopupHeadingPDP;
	}

	/**
	 * <p>
	 * Fetches veriffPromoPlantextonPDP
	 * </p>
	 *
	 * @return the veriffPromoPlantextonPDP
	 */
	@Override
	public String getVeriffPromoPlantextonPDP(){
		return veriffPromoPlantextonPDP;
	}

	/**
	 * <p>
	 * Sets veriffPromoPlantextonPDP
	 * </p>
	 *
	 * @param veriffPromoPlantextonPDP - the veriffPromoPlantextonPDP to set
	 */
	public void setVeriffPromoPlantextonPDP(String veriffPromoPlantextonPDP) {
		this.veriffPromoPlantextonPDP = veriffPromoPlantextonPDP;
	}


	/**
	 * <p>
	 * Fetches portInPromoTextPopupPDP
	 * </p>
	 *
	 * @return the portInPromoTextPopupPDP
	 */
	@Override
	public String getPortInPromoTextPopupPDP(){
		return portInPromoTextPopupPDP;
	}

	/**
	 * <p>
	 * Sets portInPromoTextPopupPDP
	 * </p>
	 *
	 * @param portInPromoTextPopupPDP - the portInPromoTextPopupPDP to set
	 */
	public void setPortInPromoTextPopupPDP(String portInPromoTextPopupPDP) {
		this.portInPromoTextPopupPDP = portInPromoTextPopupPDP;
	}

	/**
	 * <p>
	 * Fetches portInPromoTextPopupHeadingPDP
	 * </p>
	 *
	 * @return the portInPromoTextPopupHeadingPDP
	 */

	@Override
	public String getPortInPromoTextPopupHeadingPDP(){
		return portInPromoTextPopupHeadingPDP;
	}

	/**
	 * <p>
	 * Sets portInPromoTextPopupHeadingPDP
	 * </p>
	 *
	 * @param portInPromoTextPopupHeadingPDP - the portInPromoTextPopupHeadingPDP to set
	 */
	public void setPortInPromoTextPopupHeadingPDP(String portInPromoTextPopupHeadingPDP) {
		this.portInPromoTextPopupHeadingPDP = portInPromoTextPopupHeadingPDP;
	}

	/**
	 * <p>
	 * Fetches portInPromoPlantextonPDP
	 * </p>
	 *
	 * @return the portInPromoPlantextonPDP
	 */
	@Override
	public String getPortInPromoPlantextonPDP(){
		return portInPromoPlantextonPDP;
	}

	/**
	 * <p>
	 * Sets portInPromoPlantextonPDP
	 * </p>
	 *
	 * @param portInPromoPlantextonPDP - the portInPromoPlantextonPDP to set
	 */
	public void setPortInPromoPlantextonPDP(String portInPromoPlantextonPDP) {
		this.portInPromoPlantextonPDP = portInPromoPlantextonPDP;
	}

	/**
	 * <p>
	 * Fetches activationPromoPopupPDP
	 * </p>
	 *
	 * @return the activationPromoPopupPDP
	 */
	@Override
	public String getActivationPromoPopupPDP(){
		return activationPromoPopupPDP;
	}

	/**
	 * <p>
	 * Sets activationPromoPopupPDP
	 * </p>
	 *
	 * @param activationPromoPopupPDP - the activationPromoPopupPDP to set
	 */
	public void setActivationPromoPopupPDP(String activationPromoPopupPDP) {
		this.activationPromoPopupPDP = activationPromoPopupPDP;
	}

	/**
	 * <p>
	 * Fetches activationPromoPopupHeadingPDP
	 * </p>
	 *
	 * @return the activationPromoPopupHeadingPDP
	 */
	@Override
	public String getActivationPromoPopupHeadingPDP(){
		return activationPromoPopupHeadingPDP;
	}

	/**
	 * <p>
	 * Sets activationPromoPopupHeadingPDP
	 * </p>
	 *
	 * @param activationPromoPopupHeadingPDP - the activationPromoPopupHeadingPDP to set
	 */
	public void setActivationPromoPopupHeadingPDP(String activationPromoPopupHeadingPDP) {
		this.activationPromoPopupHeadingPDP = activationPromoPopupHeadingPDP;
	}

	/**
	 * <p>
	 * Fetches activationPromoPlantextonPDP
	 * </p>
	 *
	 * @return the activationPromoPlantextonPDP
	 */
	@Override
	public String getActivationPromoPlantextonPDP(){
		return activationPromoPlantextonPDP;
	}

	/**
	 * <p>
	 * Sets activationPromoPlantextonPDP
	 * </p>
	 *
	 * @param activationPromoPlantextonPDP - the activationPromoPlantextonPDP to set
	 */
	public void setActivationPromoPlantextonPDP(String activationPromoPlantextonPDP) {
		this.activationPromoPlantextonPDP = activationPromoPlantextonPDP;
	}

}
