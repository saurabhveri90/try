package com.tracfonecore.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.tracfonecore.core.utils.ApplicationUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class NavigationLinksItemModel {

	@Self
	private Resource resource;
	
	@ValueMapValue(name="linktext")
	private String linkText;
	
	@ValueMapValue(name="linktextloggedin")
	private String linkTextLoggedin;
	
	@ValueMapValue(name="linkurl")
	private String linkUrl;
	
	@ValueMapValue(name="newWindow")
	private String newWindow;
	
	@ValueMapValue(name="linkalttext")
	private String linkAltText;

	@ValueMapValue(name="loggedinlinkalttext")
	private String loggedinLinkAltText;	
	
	@ValueMapValue(name="doNotFollowLink")
	@Default(booleanValues = false)
	private Boolean doNotFollowLink;

	/**
	 * @return the linkText
	 */
	public String getLinkText() {
		return linkText;
	}

	/**
	 * @return the linkUrl
	 */
	public String getLinkUrl() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), linkUrl);
	}

	/**
	 * @return the newWindow
	 */
	public String getNewWindow() {
		return newWindow;
	}

	/**
	 * @return the linkAltText
	 */
	public String getLinkAltText() {
		return linkAltText;
	}

	/**
	 * @return the doNotFollowLink
	 */
	public Boolean getDoNotFollowLink() {
		return doNotFollowLink;
	}
	
	/**
	 * @return the linkTextLoggedin
	 */
	public String getLinkTextLoggedin() {
		return linkTextLoggedin;
	}
	/**
	 * @return the loggedinLinkAltText
	 */
	public String getLoggedinLinkAltText() {
		return loggedinLinkAltText;
	}
	
}

