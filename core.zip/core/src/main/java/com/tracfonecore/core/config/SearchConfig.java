package com.tracfonecore.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Tracfone Core - Search Config Service", description = "Configurations for Search are added here")
public @interface SearchConfig {

    @AttributeDefinition(name = "Search Api Domain",description = "Domain for Search Api")
    String searchApiDomain() default "https://search-api.swiftype.com/api/v1";
    
    @AttributeDefinition(name = "Search Api Path",description = "Uri for Search Api")
    String searchApiPath() default "/public/engines/search.json";
    
    @AttributeDefinition(name = "Search Api Engine Key",description = "Engine Key for Search Api", type = AttributeType.STRING)
    String[] searchApiEngineKey() default {"STRAIGHT_TALK:en:z4WE3KmXJg5k4jV3A-5p","STRAIGHT_TALK:es:z4WE3KmXJg5k4jV3A-5p","TRACFONE:en:z4WE3KmXJg5k4jV3A-5p"};

    @AttributeDefinition(name = "Search Api Fetch Fields",description = "Fetch Fields for Search Api")
    String[] searchApiFetchFields() default {"STRAIGHT_TALK:image,url,title,description,product_partnumber,sections,product_type,category","TRACFONE:image,url,title,description,product_partnumber,sections,product_type,category"};
    
    @AttributeDefinition(name = "Search Api Search Fields",description = "Search Fields for Search Api")
    String[] searchApiSearchFields() default {"STRAIGHT_TALK:sections,keywords","TRACFONE:sections,keywords"};
    
    @AttributeDefinition(name = "Search Api Facet Fields",description = "Facet Fields for Search Api")
    String[] searchApiFacetFields() default {"STRAIGHT_TALK:category","TRACFONE:category"};

    @AttributeDefinition(name = "Search Auto Complete Api Domain",description = "Domain for Search Auto Complete Api")
    String searchAutoCompleteApiDomain() default "https://api.swiftype.com";
    
    @AttributeDefinition(name = "Search Auto Complete Api Path",description = "Uri for Search Auto Complete Api.{engine_id} will be replaced with Engine Id.")
    String searchAutoCompleteApiPath() default "/api/v1/engines/{engine_id}/analytics/top_queries.json";
   
    @AttributeDefinition(name = "Search Auto Complete Api Engine Id",description = "Engine Id for Search Auto Complete Api", type = AttributeType.STRING)
    String[] searchAutoCompleteApiEngineId() default {"STRAIGHT_TALK:en:straight-talk-wireless","STRAIGHT_TALK:es:straight-talk-wireless"};
}



