/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;


import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the model for APN Settings component
 */
public interface ApnSettingsModel extends ComponentExporter {

	
	/**
	 * <p>Title of APN Settings component</p>
	 * 
	 * @return String - title
	 */
	@JsonProperty("title")
	public String getTitle();

	/**
	 * <p>Instructions Heading.</p>
	 *
	 * @return String - instructionsHeading.
	 */
	@JsonProperty("instructionsHeading")
	public String getInstructionsHeading();
	
	/**
	 * <p>Settings Update Alert Box Title.</p>
	 *
	 * @return String - settingsUpdateAlertBoxTitle.
	 */
	@JsonProperty("settingsUpdateAlertBoxTitle")
	public String getSettingsUpdateAlertBoxTitle();
	
	/**
	 * <p>Settings Update Alert Box Summary</p>
	 * 
	 * @return String - settingsUpdateAlertBoxSummary
	 */
	@JsonProperty("settingsUpdateAlertBoxSummary")
	public String getSettingsUpdateAlertBoxSummary();

	/**
	 * <p>Disclaimer Text</p>
	 *
	 * @return String - disclaimerText.
	 */
	@JsonProperty("disclaimerText")
	public String getDisclaimerText();
	
	/**
	 * <p>Footer Text</p>
	 *
	 * @return String - footerText.
	 */
	@JsonProperty("footerText")
	public String getFooterText();
	
	/**
	 * <p>Help Modal Link Text</p>
	 *
	 * @return String - helpModalLinkText.
	 */
	@JsonProperty("helpModalLinkText")
	public String getHelpModalLinkText();
	
	/**
	 * <p>Help Modal Content</p>
	 *
	 * @return String - helpModalContent.
	 */
	@JsonProperty("helpModalContent")
	public String getHelpModalContent();
	
}
