/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
 package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.sling.api.resource.Resource;
import org.osgi.annotation.versioning.ProviderType;

import java.util.Map;

/**
 * Defines the {@code DeviceAccessoryDetailModel} Sling Model used for the {@code /apps/tracfone-core/components/commerce/deviceaccessorydetail} component.
 */

@ProviderType
public interface DeviceAccessoryDetailModel extends ComponentExporter {
	/**
	 * Get  multiple images
	 * @return image
	 */
	public Resource getMultilinks();

	/**
	 * <p>Fetches featurelabel of the product</p>
	 * 
	 * @return String - featurelabel of the product
	 */
	@JsonProperty("featurelabel")
	public String getFeaturelabel();
	
    
	/**
	 * <p>Fetches desclabel of the product</p>
	 * 
	 * @return String - desclabel
	 */
	@JsonProperty("desclabel")
	public String getDesclabel();
	
	/**
	 * <p>Fetches description for the product</p>
	 * 
	 * @return String - description
	 */
	@JsonProperty("description")
	public String getDescription();

	/**
	 * <p>Fetches category type of the page</p>
	 *
	 * @return String - selected category type
	 */
	@JsonProperty("categoryType")
	public String getCategoryType();

	/**
	 * <p>Fetches language</p>
	 *
	 * @return String - language
	 */
    public String getLanguage();

	/**
	 * <p>Fetches queryString for the price api call</p>
	 *
	 * @return String - queryString
	 */
	public String getQueryString();

	/**
	 * <p> Method to return Api domain</p>
	 *
	 * @return String
	 */
	public String getApiDomain();

	/**
	 * <p> Method to return Price Api path</p>
	 *
	 * @return String
	 */
	public String getPriceApiPath();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return int - home Page Level
	 */
	public int getHomePageLevel();

	/**
	 * <p>
	 * Fetches the export child items
	 * </p>
	 *
	 *
	 * @return Map<String, ? extends ComponentExporter> - the export child items
	 */
	public Map<String, ? extends ComponentExporter> getItems();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - name
	 */
	public String getName();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - image path
	 */
	public String getImage();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - Cantentry Id
	 */
	public String getCantentryId();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - get Color
	 */
	public String getColor();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - get sku id
	 */
	public String getSkuId();

	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - PlanThumbnailImageAssetId
	 */
	public String getThumbnailImageAssetId();
	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - ThumbnailImageAssetAgencyId
	 */
	public String getThumbnailImageAssetAgencyId();
	/**
	 * <p>Fetches home Page Level</p>
	 *
	 * @return String - ID
	 */
	Integer getId();
	/**
	 * <p>
	 * Returns selection authored
	 * </p>
	 * 
	 * @return String - selection
	 */
	public String getSelection();

    String getInventoryApiPath();

	String getInventoryQueryString();
	
	/**
	 * <p>Fetches pricecaptionplp of the product</p>
	 * 
	 * @return String - pricecaptionplp
	 */
	@JsonProperty("pricecaptionplp")
	public String getPricecaptionplp();

	/**
	 * <p>Fetches firstImagePath of the product</p>
	 * 
	 * @return String - firstImagePath
	 */
	@JsonProperty("firstImagePath")
	public String getFirstImagePath();
	   /**
     * returns tab links
     * @return tabLinks
     * @throws SchemaViolationError
     */
    public Resource getTablinks();
    /**
	 *<p>Fetches retailPriceLabel</p>
	 *
	 * @return the retailPriceLabel
	 */
 	public String getRetailPriceLabel() ;
 	/**
	 * <p>Sets retailPriceLabel</p>
	 *
	 *@param retailPriceLabel - the retailPriceLabel to set
	 */
	public void setRetailPriceLabel(String retailPriceLabel);
	/**
	 *<p>Fetches showPriceDetailsAboveImg</p>
	 *
	 * @return the showPriceDetailsAboveImg
	 */
	public String getShowPriceDetailsAboveImg();

	/**
	 * <p>Sets showPriceDetailsAboveImg</p>
	 *
	 *@param showPriceDetailsAboveImg - the showPriceDetailsAboveImg to set
	 */
	public void setShowPriceDetailsAboveImg(String showPriceDetailsAboveImg);
	/**
	 *<p>Fetches tabLinksSize</p>
	 *
	 * @return the tabLinksSize
	 */
	public int getTabLinksSize() ;

	/**
	 * <p>Sets tabLinksSize</p>
	 *
	 *@param tabLinksSize - the tabLinksSize to set
	 */
	public void setTabLinksSize(int tabLinksSize);
	
	/**
	  * <p>
	  * Fetches show timer option
	  * </p>
	  * 
	  * @return String - Show Timer
	 */
	public String getShowTimer();
	/**
	 *
	 * @return String - Edit product URL for accessory type products.
	 * */
	public String getAccessoryEditUrl();
	/**
	 * 
	 * @return String - Make
	 */
	public String getMake();
	/**
	  * <p>
	  * Fetches Marketing Ids
	  * </p>
	  * 
	  * @return String - Marketing Ids
	 */
	public String getMarketingIds();
	/**
	 * <p>Fetches homeInternetDiscountPrice of the product</p>
	 * 
	 * @return String - homeInternetDiscountPrice
	 */
	@JsonProperty("homeInternetDiscountPrice")
	public String getHomeInternetDiscountPrice();

}
