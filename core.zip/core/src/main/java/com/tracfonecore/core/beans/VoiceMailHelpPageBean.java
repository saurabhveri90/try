/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;


/**
 * <p>Defines bean to hold Advertisement card detail</p>
 */
public class VoiceMailHelpPageBean {

	private String brandType;
	private String instructionContent;
	private String resetPasswordContent;
	
	/**
	 * <p>Fetches brand type</p>
	 * 
	 * @return String - brand type
	 */
	public String getBrandType() {
		return brandType;
	}

	/**
	 * <p>Fetches instruction text </p>
	 * 
	 * @return String - instruction content
	 */
	public String getInstructionContent() {
		return instructionContent;
	}
	
	/**
	 * <p>Fetches reset password text </p>
	 * 
	 * @return String - reset password Content 
	 */
	public String getResetPasswordContent() {
		return resetPasswordContent;
	}

	/**
	 * <p>Sets brandType</p>
	 *
	 *@param brandType - the brandType to set
	 */
	public void setBrandType(String brandType) {
		this.brandType = brandType;
	}

	/**
	 * <p>Sets instructionContent</p>
	 *
	 *@param instructionContent - the instructionContent to set
	 */
	public void setInstructionContent(String instructionContent) {
		this.instructionContent = instructionContent;
	}

	/**
	 * <p>Sets resetPasswordContent</p>
	 *
	 *@param resetPasswordContent - the resetPasswordContent to set
	 */
	public void setResetPasswordContent(String resetPasswordContent) {
		this.resetPasswordContent = resetPasswordContent;
	}	
	
	
}
