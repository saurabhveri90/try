package com.tracfonecore.core.models.impl;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.BannerItemModel;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { BannerItemModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/banneritem", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class BannerItemModelImpl extends BaseComponentModelImpl implements BannerItemModel {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BannerItemModelImpl.class);
	@Self
	private SlingHttpServletRequest request;
	
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
	@ValueMapValue
	private String title;
	@ValueMapValue
	private String summary;
	
	@ValueMapValue
	private String mediaPath;
	
	@ValueMapValue
	private String useFullWidth;
	
	@ValueMapValue
	private String mobileMediaPath;
	
	@ValueMapValue
	private String tabletMediaPath;
	
	@ValueMapValue
	private String showTitleAsH1;
	
	@ValueMapValue
	private String carouselBannerNarrow;
	
	@ValueMapValue
	private String imgHeight;
	
	@Override
	public String getTitle() {
		return title;
	}
	@Override
	public String getSummary() {
		return summary;
	}
	@Override
	public String getMediaPath() {
		String s7Path = DynamicMediaUtils.changeMediaPathToDMPath(this.mediaPath, request.getResourceResolver());
		LOGGER.debug("Media Path: {}", s7Path);
		return s7Path;
	}
	@Override
	public String getUseFullWidth() {
		return useFullWidth;
	}
	@Override
	public String getMobileMediaPath() {
		String s7Path = DynamicMediaUtils.changeMediaPathToDMPath(this.mobileMediaPath, request.getResourceResolver());
		return s7Path;
	}
	
	@Override
	public String getTabletMediaPath() {
		String s7Path = DynamicMediaUtils.changeMediaPathToDMPath(this.tabletMediaPath, request.getResourceResolver());
		return s7Path;
	}	
	
	@Override
	public String getShowTitleAsH1() {
		return showTitleAsH1;
	}
	
	@Override
	public String getImgHeight() {
		return imgHeight;
	}
	
	@Override
	public String getCarouselBannerNarrow() {
		return carouselBannerNarrow;
	}	
}