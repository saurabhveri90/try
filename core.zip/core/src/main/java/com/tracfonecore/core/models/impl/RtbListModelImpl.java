package com.tracfonecore.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.FeatureBean;
import com.tracfonecore.core.models.RtbListModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { RtbListModel.class},
    resourceType = "tracfone-core/components/commerce/rtblist", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
    @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
    @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class RtbListModelImpl implements RtbListModel {

    //Constants
    private static final String FEATURE_TITLE = "value";
    private static final String FEATURE_DESCRIPTION = "description";
    private static final String FEATURE_LOGO = "featureLogo";
    private static final String FEATURE_ACCESSIBILITY_TEXT = "accessText";
    private static final String RTB_LIST = "rtbList";

    @Inject
	private Resource resource;
    
    @ValueMapValue
	private String title;

    @ValueMapValue
	private String subtitle;

	private List<FeatureBean> rtbList = Collections.emptyList();

    @PostConstruct
	protected void initModel() {
		rtbList = new ArrayList<FeatureBean>();
		for (Resource child : resource.getChildren()) {
			if(RTB_LIST.equals(child.getName())) {
				Iterator<Resource> it = child.listChildren();
				setMultiFieldItems(it, rtbList);
			}
		}
	}

    /**
     * <p>Populates a list with all the features</p>
     *
     * @param it             - iterator of the parent node
     * @param multiFieldData - list in which the features data needs to be set
     */
    private void setMultiFieldItems(Iterator<Resource> it, List<FeatureBean> multiFieldData) {
        while (it.hasNext()) {
            FeatureBean featureBean = new FeatureBean();
            Resource grandChild = it.next();
            featureBean.setFeatureTitle(grandChild.getValueMap().get(FEATURE_TITLE, String.class));
            featureBean.setFeatureDescription(grandChild.getValueMap().get(FEATURE_DESCRIPTION, String.class));
            featureBean.setFeatureLogo(grandChild.getValueMap().get(FEATURE_LOGO, String.class));
            featureBean.setAccessText(grandChild.getValueMap().get(FEATURE_ACCESSIBILITY_TEXT, String.class));
            multiFieldData.add(featureBean);
        }
    }

    @Override
    public String getTitle() {
        return title;
    }

    @Override
    public String getSubtitle() {
        return subtitle;
    }

    @Override
    public List<FeatureBean> getRtbList() {
        return new ArrayList<>(rtbList);
    }
    
}
