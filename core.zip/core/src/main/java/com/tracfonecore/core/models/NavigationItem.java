package com.tracfonecore.core.models;

import java.util.List;

import org.osgi.annotation.versioning.ConsumerType;

import com.adobe.cq.wcm.core.components.models.ListItem;
import com.drew.lang.annotations.Nullable;

/**
 * @author vijaykumar.tripathi
 *
 */
@ConsumerType
public interface NavigationItem extends ListItem {

 
    /**
     * Returns {@code true} if the page contained by this navigation item is active.
     *
     * @return {@code true} if it is the current page, otherwise {@code false}
     * 
     */
    default boolean isActive() {
        throw new UnsupportedOperationException();
    }

    /**
     * Returns the children of this {@code NavigationItem}, if any.
     *
     * @return the children of this {@code NavigationItem}; if this {@code NavigationItem} doesn't have any children, the returned
     * {@link java.util.List} will be empty
     * 
     */
    default List<NavigationItem> getChildren() {
        throw new UnsupportedOperationException();
    }

    /**
     * Returns the depth level of this {@code NavigationItem}.
     *
     * @return the depth level
     * 
     */
    default int getLevel() {
        throw new UnsupportedOperationException();
    }
    

   /**
     * Returns the name of this {@code ListItem}.
     *
     * @return the list item name or {@code null}
     */
    @Nullable
    default String getHighlightLink() {
        throw new UnsupportedOperationException();
    }
    /**
     * Returns the name of this {@code ListItem}.
     *
     * @return the list item name or {@code null}
     */
    @Nullable
    default String getQuickLinksHeading() {
        throw new UnsupportedOperationException();
    }
    /**
     * Returns the name of this {@code QuickLinks}.
     *
     * @return the list QuickLinks name or {@code null}
     */
    @Nullable
    default List<NavigationQuickLinksModel> getQuickLinks() {
        throw new UnsupportedOperationException();
    }
    /**
     * Returns the name of this {@code FlyoutType}.
     *
     * @return the list FlyoutType name or {@code null}
     */
    @Nullable
    default String getFlyoutType() {
        throw new UnsupportedOperationException();
    }

	/**
	 * @return the flyoutHeader
	 */
    @Nullable
    default String getFlyoutHeader() {
        throw new UnsupportedOperationException();
    }
	/**
	 * @return the flyoutHeader
	 */
    @Nullable
    default String getFlyoutHeaderLink() {
        throw new UnsupportedOperationException();
    }
	/**
	 * @return the flyoutButtonLabel
	 */
    @Nullable
    default String getFlyoutButtonLabel(){
        throw new UnsupportedOperationException();
    }

	/**
	 * @return the flyoutAriaLabel
	 */
    @Nullable
    default String getFlyoutAriaLabel(){
        throw new UnsupportedOperationException();
    }

	/**
	 * @return the flyoutButtonLink
	 */
    @Nullable
    default String getFlyoutButtonLink(){
        throw new UnsupportedOperationException();
    }
    
    /**
	 * @return the smallWidthNavDropdown
	 */
    @Nullable
    default String getSmallWidthNavDropdown(){
        throw new UnsupportedOperationException();
    }

    /**
	 * @return the needAuthentication
	 */
    @Nullable
    default String getNeedAuthentication(){
        throw new UnsupportedOperationException();
    }
    @Nullable
    default String getShowFlyoutHeaderAsNavitem() {
        throw new UnsupportedOperationException();
    }

}
