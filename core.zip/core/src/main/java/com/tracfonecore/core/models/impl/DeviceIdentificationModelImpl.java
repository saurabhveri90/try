package com.tracfonecore.core.models.impl;

import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.DeviceIdentificationModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { DeviceIdentificationModel.class,
		ComponentExporter.class }, resourceType = DeviceIdentificationModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class DeviceIdentificationModelImpl implements DeviceIdentificationModel {

	protected static final String RESOURCE_TYPE = "tracfone-core/components/commerce/deviceIdentification";
	@Self
	private SlingHttpServletRequest request;

	/**
	 * Inject device type
	 */
	@Inject
	@Via("resource")
	private String deviceType;

	/**
	 * Inject header text
	 */
	@Inject
	@Via("resource")
	private String headerText;

	/**
	 * Inject summary
	 */
	@Inject
	@Via("resource")
	private String summary;

	/**
	 * Inject help link label
	 */
	@Inject
	@Via("resource")
	private String helpLinkLabel;
	
	/**
	 * Inject help link modal id
	 */
	@Inject
	@Via("resource")
	private String helpLinkType;

	/**
	 * Inject help link modal id
	 */
	@Inject
	@Via("resource")
	private String helpLinkModalId;

	/**
	 * Inject help link accessibility
	 */
	@Inject
	@Via("resource")
	private String helpLinkAccessibility;

	/**
	 * Inject device Image
	 */
	@Inject
	@Via("resource")
	private String deviceImage;

	/**
	 * Inject image Alt Text
	 */
	@Inject
	@Via("resource")
	private String imageAltText;

	/**
	 * Inject scan Text Label
	 */
	@Inject
	@Via("resource")
	private String scanTextLabel;

	/**
	 * Inject input Field Label
	 */
	@Inject
	@Via("resource")
	private String inputFieldLabel;

	/**
	 * Inject input field placeholder
	 */
	@Inject
	@Via("resource")
	private String inputFieldPlaceholder;

	/**
	 * Inject the privacyPolicy Information
	 */
	@Inject
	@Via("resource")
	private String privacyPolicyInfo;

	/**
	 * Inject tnc Text
	 */
	@Inject
	@Via("resource")
	private String tncText;

	/**
	 * Inject button Label
	 */
	@Inject
	@Via("resource")
	private String buttonLabel;
	
	/**
	 * Inject help link imei modal id
	 */
	@Inject
	@Via("resource")
	private String helpLinkIMEIModalId;

	/**
	 * Inject button Label
	 */
	@Inject
	@Via("resource")
	private String secondButtonLabel;

	/**
	 * <p>
	 * Returns deviceType from properties
	 * </p>
	 * 
	 * @return String - deviceType
	 */
	@Override
	public String getDeviceType() {
		return deviceType;
	}

	/**
	 * <p>
	 * Returns headerText from properties
	 * </p>
	 * 
	 * @return String - headerText
	 */
	@Override
	public String getHeaderText() {
		return headerText;
	}

	/**
	 * <p>
	 * Returns summary from properties
	 * </p>
	 * 
	 * @return String - summary
	 */
	@Override
	public String getSummary() {
		return summary;
	}

	/**
	 * <p>
	 * Returns helpLinkLabel from properties
	 * </p>
	 * 
	 * @return String - helpLinkLabel
	 */
	@Override
	public String getHelpLinkLabel() {
		return helpLinkLabel;
	}

	/**
	 * @return the helpLinkType
	 */
	@Override
	public String getHelpLinkType() {
		return helpLinkType;
	}

	/**
	 * <p>
	 * Returns helpLinkModalId from properties
	 * </p>
	 * 
	 * @return the helpLinkModalId
	 */
	@Override
	public String getHelpLinkModalId() {
		return helpLinkModalId;
	}

	/**
	 * <p>
	 * Returns helpLinkAccessibility from properties
	 * </p>
	 * 
	 * @return String - helpLinkAccessibility
	 */
	@Override
	public String getHelpLinkAccessibility() {
		return helpLinkAccessibility;
	}

	/**
	 * <p>
	 * Returns deviceImage from properties
	 * </p>
	 * 
	 * @return String - deviceImage
	 */
	@Override
	public String getDeviceImage() {
		return deviceImage;
	}

	/**
	 * <p>
	 * Returns imageAltText from properties
	 * </p>
	 * 
	 * @return String - imageAltText
	 */
	@Override
	public String getImageAltText() {
		return imageAltText;
	}

	/**
	 * <p>
	 * Returns scanTextLabel from properties
	 * </p>
	 * 
	 * @return String - scanTextLabel
	 */
	@Override
	public String getScanTextLabel() {
		return scanTextLabel;
	}

	/**
	 * <p>
	 * Returns inputFieldLabel from properties
	 * </p>
	 * 
	 * @return String - inputFieldLabel
	 */
	@Override
	public String getInputFieldLabel() {
		return inputFieldLabel;
	}

	/**
	 * <p>
	 * Returns inputFieldPlaceholder from properties
	 * </p>
	 * 
	 * @return String - inputFieldPlaceholder
	 */
	@Override
	public String getInputFieldPlaceholder() {
		return inputFieldPlaceholder;
	}

	/**
	 * <p>
	 * Returns privacyPolicyInfo
	 * </p>
	 *
	 * @return String - privacyPolicyInfo
	 */
	@Override
	public String getPrivacyPolicyInfo() {
		return privacyPolicyInfo;
	}

	/**
	 * <p>
	 * Returns tncText from properties
	 * </p>
	 * 
	 * @return String - tncText
	 */
	@Override
	public String getTncText() {
		return tncText;
	}

	/**
	 * <p>
	 * Returns buttonLabel from properties
	 * </p>
	 * 
	 * @return String - buttonLabel
	 */
	@Override
	public String getButtonLabel() {
		return buttonLabel;
	}

	/**
	 * <p>
	 * Returns getexportertype from resource
	 * </p>
	 * 
	 * @return String - getexportertype
	 */
	@Override
	public String getExportedType() {

		return request.getResource().getResourceType();
	}
	
	/**
	 * <p>
	 * Returns helpLinkIMEIModalId from properties
	 * </p>
	 * 
	 * @return the helpLinkIMEIModalId
	 */
	@Override
	public String getHelpLinkIMEIModalId() {
		return helpLinkIMEIModalId;
	}

	/**
	 * <p>
	 * Returns secondButtonLabel from properties
	 * </p>
	 * 
	 * @return the secondButtonLabel
	 */
	@Override
	public String getSecondButtonLabel() {
		return secondButtonLabel;
	}

}
