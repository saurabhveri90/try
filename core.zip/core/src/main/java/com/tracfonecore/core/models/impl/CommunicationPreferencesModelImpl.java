/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.settings.SlingSettingsService;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.CommunicationPreferencesModel;
import com.tracfonecore.core.utils.ApplicationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CommunicationPreferencesModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/communicationpreferences", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CommunicationPreferencesModelImpl implements CommunicationPreferencesModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;
	
	@Inject
	private SlingSettingsService settingService;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String positionCommunicationPreferences;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String positionAccountNavigation;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String declarationText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String submitRequestLink;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String checkStatusLink;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String yourPrivacyChoicesLink;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String openNewTabYourPrivacyChoicesLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String openNewTabSubmitRequestLink;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String openNewTabCheckStatusLink;

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getPositionCommunicationPreferences() {
		return positionCommunicationPreferences;
	}

	@Override
	public String getPositionAccountNavigation() {
		return positionAccountNavigation;
	}

	@Override
	public String getDeclarationText() {
		return declarationText;
	}

	@Override
	public String getSubmitRequestLink() {
		String finalSubmitRequestLink = submitRequestLink;
		if (StringUtils.isNotBlank(finalSubmitRequestLink) &&  Boolean.TRUE.equals(ApplicationUtil.isInternalLink(finalSubmitRequestLink))) {
			if (finalSubmitRequestLink.indexOf(ApplicationConstants.HTML_EXTENSION) == -1) {
				finalSubmitRequestLink = finalSubmitRequestLink + ApplicationConstants.HTML_EXTENSION;
			}
			if (StringUtils.isNotBlank(finalSubmitRequestLink)) {
				String ctaPath = request.getResourceResolver().map(finalSubmitRequestLink);
				if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
					finalSubmitRequestLink = ApplicationUtil
							.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
				}
			}
		}
		return finalSubmitRequestLink;
	}

	@Override
	public String getYourPrivacyChoicesLink() {
		String finalYourPrivacyChoicesLink = yourPrivacyChoicesLink;
		if (StringUtils.isNotBlank(finalYourPrivacyChoicesLink) &&  Boolean.TRUE.equals(ApplicationUtil.isInternalLink(finalYourPrivacyChoicesLink))) {
			if (finalYourPrivacyChoicesLink.indexOf(ApplicationConstants.HTML_EXTENSION) == -1) {
				finalYourPrivacyChoicesLink = finalYourPrivacyChoicesLink + ApplicationConstants.HTML_EXTENSION;
			}
			if (StringUtils.isNotBlank(finalYourPrivacyChoicesLink)) {
				String ctaPath = request.getResourceResolver().map(finalYourPrivacyChoicesLink);
				if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
					finalYourPrivacyChoicesLink = ApplicationUtil
							.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
				}
			}
		}
		return finalYourPrivacyChoicesLink;
	}

	@Override
	public String getCheckStatusLink() {
		String finalCheckStatusLink = checkStatusLink;
		if (StringUtils.isNotBlank(finalCheckStatusLink) &&  Boolean.TRUE.equals(ApplicationUtil.isInternalLink(finalCheckStatusLink))) {
			if (finalCheckStatusLink.indexOf(ApplicationConstants.HTML_EXTENSION) == -1) {
				finalCheckStatusLink = finalCheckStatusLink + ApplicationConstants.HTML_EXTENSION;
			}
			if (StringUtils.isNotBlank(finalCheckStatusLink)) {
				String ctaPath = request.getResourceResolver().map(finalCheckStatusLink);
				if (!StringUtils.isEmpty(ctaPath) && ApplicationUtil.isPublish(settingService)) {
					finalCheckStatusLink = ApplicationUtil
							.getUrlWithoutDomain(getShortURL(request.getServerName(), ctaPath));
				}
			}
		}
		return finalCheckStatusLink;
	}

	@Override
	public String getOpenNewTabSubmitRequestLink() {
		return openNewTabSubmitRequestLink;
	}

	@Override
	public String getOpenNewTabYourPrivacyChoicesLink() {
		return openNewTabYourPrivacyChoicesLink;
	}
	
	@Override
	public String getOpenNewTabCheckStatusLink() {
		return openNewTabCheckStatusLink;
	}

	private String getShortURL(String serverDomain, String url) {
		if (StringUtils.isNotBlank(url) && StringUtils.isNotBlank(serverDomain) && url.contains(serverDomain)) {
			url = url.split(serverDomain)[1];
		}
		return url;
	}
}
