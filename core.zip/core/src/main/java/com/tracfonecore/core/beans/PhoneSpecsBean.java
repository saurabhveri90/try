package com.tracfonecore.core.beans;
/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */

public class PhoneSpecsBean {
private String description;
private String name;
private String value;
private String iconPath;
private String identifier ;
private String iconAssetId ;
private String iconWeberId ;
private String compareIconPath;
private String compareIconAssetId ;
private String compareIconWeberId ;
private String dataUnit;
private String summary;
private String multiplier;
private String show;
private String bucketName;
private String dataConversion;
private String thresholdValue;
private String bcfDescription;
private String bcfAddOnDescription;
private String bncfAddOnDescription;
private String thresholdLabel;
private String actualName;
private String thresholdUnit;
private String accessibilityText;

public String getIconPath() {
	return iconPath;
}
public void setIconPath(String iconPath) {
	this.iconPath = iconPath;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getName() { return name;}
public void setName(String name) {
	this.name = name;
}
public String getValue() {
	return value;
}
public void setValue(String value) {
	this.value = value;
}
public String getIdentifier() { return identifier; }
public void setIdentifier(String identifier) { this.identifier = identifier; }
public String getIconAssetId() {
	return iconAssetId;
}
public String getIconWeberId() {
	return iconWeberId;
}
public void setIconAssetId(String iconAssetId) {
	this.iconAssetId = iconAssetId;
}
public void setIconWeberId(String iconWeberId) {
	this.iconWeberId = iconWeberId;
}
public String getCompareIconPath() {
	return compareIconPath;
}
public String getCompareIconAssetId() {
	return compareIconAssetId;
}
public String getCompareIconWeberId() {
	return compareIconWeberId;
}
public void setCompareIconPath(String compareIconPath) {
	this.compareIconPath = compareIconPath;
}
public void setCompareIconAssetId(String compareIconAssetId) {
	this.compareIconAssetId = compareIconAssetId;
}
public void setCompareIconWeberId(String compareIconWeberId) {
	this.compareIconWeberId = compareIconWeberId;
}
/**
 *<p>Fetches dataUnit</p>
 *
 * @return the dataUnit
 */
public String getDataUnit() {
	return dataUnit;
}
/**
 * <p>Sets dataUnit</p>
 *
 *@param dataUnit - the dataUnit to set
 */
public void setDataUnit(String dataUnit) {
	this.dataUnit = dataUnit;
}
/**
 *<p>Fetches summary</p>
 *
 * @return the summary
 */
public String getSummary() {
	return summary;
}
/**
 * <p>Sets summary</p>
 *
 *@param summary - the summary to set
 */
public void setSummary(String summary) {
	this.summary = summary;
}
/**
 *<p>Fetches multiplier</p>
 *
 * @return the multiplier
 */
public String getMultiplier() {
	return multiplier;
}
/**
 * <p>Sets multiplier</p>
 *
 *@param multiplier - the multiplier to set
 */
public void setMultiplier(String multiplier) {
	this.multiplier = multiplier;
}
/**
 *<p>Fetches show</p>
 *
 * @return the show
 */
public String getShow() {
	return show;
}
/**
 * <p>Sets show</p>
 *
 *@param show - the show to set
 */
public void setShow(String show) {
	this.show = show;
}
/**
 *<p>Fetches bucketName</p>
 *
 * @return the bucketName
 */
public String getBucketName() {
	return bucketName;
}
/**
 * <p>Sets bucketName</p>
 *
 *@param bucketName - the bucketName to set
 */
public void setBucketName(String bucketName) {
	this.bucketName = bucketName;
}
/**
 *<p>Fetches dataConversion</p>
 *
 * @return the dataConversion
 */
public String getDataConversion() {
	return dataConversion;
}

/**
 * <p>Sets dataConversion</p>
 *
 *@param dataConversion - the dataConversion to set
 */
public void setDataConversion(String dataConversion) {
	this.dataConversion = dataConversion;
}
/**
 *<p>Fetches thresholdValue</p>
 *
 * @return the thresholdValue
 */
public String getThresholdValue() {
	return thresholdValue;
}
/**
 * <p>Sets thresholdValue</p>
 *
 *@param thresholdValue - the thresholdValue to set
 */
public void setThresholdValue(String thresholdValue) {
	this.thresholdValue = thresholdValue;
}
/**
 *<p>Fetches bcfDescription</p>
 *
 * @return the bcfDescription
 */
public String getBcfDescription() {
	return bcfDescription;
}
/**
 * <p>Sets bcfDescription</p>
 *
 *@param bcfDescription - the bcfDescription to set
 */
public void setBcfDescription(String bcfDescription) {
	this.bcfDescription = bcfDescription;
}
/**
 *<p>Fetches bcfAddOnDescription</p>
 *
 * @return the bcfAddOnDescription
 */
public String getBcfAddOnDescription() {
	return bcfAddOnDescription;
}
/**
 * <p>Sets bcfAddOnDescription</p>
 *
 *@param bcfAddOnDescription - the bcfAddOnDescription to set
 */
public void setBcfAddOnDescription(String bcfAddOnDescription) {
	this.bcfAddOnDescription = bcfAddOnDescription;
}
/**
 *<p>Fetches bcfAddOnDescription</p>
 *
 * @return the bcfAddOnDescription
 */
public String getBncfAddOnDescription() {
	return bncfAddOnDescription;
}
/**
 * <p>Sets bcfAddOnDescription</p>
 *
 *@param bcfAddOnDescription - the bcfAddOnDescription to set
 */
public void setBncfAddOnDescription(String bncfAddOnDescription) {
	this.bncfAddOnDescription = bncfAddOnDescription;
}
/**
 *<p>Fetches thresholdLabel</p>
 *
 * @return the thresholdLabel
 */

public String getThresholdLabel() {
	return thresholdLabel;
}
/**
 * <p>Sets thresholdLabel</p>
 *
 *@param thresholdLabel - the thresholdLabel to set
 */
public void setThresholdLabel(String thresholdLabel) {
	this.thresholdLabel = thresholdLabel;
}
/**
 * <p>Sets actualName</p>
 *
 *@param actualName - the actualName to set
 */
public void setActualName(String actualName) {
		this.actualName = actualName;
}
/**
 * <p>Sets actualName</p>
 *
 *@param actualName - the actualName to set
 */
public String getActualName() {
	return actualName;
}	

/**
 *<p>Fetches thresholdUnit</p>
 *
 * @return the thresholdUnit
 */
public String getThresholdUnit() {
	return thresholdUnit;
}
/**
 * <p>Sets thresholdUnit</p>
 *
 *@param thresholdUnit - the thresholdUnit to set
 */
public void setThresholdUnit(String thresholdUnit) {
	this.thresholdUnit = thresholdUnit;
}	

/**
 *<p>Fetches accessibilityText</p>
 *
 * @return the accessibilityText
 */
public String getAccessibilityText() {
	return accessibilityText;
}
/**
 * <p>Sets accessibilityText</p>
 *
 *@param accessibilityText - the accessibilityText to set
 */
public void setAccessibilityText(String accessibilityText) {
	this.accessibilityText = accessibilityText;
}
}


