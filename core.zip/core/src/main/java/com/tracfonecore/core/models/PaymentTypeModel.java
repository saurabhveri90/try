/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.LinkBean;

import java.util.List;

/**
 * Defines the {@code New Line} Sling Model used for the {@code /apps/tracfone-core/components/commerce/paymettype} component.
 */
public interface PaymentTypeModel extends ComponentExporter{

    /**
     * <p>Fetches heading</p>
     *
     * @return String - heading
     */
    @JsonProperty("heading")
    public String getHeading();

    /**
     * <p>Fetches summary</p>
     *
     * @return String - summary
     */
    @JsonProperty("summary")
    public String getSummary();

    /**
     * <p>Fetches all the multi-options</p>
     *
     * @return List - all the multi-options
     */
    @JsonProperty("options")
    public List<LinkBean> getOptions();

    /**
     * <p>Fetches promoPlaceholder</p>
     *
     * @return String - promoPlaceholder
     */
    @JsonProperty("promoPlaceholder")
    public String getPromoCodePlaceholder();

    /**
     * <p>Fetches modalName</p>
     *
     * @return String - modalName
     */
    @JsonProperty("modalName")
    public String getPromoCodeModalId();

    /**
     * <p>Fetches helpText</p>
     *
     * @return String - helpText
     */
    @JsonProperty("helpText")
    public String getHelpText();

    /**
     * <p>Fetches showpromo</p>
     *
     * @return String - showpromo
     */
    @JsonProperty("showpromo")
    public String getShowPromo();

    /**
     * <p>Fetches showpromocode</p>
     *
     * @return String - showpromocode
     */
    @JsonProperty("showpromocode")
    public Boolean getShowPromoCode();

}
