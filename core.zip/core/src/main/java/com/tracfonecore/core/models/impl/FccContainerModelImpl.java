package com.tracfonecore.core.models.impl;

import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.tracfonecore.core.models.FccContainerModel;
import com.tracfonecore.core.utils.ItemsExporterUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { FccContainerModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/fccContainer", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class FccContainerModelImpl extends BaseComponentModelImpl  implements FccContainerModel {
	
	@Self
	private SlingHttpServletRequest request;

	@Inject
	private SlingModelFilter slingModelFilter;

	@Inject
	private ModelFactory modelFactory;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String heading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String subheading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String pagetype;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String showFccButton;

	private static final Logger LOGGER = LoggerFactory.getLogger(FccPlanLabelsModelImpl.class);
	
	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering initModel method");
		super.initModel();

	}

	/**
	 * Method to obtain the string review heading
	 * @return String - Review Heading 
	 */
	@Override
	public String getHeading() {
		return heading;
	}

	/**
	 * Method to obtain the string review text
	 * @return String Review Text
	 */
	@Override
	public String getSubheading() {
		return subheading;
	}
	
	/**
	 * @return String - exportedType
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
	/**
	 * <p>
	 * Fetches the export child items
	 * </p>
	 *
	 * 
	 * @return Map<String, ? extends ComponentExporter> - the export child items
	 */
	@Override
	public Map<String, ? extends ComponentExporter> getItems() {
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}

	/**
	 * Method to obtain the page type
	 * @return Page Type
	 */
	@Override
	public String getPagetype() {
		return pagetype;
	}

	/**
	 * Method to obtain the string showFccButton
	 * @return String showFccButton Text
	 */
	@Override
	public String getShowFccButton() {
		return showFccButton;
	}

}
