package com.tracfonecore.core.models;

import java.util.List;
import java.util.Map;

import org.json.JSONArray;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

/**
 * Defines the {@code accessibilityfeatures} Sling Model used for the {@code /apps/tracfone-core/components/content/accessibilityfeatures} component.
 */
public interface FCCArchivalReportModel extends ComponentExporter{

    
   
   public String getName();

   public List<Map<String, String>> getLabelList();

   public int getLimitPDF();

   public String getMessageError();

}
