/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models;

import java.util.List;
import java.util.Map;

import org.apache.sling.api.resource.Resource;
import org.osgi.framework.Constants;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.ProductListFilterBean;

/**
 * Defines the {@code Product} Sling Model used for the
 * {@code /apps/tracfone-core/components/commerce/productlist} component.
 */
public interface ProductListModel extends ComponentExporter {

	/**
	 * <p>
	 * Fetches device Type Param
	 * </p>
	 *
	 * @return String - device Type Param
	 */
	@JsonProperty("deviceTypeParam")
	public String getDeviceTypeParam();

	/**
	 * <p>
	 * Fetches product type label
	 * </p>
	 *
	 * @return String - product type label
	 */
	@JsonProperty("categoryId")
	public String getCategoryId();

	/**
	 * <p>
	 * Fetches Category Type
	 * </p>
	 *
	 * @return String - Category Type
	 */
	@JsonProperty("categoryType")
	public String getCategoryType();

	/**
	 * <p>
	 * Fetches json Page Path
	 * </p>
	 *
	 * @return String - json Page Path
	 */
	@JsonProperty("jsonPagePath")
	public String getJsonPagePath();

	/**
	 * <p>
	 * Fetches title
	 * </p>
	 *
	 * @return String - title
	 */
	@JsonProperty("title")
	public String getTitle();

	/**
	 * <p>
	 * Fetches filters
	 * </p>
	 *
	 * @return String - filters
	 */
	@JsonProperty("filters")
	public List<ProductListFilterBean> getFilters();

	/**
	 * <p>
	 * Fetches product type label
	 * </p>
	 *
	 * @return String - product type label
	 */
	@JsonProperty("productTypeLabel")
	public String getProductTypeLabel();

	/**
	 * <p>
	 * Fetches check for hide product type
	 * </p>
	 *
	 * @return String - hide Product Types
	 */
	@JsonProperty("hideProductTypes")
	public String getHideProductTypes();

	/**
	 * <p>
	 * Fetches product type list
	 * </p>
	 *
	 * @return String - product Type List
	 */
	@JsonProperty("prodTypeList")
	public Resource getProdTypeList();

	/**
	 * <p>
	 * Fetches defaul No Of Cards
	 * </p>
	 *
	 * @return String - default No Of Cards
	 */
	@JsonProperty("defaultNoOfCards")
	public int getDefaultNoOfCards();

	/**
	 * <p>
	 * Fetches filterPromoPlans
	 * </p>
	 *
	 * @return String - filterPromoPlans
	 */
	@JsonProperty("filterPromoPlans")
	public String getFilterPromoPlans();

	/**
	 * <p>
	 * Fetches filterDeviceByManufacturer
	 * </p>
	 *
	 * @return String - filterDeviceByManufacturer
	 */
	@JsonProperty("filterDeviceByManufacturer")
	public String getFilterDeviceByManufacturer();

	/**
	 * <p>
	 * Fetches no Of Cards On Scroll
	 * </p>
	 *
	 * @return String - no Of Cards On Scroll
	 */
	@JsonProperty("noOfCardsOnScroll")
	public int getNoOfCardsOnScroll();

	/**
	 * <p>
	 * Fetches no Of Devices to Sort
	 * </p>
	 *
	 * @return String - no Of devices to Srot
	 */
	@JsonProperty("sortOutofStock")
	public int getSortOutofStock();

	/**
	 * <p>
	 * Fetches product Button Label
	 * </p>
	 *
	 * @return String - product Button Label
	 */
	@JsonProperty("productButtonLabel")
	public String getProductButtonLabel();

	/**
	 * <p>
	 * Fetches compare Link Label
	 * </p>
	 *
	 * @return String - compare Link Label
	 */
	@JsonProperty("compareLinkLabel")
	public String getCompareLinkLabel();

	/**
	 * <p>
	 * Fetches hide All Filters
	 * </p>
	 *
	 * @return String - hide All Filters
	 */
	@JsonProperty("hideAllFilters")
	public String getHideAllFilters();

	/**
	 * <p>
	 * Fetches all Filters Label
	 * </p>
	 *
	 * @return String - all Filters Label
	 */
	@JsonProperty("allFiltersLabel")
	public String getAllFiltersLabel();

	/**
	 * <p>
	 * Fetches clear All Label
	 * </p>
	 *
	 * @return String - clear All Label
	 */
	@JsonProperty("clearAllLabel")
	public String getClearAllLabel();

	/**
	 * <p>
	 * Fetches options Cta Label
	 * </p>
	 *
	 * @return String - options Cta Label
	 */
	@JsonProperty("optionsCtaLabel")
	public String getOptionsCtaLabel();

	/**
	 * <p>
	 * Fetches hide Sorting Dropdow
	 * </p>
	 *
	 * @return String - hide Sorting Dropdown
	 */
	@JsonProperty("hideSortingDropdown")
	public String getHideSortingDropdown();

	/**
	 * <p>
	 * Fetches sorting List
	 * </p>
	 *
	 * @return String - sorting List
	 */
	@JsonProperty("sortingList")
	public Resource getSortingList();

	/**
	 * <p>
	 * Fetches hide Zip Code
	 * </p>
	 *
	 * @return String - hide Zip Code
	 */
	@JsonProperty("hideZipCode")
	public String getHideZipCode();

	/**
	 * <p>
	 * Fetches zip Code Label
	 * </p>
	 *
	 * @return String - zip Code Label
	 */
	@JsonProperty("zipCodeLabel")
	public String getZipCodeLabel();

	/**
	 * <p>
	 * Fetches hide Upgrade Box
	 * </p>
	 *
	 * @return String - hide Upgrade Box
	 */
	@JsonProperty("hideUpgradeBox")
	public String getHideUpgradeBox();

	/**
	 * <p>
	 * Fetches upgrade Header Label
	 * </p>
	 *
	 * @return String - upgrade Header Label
	 */
	@JsonProperty("upgradeHeaderLabel")
	public String getUpgradeHeaderLabel();

	/**
	 * <p>
	 * Fetches upgrade Subtext Label
	 * </p>
	 *
	 * @return String - upgrade Subtext Label
	 */
	@JsonProperty("upgradeSubtextLabel")
	public String getUpgradeSubtextLabel();

	/**
	 * <p>
	 * Fetches input Placeholder Text
	 * </p>
	 *
	 * @return String - input Placeholder Text
	 */
	@JsonProperty("inputPlaceholderText")
	public String getInputPlaceholderText();

	/**
	 * <p>
	 * Fetches upgrade Button Label
	 * </p>
	 *
	 * @return String - upgrade Button Label
	 */
	@JsonProperty("upgradeButtonLabel")
	public String getUpgradeButtonLabel();

	/**
	 * <p>
	 * Fetches input upgrade Eligible Label
	 * </p>
	 *
	 * @return String - upgrade Eligible Label
	 */
	@JsonProperty("upgradeEligibleLabel")
	public String getUpgradeEligibleLabel();

	/**
	 * <p>
	 * Fetches change Number Button Label
	 * </p>
	 *
	 * @return String - change Number Button Label
	 */
	@JsonProperty("changeNumberButtonLabel")
	public String getChangeNumberButtonLabel();

	/**
	 * <p>
	 * Fetches button Notify Label
	 * </p>
	 *
	 * @return String - button Notify Label
	 */
	@JsonProperty("buttonNotifyLabel")
	public String getButtonNotifyLabel();

	/**
	 * <p>
	 * Fetches product OutOfStock Banner Text
	 * </p>
	 *
	 * @return String - product OutOfStock Banner Text
	 */
	@JsonProperty("productOutOfStockBannerText")
	public String getProductOutOfStockBannerText();

	/**
	 * <p>
	 * Fetches compare Tab Description
	 * </p>
	 *
	 * @return String - compare Tab Description
	 */
	@JsonProperty("compare Tab Description")
	public String getCompareTabDescription();

	/**
	 * <p>
	 * Fetches compare Button Label
	 * </p>
	 *
	 * @return String - compare Button Label
	 */
	@JsonProperty("compareButtonLabel")
	public String getCompareButtonLabel();

	/**
	 * <p>
	 * Fetches compare Button Link
	 * </p>
	 *
	 * @return String - compare Button Link
	 */
	@JsonProperty("compareButtonLink")
	public String getCompareButtonLink();

	/**
	 * <p>
	 * Fetches hpp Thumbnail Image AssestId
	 * </p>
	 *
	 * @return String - hpp Thumbnail Image AssestId
	 */
	@JsonProperty("hppThumbnailImageAssestId")
	public String getHppThumbnailImageAssestId();

	/**
	 * <p>
	 * Fetches hpp Thumbnail Image WeberId
	 * </p>
	 *
	 * @return String - hpp Thumbnail Image WeberId
	 */
	@JsonProperty("hppThumbnailImageWeberId")
	public String getHppThumbnailImageWeberId();

	/**
	 * <p>
	 * Fetches hpp Login Redirect Link
	 * </p>
	 *
	 * @return String - hpp Login Redirect Link
	 */
	@JsonProperty("hppLoginRedirectLink")
	public String getHppLoginRedirectLink();

	/**
	 * <p>
	 * Fetches hpp Guest Redirect Link
	 * </p>
	 *
	 * @return String - hpp Guest Redirect Link
	 */
	@JsonProperty("hppGuestRedirectLink")
	public String getHppGuestRedirectLink();

	/**
	 * <p>
	 * Fetches plan Thumbnail Image WeberId
	 * </p>
	 *
	 * @return String - plan Thumbnail Image WeberId
	 */
	@JsonProperty("planThumbnailImageWeberId")
	public String getPlanThumbnailImageWeberId();

	/**
	 * <p>
	 * Fetches planIdFacet
	 * </p>
	 *
	 * @return String - plan Id Facet
	 */
	@JsonProperty("planIdFacet")
	public String getPlanIdFacet();

	/**
	 * <p>
	 * Fetches planIdFacet
	 * </p>
	 *
	 * @return String - plan Id Facet
	 */
	@JsonProperty("offerHppTrueFacet")
	public String getOfferHppTrueFacet();

	/**
	 * <p>
	 * Fetches activationPlanTypeFacet
	 * </p>
	 *
	 * @return String - activation Plan Type Facet
	 */
	@JsonProperty("activationPlanTypeFacet")
	public String getActivationPlanTypeFacet();

	/**
	 * <p>
	 * Fetches purchasePlanTypeFacet
	 * </p>
	 *
	 * @return String - purchase Plan Type Facet
	 */
	@JsonProperty("purchasePlanTypeFacet")
	public String getPurchasePlanTypeFacet();

	/**
	 * <p>
	 * Fetches refillPlanTypeFacet
	 * </p>
	 *
	 * @return String - refill Plan Type Facet
	 */
	@JsonProperty("refillPlanTypeFacet")
	public String getRefillPlanTypeFacet();

	/**
	 * <p>
	 * Fetches servicePlanFacet
	 * </p>
	 *
	 * @return String - service Plan Facet
	 */
	@JsonProperty("servicePlanFacet")
	String getServicePlanFacet();

	/**
	 * <p>
	 * Fetches default Plan Thumbnail Image
	 * </p>
	 *
	 * @return String - default Plan Thumbnail Image
	 */
	@JsonProperty("defaultPlanThumbnailImage")
	public String getDefaultPlanThumbnailImage();

	/**
	 * <p>
	 * Fetches default Hpp Thumbnail Image
	 * </p>
	 *
	 * @return String - default Hpp Thumbnail Image
	 */
	@JsonProperty("defaultHppThumbnailImage")
	public String getDefaultHppThumbnailImage();

	/**
	 * <p>
	 * Fetches default Apple Care Hpp Thumbnail Image
	 * </p>
	 *
	 * @return String - default Apple Care Hpp Thumbnail Image
	 */
	@JsonProperty("defaultAppleCareHppThumbnailImage")
	public String getDefaultAppleCareHppThumbnail();

	/**
	 * <p>
	 * Fetches plan Thumbnail Image AssestId
	 * </p>
	 *
	 * @return String - plan Thumbnail Image AssestId
	 */
	@JsonProperty("planThumbnailImageAssestId")
	public String getPlanThumbnailImageAssestId();

	/**
	 * <p>
	 * Fetches home Page Level
	 * </p>
	 *
	 * @return int - home Page Level
	 */
	@JsonProperty("homePageLevel")
	public int getHomePageLevel();

	/**
	 * <p>
	 * Fetches brand Page Level
	 * </p>
	 *
	 * @return int - brand Page Level
	 */
	@JsonProperty("brandPageLevel")
	public int getBrandPageLevel();

	/**
	 * <p>
	 * Fetches language
	 * </p>
	 *
	 * @return String - language
	 */
	@JsonProperty(Constants.BUNDLE_NATIVECODE_LANGUAGE)
	public String getLanguage();

	/**
	 * <p>
	 * Fetches brand
	 * </p>
	 *
	 * @return String - brand
	 */
	@JsonProperty("brand")
	public String getBrand();

	/**
	 * <p>
	 * Fetches queryString for the price api call
	 * </p>
	 *
	 * @return String - queryString
	 */
	@JsonProperty("queryString")
	public String getQueryString();

	/**
	 * <p>
	 * Fetches turnOffPromoCard value
	 * </p>
	 *
	 * @return String - turnOffPromoCard
	 */
	@JsonProperty("turnOffPromoCard")
	public String getTurnOffPromoCard();

	/**
	 * <p>
	 * Fetches pageType value
	 * </p>
	 *
	 * @return String - pageType
	 */
	@JsonProperty("pageType")
	public String getPagetype();

	/**
	 * <p>
	 * Fetches plpPlantext value
	 * </p>
	 *
	 * @return String - plpPlantext
	 */
	String getPlpPlantext();

	/**
	 * <p>
	 * Fetches plpPlanSubtext value
	 * </p>
	 *
	 * @return String - plpPlanSubtext
	 */
	String getPlpPlanSubtext();

	/**
	 * <p>
	 * Fetches plpFlowHeader value
	 * </p>
	 *
	 * @return String - plpFlowHeader
	 */
	@JsonProperty("plpFlowHeader")
	public String getPlpFlowHeader();

	/**
	 * <p>
	 * Fetches plpFlowSubtext value
	 * </p>
	 *
	 * @return String - plpFlowSubtext
	 */
	@JsonProperty("plpFlowSubtext")
	public String getPlpFlowSubtext();

	/**
	 * <p>
	 * Fetches plpHeader value
	 * </p>
	 *
	 * @return String - plpHeader
	 */
	@JsonProperty("plpHeader")
	public String getPlpHeader();

	/**
	 * <p>
	 * Fetches pdpJsonPath value
	 * </p>
	 *
	 * @return String - pdpJsonPath
	 */
	@JsonProperty("pdpJsonPath")
	public String getPdpJsonPath();

	/**
	 * <p>
	 * Fetches seeDetailLinkLabel value
	 * </p>
	 *
	 * @return String - seeDetailLinkLabel
	 */
	@JsonProperty("seeDetailLinkLabel")
	public String getSeeDetailLinkLabel();

	/**
	 * <p>
	 * Fetches tncLinkLabel value
	 * </p>
	 *
	 * @return String - tncLinkLabel
	 */
	@JsonProperty("tncLinkLabel")
	public String getTncLinkLabel();

	/**
	 * <p>
	 * Fetches smartpayHeader value
	 * </p>
	 *
	 * @return String - smartpayHeader
	 */
	@JsonProperty("smartpayHeader")
	public String getSmartpayHeader();

	/**
	 * <p>
	 * Fetches smartpaySubtext value
	 * </p>
	 *
	 * @return String - smartpaySubtext
	 */
	@JsonProperty("smartpaySubtext")
	public String getSmartpaySubtext();

	/**
	 * <p>
	 * Fetches smartpayButtonLabel value
	 * </p>
	 *
	 * @return String - smartpayButtonLabel
	 */
	@JsonProperty("smartpayButtonLabel")
	public String getSmartpayButtonLabel();

	/**
	 * <p>
	 * Fetches smartpayButtonDescription value
	 * </p>
	 *
	 * @return String - smartpayButtonDescription
	 */
	@JsonProperty("smartpayButtonDescription")
	public String getSmartpayButtonDescription();

	/**
	 * <p>
	 * Fetches property to hide compare
	 * </p>
	 *
	 * @return String - the disableCompare
	 */
	@JsonProperty("disableBazaarVoiceRatings")
	public String getDisableBazaarVoiceRatings();

	/**
	 * <p>
	 * Method to return Client Id
	 * </p>
	 *
	 * @return String
	 */
	public String getClientID();

	/**
	 * <p>
	 * Method to return Marketing Id Facet
	 * </p>
	 *
	 * @return String
	 */
	public String getMarketingIdFacet();

	/**
	 * <p>
	 * Method to return Price Facet
	 * </p>
	 *
	 * @return String
	 */
	public String getPriceFacet();

	/**
	 * <p>
	 * Method to return Cart Page Path
	 * </p>
	 *
	 * @return String
	 */
	public String getCartPagePath();

	/**
	 * <p>
	 * Method to return Decline Url
	 * </p>
	 *
	 * @return String
	 */
	public String getDeclineUrl();

	/**
	 * <p>
	 * Method to return Amount Decline Url
	 * </p>
	 *
	 * @return String
	 */
	public String getAmountDeclineUrl();

	/**
	 * <p>
	 * Method to return Approval Url
	 * </p>
	 *
	 * @return String
	 */
	public String getApprovalUrl();

	/**
	 * <p>
	 * Method to return Zero Offer Denial Url
	 * </p>
	 *
	 * @return String
	 */
	public String getZeroOfferDenialUrl();

	/**
	 * <p>
	 * Method to return Price Api domain
	 * </p>
	 *
	 * @return String
	 */
	public String getApiDomain();

	/**
	 * <p>
	 * Fetches Category Api Path
	 * </p>
	 *
	 * @return String - Category Api Path
	 */
	public String getCategoryApiPath();

	/**
	 * <p>
	 * Fetches Marketing Api Path
	 * </p>
	 *
	 * @return String - Marketing Api Path
	 */
	public String getMarketingApiPath();

	/**
	 * <p>
	 * Fetches Upgrade Api Path
	 * </p>
	 *
	 * @return String - Upgrade Api Path
	 */
	public String getUpgradeApiPath();

	/**
	 * <p>
	 * Fetches Marketing Api Query String
	 * </p>
	 *
	 * @return String - Marketing Api Query String
	 */
	public String getMarketingQueryString();

	/**
	 * <p>
	 * Fetches ReCaptcha SiteKey property from config
	 * </p>
	 *
	 * @return String[] - reCaptchaSiteKey
	 */
	public String getReCaptchaSiteKey();

	/**
	 * <p>
	 * Fetches skipPlanType property from config
	 * </p>
	 *
	 * @return String[] - skipPlanType
	 */
	public String getSkipPlanType();

	/**
	 * <p>
	 * Returns resouce mgmt api url from configuration
	 * </p>
	 *
	 * @return String - resource mgmt api url
	 */
	public String getResourceMgmtApiPath();

	/**
	 * String is used for resource mgmt API call
	 *
	 * @return String - queryString
	 */
	public String getResourceMgmtQueryString();

	/**
	 * <p>
	 * Fetches the export child items
	 * </p>
	 *
	 * @return Map<String, ? extends ComponentExporter> - the export child items
	 */
	public Map<String, ? extends ComponentExporter> getItems();

	/**
	 * <p>
	 * Method to return exporter type
	 * </p>
	 *
	 * @return String
	 */
	@Override
	public String getExportedType();

	/**
	 * <p>
	 * Fetches Disable guest checkout flag
	 * </p>
	 *
	 * @return String - Disable guest checkout flag
	 */
	public String getDisableGuestCheckout();

	/**
	 * <p>
	 * Fetches disable refill
	 * </p>
	 *
	 * @return String - disable refill
	 */
	@JsonProperty("disableRefill")
	public String getDisableRefill();

	/**
	 * <p>
	 * Fetches Service plan page path
	 * </p>
	 *
	 * @return String - Service plan page path
	 */
	@JsonProperty("externalPlanPagePath")
	public String getExternalPlanPagePath();

	/**
	 * <p>
	 * Fetches Service plan page path target
	 * </p>
	 *
	 * @return String - Service plan page path target
	 */
	@JsonProperty("externalPlanPagePathTarget")
	public String getExternalPlanPagePathTarget();

	/**
	 * <p>
	 * Fetches Service plan page path target
	 * </p>
	 *
	 * @return String - Service plan page path target
	 */
	public String getPhoneUpgradeReferrerList();

	/**
	 * <p>
	 * Fetches banner text for current product
	 * </p>
	 *
	 * @return String - current Product Banner Text
	 */
	@JsonProperty("currentProductBannerText")
	public String getCurrentProductBannerText();

	/**
	 * <p>
	 * Fetches heading for other plan section
	 * </p>
	 *
	 * @return String - Other Plans Heading
	 */
	@JsonProperty("otherPlansHeading")
	public String getOtherPlansHeading();

	/**
	 * <p>
	 * Fetches description for other plan section
	 * </p>
	 *
	 * @return String - Other Plans Description
	 */
	@JsonProperty("otherPlansDescription")
	public String getOtherPlansDescription();

	/**
	 * <p>
	 * Fetches hide recaptcha box
	 * </p>
	 *
	 * @return String - hide recaptcha
	 */
	@JsonProperty("hideRecaptchaBox")
	public String getHideRecaptchaBox();

	/**
	 * Get the hotFlashModalId
	 *
	 * @return String - hotFlashModalId
	 */
	@JsonProperty("hotFlashModalId")
	public String getHotFlashModalId();

	/**
	 * Get the coldFlashModalId
	 *
	 * @return String - coldFlashModalId
	 */
	@JsonProperty("coldFlashModalId")
	public String getColdFlashModalId();

	/**
	 * <p>
	 * Fetches show Phone Number Field
	 * </p>
	 *
	 * @return String - showPhoneNoField
	 */
	@JsonProperty("showPhoneNoField")
	public String getShowPhoneNoField();

	/**
	 * <p>
	 * Fetches show Auto Refill Plans
	 * </p>
	 *
	 * @return String - showAutoRefillPlans
	 */
	@JsonProperty("showAutoRefillPlans")
	public String getShowAutoRefillPlans();

	/**
	 * <p>
	 * Fetches smartPayLogoSmall
	 * </p>
	 *
	 * @return String - smartPayLogoSmall
	 */
	@JsonProperty("smartpayLogoSmall")
	String getSmartpayLogoSmall();

	/**
	 * <p>
	 * Fetches allFiltersCountLabel
	 * </p>
	 *
	 * @return String - allFiltersCountLabel
	 */
	@JsonProperty("allFiltersCountLabel")
	String getAllFiltersCountLabel();

	/**
	 * <p>
	 * Fetches hideRewardsSection
	 * </p>
	 *
	 * @return String - hideRewardsSection
	 */
	@JsonProperty("hideRewardsSection")
	String getHideRewardsSection();

	/**
	 * <p>
	 * Fetches rewardsTitle
	 * </p>
	 *
	 * @return String - rewardsTitle
	 */
	@JsonProperty("rewardsTitle")
	String getRewardsTitle();

	/**
	 * <p>
	 * Fetches rewardsDescription
	 * </p>
	 *
	 * @return String - rewardsDescription
	 */
	@JsonProperty("rewardsDescription")
	String getRewardsDescription();

	/**
	 * <p>
	 * Fetches loginLinkLabel
	 * </p>
	 *
	 * @return String - loginLinkLabel
	 */
	@JsonProperty("loginLinkLabel")
	String getLoginLinkLabel();

	/**
	 * <p>
	 * Fetches loginLinkPath
	 * </p>
	 *
	 * @return String - loginLinkPath
	 */
	@JsonProperty("loginLinkPath")
	String getLoginLinkPath();

	/**
	 * <p>
	 * Fetches redeemLabel
	 * </p>
	 *
	 * @return String - redeemLabel
	 */
	@JsonProperty("redeemLabel")
	String getRedeemLabel();

	/**
	 * <p>
	 * Fetches redeemDescription
	 * </p>
	 *
	 * @return String - redeemDescription
	 */
	@JsonProperty("redeemDescription")
	String getRedeemDescription();

	/**
	 * <p>
	 * Fetches redeemButtonLabel
	 * </p>
	 *
	 * @return String - redeemButtonLabel
	 */
	@JsonProperty("redeemButtonLabel")
	String getRedeemButtonLabel();

	/**
	 * <p>
	 * Fetches redeemButtonPath
	 * </p>
	 *
	 * @return String - redeemButtonPath
	 */
	@JsonProperty("redeemButtonPath")
	String getRedeemButtonPath();

	/**
	 * <p>
	 * Fetches show timer option
	 * </p>
	 *
	 * @return String - Show Timer
	 */
	@JsonProperty("showTimer")
	public String getShowTimer();

	/**
	 * <p>
	 * Fetches show timer above header option
	 * </p>
	 *
	 * @return String - Above Header
	 */
	@JsonProperty("showTimerAboveUpgrade")
	public String getShowTimerAboveUpgrade();

	/**
	 * <p>
	 * Fetches the singleBucketText
	 * </p>
	 *
	 * @return String - singleBucketText
	 */
	public String getSingleBucketText();

	/**
	 * <p>
	 * Fetches the singleBucketUnit
	 * </p>
	 *
	 * @return String - singleBucketUnit
	 */
	public String getSingleBucketUnit();

	/**
	 * <p>
	 * Fetches the planServiceDaysLabel
	 * </p>
	 *
	 * @return String - planServiceDaysLabel
	 */
	@JsonProperty("planServiceDaysLabel")
	public String getPlanServiceDaysLabel();

	/**
	 * <p>
	 * Fetches the specsOptions
	 * </p>
	 *
	 * @return String - specsOptions
	 */
	public String getSpecsOptions();

	/**
	 * <p>
	 * Fetches check for Show only Service Plans
	 * </p>
	 *
	 * @return String - Show only Service Plans
	 */
	@JsonProperty("applyServicePlanFacet")
	public String getApplyServicePlanFacet();

	/**
	 * <p>
	 * Fetches check for Combine Plan Type Filters for Results
	 * </p>
	 *
	 * @return String - Combine Plan Type Filters for Results
	 */
	@JsonProperty("combineAllProductFacet")
	public String getCombineAllProductFacet();

	/**
	 * Method to return not show separate recommended hpp card
	 * </p>
	 *
	 * @return String - the turnOffSeparateHppCard
	 */
	@JsonProperty("turnOffSeparateHppCard")
	public String getTurnOffSeparateHppCard();

	/**
	 * <p>
	 * Method to return recommCardPromoText
	 * </p>
	 *
	 * @return String - the recommCardPromoText
	 */
	@JsonProperty("recommCardPromoText")
	public String getRecommCardPromoText();

	/**
	 * <p>
	 * Method to return otherProtectionPlansHeading
	 * </p>
	 *
	 * @return String - otherProtectionPlansHeading
	 */
	@JsonProperty("otherProtectionPlansHeading")
	public String getOtherProtectionPlansHeading();

	/**
	 * <p>
	 * Fetches check for Buy Now Rewards Help Text
	 * </p>
	 *
	 * @return String - Buy Now Rewards Help Text
	 */
	@JsonProperty("buyNowRewardsHelpText")
	public String getBuyNowRewardsHelpText();

	/**
	 * <p>
	 * Fetches property to hide compare
	 * </p>
	 *
	 * @return String - the disableCompare
	 */
	@JsonProperty("disableCompare")
	public String getDisableCompare();

	/**
	 * @return the planAddonPlp
	 */
	@JsonProperty("planAddonPlp")
	public String getPlanAddonPlp();

	/**
	 * <p>
	 * Fetches page path of HPP Standalone landing page
	 * </p>
	 *
	 * @return String - page path of HPP Standalone landing page
	 */
	@JsonProperty("hppStandalonePagePath")
	public String getHppStandalonePagePath();

	/**
	 * @return the payGoFacet
	 */
	@JsonProperty("payGoFacet")
	public String getPayGoFacet();

	/**
	 * <p>
	 * Fetches servicePlanFacet
	 * </p>
	 *
	 * @return String - service Plan Facet
	 */
	@JsonProperty("applyPurchasePlanFacet")
	String getApplyPurchasePlanFacet();

	/**
	 * <p>
	 * Method to return dealsCategoryId
	 * </p>
	 *
	 * @return the dealsCategoryId
	 */
	@JsonProperty("dealsCategoryId")
	public String getDealsCategoryId();

	/**
	 * <p>
	 * Method to return planCardButton1
	 * </p>
	 *
	 * @return the planCardButton1
	 */
	@JsonProperty("planCardButton1")
	public String getPlanCardButton1();

	/**
	 * <p>
	 * Method to return planCardButton2
	 * </p>
	 *
	 * @return the planCardButton2
	 */
	@JsonProperty("planCardButton2")
	public String getPlanCardButton2();

	/**
	 * <p>
	 * Method to return phoneCardInfo
	 * </p>
	 *
	 * @return the phoneCardInfo
	 */
	@JsonProperty("phoneCardInfo")
	public Resource getPhoneCardInfo();

	/**
	 * <p>
	 * Method to return recommendationsForYou
	 * </p>
	 *
	 * @return the recommendationsForYou
	 */
	@JsonProperty("recommendationsForYou")
	public String getRecommendationsForYou();

	/**
	 * <p>
	 * Method to return contactLabel
	 * </p>
	 *
	 * @return the contactLabel
	 */
	@JsonProperty("contactLabel")
	public String getContactLabel();

	/**
	 * <p>
	 * Method to return serviceEndDate
	 * </p>
	 *
	 * @return the serviceEndDate
	 */
	@JsonProperty("serviceEndDate")
	public String getServiceEndDate();

	/**
	 * <p>
	 * Method to return selectDifferentNumber
	 * </p>
	 *
	 * @return the selectDifferentNumber
	 */
	@JsonProperty("selectDifferentNumber")
	public String getSelectDifferentNumber();

	/**
	 * <p>
	 * Method to return enterDifferentNumber
	 * </p>
	 *
	 * @return the enterDifferentNumber
	 */
	@JsonProperty("enterDifferentNumber")
	public String getEnterDifferentNumber();

	/**
	 * <p>
	 * Method to return refillPagePath
	 * </p>
	 *
	 * @return the refillPagePath
	 */
	@JsonProperty("refillPagePath")
	public String getRefillPagePath();

	/**
	 * <p>
	 * Method to return getSbThresholdUnit
	 * </p>
	 *
	 * @return the getSbThresholdUnit
	 */
	public String getSbThresholdUnit();

	/**
	 * <p>
	 * Method to return isCUSGEnabled
	 * </p>
	 *
	 * @return the isCUSGEnabled
	 */
	public String isCUSGEnabled();

	/**
	 * <p>
	 * Method to return CUSG Logo
	 * </p>
	 *
	 * @return the CUSGLogo
	 */
	public String getCusgLogoUrl();

	/**
	 * <p>
	 * Method to return cusg promo text
	 * </p>
	 *
	 * @return the cusgPromoText
	 */
	public String getCusgPromoText();

	/**
	 * <p>
	 * Method to return cusg disclaimer text
	 * </p>
	 *
	 * @return the cusgDisclaimerText
	 */
	public String getCusgDisclaimerText();

	/**
	 * <p>
	 * Method to return cusg alt image text
	 * </p>
	 *
	 * @return the cusgImageAltText
	 */
	public String getCusgImgAltText();

	/**
	 * <p>
	 * Method to return singleBucketThresholdValue
	 * </p>
	 *
	 * @return the singleBucketThresholdValue
	 */
	public String getSbThresholdValue();

	/**
	 * <p>
	 * Method to return multiBucketThresholdLabel
	 * </p>
	 *
	 * @return the multiBucketThresholdLabel
	 */
	public String getThresholdLabel();

	/**
	 * <p>
	 * Method to return promoText1
	 * </p>
	 *
	 * @return the promoText1
	 */
	public String getPhonePromoText1();

	/**
	 * <p>
	 * Method to return promoText2
	 * </p>
	 *
	 * @return the promoText2
	 */
	public String getPhonePromoText2();

	/**
	 * <p>
	 * Method to return RecommendedProductsPartNoList
	 * </p>
	 *
	 * @return the RecommendedProductsPartNoList
	 */
	public String getRecommendedProductsPartNoList();

	/**
	 * <p>
	 * Method to return LogOut Registered User Path
	 * </p>
	 *
	 * @return the LogOut Registered User Path
	 */
	public String getLogOutRegisteredUserApiPath();

	/**
	 * <p>
	 * Method to return autoRefillEnrolledPromoText
	 * </p>
	 *
	 * @return the autoRefillEnrolledPromoText
	 */
	public String getAutoRefillEnrolledPromoText();

	/**
	 * <p>
	 * Fetches checkoutRedirectLink
	 * </p>
	 *
	 * @return String - checkout redirect link for logged-in intangible purchase
	 *         scenario
	 */
	@JsonProperty("checkoutRedirectLink")
	String getCheckoutRedirectLink();

	/**
	 * <p>
	 * Fetches guestRedirectLink
	 * </p>
	 *
	 * @return String - guest redirect link for intangible purchase scenario
	 */
	@JsonProperty("guestRedirectLink")
	String getGuestRedirectLink();

	/**
	 * <p>
	 * Fetches refillFlowPlpPath
	 * </p>
	 *
	 * @return String - redirect link for refill flow plp
	 */
	@JsonProperty("refillFlowPlpPath")
	String getRefillFlowPlpPath();

	/**
	 * <p>
	 * Fetches description for campaign type
	 * </p>
	 *
	 * @return String - Campaign Type
	 */
	@JsonProperty("campaignType")
	public String getCampaigntype();

	/**
	 * <p>
	 * Fetches description for campaign facet id
	 * </p>
	 *
	 * @return String - Campaign Facet Id
	 */
	@JsonProperty("campaignFacetId")
	public String getCampaignFacetId();

	/**
	 * <p>
	 * Fetches description for hiding banner
	 * </p>
	 *
	 * @return String - Hiding banner
	 */
	@JsonProperty("hideBannerWCampaign")
	public String getHideBannerWCampaign();

	/**
	 * <p>
	 * Fetches campaign names list
	 * </p>
	 *
	 * @return String - campaign names list
	 */
	@JsonProperty("campaignNamesList")
	public Resource getCampaignNamesList();

	/**
	 * <p>
	 * Fetches migration url
	 * </p>
	 *
	 * @return String - Migration url
	 */
	@JsonProperty("tmoSimPdpUrl")
	public String getTmoSimPdpUrl();

	/**
	 * <p>
	 * Fetches migration url
	 * </p>
	 *
	 * @return String - Migration url
	 */
	@JsonProperty("vzwSimPdpUrl")
	public String getVzwSimPdpUrl();

	/**
	 * <p>
	 * Fetches deals query string
	 * </p>
	 *
	 * @return String - deals query string
	 */
	@JsonProperty("dealsQueryString")
	public String getDealsQueryString();

	/**
	 * <p>
	 * Fetches show row of two or three
	 * </p>
	 *
	 * @return Boolean - enableMultipleLayout
	 */
	@JsonProperty("enableMultipleLayout")
	public Boolean getEnableMultipleLayout();

	/**
	 * <p>
	 * Fetches hide upgrade recommendations
	 * </p>
	 *
	 * @return Boolean - hideUpgradeRecommendations
	 */
	@JsonProperty("hideUpgradeRecommendations")
	public Boolean getHideUpgradeRecommendations();

	/**
	 * <p>
	 * Fetches show upgrade collapsed
	 * </p>
	 *
	 * @return Boolean - showUpgradeCollapsed
	 */
	@JsonProperty("showUpgradeCollapsed")
	public Boolean getShowUpgradeCollapsed();

	/**
	 * <p>
	 * Fetches show title above upgrade
	 * </p>
	 *
	 * @return Boolean - showTitleAboveUpgrade
	 */
	@JsonProperty("showTitleAboveUpgrade")
	public Boolean getShowTitleAboveUpgrade();

	/**
	 * <p>
	 * Fetches hide user info
	 * </p>
	 *
	 * @return String - hideUserInfo
	 */
	@JsonProperty("hideUserInfo")
	public String getHideUserInfo();

	/**
	 * <p>
	 * Fetches Check Availability Label
	 * </p>
	 *
	 * @return String - Check Availability Label
	 */
	@JsonProperty("checkAvailabilityLabel")
	public String getCheckAvailabilityLabel();

	/**
	 * <p>
	 * Fetches show Check Availability
	 * </p>
	 *
	 * @return String - show Check Availability
	 */
	@JsonProperty("showCheckAvailability")
	public String getShowCheckAvailability();

	/**
	 * <p>
	 * Fetches discount Text
	 * </p>
	 *
	 * @return String - discount Text
	 */
	@JsonProperty("discountText")
	public String getDiscountText();

	/**
	 * <p>
	 * Fetches showMldPlanPromo checkbox
	 * </p>
	 *
	 * @return String - showMldPlanPromo
	 */
	@JsonProperty("showMldPlanPromo")
	public String getShowMldPlanPromo();

	/**
	 * <p>
	 * Fetches showMultiLineSelector label
	 * </p>
	 *
	 * @return String - showMultiLineSelector label
	 */
	@JsonProperty("showMultiLineSelector")
	public Boolean getShowMultiLineSelector();

	/**
	 * <p>
	 * Fetches showPaymentFrequency label
	 * </p>
	 *
	 * @return String - showPaymentFrequency label
	 */
	@JsonProperty("showPaymentFrequency")
	public Boolean getShowPaymentFrequency();

	/**
	 * <p>
	 * Fetches showPaymentFrequency label
	 * </p>
	 *
	 * @return String - showPaymentFrequency label
	 */
	@JsonProperty("paymentFrequencyLabel")
	public String getPaymentFrequencyLabel();

	/**
	 * <p>
	 * Fetches paymentFreqencyData label
	 * </p>
	 *
	 * @return Map - paymentFreqencyData label
	 */
	@JsonProperty("paymentFreqencyData")
	public Map<Integer, String> getPaymentFrequencyData();

	/**
	 * <p>
	 * Method to return Number of Lines List
	 * </p>
	 *
	 * @return String
	 */
	@JsonProperty("numberOfLinesList")
	public List<Object> getNumberOfLinesList();

	/**
	 * <p>
	 * Fetches multilinePlanText label
	 * </p>
	 *
	 * @return String - multilinePlanText label
	 */
	@JsonProperty("multilinePlanText")
	public String getMultilinePlanText();

	String getDisclaimerVisibleText();

	String getDisclaimerAccordionText();


	String getDisclaimerCollapseLabel();

	String getDisclaimerExpandLabel();

	String getDisclaimerCTALabel();

	String getDisclaimerAccessibilityText();

	String getDisclaimerCTALink();

	String getPlansIconPath();

	String getPlansPdpIconPath();

	/**
	 * <p>
	 * Fetches multiLineHeader value
	 * </p>
	 *
	 * @return String - multiLineHeader value
	 */
	@JsonProperty("multiLineHeader")
	public String getMultiLineHeader();

	/**
	 * <p>
	 * Fetches multilineDiscountHeader value
	 * </p>
	 *
	 * @return String - multilineDiscountHeader value
	 */
	@JsonProperty("multilineDiscountHeader")
	public String getMultilineDiscountHeader();

	/**
	 * <p>
	 * Fetches multiLineSubHeader value
	 * </p>
	 *
	 * @return String - multiLineSubHeader value
	 */
	@JsonProperty("multiLineSubHeader")
	public String getMultiLineSubHeader();

	/**
	 * <p>
	 * Fetches enableDynamicPricing value
	 * </p>
	 *
	 * @return String - enableDynamicPricing value
	 */
	@JsonProperty("enableDynamicPricing")
	public String getEnableDynamicPricing();

	/*
	 * Fetches financingOptionsPath
	 * </p>
	 *
	 * @return String - redirect link for refill flow plp
	 */
	@JsonProperty("financingOptionsPath")
	String getFinancingOptionsPath();

	/**
	 * <p>
	 * Fetches showPreApprovalSection option
	 * </p>
	 *
	 * @return String - Show Pre Approval Section
	 */
	@JsonProperty("showPreApprovalSection")
	public String getShowPreApprovalSection();

	/**
	 * <p>
	 * Fetches selectedPlanPartN
	 * </p>
	 *
	 * @return String - selectedPlanPartNo
	 */
	@JsonProperty("selectedPlanPartNo")
	public String getSelectedPlanPartNo();

	/**
	 * <p>
	 * Fetches description for acp facet id
	 * </p>
	 *
	 * @return String - ACP Facet Id
	 */
	@JsonProperty("acpFacetId")
	public String getAcpFacetId();

	/**
	 * <p>
	 * Fetches duplicateMldCards checkbox
	 * </p>
	 *
	 * @return String - duplicateMldCards
	 */
	@JsonProperty("duplicateMldCards")
	public String getDuplicateMldCards();

	/**
	 * <p>
	 * Fetches useSmallPlanCard checkbox
	 * </p>
	 *
	 * @return String - useSmallPlanCard
	 */
	@JsonProperty("useSmallPlanCard")
	public String getUseSmallPlanCard();

	/**
	 * <p>
	 * Fetches viewBrochurePath value
	 * </p>
	 *
	 * @return String - viewBrochurePath
	 */
	@JsonProperty("viewBrochurePath")
	public String getViewBrochurePath();

	/**
	 * <p>
	 * Fetches asurionPlansDisclaimer value
	 * </p>
	 *
	 * @return String - asurionPlansDisclaimer
	 */
	@JsonProperty("asurionPlansDisclaimer")
	public String getAsurionPlansDisclaimer();

	/**
	 * <p>
	 * Fetches hideBundlePlanCard value
	 * </p>
	 *
	 * @return String - hideBundlePlanCard
	 */
	@JsonProperty("hideBundlePlanCard")
	public String getHideBundlePlanCard();

	/**
	 * Fetches fccDisclaimerText value
	 * </p>
	 *
	 * @return String - fccDisclaimerText
	 */
	@JsonProperty("fccDisclaimerText")
	public String getFccDisclaimerText();

	/**
	 * <p>
	 * Fetches description for remote alert plan facet id
	 * </p>
	 *
	 * @return String - Remote Alert Plan Facet Id
	 */
	@JsonProperty("remoteAlertPlanFacetId")
	public String getRemoteAlertPlanFacetId();

	/**
	 * <p>
	 * Fetches check for Multi month plan
	 * </p>
	 *
	 * @return String(True or false) for Enable Multi Month Plan option
	 */
	@JsonProperty("enableMultiMonthPlan")
	public String getEnableMultiMonthPlan();

	/**
	 * <p>
	 * Fetches promo text for Multi month plan card
	 * </p>
	 *
	 * @return String - multiMonthCardPromoText
	 */
	@JsonProperty("multiMonthCardPromoText")
	public String getMultiMonthCardPromoText();

	/**
	 * <p>
	 * Fetches text for Multi Month Price Savings Lbl
	 * </p>
	 *
	 * @return String - multiMonthPriceSavingsLbl
	 */
	@JsonProperty("multiMonthPriceSavingsLbl")
	public String getMultiMonthPriceSavingsLbl();

	/**
	 * <p>
	 * Fetches text for Multi Month Price SubScript
	 * </p>
	 *
	 * @return String - multiMonthPriceSubScript
	 */
	@JsonProperty("multiMonthPriceSubScript")
	public String getMultiMonthPriceSubScript();

	/**
	 * <p>
	 * Fetches promo text for Multi Month Price
	 * </p>
	 *
	 * @return String - multiMonthPricePromoText
	 */
	@JsonProperty("multiMonthPricePromoText")
	public String getMultiMonthPricePromoText();

	/**
	 * <p>
	 * Fetches check for Multi month promo card
	 * </p>
	 *
	 * @return String(True or false) for showMultiMonthPromoCard
	 */
	@JsonProperty("showMultiMonthPromoCard")
	public String getShowMultiMonthPromoCard();

	/**
	 * <p>
	 * Fetches part number for multi month promo card
	 * </p>
	 *
	 * @return String - multiMonthPromoCardPartNo
	 */
	@JsonProperty("multiMonthPromoCardPartNo")
	public String getMultiMonthPromoCardPartNo();

	/**
	 * <p>
	 * Fetches promo text for Multi Month Promo card
	 * </p>
	 *
	 * @return String - multiMonthPromoCardPromoText
	 */
	@JsonProperty("multiMonthPromoCardPromoText")
	public String getMultiMonthPromoCardPromoText();

	/**
	 * <p>
	 * Fetches save text for Multi Month Promo card
	 * </p>
	 *
	 * @return String - multiMonthSaveHeader
	 */
	@JsonProperty("multiMonthSaveHeader")
	public String getMultiMonthSaveHeader();

	/**
	 * <p>
	 * Fetches discount text for Multi Month Promo card
	 * </p>
	 *
	 * @return String - multiMonthDiscountText
	 */
	@JsonProperty("multiMonthDiscountText")
	public String getMultiMonthDiscountText();

	/**
	 * <p>
	 * Fetches text for Multi Month Select Button Label
	 * </p>
	 *
	 * @return String - multiMonthSelectBtnLbl
	 */
	@JsonProperty("multiMonthSelectBtnLbl")
	public String getMultiMonthSelectBtnLbl();

	/**
	 * <p>
	 * Fetches turnOnAnotherPromoCard value
	 * </p>
	 *
	 * @return String - turnOnAnotherPromoCard
	 */
	@JsonProperty("turnOnAnotherPromoCard")
	public String getTurnOnAnotherPromoCard();


	/**
	 * Fetches 	Home InternetDiscount Price
	 */
	@JsonProperty("homeInternetDiscountPrice")
	public String getHomeInternetDiscountPrice();

	/**
	 *<p>Fetches retailPriceLabel</p>
	 * @return String - the retailPriceLabel
	 */
	@JsonProperty("retailPriceLabel")
	public String getRetailPriceLabel();

	/**
	 * <p>
	 * Fetches description for twentyFivePlanPartClass
	 * </p>
	 *
	 * @return String - twentyFivePlanPartClass
	 */
	@JsonProperty("twentyFivePlanPartClass")
	public String getTwentyFivePlanPartClass();


	/**
	 * <p>
	 * Fetches description for twentyFivePlanPartNumber
	 * </p>
	 *
	 * @return String - twentyFivePlanPartNumber
	 */
	@JsonProperty("twentyFivePlanPartNumber")
	public String getTwentyFivePlanPartNumber();


	/**
	 * <p>
	 * Fetches description for twentyFivePlanTitle
	 * </p>
	 *
	 * @return String - twentyFivePlanTitle
	 */
	@JsonProperty("twentyFivePlanTitle")
	public String getTwentyFivePlanTitle();


	/**
	 * <p>
	 * Fetches description for twentyFivePlanDescription
	 * </p>
	 *
	 * @return String - twentyFivePlanDescription
	 */
	@JsonProperty("twentyFivePlanDescription")
	public String getTwentyFivePlanDescription();


	/**
	 * <p>
	 * Fetches description for twentyFivePlanButtonTitle
	 * </p>
	 *
	 * @return String - twentyFivePlanButtonTitle
	 */
	@JsonProperty("twentyFivePlanButtonTitle")
	public String getTwentyFivePlanButtonTitle();


	/**
	 * <p>
	 * Fetches description for twentyFivePlanCardTypeTitle
	 * </p>
	 *
	 * @return String - twentyFivePlanCardTypeTitle
	 */
	@JsonProperty("twentyFivePlanCardTypeTitle")
	public String getTwentyFivePlanCardTypeTitle();

	/**
	 * <p>
	 * Fetches description for twentyFivePlanCardTypeSubTitle
	 * </p>
	 *
	 * @return String - twentyFivePlanCardTypeSubTitle
	 */
	@JsonProperty("twentyFivePlanCardTypeSubTitle")
	public String getTwentyFivePlanCardTypeSubTitle();

	/**
	 * <p>
	 * Fetches description for twentyFivePlanCardTitle
	 * </p>
	 *
	 * @return String - twentyFivePlanCardTitle
	 */
	@JsonProperty("twentyFivePlanCardTitle")
	public String getTwentyFivePlanCardTitle();

	/**
	 * <p>
	 * Fetches description for twentyFivePlanCardDescription
	 * </p>
	 *
	 * @return String - twentyFivePlanCardDescription
	 */
	@JsonProperty("twentyFivePlanCardDescription")
	public String getTwentyFivePlanCardDescription();


	/**
	 * <p>
	 * Fetches description for twentyFivePlanCardLearnMore
	 * </p>
	 *
	 * @return String - twentyFivePlanCardLearnMore
	 */
	@JsonProperty("twentyFivePlanCardLearnMore")
	public String getTwentyFivePlanCardLearnMore();

	/**
	 * <p>
	 * Fetches description for byopMainText
	 * </p>
	 *
	 * @return String - byopMainText
	 */
	@JsonProperty("byopMainText")
	public String getByopMainText();

	String getDcotPromoEligiblePlans();

	String getDcotPromoEligiblePlansSubText();

	String getDcotPromoOtherPlans();


	String getDcotPromoOtherPlansSubText();

	String getDcotNonEligiblePlanModel();

	/**
	 * <p>
	 * Fetches description for byopCtaText
	 * </p>
	 *
	 * @return String - byopCtaText
	 */
	@JsonProperty("byopCtaText")
	public String getByopCtaText();

	@JsonProperty("fiveGCapablefacet")
	public String getFiveGCapablefacet();

	@JsonProperty("isSortEnable")
	public String getIsSortEnable();

	/**
	 * <p>
	 * Fetches description for plansPlpLink
	 * </p>
	 *
	 * @return String - plansPlpLink
	 */
	@JsonProperty("plansPlpLink")
	public String getPlansPlpLink();
	/**
	 * <p>
	 * Fetches description for readmoreCTALabel
	 * </p>
	 *
	 * @return String - readmoreCTALabel
	 */
	@JsonProperty("readmoreCTALabel")
	public String getReadmoreCTALabel();

	/**
	 * <p>
	 * Fetches description for readmoreAccessibilityText
	 * </p>
	 *
	 * @return String - readmoreAccessibilityText
	 */
	@JsonProperty("readmoreAccessibilityText")
	public String getReadmoreAccessibilityText();

	/**
	 * <p>
	 * Fetches description for readmoreCTALink
	 * </p>
	 *
	 * @return String - readmoreCTALink
	 */
	@JsonProperty("readmoreCTALink")
	public String getReadmoreCTALink();


	/**
	 * <p>
	 * Fetches description for priceUpdate
	 * </p>
	 *
	 * @return String - priceUpdate
	 */
	@JsonProperty("priceUpdate")
	public String getPriceUpdate();

}
