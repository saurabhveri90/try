/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.tracfonecore.core.models.FooterModel;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import com.tracfonecore.core.utils.ItemsExporterUtil;


@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { FooterModel.class,ComponentExporter.class }, 
resourceType = "tracfone-core/components/structure/footer", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, 
extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = { 
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class FooterModelImpl extends BaseComponentModelImpl implements FooterModel {

	@Self
	private SlingHttpServletRequest request;

	@SlingObject
	ResourceResolver resourceResolver;

	@Inject
	private SlingModelFilter slingModelFilter;
	@Inject
	private ModelFactory modelFactory;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String fileReference;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String altText;

	private static final Logger LOGGER = LoggerFactory.getLogger(FooterModelImpl.class);	

	@Override
	public String getFileReference() {
		return DynamicMediaUtils.changeMediaPathToDMPathWithQueryParam(fileReference, resourceResolver);
	}

	@Override
	public String getAltText() {
		return altText;
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	public Map<String, ? extends ComponentExporter> getItems(){
		LOGGER.debug("inside get items");
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}
	
    @PostConstruct
	protected void initModel() {
       	super.initModel();  
    }

}