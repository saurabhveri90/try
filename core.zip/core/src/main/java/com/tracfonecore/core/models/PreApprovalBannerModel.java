package com.tracfonecore.core.models;

public interface PreApprovalBannerModel {
    String getBannerBackground();

    String getBannerFont();

    String getBannerHeader();
    String getBannerDescription();

    String getBannerCtaLabel();

    String getFinancingHeader();
    String getFinancingDescription();
    String getFinancingOptionsCtaLabel();
    String getFinancingOptionsPath();
}
