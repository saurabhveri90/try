/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;

/**
 * <p>
 * Defines bean to hold link detail
 * </p>
 */
public class HeroCarouselSlideBean {

	private String backgroundColorForSlide;
	private String backgroundImageAlign;
	private String ctaAlign;
	private String slideBackgroundtype;
	private String slideCtaLabel;
	private String slideCtaAlignment;
	private String slideCtaLink;
	private String slideHeading;
	private String slideSubHeading;
	private String backgroundImageAlt;
	private String backgroundImageForSlide;
	private String imageForSlide;
	private String cssForSlideerBackground;
	private String tooltipLogo;
	private String tooltipMsg;

	private String sliderBgType;
	private String sliderBackgroundColor;
	private String sliderBackgroundImage;
	public String getSliderBgType() {
		return sliderBgType;
	}

	public void setSliderBgType(String sliderBgType) {
		this.sliderBgType = sliderBgType;
	}

	public String getSliderBackgroundColor() {
		return sliderBackgroundColor;
	}

	public void setSliderBackgroundColor(String sliderBackgroundColor) {
		this.sliderBackgroundColor = sliderBackgroundColor;
	}

	public String getSliderBackgroundImage() {
		return sliderBackgroundImage;
	}

	public void setSliderBackgroundImage(String sliderBackgroundImage) {
		this.sliderBackgroundImage = sliderBackgroundImage;
	}




	public String getTooltipLogo() {
		return tooltipLogo;
	}

	public void setTooltipLogo(String tooltipLogo) {
		this.tooltipLogo = tooltipLogo;
	}

	public String getTooltipMsg() {
		return tooltipMsg;
	}

	public void setTooltipMsg(String tooltipMsg) {
		this.tooltipMsg = tooltipMsg;
	}

	

	public String getSlideCtaAlignment() {
		return slideCtaAlignment;
	}

	public void setSlideCtaAlignment(String slideCtaAlignment) {
		this.slideCtaAlignment = slideCtaAlignment;
	}

	public String getCssForSlideerBackground() {
		return cssForSlideerBackground;
	}

	public void setCssForSlideerBackground(String cssForSlideerBackground) {
		this.cssForSlideerBackground = cssForSlideerBackground;
	}

	public String getImageForSlide() {
		return imageForSlide;
	}

	public void setImageForSlide(String imageForSlide) {
		this.imageForSlide = imageForSlide;
	}

	public String getBackgroundImageForSlide() {
		return backgroundImageForSlide;
	}

	public void setBackgroundImageForSlide(String backgroundImageForSlide) {
		this.backgroundImageForSlide = backgroundImageForSlide;
	}

	public String getBackgroundColorForSlide() {
		return backgroundColorForSlide;
	}

	public void setBackgroundColorForSlide(String backgroundColorForSlide) {
		this.backgroundColorForSlide = backgroundColorForSlide;
	}

	public String getBackgroundImageAlign() {
		return backgroundImageAlign;
	}

	public void setBackgroundImageAlign(String backgroundImageAlign) {
		this.backgroundImageAlign = backgroundImageAlign;
	}

	public String getCtaAlign() {
		return ctaAlign;
	}

	public void setCtaAlign(String ctaAlign) {
		this.ctaAlign = ctaAlign;
	}

	public String getSlideBackgroundtype() {
		return slideBackgroundtype;
	}

	public void setSlideBackgroundtype(String slideBackgroundtype) {
		this.slideBackgroundtype = slideBackgroundtype;
	}

	public String getSlideCtaLabel() {
		return slideCtaLabel;
	}

	public void setSlideCtaLabel(String slideCtaLabel) {
		this.slideCtaLabel = slideCtaLabel;
	}

	public String getSlideCtaLink() {
		return slideCtaLink;
	}

	public void setSlideCtaLink(String slideCtaLink) {
		this.slideCtaLink = slideCtaLink;
	}

	public String getSlideHeading() {
		return slideHeading;
	}

	public void setSlideHeading(String slideHeading) {
		this.slideHeading = slideHeading;
	}

	public String getSlideSubHeading() {
		return slideSubHeading;
	}

	public void setSlideSubHeading(String slideSubHeading) {
		this.slideSubHeading = slideSubHeading;
	}

	public String getBackgroundImageAlt() {
		return backgroundImageAlt;
	}

	public void setBackgroundImageAlt(String backgroundImageAlt) {
		this.backgroundImageAlt = backgroundImageAlt;
	}

}
