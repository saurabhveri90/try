package com.tracfonecore.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Tracfone Core - Broadband Facts Config Service", description = "Configurations for brand key are added here")

public @interface BroadbandFactsConfig {
	
	@AttributeDefinition(name = "TracFone Wireless FCC Registration Number",description = "TracFone Wireless FCC Registration Number")
	String brandKeys() default "0006855639";
   
	@AttributeDefinition(name = "Content models base path",description = "")
	String[] factsContentBasePath() default {"STRAIGHT_TALK:/content/dam/straighttalk/{language}/cf/fcc","TRACFONE:/content/dam/tracfone/{language}/cf/fcc","TOTAL_WIRELESS:/content/dam/tbvz/{language}/cf/fcc","SIMPLE_MOBILE:/content/dam/simple-mobile/{language}/cf/fcc","WFM:/content/dam/wfm/{language}/cf/fcc","NET10:/content/dam/net10/{language}/cf/fcc","GO_SMART:/content/dam/go-smart/{language}/cf/fcc","SAFELINK:/content/dam/safelink/{language}/cf/fcc", "PAGE_PLUS:/content/dam/page-plus/{language}/cf/fcc"};

	@AttributeDefinition(name = "Content models base path",description = "")
	String[] retailerFactsContentBasePath() default {"STRAIGHT_TALK:/content/dam/straighttalk/{language}/cf/fcc/nationalretailer","TRACFONE:/content/dam/tracfone/{language}/cf/fcc/nationalretailer","TOTAL_WIRELESS:/content/dam/tbvz/{language}/cf/fcc/nationalretailer","SIMPLE_MOBILE:/content/dam/simple-mobile/{language}/cf/fcc/nationalretailer","WFM:/content/dam/wfm/{language}/cf/fcc/nationalretailer","NET10:/content/dam/net10/{language}/cf/fcc/nationalretailer","GO_SMART:/content/dam/go-smart/{language}/cf/fcc/nationalretailer","SAFELINK:/content/dam/safelink/{language}/cf/fcc/nationalretailer", "PAGE_PLUS:/content/dam/page-plus/{language}/cf/fcc/nationalretailer"};

	@AttributeDefinition(name = "Brand name",description = "")
	String[] brandName() default {"STRAIGHT_TALK:Straight Talk Wireless","TRACFONE:TracFone Wireless","TOTAL_WIRELESS:Total Wireless","SIMPLE_MOBILE:Simple Mobile","WFM:Walmart Family Mobile","NET10:Net10 Wireless","GO_SMART:GoSmart","SAFELINK:SafeLink","PAGE_PLUS:Page Plus"};

	@AttributeDefinition(name = "Workflow model base path",description = "")
	String workflowModelPath() default "/var/workflow/models/fcc-label-update";

	@AttributeDefinition(name = "Brand short name",description = "Brands short name for unique ID")
	String[] brandShortName() default {"STRAIGHT_TALK:ST","TRACFONE:TF","TOTAL_WIRELESS:TW","SIMPLE_MOBILE:SM","WFM:WF","NET10:NT","GO_SMART:GS","SAFELINK:SL","PAGE_PLUS:PP"};

	@AttributeDefinition(name = "FCC Content API",description = "URI of FCC Labels Content api")
	String fccContentApiPath() default "/catalog-mgmt/fcc-label-tmp";
	
	@AttributeDefinition(name = "FCC Archival API",description = "URI of FCC Labels Archival api")
	String fccArchivalApiPath() default "/catalog-mgmt/fcc-label-archive";
	
	@AttributeDefinition(name = "FCC Label Status API",description = "URI of FCC Labels Status api")
	String fccLabelStatusApiPath() default "/catalog-mgmt/fcc-label/status";
	
	@AttributeDefinition(name = "Contact Number",description = "Contact Number for each Brand")
	String[] contactNumberBrand() default {"STRAIGHT_TALK:888-663-3633","TRACFONE:888-663-3633","TOTAL_WIRELESS:888-663-3633","SIMPLE_MOBILE:888-663-3633","WFM:888-663-3633","NET10:888-663-3633","GO_SMART:888-663-3633","SAFELINK:888-663-3633","PAGE_PLUS:888-663-3633"};

	@AttributeDefinition(name = "Retries Connect API",description = "Number of retries to try to connect to the API")
	int fccRetriesConnectApi() default 3;	
	
	@AttributeDefinition(name = "Interval Connect API",description = "Time in milliseconds to wait between intervals to connect to the API")
	long fccIntervalConnectApi() default 5000;
	
	@AttributeDefinition(name = "Template Level POC base path",description = "Path where fccsettings is allocated")
	String templateLevelPath() default "/content/straighttalk/language-masters/en/fcc-global-settings/jcr:content/root/fccsettings";

	@AttributeDefinition(name = "API Url for zipcode fees calculation",description = "API Url for zipcode fees calculation")
	String getFccZipcodeFeesApiUrl() default "/order-mgmt/order/zipcode/fee";
	
	@AttributeDefinition(name = "States that require extra fee calculation",description = "States that require extra fee calculation")
	String[] getTaxRequiredStates() default {"AZ","HI","MA","NM"};

	@AttributeDefinition(name = "Max Limited PDF displayed",description = "Number of FCC labels show on PDF Archival Report")
	int fccMaxLimitPdfDisplayed() default 30;	

	@AttributeDefinition(name = "Connection Timeout to retrieve FCC Archival API",description = "Connection Timeout to retrieve FCC Archival API for PDF Archival Report")
	int fccArchivalTimeoutConection() default 30000;	

	@AttributeDefinition(name = "Max Limit FCC Archival fetched",description = "Number of Max FCC labels fetched from ArchivalAPI")
	int fccMaxLimitPdfFetched() default 1000;	
}
