/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.VerifyIdentityModel;


import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { VerifyIdentityModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/verifyIdentity", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class VerifyIdentityModelImpl implements VerifyIdentityModel {

	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String verificationCodeHeading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String verificationCodeSummary;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serialNoHeading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serialNoSummary;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String verificationCodeButtonText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serialNoButtonText;

	
	
	/**
	 * <p>Fetches verification code heading</p>
	 *
	 * @return String - verificationCode
	 */
	@Override
	public String getVerificationCodeHeading() {
		return verificationCodeHeading;
	}

	/**
	 * <p>Fetches verification code summary</p>
	 *
	 * @return String - verificationCodeSummary
	 */
	@Override
	public String getVerificationCodeSummary(){
		return verificationCodeSummary;
	}	

	/**
	 * <p>Fetches serial No. heading</p>
	 *
	 * @return String - serialNoHeading
	 */
	@Override
	public String getSerialNoHeading(){
		return serialNoHeading;
	}

	/**
	 * <p>Fetches Serial No Summary</p>
	 *
	 * @return String - serialNoSummary
	 */
	@Override
	public String getSerialNoSummary(){
		return serialNoSummary;
	}

	/**
	 * <p> Fetches Resource type </p>
	 * 
	 * @return String - exportedType
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
	/**
	 * <p> Fetches verification code screen button text </p>
	 *
	 * @return String - verification Code button text
	 */
	@Override
	public String getVerificationCodeButtonText() {
		return verificationCodeButtonText;
	}
	
	/**
	 * <p> Fetches serial no screen button text </p>
	 *
	 * @return String - serial no button text
	 */
	@Override
	public String getSerialNoButtonText() {
		return serialNoButtonText;
	}

}