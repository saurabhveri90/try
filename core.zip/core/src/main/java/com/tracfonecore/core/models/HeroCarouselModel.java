package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.HeroCarouselSlideBean;

/**
 * Defines the {@code Carousel} Sling Model used for the {@code /apps/tracfone-core/components/content/carouselbannerItem} component.
 */
public interface HeroCarouselModel extends ComponentExporter  {

	/**
	 * <p>Fetches label of the carousel</p>
	 *
	 * @return String - label of the carousel
	 */
	@JsonProperty("slides")
	public List<HeroCarouselSlideBean> getSlides();	
	
	@JsonProperty("transitionDelay")
	public String getTransitionDelay();
	
	
	
	
}
