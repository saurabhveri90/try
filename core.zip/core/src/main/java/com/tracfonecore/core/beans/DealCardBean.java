package com.tracfonecore.core.beans;

/**
 * <p>Defines bean to hold deal card detail</p>
 */
public class DealCardBean {
	
	private String cardType;
	private String cardHeadline;
	private String cardSubheadline;
	private String cardImage;
	private String cardImageAltText;
	private String cardPlpPagePath;
	private String openNewTabCardPlpPagePath;
	private String cardBgColor;
	private String cardTextColor;
	private String cardButtonClassName;
	private String cardTextHeadingColor;
	private String cardTextSubHeadingColor;
	private String cardImageAssetId;
	private String cardImageAssetAgencyId;
	
	
	public String getCardButtonClassName() {
		return cardButtonClassName;
	}
	public void setCardButtonClassName(String cardButtonClassName) {
		this.cardButtonClassName = cardButtonClassName;
	}
	public String getCardTextHeadingColor() {
		return cardTextHeadingColor;
	}
	public void setCardTextHeadingColor(String cardTextHeadingColor) {this.cardTextHeadingColor = cardTextHeadingColor;}
	public String getCardTextSubHeadingColor() {
		return cardTextSubHeadingColor;
	}
	public void setCardTextSubHeadingColor(String cardTextSubHeadingColor) {this.cardTextSubHeadingColor = cardTextSubHeadingColor;}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getCardHeadline() {
		return cardHeadline;
	}
	public void setCardHeadline(String cardHeadline) {
		this.cardHeadline = cardHeadline;
	}
	public String getCardSubheadline() {
		return cardSubheadline;
	}
	public void setCardSubheadline(String cardSubheadline) {
		this.cardSubheadline = cardSubheadline;
	}
	public String getCardImage() {
		return cardImage;
	}
	public void setCardImage(String cardImage) {
		this.cardImage = cardImage;
	}
	public String getCardImageAltText() {
		return cardImageAltText;
	}
	public void setCardImageAltText(String cardImageAltText) {
		this.cardImageAltText = cardImageAltText;
	}
	public String getCardPlpPagePath() {
		return cardPlpPagePath;
	}
	public void setCardPlpPagePath(String cardPlpPagePath) {
		this.cardPlpPagePath = cardPlpPagePath;
	}
	public String getOpenNewTabCardPlpPagePath() {
		return openNewTabCardPlpPagePath;
	}
	public void setOpenNewTabCardPlpPagePath(String openNewTabCardPlpPagePath) {
		this.openNewTabCardPlpPagePath = openNewTabCardPlpPagePath;
	}
	public String getCardTextColor() {
		return cardTextColor;
	}
	public void setCardTextColor(String cardTextColor) {
		this.cardTextColor = cardTextColor;
	}
	public String getCardBgColor() {
		return cardBgColor;
	}
	public void setCardBgColor(String cardBgColor) {
		this.cardBgColor = cardBgColor;
	}

	public String getCardImageAssetId() {
		return cardImageAssetId;
	}
	public void setCardImageAssetId(String cardImageAssetId) {
		this.cardImageAssetId = cardImageAssetId;
	}

	public String getCardImageAssetAgencyId() {
		return cardImageAssetAgencyId;
	}
	public void setCardImageAssetAgencyId(String cardImageAssetAgencyId) {
		this.cardImageAssetAgencyId = cardImageAssetAgencyId;
	}
}
