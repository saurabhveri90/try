
package com.tracfonecore.core.models.impl;

import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.tracfonecore.core.utils.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.apache.sling.settings.SlingSettingsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.DeviceAccessoryDetailModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.ProductOfferingApiService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { DeviceAccessoryDetailModel.class,
		ComponentExporter.class }, resourceType = DeviceAccessoryDetailModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class DeviceAccessoryDetailModelImpl extends BaseComponentModelImpl implements DeviceAccessoryDetailModel {
	private static final Logger LOGGER = LoggerFactory.getLogger(DeviceAccessoryDetailModelImpl.class);
	protected static final String RESOURCE_TYPE = "tracfone-core/components/commerce/deviceaccessorydetail";


	@Self
	private SlingHttpServletRequest request;

	@Inject
	private SlingModelFilter slingModelFilter;

	@Inject
	private ModelFactory modelFactory;

	@Inject
	private Resource resource;

	@Inject
	private TracfoneApiGatewayService tracfoneApiService;

	@Inject
	private ProductOfferingApiService productOfferingApiService;

	@ScriptVariable
	private ValueMap properties;

	/**
	 *  Inject the Links multifield
	 */
	@Inject @Via("resource")
	private Resource multilinks;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String featurelabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String desclabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String description;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String pricecaptionplp;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String showTimer;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String homeInternetDiscountPrice;

	@Inject @Via("resource")
	private String compareimage;

	@Inject
	@Via("resource")
	private Resource tablinks;

	private int productID;

	private String categoryType;

	private JsonObject product;

	@Inject
	private Page currentPage;

	private String selection;
	

	@Inject
	private SlingSettingsService slingSettingsService;

	/**
	 * <p>
	 * Returns selection authored
	 * </p>
	 * 
	 * @return String - selection
	 */
	@Override
	public String getSelection() {
		return selection;
	}


    @Inject
    private ApplicationConfigService applicationConfigService;

	//Constants
	private static final String CATEGORY_TYPE = "categorytype";

	private JsonArray skusArray;

	private String color;

	private String skuId;

	private String thumbnailImageAssetId;

	private String thumbnailImageAssetAgencyId;
	
	private String seoDynamicTitle;

	private String retailPriceLabel;
	
	private String showPriceDetailsAboveImg;
	
	private int tabLinksSize;
	
	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering init method of DeviceAccessoryDetailModelImpl");
		super.initModel();	
		LOGGER.debug("Entering init method of DeviceAccessoryDetailModelImpl");
		readPageProperties();
		try {
			checkTablinks();
				selection = currentPage.getContentResource().getValueMap().get("partNo", String.class);
				if (!selection.equals(StringUtils.EMPTY)) {
					product = productOfferingApiService.getProductDetailObject(selection, currentPage);
					LOGGER.debug("Product Bean "+product.toString());

					if(null!=product) {
						if(product.get(CommerceConstants.ID)!=null) 
							productID = product.get(CommerceConstants.ID).getAsInt();
						getSKUDetails();
					}
					if(!ApplicationUtil.isPublish(slingSettingsService)) {
						setDynamicSEOTitle(currentPage);
					}
					this.setThumbnailImageAssetId(ApplicationUtil.getAssetId(compareimage, request.getResourceResolver(), ApplicationConstants.IMAGE));
					this.setThumbnailImageAssetAgencyId(ApplicationUtil.getAssetMetaDataValue(compareimage, request.getResourceResolver(),ApplicationConstants.WEBER_ID));
				}
			LOGGER.debug("Exiting init method of DeviceAccessoryDetailModelImpl");
		} catch (RuntimeException re) {
			LOGGER.error("API Exception occurred while fetching phone card details {}", re);
		}
		LOGGER.debug("Exiting init method of DeviceAccessoryDetailModelImpl");
	}
	
	/**
	 * This method is used to get tablinks length
	 */
	private void checkTablinks() {
		LOGGER.info("Entering DeviceAccessoryDetailModelImpl.checkTablinks");
		int count= 0;
		if(tablinks!=null) {
			for(Resource resource: tablinks.getChildren()) {
				String ctatext = resource.getValueMap().get("ctatext","");
				if(StringUtils.isNotEmpty(ctatext)) {
					count ++;
				}
			}
		}
		this.tabLinksSize = count;
		LOGGER.info("Exiting DeviceAccessoryDetailModelImpl.checkTablinks");
	}
	
	
	/**
	 * Set seoTitle property for the currentPage (Author Server only)
	 * @return void
	 */
	private void setDynamicSEOTitle(Page currentPage) {

		String seoTitle = StringUtils.EMPTY;
		String breadcrumbTitle = StringUtils.EMPTY;
		String useDynamicTitle = ApplicationUtil.getPropertiesFromRootPage(currentPage.getPath(), resource.getResourceResolver(), "useDynamicSeoTitles");

		try {
			String seoBrandName = getPimBrand();
			if (StringUtils.isBlank(seoBrandName)) {
				seoBrandName = ApplicationUtil.getPropertiesFromRootPage(currentPage.getPath(),
						resource.getResourceResolver(), ApplicationConstants.SEO_BRAND_NAME);
			}
				
			if (StringUtils.isNotBlank(getPimMarketName()) && StringUtils.isNotBlank(seoBrandName)) {
				if (StringUtils.isNotBlank(getPimOEM()) && getPimOEM().equalsIgnoreCase("APPLE")) {
					seoTitle = getPimOEM() + ApplicationConstants.SPACE + getPimMarketName()
							+ (StringUtils.isNotBlank(getPimModel()) ? (ApplicationConstants.SPACE + getPimModel())
									: StringUtils.EMPTY)
							+ (StringUtils.isNotBlank(getPimAMXTech()) ? (ApplicationConstants.SPACE + getPimAMXTech())
									: StringUtils.EMPTY)
							+ (StringUtils.isNotBlank(getPimStockType())
									? (ApplicationConstants.SPACE + getPimStockType())
									: StringUtils.EMPTY)
							+ ApplicationConstants.PIPE_WITH_SPACES + seoBrandName;
				} else {
					seoTitle = getPimMarketName()
							+ (StringUtils.isNotBlank(getPimModel()) ? (ApplicationConstants.SPACE + getPimModel())
									: StringUtils.EMPTY)
							+ (StringUtils.isNotBlank(getPimAMXTech()) ? (ApplicationConstants.SPACE + getPimAMXTech())
									: StringUtils.EMPTY)
							+ (StringUtils.isNotBlank(getPimStockType())
									? (ApplicationConstants.SPACE + getPimStockType())
									: StringUtils.EMPTY)
							+ ApplicationConstants.PIPE_WITH_SPACES + seoBrandName;
				}
			} else if(StringUtils.isNotBlank(getPimDescription()) && StringUtils.isNotBlank(seoBrandName)) {
				seoTitle = getPimDescription()
						+ (StringUtils.isNotBlank(getPimColor()) ? (ApplicationConstants.SPACE + getPimColor()) : StringUtils.EMPTY)
						+ ApplicationConstants.PIPE_WITH_SPACES + seoBrandName;
			}

			this.setSeoDynamicTitle(seoTitle);
			if(this.getSeoDynamicTitle().lastIndexOf('|') > -1) {
				breadcrumbTitle = this.getSeoDynamicTitle().substring(0, this.getSeoDynamicTitle().lastIndexOf('|'));
			}
			if (StringUtils.isNotBlank(seoTitle)) {
				Resource currentResource = currentPage.getContentResource();
				ModifiableValueMap map = currentResource.adaptTo(ModifiableValueMap.class);
				if (map.get(ApplicationConstants.SEO_TITLE) == null
						|| map.get(ApplicationConstants.SEO_TITLE).toString().isEmpty()) {
					map.put(ApplicationConstants.SEO_TITLE, this.getSeoDynamicTitle());
				}
				if ((map.get(ApplicationConstants.BREADCRUMB_TITLE) == null
						|| map.get(ApplicationConstants.BREADCRUMB_TITLE).toString().isEmpty()) && (useDynamicTitle != null && Boolean.parseBoolean(useDynamicTitle))) {
					map.put(ApplicationConstants.BREADCRUMB_TITLE, breadcrumbTitle.trim());
				}
				currentResource.getResourceResolver().commit();
				LOGGER.debug("SEO title of the page {} is {}", currentPage.getPath(), this.getSeoDynamicTitle());
			} else {
				LOGGER.debug(
						"SEO title: Issue while retrieving Mandatory attributes from API. PIM_DESCRIPTION:{}, PIM_MARKET_NAME:{}, PIM_BRAND:{}",
						getPimDescription(), getPimMarketName(), seoBrandName);
			}

		} catch (PersistenceException e) {
			LOGGER.error("Exception {} while saving seoTitle property on page {}", e.getMessage(),
					currentPage.getPath());
		}
	}


	/**
	 * @return name
	 */
	@Override
	public String getName() {
		if (product != null && product.get(CommerceConstants.NAME) != null) {
			return product.get(CommerceConstants.NAME).getAsString();
		}
		return null;
	}

	/**
	 * @return id
	 */
	@Override
	public Integer getId() {
		if (product != null && product.get(CommerceConstants.ID) != null) {
			return product.get(CommerceConstants.ID).getAsInt();
		}
		return null;
	}
	/**
	 * 
	 * @return String - Make
	 */
	@Override
	public String getMake() {
		if (product != null && product.get(CommerceConstants.MAKE) != null) {
			return product.get(CommerceConstants.MAKE).getAsString();
		}
		return null;
	}

	/**
	 * @return the links
	 */
	public Resource getMultilinks() {
		return multilinks;
	}
	/**
	 * @param multilinks
	 */
	public void setMultilinks(Resource multilinks) {
		this.multilinks = multilinks;
	}
	/**
	 * @return getexportertype
	 */
	@Override
	public String getExportedType () {
		return request.getResource().getResourceType();
	}

	public Map<String, ? extends ComponentExporter> getItems () {
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}

	@Override
	public String getDescription () {
		return description;
	}

	@Override
	public String getFeaturelabel() {
		return featurelabel;
	}

	@Override
	public String getDesclabel() {
		return desclabel;
	}

	private void readPageProperties()
	{
			LOGGER.info("Entering DeviceAccessoryDetailModelImpl.readPageProperties");
			PageManager pm = resource.getResourceResolver().adaptTo(PageManager.class);
			LOGGER.info("Page path {}", resource.getPath());
			Page currentPage = pm.getContainingPage(resource);
			Page parentPage = currentPage.getParent();

			properties = parentPage.getProperties();

			if (properties != null) {
                categoryType = properties.get(CATEGORY_TYPE, String.class);
                if(StringUtils.isEmpty(categoryType)) {
                    Page ancestorPage = parentPage.getParent();
                    ValueMap ancProperties = ancestorPage.getProperties();
                    if (ancProperties != null) {
                        categoryType = ancProperties.get(CATEGORY_TYPE, String.class);                       
                        if (categoryType != null ) 
                        	setPagePropertiesValues(ancProperties);                                               
                    }
                }else{
                	setPagePropertiesValues(properties);
                  }                	
            }             
		LOGGER.info("Exiting DeviceAccessoryDetailModelImpl.readPageProperties");
	}
	
	/**
	 * This method is used to set page property values
	 * @param properties
	 */
	public void setPagePropertiesValues(ValueMap properties) {
		/* code added for show list price on page  */
    	if( null != properties.get(CommerceConstants.RETAIL_PRICE_LABEL))                    	
            setRetailPriceLabel(properties.get(CommerceConstants.RETAIL_PRICE_LABEL, String.class));
    	 /* code added for show price and other details above image in mobile view  */
    	if(null != properties.get(CommerceConstants.SHOW_PRICE_DETAILS_ABOVE_IMAGE))                     
			setShowPriceDetailsAboveImg(properties.get(CommerceConstants.SHOW_PRICE_DETAILS_ABOVE_IMAGE, String.class));
		
	}
	
	
	@Override
	public String getCategoryType() {
		return categoryType;
	}
	/**
	 * @param categoryType the categoryType to set
	 */
	public void setCategoryType(String categoryType) {
		this.categoryType = categoryType;
	}

	/**
	 * @return apiDomain
	 */
	@Override
	public String getApiDomain() {

		return tracfoneApiService.getApiDomain();
	}

	/**
	 * @return priceApiPath
	 */
	@Override
	public String getPriceApiPath() {

		return tracfoneApiService.getPriceApiPath();
	}
	/**
	 * @return homePageLevel
	 */
	@Override
	public int getHomePageLevel() {

		return applicationConfigService.getHomePageLevel();
	}
	/**
	 * @return language
	 */
	@Override
	public String getLanguage() {

		return CommerceUtil.getLanguage(currentPage, getHomePageLevel());
	}

	/**
	 * @return queryString String is used for price API call
	 */
	@Override
	public String getQueryString() {
		StringBuilder query = new StringBuilder("brand").append("=")
				.append(CommerceUtil.getBrandValue(currentPage, getHomePageLevel())).append("&").append("product-id")
				.append("=").append(this.productID);
		return query.toString();
	}

	@Override
	public String getImage() { return DynamicMediaUtils.changeMediaPathToDMPath(compareimage, request.getResourceResolver()); }

	private void getSKUDetails(){
			if(null != product && product.get(CommerceConstants.SKUS) != null && product.get(CommerceConstants.SKUS).isJsonArray()) {
				skusArray = product.get(CommerceConstants.SKUS).getAsJsonArray();
				JsonObject element = skusArray.get(0).getAsJsonObject();
				color = element.get(CommerceConstants.COLOR).getAsString();
				skuId = element.get(CommerceConstants.ID).getAsString();
			}
	}

	/**
	 *
	 * @return String - Cantentry id
	 */
	@Override
	public String getCantentryId() {
		if (product != null && product.get(CommerceConstants.CATENTRY_ID) != null) {
			return product.get(CommerceConstants.CATENTRY_ID).getAsString();
		}
		return null;
	}

	@Override
	public String getColor(){ return color; }

	@Override
	public String getSkuId() { return skuId; }

	@Override
	public String getThumbnailImageAssetId() {
		return thumbnailImageAssetId;
	}

	public void setThumbnailImageAssetId(String thumbnailImageAssetId) {
		this.thumbnailImageAssetId = thumbnailImageAssetId;
	}

	@Override
	public String getThumbnailImageAssetAgencyId() {
		return thumbnailImageAssetAgencyId;
	}

	public void setThumbnailImageAssetAgencyId(String thumbnailImageAssetAgencyId) {
		this.thumbnailImageAssetAgencyId = thumbnailImageAssetAgencyId;
	}

	/**
	 *
	 * @return String - Edit product URL for accessory type products.
	 * */
	public String getAccessoryEditUrl(){
		 return ApplicationUtil.getPropertiesFromRootPage(currentPage.getPath(),resource.getResourceResolver(),ApplicationConstants.ACCESSORY_EDIT_URL);
	}

	/**
	 * @return String -  inventoryApiPath
	 */
	@Override
	public String getInventoryApiPath() {
		return tracfoneApiService.getInventoryApiPath();
	}
	@Override
	public String getMarketingIds() {
		return getCharactersticValue(CommerceConstants.EXTRA_CHARACTERISTICS,CommerceConstants.MARKET);
	}
	
	private String getCharactersticValue(String charactersticsArrayName, String propertyName){
		String charactersticValue = StringUtils.EMPTY;
		if (product != null && product.get(CommerceConstants.PRODUCT_CHARACTERISTICS) != null && product.get(CommerceConstants.PRODUCT_CHARACTERISTICS).isJsonArray()) {
				JsonArray prodSpecsArray;
				prodSpecsArray = product.get(CommerceConstants.PRODUCT_CHARACTERISTICS).getAsJsonArray();
				if (prodSpecsArray.size() > 0) {
					for (int i = 0; i < prodSpecsArray.size(); i++) {
						JsonObject element = prodSpecsArray.get(i).getAsJsonObject();
						if(!element.get("identifier").getAsString().isEmpty() && propertyName.toLowerCase().equals(element.get("identifier").getAsString().trim().toLowerCase())){
							charactersticValue = element.get("value").getAsString();
						}
					}
				}
		}
	  return charactersticValue;
	}

	@Override
	public String getInventoryQueryString() {
		StringBuilder query = new StringBuilder(CommerceConstants.BRAND).append(CommerceConstants.EQUALS_TO)
				.append(CommerceUtil.getBrandValue(currentPage, getHomePageLevel())).append(CommerceConstants.AMPERSAND)
				.append(CommerceConstants.IDENTIFIER).append(CommerceConstants.EQUALS_TO).append(getSkuId());
		return query.toString();
	}

	/**
	 *
	 * @return String - Default fallback thumbnail Image.
	 * */
	public String getDefaultFallbackThumbnailImage(){
		String image =  ApplicationUtil.getPropertiesFromRootPage(currentPage.getPath(),resource.getResourceResolver(),ApplicationConstants.FALLBACK_THUMBNAIL_IMAGE);
		return DynamicMediaUtils.changeMediaPathToDMPath(image, request.getResourceResolver());
	}
	
	/**
	 * 
	 * @return String - PIM_OEM
	 * @throws SchemaViolationError 
	 */
	public String getPimOEM() {
		return getCharactersticValue(CommerceConstants.PRODUCT_CHARACTERISTICS,CommerceConstants.PIM_OEM);
	}
	
	/**
	 * 
	 * @return String - PIM_Market_Name
	 * @throws SchemaViolationError 
	 */
	public String getPimMarketName() {
		return getCharactersticValue(CommerceConstants.PRODUCT_CHARACTERISTICS,CommerceConstants.PIM_MARKET_NAME);
	}
	
	/**
	 * 
	 * @return String - PIM_Model
	 */
	public String getPimModel() {
		return getCharactersticValue(CommerceConstants.PRODUCT_CHARACTERISTICS,CommerceConstants.PIM_MODEL);
	}
	
	/**
	 * 
	 * @return String - PIM_Stock_Type
	 */
	public String getPimStockType() {
		String stockType = getCharactersticValue(CommerceConstants.PRODUCT_CHARACTERISTICS,CommerceConstants.PIM_STOCK_TYPE);		
		if(StringUtils.isNotBlank(stockType)) {			
			if(stockType.equalsIgnoreCase(CommerceConstants.NEW)) {
				return StringUtils.EMPTY;
			} else if(stockType.equalsIgnoreCase(CommerceConstants.REFURBISHED)) {
				return CommerceConstants.RECONDITIONED;
			}		
		}		
		return stockType;
	}
	
	/**
	 * 
	 * @return String - PIM_Brand
	 */
	public String getPimBrand() {
		return getCharactersticValue(CommerceConstants.PRODUCT_CHARACTERISTICS,CommerceConstants.PIM_BRAND);
	}

	/**
	 * 
	 * @return String - PIM_AMX_Technology
	 */
	public String getPimAMXTech() {
		return getCharactersticValue(CommerceConstants.PRODUCT_CHARACTERISTICS,CommerceConstants.PIM_AMX_TECHNOLOGY);
	}
	
	/**
	 * 
	 * @return String - PIM_Description
	 */
	public String getPimDescription() {
		return getCharactersticValue(CommerceConstants.PRODUCT_CHARACTERISTICS,CommerceConstants.PIM_DESCRIPTION);
	}
	
	/**
	 * 
	 * @return String - PIM_Color
	 */
	public String getPimColor() {
		return getCharactersticValue(CommerceConstants.PRODUCT_CHARACTERISTICS,CommerceConstants.PIM_COLOR);
	}
	
	/**
	 * @return String - seoDynamicTitle
	 */
	public String getSeoDynamicTitle() {
		return seoDynamicTitle;
	}

	/**
	 * Sets seoDynamicTitle
	 * @param String - seoDynamicTitle
	 */
	public void setSeoDynamicTitle(String seoDynamicTitle) {
		this.seoDynamicTitle = seoDynamicTitle;
	}

	/**
	 * @return Resource - tablinks
	 */
	@Override
	public Resource getTablinks() {
		return tablinks;
	}

	/**
	 *<p>Fetches retailPriceLabel</p>
	 *
	 * @return the retailPriceLabel
	 */
	@Override
	public String getRetailPriceLabel() {
		return retailPriceLabel;
	}

	/**
	 * <p>Sets retailPriceLabel</p>
	 *
	 *@param retailPriceLabel - the retailPriceLabel to set
	 */
	@Override
	public void setRetailPriceLabel(String retailPriceLabel) {
		this.retailPriceLabel = retailPriceLabel;
	}

	/**
	 *<p>Fetches showPriceDetailsAboveImg</p>
	 *
	 * @return the showPriceDetailsAboveImg
	 */
	@Override
	public String getShowPriceDetailsAboveImg() {
		return showPriceDetailsAboveImg;
	}

	/**
	 * <p>Sets showPriceDetailsAboveImg</p>
	 *
	 *@param showPriceDetailsAboveImg - the showPriceDetailsAboveImg to set
	 */
	@Override
	public void setShowPriceDetailsAboveImg(String showPriceDetailsAboveImg) {
		this.showPriceDetailsAboveImg = showPriceDetailsAboveImg;
	}

	/**
	 *<p>Fetches tabLinksSize</p>
	 *
	 * @return the tabLinksSize
	 */
	@Override
	public int getTabLinksSize() {
		return tabLinksSize;
	}

	/**
	 * <p>Sets tabLinksSize</p>
	 *
	 *@param tabLinksSize - the tabLinksSize to set
	 */
	@Override
	public void setTabLinksSize(int tabLinksSize) {
		this.tabLinksSize = tabLinksSize;
	}

	/**
	 *
	 * @return String - firstImagePath.
	 * */
	@Override
	public String getFirstImagePath(){
		String image = "";
		if(multilinks!=null) {
			for(Resource resource: multilinks.getChildren()) {
				image = resource.getValueMap().get("imagePath","");
				if(StringUtils.isNotEmpty(image)) {
					return DynamicMediaUtils.changeMediaPathToDMPath(image, request.getResourceResolver());
				}
			}
		}
		return "";
	}

	/**
	 * <p>Fetches pricecaptionplp of the product</p>
	 * 
	 * @return String - pricecaptionplp
	 */
	@Override
	public String getPricecaptionplp(){
		return pricecaptionplp;
	}
	
	/**
	 * <p>
	 * Method to return showTimer
	 * 
	 * @return String showTimer
	 */
	@Override
	public String getShowTimer() {
		return showTimer;
	}

	/**
	 * <p>Fetches homeInternetDiscountPrice of the product</p>
	 * 
	 * @return String - homeInternetDiscountPrice
	 */
	@Override
	public String getHomeInternetDiscountPrice(){
		return homeInternetDiscountPrice;
	}

}

