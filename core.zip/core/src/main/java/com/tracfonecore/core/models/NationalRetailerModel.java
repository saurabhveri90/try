package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

public interface NationalRetailerModel extends ComponentExporter {

	@JsonProperty("nationalRetailerHeading")
	public String getNationalRetailerHeading();

	@JsonProperty("nationalRetailerSubHeading")
	public String getNationalRetailerSubHeading();
	
	@JsonProperty("retailerName")
	public String getRetailerName();

	@JsonProperty("categoryIdPlans")
	public String getCategoryIdPlans();
}
