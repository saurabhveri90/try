package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.settings.SlingSettingsService;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.DeEnrollmentReasonsBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.CheckBalanceModel;
import com.tracfonecore.core.models.CheckBalanceOptionsModel;
import com.tracfonecore.core.utils.ApplicationUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CheckBalanceModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/checkbalance", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true")})
public class CheckBalanceModelImpl implements CheckBalanceModel{

	@Self
	private SlingHttpServletRequest request;
	
	@Inject
	private SlingSettingsService settingService;
	
	@Inject
	private Resource resource;
	
	@ValueMapValue
	private String categoryIdPlans;
	
	@ValueMapValue
	private String plansPlpPagePath;
	
	@ValueMapValue
	private String addOnILDText;

	@ValueMapValue
	private String nextChargeDateILDText;
	
	@ValueMapValue
	private String heading;
	
	@ValueMapValue
	private String nextChargeDateILDValue;
	
	@ValueMapValue
	private String planDetailHeading;
	
	@ValueMapValue
	private String serviceEndDateText;
	
	@ValueMapValue
	private String joinAutoRefilText;
	
	@ValueMapValue
	private String refillNowText;
	
	@ValueMapValue
	private String dropDownPlaceHolder;
	
	@ValueMapValue
	private String switchButtonILDText;
	
	@ValueMapValue
	private String autoRefillHomePagePath;
	
	@ValueMapValue
	private String refillHomePagePath;
	
	@ValueMapValue
	private String globalCallingCardPDPPagePath;
	
	@ChildResource
	private List<CheckBalanceOptionsModel> planAutoRefillMessageMapping;
	
	@ChildResource
	private List<CheckBalanceOptionsModel> benefitChangeOptionsForPlan;
	
	@ChildResource
	private List<CheckBalanceOptionsModel> benefitChangeOptionsForILD;

	@ValueMapValue
	private String planAutoRefillDefaultMessage;
	
	@ValueMapValue
	private String titleRefillWithPinForPlan;
	
	@ValueMapValue
	private String paragraphRefillWithPinForPlan;
	
	@ValueMapValue
	private String titleCancelEnrollmentForPlan;
	
	@ValueMapValue
	private String paragraphCancelEnrollmentForPlan;
	
	@ValueMapValue
	private String titleRefillWithPinForILD;
	
	@ValueMapValue
	private String paragraphRefillWithPinForILD;
	
	@ValueMapValue
	private String titleCancelEnrollmentForILD;
	
	@ValueMapValue
	private String ildPlanName;

	@ValueMapValue
	private String ildPlanPrice;

	@ValueMapValue
	private String ildPlanPartNumber;

	@ValueMapValue
	private String ildPlanEditCartUrl;

	@ValueMapValue
	private String paragraphCancelEnrollmentForILD;
	
	@ValueMapValue
	private String textHowDoesItWorkModal;

	@ValueMapValue
	private String planDetailsEditCartUrl;

	@ValueMapValue
	private String refillPLPPagePath;
	
	@ValueMapValue
	private String refillStartDateSelector;
	
	@ValueMapValue
	private String refillPLPPageSelector;
	
	@ValueMapValue
	private String refillBuyNowPLPPageSelector;
	
	@ValueMapValue
	private String titleBenefitChangesModalForILD;
	
	@ValueMapValue
	private String subTitleBenefitChangesModalForILD;
	
	@ValueMapValue
	private String titleBenefitChangesModalForPlan;
	
	@ValueMapValue
	private String subTitleBenefitChangesModalForPlan;
		
	@ValueMapValue
	private String redeemPlanModalHeadline;
	
	@ValueMapValue
	private String redeemPlanModalSubheadline;
	
	@ValueMapValue
	private String editGroupNameModalHeadline;
	
	@ValueMapValue
	private String editGroupNameModalSubheadline;
	
	@ValueMapValue
	private String addOnPlanCardInfoText;
		
	@ValueMapValue
	private String addOnPlanImage;
	
	@ValueMapValue
	private String addOnPlanEditCartUrl;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String selectAutoRefillAndSaveMessage;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enableAmazonPrime;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planServiceEndDateInfoModalContent;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String amazonEnrollmentInfoModalContent;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String titleCusgDiscountAlert;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String paragraphCusgDiscountAlert;
	
	private List<DeEnrollmentReasonsBean> deEnrollmentReasons = Collections.emptyList();

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String enableLoginWithVerificationCode;
	
	@PostConstruct
	private void initModel() {
		deEnrollmentReasons = new ArrayList<>();
		if (resource != null) {
			getMultifieldResource();
		}
	}
	
	private void getMultifieldResource() {
		for (Resource child : resource.getChildren()) {
			Iterator<Resource> it = child.listChildren();
			if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.DEENROLLMENT_REASONS.equals(child.getName())) {
				setDeEnrollmentReasons(it);
			}
		}
	}
	
	private void setDeEnrollmentReasons(Iterator<Resource> it) {
		while (it.hasNext()) {
			Resource grandChild = it.next();
			DeEnrollmentReasonsBean deEnrollmentReasonsBean = new DeEnrollmentReasonsBean();
			deEnrollmentReasonsBean.setDeEnrollmentReason(grandChild.getValueMap().get(ApplicationConstants.DEENROLLMENT_REASON, String.class));
			deEnrollmentReasonsBean.setDeEnrollmentReasonText(grandChild.getValueMap().get(ApplicationConstants.DEENROLLMENT_REASON_TEXT, String.class));
			deEnrollmentReasons.add(deEnrollmentReasonsBean);
		}
	}
	
	
	private String getProcessedPagePath(String inputPagePath) {
		String finalPagePath = ApplicationUtil.getShortUrl(request.getResourceResolver(), inputPagePath);
        return ApplicationUtil.isPublish(settingService) && StringUtils.isNotBlank(finalPagePath) ?
        		ApplicationUtil.getUrlWithoutDomain(getShortURL(request.getServerName(), finalPagePath))
        			:finalPagePath;
	}
	
	private String getShortURL(String serverDomain, String url) {
		return StringUtils.containsIgnoreCase(url, serverDomain)
				? StringUtils.substringAfter(url,serverDomain) : url;
	}
	
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
	@Override
	public String getPlansPlpPagePath() {
		return getProcessedPagePath(plansPlpPagePath);
	}

	/**
	 * @return the categoryIdPlans
	 */
	@Override
	public String getCategoryIdPlans() {
		return categoryIdPlans;
	}

	/**
	 * @return the addOnILDText
	 */
	@Override
	public String getAddOnILDText() {
		return addOnILDText;
	}

	/**
	 * @return the nextChargeDateILDText
	 */
	@Override
	public String getNextChargeDateILDText() {
		return nextChargeDateILDText;
	}

	/**
	 * @return the nextChargeDateILDValue
	 */
	@Override
	public String getNextChargeDateILDValue() {
		return nextChargeDateILDValue;
	}

	/**
	 * @return the planDetailHeading
	 */
	@Override
	public String getPlanDetailHeading() {
		return planDetailHeading;
	}

	/**
	 * @return the serviceEndDateText
	 */
	@Override
	public String getServiceEndDateText() {
		return serviceEndDateText;
	}

	/**
	 * @return the joinAutoRefilText
	 */
	@Override
	public String getJoinAutoRefilText() {
		return joinAutoRefilText;
	}

	/**
	 * @return the refillNowText
	 */
	@Override
	public String getRefillNowText() {
		return refillNowText;
	}

	/**
	 * @return the dropDownPlaceHolder
	 */
	@Override
	public String getDropDownPlaceHolder() {
		return dropDownPlaceHolder;
	}

	/**
	 * @return the switchButtonILDText
	 */
	@Override
	public String getSwitchButtonILDText() {
		return switchButtonILDText;
	}

	/**
	 * @return the heading
	 */
	@Override
	public String getHeading() {
		return heading;
	}

	/**
	 * @return the autoRefillHomePagePath
	 */
	@Override
	public String getAutoRefillHomePagePath() {
		return getProcessedPagePath(autoRefillHomePagePath);
	}

	/**
	 * @return the refillHomePagePath
	 */
	@Override
	public String getRefillHomePagePath() {
		return getProcessedPagePath(refillHomePagePath);
	}

	/**
	 * @return the globalCallingCardPDPPagePath
	 */
	@Override
	public String getGlobalCallingCardPDPPagePath() {
		return getProcessedPagePath(globalCallingCardPDPPagePath);
	}

	/**
	 * @return the planAutoRefillMessageMapping
	 */
	@Override
	public List<CheckBalanceOptionsModel> getPlanAutoRefillMessageMapping() {
		List<CheckBalanceOptionsModel> list = Optional.ofNullable(planAutoRefillMessageMapping)
							.map(List::stream).orElseGet(Stream::empty).collect(Collectors.toList());
		return new ArrayList<>(list);
	}
	
	/**
	 * @return the benefitChangeOptionsForPlan
	 */
	@Override
	public List<CheckBalanceOptionsModel> getBenefitChangeOptionsForPlan() {
		List<CheckBalanceOptionsModel> list = Optional.ofNullable(benefitChangeOptionsForPlan)
				.map(List::stream).orElseGet(Stream::empty).collect(Collectors.toList());
		return new ArrayList<>(list);
	}

	/**
	 * @return the benefitChangeOptionsForILD
	 */
	@Override
	public List<CheckBalanceOptionsModel> getBenefitChangeOptionsForILD() {
		List<CheckBalanceOptionsModel> list = Optional.ofNullable(benefitChangeOptionsForILD)
				.map(List::stream).orElseGet(Stream::empty).collect(Collectors.toList());
		return new ArrayList<>(list);
	}
	/**
	 * @return the planAutoRefillDefaultMessage
	 */
	@Override
	public String getPlanAutoRefillDefaultMessage() {
		return planAutoRefillDefaultMessage;
	}

	/**
	 * @return the titleRefillWithPinForPlan
	 */
	@Override
	public String getTitleRefillWithPinForPlan() {
		return titleRefillWithPinForPlan;
	}

	/**
	 * @return the paragraphRefillWithPinForPlan
	 */
	@Override
	public String getParagraphRefillWithPinForPlan() {
		return paragraphRefillWithPinForPlan;
	}

	/**
	 * @return the titleCancelEnrollmentForPlan
	 */
	@Override
	public String getTitleCancelEnrollmentForPlan() {
		return titleCancelEnrollmentForPlan;
	}

	/**
	 * @return the paragraphCancelEnrollmentForPlan
	 */
	@Override
	public String getParagraphCancelEnrollmentForPlan() {
		return paragraphCancelEnrollmentForPlan;
	}

	/**
	 * @return the titleRefillWithPinForILD
	 */
	@Override
	public String getTitleRefillWithPinForILD() {
		return titleRefillWithPinForILD;
	}

	/**
	 * @return the paragraphRefillWithPinForILD
	 */
	@Override
	public String getParagraphRefillWithPinForILD() {
		return paragraphRefillWithPinForILD;
	}

	/**
	 * @return the titleCancelEnrollmentForILD
	 */
	@Override
	public String getTitleCancelEnrollmentForILD() {
		return titleCancelEnrollmentForILD;
	}

	/**
	 * @return the paragraphCancelEnrollmentForILD
	 */
	@Override
	public String getParagraphCancelEnrollmentForILD() {
		return paragraphCancelEnrollmentForILD;
	}

	/**
	 * @return the ildPlanName
	 */
	@Override
	public String getIldPlanName() {
		return ildPlanName;
	}

	/**
	 * @return the ildPlanPrice
	 */
	@Override
	public String getIldPlanPrice() {
		return ildPlanPrice;
	}

	/**
	 * @return the ildPlanPartNumber
	 */
	@Override
	public String getIldPlanPartNumber() {
		return ildPlanPartNumber;
	}

	/**
	 * @return the ildPlanEditCartUrl
	 */
	@Override
	public String getIldPlanEditCartUrl() {
		return ildPlanEditCartUrl;
	}
	
	/**
	 * @return the textHowDoesItWorkModal
	 */
	@Override
	public String getTextHowDoesItWorkModal() {
		return textHowDoesItWorkModal;
	}

	/**
	 * @return the planDetailsEditCartUrl
	 */
	@Override
	public String getPlanDetailsEditCartUrl() {
		return planDetailsEditCartUrl;
	}

	/**
	 * @return the refillPLPPagePath
	 */
	@Override
	public String getRefillPLPPagePath() {
		return getFinalPagePathWithoutExtension(refillPLPPagePath);
	}

	/**
	 * @return the refillStartDateSelector
	 */
	@Override
	public String getRefillStartDateSelector() {
		return refillStartDateSelector;
	}

	public String getFinalPagePathWithoutExtension(String inputPath) {
		return Optional.ofNullable(inputPath).filter(str->StringUtils.isNotBlank(str)&&ApplicationUtil.isPublish(settingService))
				.map(str-> request.getResourceResolver().map(str)).filter(str->StringUtils.isNotBlank(str))
				.map(str->ApplicationUtil.getUrlWithoutDomain(getShortURL(request.getServerName(),str))).orElse(inputPath);
	}
	
	/**
	 * @return the refillPLPPageSelector
	 */
	@Override
	public String getRefillPLPPageSelector() {
		return refillPLPPageSelector;
	}

	/**
	 * @return the titleBenefitChangesModalForILD
	 */
	@Override
	public String getTitleBenefitChangesModalForILD() {
		return titleBenefitChangesModalForILD;
	}

	/**
	 * @return the subTitleBenefitChangesModalForILD
	 */
	@Override
	public String getSubTitleBenefitChangesModalForILD() {
		return subTitleBenefitChangesModalForILD;
	}

	/**
	 * @return the titleBenefitChangesModalForPlan
	 */
	@Override
	public String getTitleBenefitChangesModalForPlan() {
		return titleBenefitChangesModalForPlan;
	}

	/**
	 * @return the subTitleBenefitChangesModalForPlan
	 */
	@Override
	public String getSubTitleBenefitChangesModalForPlan() {
		return subTitleBenefitChangesModalForPlan;
	}

	/**
	 * @return the redeemPlanModalHeadline
	 */
	@Override
	public String getRedeemPlanModalHeadline() {
		return redeemPlanModalHeadline;
	}

	/**
	 * @return the redeemPlanModalSubheadline
	 */
	@Override
	public String getRedeemPlanModalSubheadline() {
		return redeemPlanModalSubheadline;
	}

	@Override
	public String getSelectAutoRefillAndSaveMessage() {
		return selectAutoRefillAndSaveMessage;
	}

	@Override
	public Boolean getEnableAmazonPrime() {
		return StringUtils.isNotBlank(enableAmazonPrime)&& ApplicationConstants.TRUE.equalsIgnoreCase(enableAmazonPrime)?true:false;
	}

	@Override
	public String getAmazonEnrollmentInfoModalContent() {
		return amazonEnrollmentInfoModalContent;
	}

	@Override
	public String getPlanServiceEndDateInfoModalContent() {
		return planServiceEndDateInfoModalContent;
	}

	@Override
	public String getTitleCusgDiscountAlert() {
		return titleCusgDiscountAlert;
	}

	@Override
	public String getParagraphCusgDiscountAlert() {
		return paragraphCusgDiscountAlert;
	}

	@Override
	public String getRefillBuyNowPLPPageSelector() {
		return refillBuyNowPLPPageSelector;
	}

	@Override
	public String getEditGroupNameModalHeadline() {
		return editGroupNameModalHeadline;
	}

	@Override
	public String getEditGroupNameModalSubheadline() {
		return editGroupNameModalSubheadline;
	}

	@Override
	public String getAddOnPlanCardInfoTextt() {
		return addOnPlanCardInfoText;
	}

	@Override
	public String getAddOnPlanImage() {
		return addOnPlanImage;
	}

	@Override
	public String getAddOnPlanEditCartUrl() {
		return addOnPlanEditCartUrl;
	}
	
	@Override
	public List<DeEnrollmentReasonsBean> getDeEnrollmentReasons() {
		return new ArrayList<DeEnrollmentReasonsBean>(deEnrollmentReasons);
	}

	@Override
	public String getEnableLoginWithVerificationCode() {
		return StringUtils.isNotBlank(enableLoginWithVerificationCode)&& ApplicationConstants.TRUE.equalsIgnoreCase(enableLoginWithVerificationCode)?"true":"false";
	}
}
