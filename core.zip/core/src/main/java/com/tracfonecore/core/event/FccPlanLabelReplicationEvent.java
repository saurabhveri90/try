package com.tracfonecore.core.event;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.settings.SlingSettingsService;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.event.Event;
import org.osgi.service.event.EventConstants;
import org.osgi.service.event.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.model.WorkflowModel;
import com.day.cq.replication.ReplicationAction;
import com.day.cq.replication.ReplicationActionType;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.BroadbandFactsConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;

@Component(service = EventHandler.class, immediate = true, property = {
		EventConstants.EVENT_TOPIC + "=" + ReplicationAction.EVENT_TOPIC,
		EventConstants.EVENT_FILTER + "=(paths=/content/dam/*)"})
public class FccPlanLabelReplicationEvent implements EventHandler {
	private static final Logger LOG = LoggerFactory.getLogger(FccPlanLabelReplicationEvent.class);

	private static final String TF_CREATE_MODIFY_SERVICE = "tf-create-modify-service-user";
	private static final String JCR_PATH = "JCR_PATH";
	private static final String IS_SAFELINK = "isSafelinkEligible";

	@Reference
	private ResourceResolverFactory resolverFactory;

	@Reference
	private BroadbandFactsConfigService broadbandFactsConfigService;

	@Reference
	private ApplicationConfigService applicationConfigService;
	
	@Reference
	private SlingSettingsService settingService;

	private String contentCFPath;
	
	private Boolean isSafeLink;

	private String workflowModelPath;

	private static final String CF_MASTER_NODE = "jcr:content/data/master";

	Map<String, Object> loginParams = Collections.emptyMap(); 
		

	@Override
	public void handleEvent(Event event) {
		LOG.debug("IS PUBLISH ENVIROMENT {}",ApplicationUtil.isPublish(settingService));
		if(!ApplicationUtil.isPublish(settingService)){
			//Reset contentCFPath workflowModelPath isSafeLink every call
			contentCFPath = null;
			workflowModelPath = null;
			isSafeLink = false;
			LOG.info("Init handleEvent on FccPlanLabelReplicationEvent");
			loginParams = new HashMap<>();
			loginParams.put(ResourceResolverFactory.SUBSERVICE, TF_CREATE_MODIFY_SERVICE);
			if(Boolean.TRUE.equals(checkConfigs(event))) {
				Optional.ofNullable(ReplicationAction.fromEvent(event))
						//Check if the event is an Activation type of Replication
						.filter(action -> action.getType().equals(ReplicationActionType.ACTIVATE))
						//Check if the path is inside their ContentCFPath or have safeLink flag
						.filter(action -> action.getPath().startsWith(contentCFPath) || isSafeLink)
						//Not replicate if is just a "master" node, must be the complete CF
						.filter(action -> !action.getPath().endsWith(CF_MASTER_NODE))
						.ifPresent(this::handleActivationEvent);
			}
			LOG.debug("Exit handleEvent on FccPlanLabelReplicationEvent");
		}
	}

	/**
	 * Handles the activation event.
	 * This method start a workflow upon the event
	 * 
	 * @param action The replication action to handle.
	 */
	private void handleActivationEvent(ReplicationAction action) {
		LOG.info("handleActivationEvent on FccPlanLabelReplicationEvent");
		try (ResourceResolver resolver = resolverFactory.getServiceResourceResolver(loginParams)) {
			startWorkflow(resolver, action.getPath());
		} catch (LoginException e) {
			LOG.error("LoginException at handleActivationEvent caused by : ", e);
		}
	}

	/**
	 * Starts a workflow.
	 * This method creates a workflow session and starts a workflow with the
	 * given model path and workflow data.
	 * 
	 * @param resourceResolver The resource resolver to use.
	 * @param path The path of the resource being replicated.
	 */
	private void startWorkflow(ResourceResolver resourceResolver, String path) {
		LOG.info("startWorkflow on FccPlanLabelReplicationEvent");
		try {
			LOG.debug("startWorkflow : {}",path);
			WorkflowSession workflowSession = resourceResolver.adaptTo(WorkflowSession.class);
			WorkflowModel model = workflowSession.getModel(workflowModelPath);
			WorkflowData workflowData = workflowSession.newWorkflowData(JCR_PATH, path);
			workflowSession.startWorkflow(model, workflowData);
			Session session = resourceResolver.adaptTo(Session.class);
			session.save();
		} catch (WorkflowException | RepositoryException e) {
			LOG.error("Cannot execute startWorkflow ", e);
		}

	}

	/**
	 * Check if the configs of the event was configurated.
	 * @param event the main event
	 * @return Boolean true or false
	 */
	private Boolean checkConfigs(Event event){
		try (ResourceResolver resourceResolver = resolverFactory.getServiceResourceResolver(loginParams)) {
			LOG.debug("contentCFPath : {}",ReplicationAction.fromEvent(event).getPath());
			//Get the resource from the path event.
			Resource resource = resourceResolver.getResource(ReplicationAction.fromEvent(event).getPath());
			Node node = resource.adaptTo(Node.class);
			if(node.hasNode(CF_MASTER_NODE)) {
				//get the "master" node of CF
				Node contentFragmentNode = node.getNode(CF_MASTER_NODE);
				LOG.debug("ReplicationEvent masterNodePath {} ", contentFragmentNode.getPath());
				Property brandProperty = contentFragmentNode.getProperty("brandHeading");
				//Get the safelink value or null
				Property safeLink = (contentFragmentNode.hasProperty(IS_SAFELINK)) ? contentFragmentNode.getProperty(IS_SAFELINK) : null;
				if(brandProperty != null){	
					String brand = brandProperty.getString();
					LOG.debug("checkConfigs brand  {}", brand);
					//Set the contentCFPath from OSGi config using the brand.
					contentCFPath = ConfigurationUtil.getConfigValue(broadbandFactsConfigService.getFactsContentBasePath(), brand);
					//set the language in the contentCFPath
					String lang =  getLanguage(ReplicationAction.fromEvent(event).getPath());
					//Block "ES" Content Fragments
					if(lang == null || StringUtils.equals(lang, "es")) return false;
					contentCFPath = contentCFPath.replace("{language}", lang);
					
					LOG.debug("checkConfigs contentCFPath updated {}", contentCFPath);
					//Set the isSafeLink true if the masterNode have the value Y in the safelink flag
					isSafeLink = (safeLink != null && safeLink.getString().equals("Y"));
					LOG.debug("checkConfigs isSafeLink {}", isSafeLink);
					//get the path of the workflow form the OSGi config.
					workflowModelPath = broadbandFactsConfigService.getWorkflowModelPath();
					LOG.debug("workflowModelPath : {}",workflowModelPath);
				}
			}		
			if(StringUtils.isNotEmpty(workflowModelPath) && StringUtils.isNotEmpty(contentCFPath)) return true;
		} catch (LoginException | RepositoryException e) {
			LOG.error("LoginException  | RepositoryException at handleEvent caused by : ", e);
		}
		return false;
	}



	/**
	 * Get language from path
	 * @param originPath path of the CF
	 * @return String - language
	 */
	private String getLanguage(String originPath) {
		String[] parts = originPath.split(ApplicationConstants.SLASH);
		if(parts.length < 5){
			return originPath;
		}
		LOG.debug("Language from {} is {}",originPath, parts[4]);
		return parts[4];
	}
}
