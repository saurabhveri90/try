package com.tracfonecore.core.models;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.tracfonecore.core.beans.OtherSpecsPDPBean;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Model(adaptables = { org.apache.sling.api.resource.Resource.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class PlanSpecificationsModel {

    private static Logger LOGGER = LoggerFactory.getLogger(PlanSpecificationsModel.class);
    @Self
    public Resource resource;
    @Inject
    protected Page currentPage;
    @ScriptVariable
    private ValueMap properties;
    @Inject
    private ResourceResolver resourceResolver;

	private String saveMoreData;
    private String disclaimerText;
    private String disclaimerCTALabel;
    private String disclaimerAccessibilityText;
    private String disclaimerCTALink;

    @ChildResource
    private  List<Resource> otherSpecsPDP;

    private List<OtherSpecsPDPBean> specsPDP;

    public List<OtherSpecsPDPBean> getSpecsPDP() {
        return specsPDP;
    }

    public void setSpecsPDP(List<OtherSpecsPDPBean> specsPDP) {
        this.specsPDP = specsPDP;
    }

    public void getPlanCardProperty() {
        String name=null;
        PageManager pm = resource.getResourceResolver().adaptTo(PageManager.class);
        Page currentPage = pm.getContainingPage(resource);
        String page= currentPage.getPath()+"/jcr:content/root/responsivegrid/product/plancard";
        Resource productRes= resourceResolver.getResource(page);
        if (productRes != null) {
            LOGGER.debug("properties::{}",productRes.getValueMap());
			saveMoreData = productRes.getValueMap().get("promoadditionaltext", String.class);
            LOGGER.debug("properties::{}-------?",saveMoreData);
            disclaimerText = productRes.getValueMap().get("disclaimerText", String.class);
            disclaimerCTALabel = productRes.getValueMap().get("disclaimerCTALabel", String.class);
            disclaimerAccessibilityText = productRes.getValueMap().get("disclaimerAccessibilityText", String.class);
            disclaimerCTALink = productRes.getValueMap().get("disclaimerCTALink", String.class);
            List<OtherSpecsPDPBean> otherSpecsPDPBeans =  new ArrayList<>();
            for (Resource child : productRes.getChildren()) {
                if (("otherSpecsPDP").equals(child.getName())) {
                    Iterator<Resource> it = child.listChildren();
                    setMultiFieldItems(it,otherSpecsPDPBeans);
                }
            }
        }
    }
        private void setMultiFieldItems(Iterator<Resource> it, List<OtherSpecsPDPBean> multiFieldData) {
            LOGGER.debug("Entering setMultiFieldItems OtherSpecsPDPBean method");
            int count=1;
            while (it.hasNext()) {
                OtherSpecsPDPBean otherSpecsPDP= new OtherSpecsPDPBean();
                Resource grandChild = it.next();
                otherSpecsPDP.setCount(count++);
                otherSpecsPDP.setIconPathPDP(grandChild.getValueMap().get("iconPathPDP", String.class));
                otherSpecsPDP.setBadgePDP(grandChild.getValueMap().get("badgePDP",String.class));
                otherSpecsPDP.setValuePDP(grandChild.getValueMap().get("valuePDP",String.class));
                otherSpecsPDP.setDescriptionPDP(grandChild.getValueMap().get("descriptionPDP",String.class));
                otherSpecsPDP.setAccessibilityTextPDP(grandChild.getValueMap().get("accessTextPDP",String.class));
                otherSpecsPDP.setIdentifierPDP(grandChild.getValueMap().get("identifierPDP",String.class));
                multiFieldData.add(otherSpecsPDP);
                setSpecsPDP(multiFieldData);
            }
            LOGGER.debug("Exiting setMultiFieldItems method ");
        }
	public String getSaveMoreData() {
        return saveMoreData;
    }
    public String getDisclaimerText() {
        return disclaimerText;
    }
    public String getDisclaimerCTALabel() {
        return disclaimerCTALabel;
    }
    public String getDisclaimerAccessibilityText() {
        return disclaimerAccessibilityText;
    }
    public String getDisclaimerCTALink() {
        return disclaimerCTALink;
    }

    @PostConstruct
    public void init() {
        getPlanCardProperty();
        LOGGER.debug("in init model for planSpecModel" );
    }

    public List<Resource> getOtherSpecsPDP() {
        return otherSpecsPDP;
    }
    public void setOtherSpecsPDP(List<Resource> otherSpecsPDP) {
        this.otherSpecsPDP = otherSpecsPDP;
    }
}
