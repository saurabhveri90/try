package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

public interface CtaWithRadioModel extends ComponentExporter {
	
	/**
	 * @return flowType
	 */
	@JsonProperty("flowType")
	public String getFlowType();
	
	/**
	 * @return heading
	 */
	@JsonProperty("heading")
	public String getHeading();
	
	/**
	 * @return subheading
	 */
	@JsonProperty("subheading")
	public String getSubheading();

	/**
	 * @return the options
	 */
	@JsonProperty("options")
	public List<CtaWithRadioOptionsModel> getOptions();
	
}
