/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.AddToCartOptBean;

/**
 * Defines the {@code Column-Control} Sling Model used for the
 * {@code /apps/tracfone-core/components/commerce/paymentoptions} component.
 */
public interface PaymentOptionsModel extends ComponentExporter {

	/**
	 * <p>
	 * Fetches category type of the product
	 * </p>
	 * 
	 * @return String - category type of the product
	 */
	@JsonProperty("categoryType")
	public String getCategoryType();

	/**
	 * <p>
	 * Fetches payment option text
	 * </p>
	 * 
	 * @return String - payment option text
	 */
	@JsonProperty("paymentOptionsLabel")
	public String getPaymentOptionsLabel();

	/**
	 * <p>
	 * Fetches CTA text of EMI payment option link/p>
	 * 
	 * @return String - CTA text of EMI Payment option
	 */
	@JsonProperty("paymentCtaText")
	public String getPaymentCtaText();

	/**
	 * <p>
	 * Fetches CTA Alt-text of EMI payment option
	 * </p>
	 * 
	 * @return String - CTA Alt-text of EMI payment option
	 */
	@JsonProperty("paymentCtaAltText")
	public String getPaymentCtaAltText();

	/**
	 * <p>
	 * Fetches CTA link of EMI payment option
	 * </p>
	 * 
	 * @return String - CTA link of EMI payment option
	 */
	@JsonProperty("paymentCtaLink")
	public String getPaymentCtaLink();

	/**
	 * <p>
	 * Fetches payment options list
	 * </p>
	 * 
	 * @return String - list of payment options
	 */
	@JsonProperty("paymentOptions")
	public List<AddToCartOptBean> getPaymentOptions();

	/**
	 * <p>
	 * Fetches logoLink
	 * </p>
	 *
	 * @return the logoLink
	 */
	@JsonProperty("logoLink")
	public String getLogoLink();

	/**
	 * <p>
	 * Fetches logoAltText
	 * </p>
	 *
	 * @return the logoAltText
	 */
	@JsonProperty("logoAltText")
	public String getLogoAltText();

	/**
	 * <p>
	 * Fetches link no-follow
	 * </p>
	 * 
	 * @return String - link no-follow
	 */
	@JsonProperty("donotfollowlink")
	public String getDonotfollowlink();

	/**
	 * <p>
	 * Fetches showStepsNumber
	 * </p>
	 *
	 * @return the showStepsNumber
	 */
	public String getShowStepsNumber();

	/**
	 * <p>
	 * Fetches enablePromotionalOffers
	 * </p>
	 *
	 * @return the enablePromotionalOffers
	 */
	public String getEnablePromotionalOffers();

	/**
	 * <p>
	 * Fetches CTA text of Offer detail option link/p>
	 * 
	 * @return String - CTA text of Offer detail option
	 */
	@JsonProperty("promoCtaText")
	public String getPromoCtaText();

	/**
	 * <p>
	 * Fetches CTA Alt-text of offer details
	 * </p>
	 * 
	 * @return String - CTA Alt-text of Offer detail option
	 */
	@JsonProperty("promoCtaAltText")
	public String getPromoCtaAltText();

	/**
	 * <p>
	 * Fetches CTA link of Activation Offers
	 * </p>
	 * 
	 * @return String - CTA link of Activation offer details
	 */
	@JsonProperty("promoActivationCtaLink")
	public String getPromoActivationCtaLink();

	/**
	 * <p>
	 * Fetches CTA link of Port-In Offers
	 * </p>
	 * 
	 * @return String - CTA link of Port-In offer details
	 */
	@JsonProperty("promoPortInCtaLink")
	public String getPromoPortInCtaLink();

	/**
	 * <p>
	 * Fetches Offer Details link no-follow
	 * </p>
	 * 
	 * @return String - link no-follow
	 */
	@JsonProperty("promoDoNotFollowLink")
	public String getPromoDoNotFollowLink();

	/**
	 * <p>
	 * Fetches See other Payment Option Text
	 * </p>
	 * 
	 * @return String - other payment options text
	 */
	@JsonProperty("otherPayOptionsCtaText")
	public String getOtherPayOptionsCtaText();

	/**
	 * <p>
	 * Fetches See other Payment Option Accessibility Text
	 * </p>
	 * 
	 * @return String - other payment options Accessibility Text
	 */
	@JsonProperty("otherPayOptionsCtaAltText")
	public String getOtherPayOptionsCtaAltText();

	/**
	 * <p>
	 * Fetches enablePromotionalOfferModal
	 * </p>
	 *
	 * @return the enablePromotionalOfferModal
	 */
	public String getEnablePromotionalOfferModal();

	/**
	 * <p>
	 * Fetches CTA link of Veriff Offers
	 * </p>
	 * 
	 * @return String - CTA link of Veriff offer details
	 */
	@JsonProperty("promoVeriffCtaLink")
	public String getPromoVeriffCtaLink();

	/**
	 * <p>
	 * Fetches hide other payment options
	 * </p>
	 * 
	 * @return String - hide other options
	 */
	@JsonProperty("hideOtherOptionDropDown")
	public String getHideOtherOptionDropDown();

	/**
	 * <p>
	 * Fetches ineligible plan promotional message
	 * </p>
	 *
	 * @return String - ineligible plan promotional message
	 */
	@JsonProperty("inEligiblePlanMsg")
	public String getInEligiblePlanMsg();


	/**
	 * <p>
	 * Fetches Eligible Plan PLP Link
	 * </p>
	 *
	 * @return String - eligible plan PLP link
	 */
	@JsonProperty("eligiblePlanPLPLink")
	public String getEligiblePlanPLPLink();

	/**
	 * <p>
	 * Fetches showEligiblePlanLink
	 * </p>
	 *
	 * @return String - showEligiblePlanLink
	 */
	@JsonProperty("showEligiblePlanLink")
	public String getShowEligiblePlanLink();

	/**
	 * <p>
	 * Fetches CTA link of DCOT Offers
	 * </p>
	 * 
	 * @return String - CTA link of DCOT offer details
	 */
	@JsonProperty("promoDcotCtaLink")
	public String getPromoDcotCtaLink();

	/**
	 * <p>
	 * Fetches CTA link of DCOT Offers
	 * </p>
	 * 
	 * @return String - CTA link of DCOT offer details
	 */
	@JsonProperty("promoDcotChrunCtaLink")
	public String getPromoDcotChrunCtaLink();


	/**
	 * <p>
	 * Fetches enableDcotPromoOffers
	 * </p>
	 *
	 * @return the enableDcotPromoOffers
	 */
	public String getEnableDcotPromoOffers();

	/**
	 * <p>
	 * Fetches dcotPromoTextPopupPDP
	 * </p>
	 *
	 * @return String - dcotPromoTextPopupPDP
	 */
	public String getDcotPromoTextPopupPDP();

	/**
	 * <p>
	 * Fetches dcotPromoTextPopupHeadingPDP
	 * </p>
	 *
	 * @return String - dcotPromoTextPopupHeadingPDP
	 */
	public String getDcotPromoTextPopupHeadingPDP();

	/**
	 * <p>
	 * Fetches dcotPromoPlantextonPDP
	 * </p>
	 *
	 * @return String - dcotPromoPlantextonPDP
	 */
	public String getDcotPromoPlantextonPDP();

	/**
	 * <p>
	 * Fetches getDcotFullpricePromoTextPDP
	 * </p>
	 *
	 * @return String - getDcotFullpricePromoTextPDP
	 */
	String getDcotFullpricePromoTextPDP();
	/**
	 * <p>
	 * Fetches veriffPromoTextPopupPDP
	 * </p>
	 *
	 * @return String - veriffPromoTextPopupPDP
	 */
	public String getVeriffPromoTextPopupPDP();

	/**
	 * <p>
	 * Fetches veriffPromoTextPopupHeadingPDP
	 * </p>
	 *
	 * @return String - veriffPromoTextPopupHeadingPDP
	 */
	public String getVeriffPromoTextPopupHeadingPDP();

	/**
	 * <p>
	 * Fetches veriffPromoPlantextonPDP
	 * </p>
	 *
	 * @return String - veriffPromoPlantextonPDP
	 */
	public String getVeriffPromoPlantextonPDP();

	/**
	 * <p>
	 * Fetches portInPromoTextPopupPDP
	 * </p>
	 *
	 * @return String - portInPromoTextPopupPDP
	 */
	public String getPortInPromoTextPopupPDP();

	/**
	 * <p>
	 * Fetches portInPromoTextPopupHeadingPDP
	 * </p>
	 *
	 * @return String - portInPromoTextPopupHeadingPDP
	 */
	public String getPortInPromoTextPopupHeadingPDP();

	/**
	 * <p>
	 * Fetches portInPromoPlantextonPDP
	 * </p>
	 *
	 * @return String - portInPromoPlantextonPDP
	 */
	public String getPortInPromoPlantextonPDP();

	/**
	 * <p>
	 * Fetches activationPromoPopupPDP
	 * </p>
	 *
	 * @return String - activationPromoPopupPDP
	 */
	public String getActivationPromoPopupPDP();

	/**
	 * <p>
	 * Fetches activationPromoPopupHeadingPDP
	 * </p>
	 *
	 * @return String - activationPromoPopupHeadingPDP
	 */
	public String getActivationPromoPopupHeadingPDP();

	/**
	 * <p>
	 * Fetches activationPromoPlantextonPDP
	 * </p>
	 *
	 * @return String - activationPromoPlantextonPDP
	 */
	public String getActivationPromoPlantextonPDP();


}