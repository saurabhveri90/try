package com.tracfonecore.core.config;


import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "PayPal Api Service", description = "Paths for PayPal Api Gateway are added here")
public @interface PayPalApiGatewayConfig {

    @AttributeDefinition(name = "Paypal Client Min Script",description = "Paypal Client Min Script Url", type = AttributeType.STRING)
    String getPaypalClientMinScriptUrl() default "https://js.braintreegateway.com/web/3.76.0/js/client.min.js";

    @AttributeDefinition(name = "Paypal Checkout Script",description = "Paypal Checout Script Url", type = AttributeType.STRING)
    String getPaypalCheckoutScriptUrl() default "https://js.braintreegateway.com/web/3.76.0/js/paypal-checkout.min.js";

    @AttributeDefinition(name = "Paypal Data Collector Script",description = "Paypal Data Collector Script Url", type = AttributeType.STRING)
    String getPaypalDataCollectorScriptUrl() default "https://js.braintreegateway.com/web/3.76.0/js/data-collector.min.js";

    @AttributeDefinition(name = "Paypal SDK Script",description = "Paypal SDK Script Url", type = AttributeType.STRING)
    String getPaypalSdkScriptUrl() default "https://www.paypal.com/sdk/js?client-id=";


}
