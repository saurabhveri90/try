/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.BreadcrumbBean;

import java.util.List;

public interface BreadcrumbModel extends ComponentExporter {

    /**
     * <p>Fetches detail for start level of breadcrumb</p>
     *
     * @return int - start level
     */
    @JsonProperty("startLevel")
    public int getStartLevel();

    /**
     * <p>To hide current page in breadcrumb </p>
     *
     * @return boolean - hide current page
     */
    @JsonProperty("hideCurrent")
    public boolean getHideCurrent();

    /**
     * Navigation List for breadcrumb
     * @return List<BreadcrumbBean>
     */
    public List<BreadcrumbBean> getItemsList();

    /**
     * <p>
     * Method to return exporter type
     * </p>
     *
     * @return String
     */
    @Override
    public String getExportedType();
    
    /**
	 * <p>Fetches breadcrumb schema org</p>
	 *
	 * @return the breadcrumbschema
	 */
	public String getBreadCrumbSchema();
	
	/**
	 * 
	 * <p>sets breadCrumbSchema</p>
	 *
	 */
	public void setBreadCrumbSchema(String breadcrumbSchema);
}
