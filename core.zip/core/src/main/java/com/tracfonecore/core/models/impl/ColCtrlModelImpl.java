/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.tracfonecore.core.beans.ColumnBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.ColCtrlModel;
import com.tracfonecore.core.utils.ItemsExporterUtil;


@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ColCtrlModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/columncontrol", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ColCtrlModelImpl implements ColCtrlModel {

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private Resource resource;
	@Inject
	private SlingModelFilter slingModelFilter;

	@Inject
	private ModelFactory modelFactory;
	@ScriptVariable
	private ValueMap properties;

	@ValueMapValue
	private String displayType;
	
	@ValueMapValue @Default(booleanValues = false)
	private boolean isContainerFluid;

	@ValueMapValue
	private String sectionname;
	
	private List<ColumnBean> columnList = Collections.emptyList();

	private static final Logger LOGGER = LoggerFactory.getLogger(ColCtrlModelImpl.class);	
	
	//Constants
	private static final String OFFSET_XL = "offset-xl-";
	private static final String OFFSET_L = "offset-lg-";
	private static final String OFFSET_M = "offset-md-";


	@PostConstruct
	private void initModel() {

		try {
			columnList = new ArrayList<ColumnBean>();
			Node currentNode = resource.adaptTo(Node.class);

				if (currentNode != null && currentNode.hasNode(ApplicationConstants.COLUMNS)) {

				Node child = currentNode.getNode(ApplicationConstants.COLUMNS);

				// get the grandchild node of the currentNode - which represents where the
				// Column control values are stored
				NodeIterator ni = child.getNodes();
				setMultiFieldItems(ni, columnList);
			}

		} catch (RepositoryException re) {
			LOGGER.error("Repository Exception occurred while fetching column control details {}", re);
		}
	}

	/**
	 * <p>Populates a list with all the values of the each column of the column control  </p>
	 * 
	 * @param ni - iterator of the parent node
	 * @param multiFieldData - list in which the columns data needs to be set
	 */
	private void setMultiFieldItems(NodeIterator ni, List<ColumnBean> multiFieldData) {
		LOGGER.debug("Entering setMultiFieldItems method.");
		try {
			while (ni.hasNext()) {
				ColumnBean columnBean = new ColumnBean();
				Node grandChild = (Node) ni.nextNode();

				if ((grandChild.hasProperty(ApplicationConstants.WIDTH))) {
					columnBean.setColumnwidth(grandChild.getProperty(ApplicationConstants.WIDTH).getString());
				}

				multiFieldData.add(columnBean);

			}
			getColWidthRatioClass(multiFieldData);
		} catch (RepositoryException re) {
			LOGGER.error("Repository Exception occurred while setting column control multifield values {}", re);
		}
		LOGGER.debug("Exiting setMultiFieldItems method.");
	}
	/**
	 * This method is used to create the Column width class for columns based on the width %age set by the authoring
	 * @param multiFieldData- List of multifield properties bean objects
	 */
	private void getColWidthRatioClass(List<ColumnBean> multiFieldData)
	{
		LOGGER.debug("Entering getColWidthRatioClass method.");		

		String strRatio = "";
		int totalCalculatedRatio = 0;
		int i=0;
		int ratio = 0;
		int diff = 0;

		for(i=0; i<multiFieldData.size()-1;i++)
		{
			String colWidth = multiFieldData.get(i).getColumnwidth();

			if(colWidth != null && !colWidth.equals(""))
			{			
				ratio = generateRatio(colWidth);
				totalCalculatedRatio=totalCalculatedRatio+ratio;

				strRatio = Integer.toString(ratio);			
			}			
			multiFieldData.get(i).setColumnClass(createWidthClass(strRatio));
		}
		ratio = generateRatio(multiFieldData.get(multiFieldData.size()-1).getColumnwidth());
		if(ratio+totalCalculatedRatio<=ApplicationConstants.TOTAL_COL)
		{
			strRatio = Integer.toString(ratio);
			if(ratio+totalCalculatedRatio<ApplicationConstants.TOTAL_COL)
			{
				diff = ApplicationConstants.TOTAL_COL-(ratio+totalCalculatedRatio);
				multiFieldData.get(0).setColumnClass(multiFieldData.get(0).getColumnClass()+" "+createOffsetClass(Integer.toString(diff-1)));
			}
		}
		else
		{
			strRatio = Integer.toString(ApplicationConstants.TOTAL_COL-totalCalculatedRatio);
		}		
		multiFieldData.get(multiFieldData.size()-1).setColumnClass(createWidthClass(strRatio));

		LOGGER.debug("Exiting getColWidthRatioClass method.");		

	}
	/**
	 * This method is used to create the Column width class for columns based on the width ratio passed as input parameter to this method
	 * @param widthRatio- Width ratio of the column
	 * @return
	 */
	private String createWidthClass(String widthRatio)
	{
		LOGGER.debug("Entering createWidthClass method.");		

		StringBuilder widthRatioClass = new StringBuilder();

		widthRatioClass.append(ApplicationConstants.COLUMN_XL);
		widthRatioClass.append(widthRatio);
		widthRatioClass.append(" ");
		widthRatioClass.append(ApplicationConstants.COLUMN_L);
		widthRatioClass.append(widthRatio);
		widthRatioClass.append(" ");
		widthRatioClass.append(ApplicationConstants.COLUMN_M);
		widthRatioClass.append(widthRatio);
		widthRatioClass.append(" ");
		widthRatioClass.append(ApplicationConstants.COLUMN_S);
		widthRatioClass.append(Integer.toString(ApplicationConstants.TOTAL_COL));

		LOGGER.debug("Exiting createWidthClass method.");

		return widthRatioClass.toString();
	}
	
	/**
	 * This method is used to create the Column offset class for columns based on the width ratio passed which is left blank
	 * @param widthRatio- Width ratio of the column
	 * @return
	 */
	private String createOffsetClass(String widthRatio)
	{
		LOGGER.debug("Entering createOffsetClass method.");		

		StringBuilder widthRatioClass = new StringBuilder();

		widthRatioClass.append(OFFSET_XL);
		widthRatioClass.append(widthRatio);
		widthRatioClass.append(" ");
		widthRatioClass.append(OFFSET_L);
		widthRatioClass.append(widthRatio);
		widthRatioClass.append(" ");
		widthRatioClass.append(OFFSET_M);
		widthRatioClass.append(widthRatio);

		LOGGER.debug("Exiting createOffsetClass method.");

		return widthRatioClass.toString();
	}
	/**
	 * <p>This method is used to calculate the width ratio based on the cloumn width percentage
	 * @param colWidth - it is teh authored column width percentage
	 * @return
	 */
	private int generateRatio(String colWidth)
	{
		LOGGER.debug("Entering generateRatio method.");
		float ratio = 0;
		int calculatedRatio = 0;

		float width = Float.parseFloat(colWidth);
		ratio = (width*12)/100;
		calculatedRatio = Math.round(ratio);		

		LOGGER.debug("Exiting generateRatio method.");
		return calculatedRatio;
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}	

	@Override
	public List<ColumnBean> getColumnList() {
		
		return new ArrayList<>(columnList);
	}

	@Override
	public String getDisplayType() {
		return displayType;
	}

	@Override
	public String getSectionname() {
		return sectionname;
	}

	/**
	 * <p>
	 * Returns json from items
	 * </p>
	 * 
	 * @return Map - items
	 */
	@Override
	public Map<String, ? extends ComponentExporter> getItems() {
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}

	/**
	 * @return the isContainerFluid
	 */
	@Override
	public boolean getIsContainerFluid() {
		return isContainerFluid;
	}
}