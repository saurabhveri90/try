/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.HeroCarouselSlideBean;
import com.tracfonecore.core.models.HeroCarouselModel;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import com.tracfonecore.core.constants.ApplicationConstants;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { HeroCarouselModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/content/hero-carousel", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class HeroCarouselModelImpl extends BaseComponentModelImpl
		implements com.tracfonecore.core.models.HeroCarouselModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(HeroCarouselModelImpl.class);
	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue
	@Default(values = "5")
	private String transitionDelay;

	private List<HeroCarouselSlideBean> slides = Collections.emptyList();
	// private String cssForCarouselBackground;

	@Inject
	private Resource resource;

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public List<HeroCarouselSlideBean> getSlides() {
		LOGGER.info("slides" + slides);
		return new ArrayList<>(slides);
	}

	@Override
	public String getTransitionDelay() {
		return transitionDelay.trim();
	}

	@PostConstruct
	protected void initModel() {
		super.initModel();

		// for adding Slider Properties

		try {
			slides = new ArrayList<HeroCarouselSlideBean>();
			Node currentNode = resource.adaptTo(Node.class);
			if (currentNode != null && currentNode.hasNode("slides")) {
				Node child = currentNode.getNode("slides");
				NodeIterator ni = child.getNodes();
				setMultiFieldItems(ni, slides);
			}
		} catch (RepositoryException re) {
			LOGGER.error("Repository Exception occurred while Hero Carousel  details {}", re);
		}

	}

	private void setMultiFieldItems(NodeIterator ni, List<HeroCarouselSlideBean> multiFieldData) {
		LOGGER.debug("Entering setMultiFieldItems method.");
		try {
			while (ni.hasNext()) {
				HeroCarouselSlideBean heroCarouselSlideBean = new HeroCarouselSlideBean();
				Node grandChild = (Node) ni.nextNode();
				String cssForSlideerBackground = "";

				if ((grandChild.hasProperty(ApplicationConstants.backgroundImageAlign))) {
					heroCarouselSlideBean.setBackgroundImageAlign(
							grandChild.getProperty(ApplicationConstants.backgroundImageAlign).getString().trim());
				}

				if ((grandChild.hasProperty(ApplicationConstants.slideHeading))) {
					heroCarouselSlideBean
							.setSlideHeading(grandChild.getProperty(ApplicationConstants.slideHeading).getString());
				}
				if ((grandChild.hasProperty(ApplicationConstants.slideCtaAlignment))) {
					heroCarouselSlideBean.setSlideCtaAlignment(
							grandChild.getProperty(ApplicationConstants.slideCtaAlignment).getString());
				}
				if ((grandChild.hasProperty(ApplicationConstants.slideSubHeading))) {
					heroCarouselSlideBean.setSlideSubHeading(
							grandChild.getProperty(ApplicationConstants.slideSubHeading).getString());
				}
				if ((grandChild.hasProperty(ApplicationConstants.backgroundImageForSlide))) {
					String imagePath = grandChild.getProperty(ApplicationConstants.backgroundImageForSlide).getString();
					
					heroCarouselSlideBean.setBackgroundImageForSlide(DynamicMediaUtils.changeMediaPathToDMPath(imagePath, request.getResourceResolver()));		
				}

				if ((grandChild.hasProperty(ApplicationConstants.backgroundImageAlt))) {
					heroCarouselSlideBean.setBackgroundImageAlt(
							grandChild.getProperty(ApplicationConstants.backgroundImageAlt).getString());
				}
				if ((grandChild.hasProperty(ApplicationConstants.tooltipLogo))) {
					heroCarouselSlideBean
							.setTooltipLogo(grandChild.getProperty(ApplicationConstants.tooltipLogo).getString());
				}
				if ((grandChild.hasProperty(ApplicationConstants.tooltipMsg))) {
					heroCarouselSlideBean
							.setTooltipMsg(grandChild.getProperty(ApplicationConstants.tooltipMsg).getString());
				}

				if ((grandChild.hasProperty(ApplicationConstants.sliderBgType))) {
					heroCarouselSlideBean
							.setSliderBgType(grandChild.getProperty(ApplicationConstants.sliderBgType).getString());
				}

				if ((grandChild.hasProperty(ApplicationConstants.sliderBackgroundColor))) {
					heroCarouselSlideBean
							.setSliderBackgroundColor(grandChild.getProperty(ApplicationConstants.sliderBackgroundColor).getString());
				}
				if ((grandChild.hasProperty(ApplicationConstants.sliderBackgroundImage))) {
					heroCarouselSlideBean
							.setSliderBackgroundImage(grandChild.getProperty(ApplicationConstants.sliderBackgroundImage).getString());
				}
				heroCarouselSlideBean.setCssForSlideerBackground(cssForSlideerBackground);

				multiFieldData.add(heroCarouselSlideBean);

			}
		} catch (RepositoryException re) {
			LOGGER.error("Repository Exception occurred while setting Hero Carousel multifield values {}", re);
		}
		LOGGER.debug("Exiting setMultiFieldItems method.");
	}

}
