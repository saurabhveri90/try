
package com.tracfonecore.core.models;

import java.util.Map;

import org.osgi.annotation.versioning.ProviderType;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

@ProviderType
public interface PlanDetailModel extends  ComponentExporter {
 	
	/**
	 * <p>
	 * Fetches the planNameDetail
	 * </p>
	 *
	 * @return String - planNameDetail
	 */
	@JsonProperty("planNameDetail")
	public String getPlanNameDetail();

	/**
	 * <p>
	 * Fetches the rewardsPurchaseLabel
	 * </p>
	 *
	 * @return String - rewardsPurchaseLabel
	 */
	@JsonProperty("rewardsPurchaseLabel")
	public String getRewardsPurchaseLabel();

	/**
	 * <p>
	 * Fetches the rewardsEarnLabel
	 * </p>
	 *
	 * @return String - rewardsEarnLabel
	 */
	@JsonProperty("rewardsEarnLabel")
	public String getRewardsEarnLabel();

	/**
	 * <p>
	 * Fetches the export child items
	 * </p>
	 *
	 * 
	 * @return Map<String, ? extends ComponentExporter> - the export child items
	 */
	public Map<String, ? extends ComponentExporter> getItems();

	/**
	 * <p>
	 * Method to return exporter type
	 * </p>
	 * 
	 * @return String
	 */
	public String getExportedType();
	
	/**
     * <p>
     * Fetches show timer option
     * </p>
     *
     * @return String - Show Timer
    */
   @JsonProperty("showTimer")
   public String getShowTimer();
   /**
	 * @return the productCardImage
	 */
	public String getProductCardImage();

	/**
	 * @return the termsCondModalLabel
	 */
	public String getTermsCondModalLabel();

	/**
	 * @return the termsCondModalId
	 */
	public String getTermsCondModalId();
	
	/**
	 * @return the useBazaarVoiceRatings
	 */
	public String getUseBazaarVoiceRatings();
	
	/**
	 * @return the selection
	 */
	public String getSelection();
	
	/**
	 * @return the useFullWidthEarnRewards
	 */
	public String getUseFullWidthEarnRewards();
	
	/**
	 * @return the planNameType
	 */
	@JsonProperty("planNameType")
	public String getPlanNameType();
	
}