package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.ACPMigrationModel;
import com.tracfonecore.core.models.KeyValuePairModel;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = {ACPMigrationModel.class,
        ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/acpmigration", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ACPMigrationModelImpl implements ACPMigrationModel {

    @Self
    private SlingHttpServletRequest request;

    @ChildResource
    private List<KeyValuePairModel> generalTextList;
    @ChildResource
    private List<KeyValuePairModel> generalRichTextList;

 

    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

    private List<KeyValuePairModel> getConstructList(List<KeyValuePairModel> textList, List<KeyValuePairModel> richTextList) {
        List<KeyValuePairModel> listText = Optional.ofNullable(textList)
                .map(List::stream).orElseGet(Stream::empty).collect(Collectors.toList());
        List<KeyValuePairModel> listRichText = Optional.ofNullable(richTextList)
                .map(List::stream).orElseGet(Stream::empty).collect(Collectors.toList());
        listText.addAll(listRichText);
        return new ArrayList<>(listText);
    }


    @Override
    public List<KeyValuePairModel> getGeneralList() {
        return getConstructList(generalTextList, generalRichTextList);
    }

}
