package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public interface AddFundsModel extends ComponentExporter {
    @JsonProperty("title")
    public String getTitle();

    @JsonProperty("description")
    public String getDescription();

    @JsonProperty("enableEstimateCall")
    public String getEnableEstimateCall();

    @JsonProperty("makePaymentChoiceLabel")
    public String getMakePaymentChoiceLabel();

    @JsonProperty("useCCLabel")
    public String getUseCCLabel();

    @JsonProperty("usePINLabel")
    public String getUsePINLabel();

    @JsonProperty("processPinPagePath")
    public String getProcessPinPagePath();

    @JsonProperty("addFundsInputMaxValue")
    public String getAddFundsInputMaxValue();
    @JsonProperty("addFundsInputMinValue")
    public String getAddFundsInputMinValue();

    @JsonProperty("enterAmountLabel")
    public String getEnterAmountLabel();

    @JsonProperty("addFundsBgImagePath")
    public String getAddFundsBgImagePath();

    @JsonProperty("addFundsBgImageAltText")
    public String getAddFundsBgImageAltText();

    @JsonProperty("addFundsBgMobileImagePath")
    public String getAddFundsBgMobileImagePath();

    @JsonProperty("addFundsBgColor")
    public String getAddFundsBgColor();
    @JsonProperty("addFundsThumbnailImage")
    public String getAddFundsThumbnailImage();

    @JsonProperty("sharedPlanPastDueDisclaimer")
    public String getSharedPlanPastDueDisclaimer();
    @JsonProperty("commonPastDueDisclaimer")
    public String getCommonPastDueDisclaimer();
    @JsonProperty("sharedPlanPastDueDisclaimerLoggedIn")
    public String getSharedPlanPastDueDisclaimerLoggedIn();

    @JsonProperty("authData")
    public List<KeyValuePairModel> getAuthData();
}
