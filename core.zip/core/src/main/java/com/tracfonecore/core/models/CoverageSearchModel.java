package com.tracfonecore.core.models;

import org.apache.sling.api.resource.Resource;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code CoverageSearch} Sling Model used for the {@code /apps/tracfone-core/components/content/coveragesearch} component.
 */
public interface CoverageSearchModel extends ComponentExporter {

	/**
	 * <p>Fetches new customer title</p>
	 * 
	 * @return String - New Customer Title
	 */
	@JsonProperty("newCustomerTitle")
	public String getNewCustomerTitle();

	/**
	 * <p>Fetches new customer link label</p>
	 * 
	 * @return String - New Customer Label
	 */
	@JsonProperty("newCustomerLabel")
	public String getNewCustomerLabel();	

	/**
	 * <p>Fetches existing customer title</p>
	 * 
	 * @return String - Existing Customer Title
	 */
	@JsonProperty("existingCustomerTitle")
	public String getExistingCustomerTitle();

	/**
	 * <p>Fetches existing customer link label</p>
	 * 
	 * @return String - Existing Customer Label
	 */
	@JsonProperty("existingCustomerLabel")
	public String getExistingCustomerLabel();

	/**
	 * <p>Fetches Coverage Map Page Path</p>
	 * 
	 * @return String - Coverage Map Page Path
	 */
	@JsonProperty("coverageMapPagePath")
	public String getCoverageMapPagePath();

}
