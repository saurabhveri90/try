package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.CarouselCardBean;
import com.tracfonecore.core.models.CardCarouselModel;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CardCarouselModel.class,
    ComponentExporter.class }, resourceType = "tracfone-core/components/content/cardcarousel", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
    @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
    @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CardCarouselModelImpl extends BaseComponentModelImpl implements CardCarouselModel {

    // Constants
    private static final String CAROUSEL_CARDS = "carouselCards";
    private static final String CARD_TITLE = "cardTitle";
	private static final String CARD_TEXT = "cardText";
	private static final String CARD_BACKGROUND_COLOR = "cardBackgroundColor";
	private static final String CARD_TEXT_COLOR = "cardTextColor";
    private static final String CARD_IMAGE = "cardImage";
	private static final String IMAGE_ALT_TEXT = "imageAltText";
	private static final String IMG_VERTICAL_ALIGN = "imgVerticalAlign";
    private static final String CARD_MOBILE_IMAGE = "cardMobileImage";
    private static final String TOOL_TIP_LOGO = "tooltipLogo";
    private static final String TOOL_TIP_MESSAGE = "tooltipMsg";
    private static final String DISABLE_BUTTON = "disableButton";


    @Self
	private SlingHttpServletRequest request;

    @Inject
	private Resource resource;

    @ValueMapValue
	private String carouselTitle;

	private List<CarouselCardBean> carouselCards = Collections.emptyList();

    @PostConstruct
	protected void initModel() {
        super.initModel();
		carouselCards = new ArrayList<CarouselCardBean>();
		for (Resource child : resource.getChildren()) {
			if(CAROUSEL_CARDS.equals(child.getName())) {
				Iterator<Resource> it = child.listChildren();
				setMultiFieldItems(it, carouselCards);
			}
		}
	}

    /**
     * <p>Populates a list with all the multi-links</p>
     *
     * @param it             - iterator of the parent node
     * @param multiFieldData - list in which the multi links data needs to be set
     */
    private void setMultiFieldItems(Iterator<Resource> it, List<CarouselCardBean> multiFieldData) {
        while (it.hasNext()) {
            CarouselCardBean carouselCardBean = new CarouselCardBean();
            Resource grandChild = it.next();
            carouselCardBean.setCardTitle(grandChild.getValueMap().get(CARD_TITLE, String.class));
            carouselCardBean.setCardText(grandChild.getValueMap().get(CARD_TEXT, String.class));
            carouselCardBean.setCardTextColor(grandChild.getValueMap().get(CARD_TEXT_COLOR, String.class));
            carouselCardBean.setCardBackgroundColor(grandChild.getValueMap().get(CARD_BACKGROUND_COLOR, String.class));
            carouselCardBean.setCardImage(DynamicMediaUtils.changeMediaPathToDMPath(grandChild.getValueMap().get(CARD_IMAGE, String.class), request.getResourceResolver()));
            carouselCardBean.setImageAltText(grandChild.getValueMap().get(IMAGE_ALT_TEXT, String.class));
            carouselCardBean.setImgVerticalAlign(grandChild.getValueMap().get(IMG_VERTICAL_ALIGN, String.class));
            carouselCardBean.setCardMobileImage(DynamicMediaUtils.changeMediaPathToDMPath(grandChild.getValueMap().get(CARD_MOBILE_IMAGE, String.class), request.getResourceResolver()));
            carouselCardBean.setTooltipLogo(grandChild.getValueMap().get(TOOL_TIP_LOGO, String.class));
            carouselCardBean.setTooltipMsg(grandChild.getValueMap().get(TOOL_TIP_MESSAGE, String.class));
            if(grandChild.getValueMap().get(DISABLE_BUTTON, Boolean.class) != null) {
                carouselCardBean.setDisableButton(grandChild.getValueMap().get(DISABLE_BUTTON, Boolean.class));
            }
            
            multiFieldData.add(carouselCardBean);
        }
    }

    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

    @Override
    public String getCarouselTitle() {
        return carouselTitle;
    }

    @Override
    public List<CarouselCardBean> getCarouselCards() {
        return new ArrayList<>(carouselCards);
    }

    @Override
    public boolean getEnableDesktopCarousel() {
        return carouselCards.size() > 3;
    }
    
}
