/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.utils.ApplicationUtil;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.SpinTheWheelModel;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { SpinTheWheelModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/content/spinthewheel", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class SpinTheWheelModelImpl implements SpinTheWheelModel {

	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String spinTheWheelTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String spinTheWheelSubTitle;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String spinTheWheelDescription;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String spinTheWheelImagePath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String spinTheWheelImageLink;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String spinTheWheelCTA;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean shouldIncludeMyAccountNav;
	
	@Override
	public String getSpinTheWheelTitle() {
		return spinTheWheelTitle;
	}

	@Override
	public String getSpinTheWheelSubTitle() {
		return spinTheWheelSubTitle;
	}

	@Override
	public String getSpinTheWheelDescription() {
		return spinTheWheelDescription;
	}

    @Override
	public String getSpinTheWheelImagePath() {
	     return DynamicMediaUtils.changeMediaPathToDMPath(spinTheWheelImagePath, request.getResourceResolver());
	}

	@Override
	public String getSpinTheWheelImageLink() {
		return spinTheWheelImageLink;
	}

    @Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getSpinTheWheelAssetId() {
		return ApplicationUtil.getAssetId(spinTheWheelImagePath,
				request.getResourceResolver(), ApplicationConstants.IMAGE);
	}

	@Override
	public String getSpinTheWheelAssetAgencyId() {
		return ApplicationUtil.getAssetMetaDataValue(spinTheWheelImagePath,
				request.getResourceResolver(), ApplicationConstants.WEBER_ID);
	}

	@Override
	public String getSpinTheWheelCTA() {
		return spinTheWheelCTA;
	}

	@Override
	public Boolean getShouldIncludeMyAccountNav() {
		return shouldIncludeMyAccountNav;
	}

}
