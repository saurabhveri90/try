package com.tracfonecore.core.config;


import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "PayPal Client ID Service", description = "Paths for PayPal Client ID are added here")
public @interface PayPalClientIDConfig {

     @AttributeDefinition(name = "Paypal SDK ClientId",description = "Paypal SDK ClientId", type = AttributeType.STRING)
     String[] getPaypalSdkClientId() default {"STRAIGHT_TALK:AashRA8xNtK6irahHJNyz5H3o8ehHGZP7kdrSUZB5kR7owZIYyyhb-pcE-2Sg0iYIp05P1ZTDZR_IC9r","TRACFONE:AXyh9GriN7nQS9s2DK92p-6uhDuWiBGpgVI6h-J7mIGA3cRxu1oOnB0KvSD5BTqtxC0UbIAZZWuq2W1a","TOTAL_WIRELESS:ARemzRi3qo30PvgnwT3Vhuik2o3ZOOThqWKOHSgGjZIN11ezo3YAYSe_KVUmjRCru8WoL07xFefHGjg1"};

}
