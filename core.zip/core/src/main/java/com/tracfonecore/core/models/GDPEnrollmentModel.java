package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public interface GDPEnrollmentModel  extends ComponentExporter {

    @JsonProperty("general")
    public List<KeyValuePairModel> getGeneralList();

    @JsonProperty("personal")
    public List<KeyValuePairModel> getPersonalList();

    @JsonProperty("eligibility")
    public List<KeyValuePairModel> getEligibilityList();

    @JsonProperty("deviceAndProgram")
    public List<KeyValuePairModel> getDeviceAndProgram();

    @JsonProperty("reviewAndComplete")
    public List<KeyValuePairModel> getReviewAndCompleteList();

    @JsonProperty("eligibilityProgramQualificationList")
    public List<ProgramQualificationModel> getEligibilityProgramQualificationList();
}
