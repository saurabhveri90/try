/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;


import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the model for Retrieve Order Number component
 */
public interface PlanStartDateModel extends ComponentExporter {

	
	/**
	 * <p>Title for Plan Start Date screen</p>
	 * 
	 * @return String - screenTitle
	 */
	@JsonProperty("screenTitle")
	public String getScreenTitle();

	/**
	 * <p>Heading for Plan Start Date screen.</p>
	 *
	 * @return String - screenHeading.
	 */
	@JsonProperty("screenHeading")
	public String getScreenHeading();
	
	/**
	 * <p>Description for Plan Start Date screen.</p>
	 *
	 * @return String - screenDescription.
	 */
	@JsonProperty("screenDescription")
	public String getScreenDescription();
	
	/**
	 * <p>Reserve Plan Text.</p>
	 *
	 * @return String - reservePlanText.
	 */
	@JsonProperty("reservePlanText")
	public String getReservePlanText();
	
	/**
	 * <p>Plan Expires Text.</p>
	 *
	 * @return String - planExpiresText.
	 */
	@JsonProperty("planExpiresText")
	public String getPlanExpiresText();
	
	/**
	 * <p>Start Today Text.</p>
	 *
	 * @return String - startToday.
	 */
	@JsonProperty("startToday")
	public String getStartToday();

	/**
	 * <p>Start Today Text.</p>
	 *
	 * @return String - startToday.
	 */
	@JsonProperty("startTodayWarning")
	public String getStartTodayWarning();
	
}
