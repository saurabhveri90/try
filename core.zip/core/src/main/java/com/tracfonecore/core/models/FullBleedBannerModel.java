package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.HeroCarouselSlideBean;

/**
 * Defines the {@code FullBleedBannerModel} Sling Model used for the {@code /apps/tracfone-core/components/content/FullBleedBannerModel} component.
 */
public interface FullBleedBannerModel extends ComponentExporter  {

	/**
	 * <p>Fetches label of the carousel</p>
	 *
	 * @return String - label of the carousel
	 */
	@JsonProperty("heading")
	public String  getHeading();

	@JsonProperty("headingTooltip")
	public String  getHeadingTooltip();

	@JsonProperty("subHeading")
	public String  getSubHeading();

	@JsonProperty("fullBleedImage")
	public String  getFullBleedImage();

	@JsonProperty("fullBleedImageMobile")
	public String  getFullBleedImageMobile();

	@JsonProperty("fullBleedImageTablet")
	public String  getFullBleedImageTablet();

	@JsonProperty("imageAlign")
	public String  getImageAlign();

	@JsonProperty("tooltipLogo")
	public String  getTooltipLogo();

	@JsonProperty("tooltipMsg")
	public String  getTooltipMsg();

	
	
	
	
}
