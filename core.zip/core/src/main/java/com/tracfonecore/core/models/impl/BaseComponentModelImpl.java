/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.models.BaseComponentModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.api.resource.Resource;

import java.util.Objects;

@Model(adaptables = { Resource.class, SlingHttpServletRequest.class }, adapters = {
		BaseComponentModel.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class BaseComponentModelImpl implements BaseComponentModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(BaseComponentModelImpl.class);

	private String rootBrandFolder;

	@Inject
	private Page currentPage;

	@Inject
	private ApplicationConfigService applicationConfigService;

	private String butterBarXFPath = StringUtils.EMPTY;

	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering initModel method");
		if (null != applicationConfigService) {
			rootBrandFolder = ConfigurationUtil.getConfigValue(applicationConfigService.getRootBrandFolder(),
					CommerceUtil.getBrandValue(currentPage, applicationConfigService.getHomePageLevel()));
			Object butterBarXf = CommerceUtil.getPagePropertyValue(currentPage, applicationConfigService.getHomePageLevel(), "butterBarLink");
			if(!Objects.isNull(butterBarXf)){
				butterBarXFPath = butterBarXf.toString();
			}

		}
		LOGGER.debug("Exiting initModel method");
	}

	/**
	 * <p>
	 * Fetches Root Brand Folder
	 * </p>
	 * 
	 * @return String -Root Brand Folder
	 */
	@Override
	public String getRootBrandFolder() {
		return rootBrandFolder;
	}

	/**
	 * <p>
	 * Fetches butterBarXFPath
	 * </p>
	 *
	 * @return String -butterBarXFPath
	 */
	@Override
	public String getButterBarXFPath() {
		return butterBarXFPath;
	}

}