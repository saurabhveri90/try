package com.tracfonecore.core.models.impl;

import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.services.ActivationFlowConfigService;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.ByopBundleModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.Map;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ByopBundleModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/byopbundle", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ByopBundleModelImpl implements ByopBundleModel {

	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue
	private String alertText;
	@ValueMapValue
	private String bundleDesc;
	@ValueMapValue
	private String cartBtnAccText;
	@ValueMapValue
	private String cartBtnLabel;
	@ValueMapValue
	private String cmpBtnAccText;
	@ValueMapValue
	private String cmpBtnLabel;
	@ValueMapValue
	private String descLS;
	@ValueMapValue
	private String headingCS;
	@ValueMapValue
	private String headingDesc;
	@ValueMapValue
	private String headingHS;
	@ValueMapValue
	private String headingPart1;
	@ValueMapValue
	private String headingPart2;
	@ValueMapValue
	private String headingQRFlow;
	@ValueMapValue
	private String headingSucSrn;
	@ValueMapValue
	private String imgLS;
	@ValueMapValue
	private String nextSteps;
	@ValueMapValue
	private String ptIMEI;
	@ValueMapValue
	private String ptZipCode;
	@ValueMapValue
	private String stepsSummary;
	@ValueMapValue
	private String subHeadingCS;
	@ValueMapValue
	private String subHeadingHS;
	@ValueMapValue
	private String subHeadingSucSrn;
	@ValueMapValue
	private String summaryIMEI;
	@ValueMapValue
	private String summaryZipCode;
	@ValueMapValue
	private String planPLPLink;
	@ValueMapValue
	private String offerPopupLabel;
	@ValueMapValue
	private String offerPopupModalId;
	@ValueMapValue
	private String imeiPopupLabel;
	@ValueMapValue
	private String imeiPopupModalId;
	@ValueMapValue
	private String flowType;
	@ValueMapValue
	private String planThmbImg;
	@ValueMapValue
	private String simThmbImg;
	@ValueMapValue
	private String eSimSubHeading;
	@ValueMapValue
	private String eSimHeading;
	@ValueMapValue
	private String eSimNxtStepsHeading;
	@ValueMapValue
	private String eSimDesc;
	@ValueMapValue
	private String eSimNxtSteps;
	@ValueMapValue
	private String faqxf;
	@ValueMapValue
	private String headingDeviceUncompatible;
	@ValueMapValue
	private String headingExistingUser;
	@ValueMapValue
	private String headingTechnicalDiff;
	@ValueMapValue
	private String headingPhoneUneligible;

	@ValueMapValue
	private String headingErrorZipCoverage;

	@ValueMapValue
	private String uncompatibleXfPath;

	@ValueMapValue
	private String unEligibleXfPath;

	@ValueMapValue
	private String zipErrorXfPath;

	@ValueMapValue
	private String activeUserXfPath;

	@ValueMapValue
	private String genericErrorXfPath;

	@ValueMapValue
	@Default(intValues = 10)
	private int apiRetryCount;

	@ValueMapValue
	private String enbTxtCmpBtn;
	@ValueMapValue
	private String disTxtCmpBtn;
	@ValueMapValue
	private String enbTxtCartBtn;

	@ValueMapValue
	private String activationPageURL;

	@ValueMapValue
	private String imeiPopupAriaLabel;

	@ValueMapValue
	private String offerPopupAriaLabel;

	@ValueMapValue
	private String headingIS;

	@ValueMapValue
	private String imgPsim;
	@ValueMapValue
	private String imgLandPage;

	@ValueMapValue
	private String nxtStepsDiffChnl;

	@ValueMapValue
	private String anotherPhoneBtnLabel;
	@ValueMapValue
	private String enbTxtAnotherPhoneBtn;
	@ValueMapValue
	private String dualSimBodyHeading;
	@ValueMapValue
	private String dualSimdiffTxt;
	@ValueMapValue
	private String diffPopupModalId;
	@ValueMapValue
	private String diffPopupAriaLabel;
	@ValueMapValue
	private String dualSimNxtSteps;
	@ValueMapValue
	private String eSIMBtnLabel;
	@ValueMapValue
	private String eSIMEnbTxtBtn;
	@ValueMapValue
	private String eSIMDisTxtBtn;
	@ValueMapValue
	private String pSIMBtnLabel;
	@ValueMapValue
	private String pSIMEnbTxtBtn;
	@ValueMapValue
	private String pSIMDisTxtBtn;

	@ValueMapValue
	private String dualSimMainHeading;
	@ValueMapValue
	private String dualSimMainSubHeading;
	@ValueMapValue
	private String eSIMScrnBtnLabel;
	@ValueMapValue
	private String eSIMScrnEnbTxtBtn;

	private ResourceResolver resourceResolver;
	private String categoryId;
	private String deviceTypeParam;
	private String language;
	private String brand;
	private Map<String, Object> propertyValueMap;

	private static final Logger LOGGER = LoggerFactory.getLogger(ByopBundleModelImpl.class);

	@Inject
	private Page currentPage;

	@Inject
	private TracfoneApiGatewayService tracfoneApiService;

	@Inject
	private ApplicationConfigService applicationConfigService;

	@Inject
	private ActivationFlowConfigService activationFlowConfigService;

	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering initModel method");

		String[] properties = { CommerceConstants.BRANDNAME };
		this.propertyValueMap = CommerceUtil.getMultiplePagePropertyValue(currentPage, getHomePageLevel(), properties);

		this.brand = CommerceUtil.getPropertyValue(this.propertyValueMap, CommerceConstants.BRANDNAME);
		resourceResolver = request.getResourceResolver();
		this.language = CommerceUtil.getLanguage(currentPage, getHomePageLevel());
		Resource plpPageResource = resourceResolver.getResource(planPLPLink);
		if (plpPageResource != null) {
			Page plpPage = plpPageResource.adaptTo(Page.class);
			if (plpPage != null) {
				ValueMap plpVm = plpPage.getContentResource().getValueMap();
				categoryId = plpVm.get("categoryId", String.class);
				String categoryType = plpVm.get(CommerceConstants.CATEGORY_TYPE, String.class);
				String subCategoryType = plpVm.get(CommerceConstants.SUB_CATEGORY_TYPE, String.class);
				deviceTypeParam = ApplicationUtil.getDeviceTypeForParam(categoryType,
						ConfigurationUtil.getConfigValue(applicationConfigService.getDeviceTypeParam(),
								CommerceUtil.getBrandValue(currentPage, getHomePageLevel())),
						subCategoryType);

			}
		}
	}

	public String getTrimmHeaderCheck() {
		String trimHeaderCheck = "false";
		String pagePath = currentPage.getPath();
		Resource currPageResource = resourceResolver.getResource(pagePath);
		if (currPageResource != null) {
			Page currPage = currPageResource.adaptTo(Page.class);
			if (currPage != null) {
				ValueMap currPageVm = currPage.getContentResource().getValueMap();
				trimHeaderCheck = currPageVm.get("isTrimmedHeader", String.class);

			}
		}
		return trimHeaderCheck;
	}

	public String getTrimFooterCheck() {
		String trimFooterCheck = "false";
		String pagePath = currentPage.getPath();
		Resource currPageResource = resourceResolver.getResource(pagePath);
		if (currPageResource != null) {
			Page currPage = currPageResource.adaptTo(Page.class);
			if (currPage != null) {
				ValueMap currPageVm = currPage.getContentResource().getValueMap();
				trimFooterCheck = currPageVm.get("isTrimmedFooter", String.class);
			}
		}
		return trimFooterCheck;
	}

	/**
	 * @return the categoryId
	 */
	@Override
	public String getCategoryId() {
		return categoryId;
	}

	/**
	 * @return the deviceTypeParam
	 */
	@Override
	public String getDeviceTypeParam() {
		return deviceTypeParam;
	}

	/**
	 * @return the query
	 */
	@Override
	public String getQueryString() {
		StringBuilder query = new StringBuilder("searchKeyword=*").append(CommerceConstants.AMPERSAND)
				.append(CommerceConstants.CATEGORY_ID).append(CommerceConstants.EQUALS_TO).append(this.getCategoryId())
				.append(CommerceConstants.AMPERSAND).append("facet=(").append(getByopFacetValue())
				.append(")");
		return query.toString();
	}

	/**
	 * @return the byopFacetValue
	 */
	public String getByopFacetValue() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getByop25TrueFacet(), this.brand);
	}

	/**
	 * @return the clientID
	 */
	@Override
	public String getClientID() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getApiClientId(), brand);
	}

	/**
	 * @return the flowType
	 */
	@Override
	public String getFlowType() {
		return flowType;
	}

	/**
	 * @return the offerPopupLabel
	 */
	@Override
	public String getOfferModalId() {
		return offerPopupLabel;
	}

	/**
	 * @return the offerPopupModalId
	 */
	@Override
	public String getOfferLinkLabel() {
		return offerPopupModalId;
	}

	/**
	 * @return the imeiPopupLabel
	 */
	@Override
	public String getImeiModalId() {
		return imeiPopupLabel;
	}

	/**
	 * @return the imeiPopupModalId
	 */
	@Override
	public String getImeiLinkLabel() {
		return imeiPopupModalId;
	}

	/**
	 * @return the homePageLevel
	 */
	@Override
	public int getHomePageLevel() {
		return applicationConfigService.getHomePageLevel();
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * @return the alertText
	 */
	@Override
	public String getAlertText() {
		return alertText;
	}

	/**
	 * @return the bundleDesc
	 */
	@Override
	public String getBundleDesc() {
		return bundleDesc;
	}

	/**
	 * @return the cartBtnAccText
	 */
	@Override
	public String getCartBtnAccText() {
		return cartBtnAccText;
	}

	/**
	 * @return the cartBtnLabel
	 */
	@Override
	public String getCartBtnLabel() {
		return cartBtnLabel;
	}

	/**
	 * @return the cmpBtnAccText
	 */
	@Override
	public String getCmpBtnAccText() {
		return cmpBtnAccText;
	}

	/**
	 * @return the cmpBtnLabel
	 */
	@Override
	public String getCmpBtnLabel() {
		return cmpBtnLabel;
	}

	/**
	 * @return the descLS
	 */
	@Override
	public String getDescLS() {
		return descLS;
	}

	/**
	 * @return the headingCS
	 */
	@Override
	public String getHeadingCS() {
		return headingCS;
	}

	/**
	 * @return the headingDesc
	 */
	@Override
	public String getHeadingDesc() {
		return headingDesc;
	}

	/**
	 * @return the headingHS
	 */
	@Override
	public String getHeadingHS() {
		return headingHS;
	}

	/**
	 * @return the headingPart1
	 */
	@Override
	public String getHeadingPart1() {
		return headingPart1;
	}

	/**
	 * @return the headingPart2
	 */
	@Override
	public String getHeadingPart2() {
		return headingPart2;
	}

	/**
	 * @return the headingQRFlow
	 */
	@Override
	public String getHeadingQRFlow() {
		return headingQRFlow;
	}

	/**
	 * @return the headingSucSrn
	 */
	@Override
	public String getHeadingSucSrn() {
		return headingSucSrn;
	}

	/**
	 * @return the imgLS
	 */
	@Override
	public String getImgLS() {
		return imgLS;
	}

	/**
	 * @return the nextSteps
	 */
	@Override
	public String getNextSteps() {
		return nextSteps;
	}

	/**
	 * @return the ptIMEI
	 */
	@Override
	public String getPtIMEI() {
		return ptIMEI;
	}

	/**
	 * @return the ptZipCode
	 */
	@Override
	public String getPtZipCode() {
		return ptZipCode;
	}

	/**
	 * @return the stepsSummary
	 */
	@Override
	public String getStepsSummary() {
		return stepsSummary;
	}

	/**
	 * @return the subHeadingCS
	 */
	@Override
	public String getSubHeadingCS() {
		return subHeadingCS;
	}

	/**
	 * @return the subHeadingHS
	 */
	@Override
	public String getSubHeadingHS() {
		return subHeadingHS;
	}

	/**
	 * @return the subHeadingSucSrn
	 */
	@Override
	public String getSubHeadingSucSrn() {
		return subHeadingSucSrn;
	}

	/**
	 * @return the summaryIMEI
	 */
	@Override
	public String getSummaryIMEI() {
		return summaryIMEI;
	}

	/**
	 * @return the summaryZipCode
	 */
	@Override
	public String getSummaryZipCode() {
		return summaryZipCode;
	}

	/**
	 * @return the planThumbnailImage
	 */
	@Override
	public String getPlanThumbnailImage() {
		return planThmbImg;
	}

	/**
	 * @return the simThumbnailImage
	 */
	@Override
	public String getSimThumbnailImage() {
		return simThmbImg;
	}
	/**
	 * <p>
	 * Fetches skipPlanType property from config
	 * </p>
	 *
	 * @return String[] - skipPlanType
	 */
	@Override
	public String getSkipPlanType() {
		return applicationConfigService.noPlanCheck();
	}

	/**
	 * @return the eSimSubHeading
	 */

	public String getESimHeading() {
		return eSimHeading;
	}

	/**
	 * @return the eSimSubHeading
	 */
	public String getESimSubHeading() {
		return eSimSubHeading;
	}

	/**
	 * @return the eSimNxtStepsHeading
	 */
	public String getESimNxtStepsHeading() {
		return eSimNxtStepsHeading;
	}

	/**
	 * @return the eSimNxtSteps
	 */
	public String getESimNxtSteps() {
		return eSimNxtSteps;
	}

	/**
	 * @return the eSimDesc
	 */
	public String getESimDesc() {
		return eSimDesc;
	}

	/**
	 * @return the faqxf
	 */
	public String getFaqxf() {
		return faqxf;
	}

	@Override
	public String getUncompatibleXfPath() {
		return uncompatibleXfPath;
	}

	@Override
	public String getUnEligibleXfPath() {
		return unEligibleXfPath;
	}

	@Override
	public String getZipErrorXfPath() {
		return zipErrorXfPath;
	}

	@Override
	public String getActiveUserXfPath() {
		return activeUserXfPath;
	}

	@Override
	public String getGenericErrorXfPath() {
		return genericErrorXfPath;
	}

	@Override
	public int getCompatibleApiRetryCount() {
		return apiRetryCount;
	}

	@Override
	public String getEnbTxtCmpBtn() {
		return enbTxtCmpBtn;
	}

	@Override
	public String getDisTxtCmpBtn() {
		return disTxtCmpBtn;
	}

	@Override
	public String getEnbTxtCartBtn() {
		return enbTxtCartBtn;
	}

	@Override
	public String getActivationPageURL() {
		return activationPageURL;
	}

	@Override
	public String getOfferPopupAriaLabel() {
		return offerPopupAriaLabel;
	}

	@Override
	public String getImeiPopupAriaLabel() {
		return imeiPopupAriaLabel;
	}

	/**
	 * <p>
	 * Returns true or false from root page page properties
	 * </p>
	 *
	 * @return String - disablePromoEligibility
	 */
	@Override
	public String getDisablePromoEligibility() {
		return CommerceUtil.getPropertiesFromRootPage(currentPage, CommerceConstants.DISABLE_PROMO_ELIGIBILITY_CALL);
	}

	@Override
	public String getHeadingIS() {
		return headingIS;
	}

	/**
	 * @return String - MarketingIdApiPath
	 */
	public String getMarketingIdApiPath() {
		return tracfoneApiService.getMarketingApiPath();
	}

	/**
	 * <p>
	 * This method is used to generate query string for marketing id call
	 *
	 * @return -String : Query String
	 */
	public String getMarketIdQueryString() {

		StringBuilder query = new StringBuilder(CommerceConstants.BRANDNAME).append(CommerceConstants.EQUALS_TO)
				.append(CommerceUtil.getBrandValue(currentPage, getHomePageLevel())).append(CommerceConstants.AMPERSAND)
				.append(CommerceConstants.SOURCE_SYSTEM).append(CommerceConstants.EQUALS_TO)
				.append(CommerceConstants.WEB).append(CommerceConstants.AMPERSAND)
				.append(CommerceConstants.ZIP_CODE).append(CommerceConstants.EQUALS_TO);

		LOGGER.info(" abc *** " + query.toString());
		return query.toString();
	}

	@Override
	public String getImgPsim() {
		return imgPsim;
	}

	@Override
	public String getImgLandPage() {
		return imgLandPage;
	}

	@Override
	public String getNxtStepsDiffChnl() {
		return nxtStepsDiffChnl;
	}

	/**
	 * @return the headingDeviceUncompatible
	 */
	public String getHeadingDeviceUncompatible() {
		return headingDeviceUncompatible;
	}

	/**
	 * @return the headingExistingUser
	 */
	public String getHeadingExistingUser() {
		return headingExistingUser;
	}

	/**
	 * @return the headingTechnicalDiff
	 */
	public String getHeadingTechnicalDiff() {
		return headingTechnicalDiff;
	}

	/**
	 * @return the headingphoneUneligible
	 */
	public String getHeadingPhoneUneligible() {
		return headingPhoneUneligible;
	}

	/**
	 * @return the headingErrorZipCoverage
	 */
	public String getHeadingErrorZipCoverage() {
		return headingErrorZipCoverage;
	}

	/**
	 * @return the anotherPhoneBtnLabel
	 */
	@Override
	public String getAnotherPhoneBtnLabel(){
		return anotherPhoneBtnLabel;
	}

	/**
	 * @return the enbTxtAnotherPhoneBtn
	 */
	@Override
	public String getEnbTxtAnotherPhoneBtn(){
		return enbTxtAnotherPhoneBtn;
	}

	/**
	 * @return the dualSimBodyHeading
	 */
	@Override
	public String getDualSimBodyHeading(){
		return dualSimBodyHeading;
	}

	/**
	 * @return the dualSimdiffTxt
	 */
	@Override
	public String getDualSimdiffTxt(){
		return dualSimdiffTxt;
	}

	/**
	 * @return the diffPopupModalId
	 */
	@Override
	public String getDiffPopupModalId(){
		return diffPopupModalId;
	}

	/**
	 * @return the diffPopupAriaLabel
	 */
	@Override
	public String getDiffPopupAriaLabel(){
		return diffPopupAriaLabel;
	}

	/**
	 * @return the dualSimNxtSteps
	 */
	@Override
	public String getDualSimNxtSteps(){
		return dualSimNxtSteps;
	}

	/**
	 * @return the eSIMBtnLabel
	 */
	@Override
	public String getESIMBtnLabel(){
		return eSIMBtnLabel;
	}

	/**
	 * @return the eSIMEnbTxtBtn
	 */
	@Override
	public String getESIMEnbTxtBtn(){
		return eSIMEnbTxtBtn;
	}

	/**
	 * @return the eSIMDisTxtBtn
	 */
	@Override
	public String getESIMDisTxtBtn(){
		return eSIMDisTxtBtn;
	}

	/**
	 * @return the pSIMBtnLabel
	 */
	@Override
	public String getPSIMBtnLabel(){
		return pSIMBtnLabel;
	}

	/**
	 * @return the pSIMEnbTxtBtn
	 */
	@Override
	public String getPSIMEnbTxtBtn(){
		return pSIMEnbTxtBtn;
	}

	/**
	 * @return the pSIMDisTxtBtn
	 */
	@Override
	public String getPSIMDisTxtBtn(){
		return pSIMDisTxtBtn;
	}

	/**
	 * @return the dualSimMainHeading
	 */
	public String getDualSimMainHeading(){
		return dualSimMainHeading;
	}

	/**
	 * @return the dualSimMainSubHeading
	 */
	public String getDualSimMainSubHeading(){
		return dualSimMainSubHeading;
	}

	/**
	 * @return the eSIMScrnEnbTxtBtn
	 */
	public String getESIMScrnBtnLabel(){
		return eSIMScrnBtnLabel;
	}

	/**
	 * @return the eSIMScrnEnbTxtBtn
	 */
	public String getESIMScrnEnbTxtBtn(){
		return eSIMScrnEnbTxtBtn;
	}
}