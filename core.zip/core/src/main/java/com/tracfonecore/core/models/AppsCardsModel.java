/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;


import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.AppsCardsBean;

public interface AppsCardsModel extends ComponentExporter {
	
	@JsonProperty("positionAppsCards")
	public String getPositionAppsCards();
	
	@JsonProperty("positionAccountNavigation")
	public String getPositionAccountNavigation();
	
	@JsonProperty("appsSummaryText")
	public String getAppsSummaryText() ;

	@JsonProperty("appsLegalCopy")
	public String getAppsLegalCopy();
	
	@JsonProperty("appsCards")
	public List<AppsCardsBean> getAppsCards();

}
