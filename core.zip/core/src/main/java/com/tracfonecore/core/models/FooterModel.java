/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;


import java.util.Map;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Header} Sling Model used for the {@code /apps/tracfone-core/components/structure/footer} component.
 */
public interface FooterModel extends ComponentExporter {
	
	@JsonProperty("logo")
	public String getFileReference() ;

	@JsonProperty("altText")
	public String getAltText();
	
 /**
 * <p> Fetches the export child items</p>
 *
 * 
 * @return Map<String, ? extends ComponentExporter> - the export child items
 */
public Map<String, ? extends ComponentExporter> getItems();

	
}
