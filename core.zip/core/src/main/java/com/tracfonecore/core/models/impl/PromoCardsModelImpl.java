package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.tracfonecore.core.utils.ApplicationUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.PromoCardsBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.PromoCardsModel;
import com.tracfonecore.core.utils.DynamicMediaUtils;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { PromoCardsModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/content/promocards", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class PromoCardsModelImpl implements PromoCardsModel {

	@Self
	private SlingHttpServletRequest request;

	@ScriptVariable
	private ValueMap properties;

	@Inject
	private Resource resource;

	private List<PromoCardsBean> promoCards = Collections.emptyList();

	@PostConstruct
	private void initModel() {
		promoCards = new ArrayList<>();
		if (resource != null) {
			getMultifieldResource();
		}
	}
	
	private void getMultifieldResource() {
		for (Resource child : resource.getChildren()) {
			Iterator<Resource> it = child.listChildren();
			if (StringUtils.isNotBlank(child.getName())
					&& ApplicationConstants.PROMO_CARDS.equals(child.getName())) {
				setPromoCards(it);
			} 
		}
	}

	private void setPromoCards(Iterator<Resource> it) {
		while (it.hasNext()) {
			PromoCardsBean promoCardsBean = new PromoCardsBean();
			Resource child = it.next();
			promoCardsBean.setHeadlineText(
					child.getValueMap().get("headlineText", String.class));
			promoCardsBean.setSubHeadlineText(
					child.getValueMap().get("subHeadlineText", String.class));
			promoCardsBean.setPromoCardImageAltText(
					child.getValueMap().get("promoCardImageAltText", String.class));
			promoCardsBean.setPromoCardImage(
					DynamicMediaUtils.changeMediaPathToDMPath(child.getValueMap().get("promoCardImage", String.class), request.getResourceResolver()));
			promoCardsBean.setPromoCardCtaText(
					child.getValueMap().get("promoCardCtaText", String.class));
			promoCardsBean.setPromoCardCtaLink(
					child.getValueMap().get("promoCardCtaLink", String.class));
			promoCardsBean.setPromoCardTextColor(
					child.getValueMap().get("promoCardTextColor", String.class));
			promoCardsBean.setPromoCardBgColor(
					child.getValueMap().get("promoCardBgColor", String.class));
			promoCardsBean.setPromoCardButtonClassName(
					child.getValueMap().get("promoCardButtonClassName", String.class));
			promoCardsBean.setPromoCardTextHeadingColor(
					child.getValueMap().get("promoCardTextHeadingColor", String.class));
			promoCardsBean.setPromoCardTextSubHeadingColor(
					child.getValueMap().get("promoCardTextSubHeadingColor", String.class));
			promoCardsBean.setPromoCardImageAssetId(ApplicationUtil.getAssetId(child.getValueMap().get("promoCardImage",String.class),
					request.getResourceResolver(), ApplicationConstants.IMAGE));
			promoCardsBean.setPromoCardImageAssetAgencyId(ApplicationUtil.getAssetMetaDataValue(child.getValueMap().get("promoCardImage",String.class),
					request.getResourceResolver(), ApplicationConstants.IMAGE));
			
			
			promoCards.add(promoCardsBean);
		}
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public List<PromoCardsBean> getPromoCards() {
		return new ArrayList<>(promoCards);
	}

}
