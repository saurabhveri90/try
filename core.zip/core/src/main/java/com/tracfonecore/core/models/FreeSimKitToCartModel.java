package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

public interface FreeSimKitToCartModel extends ComponentExporter {
	
	/**
	 * @return subheading
	 */
	@JsonProperty("getSubheading")
	public String getSubheading();

    /**
     * Get the input Field Placeholder
     * @return String - inputFieldPlaceholder
     */
    @JsonProperty("getInputFieldPlaceholder")
    public String getInputFieldPlaceholder();  

    /**
	 * @return summary
	 */
	@JsonProperty("summary")
	public String getSummary();

    /**
     * Get the button Label
     * @return String - buttonLabel
     */
    @JsonProperty("buttonLabel")
    public String getButtonLabel();

    /**
	 * @return ctaText
	 */
    @JsonProperty("ctaText")
    public String getCtaText();

    /**
	 * @return ctaLink
	 */
    @JsonProperty("ctaLink")
    public String getCtaLink();

    /**
	 * <p>
	 * Fetches ReCaptcha SiteKey property from config
	 * </p>
	 *
	 * @return String[] - reCaptchaSiteKey
	 */
	public String getReCaptchaSiteKey();

    /**
	 * <p>
	 * Fetches hide recaptcha box
	 * </p>
	 *
	 * @return String - hide recaptcha
	 */
	@JsonProperty("hideRecaptchaBox")
	public String getHideRecaptchaBox();
	
}
