package com.tracfonecore.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Tracfone Core Yext Search Config Service",description = "Configurations for YEXT Search for TF Brands")
public @interface YextSearchConfig {

    @AttributeDefinition(name = "Yext Search Api Engine Key",description = "Engine Key for Search Api", type = AttributeType.STRING)
    String[] getYextApiKey() default{"STRAIGHT_TALK:e15fd7ab26d7b1f17833a3990a1c0aaf","TRACFONE:e15fd7ab26d7b1f17833a3990a1c0aaf","TOTAL_WIRELESS:e15fd7ab26d7b1f17833a3990a1c0aaf"};

    @AttributeDefinition(name = "Experience Key ",description = "Experience Key", type = AttributeType.STRING)
    String[] getExperienceKey() default{"STRAIGHT_TALK:en:straight-talk-answers","STRAIGHT_TALK:es:straight-talk-search-spanish","TRACFONE:en:tracfone-answers","TRACFONE:es:tracfone-search-spanish","TOTAL_WIRELESS:en:totalwirelessanswers","TOTAL_WIRELESS:es:tbv-search-spanish"};

    @AttributeDefinition(name = "Experience Version",description = "Experience Version for the environment", type = AttributeType.STRING)
    String[] getExperienceVersion() default{"STRAIGHT_TALK:en:PRODUCTION","STRAIGHT_TALK:es:v1.29.0","TRACFONE:en:PRODUCTION","TRACFONE:es:v1.29.0","TOTAL_WIRELESS:en:PRODUCTION","TOTAL_WIRELESS:es:v1.29.0"};

    @AttributeDefinition(name = "Business ID",description = "Provide the business id here", type = AttributeType.STRING)
    String[] getBusinessId() default{"STRAIGHT_TALK:1197005","TRACFONE:1197005","TOTAL_WIRELESS:1197005"};

    @AttributeDefinition(name = "Search Results IFRAME Url",description = "Provide Iframe Yext answers URL based on the brand", type = AttributeType.STRING)
    String[] getSearchResultsIframeURL() default{"STRAIGHT_TALK:https://answers.straighttalk.pagescdn.com/iframe.js","TRACFONE:https://answers.tracfone.pagescdn.com/iframe.js","TOTAL_WIRELESS:https://answers-totalwireless.pagescdn.com/iframe.js"};

    @AttributeDefinition(name = "Yext Search bar JS Url",description = "Yext Search bar JS Url", type = AttributeType.STRING)
    String getYextSearchBarScriptUrl() default "https://assets.sitescdn.net/answers-search-bar/v1.0/answers.min.js";
    
    @AttributeDefinition(name = "Yext Answers template JS Url",description = "Yext Amswers template JS Url", type = AttributeType.STRING)
    String getYextAnswersTemplateUrl() default "https://assets.sitescdn.net/answers-search-bar/v1.0/answerstemplates-iife.compiled.min.js";

    @AttributeDefinition(name = "Yext Search bar CSS Url",description = "Yext Search bar CSS Url", type = AttributeType.STRING)
    String getYextSearchBarCssUrl() default "https://assets.sitescdn.net/answers-search-bar/v1.0/answers.css";


}