/*
 *  Copyright 2020 HCL Technologies Ltd.
 *
 */
package com.tracfonecore.core.models.impl.v2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.RequestAttribute;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.tracfonecore.core.beans.PhoneSpecsBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.PlanCardModel;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;


@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { PlanCardModel.class,
		ComponentExporter.class }, resourceType = {
				PlanCardModelImpl.RESOURCE_TYPE_V2 }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class PlanCardModelImpl extends com.tracfonecore.core.models.impl.v1.PlanCardModelImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(PlanCardModelImpl.class);

	// constants
	protected static final String RESOURCE_TYPE_V2 = "tracfone-core/components/commerce/plancard/v2/plancard";
	protected static final String PLAN_NAME_DETAIL = "planNameDetail";
	private static final String N = "n";
	private static final String Y = "y";

	@Self
	private SlingHttpServletRequest request;

	@RequestAttribute
	private String multilineplan;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String planServiceDaysLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String serviceDaysPopoverText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ctaLink;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private  Boolean hideAutoRefillTextUnderPrice;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String alternateDataUnitForPlanCard;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Default(values = "false")
	private  String multilinePlanSelection;

	private String planText;

	private String planServiceDaysApi;

	private String planEarnPoints;

	private String planPurchasePoints;

	private String data;

	private String minutes;

	private String planDeviceType;

	private String planMinutesLabel;

	private String planTextLabel;

	private String planDataLabel;

	private Map<String, String> singleBucketSpecsMap = Collections.emptyMap();

	private List<String> multiplierList = Collections.emptyList();

	private List<String> multiplierUnitList = Collections.emptyList();

	private Map<String, PhoneSpecsBean> specsConfig = Collections.emptyMap();

	private List<PhoneSpecsBean> singleBucketSpecsList = Collections.emptyList();

	private List<String> singleBucketList = Collections.emptyList();
	
	private String planType;
	private String productType;
	private String productCardHeading;
	private String productCardDescription;
	private String servicePlanGroup;

	private String benefitsCarryForward = ApplicationConstants.FALSE;
	private String globalCardDescription;
	private String globalCardTitle;

	private String thresholdLabel;
	private String thresholdUnit;
	private String singleBucketThresholdValue;
	private String singleBucketThresholdUnit;
	
	private String voiceCarryForwardDescription;
	private String textCarryForwardDescription;
	private String dataCarryForwardDescription;
	protected String billingPlanType;
	protected String taxInclusive;

	private String hotspotText = null; 
	private String capableText = null; 

	/**
	 * <p>
	 * Init method : Calls the product api with part number authored and sets plan
	 * data in product field.
	 * </p>
	 *
	 */
	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering init method of V2 PlanCardModelImpl");
		
		multiplierList = new ArrayList<String>();
		multiplierUnitList = new ArrayList<String>();
		specsConfig = new LinkedHashMap<String, PhoneSpecsBean>();
		singleBucketSpecsMap = new HashMap<String, String>();
		singleBucketSpecsList = new ArrayList<PhoneSpecsBean>();
		singleBucketList = new ArrayList<String>();
		globalCardTitle = getPlanNameValue();
		try {
			if (StringUtils.isNotEmpty(type) && StringUtils.equalsIgnoreCase("dynamic", type)
					&& StringUtils.isNotEmpty(pdpPagePath)) {
				ctaLink = pdpPagePath;	
				Resource planCardResource = request.getResource().getResourceResolver()
						.getResource(pdpPagePath + CommerceConstants.PLAN_DETAIL_NODE_PATH);			
				if (StringUtils.isNotEmpty(multilineplan) && StringUtils.equalsIgnoreCase("true", multilineplan)) {
					if (currentPage == null && resource != null) {
						currentPage = resource.getResourceResolver().adaptTo(PageManager.class)
								.getContainingPage(resource);
					}
					thresholdLabel = (String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
							CommerceConstants.THRESHOLD_LABEL);
					thresholdUnit = (String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
							CommerceConstants.THRESHOLD_UNIT);
					planType = currentPage.getProperties().get("planType", String.class);
					setMultiplierList();
					singleBucketList = setSingleBucketIdetifiers();
					fetchPagePropertiesData();
					getSKUDetails();
					setUnitValues();
					setSingleBucketData(singleBucketSpecsMap, resource);
					if(null!= planCardResource){
						selection=planCardResource.getValueMap().get("selection", String.class);						
					}
				}else{
				if(null!= planCardResource)
					planCardModel = planCardResource.adaptTo(PlanCardModel.class);
				}

			} else {
				super.initModel();
				/*
				 * If the current page is null for any reason then find the currentPage for the
				 * resource's containing page.
				 */
				if (currentPage == null && resource != null) {
					currentPage = resource.getResourceResolver().adaptTo(PageManager.class)
							.getContainingPage(resource);
				}
				thresholdLabel = (String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
						CommerceConstants.THRESHOLD_LABEL);
				thresholdUnit = (String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
						CommerceConstants.THRESHOLD_UNIT);
				planType = currentPage.getProperties().get("planType", String.class);
				setMultiplierList();
				singleBucketList = setSingleBucketIdetifiers();
				getProductCharacteristics();
				fetchPagePropertiesData();
				getSKUDetails();
				setUnitValues();
				setSingleBucketData(singleBucketSpecsMap, resource);	
							
				LOGGER.debug("Exiting init method of V2 PlanCardModelImpl");
		}
		} catch (RuntimeException re) {
			LOGGER.error("Product Offering API not available for resource", re);
		}
	}

	/**
	 * <p>
	 * Returns planType from current page properties
	 * </p>
	 *
	 * @return String - planType
	 */
	public String getPlanType() {
		return planType;
	}

	/**
	 * <p>
	 * Returns product type from current page properties
	 * </p>
	 * 
	 * @return String - productType
	 */
	@Override
	public String getProductType() {
		return productType;
	}

	/**
	 * <p>
	 * Sets value from page properties for productCardImage, productCardHeading,
	 * productCardDescription
	 * </p>
	 *
	 * @return void
	 */
	private void fetchPagePropertiesData() {
		try {
			Page parentPage = currentPage.getParent();
			Page ancestorPage = parentPage.getParent();
			ValueMap pageProperties = null;
			Page rendingPage = parentPage;
			if (CommerceUtil.checkCategoryValues(parentPage.getProperties())) {
				pageProperties = parentPage.getProperties();
			} else if (CommerceUtil.checkCategoryValues(ancestorPage.getProperties())) {
				pageProperties = ancestorPage.getProperties();
				rendingPage = ancestorPage;
			}
			if (pageProperties != null) {
				Resource renderingResource = rendingPage.getContentResource();
				productType = renderingResource.getValueMap().get("categorytype", String.class);
				Node currentNode = renderingResource.adaptTo(Node.class);
				Node child;
				child = currentNode.getNode(CommerceConstants.CARRYOVER_OPTIONS);
				if(child !=null) {
					NodeIterator ni = child.getNodes();
					setMultiFieldItems(ni);
				}
			}
		} catch (RepositoryException e) {
			LOGGER.error("Repository Exception occurred while fetching multi link details {}", e);
		}
	}

	/**
	 * <p>
	 * Returns true if valuemap has category type and Id values
	 * </p>
	 *
	 * @return Boolean - true/false
	 */
	private Boolean checkCategoryValues(ValueMap properties) {

		if (properties != null && properties.containsKey(CommerceConstants.CATEGORY_ID)
				&& !properties.get(CommerceConstants.CATEGORY_ID, String.class).isEmpty()
				&& properties.containsKey(CommerceConstants.CATEGORY_TYPE)
				&& !properties.get(CommerceConstants.CATEGORY_TYPE, String.class).isEmpty()) {
			return true;
		}

		return false;
	}

	/**
	 * <p>
	 * Set the Value of carryover card heading and description on 5
	 * </p>
	 *
	 */
	private void setMultiFieldItems(NodeIterator ni) throws RepositoryException {
		try {
			while (ni.hasNext()) {
				Node grandChild = (Node) ni.nextNode();

				if ((grandChild.hasProperty(CommerceConstants.SERVICE_PLAN_GROUP))) {
					if ((grandChild.getProperty(CommerceConstants.SERVICE_PLAN_GROUP).getString())
							.equalsIgnoreCase(servicePlanGroup)) {
						if ((grandChild.hasProperty(CommerceConstants.PRODUCT_CARD_DESCRIPTION))) {
							productCardDescription = (grandChild.getProperty(CommerceConstants.PRODUCT_CARD_DESCRIPTION)
									.getString());
						}
						if ((grandChild.hasProperty(CommerceConstants.PRODUCT_CARD_HEADING))) {
							productCardHeading = (grandChild.getProperty(CommerceConstants.PRODUCT_CARD_HEADING)
									.getString());
						}
					}
				}

			}
		} catch (RepositoryException re) {
			LOGGER.error("Repository Exception occurred while fetching multi link details {}", re);
		}
	}

	/**
	 * <p>
	 * Sets plan data and plan talk minutes from product characteristics from API
	 * response
	 * </p>
	 * 
	 * @return void
	 */
	private void getProductCharacteristics() {
		LOGGER.debug("Entering getProductCharacteristics method");
		allPlanType = new ArrayList<String>();
		devicesType = new ArrayList<String>();
		devicesTypeMapping = new ArrayList<String>();
		if (product != null) {
			JsonArray jsonArray = product.get(CommerceConstants.PRODUCT_CHARACTERISTICS).getAsJsonArray();
			if (jsonArray.size() > 0) {
				for (int i = 0; i < jsonArray.size(); i++) {
					JsonObject jsonObject = jsonArray.get(i).getAsJsonObject();
					String key = jsonObject.get(CommerceConstants.IDENTIFIER).getAsString();
					if (key.equalsIgnoreCase(CommerceConstants.PLAN_DATA)) {

						planData = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Plan data value {}", planData);
					} else if (key.equalsIgnoreCase(CommerceConstants.PLAN_TALK_MINUTES)) {

						planTalkMinutes = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Plan talk minutes value {}", planTalkMinutes);
					} else if (key.equalsIgnoreCase(CommerceConstants.ALL_PLAN_TYPE)) {

						allPlanType.add(jsonObject.get(CommerceConstants.VALUE).getAsString()
								.trim().toLowerCase());
						LOGGER.debug("All Plan type value {}", allPlanType);
					} else if (key.equalsIgnoreCase(CommerceConstants.DEVICES_TYPE)) {
						JsonElement deviceType = jsonObject.get(CommerceConstants.VALUE);
						if (deviceType != null && !deviceType.isJsonNull() && !deviceType.getAsString().equals("0")
								&& !deviceType.getAsString().isEmpty()) {
							devicesType.add(deviceType.getAsString().trim().toLowerCase());
							flowType = getDevicesType(deviceType.getAsString().trim().toLowerCase());
							if(flowType!=null)
								devicesTypeMapping.add(deviceType.getAsString().trim() + ":" + flowType);
						}
						LOGGER.debug("Devices Type value {}", devicesType);
					} else if (key.equalsIgnoreCase(CommerceConstants.EXTENTDED_PLAN_ELIGIBLE)) {

						extendedPlanEligibility = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Extended Plan Eligibility value {}", extendedPlanEligibility);
					} else if (key.equalsIgnoreCase(CommerceConstants.OFFER_SMART_PAY)) {

						offerSmartPay = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Offer SmartPay value {}", offerSmartPay);
					} else if (key.equalsIgnoreCase(CommerceConstants.OFFER_HPP_PLAN)) {

						offerHPPPlan = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Offer HPP Plan value {}", offerHPPPlan);
					} else if (key.equalsIgnoreCase(CommerceConstants.ALLOW_GUEST_CHECKOUT)) {

						allowGuestCheckout = jsonObject.get(CommerceConstants.VALUE)
								.getAsString();
						LOGGER.debug("Allow Guest Checkout value {}", allowGuestCheckout);
					} else if (key.equalsIgnoreCase(CommerceConstants.INBUILT_PROTECTION_PLAN)) {

						inBuiltProtectionPlan = jsonObject.get(CommerceConstants.VALUE)
								.getAsString();
						LOGGER.debug("inBuiltProtectionPlan value {}", inBuiltProtectionPlan);
					} else if (key.equalsIgnoreCase(CommerceConstants.MARKET)) {

						marketingIds = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Marketign IDs value {}", marketingIds);
					} else if (key.equalsIgnoreCase(CommerceConstants.PLAN_CATEGORY) && !(CommerceConstants.UPSELL).equalsIgnoreCase(jsonObject.get(CommerceConstants.VALUE).getAsString())) {

						planCategory = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Plan category value {}", planCategory);
					} else if (key.equalsIgnoreCase(CommerceConstants.PLAN_PURCHASE_TYPE)) {

						planPurchaseType = jsonObject.get(CommerceConstants.VALUE)
								.getAsString();
						LOGGER.debug("Plan purchase type value {}", planPurchaseType);
					} else if (key.equalsIgnoreCase(CommerceConstants.PLAN_TEXT)) {

						planText = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Plan text value {}", planText);
					} else if (key.equalsIgnoreCase(CommerceConstants.PLAN_SERVICE_DAYS)) {

						planServiceDaysApi = jsonObject.get(CommerceConstants.VALUE)
								.getAsString();
						LOGGER.debug("Plan service days value {}", planServiceDaysApi);
					} else if (key.equalsIgnoreCase(CommerceConstants.PLAN_PURCHASE_POINTS)) {

						planPurchasePoints = jsonObject.get(CommerceConstants.VALUE)
								.getAsString();
						LOGGER.debug("Plan purchase points value {}", planPurchasePoints);
					} else if (key.equalsIgnoreCase(CommerceConstants.PLAN_EARN_POINTS)) {

						planEarnPoints = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Plan earn points value {}", planEarnPoints);
					} else if (key.equalsIgnoreCase(CommerceConstants.DATA)) {

						data = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Data value {}", data);
					} else if (key.equalsIgnoreCase(CommerceConstants.TALK_MINUTES)) {

						minutes = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Minutes value {}", minutes);
					} else if (key.equalsIgnoreCase(CommerceConstants.PLAN_DEVICE_TYPE)) {
						if (StringUtils.isNotBlank(
								jsonObject.get(CommerceConstants.VALUE).getAsString())) {
							planDeviceType = jsonObject.get(CommerceConstants.VALUE).getAsString();
							LOGGER.debug("plan device type {}", planDeviceType);
						}
					} else if (key.equalsIgnoreCase(CommerceConstants.SERVICE_PLAN_GROUP_IDENTIFIER)) {
						servicePlanGroup = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Service Plan group {}", servicePlanGroup);
					}else if (key.equalsIgnoreCase(CommerceConstants.BENEFITS_CARRY_FORWARD_FLAG)) {
						benefitsCarryForward = jsonObject.get(CommerceConstants.VALUE).getAsString();
						LOGGER.debug("Benefits Carry Forward {}", benefitsCarryForward);
					}else if (key.equalsIgnoreCase(CommerceConstants.ADDON_GLOBAL_CARD_DETAILS)) {
						if(!(StringUtils.isEmpty(jsonObject.get(CommerceConstants.VALUE).getAsString()))) {
							globalCardDescription = jsonObject.get(CommerceConstants.VALUE).getAsString();
						}
						LOGGER.debug("Global Calling Card Description {}", globalCardDescription);
					}else if (key.equalsIgnoreCase(CommerceConstants.PLAN_ELIGIBLE_FOR_AUTOREFILL)) {
						if(!(StringUtils.isEmpty(jsonObject.get(CommerceConstants.VALUE).getAsString()))) {
							planEligibleForAutoRefill = jsonObject.get(CommerceConstants.VALUE).getAsString().toLowerCase();
						}
						LOGGER.debug("Plan Eligible For AutoRefill {}", planEligibleForAutoRefill);
					}else if (key.equalsIgnoreCase(CommerceConstants.BILLING_PLAN_TYPE)) {
						if(!(StringUtils.isEmpty(jsonObject.get(CommerceConstants.VALUE).getAsString()))) {
							billingPlanType = jsonObject.get(CommerceConstants.VALUE).getAsString();
						}
						LOGGER.debug("Billing Plan Type {}", billingPlanType);
					}else if (key.equalsIgnoreCase(CommerceConstants.TAX_INCLUSIVE)) {
						if(!(StringUtils.isEmpty(jsonObject.get(CommerceConstants.VALUE).getAsString()))) {
							taxInclusive = jsonObject.get(CommerceConstants.VALUE).getAsString();
						}
						LOGGER.debug("Tax Inclusive {}", taxInclusive);
					} else if(key.equalsIgnoreCase(CommerceConstants.HOTSPOT_CAPABILITY)){
						if(!(StringUtils.isEmpty(jsonObject.get(CommerceConstants.VALUE).getAsString()))) {
							String hotspotCapableResponse = jsonObject.get(CommerceConstants.VALUE).getAsString();
							if(hotspotCapableResponse!=null && hotspotCapableResponse.equals(CommerceConstants.HOTSPOT_CAPABLE_EN)){
								hotspotText = CommerceConstants.HOTSPOT_TEXT;
								capableText = CommerceConstants.CAPABLE_TEXT_EN;
							}else if(hotspotCapableResponse!=null && hotspotCapableResponse.equals(CommerceConstants.HOTSPOT_CAPABLE_ES)){
								hotspotText = CommerceConstants.HOTSPOT_TEXT;
								capableText = CommerceConstants.CAPABLE_TEXT_ES;
							}
						}
					}
					
					String identifierValue;
					for (String identifierKey : singleBucketList) {
						if (key.equalsIgnoreCase(identifierKey)) {
							identifierValue = jsonObject.get(CommerceConstants.VALUE).getAsString();
							singleBucketSpecsMap.put(identifierKey, identifierValue);
							LOGGER.debug("Bean:" + identifierKey + "value {}", identifierValue);
						}
					}
				}
			}

			LOGGER.debug("Exiting getProductCharacteristics method");
		}
	}
	
	/**
	 * 	 * <p>
	 * Returns Global Card Description
	 * </p>
	 * 
	 * @return the globalCardDescription
	 */
	public String getGlobalCardDescription() {
		return globalCardDescription;
	}

	/**
	 * <p>
	 * Returns Benefits Carry Forward
	 * </p>
	 * 
	 * @return the benefitsCarryForward
	 */
	@Override
	public String getBenefitsCarryForward() {
		return benefitsCarryForward;
	}

	/**
	 * <p>
	 * Returns plan Text
	 * </p>
	 * 
	 * @return String - planText
	 */
	@Override
	public String getPlanText() {
		return planText;
	}

	/**
	 * <p>
	 * Returns plan Service Days Api
	 * </p>
	 * 
	 * @return String - planServiceDaysApi
	 */
	@Override
	public String getPlanServiceDaysApi() {
		return planServiceDaysApi;
	}

	/**
	 * <p>
	 * Returns plan Purchase Points
	 * </p>
	 * 
	 * @return the planPurchasePoints
	 */
	@Override
	public String getPlanPurchasePoints() {
		return planPurchasePoints;
	}

	/**
	 * <p>
	 * Returns plan Earn Points
	 * </p>
	 * 
	 * @return the planEarnPoints
	 */
	@Override
	public String getPlanEarnPoints() {
		return planEarnPoints;
	}

	/**
	 * <p>
	 * Returns data value
	 * </p>
	 * 
	 * @return the data
	 */
	@Override
	public String getData() {
		return data;
	}

	/**
	 * <p>
	 * Returns minutes value
	 * </p>
	 * 
	 * @return the minutes
	 */
	@Override
	public String getMinutes() {
		return minutes;
	}

	/**
	 * @return the planDeviceType
	 */
	@Override
	public String getPlanDeviceType() {
		return planDeviceType;
	}

	/**
	 * <p>
	 * Returns exporter type
	 * </p>
	 * 
	 * @return String - getexportertype
	 */
	@Override
	public String getExportedType() {

		return resource.getResourceType();
	}

	/**
	 * <p>
	 * Returns PlanCardModel
	 * </p>
	 * 
	 * @return PlanCardModel - getPlanCardModel
	 */
	@Override
	public PlanCardModel getPlanCardModel() {
		return planCardModel;
	}

	/**
	 * <p>
	 * Returns type
	 * </p>
	 * 
	 * @return String - getType
	 */
	@Override
	public String getType() {
		return type;
	}

	/**
	 * <p>
	 * Returns Plan Service Days Label authored
	 * </p>
	 *
	 * @return String - planServiceDaysLabel
	 */
	@Override
	public String getPlanServiceDaysLabel() {
		return planServiceDaysLabel;
	}

	/**
	 * <p>
	 * Returns Service Days Popover Text authored
	 * </p>
	 *
	 * @return String - serviceDaysPopoverText
	 */
	@Override
	public String getServiceDaysPopoverText() {
		return serviceDaysPopoverText;
	}

	/**
	 * <p>
	 * Returns Auto Refill Id
	 * </p>
	 *
	 * @return String - autoRefillId
	 */
	@Override
	public String getAutoRefillId() {
		return autoRefillId;
	}

	/**
	 * <p>
	 * Returns Auto Refill Price
	 * </p>
	 *
	 * @return String - autoRefillPrice
	 */
	@Override
	public String getAutoRefillPrice() {
		return autoRefillPrice;
	}

	private void setSingleBucketData(Map<String, String> sbSpecsDataMap, Resource resource) {
		Map<String, PhoneSpecsBean> bucketMap = new HashMap<String, PhoneSpecsBean>();
		PhoneSpecsBean phoneSpecsBean = new PhoneSpecsBean();
		phoneSpecsBean.setShow(N);
		PhoneSpecsBean bucketBean;
		int count = 0;
		/* This will fetch the identifiers/units/text set for single bucket. */
		bucketBean = setSingleBucketUnitText();
		/* Below code to used to set value to be displayed for single bucket */
		for (Map.Entry<String, String> sbSpecs : sbSpecsDataMap.entrySet()) {
			String identifier = sbSpecs.getKey();
			if (StringUtils.isNotBlank(identifier)) {				
				if (singleBucketList.contains(identifier) && StringUtils.isNotBlank(sbSpecs.getValue())
						&& !(ApplicationConstants.ZERO).equalsIgnoreCase(sbSpecs.getValue())) {
					count++;
					bucketMap.put(sbSpecs.getKey(), bucketBean);
				}
				
			}
			setFormattedDataValue(phoneSpecsBean, sbSpecs, identifier);
		}
		for (Map.Entry<String, String> sbSpecs : sbSpecsDataMap.entrySet()) {
			String identifier = sbSpecs.getKey();
			/* This code to check and set the attribute required to show single bucket */
			if (count == 1 && singleBucketList.contains(identifier)) {
				if (bucketMap.containsKey(identifier)) {
					PhoneSpecsBean b1 = bucketMap.get(identifier);
					phoneSpecsBean.setShow(Y);
					if ((ApplicationConstants.YES)
							.equalsIgnoreCase(CommerceUtil.getDataConversionIdentifier(identifier, specsConfig)))
						phoneSpecsBean.setValue(CommerceUtil.getDataUnits(sbSpecs.getValue(),
								bucketBean.getThresholdValue(), bucketBean.getThresholdLabel()));
					else
						phoneSpecsBean.setValue(CommerceUtil.checkForUnlimited(sbSpecs.getValue(),
								bucketBean.getThresholdValue(), bucketBean.getThresholdLabel()));	
					if (identifier.equalsIgnoreCase(CommerceConstants.TALK_MINUTES)) {
						if (StringUtils.isNotBlank(b1.getThresholdUnit())
								&& (bucketBean.getThresholdLabel().equalsIgnoreCase(phoneSpecsBean.getValue())))
							phoneSpecsBean.setSummary(b1.getThresholdUnit());
						else
							phoneSpecsBean.setSummary(b1.getValue());
					}else if(identifier.equalsIgnoreCase(CommerceConstants.DATA)) {
						phoneSpecsBean.setSummary(planDataLabel);
					}else if(identifier.equalsIgnoreCase(CommerceConstants.PLAN_TEXT)) {						
							phoneSpecsBean.setSummary(planTextLabel); 						
					}
					phoneSpecsBean.setBucketName(b1.getMultiplier());
				}
			}
		}
		singleBucketSpecsList.add(phoneSpecsBean);
	}

	@Override
	public List<PhoneSpecsBean> getSingleBucketSpecsList() {
		return new ArrayList<>(singleBucketSpecsList);
	}

	private List<String> setSingleBucketIdetifiers() {
		List<String> bucketList = new ArrayList<String>();
		/* This will fetch the identifiers/units/text set for single bucket. */
		String sbIdentifiers = (String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
				CommerceConstants.SINGLE_BUCKET_IDENTIFIERS);
		if (org.apache.commons.lang.StringUtils.isNotEmpty(sbIdentifiers)) {
			sbIdentifiers = sbIdentifiers.toLowerCase();
			Collections.addAll(bucketList, sbIdentifiers.split(ApplicationConstants.COMMA));
		}
		return bucketList;
	}

	private PhoneSpecsBean setSingleBucketUnitText() {
		PhoneSpecsBean unitTextBean = new PhoneSpecsBean();
		String sbUnit = (String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
				CommerceConstants.SINGLE_BUCKET_UNIT);
		String sbText = (String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
				CommerceConstants.SINGLE_BUCKET_TEXT);
		unitTextBean.setMultiplier(sbText);
		unitTextBean.setValue(sbUnit);
		unitTextBean.setThresholdValue((String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
				CommerceConstants.THRESHOLD_VALUE));
		unitTextBean.setThresholdLabel(thresholdLabel);
		unitTextBean.setThresholdUnit(thresholdUnit);
		return unitTextBean;
	}

	private Map<String, PhoneSpecsBean> setMultiplierList() {
		/* This code will get the multiplers values set at page level. */
		specsConfig = CommerceUtil.getMultifieldPagePropertyMap(currentPage, getHomePageLevel(),
				CommerceConstants.SPECS_OPTIONS, CommerceConstants.IDENTIFIER, CommerceConstants.UNIT,
				CommerceConstants.MULTIPLIER, CommerceConstants.DATA_CONVERSION,
				CommerceConstants.BENEFIT_CARRY_FORWARD_ADD_ON_DESC,
				CommerceConstants.BENEFIT_NON_CARRY_FORWARD_ADD_ON_DESC, CommerceConstants.BENEFIT_CARRY_FORWARD_DESC,
				CommerceConstants.THRESHOLD_VALUE, CommerceConstants.THRESHOLD_UNIT);
		return specsConfig;
	}

	public List<String> getIdentifierList() {
		if (!specsConfig.isEmpty()) {
			if (multiplierList.isEmpty()) {
				multiplierList = CommerceUtil.getMultipliersList(specsConfig);
			}
		}
		return new ArrayList<>(multiplierList);
	}

	public List<String> getIdentifierUnitList() {
		if (!specsConfig.isEmpty()) {
			if (multiplierUnitList.isEmpty()) {
				multiplierUnitList = CommerceUtil.getMultiplierUnitList(specsConfig);
			}
		}
		return new ArrayList<>(multiplierUnitList);
	}

	public String getDataUnitConversion() {
		return CommerceUtil.getUnitValuesJsonString(specsConfig);
	}

	private PhoneSpecsBean setFormattedDataValue(PhoneSpecsBean phoneSpecsBean, Map.Entry<String, String> sbSpecs,
			String identifier) {
		for (Map.Entry<String, PhoneSpecsBean> entry : specsConfig.entrySet()) {
			PhoneSpecsBean specBean = entry.getValue();
			if (specBean != null) {
				if ((ApplicationConstants.YES).equalsIgnoreCase(specBean.getDataConversion())) {
					/* convert data unit in MB/GB */
					phoneSpecsBean.setValue(CommerceUtil.getDataUnits(sbSpecs.getValue(), specBean.getThresholdValue(),
							thresholdLabel));
					break;
				} else {
					phoneSpecsBean.setValue(sbSpecs.getValue());
					break;
				}
			}
		}
		return phoneSpecsBean;
	}

	private void setUnitValues() {
		
		for (Map.Entry<String, PhoneSpecsBean> entry : specsConfig.entrySet()) {
			PhoneSpecsBean specBean = entry.getValue();
			if (specBean != null) {
				
				if (specBean.getName().equalsIgnoreCase(CommerceConstants.DATA)) {
					planDataLabel = specBean.getValue();
					dataCarryForwardDescription = (benefitsCarryForward.equals("true")) ? specBean.getBcfAddOnDescription() : specBean.getBncfAddOnDescription();
					if ((ApplicationConstants.YES).equalsIgnoreCase(specBean.getDataConversion()) && StringUtils.isNotBlank(data))
						/* convert data unit in MB/GB */
						data = CommerceUtil.getDataUnits(data, specBean.getThresholdValue(), thresholdLabel);

					if (StringUtils.isNotBlank(specBean.getThresholdUnit()) && StringUtils.isNotBlank(data) && data.equalsIgnoreCase(thresholdLabel))
						planDataLabel = specBean.getThresholdUnit();
					else
						planDataLabel = specBean.getValue();
				} else if (specBean.getName().equalsIgnoreCase(CommerceConstants.TALK_MINUTES) && StringUtils.isNotBlank(minutes)) {
					String originalUnit = minutes;
					voiceCarryForwardDescription = (benefitsCarryForward.equals("true")) ? specBean.getBcfAddOnDescription() : specBean.getBncfAddOnDescription();
					minutes = CommerceUtil.checkForUnlimited(minutes, specBean.getThresholdValue(), thresholdLabel);
					if (StringUtils.isNotBlank(specBean.getThresholdUnit()) && StringUtils.isNotBlank(minutes) && !originalUnit.equalsIgnoreCase(minutes))
						planMinutesLabel = specBean.getThresholdUnit();
					else
						planMinutesLabel = specBean.getValue();
				} else if (specBean.getName().equalsIgnoreCase(CommerceConstants.PLAN_TEXT) && StringUtils.isNotBlank(planText)) {
					String originalUnit = planText;
					textCarryForwardDescription = (benefitsCarryForward.equals("true")) ? specBean.getBcfAddOnDescription() : specBean.getBncfAddOnDescription();
					planText = CommerceUtil.checkForUnlimited(planText, specBean.getThresholdValue(), thresholdLabel);
					if (StringUtils.isNotBlank(specBean.getThresholdUnit()) && StringUtils.isNotBlank(planText) && !originalUnit.equalsIgnoreCase(planText))
						planTextLabel = specBean.getThresholdUnit();
					else
						planTextLabel = specBean.getValue();
				}
			}
		}
	}
	
	/**
	 * @return the voiceCarryForwardDescription
	 */
	@Override
	public String getVoiceCarryForwardDescription() {
		return voiceCarryForwardDescription;
	}

	/**
	 * @return the textCarryForwardDescription
	 */
	@Override
	public String getTextCarryForwardDescription() {
		return textCarryForwardDescription;
	}

	/**
	 * @return the dataCarryForwardDescription
	 */
	@Override
	public String getDataCarryForwardDescription() {
		return dataCarryForwardDescription;
	}
	

	/**
	 * @return the globalCardTitle
	 */
	@Override
	public String getGlobalCardTitle() {
		return globalCardTitle;
	}

	/**
	 * <p>
	 * Returns Plan Minutes Label authored
	 * </p>
	 *
	 * @return String - planMinutesLabel
	 */
	@Override
	public String getPlanMinutesLabel() {
		return planMinutesLabel;
	}

	/**
	 * <p>
	 * Returns Plan Text Label authored
	 * </p>
	 *
	 * @return String - planTextLabel
	 */
	@Override
	public String getPlanTextLabel() {
		return planTextLabel;
	}

	/**
	 * <p>
	 * Returns Plan Data Text Label authored
	 * </p>
	 *
	 * @return String - planDataLabel
	 */
	@Override
	public String getPlanDataTextLabel() {
		return planDataLabel;
	}

	/**
	 * <p>
	 * Fetches productCardHeading
	 * </p>
	 *
	 * @return the productCardHeading
	 */
	@Override
	public String getProductCardHeading() {
		return productCardHeading;
	}

	/**
	 * <p>
	 * Fetches productCardDescription
	 * </p>
	 *
	 * @return the productCardDescription
	 */
	@Override
	public String getProductCardDescription() {
		return productCardDescription;
	}

	/**
	 * <p>
	 * Method to return singleBucketThresholdValue
	 * </p>
	 *
	 * @return the singleBucketThresholdValue
	 */
	@Override
	public String getSbThresholdValue() {
		singleBucketThresholdValue = (String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
				CommerceConstants.THRESHOLD_VALUE);
		return singleBucketThresholdValue;
	}

	/**
	 * <p>
	 * Method to return singleBucketThresholdUnit
	 * </p>
	 *
	 * @return the singleBucketThresholdUnit
	 */
	@Override
	public String getSbThresholdUnit() {
		singleBucketThresholdUnit = (String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
				CommerceConstants.THRESHOLD_UNIT);
		return singleBucketThresholdUnit;
	}

	/**
	 * <p>
	 * Method to return multiBucketThresholdLabel
	 * </p>
	 *
	 * @return the multiBucketThresholdLabel
	 */
	@Override
	public String getThresholdLabel() {
		return thresholdLabel;
	}

	/**
	 * <p>
	 * Fetches thresholdUnit
	 * </p>
	 *
	 * @return the thresholdUnit
	 */
	 @Override
	public String getThresholdUnit() {
		return thresholdUnit;
	}

	/**
	 * <p>
	 * Method to return buyNowRewardsHelpText
	 * </p>
	 *
	 * @return the buyNowRewardsHelpText
	 */
	@Override
	public String getBuyNowRewardsHelpText() {
		return (String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
				CommerceConstants.BUY_NOW_REWARDS_HELP_TEXT);
	}

	/**
	 * Method to return ctaLink
	 * </p>
	 *
	 * @return the ctaLink
	 */
	@Override
	public String getCtaLink() {
		return ApplicationUtil.getShortUrl(resource.getResourceResolver(), this.ctaLink);
	}

	/**
	 * <p>
	 * Method to check plan name value
	 * </p>
	 */
	@Override
	public String getPlanNameValue() {
		String productName = StringUtils.EMPTY;
		if (resource != null && currentPage != null && resource.getResourceResolver() != null) {
			Resource productRes = resource.getResourceResolver()
					.resolve(currentPage.getPath() + CommerceConstants.PLAN_DETAIL_ROOT_PATH);
			if (productRes != null)
				productName = StringUtils.defaultString(productRes.getValueMap().get(PLAN_NAME_DETAIL, String.class));
		}
		return productName;
	}

	/**
	 * <p>
	 * Returns Device Type mapping
	 * </p>
	 *
	 * @return String - devicesTypeMapping
	 */
	@Override
	public List<String> getDevicesTypeMapping() {
		return new ArrayList<>(devicesTypeMapping);
	}
	
	/**
	 * @return the planCardButtonLabel
	 */
	@Override
	public String getPlanCardButtonLabel() {
		return (String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
				CommerceConstants.PHONE_PLAN_CAROUSEL_BUTTON_LABEL);
	}
	
	/**
	 * <p>
	 * Returns True if Hide AutoRefill Text Under Price is enabled
	 * </p>
	 *
	 * @return Boolean - True of False
	 */
	@Override
	public Boolean getHideAutoRefillTextUnderPrice() {
		return hideAutoRefillTextUnderPrice != null ? hideAutoRefillTextUnderPrice : false;
	}
	
	/**
	 * <p>
	 * Fetches Alternate DataUnit For PlanCard
	 * </p>
	 *
	 * @return String - alternateDataUnitForPlanCard
	 */
	@Override
	public String getAlternateDataUnitForPlanCard() {
		return alternateDataUnitForPlanCard;
	}

	/**
	 * <p>
	 * Returns True if Hide AutoRefill Text Under Price is enabled
	 * </p>
	 *
	 * @return Boolean - True of False
	 */
	@Override
	public String getMultilinePlanSelection() {
		return multilinePlanSelection;
	}

	/**
	 * <p>
	 * Fetches Show Capable Text For PlanCard
	 * </p>
	 *
	 * @return String - showCapableTextForPlanCard
	 */

	public String getHotspotText(){
		return hotspotText;
	}

	public String getCapableText(){
		return capableText;
	}
	
}