package com.tracfonecore.core.models.impl;

import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.DeviceWarningModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { DeviceWarningModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/deviceIdentification", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class DeviceWarningModelImpl implements DeviceWarningModel {

	@Self
	private SlingHttpServletRequest request;


	/**
	 * Inject header text
	 */
	@Inject
	@Via("resource")
	private String headerText;

	/**
	 * Inject summary
	 */
	@Inject
	@Via("resource")
	private String summary;

	/**
	 * Inject show input
	 */
	@Inject
	@Via("resource")
	private String showInput;
	
	/**
	 * Inject input Field Label
	 */
	@Inject
	@Via("resource")
	private String inputFieldLabel;

	/**
	 * Inject subtext Label
	 */
	@Inject
	@Via("resource")
	private String subtext;

	/**
	 * Inject button Label
	 */
	@Inject
	@Via("resource")
	private String buttonLabel;

	/**
	 * <p>
	 * Returns headerText from properties
	 * </p>
	 * 
	 * @return String - headerText
	 */
	@Override
	public String getHeaderText() {
		return headerText;
	}

	/**
	 * <p>
	 * Returns summary from properties
	 * </p>
	 * 
	 * @return String - summary
	 */
	@Override
	public String getSummary() {
		return summary;
	}

	/**
	 * @return the showInput
	 */
	@Override
	public String getShowInput() {
		return showInput;
	}

	/**
	 * <p>
	 * Returns inputFieldLabel from properties
	 * </p>
	 * 
	 * @return String - inputFieldLabel
	 */
	@Override
	public String getInputFieldLabel() {
		return inputFieldLabel;
	}

	/**
	 * <p>
	 * Returns subtext from properties
	 * </p>
	 * 
	 * @return String - subtext
	 */
	@Override
	public String getSubtext() {
		return subtext;
	}

	/**
	 * <p>
	 * Returns buttonLabel from properties
	 * </p>
	 * 
	 * @return String - buttonLabel
	 */
	@Override
	public String getButtonLabel() {
		return buttonLabel;
	}

	/**
	 * <p>
	 * Returns getexportertype from resource
	 * </p>
	 * 
	 * @return String - getexportertype
	 */
	@Override
	public String getExportedType() {

		return request.getResource().getResourceType();
	}

}
