/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Multi-Links} Sling Model used for the
 * {@code /apps/tracfone-core/components/commerce/passwordrecovery} component.
 */
public interface PasswordRecoveryModel extends ComponentExporter {

	/**
	 * <p>
	 * Fetches headlinePwdRecovery for the passwordrecovery
	 * </p>
	 * 
	 * @return String - headlinePwdRecovery for the passwordrecovery
	 */
	@JsonProperty("headlinePwdRecovery")
	public String getHeadlinePwdRecovery();

	/**
	 * <p>
	 * Fetches summaryPwdRecovery for the passwordrecovery
	 * </p>
	 * 
	 * @return String - summaryPwdRecovery for the passwordrecovery
	 */
	@JsonProperty("summaryPwdRecovery")
	public String getSummaryPwdRecovery();

	/**
	 * <p>
	 * Fetches Register Success Message for the passwordrecovery
	 * </p>
	 * 
	 * @return String - Success Message for the passwordrecovery
	 */
	@JsonProperty("successMessage")
	public String getSuccessMessage();
	/**
	 * <p>
	 * Fetches Login Page Path
	 * </p>
	 * 
	 * @return String - Login Page Path
	 */
	public String getLoginPagePath();
	  /**
     * Get the homePageLevel
     * @return String - homePageLevel
     */
    public int getHomePageLevel();

	/**
	 * <p>
	 * Fetches Accessibility Text
	 * </p>
	 * 
	 * @return String - accessibilityText
	 */
	@JsonProperty("accessibilityText")
	public String getAccessibilityText();
}
