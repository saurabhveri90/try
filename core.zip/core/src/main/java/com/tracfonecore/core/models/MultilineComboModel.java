package com.tracfonecore.core.models;

import java.util.List;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tracfonecore.core.beans.ProductDetailJsonBean;

public interface MultilineComboModel extends ComponentExporter {

    /**
     * <p>
     * Fetches the plans
     * </p>
     *
     * @return List - plans
     */
    @JsonProperty("plans")
    public List<ProductDetailJsonBean> getPlans();

    /**
     * <p>
     * Fetches the planPaths
     * </p>
     *
     * @return String - planPaths
     */
    @JsonProperty("planPaths")
    public String[] getPlanPaths();

    /**
     * <p>
     * Fetches the ctaText
     * </p>
     *
     * @return String - ctaText
     */
    @JsonProperty("ctaText")
    public String getCtaText();

    /**
     * <p>
     * Fetches the ctaAccessibility
     * </p>
     *
     * @return String - ctaAccessibility
     */
    @JsonProperty("ctaAccessibility")
    public String getCtaAccessibility();

    /**
     * <p>
     * Fetches the ctaLink
     * </p>
     *
     * @return String - ctaLink
     */
    @JsonProperty("ctaLink")
    public String getCtaLink();

    /**
     * <p>
     * Fetches the cardWidth
     * </p>
     *
     * @return String - cardWidth
     */
    @JsonProperty("cardWidth")
    public String getCardWidth();

    /**
     * <p>
     * Fetches the noOfPlans
     * </p>
     *
     * @return String - noOfPlans
     */
    @JsonProperty("noOfPlans")
    public String getNoOfPlans();

    /**
     * <p>
     * Fetches the priceApiPath
     * </p>
     *
     * @return String - priceApiPath
     */
    @JsonProperty("priceApiPath")
    public String getPriceApiPath();

    /**
     * <p>
     * Fetches the apiDomain
     * </p>
     *
     * @return String - apiDomain
     */
    @JsonProperty("apiDomain")
    public String getApiDomain();

    /**
     * <p>
     * Fetches the queryString
     * </p>
     *
     * @return String - queryString
     */
    @JsonProperty("queryString")
    public String getQueryString();

    /**
     * <p>
     * Fetches the priceSaveAccessibility
     * </p>
     *
     * @return String - priceSaveAccessibility
     */
    @JsonProperty("priceSaveAccessibility")
    public String getPriceSaveAccessibility();

	/**
	 * <p>
	 * Fetches order index
	 * </p>
	 * 
	 * @return String - Order Index
	 */
	@JsonProperty("orderIndex")
	public String getOrderIndex();

}
