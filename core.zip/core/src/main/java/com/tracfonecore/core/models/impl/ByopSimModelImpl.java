package com.tracfonecore.core.models.impl;

import com.tracfonecore.core.models.ByopSimModel;
import com.tracfonecore.core.models.ByopSimOptionsModel;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;


import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ByopSimModel.class,
    ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/byopsim", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
    @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
    @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ByopSimModelImpl implements ByopSimModel{

    @Self
    private SlingHttpServletRequest request;

    @ChildResource
	private List<ByopSimOptionsModel> options = Collections.emptyList();

    @ValueMapValue
    private String heading;

    @ValueMapValue
    private String summary;
    
    @ValueMapValue
    private String phoneRedirectUrl;
    
    @ValueMapValue
    private String tabRedirectUrl;

    @ValueMapValue
    private String scanText;

    @ValueMapValue
    private String scanPlacement;

    @ValueMapValue
    private String simbSummary;
    /**
     * <p>Fetches heading</p>
     *
     * @return String - heading
     */
    @Override
    public String getHeading() {
        return heading;
    }

    /**
     * <p>Fetches summary</p>
     *
     * @return String - summary
     */
    @Override
    public String getSummary() {
        return summary;
    }

    /**
     * <p>Fetches all the multi-options</p>
     *
     * @return List - all the multi-options
     */
    @Override
    public List<ByopSimOptionsModel> getOptions() {
        return new ArrayList<ByopSimOptionsModel>(options);
    }

    /**
     * @return String - exportedType
     */
    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }
    
    /**
     * <p>Fetches phoneRedirectUrl</p>
     *
     * @return String - phoneRedirectUrl
     */
    @Override
    public String getPhoneRedirectUrl() {
        return phoneRedirectUrl;
    }
    
    /**
     * <p>Fetches tabRedirectUrl</p>
     *
     * @return String - tabRedirectUrl
     */
    @Override
    public String getTabRedirectUrl() {
        return tabRedirectUrl;
    }

    /**
     * <p>Fetches scanText</p>
     *
     * @return String - scanText
     */
    @Override
    public String getScanText() {
        return scanText;
    }

    /**
     * <p>Fetches scanPlacement</p>
     *
     * @return String - scanPlacement
     */
    @Override
    public String getScanPlacement() {
        return scanPlacement;
    }

    /**
     * <p>Fetches simbSummary</p>
     *
     * @return String - simbSummary
     */
    @Override
    public String getSimbSummary() {
        return simbSummary;
    }
}


