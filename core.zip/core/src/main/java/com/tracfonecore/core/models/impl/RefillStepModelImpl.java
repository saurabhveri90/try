package com.tracfonecore.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.RefillStepModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { RefillStepModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/refillstepmodal", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class RefillStepModelImpl implements RefillStepModel {

	@Self
	private SlingHttpServletRequest request;	
	
	@ValueMapValue
	private String stepBannerSummary;

	@ValueMapValue
	private String stepModalButtonSummary;

	@ValueMapValue
	private String stepModalChangeButtonLabel;

	@ValueMapValue
	private String stepModalKeepplanButtonLabel;
	
	@ValueMapValue
	private String stepBannerHeading;

	@ValueMapValue
	private String modalType;
	
	/**
     * @return String - exported Type
     */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}	

	/**
	 * <p>
	 * Fetches label for stepupBannerHeading
	 * </p>
	 * 
	 * @return String - stepupBannerHeading
	 */
	@Override
	public String getStepBannerHeading() {
		return stepBannerHeading;
	}
	/**
	 * <p>
	 * Fetches label for stepupBannerSummary
	 * </p>
	 * 
	 * @return String - stepupBannerSummary
	 */
	@Override
	public String getStepBannerSummary() {
		return stepBannerSummary;
	}

	/**
	 * <p>
	 * Fetches label for stepupModalButtonSummary
	 * </p>
	 * 
	 * @return String - stepupModalButtonSummary
	 */
	@Override
	public String getStepModalButtonSummary() {
		return stepModalButtonSummary;
	}

	/**
	 * <p>
	 * Fetches label for stepupModalChangeButtonLabel
	 * </p>
	 * 
	 * @return String - stepupModalChangeButtonLabel
	 */
	@Override
	public String getStepModalChangeButtonLabel() {
		return stepModalChangeButtonLabel;
	}

	/**
	 * <p>
	 * Fetches label for stepupModalKeepplanButtonLabel
	 * </p>
	 * 
	 * @return String - stepupModalKeepplanButtonLabel
	 */
	@Override
	public String getStepModalKeepplanButtonLabel() {
		return stepModalKeepplanButtonLabel;
	}

	@Override
	public String getModalType() {
		return modalType;
	}
}
