package com.tracfonecore.core.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public interface MldCardsContainerModel {

    @JsonProperty("showMultilineSelector")
	public String getShowMultilineSelector();

    @JsonProperty("multilineSelectorText")
	public String getMultilineSelectorText();

    @JsonProperty("overridePrice")
	public String getOverridePrice();

    @JsonProperty("showFccLink")
	public String getShowFccLink();

    @JsonProperty("fccLinkText")
	public String getFccLinkText();

    @JsonProperty("showPriceBreakdown")
	public String getShowPriceBreakdown();

    @JsonProperty("priceApiPath")
    public String getPriceApiPath();
    
    @JsonProperty("queryString")
    public String getQueryString();

    @JsonProperty("showCommonFccLink")
    public String getShowCommonFccLink();
    
    @JsonProperty("fccCommonLink")
    public String getFccCommonLink();
}
