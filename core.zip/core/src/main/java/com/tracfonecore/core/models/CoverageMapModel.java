package com.tracfonecore.core.models;

import org.apache.sling.api.resource.Resource;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code CoverageMap} Sling Model used for the {@code /apps/tracfone-core/components/content/coveragemap} component.
 */
public interface CoverageMapModel extends ComponentExporter {

	/**
	 * <p>Fetches title of step one of Coverage map search</p>
	 * 
	 * @return String - Step One Title
	 */
	@JsonProperty("stepOneTitle")
	public String getStepOneTitle();

	/**
	 * <p>Fetches sub-title of step one of Coverage map search</p>
	 * 
	 * @return String - Step One SubTitle
	 */
	@JsonProperty("stepOneSubTitle")
	public String getStepOneSubTitle();


	/**
	 * <p>Fetches continue button text of step one of Coverage map search</p>
	 * 
	 * @return String - Step One Button Text
	 */
	@JsonProperty("stepOneContinueButtonText")
	public String getStepOneContinueButtonText();

	/**
	 * <p>Fetches existing customer link label step one of Coverage map search</p>
	 * 
	 * @return String - Step One existing customer label text
	 */
	@JsonProperty("stepOneExisitngCustomerLabelText")
	public String getStepOneExisitngCustomerLabelText();

	/**
	 * <p>Fetches title of step two of Coverage map search</p>
	 * 
	 * @return String - Step Two Title
	 */
	@JsonProperty("stepTwoTitle")
	public String getStepTwoTitle();

	/**
	 * <p>Fetches sub-title of step two of Coverage map search</p>
	 * 
	 * @return String - Step Two SubTitle
	 */
	@JsonProperty("stepTwoSubTitle")
	public String getStepTwoSubTitle();


	/**
	 * <p>Fetches continue button text of step two of Coverage map search</p>
	 * 
	 * @return String - Step Two Button Text
	 */
	@JsonProperty("stepTwoContinueButtonText")
	public String getStepTwoContinueButtonText();

	/**
	 * <p>Fetches new customer link label step two of Coverage map search</p>
	 * 
	 * @return String - Step Two new customer label text
	 */
	@JsonProperty("stepTwoNewCustomerLabelText")
	public String getStepTwoNewCustomerLabelText();

	/**
	 * <p>Fetches title of step three of Coverage map search</p>
	 * 
	 * @return String - Step Three Title
	 */
	@JsonProperty("stepThreeTitle")
	public String getStepThreeTitle();

	/**
	 * <p>Fetches sub-title of step three of Coverage map search</p>
	 * 
	 * @return String - Step Three Sub-title
	 */
	@JsonProperty("stepThreeSubTitle")
	public String getStepThreeSubTitle();

	/**
	 * <p>Fetches buy new phone option label for step three of Coverage map search</p>
	 * 
	 * @return String - Step Three buy new phone option label
	 */
	@JsonProperty("stepThreeBuyingPhoneText")
	public String getStepThreeBuyingPhoneText();

	/**
	 * <p>Fetches byop option label for step three of Coverage map search</p>
	 * 
	 * @return String - Step Three BYOP option label
	 */
	@JsonProperty("stepThreeBringOwnPhoneNext")
	public String getStepThreeBringOwnPhoneNext();

	/**
	 * <p>Fetches continue button text of step three of Coverage map search</p>
	 * 
	 * @return String - Step Three Button Continue Text
	 */
	@JsonProperty("stepThreeButtonContinue")
	public String getStepThreeButtonContinue();

	/**
	 * <p>Fetches helptext for step three buy new phone of Coverage map search</p>
	 * 
	 * @return String - Step Three Buy Phone Help Text
	 */
	@JsonProperty("stepThreeBuyingPhoneHelpText")
	public String getStepThreeBuyingPhoneHelpText();

	/**
	 * <p>Fetches helptext for step three byop of Coverage map search</p>
	 * 
	 * @return String - Step Three Bring Own Phone Help Text
	 */
	@JsonProperty("stepThreeBringOwnPhoneHelpText")
	public String getStepThreeBringOwnPhoneHelpText();

	/**
	 * <p>Fetches service provider modal label</p>
	 * 
	 * @return String - Service Provider Modal label
	 */
	@JsonProperty("serviceProviderModalLabel")
	public String getServiceProviderModalLabel();

	/**
	 * <p>Fetches service provider modal name</p>
	 * 
	 * @return String - Service Provider Modal Name
	 */
	@JsonProperty("serviceProviderModalName")
	public String getServiceProviderModalName();

	/**
	 * <p>Fetches Disclaimer text</p>
	 * 
	 * @return String - Disclaimer Text
	 */
	@JsonProperty("disclaimer")
	public String getDisclaimer();

	/**
	 * <p>Fetches Phones Category ID</p>
	 * 
	 * @return String - Phones Category ID
	 */
	@JsonProperty("categoryIdPhones")
	public String getCategoryIdPhones();

	/**
	 * <p>Fetches Sims Category ID</p>
	 * 
	 * @return String - Sims Category ID
	 */
	@JsonProperty("categoryIdSims")
	public String getCategoryIdSims();

	/**
	 * <p>Fetches Phones PLP path</p>
	 * 
	 * @return String - Phones PLP path
	 */
	@JsonProperty("phonesPlpPath")
	public String getPhonesPlpPath();

	/**
	 * <p>Fetches Sims PLP path</p>
	 * 
	 * @return String - Sims PLP path
	 */
	@JsonProperty("simsPlpPath")
	public String getSimsPlpPath();

	/**
	 * <p>Fetches Sims PLP Short url</p>
	 * 
	 * @return String - Sims PLP Short url
	 */
	@JsonProperty("simsPlpShortUrl")
	public String getSimsPlpShortUrl();

	/**
	 * <p>Fetches Phones PLP Short url</p>
	 * 
	 * @return String - Phones PLP Short url
	 */
	@JsonProperty("phonesPlpShortUrl")
	public String getPhonesPlpShortUrl();

	/**
	 * <p>Fetches Service Provider Modal ID</p>
	 * 
	 * @return String - Service Provider Modal ID
	 */
	@JsonProperty("serviceProviderModalId")
	public String getServiceProviderModalId();

	/**
	 * <p>Fetches Service Provider name List</p>
	 * 
	 * @return String - Service Provider name List
	 */
	@JsonProperty("serviceProviderList")
	public String getServiceProviderList();
	
	/**
	 * <p>Fetches Show City/State Flag value</p>
	 * 
	 * @return String - Show City/State Flag
	 */
	@JsonProperty("showCityState")
	public String getShowCityState();

	/**
	 * <p>Fetches Step One summary text</p>
	 * 
	 * @return String - Step One summary
	 */
	@JsonProperty("stepOneSummary")
	public String getStepOneSummary();

	/**
	 * <p>Fetches Step One Image Path</p>
	 * 
	 * @return String - Step One Image Path
	 */
	@JsonProperty("stepOneFileReference")
	public String getStepOneFileReference();

	/**
	 * <p>Fetches Unchanged Step One Image Path</p>
	 * 
	 * @return String - Step One Image Path
	 */
	@JsonProperty("stepOneFileReference")
	public String getStepOneFilePath();

	/**
	 * <p>Fetches Media Alignment for Step One screen</p>
	 * 
	 * @return String - Media Alignment for Step One
	 */
	@JsonProperty("stepOneMediaAlignment")
	public String getStepOneMediaAlignment();

	/**
	 * <p>Fetches Step Two summary text</p>
	 * 
	 * @return String - Step Two summary
	 */
	@JsonProperty("stepTwoSummary")
	public String getStepTwoSummary();

	/**
	 * <p>Fetches Step Two Image Path</p>
	 * 
	 * @return String - Step Two Image Path
	 */
	@JsonProperty("stepTwoFileReference")
	public String getStepTwoFileReference();

	/**
	 * <p>Fetches Unchanged Step Two Image Path</p>
	 * 
	 * @return String - Unchanged Step Two Image Path
	 */
	@JsonProperty("stepTwoFileReference")
	public String getStepTwoFilePath();

	/**
	 * <p>Fetches Media Alignment for Step Two screen</p>
	 * 
	 * @return String - Media Alignment for Step Two
	 */
	@JsonProperty("stepTwoMediaAlignment")
	public String getStepTwoMediaAlignment();

	/**
	 * <p>Fetches hide buy phone helptext flag value</p>
	 * 
	 * @return String - hide buy phone helptext flag
	 */
	@JsonProperty("hideBuyPhoneHelpText")
	public String getHideBuyPhoneHelpText();

	/**
	 * <p>Fetches Buy new phone slide title</p>
	 * 
	 * @return String -stepThreeBuyingPhoneSlideTitle
	 */
	@JsonProperty("stepThreeBuyingPhoneSlideTitle")
	public String getStepThreeBuyingPhoneSlideTitle();

	/**
	 * <p>Fetches Buy new phone slide description</p>
	 * 
	 * @return String -stepThreeBuyingPhoneSlideDesc
	 */
	@JsonProperty("stepThreeBuyingPhoneSlideDesc")
	public String getStepThreeBuyingPhoneSlideDesc();

	/**
	 * <p>Fetches device name help modal label</p>
	 * 
	 * @return String - deviceNameHelpModalLabel
	 */
	@JsonProperty("deviceNameHelpModalLabel")
	public String getDeviceNameHelpModalLabel();

	/**
	 * <p>Fetches device name help modal name</p>
	 * 
	 * @return String - deviceNameHelpModalName
	 */
	@JsonProperty("deviceNameHelpModalName")
	public String getDeviceNameHelpModalName();

	/**
	 * <p>Fetches buy new phone continue button label</p>
	 * 
	 * @return String - buyNewPhoneButtonContinue
	 */
	@JsonProperty("buyNewPhoneButtonContinue")
	public String getBuyNewPhoneButtonContinue();

	/**
	 * <p>Fetches hide bring own phone helptext flag value</p>
	 * 
	 * @return String - hideBringOwnPhoneHelpText
	 */
	@JsonProperty("hideBringOwnPhoneHelpText")
	public String getHideBringOwnPhoneHelpText();

	/**
	 * <p>Fetches Bring Own Phone slide title</p>
	 * 
	 * @return String -stepThreeBringOwnPhoneSlideTitle
	 */
	@JsonProperty("stepThreeBringOwnPhoneSlideTitle")
	public String getStepThreeBringOwnPhoneSlideTitle();

	/**
	 * <p>Fetches Bring Own Phone slide description</p>
	 * 
	 * @return String -stepThreeBringOwnPhoneSlideDesc
	 */
	@JsonProperty("stepThreeBringOwnPhoneSlideDesc")
	public String getStepThreeBringOwnPhoneSlideDesc();

	/**
	 * <p>Fetches bring own phone continue button label</p>
	 * 
	 * @return String - bringOwnPhoneButtonContinue
	 */
	@JsonProperty("bringOwnPhoneButtonContinue")
	public String getBringOwnPhoneButtonContinue();

	/**
	 * <p>Fetches title of step four of Coverage map search</p>
	 * 
	 * @return String - stepFourTitle
	 */
	@JsonProperty("stepFourTitle")
	public String getStepFourTitle();

	/**
	 * <p>Fetches restart coverage search button label</p>
	 * 
	 * @return String - restartButtonLabel
	 */
	@JsonProperty("restartButtonLabel")
	public String getRestartButtonLabel();

	/**
	 * <p>Fetches phone banner title</p>
	 * 
	 * @return String - phoneBannerTitle
	 */
	@JsonProperty("phoneBannerTitle")
	public String getPhoneBannerTitle();

	/**
	 * <p>Fetches phone banner summary</p>
	 * 
	 * @return String - phoneBannerSummary
	 */
	@JsonProperty("phoneBannerSummary")
	public String getPhoneBannerSummary();
	
	/**
	 * <p>Fetches sim banner title</p>
	 * 
	 * @return String - simBannerTitle
	 */
	@JsonProperty("simBannerTitle")
	public String getSimBannerTitle();

	/**
	 * <p>Fetches sim banner summary</p>
	 * 
	 * @return String - simBannerSummary
	 */
	@JsonProperty("simBannerSummary")
	public String getSimBannerSummary();
	
	/**
	 * <p>Fetches flag value to enable change device functionality</p>
	 * 
	 * @return String - enableChangeDevice
	 */
	@JsonProperty("enableChangeDevice")
	public String getEnableChangeDevice();

	/**
	 * <p>Fetches flag value to enable change service provider functionality</p>
	 * 
	 * @return String - enableChangeServiceProvider
	 */
	@JsonProperty("enableChangeServiceProvider")
	public String getEnableChangeServiceProvider();

	/**
	 * <p>Fetches flag value to enable change location functionality</p>
	 * 
	 * @return String - enableChangeLocation
	 */
	@JsonProperty("enableChangeLocation")
	public String getEnableChangeLocation();

	/**
	 * <p>Fetches flag value to enable change phone number functionality</p>
	 * 
	 * @return String - enableChangePhoneNo
	 */
	@JsonProperty("enableChangePhoneNo")
	public String getEnableChangePhoneNo();

	/**
	 * <p>Fetches Device name help Modal ID</p>
	 * 
	 * @return String - deviceHelpModalId
	 */
	@JsonProperty("deviceHelpModalId")
	public String getDeviceHelpModalId();

	/**
	 * <p>Fetches step three text slide title</p>
	 * 
	 * @return String -stepThreeTextSlideTitle
	 */
	@JsonProperty("stepThreeTextSlideTitle")
	public String getStepThreeTextSlideTitle();

	/**
	 * <p>Fetches step three text slide description</p>
	 * 
	 * @return String -stepThreeTextSlideDesc
	 */
	@JsonProperty("stepThreeTextSlideDesc")
	public String getStepThreeTextSlideDesc();

	/**
	 * <p>Fetches show step phone text slide flag value</p>
	 * 
	 * @return String - showTextSlide
	 */
	@JsonProperty("showTextSlide")
	public String getShowTextSlide();

}
