
package com.tracfonecore.core.models.impl.v3;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import javax.annotation.PostConstruct;
import org.apache.sling.models.annotations.injectorspecific.Self;
import com.tracfonecore.core.utils.ApplicationUtil;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.LtoPreApprovalModel;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { LtoPreApprovalModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/spa/commerce/ltopreapproval", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
    public class LtoPreApprovalModelImpl implements LtoPreApprovalModel {

		@Self
	private SlingHttpServletRequest request;

		@PostConstruct
	private void initModel() {
		
	}

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String smartPayConsentLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String smartPayTcpaConsentLink;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String shopPhonesLink;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String linesPerAccountPath;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String smartPayFooterDisclaimer;

	@Override
	public String getSmartPayConsentLink() {
		return smartPayConsentLink;	
	}

	@Override
	public String getSmartPayTcpaConsentLink() {
		return smartPayTcpaConsentLink;	
	}

	@Override
	public String getShopPhonesLink() {
		return ApplicationUtil.getShortUrl(request.getResourceResolver(), shopPhonesLink);
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	@Override
	public String getLinesPerAccountPath() {
		return linesPerAccountPath;	
	}

	@Override
	public String getSmartPayFooterDisclaimer() {
		return smartPayFooterDisclaimer;	
	}
    
}
