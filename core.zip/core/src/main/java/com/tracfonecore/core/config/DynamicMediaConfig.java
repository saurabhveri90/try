package com.tracfonecore.core.config;


import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Dynamic Media Configuration", description = "Dynamic Media Configuration")
public @interface DynamicMediaConfig {
	
    
    @AttributeDefinition(name = "Universal Image Aspect Ration",description = "Aspect Ratio for dynamic media to be followed throughout the website", type = AttributeType.STRING)
    String getAspectRatio() default "4:3";
    
    @AttributeDefinition(name = "BreakPoints",description = "Breakpoints for dynamic media to be followed throughout the website", type = AttributeType.STRING)
    String getBreakPoint() default "375,768,1024,1280";
    
    @AttributeDefinition(name = "Image Preset",description = "Aspect Ratio for dynamic media to be followed throughout the website", type = AttributeType.STRING)
    String getImagePreset() default "TF-ResponsiveImagePreset";

    @AttributeDefinition(name = "Image Preset",description = "Aspect Ratio for dynamic media to be followed throughout the website", type = AttributeType.STRING)
    String getImageProfilePath() default "/conf/global/settings/dam/adminui-extension/imageprofile/ST-Image-Smartcrop-Profile";
    
}
