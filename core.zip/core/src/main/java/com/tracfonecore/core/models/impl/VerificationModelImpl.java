/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;


import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.beans.VerificationOptBean;
import com.tracfonecore.core.models.VerificationModel;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { VerificationModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/verification", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class VerificationModelImpl implements VerificationModel {

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private Resource resource;

	@ScriptVariable
	private ValueMap properties;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ctaText;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ctaAccessibility;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String heading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String summary;

	private List<VerificationOptBean> verificationOptions = Collections.emptyList();

	private static final Logger LOGGER = LoggerFactory.getLogger(VerificationModelImpl.class);

	//Constants
	private static final String OPTIONS = "verificationOptions";

	@PostConstruct
	private void initModel() {

		verificationOptions = new ArrayList<>();

		for (Resource child : resource.getChildren()) {
			if(OPTIONS.equals(child.getName()))
			{
				Iterator<Resource> it = child.listChildren();
				setMultiFieldItems(it, verificationOptions);
			}
		}
	}
	/**
	 * <p>Populates a list with all the multi-options</p>
	 *
	 * @param it - iterator of the parent node
	 * @param multiFieldData - list in which the multi options data needs to be set
	 */

	private void setMultiFieldItems(Iterator<Resource> it, List<VerificationOptBean> multiFieldData) {
		LOGGER.debug("Entering setMultiFieldItems method");	
		VerificationOptBean optBean = null;
		while (it.hasNext()) {
			optBean = new VerificationOptBean();
			Resource grandChild = it.next();
			optBean.setVerificationType(grandChild.getValueMap().get("verificationType", String.class));
			optBean.setLabel(grandChild.getValueMap().get("optionLabel", String.class));
			multiFieldData.add(optBean);
		}

		LOGGER.debug("Exiting setMultiFieldItems method ");
	}

	/**
	 * <p>Fetches all the multi-options</p>
	 *
	 * @return List - all the multi-options
	 */
	@Override
	public List<VerificationOptBean> getVerificationOptions() {
		return new ArrayList<>(verificationOptions);
	}

	/**
	 * @return String - exportedType
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>Fetches CTA text</p>
	 *
	 * @return String - CTA text
	 */
	@Override
	public String getCtaText() {
		return ctaText;
	}

	/**
	 * <p>Fetches CTA Accessibility label</p>
	 *
	 * @return String - CTA Accessibility label
	 */
	@Override
	public String getCtaAccessibility() {
		return ctaAccessibility;
	}

	/**
	 * <p>Fetches heading for Verification section</p>
	 * 
	 * @return String - heading for Verification section
	 */
	@Override
	public String getHeading() {
		return heading;
	}

	/**
	 * <p>Fetches summary for Verification section</p>
	 *
	 * @return String - summary for Verification section
	 */
	@Override
	public String getSummary() {
		return summary;
	}


}