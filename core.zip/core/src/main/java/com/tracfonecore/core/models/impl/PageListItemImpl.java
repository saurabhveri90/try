
package com.tracfonecore.core.models.impl;

import java.util.Calendar;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import com.adobe.cq.wcm.core.components.internal.models.v2.PageImpl;
import com.day.cq.wcm.api.Page;
import com.drew.lang.annotations.NotNull;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.models.ListModelItem;
import com.tracfonecore.core.utils.ApplicationUtil;
/**
 * @author vijaykumar.tripathi
 *
 */
public class PageListItemImpl implements ListModelItem {

    protected SlingHttpServletRequest request;
    protected Page page;

    public PageListItemImpl(@NotNull SlingHttpServletRequest request, @NotNull Page page) {
        this.request = request;
        this.page = page;
    }

	@Override
	public String getURL() {
		String url = page.getProperties().get(PageImpl.PN_REDIRECT_TARGET, String.class);
		if (StringUtils.isEmpty(url)) {
			url = page.getVanityUrl();
		} 
		if (StringUtils.isEmpty(url)) {
			url = page.getPath();
		}
        return ApplicationUtil.getShortUrl(request.getResourceResolver(), url);
	}

    @Override
    public String getTitle() {
        String title = page.getNavigationTitle();
        if (title == null) {
            title = page.getPageTitle();
        }
        if (title == null) {
            title = page.getTitle();
        }
        if (title == null) {
            title = page.getName();
        }
        return title;
    }

    @Override
    public String getDescription() {
        return page.getDescription();
    }

    @Override
    public Calendar getLastModified() {
        return page.getLastModified();
    }

    @Override
    public String getPath() {
        return page.getPath();
    }

    @Override
    @JsonIgnore
    public String getName() {
        return page.getName();
    }
    
    @Override
    public String getIconPath() {
    	Resource res = page.getContentResource(ApplicationConstants.IMAGE);
    	String iconPath = "";
		if (res != null) {
			iconPath = res.getValueMap().get(ApplicationConstants.FILEREFERENCE,String.class);
			
		}
        return iconPath;
    }
    @Override
	public String getS7thumbnailurl() {
		return com.tracfonecore.core.utils.DynamicMediaUtils.changeMediaPathToDMPath(getIconPath(),
				request.getResourceResolver());
	}

}
