/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Column-Control} Sling Model used for the {@code /apps/tracfone-core/components/commerce/recommendedplan} component.
 */
public interface RecommProductModel extends ComponentExporter {

	/**
	 * <p>Fetches page path for the Recommended Product detail page</p>
	 * 
	 * @return the pagePath
	 */
	@JsonProperty("pagePath")
	public String getPagePath();

    /**
     * Get ratings of the product(i.e. "0 to 5")
     * @return Ratings
     */
    public String getRating();
	
    /**
     * Get reviews of the product
     * @return Reviews
     */
    public String getReviews();

	/**
	 * <p>Fetches queryString for the price api call</p>
	 *
	 * @return String - queryString
	 */
	@JsonProperty("queryString")
	String getQueryString();

	/**
	 * <p>Fetches Plan Name for the Recommended Plan</p>
	 *
	 * @return the planName
	 */
	@JsonProperty("planName")
	public String getPlanName();

	/**
	 * <p>Fetches Plan Description for the Recommended Plan</p>
	 *
	 * @return the planDescription
	 */
	@JsonProperty("priceDescription")
	public String getPriceDescription();

	/**
	 * <p>Fetches Plan Data Descrtiption for the Recommended Plan</p>
	 *
	 * @return the planDataDescription
	 */
	@JsonProperty("planDataDescription")
	public String getPlanDataDescription();

	/**
	 * <p>Fetches price superscript for the product</p>
	 *
	 * @return String - pricesuperscript
	 */
	@JsonProperty("pricesuperscript")
	public String getPriceSuperScript();

	/**
	 * <p>Fetches promotext of the product</p>
	 *
	 * @return String - promotext
	 */
	@JsonProperty("promotext")
	public String getPromoText();

	/**
	 * <p>Fetches plan Data Label of the product</p>
	 *
	 * @return String - planDataLabel
	 */
	@JsonProperty("planDataLabel")
	public String getPlanDataLabel();

	/**
	 * <p>Fetches price Accessibility Label of the product</p>
	 *
	 * @return String - priceAccessibilityLabel
	 */
	@JsonProperty("priceAccessibilityLabel")
	public String getPriceAccessibilityLabel();

	public String getPlanData();

	public String getPlanTalkMinutes();

	public String getApiDomain();

	public String getPriceApiPath();

	public String getSkuId();

	public String getLanguage();

	public String getAccessibilityRating();

	/**
	 * <p>Fetches enableButtonForProductCards</p>
	 *
	 * @return String - enableButtonForProductCards
	 */
	@JsonProperty("enableButtonForProductCards")
	public String getEnableButtonForProductCards();
}
