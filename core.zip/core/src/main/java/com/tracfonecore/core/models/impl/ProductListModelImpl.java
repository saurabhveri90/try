/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.Objects;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.export.json.SlingModelFilter;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.tracfonecore.core.beans.ProductFilterBean;
import com.tracfonecore.core.beans.ProductListFilterBean;
import com.tracfonecore.core.beans.SpecsBean;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.PlpPagesModel;
import com.tracfonecore.core.models.ProductListModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.services.ProductOfferingApiService;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.services.TracfoneApplicationConfigService;
import com.tracfonecore.core.services.TracfoneValueMappingConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;
import com.tracfonecore.core.utils.ConfigurationUtil;
import com.tracfonecore.core.utils.DynamicMediaUtils;
import com.tracfonecore.core.utils.ItemsExporterUtil;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { ProductListModel.class,
		ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/productlist", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ProductListModelImpl extends BaseComponentModelImpl implements ProductListModel {

	@Self
	private SlingHttpServletRequest request;

	private ResourceResolver resourceResolver;

	@Inject
	private SlingModelFilter slingModelFilter;

	@Inject
	private ModelFactory modelFactory;

	@Inject
	private TracfoneApiGatewayService tracfoneApiService;

	@Inject
	private TracfoneApplicationConfigService tracfoneApplicationConfigService;

	@Inject
	private ApplicationConfigService applicationConfigService;

	@Inject
	private TracfoneValueMappingConfigService tracfoneValueMappingConfigService;

	@Inject
	private ProductOfferingApiService productOfferingApiService;

	private static final Logger LOGGER = LoggerFactory.getLogger(ProductListModelImpl.class);

	@Inject
	private Resource resource;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String productTypeLabel;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String hideProductTypes;

	/**
	 * Inject the Links multifield
	 */
	@Inject
	@Via("resource")
	private Resource prodTypeList;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String hideSortingDropdown;

	/**
	 * Inject the Links multifield
	 */
	@Inject
	@Via("resource")
	private Resource sortingList;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String hideAllFilters;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String allFiltersLabel;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String clearAllLabel;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String optionsCtaLabel;

	/**
	 * Inject the Links multifield
	 */
	@Inject
	@Via("resource")
	private Resource filterTypeList;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String hideZipCode;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String zipCodeLabel;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String hideUpgradeBox;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String upgradeHeaderLabel;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String upgradeSubtextLabel;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String inputPlaceholderText;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String upgradeButtonLabel;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String upgradeEligibleLabel;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String changeNumberButtonLabel;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String turnOffPromoCard;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String turnOnAnotherPromoCard;

	/**
	 * Inject the Numberfield
	 */
	@Inject
	@Via("resource")
	@Default(intValues = 11)
	private int defaultNoOfCards;

	/**
	 * Inject the textfield
	 */
	@Inject
	@Via("resource")
	private String filterPromoPlans;

	/**
	 * Inject the textfield
	 */
	@Inject
	@Via("resource")
	private String filterDeviceByManufacturer;

	/**
	 * Inject the Numberfield
	 */
	@Inject
	@Via("resource")
	@Default(intValues = 12)
	private int noOfCardsOnScroll;

	/**
	 * Inject the Numberfield
	 */
	@Inject
	@Via("resource")
	@Default(intValues = 15)
	private int sortOutofStock;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String productButtonLabel;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String compareLinkLabel;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Default(values = "false")
	@Via("resource")
	private String disableCompare;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String buttonNotifyLabel;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String productOutOfStockBannerText;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String compareTabDescription;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String compareButtonLabel;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String compareButtonLink;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	@Default(values = "plp")
	private String pagetype;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String plpPlantext;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String plpPlanSubtext;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String plpFlowHeader;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String plpFlowSubtext;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String plpHeader;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String pdpJsonPath;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String smartpayHeader;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String smartpaySubtext;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String smartpayButtonLabel;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String smartpayButtonDescription;

	/**
	 * Inject the check box field
	 */
	@Inject
	@Default(values = "false")
	@Via("resource")
	private String disableBazaarVoiceRatings;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String seeDetailLinkLabel;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String tncLinkLabel;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String hppLoginRedirectLink;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String hppGuestRedirectLink;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String disableGuestCheckout;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String disableRefill;

	/**
	 * Inject the pathbrowser
	 */
	@Inject
	@Via("resource")
	private String externalPlanPagePath;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String externalPlanPagePathTarget;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String currentProductBannerText;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String otherPlansHeading;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String otherPlansDescription;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String plansPlpLink;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String hideRecaptchaBox;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String showPhoneNoField;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String showAutoRefillPlans;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String allFiltersCountLabel;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String hideRewardsSection;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String rewardsTitle;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String rewardsDescription;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String loginLinkLabel;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String loginLinkPath;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String redeemLabel;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String redeemDescription;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String redeemButtonLabel;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String redeemButtonPath;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String showTimer;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String showTimerAboveUpgrade;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String applyServicePlanFacet;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String applyPurchasePlanFacet;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String combineAllProductFacet;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String turnOffSeparateHppCard;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String recommCardPromoText;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String otherProtectionPlansHeading;

	@Inject
	@Via("resource")
	private String dealsCategoryId;

	@Inject
	@Via("resource")
	private String planCardButton1;

	@Inject
	@Via("resource")
	private String planCardButton2;

	@Inject
	@Via("resource")
	private Resource phoneCardInfo;

	@Inject
	@Via("resource")
	private String recommendationsForYou;

	@Inject
	@Via("resource")
	private String contactLabel;

	@Inject
	@Via("resource")
	private String serviceEndDate;

	@Inject
	@Via("resource")
	private String selectDifferentNumber;

	@Inject
	@Via("resource")
	private String enterDifferentNumber;

	@Inject
	@Via("resource")
	private String refillPagePath;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String phonePromoText1;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String phonePromoText2;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String autoRefillEnrolledPromoText;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String checkoutRedirectLink;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String guestRedirectLink;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String refillFlowPlpPath;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	@Default(values = "no")
	private String campaigntype;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String campaignFacetId;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String hideBannerWCampaign;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String tmoSimPdpUrl;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String vzwSimPdpUrl;

	/**
	 * Inject the Links multifield
	 */
	@Inject
	@Via("resource")
	private Resource campaignNamesList;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private Boolean enableMultipleLayout;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private Boolean hideUpgradeRecommendations;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String checkAvailabilityLabel;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")

	private Boolean showUpgradeCollapsed;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private Boolean showTitleAboveUpgrade;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	@Default(values = "false")
	private String hideUserInfo;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String showCheckAvailability;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String discountText;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String financingOptionsPath;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String showMldPlanPromo;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String multiLineHeader;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String multilineDiscountHeader;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String multiLineSubHeader;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private Boolean showMultiLineSelector;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private Boolean showPaymentFrequency;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String enableDynamicPricing;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String showPreApprovalSection;

	/**
	 * Inject the field
	 */
	@Inject
	@Via("resource")
	private String selectedPlanPartNo;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String acpFacetId;

	/**
	 * Inject the Checkbox
	 */
	@Inject
	@Via("resource")
	private String duplicateMldCards;

	/**
	 * Inject the Checkbox
	 */
	@Inject
	@Via("resource")
	private String useSmallPlanCard;

	/**
	 * Inject the fccDisclaimerText
	 */
	@Inject
	@Via("resource")
	private String fccDisclaimerText;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String viewBrochurePath;

	/**
	 * Inject the asurionPlansDisclaimer
	 */
	@Inject
	@Via("resource")
	private String asurionPlansDisclaimer;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String remoteAlertPlanFacetId;

	/**
	 * Inject the checkbox
	 */
	@Inject
	@Via("resource")
	private String enableMultiMonthPlan;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String multiMonthCardPromoText;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String multiMonthPriceSavingsLbl;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String multiMonthPriceSubScript;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String multiMonthPricePromoText;

	/**
	 * Inject the Checkbox
	 */
	@Inject
	@Via("resource")
	private String showMultiMonthPromoCard;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String multiMonthPromoCardPartNo;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String multiMonthPromoCardPromoText;

	/**
	 * Inject the RTE
	 */
	@Inject
	@Via("resource")
	private String multiMonthSaveHeader;

	/**
	 * Inject the RTE
	 */
	@Inject
	@Via("resource")
	private String multiMonthDiscountText;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String multiMonthSelectBtnLbl;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String homeInternetDiscountPrice;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String retailPriceLabel;


	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String twentyFivePlanPartClass;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String twentyFivePlanPartNumber;


	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String twentyFivePlanTitle;


	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String twentyFivePlanDescription;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String twentyFivePlanButtonTitle;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String twentyFivePlanCardTypeTitle;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String twentyFivePlanCardTypeSubTitle;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String twentyFivePlanCardTitle;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String twentyFivePlanCardDescription;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String twentyFivePlanCardLearnMore;
	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String byopMainText;
	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String dcotPromoEligiblePlans;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String dcotPromoEligiblePlansSubText;
	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String dcotPromoOtherPlans;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String dcotPromoOtherPlansSubText;

	@Inject
	@Via("resource")
	private String dcotNonEligiblePlanModel;

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String byopCtaText;

	@Inject
	private Page currentPage;

	private Page homePage;
	private String brand;
	private String language;
	private String jsonPagePath;
	private String categoryId;
	private String categoryType;
	private String planAddonPlp;
	private String subCategoryType;
	private String title;
	private String deviceTypeParam;
	private String approvalUrl;
	private String declineUrl;
	private String amountDeclineUrl;
	private String zeroOfferDenialUrl;
	private String coldFlashModalId;
	private String hotFlashModalId;
	private String specsOptions;
	private String planServiceDaysLabel;
	List<String> dataUnitConversionList = Collections.emptyList();
	private Map<String, Object> propertyValueMap;
	private Map<String, Object> brandPagePropertyVm;
	private ObjectMapper mapper;
	private String recommendedProductsPartNoList;
	private String multilinePlanText;
	private String disclaimerVisibleText;
	private String disclaimerAccordionText;
	private String disclaimerCollapseLabel;
	private String disclaimerExpandLabel;
	private String disclaimerCTALabel;
	private String disclaimerAccessibilityText;
	private String disclaimerCTALink;
	private String plansIconPath;
	private String plansPdpIconPath;

	private String readmoreCTALabel;
	private String readmoreAccessibilityText;
	private String readmoreCTALink;


	/* Constants */
	private static final String HPP_STANDALONE_PATH = "hppStandalonePath";
	private static final String ORDER_CONFIRMATION_PAGE_PATH = "orderConfirmPagePath";
	private static final String CHANGE_DEVICE_PATH = "changeDevicePath";
	private static final String CART_PAGE_PATH = "cartPagePath";
	private static final String DEFAULT_PLAN_THUMBNAIL_IMAGE = "defaultPlanThumbnailImage";
	private static final String DEFAULT_HPP_THUMBNAIL_IMAGE = "defaultHppThumbnailImage";
	private static final String SMART_PAY_LOGO_IMAGE = "smartPayLogoImage";
	private static final String DEFAULT_APPLE_CARE_THUMBNAIL_IMAGE = "defaultAppleCareHppThumbnailImage";
	private static final String RECOMMENDED_CARD_INFO = "recommendedCardInfo";
	private static final String PDP_PAGE_PATH = "pdpPagePath";
	private static final String HIDE_BUNDLE_PLAN_CARD = "hideBundlePlanCard";
	private static final String PRICE_UPDATE = "priceUpdate";
	private static final String ENABLESORT = "enableSort";

	private Map<Integer, String> paymentFreqency = new TreeMap();
	private String paymentFrequencyLabel = StringUtils.EMPTY;

	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering initModel method");

		JsonObject jsonObject = null;
		JsonArray jsonArray = null;

		super.initModel();

		String[] properties = { CommerceConstants.BRANDNAME, CommerceConstants.BUY_NOW_REWARDS_HELP_TEXT,
				CommerceConstants.THRESHOLD_LABEL,
				CommerceConstants.SINGLE_BUCKET_TEXT, CommerceConstants.SINGLE_BUCKET_UNIT,
				CommerceConstants.THRESHOLD_VALUE,
				CommerceConstants.THRESHOLD_UNIT, CART_PAGE_PATH, CHANGE_DEVICE_PATH, ORDER_CONFIRMATION_PAGE_PATH,
				HPP_STANDALONE_PATH };
		this.propertyValueMap = CommerceUtil.getMultiplePagePropertyValue(currentPage, getHomePageLevel(), properties);

		String[] brandPageProperties = { DEFAULT_PLAN_THUMBNAIL_IMAGE, CommerceConstants.NUMBER_OF_LINES,
				DEFAULT_HPP_THUMBNAIL_IMAGE, SMART_PAY_LOGO_IMAGE, DEFAULT_APPLE_CARE_THUMBNAIL_IMAGE,
				HIDE_BUNDLE_PLAN_CARD,ENABLESORT, PRICE_UPDATE };
		this.brandPagePropertyVm = CommerceUtil.getMultiplePagePropertyValue(currentPage, getBrandPageLevel(),
				brandPageProperties);
		this.brand = CommerceUtil.getPropertyValue(this.propertyValueMap, CommerceConstants.BRANDNAME);
		this.language = CommerceUtil.getLanguage(currentPage, getHomePageLevel());
		this.homePage = CommerceUtil.getHomePage(currentPage, getHomePageLevel());

		resourceResolver = request.getResourceResolver();
		mapper = new ObjectMapper();
		setUnitValues();

		jsonArray = new JsonArray();
		for (Resource child : resource.getChildren()) {
			if (RECOMMENDED_CARD_INFO.equals(child.getName())) {
				Iterator<Resource> it = child.listChildren();
				setMultiFieldItems(it, jsonArray);
			}
		}
		jsonObject = new JsonObject();
		jsonObject.add(CommerceConstants.PART_NUMBER, jsonArray);
		recommendedProductsPartNoList = jsonObject.toString();

		ValueMap currentPageVm = currentPage.getContentResource().getValueMap();
		if (currentPageVm != null) {
			Page parentPage = currentPage.getParent();
			ValueMap parentVm = Optional.ofNullable(parentPage).map(Page::getContentResource)
					.filter(Objects::nonNull).map(Resource::getValueMap).orElse(null);
			String catType = currentPageVm.get("categorytype", String.class);
			if (pagetype.equals("purchaseflow") || pagetype.equals("activation") || pagetype.equals("refill")
					|| pagetype.equals("mld")) {
				Resource plpPageResource = resourceResolver.getResource(pdpJsonPath);
				if (plpPageResource != null) {
					Page plpPage = plpPageResource.adaptTo(Page.class);
					if (plpPage != null) {
						ValueMap plpVm = plpPage.getContentResource().getValueMap();
						categoryType = plpVm.get("categorytype", String.class);
						categoryId = plpVm.get("categoryId", String.class);
						planAddonPlp = plpVm.get("planAddonPlp", "false");
						subCategoryType = plpVm.get(CommerceConstants.SUB_CATEGORY_TYPE, String.class);
						multilinePlanText = plpVm.get("multilineSubheading", String.class);
						disclaimerVisibleText = plpVm.get("disclaimerVisibleText", String.class);
						disclaimerAccordionText = plpVm.get("disclaimerAccordionText", String.class);


						disclaimerCollapseLabel = plpVm.get("disclaimerCollapseLabel", String.class);
						disclaimerExpandLabel = plpVm.get("disclaimerExpandLabel", String.class);
						disclaimerCTALabel = plpVm.get("disclaimerCTALabel", String.class);
						disclaimerAccessibilityText = plpVm.get("disclaimerAccessibilityText", String.class);
						disclaimerCTALink = plpVm.get("disclaimerCTALink", String.class);
						plansIconPath = plpVm.get("plansIconPath", String.class);
						readmoreCTALabel = plpVm.get("readmoreCTALabel", String.class);
						readmoreAccessibilityText = plpVm.get("readmoreAccessibilityText", String.class);
						readmoreCTALink = plpVm.get("readmoreCTALink", String.class);
					}
				}
			} else {
				categoryType = catType;
				categoryId = currentPageVm.get("categoryId", String.class);
				String createJsonProperty = currentPageVm.get("createjson", String.class);
				planAddonPlp = currentPageVm.get("planAddonPlp", "false");
				subCategoryType = currentPageVm.get(CommerceConstants.SUB_CATEGORY_TYPE, String.class);
				multilinePlanText = currentPageVm.get("multilineSubheading", String.class);

				if(StringUtils.isNotBlank(createJsonProperty) && "yes".equalsIgnoreCase(createJsonProperty)){
					disclaimerVisibleText = currentPageVm.get("disclaimerVisibleText", String.class);
					disclaimerAccordionText = currentPageVm.get("disclaimerAccordionText", String.class);
					disclaimerCollapseLabel = currentPageVm.get("disclaimerCollapseLabel", String.class);
					disclaimerExpandLabel = currentPageVm.get("disclaimerExpandLabel", String.class);
					disclaimerCTALabel = currentPageVm.get("disclaimerCTALabel", String.class);
					disclaimerAccessibilityText = currentPageVm.get("disclaimerAccessibilityText", String.class);
					disclaimerCTALink = currentPageVm.get("disclaimerCTALink", String.class);
					plansIconPath = currentPageVm.get("plansIconPath", String.class);

					readmoreCTALabel = currentPageVm.get("readmoreCTALabel", String.class);
					readmoreAccessibilityText = currentPageVm.get("readmoreAccessibilityText", String.class);
					readmoreCTALink = currentPageVm.get("readmoreCTALink", String.class);
				} else if( parentVm != null){
					disclaimerVisibleText = parentVm.get("disclaimerVisibleText", String.class);
					disclaimerAccordionText = parentVm.get("disclaimerAccordionText", String.class);
					disclaimerCollapseLabel = parentVm.get("disclaimerCollapseLabel", String.class);
					disclaimerExpandLabel = parentVm.get("disclaimerExpandLabel", String.class);
					disclaimerCTALabel = parentVm.get("disclaimerCTALabel", String.class);
					disclaimerAccessibilityText = parentVm.get("disclaimerAccessibilityText", String.class);
					disclaimerCTALink = parentVm.get("disclaimerCTALink", String.class);
					plansIconPath = parentVm.get("plansIconPath", String.class);

					readmoreCTALabel = parentVm.get("readmoreCTALabel", String.class);
					readmoreAccessibilityText = parentVm.get("readmoreAccessibilityText", String.class);
					readmoreCTALink = parentVm.get("readmoreCTALink", String.class);
				}


				if (StringUtils.isBlank(categoryId) && parentVm != null) {
					categoryType = parentVm.get("categorytype", String.class);
					categoryId = parentVm.get("categoryId", String.class);
					planAddonPlp = parentVm.get("planAddonPlp", "false");
					subCategoryType = currentPageVm.get(CommerceConstants.SUB_CATEGORY_TYPE, String.class);
					multilinePlanText = parentVm.get("multilineSubheading", String.class);
				}
			}

			if(StringUtils.isNotBlank(plansIconPath)){
				plansPdpIconPath = plansIconPath.replace(".svg", "-pdp.svg");
			}

			jsonPagePath = StringUtils.equalsIgnoreCase(currentPageVm.get("createjson", String.class),
					ApplicationConstants.YES)
					? currentPage.getPath()
					: (parentVm != null
					&& StringUtils.equalsIgnoreCase(parentVm.get("createjson", String.class),
					ApplicationConstants.YES) ? parentPage.getPath() : "");

			if (StringUtils.isBlank(jsonPagePath) && StringUtils.isNotEmpty(catType) && this.homePage != null) {
				PlpPagesModel allPaths = this.homePage.getContentResource().adaptTo(PlpPagesModel.class);
				ObjectNode objNode = mapper.convertValue(allPaths, ObjectNode.class);
				if (objNode.get(catType) != null) {
					jsonPagePath = objNode.get(catType).textValue();
				}
			}
			if (StringUtils.isNotBlank(pdpJsonPath)) {
				Resource getResource = resourceResolver.getResource(pdpJsonPath);
				PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
				Page currentPDPJsonPageVm = pageManager.getContainingPage(getResource);
				if (null != currentPDPJsonPageVm
						&& !currentPDPJsonPageVm.getContentResource().getValueMap().containsKey("createjson")) {
					Page parentPDPJsonPageVm = currentPDPJsonPageVm.getParent();
					pdpJsonPath = StringUtils.equalsIgnoreCase(
							currentPDPJsonPageVm.getContentResource().getValueMap().get("createjson", String.class),
							ApplicationConstants.YES)
							? pdpJsonPath
							: (parentVm != null && StringUtils.equalsIgnoreCase(parentPDPJsonPageVm
									.getContentResource().getValueMap().get("createjson", String.class),
							ApplicationConstants.YES) ? parentPDPJsonPageVm.getPath() : "");
				}
			}
			title = currentPageVm.get(JcrConstants.JCR_TITLE, String.class);
			deviceTypeParam = ApplicationUtil.getDeviceTypeForParam(categoryType,
					ConfigurationUtil.getConfigValue(applicationConfigService.getDeviceTypeParam(), this.brand),
					subCategoryType);
			hotFlashModalId = currentPageVm.get("hotFlashModalId", String.class);
			coldFlashModalId = currentPageVm.get("coldFlashModalId", String.class);
		}

		LOGGER.info("homePage : {}", homePage);
		if(homePage != null && null != homePage.getContentResource().getChild("paymentfreqency")){
			Resource contentResource = homePage.getContentResource();
			if(contentResource != null) {
				ValueMap homeProperties = contentResource.getValueMap();
				paymentFrequencyLabel = homeProperties.get("paymentFrequencyLabel", StringUtils.EMPTY);

				Iterator<Resource> paymentItr = homePage.getContentResource().getChild("paymentfreqency").listChildren();

				LOGGER.info("inside payment check");
				while (paymentItr.hasNext()) {
					try {
						Resource payment = paymentItr.next();
						ValueMap paymentProperties = payment.getValueMap();
						String label = paymentProperties.get("label", StringUtils.EMPTY);
						int month = Integer.parseInt(paymentProperties.get("month", "0"));
						paymentFreqency.put(month, label);
					} catch (NumberFormatException e) {
						System.out.println("Invalid number format for month value: " + e.getMessage());
					}
				}
			}


		}
		LOGGER.debug("Exiting initModel method");

	}


	/**
	 * <p>
	 * Fetches filter data for authored filter facet
	 * </p>
	 *
	 * @return filters data
	 */
	@Override
	public List<ProductListFilterBean> getFilters() {

		ProductFilterBean fiterAttributes;
		ArrayList<ProductFilterBean> fiterAttributesList;
		ProductListFilterBean filterData;
		List<ProductListFilterBean> filterDataList = null;

		JsonObject productData = productOfferingApiService.getCategoryDetailObject(getQueryString(), currentPage,
				false);

		if (null != productData && null != productData.get(CommerceConstants.FILTER_SUMMARY)
				&& productData.get(CommerceConstants.FILTER_SUMMARY).isJsonArray()) {

			Iterator<Resource> filterTypeListIterator = filterTypeList.listChildren();
			filterDataList = new ArrayList<ProductListFilterBean>();
			String[] smartpayFacetIds = tracfoneApplicationConfigService.smartpayFilterFacetId();
			List<String> smartpayFacetList = Arrays.asList(smartpayFacetIds);
			while (filterTypeListIterator.hasNext()) {

				Resource filterListItems = filterTypeListIterator.next();
				ValueMap filterListItemsVm = filterListItems.getValueMap();

				String filterId = filterListItemsVm.get("filterTypeFacetId").toString();
				JsonArray jsonArray;
				jsonArray = productData.get(CommerceConstants.FILTER_SUMMARY).getAsJsonArray();

				if (jsonArray.size() > 0) {
					for (int i = 0; i < jsonArray.size(); i++) {
						JsonObject jsonObject = jsonArray.get(i).getAsJsonObject();
						String value = jsonObject.get(CommerceConstants.VALUE).getAsString();
						if (filterId.equals(value)) {
							fiterAttributesList = new ArrayList<ProductFilterBean>();
							filterData = new ProductListFilterBean();
							JsonArray subFilterArray = jsonObject.get("subFilterSummary").getAsJsonArray();
							for (int j = 0; j < subFilterArray.size(); j++) {
								JsonObject subFilterJsonObj = subFilterArray.get(j).getAsJsonObject();
								fiterAttributes = new ProductFilterBean();
								String facetId = subFilterJsonObj.get(CommerceConstants.VALUE).getAsString();
								Boolean smartpayImageFlag = smartpayFacetList.contains(facetId);
								fiterAttributes.setSubfilterAttribute(
										subFilterJsonObj.get(CommerceConstants.ATTRIBUTE).getAsString());
								fiterAttributes.setSubfilterValue(facetId);
								fiterAttributes.setCount(subFilterJsonObj.get(CommerceConstants.COUNT).getAsString());
								fiterAttributes.setSetSmartPayImage(smartpayImageFlag);
								fiterAttributesList.add(fiterAttributes);
							}
							if (jsonObject.get(CommerceConstants.ATTRIBUTE).getAsString()
									.equalsIgnoreCase(CommerceConstants.CUSTOMER_RANKING)) {
								Collections.sort(fiterAttributesList);
								LOGGER.debug("Sort Rating Data : " + fiterAttributesList.toString());
							}
							filterData.setFilerData(fiterAttributesList);
							filterData.setFilterLabel(filterListItemsVm.get("filterLabel", "").toString());
							filterData.setFilterType(filterListItemsVm.get("filterType", "").toString());
							filterData.setFilterTypeFacetId(filterListItemsVm.get("filterTypeFacetId", "").toString());
							filterData.setDataType(filterListItemsVm.get("dataType", "").toString());
							filterData.setSliderMinValue(filterListItemsVm.get("sliderMinValue", "").toString());
							filterData.setSliderMaxValue(filterListItemsVm.get("sliderMaxValue", "").toString());
							filterData.setSliderStepValue(filterListItemsVm.get("sliderStepValue", "").toString());
							filterData.setShowCheckboxesWithSlider(
									filterListItemsVm.get("showCheckboxesWithSlider", "").toString());
							filterData.setShowCheckboxesWithoutSlider(
									filterListItemsVm.get("showCheckboxesWithoutSlider", "").toString());
							filterData.setCheckboxList(filterListItems.getChild("checkboxList"));
							filterData.setSelectedCheckboxView(
									filterListItemsVm.get("selectedCheckboxView", "").toString());
							filterData.setSubtext(filterListItemsVm.get("subtext", "").toString());
							filterDataList.add(filterData);
						}

					}
				}
			}
			LOGGER.debug("All Filter Data : " + filterDataList.toString());
		}

		return filterDataList;
	}

	/**
	 * <p>
	 * This method is used to device type param for zip to marketing id call
	 *
	 * @return -String : Query String
	 */
	@Override
	public String getDeviceTypeParam() {
		return deviceTypeParam;
	}

	/**
	 * <p>
	 * Fetches category id from parent page
	 * </p>
	 *
	 * @return String - the categoryId
	 */
	@Override
	public String getCategoryId() {
		return categoryId;
	}

	/**
	 * <p>
	 * Fetches category type from parent page properties
	 * </p>
	 *
	 * @return String - the categoryType
	 */
	@Override
	public String getCategoryType() {
		return categoryType;
	}

	/**
	 * @return the planAddonPlp
	 */
	@Override
	public String getPlanAddonPlp() {
		return planAddonPlp;
	}

	/**
	 * @return the jsonPagePath
	 */
	@Override
	public String getJsonPagePath() {
		return jsonPagePath;
	}

	/**
	 * <p>
	 * Fetches title from page properties
	 * </p>
	 *
	 * @return String - the title
	 */
	@Override
	public String getTitle() {
		return title;
	}

	/**
	 * <p>
	 * Fetches text for product type label
	 * </p>
	 *
	 * @return String - the productTypeLabel
	 */
	@Override
	public String getProductTypeLabel() {
		return productTypeLabel;
	}

	/**
	 * <p>
	 * Fetches property to hide product types
	 * </p>
	 *
	 * @return String - the hideprodtypes
	 */
	@Override
	public String getHideProductTypes() {
		return hideProductTypes;
	}

	/**
	 * <p>
	 * Fetches product type list
	 * </p>
	 *
	 * @return Resource - prodTypeList
	 */
	@Override
	public Resource getProdTypeList() {
		return prodTypeList;
	}

	/**
	 * <p>
	 * Fetches default no of card to be displayed on page load
	 * </p>
	 *
	 * @return int - defaultNoOfCards
	 */
	@Override
	public int getDefaultNoOfCards() {
		return defaultNoOfCards;
	}

	/**
	 * <p>
	 * Fetches default no of card to be displayed on page load
	 * </p>
	 *
	 * @return string - filterPromoPlans
	 */
	@Override
	public String getFilterPromoPlans() {
		return filterPromoPlans;
	}

	/**
	 * <p>
	 * Fetches default no of card to be displayed on page load
	 * </p>
	 *
	 * @return string - filterDeviceByManufacturer
	 */
	@Override
	public String getFilterDeviceByManufacturer() {
		return filterDeviceByManufacturer;
	}

	/**
	 * <p>
	 * Fetches no of card to be displayed on scroll
	 * </p>
	 *
	 * @return int - noOfCardsOnScroll
	 */
	@Override
	public int getNoOfCardsOnScroll() {
		return noOfCardsOnScroll;
	}

	/**
	 * <p>
	 * Fetches no of devices to sort
	 * </p>
	 *
	 * @return int - sortOutofStock
	 */
	@Override
	public int getSortOutofStock() {
		return sortOutofStock;
	}

	/**
	 * <p>
	 * Fetches label for product button
	 * </p>
	 *
	 * @return String - the productButtonLabel
	 */
	@Override
	public String getProductButtonLabel() {
		return productButtonLabel;
	}

	/**
	 * <p>
	 * Fetches label for compare link
	 * </p>
	 *
	 * @return String - the compareLinkLabel
	 */
	@Override
	public String getCompareLinkLabel() {
		return compareLinkLabel;
	}

	/**
	 * <p>
	 * Fetches property to hide compare
	 * </p>
	 *
	 * @return String - the disableCompare
	 */
	@Override
	public String getDisableCompare() {
		return disableCompare;
	}

	/**
	 * <p>
	 * Fetches property to hide all filters
	 * </p>
	 *
	 * @return String - the hideAllFilters
	 */
	@Override
	public String getHideAllFilters() {
		return hideAllFilters;
	}

	/**
	 * <p>
	 * Fetches label for all filters link
	 * </p>
	 *
	 * @return String - allFiltersLabel
	 */
	@Override
	public String getAllFiltersLabel() {
		return allFiltersLabel;
	}

	/**
	 * <p>
	 * Fetches label for clear all link
	 * </p>
	 *
	 * @return String - clearAllLabel
	 */
	@Override
	public String getClearAllLabel() {
		return clearAllLabel;
	}

	/**
	 * <p>
	 * Fetches label for options cta label
	 * </p>
	 *
	 * @return String - optionsCtaLabel
	 */
	@Override
	public String getOptionsCtaLabel() {
		return optionsCtaLabel;
	}

	/**
	 * <p>
	 * Fetches propert to hide zip code
	 * </p>
	 *
	 * @return String - hideZipCode
	 */
	@Override
	public String getHideZipCode() {
		return hideZipCode;
	}

	/**
	 * <p>
	 * Fetches label for zip code link
	 * </p>
	 *
	 * @return String - zipCodeLabel
	 */
	@Override
	public String getZipCodeLabel() {
		return zipCodeLabel;
	}

	/**
	 * <p>
	 * Fetches property to hide sorting dropdown
	 * </p>
	 *
	 * @return String - hideSortingDropdown
	 */
	@Override
	public String getHideSortingDropdown() {
		return hideSortingDropdown;
	}

	/**
	 * <p>
	 * Fetches data for sorting list
	 * </p>
	 *
	 * @return Resource - sortingList
	 */
	@Override
	public Resource getSortingList() {
		return sortingList;
	}

	/**
	 * <p>
	 * Fetches property to hide upgrade box
	 * </p>
	 *
	 * @return String - hideUpgradeBox
	 */
	@Override
	public String getHideUpgradeBox() {
		return hideUpgradeBox;
	}

	/**
	 * <p>
	 * Fetches label for upgrade header
	 * </p>
	 *
	 * @return String - upgradeHeaderLabel
	 */
	@Override
	public String getUpgradeHeaderLabel() {
		return upgradeHeaderLabel;
	}

	/**
	 * <p>
	 * Fetches label for upgrade subtext
	 * </p>
	 *
	 * @return String - upgradeSubtextLabel
	 */
	@Override
	public String getUpgradeSubtextLabel() {
		return upgradeSubtextLabel;
	}

	/**
	 * Fetches text for input placeholder
	 *
	 * @return String - inputPlaceholderText
	 */
	@Override
	public String getInputPlaceholderText() {
		return inputPlaceholderText;
	}

	/**
	 * <p>
	 * Fetches label for upgrade button
	 * </p>
	 *
	 * @return String - upgradeButtonLabel
	 */
	@Override
	public String getUpgradeButtonLabel() {
		return upgradeButtonLabel;
	}

	/**
	 * <p>
	 * Fetches text for upgrade eligible label
	 * </p>
	 *
	 * @return String - upgradeEligibleLabel
	 */
	@Override
	public String getUpgradeEligibleLabel() {
		return upgradeEligibleLabel;
	}

	/**
	 * <p>
	 * Fetches label for change number button
	 * </p>
	 *
	 * @return String - changeNumberButtonLabel
	 */
	@Override
	public String getChangeNumberButtonLabel() {
		return changeNumberButtonLabel;
	}

	/**
	 * @return the turnOffPromoCard
	 */
	public String getTurnOffPromoCard() {
		return turnOffPromoCard;
	}

	/**
	 * <p>
	 * Fetches label for notify button
	 * </p>
	 *
	 * @return String - buttonNotifyLabel
	 */
	@Override
	public String getButtonNotifyLabel() {
		return buttonNotifyLabel;
	}

	/**
	 * <p>
	 * Fetches label for out of box banner
	 * </p>
	 *
	 * @return String - productOutOfStockBannerText
	 */
	@Override
	public String getProductOutOfStockBannerText() {
		return productOutOfStockBannerText;
	}

	/**
	 * <p>
	 * Fetches label for compare tab description
	 * </p>
	 *
	 * @return String - compareTabDescription
	 */
	@Override
	public String getCompareTabDescription() {
		return compareTabDescription;
	}

	/**
	 * <p>
	 * Fetches label for compare button
	 * </p>
	 *
	 * @return String - compareButtonLabel
	 */
	@Override
	public String getCompareButtonLabel() {
		return compareButtonLabel;
	}

	/**
	 * <p>
	 * Fetches url for compare button
	 * </p>
	 *
	 * @return String - compareButtonLink
	 */
	@Override
	public String getCompareButtonLink() {
		return ApplicationUtil.getShortUrl(resourceResolver, compareButtonLink);
	}

	/**
	 * @return the pagetype
	 */
	@Override
	public String getPagetype() {
		return pagetype;
	}

	/**
	 * @return the plpPlantext
	 */
	@Override
	public String getPlpPlantext() {
		return plpPlantext;
	}

	/**
	 * @return the plpPlanSubtext
	 */
	@Override
	public String getPlpPlanSubtext() {
		return plpPlanSubtext;
	}


	/**
	 * @return the plpFlowHeader
	 */
	@Override
	public String getPlpFlowHeader() {
		return plpFlowHeader;
	}

	/**
	 * @return the plpFlowSubtext
	 */
	@Override
	public String getPlpFlowSubtext() {
		return plpFlowSubtext;
	}

	/**
	 * @return the plpHeader
	 */
	@Override
	public String getPlpHeader() {
		return plpHeader;
	}

	/**
	 * @return the pdpJsonPath
	 */
	@Override
	public String getPdpJsonPath() {
		return pdpJsonPath;
	}

	/**
	 * @return the smartpayHeader
	 */
	@Override
	public String getSmartpayHeader() {
		return smartpayHeader;
	}

	/**
	 * @return the smartpaySubtext
	 */
	@Override
	public String getSmartpaySubtext() {
		return smartpaySubtext;
	}

	/**
	 * @return the smartpayButtonLabel
	 */
	@Override
	public String getSmartpayButtonLabel() {
		return smartpayButtonLabel;
	}

	/**
	 * @return the smartpayButtonDescription
	 */
	@Override
	public String getSmartpayButtonDescription() {
		return smartpayButtonDescription;
	}

	/**
	 * <p>
	 * Fetches property to hide Bazaar Voice ratings
	 * </p>
	 *
	 * @return String - the disableBazaarVoiceRatings
	 */
	@Override
	public String getDisableBazaarVoiceRatings() {
		return disableBazaarVoiceRatings;
	}

	/**
	 * @return the seeDetailLinkLabel
	 */
	@Override
	public String getSeeDetailLinkLabel() {
		return seeDetailLinkLabel;
	}

	/**
	 * @return the tncLinkLabel
	 */
	@Override
	public String getTncLinkLabel() {
		return tncLinkLabel;
	}

	/**
	 * @return the offerHppTrueFacet
	 */
	@Override
	public String getOfferHppTrueFacet() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getOfferHppTrueFacet(), this.brand);
	}

	/**
	 * @return the planIdFacet
	 */
	@Override
	public String getPlanIdFacet() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getPlanIdFacet(), this.brand);
	}

	/**
	 * @return the activationPlanTypeFacet
	 */
	@Override
	public String getActivationPlanTypeFacet() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getActivationPlanTypeFacet(), this.brand);
	}

	/**
	 * @return the purchasePlanTypeFacet
	 */
	@Override
	public String getPurchasePlanTypeFacet() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getPurchasePlanTypeFacet(), this.brand);
	}

	/**
	 * @return the refillPlanTypeFacet
	 */
	@Override
	public String getRefillPlanTypeFacet() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getRefillPlanTypeFacet(), this.brand);
	}

	/**
	 * @return the servicePlanFacet
	 */
	@Override
	public String getServicePlanFacet() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getServicePlanFacet(), this.brand);
	}

	/**
	 * @return the payGoFacet
	 */
	@Override
	public String getPayGoFacet() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getPayGoFacet(), this.brand);
	}

	/**
	 * @return the defaultPlanThumbnailImage
	 */
	@Override
	public String getDefaultPlanThumbnailImage() {
		return DynamicMediaUtils.changeMediaPathToDMPath(CommerceUtil
				.getPropertyValue(this.brandPagePropertyVm, DEFAULT_PLAN_THUMBNAIL_IMAGE), resourceResolver);
	}

	/**
	 * @return the defaultHppThumbnailImage
	 */
	@Override
	public String getDefaultHppThumbnailImage() {
		return DynamicMediaUtils.changeMediaPathToDMPath(CommerceUtil
				.getPropertyValue(this.brandPagePropertyVm, DEFAULT_HPP_THUMBNAIL_IMAGE), resourceResolver);
	}

	/**
	 * @return the planThumbnailImageAssestId
	 */
	@Override
	public String getPlanThumbnailImageAssestId() {
		return ApplicationUtil.getAssetId(getDefaultPlanThumbnailImage(),
				resourceResolver, ApplicationConstants.IMAGE);
	}

	/**
	 * @return the planThumbnailImageWeberId
	 */
	@Override
	public String getPlanThumbnailImageWeberId() {
		return ApplicationUtil.getAssetMetaDataValue(getDefaultPlanThumbnailImage(),
				resourceResolver, ApplicationConstants.WEBER_ID);
	}

	/**
	 * @return the hppThumbnailImageAssestId
	 */
	@Override
	public String getHppThumbnailImageAssestId() {
		return ApplicationUtil.getAssetId(getDefaultHppThumbnailImage(),
				resourceResolver, ApplicationConstants.IMAGE);
	}

	/**
	 * @return the hppThumbnailImageWeberId
	 */
	@Override
	public String getHppThumbnailImageWeberId() {
		return ApplicationUtil.getAssetMetaDataValue(getDefaultPlanThumbnailImage(),
				resourceResolver, ApplicationConstants.WEBER_ID);
	}

	/**
	 * @return the hppLoginRedirectLink
	 */
	@Override
	public String getHppLoginRedirectLink() {
		return ApplicationUtil.getShortUrl(resourceResolver, hppLoginRedirectLink);
	}

	/**
	 * @return the hppGuestRedirectLink
	 */
	@Override
	public String getHppGuestRedirectLink() {
		return ApplicationUtil.getShortUrl(resourceResolver, hppGuestRedirectLink);
	}

	/**
	 * @return the declineUrl
	 */
	@Override
	public String getCartPagePath() {

		return ApplicationUtil.getShortUrl(resourceResolver,
				CommerceUtil.getPropertyValue(this.propertyValueMap, CART_PAGE_PATH));
	}

	/**
	 * @return the declineUrl
	 */
	@Override
	public String getDeclineUrl() {
		declineUrl = getCartPagePath() + tracfoneApiService.getDeclineUrlParams();
		return declineUrl;
	}

	/**
	 * @return the amountDeclineUrl
	 */
	@Override
	public String getAmountDeclineUrl() {
		amountDeclineUrl = getCartPagePath() + tracfoneApiService.getAmountDeclineUrlParams();
		return amountDeclineUrl;
	}

	/**
	 * @return the approvalUrl
	 */
	@Override
	public String getApprovalUrl() {
		approvalUrl = ApplicationUtil.getShortUrl(resourceResolver,
				CommerceUtil.getPropertyValue(this.propertyValueMap, ORDER_CONFIRMATION_PAGE_PATH))
				+ tracfoneApiService.getApproveUrlParam();
		return approvalUrl;
	}

	/**
	 * @return the zeroOfferDenialUrl
	 */
	@Override
	public String getZeroOfferDenialUrl() {
		zeroOfferDenialUrl = ApplicationUtil.getShortUrl(resourceResolver,
				CommerceUtil.getPropertyValue(this.propertyValueMap, CHANGE_DEVICE_PATH))
				+ tracfoneApiService.getZeroOfferDenialUrlParams();
		return zeroOfferDenialUrl;
	}

	/**
	 * <p>
	 * Fetches home page level property from config
	 * </p>
	 *
	 * @return int - homePageLevel
	 */
	@Override
	public int getHomePageLevel() {

		return applicationConfigService.getHomePageLevel();
	}

	/**
	 * <p>
	 * Fetches brand page level property from config
	 * </p>
	 *
	 * @return int - brandPageLevel
	 */
	@Override
	public int getBrandPageLevel() {

		return applicationConfigService.getBrandPageLevel();
	}

	/**
	 * <p>
	 * Returns language from util
	 * </p>
	 *
	 * @return String - language
	 */
	@Override
	public String getLanguage() {
		return language;
	}

	/**
	 * @return String - brand
	 */
	@Override
	public String getBrand() {
		return brand;
	}

	/**
	 * <p>
	 * Returns apiDomain from configuration
	 * </p>
	 *
	 * @return String - apiDomain
	 */
	@Override
	public String getApiDomain() {
		return tracfoneApiService.getApiDomain();
	}

	/**
	 * <p>
	 * Returns categoryApiPath from configuration
	 * </p>
	 *
	 * @return String - categoryApiPath
	 */
	@Override
	public String getCategoryApiPath() {

		return tracfoneApiService.getCategoryApiPath();
	}

	/**
	 * <p>
	 * Returns MarketingApiPath from configuration
	 * </p>
	 *
	 * @return String - MarketingApiPath
	 */
	@Override
	public String getMarketingApiPath() {

		return tracfoneApiService.getMarketingApiPath();
	}

	/**
	 * <p>
	 * Returns getUpgradeApiPath from configuration
	 * </p>
	 *
	 * @return String - getUpgradeApiPath
	 */
	@Override
	public String getUpgradeApiPath() {

		return tracfoneApiService.getUpgradeEligibilityApiPath();
	}

	/**
	 * @return String - clientID
	 */
	@Override
	public String getClientID() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.getApiClientId(), brand);
	}

	/**
	 * <p>
	 * Returns MarketingIdFacet from configuration
	 * </p>
	 *
	 * @return String - MarketingIdFacet
	 */
	@Override
	public String getMarketingIdFacet() {

		return ConfigurationUtil.getConfigValue(tracfoneApiService.getMarketingIdFacet(), brand);
	}

	/**
	 * <p>
	 * Returns PriceFacet from configuration
	 * </p>
	 *
	 * @return String - PriceFacet
	 */
	@Override
	public String getPriceFacet() {

		return ConfigurationUtil.getConfigValue(tracfoneApiService.getPriceFacet(), brand);
	}

	/**
	 * String is used for marketing API call
	 *
	 * @return String - queryString
	 */
	@Override
	public String getMarketingQueryString() {
		StringBuilder query = new StringBuilder("brandName").append(CommerceConstants.EQUALS_TO).append(brand)
				.append(CommerceConstants.AMPERSAND).append("sourceSystem").append(CommerceConstants.EQUALS_TO)
				.append(tracfoneApiService.getApiSourceSystem()).append(CommerceConstants.AMPERSAND).append("zipCode")
				.append(CommerceConstants.EQUALS_TO);
		return query.toString();
	}

	/**
	 * String is used for category API call
	 *
	 * @return String - queryString
	 */
	@Override
	public String getQueryString() {
		StringBuilder query = new StringBuilder("searchKeyword=*").append(CommerceConstants.AMPERSAND)
				.append(CommerceConstants.CATEGORY_ID).append(CommerceConstants.EQUALS_TO).append(this.getCategoryId());
		return query.toString();
	}

	/**
	 * <p>
	 * Fetches skipPlanType property from config
	 * </p>
	 *
	 * @return String[] - skipPlanType
	 */
	@Override
	public String getSkipPlanType() {

		return applicationConfigService.noPlanCheck();
	}

	/**
	 * <p>
	 * Fetches ReCaptcha SiteKey property from config
	 * </p>
	 *
	 * @return String[] - reCaptchaSiteKey
	 */
	@Override
	public String getReCaptchaSiteKey() {

		return ConfigurationUtil.getConfigValue(applicationConfigService.getReCaptchaSiteKey(), brand);
	}

	/**
	 * <p>
	 * Returns resource mgmt api url from configuration
	 * </p>
	 *
	 * @return String - resource mgmt api url
	 */
	@Override
	public String getResourceMgmtApiPath() {

		return tracfoneApiService.getResourceMgmtApiPath();
	}

	/**
	 * String is used for resource mgmt API call
	 *
	 * @return String - queryString
	 */
	@Override
	public String getResourceMgmtQueryString() {
		String languageCode = org.apache.commons.lang.StringUtils.EMPTY;
		String[] apiLanguageArray = tracfoneApiService.getApiLanguage();
		String languageFromPage = this.language;
		if (StringUtils.isNotBlank(languageFromPage) && apiLanguageArray != null) {
			languageCode = ApplicationUtil.getAPILanguageValue(languageFromPage, apiLanguageArray);
		}
		StringBuilder query = new StringBuilder("brand").append(CommerceConstants.EQUALS_TO).append(brand)
				.append(CommerceConstants.AMPERSAND).append("sourceSystem").append(CommerceConstants.EQUALS_TO)
				.append(tracfoneApiService.getApiSourceSystem())
				.append(CommerceConstants.AMPERSAND).append("lang")
				.append(CommerceConstants.EQUALS_TO).append(languageCode).append(CommerceConstants.AMPERSAND)
				.append("client_id").append(CommerceConstants.EQUALS_TO).append(getClientID());
		return query.toString();
	}

	/**
	 * <p>
	 * Returns exporter type
	 * </p>
	 *
	 * @return String - getexportertype
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}

	/**
	 * <p>
	 * Returns json from items
	 * </p>
	 *
	 * @return Map - items
	 */
	@Override
	public Map<String, ? extends ComponentExporter> getItems() {
		return ItemsExporterUtil.getItems(request, slingModelFilter, modelFactory);
	}

	/**
	 * <p>
	 * Fetches Disable guest checkout flag
	 * </p>
	 *
	 * @return String - Disable guest checkout flag
	 */
	@Override
	public String getDisableGuestCheckout() {
		return disableGuestCheckout;
	}

	/**
	 * <p>
	 * Fetches disable refill
	 * </p>
	 *
	 * @return String - disable refill
	 */
	@Override
	public String getDisableRefill() {
		return disableRefill;
	}

	/**
	 * <p>
	 * Fetches Service plan page path
	 * </p>
	 *
	 * @return String - Service plan page path
	 */
	@Override
	public String getExternalPlanPagePath() {
		return externalPlanPagePath;
	}

	/**
	 * <p>
	 * Fetches Service plan page path target
	 * </p>
	 *
	 * @return String - Service plan page path target
	 */
	@Override
	public String getExternalPlanPagePathTarget() {
		return externalPlanPagePathTarget;
	}

	@Override
	public String getPhoneUpgradeReferrerList() {
		return String.join(",", ConfigurationUtil.getBrandConfigValueMap(brand,
				tracfoneValueMappingConfigService.phoneUpgradeReferrerList()));
	}

	/**
	 * <p>
	 * Fetches banner text for current product
	 * </p>
	 *
	 * @return String - current Product Banner Text
	 */
	@Override
	public String getCurrentProductBannerText() {
		return currentProductBannerText;
	}

	/**
	 * <p>
	 * Fetches heading for other plan section
	 * </p>
	 *
	 * @return String - Other Plans Heading
	 */
	public String getOtherPlansHeading() {
		return otherPlansHeading;
	}

	/**
	 * <p>
	 * Fetches description for other plan section
	 * </p>
	 *
	 * @return String - Other Plans Description
	 */
	public String getOtherPlansDescription() {
		return otherPlansDescription;
	}

	/**
	 * <p>
	 * Fetches description for plansPlpLink
	 * </p>
	 *
	 * @return String - plansPlpLink
	 */
	public String getPlansPlpLink() {
		return plansPlpLink;
	}

	/**
	 * <p>
	 * Fetches hide recaptcha
	 * </p>
	 *
	 * @return String - hide recaptcha
	 */
	@Override
	public String getHideRecaptchaBox() {
		return hideRecaptchaBox;
	}

	/**
	 * <p>
	 * Returns hotFlashModalId from properties
	 * </p>
	 *
	 * @return String - hotFlashModalId
	 */
	@Override
	public String getHotFlashModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(hotFlashModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * <p>
	 * Returns coldFlashModalId from properties
	 * </p>
	 *
	 * @return String - coldFlashModalId
	 */
	@Override
	public String getColdFlashModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(coldFlashModalId) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}

	/**
	 * <p>
	 * Fetches show Phone Number Field
	 * </p>
	 *
	 * @return String - showPhoneNoField
	 */
	public String getShowPhoneNoField() {
		return showPhoneNoField;
	}

	/**
	 * <p>
	 * Fetches show Auto Refill Plans
	 * </p>
	 *
	 * @return String - showAutoRefillPlans
	 */
	public String getShowAutoRefillPlans() {
		return showAutoRefillPlans;
	}

	/**
	 * <p>
	 * Fetches smartpay Logo Small
	 * </p>
	 *
	 * @return the smartpayLogoSmall
	 */
	@Override
	public String getSmartpayLogoSmall() {
		return DynamicMediaUtils.changeMediaPathToDMPath(CommerceUtil
				.getPropertyValue(this.brandPagePropertyVm, "smartPayLogoImage"), resourceResolver);
	}

	/**
	 * <p>
	 * Fetches allFiltersCountLabel
	 * </p>
	 *
	 * @return the allFiltersCountLabel
	 */
	@Override
	public String getAllFiltersCountLabel() {
		return allFiltersCountLabel;
	}

	/**
	 * <p>
	 * Fetches hideRewardsSection
	 * </p>
	 *
	 * @return the hideRewardsSection
	 */
	@Override
	public String getHideRewardsSection() {
		return hideRewardsSection;
	}

	/**
	 * <p>
	 * Fetches rewardsTitle
	 * </p>
	 *
	 * @return the rewardsTitle
	 */
	@Override
	public String getRewardsTitle() {
		return rewardsTitle;
	}

	/**
	 * <p>
	 * Fetches rewardsDescription
	 * </p>
	 *
	 * @return the rewardsDescription
	 */
	@Override
	public String getRewardsDescription() {
		return rewardsDescription;
	}

	/**
	 * <p>
	 * Fetches loginLinkLabel
	 * </p>
	 *
	 * @return the loginLinkLabel
	 */
	@Override
	public String getLoginLinkLabel() {
		return loginLinkLabel;
	}

	/**
	 * <p>
	 * Fetches loginLinkPath
	 * </p>
	 *
	 * @return the loginLinkPath
	 */
	@Override
	public String getLoginLinkPath() {
		return ApplicationUtil.getShortUrl(resourceResolver, loginLinkPath);
	}

	/**
	 * <p>
	 * Fetches redeemLabel
	 * </p>
	 *
	 * @return the redeemLabel
	 */
	@Override
	public String getRedeemLabel() {
		return redeemLabel;
	}

	/**
	 * <p>
	 * Fetches redeemDescription
	 * </p>
	 *
	 * @return the redeemDescription
	 */
	@Override
	public String getRedeemDescription() {
		return redeemDescription;
	}

	/**
	 * <p>
	 * Fetches redeemButtonLabel
	 * </p>
	 *
	 * @return the redeemButtonLabel
	 */
	@Override
	public String getRedeemButtonLabel() {
		return redeemButtonLabel;
	}

	/**
	 * <p>
	 * Fetches redeemButtonPath
	 * </p>
	 *
	 * @return the redeemButtonPath
	 */
	@Override
	public String getRedeemButtonPath() {
		return redeemButtonPath;
	}

	/**
	 * <p>
	 * Method to return showTimer
	 * </p>
	 *
	 * @return String showTimer
	 */
	@Override
	public String getShowTimer() {
		return showTimer;
	}

	/**
	 * <p>
	 * Method to return showTimerAboveUpgrade
	 * </p>
	 *
	 * @return String showTimerAboveUpgrade
	 */
	@Override
	public String getShowTimerAboveUpgrade() {
		return showTimerAboveUpgrade;
	}

	/**
	 * <p>
	 * Method to return singleBucketText
	 * </p>
	 *
	 * @return the singleBucketText
	 */
	@Override
	public String getSingleBucketText() {
		return CommerceUtil.getPropertyValue(this.propertyValueMap, CommerceConstants.SINGLE_BUCKET_TEXT);
	}

	/**
	 * <p>
	 * Method to return singleBucketUnit
	 * </p>
	 *
	 * @return the singleBucketUnit
	 */
	@Override
	public String getSingleBucketUnit() {
		return CommerceUtil.getPropertyValue(this.propertyValueMap, CommerceConstants.SINGLE_BUCKET_UNIT);
	}

	private void setUnitValues() {
		Page resourcePage = currentPage;

		if (pagetype.equals("purchaseflow") || pagetype.equals("activation") || pagetype.equals("refill")
				|| pagetype.equals("mld")) {
			Resource plpPageResource = resourceResolver.getResource(pdpJsonPath);
			if (plpPageResource != null) {
				Page plpPage = plpPageResource.adaptTo(Page.class);
				if (plpPage != null) {
					resourcePage = plpPage;
				}
			}
		}

		ObjectNode objNode = mapper.createObjectNode();
		SpecsBean specsBean = CommerceUtil.getProductSpecificationUnit(resourcePage, getHomePageLevel());
		if (specsBean.getOtherSpecs() != null) {
			specsBean.getOtherSpecs().forEach(entry -> {
				if (StringUtils.equalsIgnoreCase(entry.getIdentifier(), CommerceConstants.PLAN_SERVICE_DAYS)) {
					planServiceDaysLabel = entry.getUnit();
				}
			});
		}
		if (specsBean.getSpecsOptions() != null) {
			objNode.putPOJO(CommerceConstants.SPECS_OPTIONS, specsBean.getSpecsOptions());
		}
		try {
			specsOptions = mapper.writeValueAsString(objNode);
		} catch (JsonProcessingException e) {
			LOGGER.error("ProductListModelImpl :: JsonProcessingException in setUnitValues" + e);
		}
	}

	/**
	 * <p>
	 * Returns planServiceDaysLabel authored
	 * </p>
	 *
	 * @return String - planServiceDaysLabel
	 */
	@Override
	public String getPlanServiceDaysLabel() {
		return planServiceDaysLabel;
	}

	/**
	 * @return the specsOptions
	 */
	@Override
	public String getSpecsOptions() {
		return specsOptions;
	}

	/**
	 * <p>
	 * Method to return singleBucketThresholdValue
	 * </p>
	 *
	 * @return the singleBucketThresholdValue
	 */
	@Override
	public String getSbThresholdValue() {
		return CommerceUtil.getPropertyValue(this.propertyValueMap, CommerceConstants.THRESHOLD_VALUE);
	}

	/**
	 * <p>
	 * Method to return multiBucketThresholdLabel
	 * </p>
	 *
	 * @return the multiBucketThresholdLabel
	 */
	@Override
	public String getThresholdLabel() {
		return CommerceUtil.getPropertyValue(this.propertyValueMap, CommerceConstants.THRESHOLD_LABEL);
	}

	/**
	 * <p>
	 * Fetches property to show service plans
	 * </p>
	 *
	 * @return String - the applyServicePlanFacet
	 */
	@Override
	public String getApplyServicePlanFacet() {
		return StringUtils.isNotBlank(applyServicePlanFacet) ? applyServicePlanFacet : "false";
	}

	/**
	 * <p>
	 * Fetches check for Combine Plan Type Filters for Results
	 * </p>
	 *
	 * @return String - Combine Plan Type Filters for Results
	 */
	@Override
	public String getCombineAllProductFacet() {
		return StringUtils.isNotBlank(combineAllProductFacet) ? combineAllProductFacet : "false";
	}

	/**
	 * <p>
	 * Method to return not show separate recommended hpp card
	 * </p>
	 *
	 * @return String - the turnOffSeparateHppCard
	 */
	@Override
	public String getTurnOffSeparateHppCard() {
		return turnOffSeparateHppCard;
	}

	/**
	 * <p>
	 * Method to return recommCardPromoText
	 * </p>
	 *
	 * @return String - the recommCardPromoText
	 */
	@Override
	public String getRecommCardPromoText() {
		return recommCardPromoText;
	}

	/**
	 * <p>
	 * Method to return otherProtectionPlansHeading
	 * </p>
	 *
	 * @return String - otherProtectionPlansHeading
	 */
	@Override
	public String getOtherProtectionPlansHeading() {
		return otherProtectionPlansHeading;
	}

	/**
	 * <p>
	 * Fetches check for Buy Now Rewards Help Text
	 * </p>
	 *
	 * @return String - Buy Now Rewards Help Text
	 */
	@Override
	public String getBuyNowRewardsHelpText() {
		return CommerceUtil.getPropertyValue(this.propertyValueMap, CommerceConstants.BUY_NOW_REWARDS_HELP_TEXT);
	}

	/**
	 * @return the defaultAppleCareHppThumbnail
	 */
	@Override
	public String getDefaultAppleCareHppThumbnail() {
		return DynamicMediaUtils.changeMediaPathToDMPath(CommerceUtil
				.getPropertyValue(this.brandPagePropertyVm, DEFAULT_APPLE_CARE_THUMBNAIL_IMAGE), resourceResolver);
	}

	/**
	 * <p>
	 * Fetches page path of HPP Standalone landing page
	 * </p>
	 *
	 * @return String - page path of HPP Standalone landing page
	 */
	@Override
	public String getHppStandalonePagePath() {
		return ApplicationUtil.getShortUrl(resourceResolver,
				CommerceUtil.getPropertyValue(this.propertyValueMap, HPP_STANDALONE_PATH));
	}

	/**
	 * <p>
	 * Fetches property to show purchase plans
	 * </p>
	 *
	 * @return String - the applyPurchasePlanFacet
	 */
	@Override
	public String getApplyPurchasePlanFacet() {
		return StringUtils.isNotBlank(applyPurchasePlanFacet) ? applyPurchasePlanFacet : "false";
	}

	/**
	 * <p>
	 * Method to return singleBucketThresholdUnit
	 * </p>
	 *
	 * @return the singleBucketThresholdUnit
	 */
	@Override
	public String getSbThresholdUnit() {
		return CommerceUtil.getPropertyValue(this.propertyValueMap, CommerceConstants.THRESHOLD_UNIT);
	}

	/**
	 * <p>
	 * Method to return isCUSGEnabled
	 * </p>
	 *
	 * @return the isCUSGEnabled
	 */
	@Override
	public String isCUSGEnabled() {
		return (String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
				CommerceConstants.ENABLE_CUSG);
	}

	/**
	 * <p>
	 * Method to return CUSG Logo
	 * </p>
	 *
	 * @return the CUSGLogo
	 */
	@Override
	public String getCusgLogoUrl() {
		return CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(), CommerceConstants.LOGO_CUSG)
				.toString();
	}

	/**
	 * <p>
	 * Method to return cusg promo text
	 * </p>
	 *
	 * @return the cusgPromoText
	 */
	@Override
	public String getCusgPromoText() {
		return (String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
				CommerceConstants.LABEL_PLAN_CUSG_DISCOUNT_TYPE);
	}

	/**
	 * <p>
	 * Method to return cusg disclaimer text
	 * </p>
	 *
	 * @return the cusgDisclaimerText
	 */
	@Override
	public String getCusgDisclaimerText() {
		return (String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
				CommerceConstants.CUSG_DISCLAIMER_TEXT);
	}

	/**
	 * <p>
	 * Method to return cusg alt image text
	 * </p>
	 *
	 * @return the cusgImageAltText
	 */
	@Override
	public String getCusgImgAltText() {
		return (String) CommerceUtil.getPagePropertyValue(currentPage, getHomePageLevel(),
				CommerceConstants.LOGO_ALT_TEXT_CUSG);
	}

	/*
	 * Code Added By Reed Murphy 9/23/2021
	 */
	@Override
	public String getDealsCategoryId() {
		return dealsCategoryId;
	}

	@Override
	public String getPlanCardButton1() {
		return planCardButton1;
	}

	@Override
	public String getPlanCardButton2() {
		return planCardButton2;
	}

	@Override
	public Resource getPhoneCardInfo() {
		return phoneCardInfo;
	}

	@Override
	public String getRecommendationsForYou() {
		return recommendationsForYou;
	}

	@Override
	public String getContactLabel() {
		return contactLabel;
	}

	@Override
	public String getServiceEndDate() {
		return serviceEndDate;
	}

	@Override
	public String getSelectDifferentNumber() {
		return selectDifferentNumber;
	}

	@Override
	public String getEnterDifferentNumber() {
		return enterDifferentNumber;
	}

	@Override
	public String getPhonePromoText1() {
		return phonePromoText1;
	}

	@Override
	public String getPhonePromoText2() {
		return phonePromoText2;
	}

	@Override
	public String getAutoRefillEnrolledPromoText() {
		return autoRefillEnrolledPromoText;
	}

	/**
	 * String is used for deals category API call
	 *
	 * @return String - dealsQueryString
	 */
	@Override
	public String getDealsQueryString() {
		StringBuilder query = new StringBuilder("searchKeyword=*").append(CommerceConstants.AMPERSAND)
				.append(CommerceConstants.CATEGORY_ID).append(CommerceConstants.EQUALS_TO)
				.append(this.getDealsCategoryId());
		return query.toString();
	}

	/**
	 * @return the guestRedirectLink
	 */
	@Override
	public String getGuestRedirectLink() {
		return ApplicationUtil.getShortUrl(resourceResolver, guestRedirectLink);
	}

	/**
	 * @return the checkoutRedirectLink
	 */
	@Override
	public String getCheckoutRedirectLink() {
		return ApplicationUtil.getShortUrl(resourceResolver, checkoutRedirectLink);
	}

	/**
	 * <p>
	 * Populates a list with all the multi-links
	 * </p>
	 *
	 * @param it             - iterator of the parent node
	 * @param multiFieldData - list in which the multi links data needs to be set
	 *
	 */
	private void setMultiFieldItems(Iterator<Resource> it, JsonArray jsonArray) {
		LOGGER.debug("Entering setMultiFieldItems method");

		String partNo = "";
		JsonObject dataObject = null;

		while (it.hasNext()) {
			Resource grandChild = it.next();
			String pdpPagePath = grandChild.getValueMap().get(PDP_PAGE_PATH, String.class);

			if (StringUtils.isNotEmpty(pdpPagePath)) {
				Resource phoneResource = request.getResourceResolver().resolve(pdpPagePath);
				Page productPage = phoneResource.adaptTo(Page.class);
				if (ApplicationUtil.isPdpPage(productPage, tracfoneValueMappingConfigService.pdpTemplateValues())
						&& !ApplicationUtil.isPageDeleted(productPage)) {
					ValueMap vm = request.getResourceResolver().resolve(pdpPagePath + CommerceConstants.JCR_CONTENT)
							.getValueMap();
					partNo = vm.get(CommerceConstants.PART_NO, String.class);
					dataObject = new JsonObject();
					dataObject.addProperty(CommerceConstants.PART_NO, partNo);
					jsonArray.add(dataObject);
				}
			}
		}

		LOGGER.debug("Exiting setMultiFieldItems method ");
	}

	@Override
	public String getRecommendedProductsPartNoList() {
		return recommendedProductsPartNoList;
	}

	@Override
	public String getLogOutRegisteredUserApiPath() {
		return tracfoneApiService.getLogOutRegisteredUserApiPath();
	}

	@Override
	public String getRefillPagePath() {
		return ApplicationUtil.getShortUrl(resourceResolver, refillPagePath);
	}

	@Override
	public String getRefillFlowPlpPath() {
		return ApplicationUtil.getShortUrl(resourceResolver, refillFlowPlpPath);
	}

	/**
	 * @return the campaigntype
	 */
	@Override
	public String getCampaigntype() {
		return campaigntype;
	}

	/**
	 * @return the campaignFacetId
	 */
	@Override
	public String getCampaignFacetId() {
		return campaignFacetId;
	}

	/**
	 * @return the hideBannerWCampaign
	 */
	@Override
	public String getHideBannerWCampaign() {
		return hideBannerWCampaign;
	}

	/**
	 * @return the tmoSimPdpUrl
	 */
	@Override
	public String getTmoSimPdpUrl() {
		return tmoSimPdpUrl;
	}

	/**
	 * @return the vzwSimPdpUrl
	 */
	@Override
	public String getVzwSimPdpUrl() {
		return vzwSimPdpUrl;
	}

	/**
	 * <p>
	 * Fetches data for campaign names list
	 * </p>
	 *
	 * @return Resource - campaignNamesList
	 */
	@Override
	public Resource getCampaignNamesList() {
		return campaignNamesList;
	}

	/**
	 * <p>
	 * Fetches property to show row of two or three
	 * </p>
	 *
	 * @return Boolean - enableMultipleLayout
	 */
	@Override
	public Boolean getEnableMultipleLayout() {
		return enableMultipleLayout;
	}

	/**
	 * <p>
	 * Fetches property to hide upgrade recommendations
	 * </p>
	 *
	 * @return Boolean - hideUpgradeRecommendations
	 */
	@Override
	public Boolean getHideUpgradeRecommendations() {
		return hideUpgradeRecommendations;
	}

	/**
	 * <p>
	 * Fetches property to show upgrade collapsed
	 * </p>
	 *
	 * @return Boolean - showUpgradeCollapsed
	 */
	@Override
	public Boolean getShowUpgradeCollapsed() {
		return showUpgradeCollapsed;
	}

	/**
	 * <p>
	 * Fetches property to show title above upgrade
	 * </p>
	 *
	 * @return Boolean - showTitleAboveUpgrade
	 */
	@Override
	public Boolean getShowTitleAboveUpgrade() {
		return showTitleAboveUpgrade;
	}

	/**
	 * <p>
	 * Fetches hide user info
	 * </p>
	 *
	 * @return String - hideUserInfo
	 */
	@Override
	public String getHideUserInfo() {
		return hideUserInfo;
	}

	/**
	 * <p>
	 * Fetches label for check availability link
	 * </p>
	 *
	 * @return String - checkAvailabilityLabel
	 */
	@Override
	public String getCheckAvailabilityLabel() {
		return checkAvailabilityLabel;
	}

	/**
	 * <p>
	 * Fetches propert to show check availability
	 * </p>
	 *
	 * @return String - checkAvailabilityLabel
	 */
	@Override
	public String getShowCheckAvailability() {
		return showCheckAvailability;
	}

	/**
	 * <p>
	 * Fetches property to show discountText
	 * </p>
	 *
	 * @return String - discountText
	 */
	@Override
	public String getDiscountText() {
		return discountText;
	}

	/**
	 * <p>
	 * Fetches showMldPlanPromo
	 * </p>
	 *
	 * @return String - showMldPlanPromo
	 */
	@Override
	public String getShowMldPlanPromo() {
		return showMldPlanPromo;
	}

	@Override
	public String getFinancingOptionsPath() {
		return ApplicationUtil.getShortUrl(resourceResolver, financingOptionsPath);
	}

	/**
	 * <p>
	 * Fetches showMultiLineSelector Param
	 * </p>
	 *
	 * @return String - showMultiLineSelector Param
	 */

	@Override
	public Boolean getShowMultiLineSelector() {
		return showMultiLineSelector;
	}

	/**
	 * <p>
	 * Fetches showPaymentFrequency Param
	 * </p>
	 *
	 * @return String - showPaymentFrequency Param
	 */
	@Override
	public Boolean getShowPaymentFrequency() {
		return showPaymentFrequency;
	}
	/**
	 * <p>
	 * Fetches paymentFrequencyLabel Param
	 * </p>
	 *
	 * @return String - paymentFrequencyLabel Param
	 */
	@Override
	public String getPaymentFrequencyLabel(){
		return paymentFrequencyLabel;
	}

	/**
	 * <p>
	 * Fetches paymentFreqency Param
	 * </p>
	 *
	 * @return Map - paymentFreqency Param
	 */
	@Override
	public Map<Integer, String> getPaymentFrequencyData() {
		return new TreeMap<>(paymentFreqency);
	}

	/**
	 * <p>
	 * Method to return numberOfLinesList
	 *
	 * @return List numberOfLinesList
	 */
	@Override
	public List<Object> getNumberOfLinesList() {
		int numOfLines = Integer
				.parseInt(CommerceUtil.getPropertyValue(this.brandPagePropertyVm, CommerceConstants.NUMBER_OF_LINES));
		List<Object> list = new ArrayList<>(numOfLines);
		for (int i = 0; i < numOfLines; i++) {
			list.add("");
		}
		return list;
	}

	/**
	 * <p>
	 * Fetches multilineSelectorText Param
	 * </p>
	 *
	 * @return String - multilineSelectorText Param
	 */
	@Override
	public String getMultilinePlanText() {
		return multilinePlanText;
	}

	@Override
	public String getDisclaimerVisibleText() {
		return disclaimerVisibleText;
	}

	@Override
	public String getDisclaimerAccordionText() {
		return disclaimerAccordionText;
	}


	@Override
	public String getDisclaimerCollapseLabel() {
		return disclaimerCollapseLabel;
	}

	@Override
	public String getDisclaimerExpandLabel() {
		return disclaimerExpandLabel;
	}

	@Override
	public String getDisclaimerCTALabel() {
		return disclaimerCTALabel;
	}

	@Override
	public String getDisclaimerAccessibilityText() {
		return disclaimerAccessibilityText;
	}

	@Override
	public String getDisclaimerCTALink() {
		return disclaimerCTALink;
	}

	@Override
	public String getPlansIconPath() {
		return plansIconPath;
	}

	public String getPlansPdpIconPath(){
		return plansPdpIconPath;
	}

	/**
	 * @return the readmoreCTALabel
	 */
	@Override
	public String getReadmoreCTALabel() {
		return readmoreCTALabel;
	}

	/**
	 * @return the readmoreAccessibilityText
	 */
	@Override
	public String getReadmoreAccessibilityText() {
		return readmoreAccessibilityText;
	}

	/**
	 * @return the readmoreCTALink
	 */
	@Override
	public String getReadmoreCTALink() {
		return readmoreCTALink;
	}

	/**
	 * @return the multiLineHeader
	 */
	@Override
	public String getMultiLineHeader() {
		return multiLineHeader;
	}

	/**
	 * @return the multilineDiscountHeader
	 */
	@Override
	public String getMultilineDiscountHeader() {
		return multilineDiscountHeader;
	}

	/**
	 * @return the multiLineSubHeader
	 */
	@Override
	public String getMultiLineSubHeader() {
		return multiLineSubHeader;
	}

	/**
	 * @return the enableDynamicPricing
	 */
	@Override
	public String getEnableDynamicPricing() {
		return enableDynamicPricing;
	}

	/*
	 * Method to return showPreApprovalSection
	 * </p>
	 *
	 * @return String showPreApprovalSection
	 */
	@Override
	public String getShowPreApprovalSection() {
		return showPreApprovalSection;
	}

	/*
	 * Method to return selectedPlanPartNo
	 * </p>
	 *
	 * @return String selectedPlanPartNo
	 */
	@Override
	public String getSelectedPlanPartNo() {
		return selectedPlanPartNo;
	}

	/**
	 * @return the acpFacetId
	 */
	@Override
	public String getAcpFacetId() {
		return acpFacetId;
	}

	/**
	 * @return the duplicateMldCards
	 */
	@Override
	public String getDuplicateMldCards() {
		return duplicateMldCards;
	}

	/**
	 * @return the useSmallPlanCard
	 */
	@Override
	public String getUseSmallPlanCard() {
		return useSmallPlanCard;
	}

	/**
	 * @return the viewBrochurePath
	 */
	@Override
	public String getViewBrochurePath() {
		return viewBrochurePath;
	}

	/**
	 * @return the asurionPlansDisclaimer
	 */
	@Override
	public String getAsurionPlansDisclaimer() {
		return asurionPlansDisclaimer;
	}

	/**
	 * @return the hideBundlePlanCard
	 */
	@Override
	public String getHideBundlePlanCard() {
		return CommerceUtil.getPropertyValue(this.brandPagePropertyVm, HIDE_BUNDLE_PLAN_CARD);
	}

	/**
	 * @return the fccDisclaimerText
	 */
	@Override
	public String getFccDisclaimerText() {
		return fccDisclaimerText;
	}

	/**
	 * @return the remoteAlertPlanFacetId
	 */
	@Override
	public String getRemoteAlertPlanFacetId() {
		return remoteAlertPlanFacetId;
	}

	/**
	 * <p>
	 * Fetches check for Multi month plan
	 * </p>
	 *
	 * @return String(True or false) for Enable Multi Month Plan option
	 */
	@Override
	public String getEnableMultiMonthPlan() {
		return StringUtils.isNotBlank(enableMultiMonthPlan) ? enableMultiMonthPlan : "false";
	}

	/**
	 * <p>
	 * Fetches promo text for Multi month plan card
	 * </p>
	 *
	 * @return String - multiMonthCardPromoText
	 */
	@Override
	public String getMultiMonthCardPromoText() {
		return multiMonthCardPromoText;
	}

	/**
	 * <p>
	 * Fetches text for Multi Month Price Savings Lbl
	 * </p>
	 *
	 * @return String - multiMonthPriceSavingsLbl
	 */
	@Override
	public String getMultiMonthPriceSavingsLbl() {
		return multiMonthPriceSavingsLbl;
	}

	/**
	 * <p>
	 * Fetches text for Multi Month Price SubScript
	 * </p>
	 *
	 * @return String - multiMonthPriceSubScript
	 */
	@Override
	public String getMultiMonthPriceSubScript() {
		return multiMonthPriceSubScript;
	}

	/**
	 * <p>
	 * Fetches promo text for Multi Month Price
	 * </p>
	 *
	 * @return String - multiMonthPricePromoText
	 */
	@Override
	public String getMultiMonthPricePromoText() {
		return multiMonthPricePromoText;
	}

	/**
	 * <p>
	 * Fetches check for Multi month promo card
	 * </p>
	 *
	 * @return String(True or false) for showMultiMonthPromoCard
	 */
	@Override
	public String getShowMultiMonthPromoCard() {
		return StringUtils.isNotBlank(showMultiMonthPromoCard) ? showMultiMonthPromoCard : "false";
	}

	/**
	 * <p>
	 * Fetches part number for multi month promo card
	 * </p>
	 *
	 * @return String - multiMonthPromoCardPartNo
	 */
	@Override
	public String getMultiMonthPromoCardPartNo() {
		return multiMonthPromoCardPartNo;
	}

	/**
	 * <p>
	 * Fetches promo text for Multi Month Promo card
	 * </p>
	 *
	 * @return String - multiMonthPromoCardPromoText
	 */
	@Override
	public String getMultiMonthPromoCardPromoText() {
		return multiMonthPromoCardPromoText;
	}

	/**
	 * <p>
	 * Fetches save text for Multi Month Promo card
	 * </p>
	 *
	 * @return String - multiMonthSaveHeader
	 */
	@Override
	public String getMultiMonthSaveHeader() {
		return multiMonthSaveHeader;
	}

	/**
	 * <p>
	 * Fetches discount text for Multi Month Promo card
	 * </p>
	 *
	 * @return String - multiMonthDiscountText
	 */
	@Override
	public String getMultiMonthDiscountText() {
		return multiMonthDiscountText;
	}

	/**
	 * <p>
	 * Fetches text for Multi Month Select Button Label
	 * </p>
	 *
	 * @return String - multiMonthSelectBtnLbl
	 */
	@Override
	public String getMultiMonthSelectBtnLbl() {
		return multiMonthSelectBtnLbl;
	}

	/**
	 * @return the turnOnAnotherPromoCard
	 */
	public String getTurnOnAnotherPromoCard() {
		return turnOnAnotherPromoCard;
	}

	/**

	 *
	 * @return String - homeInternetDiscountPrice
	 */
	@Override
	public String getHomeInternetDiscountPrice() {
		return homeInternetDiscountPrice;
	}

	/**
	 *<p>Fetches retailPriceLabel</p>
	 *
	 * @return String - retailPriceLabel
	 *
	 *  */
	@Override
	public String getRetailPriceLabel() {
		return retailPriceLabel;

	}

	/**
	 * @return the twentyFivePlanPartClass
	 */
	@Override
	public String getTwentyFivePlanPartClass() {
		return twentyFivePlanPartClass;
	}

	/**
	 * @return the twentyFivePlanPartNumber
	 */
	@Override
	public String getTwentyFivePlanPartNumber() {
		return twentyFivePlanPartNumber;
	}

	/**
	 * @return the twentyFivePlanTitle
	 */
	@Override
	public String getTwentyFivePlanTitle() {
		return twentyFivePlanTitle;
	}

	/**
	 * @return the twentyFivePlanDescription
	 */
	@Override
	public String getTwentyFivePlanDescription() {
		return twentyFivePlanDescription;
	}

	/**
	 * @return the twentyFivePlanButtonTitle
	 */
	@Override
	public String getTwentyFivePlanButtonTitle() {
		return twentyFivePlanButtonTitle;
	}

	/**
	 * @return the twentyFivePlanCardTypeTitle
	 */
	@Override
	public String getTwentyFivePlanCardTypeTitle() {
		return twentyFivePlanCardTypeTitle;
	}

	/**
	 * @return the twentyFivePlanCardTypeSubTitle
	 */
	@Override
	public String getTwentyFivePlanCardTypeSubTitle() {
		return twentyFivePlanCardTypeSubTitle;
	}

	/**
	 * @return the twentyFivePlanCardTitle
	 */
	@Override
	public String getTwentyFivePlanCardTitle() {
		return twentyFivePlanCardTitle;
	}

	/**
	 * @return the twentyFivePlanCardDescription
	 */
	@Override
	public String getTwentyFivePlanCardDescription() {
		return twentyFivePlanCardDescription;
	}

	/**
	 * @return the twentyFivePlanCardLearnMore
	 */
	@Override
	public String getTwentyFivePlanCardLearnMore() {
		return twentyFivePlanCardLearnMore;
	}


	/**
	 * @return the twentyFivePlanCardLearnMore
	 */
	@Override
	public String getByopMainText() {
		return byopMainText;
	}

	/**
	 * @return the dcotPromoEligiblePlans
	 */
	@Override
	public String getDcotPromoEligiblePlans() {
		return dcotPromoEligiblePlans;
	}

	/**
	 * @return the dcotEligiblePlansSubText
	 */
	@Override
	public String getDcotPromoEligiblePlansSubText() {
		return dcotPromoEligiblePlansSubText;
	}

	/**
	 * @return the dcotPromoOtherPlans
	 */
	@Override
	public String getDcotPromoOtherPlans() {
		return dcotPromoOtherPlans;
	}

	/**
	 * @return the dcotPromoOtherPlansSubText
	 */
	@Override
	public String getDcotPromoOtherPlansSubText() {
		return dcotPromoOtherPlansSubText;
	}

	/**
	 * @return the dcotPromoOtherPlans
	 */
	@Override
	public String getDcotNonEligiblePlanModel() {
		return dcotNonEligiblePlanModel;
	}


	/**
	 * @return the twentyFivePlanCardLearnMore
	 */
	@Override
	public String getByopCtaText() {
		return byopCtaText;
	}

	@Override
	public String getFiveGCapablefacet() {
		return ConfigurationUtil.getConfigValue(tracfoneApiService.fiveGCapablefacet(), brand);
	}

	@Override
	public String getIsSortEnable() {
		return CommerceUtil.getPropertyValue(this.brandPagePropertyVm, ENABLESORT);
	}

	@Override
	public String getPriceUpdate() {
		return CommerceUtil.getPropertyValue(this.brandPagePropertyVm, "priceUpdate");
	}

}
