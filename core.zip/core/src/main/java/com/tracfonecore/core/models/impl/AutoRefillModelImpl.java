/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.wcm.api.Page;
import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.AutoRefillModel;
import com.tracfonecore.core.services.ApplicationConfigService;
import com.tracfonecore.core.utils.ApplicationUtil;
import com.tracfonecore.core.utils.CommerceUtil;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { AutoRefillModel.class,
		ComponentExporter.class }, resourceType = AutoRefillModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class AutoRefillModelImpl implements AutoRefillModel {

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private Resource resource;

	@Inject
	private Page currentPage;

	@ScriptVariable
	private ValueMap properties;

	@Inject
	protected ApplicationConfigService applicationConfigService;

	protected static final String RESOURCE_TYPE = "tracfone-core/components/commerce/autorefill";

	/**
	 * Inject the Textfield
	 */
	@Inject
	@Via("resource")
	private String disableGuestCheckout;

	@Inject
	@Via("resource")
	private String disablePriceSection;

	@ValueMapValue
	private String noDiscountPriceLabel;

	@ValueMapValue
	private String discountPriceLabel;

	@ValueMapValue
	private String heading;

	@ValueMapValue
	private String showHeadingAsH1;

	@ValueMapValue
	private String summary;

	@ValueMapValue
	private String planMessage;

	@ValueMapValue
	private String disclaimer;

	
	@ValueMapValue
	private String flowType;

	@ValueMapValue
	private String ildMessage;

	@ValueMapValue
	private String dcotPromoDesc;

	@ValueMapValue
	@Default(values = "Learn More")
	private String modalName;

	@ValueMapValue
	private String ildDisclaimer;

	private List<String> options = Collections.emptyList();

	private static final Logger LOGGER = LoggerFactory.getLogger(AutoRefillModelImpl.class);
	
	@PostConstruct
	private void initModel() {

		options = new ArrayList<>();

		for (Resource child : resource.getChildren()) {
			if(ApplicationConstants.OPTIONS.equals(child.getName()))
			{
				Iterator<Resource> it = child.listChildren();
				setMultiFieldItems(it, options);
			}
		}

	}
	/**
	 * <p>Populates a list with all the multi-options</p>
	 *
	 * @param it - iterator of the parent node
	 * @param multiFieldData - list in which the multi options data needs to be set
	 */

	private void setMultiFieldItems(Iterator<Resource> it, List<String> multiFieldData) {
		LOGGER.debug("Entering setMultiFieldItems method");		
			while (it.hasNext()) {
				Resource grandChild = it.next();
				multiFieldData.add(grandChild.getValueMap().get("option", String.class));
			}
		
		LOGGER.debug("Exiting setMultiFieldItems method ");
	}

	/**
	 * <p>Fetches title for Auto Refill</p>
	 *
	 * @return String - title for Auto Refill
	 */
	@Override
	public String getTitle() {
		return "title";
	}

	/**
	 * <p>Fetches description for Auto Refill</p>
	 *
	 * @return String - description for Auto Refill
	 */
	@Override
	public String getDescription() {
		return "description";
	}

	/**
	 * <p>Fetches all the multi-options</p>
	 *
	 * @return List - all the multi-options
	 */
	@Override
	public List<String> getOptions() {
		return new ArrayList<>(options);
	}

	/**
	 * @return String - exportedType
	 */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
	/**
	 * <p>Fetches Disable guest checkout flag</p>
	 *
	 * @return String - Disable guest checkout flag
	 */
	@Override
	public String getDisableGuestCheckout() {
		return disableGuestCheckout;
	}
	/**
	 * <p>Fetches label when discount price is less than and equals to 0 dollar</p>
	 *
	 * @return String - No discount price label
	 */
	@Override
	public String getNoDiscountPriceLabel(){
		return noDiscountPriceLabel;
	}
	/**
	 * <p>Fetches label when discount price is greater than 0 dollar</p>
	 *
	 * @return String - discount price label
	 */
	@Override
	public String getDiscountPriceLabel(){
		return discountPriceLabel;
	}
	
	/**
	 * <p>Fetches CUSG Logo path</p>
	 *
	 * @return String - CUSG logo path
	 */
	@Override
	public String getCusgLogo() {
		return CommerceUtil.getPagePropertyValue(currentPage, applicationConfigService.getHomePageLevel(),
				CommerceConstants.LOGO_CUSG).toString();
	}
	
	/**
	 * <p>Fetches CUSG Logo alt text</p>
	 *
	 * @return String - CUSG Logo alternate text
	 */
	@Override
	public String getCusgLogoAltText() {
		return CommerceUtil.getPagePropertyValue(currentPage, applicationConfigService.getHomePageLevel(),
				CommerceConstants.LOGO_ALT_TEXT_CUSG).toString();
	}
	
	/**
	 * <p>Fetches CUSG Discount Label</p>
	 *
	 * @return String - CUSG discount label
	 */
	@Override
	public String getCusgLabel() {
		return CommerceUtil.getPagePropertyValue(currentPage, applicationConfigService.getHomePageLevel(),
				CommerceConstants.LABEL_PLAN_CUSG_DISCOUNT_TYPE).toString();
	}
	
	/**
	 * <p>Fetches to check if CUSG is enable</p>
	 *
	 * @return String -CUSG enable
	 */
	@Override
	public String getEnableCusg() {
		String enableCusg =  CommerceUtil.getPagePropertyValue(currentPage, applicationConfigService.getHomePageLevel(),
				CommerceConstants.ENABLE_CUSG).toString();
		String cusgFlag=ApplicationConstants.FALSE;
		if (StringUtils.isNotBlank(enableCusg) && ApplicationConstants.TRUE.equalsIgnoreCase(enableCusg)) {
			cusgFlag=ApplicationConstants.TRUE;
		} 
		return cusgFlag;
	}
	/**
	 * <p>Fetches the heading</p>
	 *
	 * @return String -Heading
	 */
	@Override
	public String getHeading() {
		return heading;
	}

	/**
	 * <p>Fetches the showHeadingAsH1</p>
	 *
	 * @return String -showHeadingAsH1
	 */
	@Override
	public String getShowHeadingAsH1() {
		return showHeadingAsH1;
	}

	/**
	 * <p>Fetches the summary</p>
	 *
	 * @return String -Summary
	 */
	@Override
	public String getSummary() {
		return summary;
	}

	/**
	 * <p>Fetches the planMessage</p>
	 *
	 * @return String -Plan Message
	 */
	@Override
	public String getPlanMessage() {
		return planMessage;
	}
	/**
	 * <p>Fetches the disclaimer</p>
	 *
	 * @return String -Disclaimer
	 */
	@Override
	public String getDisclaimer() {
		return disclaimer;
	}
	/**
	 * <p>
	 * Fetches modalName
	 * </p>
	 *
	 * @return the modalName
	 */
	@Override
	public String getModalName() {
		return ApplicationUtil.getLowerCaseWithHyphen(modalName) + ApplicationConstants.HYPHEN
				+ ApplicationConstants.MODAL;
	}
	/**
	 * <p>
	 * Fetches flowType
	 * </p>
	 *
	 * @return the flowType
	 */
	@Override
	public String getFlowType() {
		return flowType;
	}	
	
	/**
	 * <p>Fetches the ILD Message</p>
	 *
	 * @return ILD Message
	 */
	@Override
	public String getIldMessage() {
		return ildMessage;
	}

	/**
	 * <p>Fetches Disable price section flag</p>
	 *
	 * @return String - Disable price section flag
	 */
	@Override
	public String getDisablePriceSection() {
		return disablePriceSection;
	}

	/**
	 * <p>Fetches ild Disclaimer</p>
	 *
	 * @return String - ild Disclaimer
	 */
	@Override
	public String getIldDisclaimer() {
		return ildDisclaimer;
	}

	/**
	 * <p>
	 * Fetches dcotPromoDesc
	 * </p>
	 *
	 * @return String - dcotPromoDesc
	 */
	@Override
	public String getDcotPromoDesc() {
		return dcotPromoDesc;
	}

}
