package com.tracfonecore.core.models.impl;

import com.tracfonecore.core.constants.ApplicationConstants;
import com.tracfonecore.core.utils.ApplicationUtil;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.CusgModel;


@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CusgModel.class,
  ComponentExporter.class }, resourceType = CusgModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
  @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
  @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CusgModelImpl implements CusgModel {
  protected static final String RESOURCE_TYPE = "tracfone-core/components/commerce/cusg";

  @Self
	private SlingHttpServletRequest request;

  @ValueMapValue
	@Default(values = "Learn More")
	private String modalId;

  @ValueMapValue
    private boolean addRteComponent;

  @ValueMapValue
	private String[] websites;

  @Override
	public String getModalId() {
		return ApplicationUtil.getLowerCaseWithHyphen(modalId) + ApplicationConstants.HYPHEN
      + ApplicationConstants.MODAL;
	}

  @Override
	public boolean getAddRteComponent() {
		return this.addRteComponent;
	}

  @Override
	public String getWebsites() {
		return String.join(", ", this.websites);
	}

  /**
   * @return String - exported Type
   */
	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
}
