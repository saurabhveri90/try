/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;

/**
 * <p>Defines bean to hold link detail</p>
 */
public class ColumnBean {

	private String columnwidth;
	private String columnClass;
	/**
	 * @return the columnwidth
	 */
	public String getColumnwidth() {
		return columnwidth;
	}
	/**
	 * @param columnwidth the columnwidth to set
	 */
	public void setColumnwidth(String columnwidth) {
		this.columnwidth = columnwidth;
	}

	/**
	 * @return the columnType
	 */
	public String getColumnClass() {
		return columnClass;
	}
	/**
	 * @param columnType the columnType to set
	 */
	public void setColumnClass(String columnClass) {
		this.columnClass = columnClass;
	}
	

	
}
