/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.services.TracfoneApiGatewayService;
import com.tracfonecore.core.models.CompareProductModel;
import com.tracfonecore.core.constants.CommerceConstants;


@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { CompareProductModel.class,ComponentExporter.class }, 
resourceType = "tracfone-core/components/commerce/compareproducts", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, 
extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = { 
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CompareProductModelImpl extends BaseComponentModelImpl implements CompareProductModel {

	@Self
	private SlingHttpServletRequest request;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String specsHeading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addnSpecsHeading;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ctaText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String flowType;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addProductPagePath;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addProductCtaAcc;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addproductdonotfollowlink;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String addProductCtaText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String ctaAccessibility;

	@ValueMapValue @Default(values="false")
	private String isPlanCompare;
	
	@Inject
	private TracfoneApiGatewayService tracfoneApiService;
	
	@PostConstruct
	protected void initModel() {
		super.initModel();
	}
	@Override
	public String getSpecsHeading() {
		return specsHeading;
	}
	@Override
	public String getAddnSpecsHeading() {
		return addnSpecsHeading;
	}
	@Override
	public String getCtaText() {
		return ctaText;
	}
	
	@Override
	public String getFlowType() {
		return flowType;
	}

	@Override
	public String getExportedType() {
		return request.getResource().getResourceType();
	}
	
	/**
	 * @return apiDomain
	 */
	public String getApiDomain() {
		
		return tracfoneApiService.getApiDomain();
	}
	

	/**
	 * @return priceApiPath
	 */
	public String getPriceApiPath() {
		
		return tracfoneApiService.getPriceApiPath();
	}
	
	public String getQueryString() {
		StringBuilder query = new StringBuilder(CommerceConstants.PRODUCT_ID).append(CommerceConstants.EQUALS_TO);
				
		return query.toString();
	}
	@Override
	public String getAddProductPagePath() {
		return addProductPagePath;
	}
	@Override
	public String getAddProductCtaAcc() {
		return addProductCtaAcc;
	}
	@Override
	public String getAddproductdonotfollowlink() {
		return addproductdonotfollowlink;
	}
	@Override
	public String getAddProductCtaText() {
		return addProductCtaText;
	}
	@Override
	public String getCtaAccessibility() {		
		return ctaAccessibility;
	}
	/**
	 * @return the isPlanCompare
	 */
	@Override
	public String getIsPlanCompare() {
		return isPlanCompare;
	}
	

}