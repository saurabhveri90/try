/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code New Line} Sling Model used for the {@code /apps/tracfone-core/components/commerce/currentServiceProvider} component.
 */
public interface CurrentServiceProviderModel extends ComponentExporter {


	/**
	 * <p>Fetches label for Phone Type</p>
	 *
	 * @return List - Phone Type Label
	 */
	@JsonProperty("phoneTypeLabel")
	public String getPhoneTypeLabel();
	
	/**
	 * <p>Fetches Placeholder text for Phone Type</p>
	 *
	 * @return List - Phone Type Placeholder Text
	 */
	@JsonProperty("phoneTypePlaceholderText")
	public String getPhoneTypePlaceholderText();
	
	/**
	 * <p>Fetches label for Current Service Provider</p>
	 *
	 * @return List - Service Provider Label
	 */
	@JsonProperty("serviceProviderLabel")
	public String getServiceProviderLabel();
	
	/**
	 * <p>Fetches Placeholder text for Service Provider</p>
	 *
	 * @return List - Service Provider Placeholder Text
	 */
	@JsonProperty("serviceProviderPlaceholderText")
	public String getServiceProviderPlaceholderText();	
	
	/**
	 * <p>Fetches label for Zip code</p>
	 *
	 * @return List - Zip Code Label
	 */
	@JsonProperty("zipCodeLabel")
	public String getZipCodeLabel();
	
	/**
	 * <p>Fetches Placeholder text for Zip Code</p>
	 *
	 * @return List - Zip Code Placeholder Text
	 */
	@JsonProperty("zipCodePlaceholderText")
	public String getZipCodePlaceholderText();
	
	/**
	 * <p>Fetches modal name</p>
	 *
	 * @return String - modalName
	 */
	@JsonProperty("modalName")
	public String getModalName();

	/**
	 * <p>Fetches heading</p>
	 *
	 * @return String - heading
	 */
	@JsonProperty("heading")
	public String getHeading();

	/**
	 * <p>Fetches summary</p>
	 *
	 * @return String - summary
	 */
	@JsonProperty("summary")
	public String getSummary();

	/**
	 * <p>Fetches label for Learn More Modal</p>
	 *
	 * @return String - modal label
	 */
	@JsonProperty("modalLabel")
	public String getModalLabel();

	/**
	 * <p>Fetches button text</p>
	 *
	 * @return String - button text
	 */
	@JsonProperty("buttontext")
	public String getButtontext();
	/**
	 * <p> Fetches modalId </p>
	 *
	 * @return the modalId
	 */
	public String getModalId();
	
	/**
	 * <p> Fetches heading for Account detail section </p>
	 * 
	 * @return the accountHeading
	 */
	@JsonProperty("accountHeading")
	public String getAccountHeading();

	/**
	 * <p> Fetches summary for Account detail section </p>
	 * 
	 * @return the accountSummary
	 */
	@JsonProperty("accountSummary")
	public String getAccountSummary();

	/**
	 * <p> Fetches label for Account modal</p>
	 * 
	 * @return the accountModalLabel
	 */
	@JsonProperty("accountModalLabel")
	public String getAccountModalLabel();

	/**
	 * <p> Fetches label for Account section modal name</p>
	 * 
	 * @return the accountModalName
	 */
	@JsonProperty("accountModalName")
	public String getAccountModalName();

	/**
	 * <p> Fetches label for Account info</p>
	 * 
	 * @return the accountInfoLabel
	 */
	@JsonProperty("accountInfoLabel")
	public String getAccountInfoLabel();

	/**
	 * <p> Fetches placeholder text for Account number</p>
	 * 
	 * @return the accountNoPlaceholderText
	 */
	@JsonProperty("accountNoPlaceholderText")
	public String getAccountNoPlaceholderText();

	/**
	 * <p> Fetches placeholder text for Account key</p>
	 * 
	 * @return the accountKeyPlaceholderText
	 */
	@JsonProperty("accountKeyPlaceholderText")
	public String getAccountKeyPlaceholderText();

	/**
	 * <p> Fetches label for contact info</p>
	 * 
	 * @return the contactInfoLabel
	 */
	@JsonProperty("contactInfoLabel")
	public String getContactInfoLabel();

	/**
	 * <p> Fetches placeholder text for first name</p>
	 * 
	 * @return the firstNamePlaceholderText
	 */
	@JsonProperty("firstNamePlaceholderText")
	public String getFirstNamePlaceholderText();

	/**
	 * <p> Fetches placeholder text for last name </p>
	 * 
	 * @return the lastNamePlaceholderText
	 */
	@JsonProperty("lastNamePlaceholderText")
	public String getLastNamePlaceholderText();

	/**
	 * <p> Fetches placeholder text for phone no.</p>
	 * 
	 * @return the phoneNoPlaceholderText
	 */
	@JsonProperty("phoneNoPlaceholderText")
	public String getPhoneNoPlaceholderText();

	/**
	 * <p> Fetches label for Address info</p>
	 * 
	 * @return the addressInfoLabel
	 */
	@JsonProperty("addressInfoLabel")
	public String getAddressInfoLabel();

	/**
	 * <p> Fetches placeholder text for Address line 1</p>
	 * 
	 * @return the address1PlaceholderText
	 */
	@JsonProperty("address1PlaceholderText")
	public String getAddress1PlaceholderText();

	/**
	 * <p> Fetches placeholder text for Address line 2 </p>
	 * 
	 * @return the address2PlaceholderText
	 */
	@JsonProperty("address2PlaceholderText")
	public String getAddress2PlaceholderText();

	/**
	 * <p> Fetches placeholder text for city field </p>
	 * 
	 * @return the cityPlaceholderText
	 */
	@JsonProperty("cityPlaceholderText")
	public String getCityPlaceholderText();

	/**
	 * <p> Fetches placeholder text for zipcode field </p>
	 * 
	 * @return the accountZipCodePlaceholderText
	 */
	@JsonProperty("accountZipCodePlaceholderText")
	public String getAccountZipCodePlaceholderText();

	/**
	 * <p> Fetches placeholder text for state field </p>
	 * 
	 * @return the statePlaceholderText
	 */
	@JsonProperty("statePlaceholderText")
	public String getStatePlaceholderText();

	/**
	 * <p> Fetches label for cta button</p>
	 * 
	 * @return the ctaButton
	 */
	@JsonProperty("ctaButton")
	public String getCtaButton();
	
	/**
	 * <p> Fetches accountModalId </p>
	 *
	 * @return the accountModalId
	 */
	@JsonProperty("accountModalId")
	public String getAccountModalId();

	/**
	 * <p> Fetches placeholder text for MIN field </p>
	 * 
	 * @return the accountMinPlaceholderText
	 */
	@JsonProperty("accountMinPlaceholderText")
	String getAccountMinPlaceholderText();

	/**
	 * <p> Fetches placeholder text for Current ESN field </p>
	 * 
	 * @return the accountCurrentEsnPlaceholderText
	 */
	@JsonProperty("accountCurrentEsnPlaceholderText")
	String getAccountCurrentEsnPlaceholderText();

	/**
	 * <p> Fetches placeholder text for VKey field </p>
	 * 
	 * @return the accountVKeyPlaceholderText
	 */
	@JsonProperty("accountVKeyPlaceholderText")
	String getAccountVKeyPlaceholderText();

	/**
	 * <p> Fetches placeholder text for Last 4 SSN field </p>
	 * 
	 * @return the accountLast4SSNPlaceholderText
	 */
	@JsonProperty("accountLast4SSNPlaceholderText")
	String getAccountLast4SSNPlaceholderText();

	/**
	 * <p>Fetches unlock summary</p>
	 *
	 * @return the unlockSummary
	 */
	@JsonProperty("unlockSummary")
	public String getUnlockSummary();

	/**
	 * <p>Fetches unlock button text</p>
	 *
	 * @return the unlockButtonText
	 */
	@JsonProperty("unlockButtonText")
	public String getUnlockButtonText();

	/**
	 * @return troubleTicketApiPath
	 */
	public String getTroubleTicketApiPath();

	/**
	 * @return portInScreenChanges
	 */
	@JsonProperty("portInScreenChanges")
	public String getPortInScreenChanges();
}
