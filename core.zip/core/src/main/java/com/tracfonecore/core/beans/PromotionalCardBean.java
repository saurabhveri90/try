package com.tracfonecore.core.beans;

public class PromotionalCardBean {

	private String cardType;
	private String enableCard;
	private String applyFallback;
	private String cardHeadlineText;
	private String cardSubHeadlineText;
	private String cardTextColor;
	private String cardBgColor;
	private String cardImage;
	private String cardImageAltText;
	private String cardImageAlignment;
	private String cardCtaType;
	private String cardCtaLabel;
	private String cardCtaLink;
	private String cardCtaLinkTarget;
	private String cardCtaDoNotFollowLink;
	private String playStoreFileReference;
	private String playStoreLink;
	private String playStoreAltText;
	private String appStoreFileReference;
	private String appStoreLink;
	private String appStoreAltText;
	private String purchaseScenario;

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getEnableCard() {
		return enableCard;
	}

	public void setEnableCard(String enableCard) {
		this.enableCard = enableCard;
	}

	public String getCardHeadlineText() {
		return cardHeadlineText;
	}

	public void setCardHeadlineText(String cardHeadlineText) {
		this.cardHeadlineText = cardHeadlineText;
	}

	public String getCardSubHeadlineText() {
		return cardSubHeadlineText;
	}

	public void setCardSubHeadlineText(String cardSubHeadlineText) {
		this.cardSubHeadlineText = cardSubHeadlineText;
	}

	public String getCardTextColor() {
		return cardTextColor;
	}

	public void setCardTextColor(String cardTextColor) {
		this.cardTextColor = cardTextColor;
	}

	public String getCardBgColor() {
		return cardBgColor;
	}

	public void setCardBgColor(String cardBgColor) {
		this.cardBgColor = cardBgColor;
	}

	public String getCardImage() {
		return cardImage;
	}

	public void setCardImage(String cardImage) {
		this.cardImage = cardImage;
	}

	public String getCardImageAltText() {
		return cardImageAltText;
	}

	public void setCardImageAltText(String cardImageAltText) {
		this.cardImageAltText = cardImageAltText;
	}

	public String getCardImageAlignment() {
		return cardImageAlignment;
	}

	public void setCardImageAlignment(String cardImageAlignment) {
		this.cardImageAlignment = cardImageAlignment;
	}

	public String getCardCtaType() {
		return cardCtaType;
	}

	public void setCardCtaType(String cardCtaType) {
		this.cardCtaType = cardCtaType;
	}

	public String getCardCtaLabel() {
		return cardCtaLabel;
	}

	public void setCardCtaLabel(String cardCtaLabel) {
		this.cardCtaLabel = cardCtaLabel;
	}

	public String getCardCtaLink() {
		return cardCtaLink;
	}

	public void setCardCtaLink(String cardCtaLink) {
		this.cardCtaLink = cardCtaLink;
	}

	public String getCardCtaLinkTarget() {
		return cardCtaLinkTarget;
	}

	public void setCardCtaLinkTarget(String cardCtaLinkTarget) {
		this.cardCtaLinkTarget = cardCtaLinkTarget;
	}

	public String getCardCtaDoNotFollowLink() {
		return cardCtaDoNotFollowLink;
	}

	public void setCardCtaDoNotFollowLink(String cardCtaDoNotFollowLink) {
		this.cardCtaDoNotFollowLink = cardCtaDoNotFollowLink;
	}

	public String getPlayStoreFileReference() {
		return playStoreFileReference;
	}

	public void setPlayStoreFileReference(String playStoreFileReference) {
		this.playStoreFileReference = playStoreFileReference;
	}

	public String getPlayStoreLink() {
		return playStoreLink;
	}

	public void setPlayStoreLink(String playStoreLink) {
		this.playStoreLink = playStoreLink;
	}

	public String getPlayStoreAltText() {
		return playStoreAltText;
	}

	public void setPlayStoreAltText(String playStoreAltText) {
		this.playStoreAltText = playStoreAltText;
	}

	public String getAppStoreFileReference() {
		return appStoreFileReference;
	}

	public void setAppStoreFileReference(String appStoreFileReference) {
		this.appStoreFileReference = appStoreFileReference;
	}

	public String getAppStoreLink() {
		return appStoreLink;
	}

	public void setAppStoreLink(String appStoreLink) {
		this.appStoreLink = appStoreLink;
	}

	public String getAppStoreAltText() {
		return appStoreAltText;
	}

	public void setAppStoreAltText(String appStoreAltText) {
		this.appStoreAltText = appStoreAltText;
	}

	public String getPurchaseScenario() {
		return purchaseScenario;
	}

	public void setPurchaseScenario(String purchaseScenario) {
		this.purchaseScenario = purchaseScenario;
	}

	public String getApplyFallback() {
		return applyFallback;
	}

	public void setApplyFallback(String applyFallback) {
		this.applyFallback = applyFallback;
	}

}
