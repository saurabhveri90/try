package com.tracfonecore.core.beans;

public class OrderConfirmationVasModel { 
    private String vasVendorName;
    private String vasPartNumber;    
    private String vasHeaderTitle;
    private String vasApiFrequency;
    private String vasApiInterval;
    private String vasConfirmationMessage1;
    private String vasConfirmationMessage2;
    private String vasButtonLabel;
    private String vasCtaLink;
    private String vasProductLogo;
    private String vasProductLogoAltText;
    
    public String getVasVendorName() {
		return vasVendorName;
	}
	public void setVasVendorName(String vasVendorName) {
		this.vasVendorName = vasVendorName;
	}
	public String getVasPartNumber() {
		return vasPartNumber;
	}
	public void setVasPartNumber(String vasPartNumber) {
		this.vasPartNumber = vasPartNumber;
	}   
    
    public String getVasHeaderTitle() {
        return vasHeaderTitle;
    }
    public void setVasHeaderTitle(String vasHeaderTitle) {
        this.vasHeaderTitle = vasHeaderTitle;
    }
    public String getVasApiFrequency() {
        return vasApiFrequency;
    }
    public void setVasApiFrequency(String vasApiFrequency) {
        this.vasApiFrequency = vasApiFrequency;
    }
    public String getVasApiInterval() {
        return vasApiInterval;
    }
    public void setVasApiInterval(String vasApiInterval) {
        this.vasApiInterval = vasApiInterval;
    }
    public String getVasConfirmationMessage1() {
        return vasConfirmationMessage1;
    }
    public void setVasConfirmationMessage1(String vasConfirmationMessage1) {
        this.vasConfirmationMessage1 = vasConfirmationMessage1;
    }
    public String getVasConfirmationMessage2() {
        return vasConfirmationMessage2;
    }
    public void setVasConfirmationMessage2(String vasConfirmationMessage2) {
        this.vasConfirmationMessage2 = vasConfirmationMessage2;
    }
    public String getVasButtonLabel() {
        return vasButtonLabel;
    }
    public void setVasButtonLabel(String vasButtonLabel) {
        this.vasButtonLabel = vasButtonLabel;
    }
    public String getVasCtaLink() {
        return vasCtaLink;
    }
    public void setVasCtaLink(String vasCtaLink) {
        this.vasCtaLink = vasCtaLink;
    }
    public String getVasProductLogo() {
        return vasProductLogo;
    }
    public void setVasProductLogo(String vasProductLogo) {
        this.vasProductLogo = vasProductLogo;
    }
    public String getVasProductLogoAltText() {
        return vasProductLogoAltText;
    }
    public void setVasProductLogoAltText(String vasProductLogoAltText) {
        this.vasProductLogoAltText = vasProductLogoAltText;
    }
}