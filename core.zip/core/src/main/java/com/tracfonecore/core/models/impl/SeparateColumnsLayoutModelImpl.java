package com.tracfonecore.core.models.impl;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.models.SeparateColumnsLayoutModel;
import com.tracfonecore.core.utils.DynamicMediaUtils;

import javax.annotation.PostConstruct;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { SeparateColumnsLayoutModel.class,
        ComponentExporter.class }, resourceType = "tracfone-core/components/commerce/seperatetwocolumn", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = {
        @ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
        @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class SeparateColumnsLayoutModelImpl implements SeparateColumnsLayoutModel {
    @Self
    private SlingHttpServletRequest request;
    @ValueMapValue
    private String headingColumnOne;
    @ValueMapValue
    private String descColumnOne;
    @ValueMapValue
    private String alignTypeTwoColumn;
    @ValueMapValue
    private String alignBtnContainerCol1;
    @ValueMapValue
    private String alignBtnContainerCol2;
    @ValueMapValue
    private String imgPathColOne;
    @ValueMapValue
    private String headingColumnTwo;
    @ValueMapValue
    private String descColumnTwo;
    @ValueMapValue
    private String imgPathColTwo;
    @ValueMapValue
    private String alignTypeColTwo;
    @ValueMapValue
    private String imgAlignFirstCard;
    @ValueMapValue
    private String imgAlignSecondCard;
    @ValueMapValue
    @Default(values = "")
    private String tooltipLogoColOne;
    @ValueMapValue
    @Default(values = "")
    private String tooltipLogoColTwo;
    @ValueMapValue
    @Default(values = "")
    private String tooltipMsgColTwo;
    @ValueMapValue
    @Default(values = "")
    private String tooltipMsgColOne;
    @ValueMapValue
    @Default(values = "")
    private String tooltipIdColTwo;
    @ValueMapValue
    @Default(values = "")
    private String tooltipIdColOne;


    public String getHeadingColumnOne(){ return headingColumnOne;}
    public String getDescColumnOne(){ return  descColumnOne;}
    public String getAlignTypeTwoColumn(){return  alignTypeTwoColumn;}
    public String getAlignBtnContainerCol1(){return  alignBtnContainerCol1;}
    public String getAlignBtnContainerCol2(){return  alignBtnContainerCol2;}
    public String getImgPathColOne(){return DynamicMediaUtils.changeMediaPathToDMPath(imgPathColOne, request.getResourceResolver());}
    public String getHeadingColumnTwo(){ return headingColumnTwo;}
    public String getDescColumnTwo(){return  descColumnTwo;}
    public String getImgPathColTwo(){return DynamicMediaUtils.changeMediaPathToDMPath(imgPathColTwo, request.getResourceResolver());}
    public String getAlignTypeColTwo(){return  alignTypeColTwo;}
    public String getTooltipMsgColOne(){ return tooltipMsgColOne;}
    public String getTooltipMsgColTwo(){return  tooltipMsgColTwo;}
    public String getTooltipLogoColTwo(){return tooltipLogoColTwo;}
    public String getTooltipIdColOne(){ return tooltipIdColOne;}
    public String getTooltipIdColTwo(){return  tooltipIdColTwo;}
    public String getTooltipLogoColOne(){return  tooltipLogoColOne;}
    public String getImgAlignFirstCard(){return  imgAlignFirstCard;}
    public String getImgAlignSecondCard(){return  imgAlignSecondCard;}

    @Override
    public String getExportedType() {
        return request.getResource().getResourceType();
    }

    @PostConstruct
    protected void initModel() {

        descColumnOne = descColumnOne.replace("TooltipIdentifier", tooltipMsgColOne);
        descColumnOne = descColumnOne.replace("tooltipLogoIdentifier", tooltipLogoColOne);
        descColumnTwo = descColumnTwo.replace("TooltipIdentifier", tooltipMsgColTwo);
        descColumnTwo = descColumnTwo.replace("tooltipLogoIdentifier", tooltipLogoColTwo);


    }
}