package com.tracfonecore.core.beans;

public class LocatorBean {

	private String radiusLabel;
	
	private String radius;
	
	/**
	 * @return the radiusLabel
	 */
	public String getRadiusLabel() {
		return radiusLabel;
	}
	/**
	 * @return the radius
	 */
	public String getRadius() {
		return radius;
	}
	/**
	 * @param radiusLabel the radiusLabel to set
	 */
	public void setRadiusLabel(String radiusLabel) {
		this.radiusLabel = radiusLabel;
	}
	/**
	 * @param radius the radius to set
	 */
	public void setRadius(String radius) {
		this.radius = radius;
	}
	
}
