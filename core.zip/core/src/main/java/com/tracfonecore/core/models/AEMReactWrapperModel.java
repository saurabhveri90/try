package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public interface AEMReactWrapperModel  extends ComponentExporter {

    @JsonProperty("reactComponent")
	public String getReactComponent();

    @JsonProperty("authData")
    public List<KeyValuePairModel> getAuthData();

}
