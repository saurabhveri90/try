/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.beans;

/**
 * <p>Defines bean to hold verification type detail</p>
 */
public class VerificationOptBean {

	private String label;
	private String verificationType;
	/**
	 * @return the label
	 */
	public String getLabel() {
		return label;
	}
	/**
	 * @return the verificationType
	 */
	public String getVerificationType() {
		return verificationType;
	}
	/**
	 * @param label the label to set
	 */
	public void setLabel(String label) {
		this.label = label;
	}
	/**
	 * @param verificationType the verificationType to set
	 */
	public void setVerificationType(String verificationType) {
		this.verificationType = verificationType;
	}
}
