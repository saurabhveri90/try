package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

public interface RefillProrationModel extends ComponentExporter {

	/**
	 * @return the heading
	 */
	@JsonProperty("heading")
	public String getHeading();

	/**
	 * @return the subheading
	 */
	@JsonProperty("subheading")
	public String getSubheading();

	/**
	 * @return the changePlanlbl
	 */
	@JsonProperty("changePlanlbl")
	public String getChangePlanlbl();

	/**
	 * @return the opt1label
	 */
	@JsonProperty("opt1label")
	public String getOpt1label();
	

	/**
	 * @return the opt1labelsummary
	 */
	@JsonProperty("opt1labelsummary")
	public String getOpt1labelsummary();

	/**
	 * @return the opt2label
	 */
	@JsonProperty("opt2label")
	public String getOpt2label();

	/**
	 * @return the opt2labelsummary
	 */
	@JsonProperty("opt2labelsummary")
	public String getOpt2labelsummary();
	
	/**
	 * @return the buttonText
	 */
	@JsonProperty("buttonText")
	public String getButtonText();

}
