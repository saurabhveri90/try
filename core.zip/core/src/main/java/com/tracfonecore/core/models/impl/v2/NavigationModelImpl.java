/**
 * 
 */
package com.tracfonecore.core.models.impl.v2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.jcr.RangeIterator;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.via.ResourceSuperType;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.internal.models.v2.PageImpl;
import com.adobe.cq.wcm.core.components.models.Navigation;
import com.day.cq.wcm.api.LanguageManager;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageFilter;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.wcm.api.WCMException;
import com.day.cq.wcm.api.designer.Style;
import com.day.cq.wcm.msm.api.LiveRelationship;
import com.day.cq.wcm.msm.api.LiveRelationshipManager;
import com.drew.lang.annotations.NotNull;
import com.drew.lang.annotations.Nullable;
import com.tracfonecore.core.models.NavigationItem;
import com.tracfonecore.core.models.NavigationLinksItemModel;
import com.tracfonecore.core.models.NavigationModel;
import com.tracfonecore.core.models.impl.NavigationItemImpl;
import com.tracfonecore.core.utils.ApplicationUtil;

/**
 * @author vijaykumar.tripathi
 *
 */
@Model(adaptables = {Resource.class, SlingHttpServletRequest.class},
adapters = {NavigationModel.class, ComponentExporter.class},
resourceType = NavigationModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME , extensions = ExporterConstants.SLING_MODEL_EXTENSION)
public class NavigationModelImpl implements NavigationModel{
	
	 public static final String RESOURCE_TYPE = "tracfone-core/components/structure/navigation/v2/navigation";
	 
	    @Self
	    @Via(type = ResourceSuperType.class)
	    private Navigation navigation;

	    @Self
	    private SlingHttpServletRequest request;

	    @SlingObject
	    private ResourceResolver resourceResolver;
	    
	    @SlingObject
	    private Resource resource;

	    @ScriptVariable
	    private Page currentPage;

	    @ScriptVariable
	    private ValueMap properties;

	    @ScriptVariable
	    private Style currentStyle;
	    
	    @ValueMapValue
	    private boolean flexibleNavigationWidth;

	    @OSGiService
	    private LanguageManager languageManager;

	    @OSGiService
	    private LiveRelationshipManager relationshipManager;

	    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	    private String accessibilityLabel;

	    private int structureDepth;
	    private String navigationRootPage;
	    private List<NavigationItem> item;
	    private boolean skipNavigationRoot;
	    private int structureStart;
	    private Resource parentResource; 

	    
	    @PostConstruct
	    private void initModel() {
	    	parentResource = resource.getParent();
	        structureDepth = properties.get(PN_STRUCTURE_DEPTH, currentStyle.get(PN_STRUCTURE_DEPTH, -1));
	        boolean collectAllPages = properties.get(PN_COLLECT_ALL_PAGES, currentStyle.get(PN_COLLECT_ALL_PAGES, true));
	        if (collectAllPages) {
	            structureDepth = -1;
	        }
	        navigationRootPage = properties.get(PN_NAVIGATION_ROOT, currentStyle.get(PN_NAVIGATION_ROOT, String.class));
	        if (currentStyle.containsKey(PN_STRUCTURE_START) || properties.containsKey(PN_STRUCTURE_START)) {
	            //workaround to maintain the content of Navigation component of users in case they update to the current i.e. the `structureStart` version.
	            structureStart = properties.get(PN_STRUCTURE_START, currentStyle.get(PN_STRUCTURE_START, 1));
	        } else {
	            skipNavigationRoot = properties.get(PN_SKIP_NAVIGATION_ROOT, currentStyle.get(PN_SKIP_NAVIGATION_ROOT, true));
	            if (skipNavigationRoot) {
	                structureStart = 1;
	            } else {
	                structureStart = 0;
	            }
	        }
	    }
	    /**
	     * Builds the navigation item for a {@code NavigationItem} page.
	     *
	     * @param NavigationItem the global navigation (start page)
	     * @param pages the current sub-tree root (changes depending on the level of recursion)
	     * @return the list of collected navigation item
	     */
	    @Override
	    public List<NavigationItem> getItem() {
	        if (item == null) {
	            PageManager pageManager = currentPage.getPageManager();
	            Page rootPage = pageManager.getPage(navigationRootPage);
	            if (rootPage != null) {
	                NavigationRoot navigationRoot = new NavigationRoot(rootPage, structureDepth);
	                Page navigationRootLanguageRoot = navigationRoot.getPageResource().map(languageManager::getLanguageRoot).orElse(null);
	                Page currentPageLanguageRoot = languageManager.getLanguageRoot(currentPage.getContentResource());
	                RangeIterator liveCopiesIterator = null;
	                try {
	                    liveCopiesIterator = relationshipManager.getLiveRelationships(navigationRoot.page.adaptTo(Resource.class), null, null);
	                } catch (WCMException e) {
	                    // ignore it
	                }
	                if (navigationRootLanguageRoot != null && currentPageLanguageRoot != null && !navigationRootLanguageRoot.equals
	                        (currentPageLanguageRoot)) {
	                    // check if there's a language copy of the navigation root
	                    Page languageCopyNavigationRoot = pageManager.getPage(ResourceUtil.normalize(currentPageLanguageRoot.getPath() + "/" +
	                            getRelativePath(navigationRootLanguageRoot, navigationRoot.page)));
	                    if (languageCopyNavigationRoot != null) {
	                        navigationRoot = new NavigationRoot(languageCopyNavigationRoot, structureDepth);
	                    }
	                } else if (liveCopiesIterator != null) {
	                    while (liveCopiesIterator.hasNext()) {
	                        LiveRelationship relationship = (LiveRelationship) liveCopiesIterator.next();
	                        if (currentPage.getPath().startsWith(relationship.getTargetPath() + "/")) {
	                            Page liveCopyNavigationRoot = pageManager.getPage(relationship.getTargetPath());
	                            if (liveCopyNavigationRoot != null) {
	                                navigationRoot = new NavigationRoot(liveCopyNavigationRoot, structureDepth);
	                                break;
	                            }
	                        }
	                    }
	                }
	                item = getNavigationTree(navigationRoot);
	            } else {
	                item = Collections.emptyList();
	            }
	        }
	        return Collections.unmodifiableList(item);
	    }

	    @Override
	    public String getAccessibilityLabel() {
	        return navigation.getAccessibilityLabel();
	    }

	    @NotNull
	    @Override
	    public String getExportedType() {
	        return navigation.getExportedType();
	    }

	    /**
	     * Builds the navigation item for a {@code NavigationItem} page.
	     *
	     * @param NavigationItem the global navigation (start page)
	     * @param pages the current sub-tree root (changes depending on the level of recursion)
	     * @return the list of collected navigation item
	     */
	    private List<NavigationItem> getItem(NavigationRoot navigationRoot, Page subtreeRoot) {
	        List<NavigationItem> pages = new ArrayList<>();
	        if (navigationRoot.structureDepth == -1 || getLevel(subtreeRoot) < navigationRoot.structureDepth) {
	            Iterator<Page> it = subtreeRoot.listChildren(new PageFilter());
	            while (it.hasNext()) {
	                Page page = it.next();
	                int pageLevel = getLevel(page);
	                int level = pageLevel - navigationRoot.startLevel - 1;
	                List<NavigationItem> children = getItem(navigationRoot, page);
	                boolean isSelected = checkSelected(page);
	                if (structureStart == 0) {
	                    level = level + 1;
	                }
	                pages.add(new NavigationItemImpl(page, isSelected, request, level, children));
	            }
	        }
	        return pages;
	    }
	    /**
	     * Builds the navigation tree for a {@code navigationRoot} page.
	     *
	     * @param navigationRoot the global navigation tree root (start page)
	     * @param subtreeRoot the current sub-tree root (changes depending on the level of recursion)
	     * @return the list of collected navigation trees
	     */
	    private List<NavigationItem> getNavigationTree(NavigationRoot navigationRoot) {
	        List<NavigationItem> itemTree = new ArrayList<>();
	        Iterator<NavigationRoot> it = getRootItems(navigationRoot, structureStart).iterator();
	        while (it.hasNext()) {
	            NavigationRoot item = it.next();
	            itemTree.addAll(getItem(item, item.page));
	        }
	        if (structureStart == 0) {
	            boolean isSelected = checkSelected(navigationRoot.page);
	            NavigationItemImpl root = new NavigationItemImpl(navigationRoot.page, isSelected, request, 0, itemTree);
	            itemTree = new ArrayList<>();
	            itemTree.add(root);
	        }
	        return  itemTree;
	    }
	    /**
	     * Builds the navigation tree for a {@code navigationRoot} page.
	     *
	     * @param navigationRoot the global navigation tree root (start page)
	     * @param page the current sub-tree root (changes depending on the level of recursion)
	     * @return the list of collected navigation Root
	     */
	    private List<NavigationRoot> getRootItems(NavigationRoot navigationRoot, int structureStart) {
	        LinkedList<NavigationRoot> pages = new LinkedList<>();
	        pages.addLast(navigationRoot);
	        if (structureStart != 0) {
	            int level = 1;
	            while (level != structureStart && !pages.isEmpty()) {
	                int size = pages.size();
	                while (size > 0) {
	                    NavigationRoot item = pages.removeFirst();
	                    Iterator<Page> it = item.page.listChildren(new PageFilter());
	                    while (it.hasNext()) {
	                        pages.addLast(new NavigationRoot(it.next(), structureDepth));
	                    }
	                    size = size - 1;
	                }
	                level = level + 1;
	            }
	        }
	        return pages;
	    }

	    private boolean checkSelected(Page page) {
	        return this.currentPage.equals(page) ||
	                this.currentPage.getPath().startsWith(page.getPath() + "/") ||
	                currentPageIsRedirectTarget(page);
	    }

	    private boolean currentPageIsRedirectTarget(Page page) {
	        boolean currentPageIsRedirectTarget = false;
	        Resource contentResource = page.getContentResource();
	        if (contentResource != null) {
	            ValueMap valueMap = contentResource.getValueMap();
	            String redirectTarget = valueMap.get(PageImpl.PN_REDIRECT_TARGET, String.class);
	            if(StringUtils.isNotBlank(redirectTarget)) {
	                PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
	                if (pageManager != null) {
	                    Page redirectPage = pageManager.getPage(redirectTarget);
	                    if (currentPage.equals(redirectPage)) {
	                        currentPageIsRedirectTarget = true;
	                    }
	                }
	            }
	        }
	        return currentPageIsRedirectTarget;
	    }

	    private int getLevel(Page page) {
	        return StringUtils.countMatches(page.getPath(), "/") - 1;
	    }

	    @Nullable
	    private String getRelativePath(@NotNull Page root, @NotNull Page child) {
	        if (child.equals(root)) {
	            return ".";
	        } else if ((child.getPath() + "/").startsWith(root.getPath())) {
	            return child.getPath().substring(root.getPath().length() + 1);
	        }
	        return null;
	    }

	    private class NavigationRoot {
	        final Page page;
	        int startLevel;
	        int structureDepth = -1;

	        private NavigationRoot(@NotNull Page navigationRoot, int configuredStructureDepth) {
	            page = navigationRoot;
	            this.startLevel = getLevel(navigationRoot);
	            if (configuredStructureDepth > -1) {
	                structureDepth = configuredStructureDepth + startLevel;
	            }
	        }

	        /**
	         * Gets the resource representation of the navigation root page.
	         *
	         * @return the resource for the navigation root, empty if the resource could not be resolved
	         */
	        @NotNull
	        final Optional<Resource> getPageResource() {
	            return Optional.ofNullable(
	                Optional.of(this.page)
	                    // get the parent of the content resource
	                    .map(Page::getContentResource)
	                    .map(Resource::getParent)
	                    // if content resource is missing, resolve resource at page path
	                    .orElseGet(() -> resourceResolver.getResource(this.page.getPath())));
	        }
	    }

	    /**
		 * @return the NavigationLinksItemModel
		 */
	    @Override
	    public List<NavigationLinksItemModel> getNavigationLinks() {
	    	List<NavigationLinksItemModel> navLinksItem = new ArrayList<NavigationLinksItemModel>();
	    	Resource navResource = parentResource.getChild("navigationLinks");
	    	if(navResource != null) {
	    		navResource.getChildren().forEach(res -> {
	    			navLinksItem.add(res.adaptTo(NavigationLinksItemModel.class));
	    		});
	    	}
	        return navLinksItem;
	    }
	    
		/**
		 * @return the cartUrlTarget
		 */
	    @Override
		public Boolean getCartUrlTarget() {
			return Optional.ofNullable(parentResource).map(Resource::getValueMap)
					.map(vm -> vm.get("cartUrlTarget", Boolean.class)).orElse(false);
		}
	    
	    /**
		 * @return the CartIconUrl
		 */
	    @Override
		public String getCartIconUrl() {
			return Optional.ofNullable(parentResource).map(Resource::getValueMap).map(vm -> vm.get("cartIconUrl", String.class))
					.map(url -> ApplicationUtil.getShortUrl(resourceResolver, url)).orElse("");
		}
	    /**
		 * @return the Search Enable/Disable
		 */
	    @Override
		public Boolean getSearchDisable() {
			return Optional.ofNullable(parentResource).map(Resource::getValueMap)
					.map(vm -> vm.get("searchDisable", Boolean.class)).orElse(false);
		}
	    /**
		 * <p>
		 * Fetches flexible navigation width
		 * </p>
		 * 
		 * @return String - flexible navigation width
		 */
		@Override
		public boolean getFlexibleNavigationWidth() {
			return flexibleNavigationWidth;
		}    
	    
}