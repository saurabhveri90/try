/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Multi-Links} Sling Model used for the {@code /apps/tracfone-core/components/spa/commerce/handsetprotection} component.
 */
public interface HandsetProtectionModel extends ComponentExporter {
	

	
}
