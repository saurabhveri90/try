package com.tracfonecore.core.models;

import java.util.List;
import java.util.Map;

import com.adobe.cq.export.json.ComponentExporter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the {@code Carousel} Sling Model used for the {@code /apps/tracfone-core/components/content/carouselcontainer} component.
 */
public interface CarouselContainerModel extends ComponentExporter  {
	/**
	 * <p>Fetches type of the carousel to define the layout</p>
	 * 
	 * @return String - type of the carousel
	 */
	@JsonProperty("type")
	public String getType();
	
	/**
	 * <p>Fetches number of cards to be displayed by default</p>
	 * 
	 * @return int - no. of cards
	 */
	@JsonProperty("noOfCards")
	public int getNoOfCards();
	
	
	/**
	 * <p>Fetches number of slides to be displayed in carousel</p>
	 * 
	 * @return int - no. of items
	 */
	@JsonProperty("itemsCount")
	public int getItemsCount();
	
	/**
	 * <p>Fetches number of cards to be displayed by default on Phone card</p>
	 * 
	 * @return int - no. of cards to be displayed on Phone card
	 */
	@JsonProperty("noOfCardsPhone")
	public int getNoOfCardsPhone();
	
	/**
	 * <p>Fetches number of cards to be displayed by default on Plans card</p>
	 * 
	 * @return int - no. of cards to be displayed on Plans card
	 */
	@JsonProperty("noOfCardsPlans")
	public int getNoOfCardsPlans();
	
	/**
	 * <p>Fetches number of cards to be displayed by default on Rewards</p>
	 * 
	 * @return int - no. of cards to be displayed on Rewards
	 */
	@JsonProperty("noOfCardsRewards")
	public int getNoOfCardsRewards();
	
	/**
	 * <p>Fetches number of cards to be displayed by default on Featured App</p>
	 * 
	 * @return int - no. of cards to be displayed on Featured App
	 */
	@JsonProperty("noOfCardsFeaturedApp")
	public int getNoOfCardsFeaturedApp();
	/**
	 * <p>Fetches number of cards to be displayed by default on Featured App</p>
	 *
	 * @return int - no. of cards to be displayed on Featured App
	 */
	@JsonProperty("noOfCardsRecomPlan")
	public int getNoOfCardsRecomPlan();

	/**
	 * <p>
	 * Fetches totalItemsList
	 * </p>
	 *
	 * @return the totalItemsList
	 */
	public List<Integer> getTotalItemsList();
	
	/**
	 * <p>
	 * Fetches autoScroll value for carousel
	 * </p>
	 *
	 * @return String -  auto Scroll value for the sequential cards
	 */
	 public String getAutoScroll();
	 
		/**
	  * <p>
	 * Fetches the export child items
	 * </p>
	 *
	 * 
	 * @return Map<String, ? extends ComponentExporter> - the export child items
	 */
	public Map<String, ? extends ComponentExporter> getItems();
	
	/**
	 * <p>Fetches Carousel speed in milliseconds</p>
	 * 
	 * @return int - carousel speed in milliseconds
	 */
	@JsonProperty("carouselSpeed")
	public int getCarouselSpeed();

	/**
	 * <p>Fetches smartPayMessagelogo getches</p>
	 * 
	 * @return int - smartPayMessagelogo 
	 */
	@JsonProperty("smartPayMessagelogo")
	public String getSmartPayMessagelogo();

	/**
	 *<p>Fetches smartPayMessagePrefix</p>
	 *
	 * @return the smartPayMessagePrefix
	 */
	@JsonProperty("smartPayMessagePrefix")
	public String getSmartPayMessagePrefix() ;

   	/**
	 *<p>Fetches smartPayMessageSuffix</p>
	 *
	 * @return the smartPayMessageSuffix
	 */
	@JsonProperty("smartPayMessageSuffix")
	public String getSmartPayMessageSuffix();

	/**
	 * <p>Fetches carousel ful-width banner width</p>
	 * 
	 * @return boolean - ful-width banner width
	 */
	@JsonProperty("doNotUseFullWidth")
	public boolean isDoNotUseFullWidth();

	/**
	 * <p>Fetches carousel banner narrow</p>
	 *
	 * @return boolean - carousel banner narrow
	 */
	@JsonProperty("carouselBannerNarrow")
	public boolean isCarouselBannerNarrow();

	/**
	 * <p>Select to render plans carousel multiline</p>
	 * 
	 * @return boolean - show plans as a multiline
	 */
	@JsonProperty("multilinePlanSelection")
	public String getMultilinePlanSelection();

	/**
	 * <p>Plans path to get all the plans</p>
	 * 
	 * @return String - plans path
	 */
	@JsonProperty("plansPdpPath")
	public String getPlansPdpPath();
	
}