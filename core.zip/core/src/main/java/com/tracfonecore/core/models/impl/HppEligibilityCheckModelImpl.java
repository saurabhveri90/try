/*
 *  Copyright 2019 HCL Technologies Ltd.
 *
 *  
 */
package com.tracfonecore.core.models.impl;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.tracfonecore.core.constants.CommerceConstants;
import com.tracfonecore.core.models.HppEligibilityCheckModel;
import com.tracfonecore.core.services.TracfoneApiGatewayService;


@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = { HppEligibilityCheckModel.class,ComponentExporter.class }, 
resourceType = "tracfone-core/components/commerce/hppeligibilitychecker", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, selector = ExporterConstants.SLING_MODEL_SELECTOR, 
extensions = ExporterConstants.SLING_MODEL_EXTENSION, options = { 
		@ExporterOption(name = "MapperFeature.SORT_PROPERTIES_ALPHABETICALLY", value = "true"),
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class HppEligibilityCheckModelImpl extends BaseComponentModelImpl implements HppEligibilityCheckModel {

	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String heading;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String dropdownLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String textboxLabel;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String privacyPolicy;

	@Inject
	private TracfoneApiGatewayService tracfoneApiService;


	private static final Logger LOGGER = LoggerFactory.getLogger(HppEligibilityCheckModelImpl.class);

	@PostConstruct
	protected void initModel() {
		LOGGER.debug("Entering initModel method");
		super.initModel();
	}
	
	@Override
	public String getExportedType() {

		return request.getResource().getResourceType();
	}

	@Override
	public String getHeading() {

		return heading;
	}

	@Override
	public String getDropdownLabel() {

		return dropdownLabel;
	}

	@Override
	public String getTextboxLabel() {

		return textboxLabel;
	}

    @Override
    public String getPrivacyPolicy() {
		
	    return privacyPolicy;
    }

	/**
	 * @return String - apiDomain
	 */
	public String getApiDomain() {

		return tracfoneApiService.getApiDomain();
	}

	/**
	 * @return String -  AccountProfileApiPath
	 */
	public String getAccountProfileApiPath() {

		return tracfoneApiService.getAccountProfileApiPath();
	}

	/**
	 * @return String -  AccountProfileApiPath
	 */
	public String getResourceMgmtApiPath() {

		return tracfoneApiService.getResourceMgmtApiPath();
	}
	
	/**
	 * @return String -  ResourceMgmtApiProjection
	 */
	public String getResourceMgmtApiProjection() {

		return tracfoneApiService.getResourceMgmtApiProjection();
	}

	/**
	 * @return String -  AccountProfile API Query String
	 */
	public String getAccountProfileQuery() {

		StringBuilder query = new StringBuilder(CommerceConstants.VIEW).append(CommerceConstants.EQUALS_TO)
				.append(CommerceConstants.VIEW_TYPE_FULL);

		return query.toString();
	}

	public String getResourceMgmtQuery() {

		StringBuilder query = new StringBuilder(CommerceConstants.RESOURCE_CATEGORY).append(CommerceConstants.EQUALS_TO)
				.append(CommerceConstants.LINE).append(CommerceConstants.AMPERSAND).append(CommerceConstants.PROJECTION).append(CommerceConstants.EQUALS_TO)
				.append(CommerceConstants.BASIC_INFO).append(CommerceConstants.AMPERSAND).append(CommerceConstants.RESOURCE_IDENTIFIER).append(CommerceConstants.EQUALS_TO);

		return query.toString();
	}


}